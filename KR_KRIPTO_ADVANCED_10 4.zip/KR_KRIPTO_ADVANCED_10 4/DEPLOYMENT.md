# Documentação de Implantação - KR Kripto Advanced

Este documento descreve como implantar e executar a aplicação KR Kripto Advanced usando Docker e Docker Compose.

## Pré-requisitos

*   **Docker:** Certifique-se de que o Docker Engine esteja instalado em seu sistema. Consulte a [documentação oficial do Docker](https://docs.docker.com/engine/install/) para obter instruções de instalação.
*   **Docker Compose:** Certifique-se de que o Docker Compose (v2 ou superior) esteja instalado. Consulte a [documentação oficial do Docker Compose](https://docs.docker.com/compose/install/) para obter instruções.
*   **Código Fonte:** Clone ou baixe o repositório do projeto KR Kripto Advanced.

## Configuração do Ambiente

1.  **Diretório do Projeto:** Navegue até o diretório raiz do projeto (`KR_KRIPTO_ADVANCED_REORGANIZED`).
2.  **Arquivo de Configuração (`config.json`):** Certifique-se de que o arquivo `config.json` esteja presente no diretório raiz e configurado corretamente para suas necessidades (ativos, parâmetros de estratégia, etc.).
3.  **Chaves de API (Opcional, mas recomendado):**
    *   Crie um arquivo chamado `.env` no diretório raiz do projeto.
    *   Adicione suas chaves de API da Binance (ou Testnet) a este arquivo:
        ```env
        BINANCE_API_KEY=SUA_API_KEY_AQUI
        BINANCE_API_SECRET=SEU_API_SECRET_AQUI
        ```
    *   O `docker-compose.yml` está configurado para ler essas variáveis de ambiente e passá-las para os contêineres. **Nunca** comite o arquivo `.env` no controle de versão.
4.  **Dados Históricos (Opcional):** Se você possui dados históricos pré-processados, coloque-os no diretório `data/`.

## Construção das Imagens Docker

Antes de executar os serviços pela primeira vez, ou após alterações no `Dockerfile` ou `requirements.txt`, você precisa construir as imagens Docker.

No diretório raiz do projeto, execute:

```bash
docker-compose build
```

Isso construirá a imagem definida no `Dockerfile`, baixando as dependências e copiando o código da aplicação.

## Executando a Aplicação

Você pode executar a aplicação em diferentes modos usando Docker Compose.

### Modo Standalone

Este modo executa uma única instância da aplicação, adequada para testes ou operação com poucos ativos.

```bash
docker-compose up kripto_standalone
```

Para executar em segundo plano (detached mode):

```bash
docker-compose up -d kripto_standalone
```

*   **Métricas Prometheus:** Acessíveis em `http://localhost:8000/metrics`.

### Modo Cluster (Master/Worker)

Este modo executa um nó mestre e um ou mais nós workers, distribuindo o processamento de ativos.

1.  **Iniciar Master e Worker(s):**
    ```bash
    docker-compose up kripto_master kripto_worker
    ```

2.  **Iniciar em Segundo Plano:**
    ```bash
    docker-compose up -d kripto_master kripto_worker
    ```

3.  **Escalar Workers (Opcional):**
    Para iniciar múltiplos workers (ex: 3 workers):
    ```bash
    docker-compose up -d --scale kripto_worker=3 kripto_master
    ```

*   **Métricas Prometheus (Master):** Acessíveis em `http://localhost:8001/metrics` (note a porta diferente definida no `docker-compose.yml` para evitar conflito com o modo standalone).
*   **Comunicação:** Master e workers se comunicam internamente através da rede Docker `kripto_net` usando ZeroMQ.

## Verificando Logs

Para visualizar os logs dos contêineres em execução:

*   **Modo Standalone:**
    ```bash
    docker-compose logs -f kripto_standalone
    ```
*   **Modo Cluster:**
    ```bash
    docker-compose logs -f kripto_master kripto_worker
    ```
    (Use `docker ps` para ver os nomes exatos dos contêineres dos workers se escalados).

Alternativamente, os logs também são escritos nos arquivos dentro do diretório `logs/` montado nos contêineres.

## Parando a Aplicação

Para parar os contêineres:

*   **Se executando em primeiro plano:** Pressione `Ctrl+C` no terminal onde `docker-compose up` foi executado.
*   **Se executando em segundo plano (`-d`):**
    ```bash
    docker-compose down
    ```
    O comando `docker-compose down` para e remove os contêineres, redes e volumes (se não forem externos) definidos no `docker-compose.yml`.

## Health Checks

O `docker-compose.yml` inclui `healthcheck` para os serviços:

*   `kripto_standalone` e `kripto_master`: Verificam se o endpoint `/metrics` está respondendo.
*   `kripto_worker`: Verifica se o processo Python principal do worker está em execução.

You can check the health status using `docker ps`.

