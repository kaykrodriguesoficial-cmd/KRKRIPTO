# KR_KRIPTO_ADVANCED (Reorganized)

Este é o projeto KR Kripto Advanced, um bot de trading algorítmico para a Binance, reorganizado para melhor clareza, modularidade e manutenibilidade.

## Visão Geral

O bot conecta-se ao stream de dados da Binance para múltiplos ativos, processa dados de klines e book de ofertas em tempo real, aplica uma variedade de indicadores técnicos e modelos de IA (incluindo Transformers, Reinforcement Learning e AutoML, se disponíveis) para gerar sinais de compra/venda, e envia notificações via Telegram.

## Estrutura do Projeto

A estrutura foi reorganizada da seguinte forma:

```
KR_KRIPTO_ADVANCED_REORGANIZED/
├── main.py                 # Script principal de execução
├── requirements.txt        # Dependências Python
├── config.json             # Arquivo de configuração (API keys, ativos, limiares, etc.)
├── README.md               # Este arquivo
├── logs/                   # Diretório de logs gerados pelo bot
├── data/                   # Diretório para dados históricos baixados
├── models/                 # Diretório para modelos de IA (ex: Transformer)
└── src/                    # Código fonte principal
    ├── __init__.py
    ├── core/               # Lógica central (conexão, processamento de dados, loop principal)
    ├── strategies/         # Lógica da estratégia (cálculo de score, classificação, validação, risco)
    │   └── validators/     # Submódulos de validação
    ├── intelligence/       # Componentes avançados de IA/ML (feedback, evolução, predição, RL, AutoML)
    │   ├── automl/
    │   └── rl/
    ├── realtime/           # Processamento do book de ofertas em tempo real
    ├── infrastructure/     # Módulos de suporte (logging, notificação, segurança, memória)
    ├── dashboard/          # Código do Dashboard (se disponível)
    └── tests/              # Testes (a serem implementados)
```

## Configuração

1.  **Clonar o Repositório:** (Assumindo que está em um repositório git)
    ```bash
    git clone <url_do_repositorio>
    cd KR_KRIPTO_ADVANCED_REORGANIZED
    ```
2.  **Instalar Dependências:**
    ```bash
    pip install -r requirements.txt
    ```
3.  **Configurar `config.json`:**
    *   Crie ou edite o arquivo `config.json` na raiz do projeto.
    *   Adicione suas chaves de API da Binance (se necessário para funcionalidades futuras, o stream atual é público).
    *   Configure a lista de `ativos` que deseja monitorar (ex: `["BTCUSDT", "ETHUSDT"]`).
    *   Configure as credenciais do bot do Telegram (`telegram_token`, `telegram_chat_id`).
    *   Ajuste outros parâmetros como `limiar_compra`, `limiar_venda`, etc., conforme necessário.
    *   Exemplo básico:
        ```json
        {
          "ativos": ["BTCUSDT", "ETHUSDT"],
          "limiar_compra": 0.65,
          "limiar_venda": 0.35,
          "telegram_token": "SEU_TOKEN_AQUI",
          "telegram_chat_id": "SEU_CHAT_ID_AQUI",
          "binance_api_key": "SUA_API_KEY",
          "binance_api_secret": "SEU_API_SECRET"
        }
        ```
4.  **Modelos e Chaves:**
    *   Coloque os modelos de IA necessários (ex: `modelo_transformer_futuro.h5`, `modelo_transformer_futuro.sig`) no diretório `models/`.
    *   Coloque a chave pública (`chave_publica.pem`) no diretório `config/` (ou ajuste o caminho em `main.py` se necessário).

## Execução

Para iniciar o bot, execute o script `main.py` a partir do diretório raiz do projeto:

```bash
python main.py [ATIVO1] [ATIVO2] ...
```

*   Se nenhum ativo for fornecido na linha de comando, o bot tentará carregar a lista de `ativos` do arquivo `config.json`.
*   O bot se conectará aos streams da Binance para os ativos especificados e começará a processar os dados e gerar logs.
*   Use `Ctrl+C` para encerrar o bot graciosamente.

## Módulos Principais (`src/`)

*   **`core`**: Contém a lógica principal para carregar configuração, gerenciar dados históricos, conectar ao WebSocket da Binance e orquestrar a análise de sinais.
*   **`strategies`**: Implementa as lógicas específicas de trading, incluindo o cálculo de score (`score_calculator.py`), classificação de sinais (`signal_classifier.py`), detecção de padrões (`fakeout.py`), gerenciamento de risco (`risk_manager.py`) e validações diversas (`validators/`).
*   **`intelligence`**: Agrupa os componentes mais avançados de IA e aprendizado de máquina, como feedback loops, evolução de modelos, motores de predição, Reinforcement Learning e AutoML.
*   **`realtime`**: Focado no processamento em tempo real do book de ofertas para identificar desequilíbrios e padrões institucionais.
*   **`infrastructure`**: Fornece serviços de suporte essenciais como logging, notificações (Telegram), gerenciamento de memória temporal, segurança (verificação de assinatura) e mecanismos de fallback/rollback.
*   **`dashboard`**: Contém o código para a interface de monitoramento web (se o módulo Dash estiver instalado e habilitado).

## Observações

*   Esta versão reorganizada visa melhorar a estrutura. A lógica interna dos módulos de `intelligence` e outros pode exigir refatoração adicional para remover redundâncias (arquivos `_CORRIGIDO`) e melhorar a coesão.
*   Testes unitários e de integração devem ser adicionados no diretório `tests/` para garantir a robustez do sistema.
*   A gestão de dependências no `requirements.txt` é inicial e pode precisar ser refinada.




## Melhorias Recentes (Auditoria e Refatoração - Fase 2)

Esta seção detalha as melhorias implementadas durante a segunda fase da auditoria e refatoração, focada na revisão do código, implementação de testes e aprimoramento da estrutura:

1.  **Consolidação de Módulos:**
    *   **Validadores:** Os módulos de validação (`book_imbalance.py`, `filtros_institucionais.py`, etc.) foram movidos do local incorreto (`src/intelligence/validadores`) para o diretório correto `src/strategies/validators/`, melhorando a coesão da lógica de estratégia.
    *   **Segurança:** A função `validar_modelo_sha256` foi movida de `src/intelligence/seguranca` para `src/infrastructure/security.py`, consolidando as funcionalidades de verificação de modelo em um único local.
2.  **Remoção de Redundâncias:**
    *   O arquivo `src/intelligence/preditores/ia_futuro.py` foi removido, pois era uma versão redundante e menos completa do `ia_futuro_transformer_v1.py`.
    *   O arquivo `src/intelligence/seguranca/verificador_modelo_v1.py` foi removido após a consolidação da sua função.
3.  **Refatoração do Core Logic:**
    *   As funções centrais de processamento (`validar_entrada_sinal`, `analisar_sinal`, `processar_mensagem`, `conectar_binance`) foram extraídas do script principal (`main.py`) e movidas para módulos dedicados em `src/core/` (`signal_processor.py`, `binance_stream.py`) e `src/strategies/validators/` (`input_validator.py`).
    *   O `main.py` foi significativamente simplificado, atuando agora principalmente como orquestrador, inicializador de estado e ponto de entrada.
    *   Essa refatoração desacoplou a lógica principal do ponto de entrada, melhorando drasticamente a modularidade e a testabilidade do sistema.
4.  **Implementação de Testes:**
    *   Uma estrutura de diretórios para testes foi criada em `src/tests/`.
    *   A biblioteca `pytest` foi adicionada como dependência de desenvolvimento (precisa ser adicionada ao `requirements.txt` ou um `requirements-dev.txt`).
    *   Testes unitários foram implementados e executados com sucesso para as funções de segurança consolidadas em `src/infrastructure/security.py` (`test_security.py`).
    *   Um teste de integração inicial foi implementado para o fluxo principal de geração de sinal (`test_integration_signal_flow.py`). A execução inicial deste teste revelou a necessidade da refatoração do Core Logic mencionada acima.

**Benefícios:**

*   **Maior Modularidade:** O código está mais organizado em módulos coesos e com responsabilidades bem definidas.
*   **Melhor Testabilidade:** A extração da lógica do `main.py` e a estrutura de testes facilitam a criação e execução de testes unitários e de integração.
*   **Manutenibilidade Aprimorada:** A estrutura mais clara e a redução de redundâncias tornam o código mais fácil de entender, manter e estender.
*   **Robustez:** A identificação e correção de inconsistências estruturais e a validação através de testes aumentam a confiança na corretude do sistema.




## Melhorias Recentes (Fases 4-6: Escalabilidade, Monitoramento, Implantação)

Esta seção detalha as melhorias implementadas durante as fases 4, 5 e 6, focadas em escalabilidade, monitoramento e preparação para implantação:

### Fase 4: Escalabilidade e Manutenção

*   **Modo Cluster (Master/Worker):**
    *   Implementado um `ClusterManager` usando ZeroMQ para comunicação pub/sub entre nós.
    *   O `main.py` foi modificado para suportar os modos de execução `--mode master` e `--mode worker`, além do `standalone` padrão.
    *   O nó master distribui tarefas (ativos) para os workers disponíveis.
    *   Inclui mecanismos de heartbeat e reconexão automática para robustez.
    *   A arquitetura detalhada está documentada em `docs/cluster_architecture.md`.
*   **Auto-Reload de Modelos:**
    *   Implementado um `ModelReloader` que monitora um arquivo flag (`reload.flag`) ou outro gatilho para recarregar modelos de IA (ex: Transformer, RL) sem reiniciar o sistema.
    *   Permite atualizações dinâmicas dos modelos em produção.

### Fase 5: Monitoramento e Alertas

*   **Logging Estruturado JSON:**
    *   Revisado e confirmado que o sistema utiliza logging em formato JSON de forma consistente, facilitando a integração com sistemas de gerenciamento de logs (ex: ELK stack).
*   **Métricas Prometheus:**
    *   Expandido o `PrometheusExporter` (`src/infrastructure/prometheus_exporter.py`) para incluir métricas detalhadas sobre latência de processamento, performance de modelos de IA, estado do cluster, regime de mercado, contagem de erros, ativação de fallback, etc.
    *   O exportador expõe as métricas em um endpoint HTTP (padrão: porta 8000).
*   **Dashboards Grafana:**
    *   Criados arquivos JSON de exemplo (`docs/grafana_system_overview.json`, `docs/grafana_latency_performance.json`, `docs/grafana_governance_rl.json`) que podem ser importados no Grafana para visualizar as métricas Prometheus.
*   **Sistema de Alertas:**
    *   Criado um arquivo de exemplo (`docs/prometheus_alert_rules.yml`) com regras de alerta para o Prometheus/Alertmanager, cobrindo condições críticas como erros, timeouts, ativação de fallback e latência elevada.
*   **Documentação:**
    *   A arquitetura de monitoramento está detalhada em `docs/monitoring_architecture.md`.

### Fase 6: Implantação e Operacionalização

*   **Script de Implantação:**
    *   Criado um script `deploy.sh` que facilita a execução da aplicação, suportando os modos `standalone`, `master` e `worker` através do argumento `--mode`.
*   **Containerização (Docker):**
    *   Criado um `Dockerfile` para construir a imagem da aplicação Python.
    *   Criado um `docker-compose.yml` para orquestrar a execução dos serviços (`kripto_standalone`, `kripto_master`, `kripto_worker`) como contêineres separados, facilitando a implantação e o gerenciamento.
*   **Health Checks:**
    *   Adicionadas verificações de saúde (`healthcheck`) no `docker-compose.yml` para monitorar o estado dos contêineres (verificando o endpoint de métricas ou a execução do processo Python).
*   **Documentação de Implantação:**
    *   Criado o arquivo `DEPLOYMENT.md` detalhando os pré-requisitos (Docker, Docker Compose) e os passos para construir as imagens e executar a aplicação usando Docker Compose.

**Observação:** Os testes de build e execução com Docker não puderam ser validados completamente no ambiente de desenvolvimento atual devido à ausência do Docker, mas os arquivos de configuração estão prontos para uso.




## Guia do Usuário Detalhado

Este guia fornece instruções mais detalhadas para configurar, executar e implantar o KR Kripto Advanced.

### Pré-requisitos

*   Python 3.9 ou superior
*   pip (gerenciador de pacotes Python)
*   Git (para clonar o repositório)
*   **Opcional (para implantação via Docker):**
    *   Docker Engine
    *   Docker Compose

### Instalação

1.  **Clone o Repositório:**
    ```bash
    git clone <url_do_repositorio>
    cd KR_KRIPTO_ADVANCED_REORGANIZED
    ```
2.  **Crie um Ambiente Virtual (Recomendado):**
    ```bash
    python -m venv venv
    source venv/bin/activate  # Linux/macOS
    # OU
    .\venv\Scripts\activate  # Windows
    ```
3.  **Instale as Dependências:**
    ```bash
    pip install -r requirements.txt
    ```

### Configuração (`config.json`)

*   Crie ou edite o arquivo `config.json` na raiz do projeto.
*   **Essencial:**
    *   `ativos`: Lista de pares de moedas a serem monitorados (ex: `["BTCUSDT", "ETHUSDT"]`).
    *   `telegram_token`: Token do seu bot do Telegram para notificações.
    *   `telegram_chat_id`: ID do chat do Telegram para onde as notificações serão enviadas.
*   **Opcional (para funcionalidades específicas):**
    *   `binance_api_key`, `binance_api_secret`: Chaves de API da Binance (necessárias para operações de trade reais, não apenas para o stream de dados).
    *   `limiar_compra`, `limiar_venda`: Limiares de score para gerar sinais.
    *   Outros parâmetros específicos de estratégias ou módulos.
*   **Modelos e Chaves:**
    *   Coloque os modelos de IA (`.h5`, `.sig`, etc.) no diretório `models/`.
    *   Coloque a chave pública (`chave_publica.pem`) no diretório `config/` (ou ajuste o caminho no código, se necessário).

### Execução Local (Standalone)

Use o script `main.py` diretamente ou o script `deploy.sh`:

*   **Via `main.py`:**
    ```bash
    python main.py [ATIVO1] [ATIVO2] ...
    ```
    (Se nenhum ativo for fornecido, usará a lista do `config.json`)

*   **Via `deploy.sh` (Modo Standalone - Padrão):**
    ```bash
    ./deploy.sh
    # OU especificando ativos
    # ./deploy.sh --ativos BTCUSDT ETHUSDT
    ```

### Execução em Cluster (Master/Worker)

Use o script `deploy.sh` em terminais separados:

1.  **Terminal 1 (Master):**
    ```bash
    ./deploy.sh --mode master
    ```
2.  **Terminal 2 (Worker 1):**
    ```bash
    ./deploy.sh --mode worker
    ```
3.  **Terminal 3 (Worker 2, etc.):**
    ```bash
    ./deploy.sh --mode worker
    ```
    O nó master distribuirá os ativos configurados entre os workers disponíveis.

### Implantação com Docker Compose

Consulte o arquivo `DEPLOYMENT.md` para instruções detalhadas sobre como construir as imagens Docker e executar os serviços (`standalone`, `master`, `worker`) usando `docker-compose up`.

## Problemas Conhecidos

Durante a fase de testes finais, foram identificados os seguintes problemas que ainda precisam ser resolvidos:

1.  **Falha nos Testes End-to-End (`test_end_to_end.py`):**
    *   **Sintoma:** A execução de `pytest tests/test_end_to_end.py` falha consistentemente com um erro `pytest: error: unrecognized arguments: tests/test_end_to_end.py`.
    *   **Causa Provável:** Apesar de várias tentativas de correção (mocking de `sys.argv`, `parse_args`, refatoração do `main.py`), a biblioteca `argparse` utilizada no `main.py` ainda entra em conflito com a forma como o `pytest` coleta e executa os testes.
    *   **Status:** Bug conhecido. A funcionalidade principal testada manualmente parece estável, mas a validação automatizada E2E está bloqueada.

2.  **Erro nos Testes Unitários do Risk Manager (`test_risk_manager.py`):**
    *   **Sintoma:** A execução de `pytest tests/test_risk_manager.py` falha com `AttributeError: LATERAL_ALTA_VOL` em múltiplos testes parametrizados e funções de teste.
    *   **Causa Provável:** A implementação da função `aplicar_risco` em `src/strategies/risk_manager.py` parece ainda estar utilizando o valor antigo `MarketRegime.LATERAL_ALTA_VOL`, que foi renomeado para `MarketRegime.ALTA_VOLATILIDADE` na enumeração `MarketRegime` em `src/intelligence/context_switcher.py`. As referências no arquivo de teste foram corrigidas, mas o erro persiste, apontando para a implementação.
    *   **Status:** Bug conhecido. A lógica de ajuste de risco para alta volatilidade pode não estar funcionando como esperado até que a implementação seja corrigida.

3.  **Outras Falhas de Testes Unitários/Integração:**
    *   A execução completa de `pytest` revela outras falhas e erros em diversos módulos (ex: `test_rl_integration.py`, `test_simulator.py`, `test_filtros_institucionais.py`, etc.). Estes não foram investigados a fundo nesta fase, mas indicam a necessidade de revisão e correção adicionais para garantir a robustez completa do sistema.

**Recomendação:** Priorizar a correção do bug no `risk_manager.py` e investigar as demais falhas de teste antes de considerar o sistema totalmente pronto para produção (GO-LIVE).

