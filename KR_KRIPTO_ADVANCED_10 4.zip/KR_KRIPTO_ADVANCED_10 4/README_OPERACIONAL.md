# KR_KRIPTO_ADVANCED - README Operacional

Este documento fornece um guia operacional para o sistema KR_KRIPTO_ADVANCED, detalhando sua configuração, inicialização, componentes críticos, mecanismos de fail-safe e procedimentos de validação. O objetivo é garantir que os operadores possam executar e monitorar o sistema de forma eficaz e segura em um ambiente de produção.

## 1. Visão Geral do Sistema

O KR_KRIPTO_ADVANCED é um sistema de análise e processamento de sinais de mercado financeiro, projetado para identificar oportunidades de trade com base em múltiplos algoritmos e camadas de inteligência. Ele incorpora detecção de anomalias de mercado, rastreamento de performance de modelos e governança neural para otimização contínua.

## 2. Pré-requisitos

- Python 3.9 ou superior.
- Dependências listadas em `requirements.txt` devidamente instaladas em um ambiente virtual.
- Acesso aos dados de mercado necessários (configurados via API ou similar).
- Configuração correta do arquivo `config.json`.

## 3. Estrutura do Projeto

O código-fonte principal está localizado no diretório `src/` e está organizado nos seguintes subdiretórios:
- `core/`: Componentes centrais do sistema, como o processador de sinais.
- `intelligence/`: Módulos de inteligência, incluindo o detector de ataques, o rastreador de performance e a governança neural.
- `strategies/`: Estratégias e classificadores de sinais.
- `infrastructure/`: Módulos de infraestrutura, como logging, exportador Prometheus e gerenciamento de memória.

O arquivo principal de execução é `main.py`.
O arquivo de configuração principal é `config.json`.

## 4. Configuração (`config.json`)

O arquivo `config.json` é crucial para o funcionamento do sistema. Ele controla a ativação de módulos, parâmetros de estratégias, credenciais de API (se aplicável), e outros aspectos operacionais. As seções mais importantes incluem:

- `components_activation`:
    - `attack_detector_active`: (true/false) Ativa/desativa o `AttackDetector`.
    - `model_performance_tracker_active`: (true/false) Ativa/desativa o `ModelPerformanceTracker`.
    - `neural_governor_active`: (true/false) Ativa/desativa o `NeuralGovernor`.
    - `institutional_validator_active`: (true/false) Ativa/desativa o `InstitutionalValidator`.
- `api_keys`: Configurações para APIs externas (ex: corretoras, provedores de dados).
- `logging`: Configurações de nível de log e formato.
- Outras seções específicas de cada módulo ou estratégia.

**Importante:** É fundamental que os componentes críticos (`AttackDetector`, `ModelPerformanceTracker`, `NeuralGovernor`, `InstitutionalValidator`) estejam marcados como `true` em `components_activation` para operação completa e segura. Se algum for definido como `false`, o sistema registrará sua inatividade, mas poderá prosseguir (com funcionalidade reduzida) se não for uma dependência crítica para o fluxo principal configurado.

## 5. Inicialização do Sistema

1.  **Ative o Ambiente Virtual:**
    ```bash
    source venv/bin/activate
    ```
2.  **Navegue até o Diretório Raiz do Projeto:**
    ```bash
    cd /path/to/KR_KRIPTO_ADVANCED
    ```
3.  **Execute o Script Principal:**
    ```bash
    python3 main.py
    ```

Durante a inicialização, o sistema realizará as seguintes etapas:
- Carregamento da configuração de `config.json`.
- Inicialização dos componentes configurados como ativos.
- Execução da função `checar_componentes_criticos()`:
    - Esta função verifica se todos os módulos marcados como ativos em `config.json` foram carregados corretamente e são instâncias das suas classes reais.
    - Se um componente crítico estiver configurado como ativo mas falhar na inicialização ou não for encontrado, o sistema registrará um erro crítico e **não prosseguirá com a execução**, abortando para evitar operação em modo degradado.
    - O status de cada componente (operacional ou não) é logado e exportado via Prometheus (`component_operational_status`).

## 6. Componentes Críticos e Fail-Safe

Os seguintes componentes são considerados críticos para a operação segura e eficaz do sistema:

- **`AttackDetector`**: Responsável por identificar manipulações de mercado (spoofing, volume artificial, etc.). Se inativo ou falhar, o sistema fica vulnerável a sinais maliciosos.
- **`ModelPerformanceTracker`**: Coleta métricas de desempenho dos modelos de previsão. Essencial para a `NeuralGovernor` e para a avaliação da eficácia do sistema. A correção do fluxo de `actual_result` garante que ele receba dados reais.
- **`NeuralGovernor`**: Gerencia a seleção e o desempenho dos modelos de previsão. Sua ausência impede a adaptação e otimização dinâmica.
- **`InstitutionalValidator`** (baseado em `filtros_institucionais.py`): Aplica filtros adicionais baseados em critérios institucionais. Sua ausência pode levar à aceitação de sinais de menor qualidade.

**Mecanismos de Fail-Safe Implementados:**

1.  **Parada Crítica na Inicialização:** Se qualquer um dos componentes acima estiver configurado como `active` em `config.json` mas falhar ao ser importado ou inicializado, o sistema **não iniciará**. Uma exceção (`ImportError` ou `RuntimeError`) será levantada, e uma mensagem de erro crítico será logada.
2.  **Verificação em Runtime (em `analisar_sinal`):** Antes de processar cada sinal, a função `analisar_sinal` verifica se os componentes injetados (governor, tracker, attack_detector, institutional_validator) são instâncias válidas. Se um componente estiver habilitado na configuração mas for `None` ou um tipo inesperado em runtime, a função `analisar_sinal` levantará um `RuntimeError` para aquele sinal específico, registrando um erro crítico e impedindo o processamento com um componente degradado.
3.  **Ausência de Fallbacks Silenciosos para Stubs:** Os stubs globais e fallbacks silenciosos para classes vazias (`class X: pass`) foram eliminados. Falhas de importação resultam em erros explícitos.

## 7. Monitoramento e Logs

- **Logs:** O sistema gera logs detalhados sobre suas operações, incluindo o status de inicialização dos componentes, sinais processados, decisões tomadas e quaisquer erros ou avisos. Verifique a configuração de logging em `config.json` para o local e nível dos logs.
- **Prometheus:** Se o `PrometheusExporter` estiver ativo, métricas operacionais são expostas, incluindo:
    - `component_operational_status`: Indica se cada componente crítico está ativo (1) ou inativo/falhou (0).
    - Outras métricas de desempenho e de negócio.

**Indicadores de Modo Degradado ou Falha:**

- **Logs Críticos:** Mensagens de erro com `[CRÍTICO]` ou `[ERROR]` indicam problemas sérios.
- **Métricas do Prometheus:** `component_operational_status` com valor `0` para um componente que deveria estar ativo.
- **Sistema Não Inicia:** Se o sistema não conseguir iniciar e exibir uma `Traceback` relacionada a `ImportError` ou `RuntimeError` na função `checar_componentes_criticos()` ou durante a importação de módulos em `main.py`.

## 8. Procedimentos de Validação e Teste

Para garantir que o sistema está operando corretamente, especialmente após atualizações ou mudanças de configuração, execute os seguintes procedimentos:

1.  **Validação do Status dos Módulos:**
    Execute o script `validation_script_module_status.py` localizado no diretório raiz do projeto:
    ```bash
    python3 validation_script_module_status.py
    ```
    Este script verifica se todos os componentes críticos configurados como ativos estão corretamente carregados. A saída esperada é um JSON indicando `true` para todos os componentes ativos e um log (`validation_script_module_status_SUCCESS_OUTPUT.txt` ou similar) confirmando o sucesso.

2.  **Revisão dos Logs de Inicialização:** Verifique os logs gerados durante a inicialização do `main.py` para confirmar que não há erros críticos e que todos os componentes esperados foram carregados.

3.  **Testes Adicionais (Conforme Plano de Validação de Produção Real):**
    Consulte o documento `test_validation_summary.md` para um resumo dos testes já realizados e as recomendações para testes mais abrangentes, incluindo:
    - Testes E2E com cenários simulados.
    - Testes de alertas.
    - Testes de regressão.
    - Backtests com dados reais.
    - Monitoramento de performance.
    - Testes de carga.

## 9. Solução de Problemas Comuns

- **Erro de Importação (`ImportError`):**
    - Verifique se o ambiente virtual está ativo.
    - Confirme se todas as dependências em `requirements.txt` estão instaladas (`pip install -r requirements.txt`).
    - Assegure-se de que a estrutura de diretórios do projeto está intacta e que você está executando os scripts do diretório raiz do projeto.
    - Verifique se o `PYTHONPATH` está configurado corretamente, se aplicável (geralmente não necessário se executado da raiz com a estrutura de pacotes correta).

- **Componente Crítico Não Inicia:**
    - Verifique o arquivo `config.json` para garantir que o componente está ativo (`"component_name_active": true`).
    - Revise os logs para mensagens de erro específicas relacionadas à inicialização desse componente.
    - Certifique-se de que as dependências específicas do componente estão presentes.

- **Sistema Opera de Forma Inesperada:**
    - Revise `config.json` para configurações incorretas.
    - Analise os logs detalhados para entender o fluxo de decisão.
    - Considere executar testes mais granulares ou E2E para isolar o problema.

## 10. Contato e Suporte

Para problemas ou dúvidas, consulte a documentação do projeto ou entre em contato com a equipe de desenvolvimento.

