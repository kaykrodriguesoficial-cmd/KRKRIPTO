#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para adicionar integração Telegram direta ao main.py
=========================================================

Este script adiciona uma função de envio direto para Telegram
sem dependências externas, resolvendo problemas de encoding.

Autor: Sistema ML Supremo
Data: 2025-09-01
"""

import re
import os
from datetime import datetime

def adicionar_telegram_direto():
    """
    Adiciona integração Telegram direta ao main.py
    """
    print("🔧 ADICIONANDO INTEGRAÇÃO TELEGRAM DIRETA")
    print("=" * 50)
    
    main_file = 'main.py'
    
    # Verifica se o arquivo existe
    if not os.path.exists(main_file):
        print(f"❌ Arquivo {main_file} não encontrado!")
        return False
    
    try:
        # Faz backup
        backup_file = f"main_backup_telegram_direto_{datetime.now().strftime('%Y%m%d_%H%M%S')}.py"
        print(f"📋 Fazendo backup: {backup_file}")
        
        with open(main_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        with open(backup_file, 'w', encoding='utf-8') as f:
            f.write(content)
        
        # Verifica se já tem a função
        if 'def enviar_telegram_direto' in content:
            print("⚠️  Função enviar_telegram_direto já existe")
            return True
        
        print("✅ Adicionando função de envio direto...")
        
        # Função de envio direto (sem emojis problemáticos)
        telegram_function = '''
# ===== INTEGRAÇÃO TELEGRAM DIRETA =====
def enviar_telegram_direto(ativo, acao_final, confianca_final, preco_atual, 
                          position_size=None, stop_loss=None, take_profit=None, motivo_final=None):
    """
    Envia sinal diretamente para Telegram
    """
    try:
        import json
        import requests
        from datetime import datetime
        
        # Carrega configurações
        with open('config.json', 'r') as f:
            config = json.load(f)
        
        telegram_config = config.get('telegram', {})
        if not telegram_config.get('ativo', False):
            logger.debug("Telegram desativado na configuração")
            return False
        
        TOKEN = config.get('telegram_token')
        CHAT_ID = config.get('telegram_chat_id')
        
        if not TOKEN or not CHAT_ID:
            logger.warning("Token ou Chat ID do Telegram não configurados")
            return False
        
        # Filtro de confiança
        confianca_minima = telegram_config.get('confianca_minima', 60)
        confianca_pct = confianca_final * 100 if confianca_final < 1 else confianca_final
        
        if confianca_pct < confianca_minima:
            logger.debug(f'Sinal {ativo} não enviado: confiança {confianca_pct:.1f}% < {confianca_minima}%')
            return False
        
        # Filtro de gestão de risco
        apenas_gestao_aprovada = telegram_config.get('filtros', {}).get('apenas_gestao_aprovada', True)
        if apenas_gestao_aprovada and 'APROVADO' not in str(motivo_final):
            logger.debug(f'Sinal {ativo} não enviado: gestão de risco não aprovada')
            return False
        
        # Emoji da ação (usando códigos seguros)
        emoji_map = {
            'COMPRAR': '\\U0001F7E2',  # 🟢
            'VENDER': '\\U0001F534',   # 🔴
            'AGUARDAR': '\\U0001F7E1', # 🟡
            'MANTER': '\\U0001F7E1'    # 🟡
        }
        emoji = emoji_map.get(acao_final, '\\u26AA')  # ⚪
        
        # Monta mensagem
        timestamp = datetime.now().strftime('%H:%M:%S - %d/%m/%Y')
        
        message = f'''\\U0001F3AF SINAL ML SUPREMO

\\U0001F4B0 {ativo}
{emoji} Acao: {acao_final}
\\U0001F4CA Confianca: {confianca_pct:.1f}%
\\U0001F4B5 Preco: ${preco_atual:,.2f}'''
        
        if position_size and position_size > 0:
            message += f'''
\\U0001F4C8 Position Size: {position_size:.6f}'''
        
        if stop_loss and stop_loss > 0:
            message += f'''

\\U0001F6D1 Stop-Loss: ${stop_loss:,.2f}'''
        
        if take_profit and take_profit > 0:
            message += f'''
\\U0001F3AF Take-Profit: ${take_profit:,.2f}'''
        
        if motivo_final:
            message += f'''

\\U0001F6E1 Gestao de Risco: {motivo_final}'''
        
        message += f'''
\\u23F0 {timestamp}'''
        
        # Envia mensagem
        url = f'https://api.telegram.org/bot{TOKEN}/sendMessage'
        data = {'chat_id': CHAT_ID, 'text': message}
        response = requests.post(url, data=data, timeout=10)
        
        if response.status_code == 200:
            logger.info(f'Sinal {ativo} enviado para Telegram: {acao_final}')
            return True
        else:
            logger.warning(f'Falha ao enviar sinal {ativo}: {response.text}')
            return False
            
    except Exception as e:
        logger.error(f'Erro ao enviar sinal para Telegram: {e}')
        return False

'''
        
        # Encontra onde adicionar a função
        import_pos = content.find('def obter_credencial')
        if import_pos == -1:
            import_pos = content.find('# ===== CONFIGURAÇÃO DE LOGGING =====')
        
        if import_pos != -1:
            content = content[:import_pos] + telegram_function + '\n' + content[import_pos:]
            print("✅ Função enviar_telegram_direto adicionada")
        else:
            print("⚠️  Não foi possível encontrar local para inserir a função")
            return False
        
        # Adiciona chamada da função onde os sinais são gerados
        print("✅ Adicionando chamada da função...")
        
        # Padrão mais específico para encontrar onde adicionar
        patterns = [
            r'(logger\.critical\(f"   ✅ Operação registrada na gestão de risco"\))',
            r'(logger\.critical\(f"   \u2705 Opera\u00e7\u00e3o registrada na gest\u00e3o de risco"\))',
            r'(logger\.info\(f"   ✅ Operação registrada na gestão de risco"\))'
        ]
        
        replacement = r'''\1
                        
                        # Enviar sinal para Telegram
                        try:
                            enviar_telegram_direto(
                                ativo, 
                                acao_final, 
                                confianca_final, 
                                preco_atual,
                                position_size if 'position_size' in locals() else None,
                                stop_loss if 'stop_loss' in locals() else None,
                                take_profit if 'take_profit' in locals() else None,
                                motivo_final
                            )
                        except Exception as e:
                            logger.error(f"Erro ao enviar sinal Telegram: {e}")'''
        
        found_pattern = False
        for pattern in patterns:
            if re.search(pattern, content):
                content = re.sub(pattern, replacement, content)
                found_pattern = True
                print(f"✅ Chamada adicionada usando padrão: {pattern}")
                break
        
        if not found_pattern:
            print("⚠️  Não foi possível encontrar local para adicionar chamada")
            print("📝 Adicionando chamada manual...")
            
            # Adiciona chamada manual após position_size
            manual_pattern = r'(position_size = gestao_risco\.calcular_position_size\(ativo, preco_atual, stop_loss\))'
            manual_replacement = r'''\1
                            
                            # Enviar sinal para Telegram
                            try:
                                enviar_telegram_direto(
                                    ativo, 
                                    acao_final, 
                                    confianca_final, 
                                    preco_atual,
                                    position_size,
                                    stop_loss,
                                    take_profit,
                                    motivo_final
                                )
                            except Exception as e:
                                logger.error(f"Erro ao enviar sinal Telegram: {e}")'''
            
            if re.search(manual_pattern, content):
                content = re.sub(manual_pattern, manual_replacement, content)
                print("✅ Chamada manual adicionada")
            else:
                print("⚠️  Chamada manual também não foi possível")
        
        # Salva arquivo atualizado
        print("💾 Salvando main.py atualizado...")
        with open(main_file, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print("✅ Integração Telegram direta adicionada com sucesso!")
        print(f"📁 Backup salvo em: {backup_file}")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro ao adicionar integração: {e}")
        return False

def verificar_integracao():
    """
    Verifica se a integração foi adicionada corretamente
    """
    print("\n🔍 VERIFICANDO INTEGRAÇÃO...")
    print("-" * 30)
    
    try:
        with open('main.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        checks = [
            ('Função enviar_telegram_direto', 'def enviar_telegram_direto' in content),
            ('Importação requests', 'import requests' in content),
            ('Chamada da função', 'enviar_telegram_direto(' in content),
            ('Configuração Telegram', 'telegram_config.get' in content),
        ]
        
        all_ok = True
        for check_name, check_result in checks:
            if check_result:
                print(f"✅ {check_name}")
            else:
                print(f"❌ {check_name}")
                all_ok = False
        
        if all_ok:
            print("\n🎉 INTEGRAÇÃO ADICIONADA CORRETAMENTE!")
            return True
        else:
            print("\n⚠️  Integração incompleta")
            return False
            
    except Exception as e:
        print(f"❌ Erro na verificação: {e}")
        return False

def testar_sintaxe():
    """
    Testa se o arquivo tem sintaxe válida
    """
    print("\n🔍 TESTANDO SINTAXE...")
    print("-" * 20)
    
    try:
        import py_compile
        py_compile.compile('main.py', doraise=True)
        print("✅ Sintaxe válida!")
        return True
    except py_compile.PyCompileError as e:
        print(f"❌ Erro de sintaxe: {e}")
        return False
    except Exception as e:
        print(f"❌ Erro ao testar sintaxe: {e}")
        return False

def main():
    """
    Função principal
    """
    print("🎯 INTEGRAÇÃO TELEGRAM DIRETA")
    print("=" * 40)
    
    if adicionar_telegram_direto():
        if verificar_integracao():
            if testar_sintaxe():
                print("\n🚀 PRÓXIMOS PASSOS:")
                print("1. Reinicie o sistema: python3 main.py --modo trading --debug")
                print("2. Aguarde os sinais no Telegram!")
                print("\n📱 O sistema agora enviará:")
                print("   • Sinais de trading automaticamente")
                print("   • Filtros de confiança aplicados")
                print("   • Mensagens formatadas")
            else:
                print("\n⚠️  Verifique erros de sintaxe")
        else:
            print("\n⚠️  Verifique a integração manualmente")
    else:
        print("\n❌ Falha na integração")

if __name__ == "__main__":
    main()

