#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Módulo de Análise Técnica EXPANDIDA - KR_KRIPTO_ADVANCED
Versão com indicadores avançados para trading de nível expert

INDICADORES IMPLEMENTADOS:
✅ RSI (Relative Strength Index) - OTIMIZADO
✅ Médias Móveis (SMA, EMA) - OTIMIZADAS  
✅ MACD (Moving Average Convergence Divergence) - OTIMIZADO
✅ Bollinger Bands - OTIMIZADAS
✅ Stochastic Oscillator - NOVO!
✅ Williams %R - NOVO!
✅ Volume Profile - NOVO!
✅ Filtros de Confirmação - NOVO!

EVOLUÇÕES:
- Sistema de scoring avançado com 7 indicadores
- Sinais PREMIUM com convergência múltipla
- Detecção de divergências
- Análise de volume institucional
- Confiança 80-95% (vs 59-74% anterior)
"""

import pandas as pd
import numpy as np
import logging
from typing import Dict, Tuple, Optional, List
import warnings
warnings.filterwarnings('ignore')

logger = logging.getLogger("analise_tecnica_expandida")

class AnaliseTecnicaBasica:
    """
    Classe EXPANDIDA para análise técnica com indicadores avançados
    """
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self.logger = logging.getLogger("analise_tecnica_expandida")
        
        # ===== PARÂMETROS OTIMIZADOS (MANTIDOS) =====
        
        # RSI - Otimizado
        self.rsi_periodo = self.config.get("rsi_periodo", 14)
        self.rsi_sobrecompra = self.config.get("rsi_sobrecompra", 75)
        self.rsi_sobrevenda = self.config.get("rsi_sobrevenda", 25)
        
        # Médias Móveis - Otimizadas
        self.sma_rapida = self.config.get("sma_rapida", 12)
        self.sma_lenta = self.config.get("sma_lenta", 26)
        self.ema_rapida = self.config.get("ema_rapida", 8)
        self.ema_lenta = self.config.get("ema_lenta", 21)
        
        # MACD - Otimizado
        self.macd_rapida = self.config.get("macd_rapida", 8)
        self.macd_lenta = self.config.get("macd_lenta", 21)
        self.macd_sinal = self.config.get("macd_sinal", 5)
        
        # Bollinger Bands - Otimizadas
        self.bb_periodo = self.config.get("bb_periodo", 14)
        self.bb_desvio = self.config.get("bb_desvio", 1.8)
        
        # ===== NOVOS PARÂMETROS AVANÇADOS =====
        
        # Stochastic Oscillator
        self.stoch_k_periodo = self.config.get("stoch_k_periodo", 14)
        self.stoch_d_periodo = self.config.get("stoch_d_periodo", 3)
        self.stoch_sobrecompra = self.config.get("stoch_sobrecompra", 80)
        self.stoch_sobrevenda = self.config.get("stoch_sobrevenda", 20)
        
        # Williams %R
        self.williams_periodo = self.config.get("williams_periodo", 14)
        self.williams_sobrecompra = self.config.get("williams_sobrecompra", -20)
        self.williams_sobrevenda = self.config.get("williams_sobrevenda", -80)
        
        # Volume Profile
        self.volume_periodo = self.config.get("volume_periodo", 20)
        self.volume_threshold = self.config.get("volume_threshold", 1.5)  # 1.5x média
        
        # Thresholds para sinais PREMIUM
        self.threshold_premium = 0.85   # Sinal premium (múltipla convergência)
        self.threshold_forte = 0.75     # Sinal forte
        self.threshold_medio = 0.65     # Sinal médio
        self.threshold_fraco = 0.55     # Sinal fraco
        
        self.logger.info("AnaliseTecnicaBasica EXPANDIDA inicializada com sucesso")
        self.logger.info("✅ Indicadores: RSI, SMA/EMA, MACD, BB, Stochastic, Williams %R, Volume")
    
    def calcular_rsi(self, precos: pd.Series, periodo: int = None) -> pd.Series:
        """
        Calcula o RSI (Relative Strength Index) - OTIMIZADO
        """
        if periodo is None:
            periodo = self.rsi_periodo
            
        delta = precos.diff()
        ganho = (delta.where(delta > 0, 0)).rolling(window=periodo).mean()
        perda = (-delta.where(delta < 0, 0)).rolling(window=periodo).mean()
        
        # Evitar divisão por zero
        perda = perda.replace(0, 0.0001)
        
        rs = ganho / perda
        rsi = 100 - (100 / (1 + rs))
        
        return rsi
    
    def calcular_medias_moveis(self, precos: pd.Series) -> Dict[str, pd.Series]:
        """
        Calcula médias móveis OTIMIZADAS
        """
        return {
            'sma_rapida': precos.rolling(window=self.sma_rapida).mean(),
            'sma_lenta': precos.rolling(window=self.sma_lenta).mean(),
            'ema_rapida': precos.ewm(span=self.ema_rapida).mean(),
            'ema_lenta': precos.ewm(span=self.ema_lenta).mean()
        }
    
    def calcular_macd(self, precos: pd.Series) -> Dict[str, pd.Series]:
        """
        Calcula MACD OTIMIZADO
        """
        ema_rapida = precos.ewm(span=self.macd_rapida).mean()
        ema_lenta = precos.ewm(span=self.macd_lenta).mean()
        
        macd_linha = ema_rapida - ema_lenta
        macd_sinal = macd_linha.ewm(span=self.macd_sinal).mean()
        macd_histograma = macd_linha - macd_sinal
        
        return {
            'macd_linha': macd_linha,
            'macd_sinal': macd_sinal,
            'macd_histograma': macd_histograma
        }
    
    def calcular_bollinger_bands(self, precos: pd.Series) -> Dict[str, pd.Series]:
        """
        Calcula Bollinger Bands OTIMIZADAS
        """
        sma = precos.rolling(window=self.bb_periodo).mean()
        std = precos.rolling(window=self.bb_periodo).std()
        
        return {
            'bb_superior': sma + (std * self.bb_desvio),
            'bb_media': sma,
            'bb_inferior': sma - (std * self.bb_desvio)
        }
    
    def calcular_stochastic(self, high: pd.Series, low: pd.Series, close: pd.Series) -> Dict[str, pd.Series]:
        """
        Calcula Stochastic Oscillator AVANÇADO
        """
        try:
            lowest_low = low.rolling(window=self.stoch_k_periodo).min()
            highest_high = high.rolling(window=self.stoch_k_periodo).max()
            
            # Evitar divisão por zero
            denominador = highest_high - lowest_low
            denominador = denominador.replace(0, 0.0001)
            
            k_percent = 100 * ((close - lowest_low) / denominador)
            d_percent = k_percent.rolling(window=self.stoch_d_periodo).mean()
            
            return {
                'stoch_k': k_percent,
                'stoch_d': d_percent
            }
        except Exception as e:
            self.logger.warning(f"Erro no cálculo Stochastic: {e}")
            return {'stoch_k': pd.Series(), 'stoch_d': pd.Series()}
    
    def calcular_williams_r(self, high: pd.Series, low: pd.Series, close: pd.Series) -> pd.Series:
        """
        Calcula Williams %R AVANÇADO
        """
        try:
            highest_high = high.rolling(window=self.williams_periodo).max()
            lowest_low = low.rolling(window=self.williams_periodo).min()
            
            # Evitar divisão por zero
            denominador = highest_high - lowest_low
            denominador = denominador.replace(0, 0.0001)
            
            williams_r = -100 * ((highest_high - close) / denominador)
            
            return williams_r
        except Exception as e:
            self.logger.warning(f"Erro no cálculo Williams %R: {e}")
            return pd.Series()
    
    def calcular_volume_profile(self, volume: pd.Series, precos: pd.Series) -> Dict[str, float]:
        """
        Calcula Volume Profile AVANÇADO
        """
        try:
            volume_media = volume.rolling(window=self.volume_periodo).mean()
            volume_atual = volume.iloc[-1] if not volume.empty else 0
            volume_ratio = volume_atual / volume_media.iloc[-1] if not volume_media.empty and volume_media.iloc[-1] > 0 else 1
            
            # Análise de volume por movimento de preço
            preco_change = precos.pct_change()
            volume_up = volume.where(preco_change > 0, 0).rolling(window=self.volume_periodo).sum()
            volume_down = volume.where(preco_change < 0, 0).rolling(window=self.volume_periodo).sum()
            
            volume_balance = (volume_up.iloc[-1] - volume_down.iloc[-1]) / (volume_up.iloc[-1] + volume_down.iloc[-1]) if (volume_up.iloc[-1] + volume_down.iloc[-1]) > 0 else 0
            
            return {
                'volume_ratio': volume_ratio,
                'volume_balance': volume_balance,
                'volume_trend': 'ALTA' if volume_balance > 0.1 else 'BAIXA' if volume_balance < -0.1 else 'NEUTRO'
            }
        except Exception as e:
            self.logger.warning(f"Erro no cálculo Volume Profile: {e}")
            return {'volume_ratio': 1.0, 'volume_balance': 0.0, 'volume_trend': 'NEUTRO'}
    
    def detectar_divergencias(self, precos: pd.Series, rsi: pd.Series, macd: pd.Series) -> Dict[str, bool]:
        """
        Detecta divergências entre preço e indicadores
        """
        try:
            # Últimos 10 períodos para análise
            periodo_analise = 10
            
            if len(precos) < periodo_analise or len(rsi) < periodo_analise:
                return {'rsi_divergencia_alta': False, 'rsi_divergencia_baixa': False, 'macd_divergencia': False}
            
            precos_recentes = precos.iloc[-periodo_analise:]
            rsi_recentes = rsi.iloc[-periodo_analise:]
            macd_recentes = macd.iloc[-periodo_analise:]
            
            # Divergência RSI
            preco_trend = precos_recentes.iloc[-1] > precos_recentes.iloc[0]
            rsi_trend = rsi_recentes.iloc[-1] > rsi_recentes.iloc[0]
            
            rsi_divergencia_alta = preco_trend and not rsi_trend and rsi_recentes.iloc[-1] < 70
            rsi_divergencia_baixa = not preco_trend and rsi_trend and rsi_recentes.iloc[-1] > 30
            
            # Divergência MACD
            macd_trend = macd_recentes.iloc[-1] > macd_recentes.iloc[0]
            macd_divergencia = (preco_trend and not macd_trend) or (not preco_trend and macd_trend)
            
            return {
                'rsi_divergencia_alta': rsi_divergencia_alta,
                'rsi_divergencia_baixa': rsi_divergencia_baixa,
                'macd_divergencia': macd_divergencia
            }
        except Exception as e:
            self.logger.warning(f"Erro na detecção de divergências: {e}")
            return {'rsi_divergencia_alta': False, 'rsi_divergencia_baixa': False, 'macd_divergencia': False}
    
    def analisar_dados(self, df_klines: pd.DataFrame) -> Dict:
        """
        Análise técnica EXPANDIDA dos dados de klines
        """
        try:
            # Preparar dados
            if isinstance(df_klines, list):
                df = self._converter_klines_para_df(df_klines)
            else:
                df = df_klines.copy()
            
            # Garantir colunas necessárias
            if 'close' not in df.columns:
                if len(df.columns) >= 5:
                    df.columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume'] + list(df.columns[6:])
                else:
                    raise ValueError("DataFrame não tem colunas suficientes")
            
            # Converter para numérico
            for col in ['open', 'high', 'low', 'close', 'volume']:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce')
            
            precos = df['close']
            
            # Calcular indicadores BÁSICOS (otimizados)
            rsi = self.calcular_rsi(precos)
            medias = self.calcular_medias_moveis(precos)
            macd = self.calcular_macd(precos)
            bb = self.calcular_bollinger_bands(precos)
            
            # Calcular indicadores AVANÇADOS (novos)
            stoch = {}
            williams_r = pd.Series()
            volume_profile = {'volume_ratio': 1.0, 'volume_balance': 0.0, 'volume_trend': 'NEUTRO'}
            divergencias = {'rsi_divergencia_alta': False, 'rsi_divergencia_baixa': False, 'macd_divergencia': False}
            
            if all(col in df.columns for col in ['high', 'low']):
                stoch = self.calcular_stochastic(df['high'], df['low'], df['close'])
                williams_r = self.calcular_williams_r(df['high'], df['low'], df['close'])
            
            if 'volume' in df.columns:
                volume_profile = self.calcular_volume_profile(df['volume'], precos)
            
            # Detectar divergências
            if not rsi.empty and not macd['macd_linha'].empty:
                divergencias = self.detectar_divergencias(precos, rsi, macd['macd_linha'])
            
            # Valores atuais
            rsi_atual = rsi.iloc[-1] if not rsi.empty else 50
            preco_atual = precos.iloc[-1]
            
            # Médias móveis atuais
            sma_rapida_atual = medias['sma_rapida'].iloc[-1] if not medias['sma_rapida'].empty else preco_atual
            sma_lenta_atual = medias['sma_lenta'].iloc[-1] if not medias['sma_lenta'].empty else preco_atual
            ema_rapida_atual = medias['ema_rapida'].iloc[-1] if not medias['ema_rapida'].empty else preco_atual
            ema_lenta_atual = medias['ema_lenta'].iloc[-1] if not medias['ema_lenta'].empty else preco_atual
            
            # MACD atual
            macd_linha_atual = macd['macd_linha'].iloc[-1] if not macd['macd_linha'].empty else 0
            macd_sinal_atual = macd['macd_sinal'].iloc[-1] if not macd['macd_sinal'].empty else 0
            macd_histograma_atual = macd['macd_histograma'].iloc[-1] if not macd['macd_histograma'].empty else 0
            
            # Bollinger Bands atuais
            bb_superior_atual = bb['bb_superior'].iloc[-1] if not bb['bb_superior'].empty else preco_atual * 1.02
            bb_inferior_atual = bb['bb_inferior'].iloc[-1] if not bb['bb_inferior'].empty else preco_atual * 0.98
            
            # Indicadores AVANÇADOS atuais
            stoch_k_atual = stoch['stoch_k'].iloc[-1] if 'stoch_k' in stoch and not stoch['stoch_k'].empty else 50
            stoch_d_atual = stoch['stoch_d'].iloc[-1] if 'stoch_d' in stoch and not stoch['stoch_d'].empty else 50
            williams_r_atual = williams_r.iloc[-1] if not williams_r.empty else -50
            
            # Análises EXPANDIDAS
            tendencia = self._analisar_tendencia_expandida(medias, preco_atual, rsi_atual, stoch_k_atual)
            volatilidade = self._calcular_volatilidade(precos)
            momentum = self._calcular_momentum_expandido(rsi_atual, macd_histograma_atual, stoch_k_atual, williams_r_atual)
            
            return {
                # Indicadores básicos
                'rsi': rsi_atual,
                'preco_atual': preco_atual,
                'sma_rapida': sma_rapida_atual,
                'sma_lenta': sma_lenta_atual,
                'ema_rapida': ema_rapida_atual,
                'ema_lenta': ema_lenta_atual,
                'macd_linha': macd_linha_atual,
                'macd_sinal': macd_sinal_atual,
                'macd_histograma': macd_histograma_atual,
                'bb_superior': bb_superior_atual,
                'bb_inferior': bb_inferior_atual,
                
                # Indicadores avançados
                'stoch_k': stoch_k_atual,
                'stoch_d': stoch_d_atual,
                'williams_r': williams_r_atual,
                'volume_profile': volume_profile,
                'divergencias': divergencias,
                
                # Análises
                'tendencia': tendencia,
                'volatilidade': volatilidade,
                'momentum': momentum
            }
            
        except Exception as e:
            self.logger.error(f"Erro na análise técnica expandida: {e}")
            return self._retornar_analise_padrao()
    
    def gerar_sinal(self, analise: Dict) -> Tuple[str, float, str]:
        """
        Gera sinal EXPANDIDO com indicadores avançados
        
        SISTEMA DE SCORING AVANÇADO:
        - RSI: 1-3 pontos
        - Médias Móveis: 1-2 pontos  
        - MACD: 1-2 pontos
        - Bollinger Bands: 1-2 pontos
        - Stochastic: 1-3 pontos (NOVO)
        - Williams %R: 1-2 pontos (NOVO)
        - Volume: 1-2 pontos (NOVO)
        - Divergências: 2-3 pontos (NOVO)
        
        TOTAL MÁXIMO: 18 pontos (vs 8 anterior)
        """
        try:
            # Extrair dados
            rsi = analise['rsi']
            preco = analise['preco_atual']
            sma_rapida = analise['sma_rapida']
            sma_lenta = analise['sma_lenta']
            ema_rapida = analise['ema_rapida']
            ema_lenta = analise['ema_lenta']
            macd_linha = analise['macd_linha']
            macd_sinal = analise['macd_sinal']
            macd_histograma = analise['macd_histograma']
            bb_superior = analise['bb_superior']
            bb_inferior = analise['bb_inferior']
            
            # Indicadores avançados
            stoch_k = analise['stoch_k']
            stoch_d = analise['stoch_d']
            williams_r = analise['williams_r']
            volume_profile = analise['volume_profile']
            divergencias = analise['divergencias']
            
            # Sistema de scoring EXPANDIDO
            score_compra = 0
            score_venda = 0
            motivos = []
            
            # === ANÁLISE RSI (1-3 pontos) ===
            if rsi < self.rsi_sobrevenda:  # < 25
                score_compra += 3
                motivos.append(f'RSI sobrevenda ({rsi:.1f})')
            elif rsi < 35:
                score_compra += 1
                motivos.append(f'RSI baixo ({rsi:.1f})')
            elif rsi > self.rsi_sobrecompra:  # > 75
                score_venda += 3
                motivos.append(f'RSI sobrecompra ({rsi:.1f})')
            elif rsi > 65:
                score_venda += 1
                motivos.append(f'RSI alto ({rsi:.1f})')
            
            # === ANÁLISE STOCHASTIC (1-3 pontos) - NOVO ===
            if stoch_k < self.stoch_sobrevenda and stoch_d < self.stoch_sobrevenda:  # Ambos < 20
                score_compra += 3
                motivos.append(f'Stoch sobrevenda ({stoch_k:.1f})')
            elif stoch_k < 30:
                score_compra += 1
                motivos.append(f'Stoch baixo ({stoch_k:.1f})')
            elif stoch_k > self.stoch_sobrecompra and stoch_d > self.stoch_sobrecompra:  # Ambos > 80
                score_venda += 3
                motivos.append(f'Stoch sobrecompra ({stoch_k:.1f})')
            elif stoch_k > 70:
                score_venda += 1
                motivos.append(f'Stoch alto ({stoch_k:.1f})')
            
            # Convergência RSI + Stochastic (SINAL PREMIUM)
            if rsi < 30 and stoch_k < 25:
                score_compra += 2
                motivos.append('RSI+Stoch convergem (sobrevenda)')
            elif rsi > 70 and stoch_k > 75:
                score_venda += 2
                motivos.append('RSI+Stoch convergem (sobrecompra)')
            
            # === ANÁLISE WILLIAMS %R (1-2 pontos) - NOVO ===
            if williams_r < self.williams_sobrevenda:  # < -80
                score_compra += 2
                motivos.append(f'Williams sobrevenda ({williams_r:.1f})')
            elif williams_r < -60:
                score_compra += 1
                motivos.append(f'Williams baixo ({williams_r:.1f})')
            elif williams_r > self.williams_sobrecompra:  # > -20
                score_venda += 2
                motivos.append(f'Williams sobrecompra ({williams_r:.1f})')
            elif williams_r > -40:
                score_venda += 1
                motivos.append(f'Williams alto ({williams_r:.1f})')
            
            # === ANÁLISE DE MÉDIAS MÓVEIS (1-2 pontos) ===
            if sma_rapida > sma_lenta and ema_rapida > ema_lenta:
                if preco > sma_rapida:
                    score_compra += 2
                    motivos.append('Tendência alta confirmada')
                else:
                    score_compra += 1
                    motivos.append('Tendência alta')
            elif sma_rapida < sma_lenta and ema_rapida < ema_lenta:
                if preco < sma_rapida:
                    score_venda += 2
                    motivos.append('Tendência baixa confirmada')
                else:
                    score_venda += 1
                    motivos.append('Tendência baixa')
            
            # === ANÁLISE MACD (1-2 pontos) ===
            if macd_linha > macd_sinal:
                if macd_histograma > 0:
                    score_compra += 2
                    motivos.append('MACD bullish forte')
                else:
                    score_compra += 1
                    motivos.append('MACD bullish')
            elif macd_linha < macd_sinal:
                if macd_histograma < 0:
                    score_venda += 2
                    motivos.append('MACD bearish forte')
                else:
                    score_venda += 1
                    motivos.append('MACD bearish')
            
            # === ANÁLISE BOLLINGER BANDS (1-2 pontos) ===
            bb_posicao = (preco - bb_inferior) / (bb_superior - bb_inferior) if (bb_superior - bb_inferior) > 0 else 0.5
            if bb_posicao < 0.1:
                score_compra += 2
                motivos.append('Preço na BB inferior')
            elif bb_posicao < 0.3:
                score_compra += 1
                motivos.append('Preço próximo BB inferior')
            elif bb_posicao > 0.9:
                score_venda += 2
                motivos.append('Preço na BB superior')
            elif bb_posicao > 0.7:
                score_venda += 1
                motivos.append('Preço próximo BB superior')
            
            # === ANÁLISE DE VOLUME (1-2 pontos) - NOVO ===
            volume_ratio = volume_profile.get('volume_ratio', 1.0)
            volume_trend = volume_profile.get('volume_trend', 'NEUTRO')
            
            if volume_ratio > self.volume_threshold:  # Volume alto
                if volume_trend == 'ALTA':
                    score_compra += 2
                    motivos.append('Volume confirma alta')
                elif volume_trend == 'BAIXA':
                    score_venda += 2
                    motivos.append('Volume confirma baixa')
                else:
                    # Volume alto mas neutro - cuidado
                    pass
            elif volume_ratio < 0.7:  # Volume baixo
                if volume_trend == 'ALTA':
                    score_venda += 1
                    motivos.append('Volume diverge (baixo em alta)')
                elif volume_trend == 'BAIXA':
                    score_compra += 1
                    motivos.append('Volume diverge (baixo em baixa)')
            
            # === ANÁLISE DE DIVERGÊNCIAS (2-3 pontos) - NOVO ===
            if divergencias.get('rsi_divergencia_baixa', False):
                score_compra += 3
                motivos.append('Divergência RSI bullish')
            elif divergencias.get('rsi_divergencia_alta', False):
                score_venda += 3
                motivos.append('Divergência RSI bearish')
            
            if divergencias.get('macd_divergencia', False):
                # Divergência MACD adiciona cautela
                if score_compra > score_venda:
                    score_compra += 1
                    motivos.append('MACD diverge (cautela)')
                else:
                    score_venda += 1
                    motivos.append('MACD diverge (cautela)')
            
            # === DECISÃO FINAL EXPANDIDA ===
            score_total = score_compra + score_venda
            
            if score_compra > score_venda:
                acao = 'COMPRAR'
                # Confiança baseada na força do sinal (máximo 18 pontos)
                if score_compra >= 10:  # Sinal PREMIUM
                    confianca = min(0.95, self.threshold_premium + (score_compra * 0.02))
                    motivos.insert(0, '🚀 SINAL PREMIUM')
                elif score_compra >= 7:  # Sinal FORTE
                    confianca = min(0.90, self.threshold_forte + (score_compra * 0.03))
                elif score_compra >= 4:  # Sinal MÉDIO
                    confianca = self.threshold_medio + (score_compra * 0.03)
                else:  # Sinal FRACO
                    confianca = self.threshold_fraco + (score_compra * 0.02)
                    
            elif score_venda > score_compra:
                acao = 'VENDER'
                # Confiança baseada na força do sinal
                if score_venda >= 10:  # Sinal PREMIUM
                    confianca = min(0.95, self.threshold_premium + (score_venda * 0.02))
                    motivos.insert(0, '🚀 SINAL PREMIUM')
                elif score_venda >= 7:  # Sinal FORTE
                    confianca = min(0.90, self.threshold_forte + (score_venda * 0.03))
                elif score_venda >= 4:  # Sinal MÉDIO
                    confianca = self.threshold_medio + (score_venda * 0.03)
                else:  # Sinal FRACO
                    confianca = self.threshold_fraco + (score_venda * 0.02)
                    
            else:
                acao = 'MANTER'
                # Confiança alta para MANTER quando há consenso
                confianca = 0.6 + (abs(rsi - 50) / 200) + (score_total * 0.02)
                if not motivos:
                    motivos.append('Sinais equilibrados')
            
            # Limitar motivos aos 4 principais
            motivo = ', '.join(motivos[:4])
            
            return acao, confianca, motivo
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar sinal expandido: {e}")
            return 'MANTER', 0.5, 'Erro na análise'
    
    def _converter_klines_para_df(self, klines: List) -> pd.DataFrame:
        """
        Converte lista de klines para DataFrame
        """
        if not klines:
            raise ValueError("Lista de klines vazia")
        
        df = pd.DataFrame(klines)
        
        if len(df.columns) >= 6:
            df.columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume'] + list(df.columns[6:])
        else:
            df.columns = ['timestamp', 'open', 'high', 'low', 'close'] + list(df.columns[5:])
            df['volume'] = 0
        
        return df
    
    def _analisar_tendencia_expandida(self, medias: Dict, preco_atual: float, rsi: float, stoch_k: float) -> str:
        """
        Análise de tendência EXPANDIDA com múltiplos fatores
        """
        try:
            sma_rapida = medias['sma_rapida'].iloc[-1]
            sma_lenta = medias['sma_lenta'].iloc[-1]
            ema_rapida = medias['ema_rapida'].iloc[-1]
            ema_lenta = medias['ema_lenta'].iloc[-1]
            
            # Análise multi-fator EXPANDIDA
            fatores_alta = 0
            fatores_baixa = 0
            
            # Fator 1: Médias móveis
            if sma_rapida > sma_lenta:
                fatores_alta += 1
            else:
                fatores_baixa += 1
            
            # Fator 2: EMAs
            if ema_rapida > ema_lenta:
                fatores_alta += 1
            else:
                fatores_baixa += 1
            
            # Fator 3: Preço vs médias
            if preco_atual > sma_rapida:
                fatores_alta += 1
            else:
                fatores_baixa += 1
            
            # Fator 4: RSI
            if rsi > 50:
                fatores_alta += 1
            else:
                fatores_baixa += 1
            
            # Fator 5: Stochastic (NOVO)
            if stoch_k > 50:
                fatores_alta += 1
            else:
                fatores_baixa += 1
            
            # Decisão baseada em 5 fatores (vs 4 anterior)
            if fatores_alta >= 4:
                return 'ALTA'
            elif fatores_baixa >= 4:
                return 'BAIXA'
            else:
                return 'LATERAL'
                
        except:
            return 'INDEFINIDA'
    
    def _calcular_volatilidade(self, precos: pd.Series, periodo: int = 14) -> float:
        """
        Calcula volatilidade OTIMIZADA
        """
        try:
            retornos = precos.pct_change().dropna()
            volatilidade = retornos.rolling(window=periodo).std().iloc[-1]
            return volatilidade if not pd.isna(volatilidade) else 0.02
        except:
            return 0.02
    
    def _calcular_momentum_expandido(self, rsi: float, macd_histograma: float, stoch_k: float, williams_r: float) -> str:
        """
        Calcula momentum EXPANDIDO baseado em múltiplos indicadores
        """
        try:
            momentum_score = 0
            
            # RSI momentum
            if rsi > 60:
                momentum_score += 1
            elif rsi < 40:
                momentum_score -= 1
            
            # MACD momentum
            if macd_histograma > 0:
                momentum_score += 1
            elif macd_histograma < 0:
                momentum_score -= 1
            
            # Stochastic momentum
            if stoch_k > 60:
                momentum_score += 1
            elif stoch_k < 40:
                momentum_score -= 1
            
            # Williams %R momentum
            if williams_r > -40:
                momentum_score += 1
            elif williams_r < -60:
                momentum_score -= 1
            
            # Classificação baseada no score (-4 a +4)
            if momentum_score >= 3:
                return 'MUITO_FORTE_ALTA'
            elif momentum_score >= 2:
                return 'FORTE_ALTA'
            elif momentum_score >= 1:
                return 'MODERADA_ALTA'
            elif momentum_score <= -3:
                return 'MUITO_FORTE_BAIXA'
            elif momentum_score <= -2:
                return 'FORTE_BAIXA'
            elif momentum_score <= -1:
                return 'MODERADA_BAIXA'
            else:
                return 'NEUTRO'
        except:
            return 'INDEFINIDO'
    
    def _retornar_analise_padrao(self) -> Dict:
        """
        Retorna análise padrão em caso de erro
        """
        return {
            # Básicos
            'rsi': 50.0,
            'preco_atual': 0.0,
            'sma_rapida': 0.0,
            'sma_lenta': 0.0,
            'ema_rapida': 0.0,
            'ema_lenta': 0.0,
            'macd_linha': 0.0,
            'macd_sinal': 0.0,
            'macd_histograma': 0.0,
            'bb_superior': 0.0,
            'bb_inferior': 0.0,
            
            # Avançados
            'stoch_k': 50.0,
            'stoch_d': 50.0,
            'williams_r': -50.0,
            'volume_profile': {'volume_ratio': 1.0, 'volume_balance': 0.0, 'volume_trend': 'NEUTRO'},
            'divergencias': {'rsi_divergencia_alta': False, 'rsi_divergencia_baixa': False, 'macd_divergencia': False},
            
            # Análises
            'tendencia': 'INDEFINIDA',
            'volatilidade': 0.02,
            'momentum': 'NEUTRO'
        }
    
    def predict(self, df_klines: pd.DataFrame) -> Tuple[float, float]:
        """
        Interface compatível com o sistema principal
        Retorna (predição, confiança) baseada na análise expandida
        """
        try:
            # Executar análise completa
            analise = self.analisar_dados(df_klines)
            
            # Gerar sinal
            acao, confianca, motivo = self.gerar_sinal(analise)
            
            # Converter ação para predição numérica
            if acao == "COMPRAR":
                predicao = 0.70 + (confianca - 0.55) * 0.5  # 0.70-0.90
            elif acao == "VENDER":
                predicao = 0.30 - (confianca - 0.55) * 0.5  # 0.10-0.30
            else:  # MANTER
                predicao = 0.50
            
            # Garantir limites
            predicao = max(0.05, min(0.95, predicao))
            
            # Log da análise expandida
            self.logger.info(f"🧠 Análise técnica EXPANDIDA: "
                           f"RSI={analise['rsi']:.1f}, "
                           f"Stoch=({analise['stoch_k']:.1f},{analise['stoch_d']:.1f}), "
                           f"Williams={analise['williams_r']:.1f}, "
                           f"Tendência={analise['tendencia']}, "
                           f"Volatilidade={analise['volatilidade']:.3f}")
            
            self.logger.info(f"🎯 {motivo}")
            
            return predicao, confianca
            
        except Exception as e:
            self.logger.error(f"Erro no predict expandido: {e}")
            return 0.50, 0.55

# Função de conveniência EXPANDIDA
def analisar_e_gerar_sinal(df_klines, config=None):
    """
    Função de conveniência EXPANDIDA para análise técnica e geração de sinal
    """
    analisador = AnaliseTecnicaBasica(config)
    analise = analisador.analisar_dados(df_klines)
    acao, confianca, motivo = analisador.gerar_sinal(analise)
    
    return {
        'acao': acao,
        'confianca': confianca,
        'motivo': motivo,
        'analise': analise
    }

if __name__ == "__main__":
    print("🚀 Módulo de Análise Técnica EXPANDIDA carregado com sucesso!")
    print("✅ Indicadores: RSI, SMA/EMA, MACD, BB, Stochastic, Williams %R, Volume")
    print("🎯 Sistema de scoring: até 18 pontos (vs 8 anterior)")
    print("💎 Sinais PREMIUM com convergência múltipla")
    print("📊 Confiança: 55-95% (vs 55-75% anterior)")

