#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Módulo de Análise Técnica OTIMIZADA - KR_KRIPTO_ADVANCED
Versão otimizada com parâmetros calibrados para maior sensibilidade e precisão

OTIMIZAÇÕES IMPLEMENTADAS:
- RSI: 30/70 → 25/75 (mais sinais, menos ruído)
- SMA: 20/50 → 12/26 (mais responsivo)
- MACD: 12,26,9 → 8,21,5 (sinais mais rápidos)
- Bollinger: 20,2 → 14,1.8 (melhor detecção)
- Logs otimizados (sem duplicatas)
- Lógica de sinais aprimorada
"""

import pandas as pd
import numpy as np
import logging
from typing import Dict, Tuple, Optional, List
import warnings
warnings.filterwarnings('ignore')

logger = logging.getLogger("analise_tecnica_otimizada")

class AnaliseTecnicaBasica:
    """
    Classe OTIMIZADA para análise técnica com parâmetros calibrados
    """
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self.logger = logging.getLogger("analise_tecnica_otimizada")
        
        # ===== PARÂMETROS OTIMIZADOS =====
        
        # RSI - Mais sensível para capturar mais oportunidades
        self.rsi_periodo = self.config.get("rsi_periodo", 14)
        self.rsi_sobrecompra = self.config.get("rsi_sobrecompra", 75)  # 70 → 75
        self.rsi_sobrevenda = self.config.get("rsi_sobrevenda", 25)   # 30 → 25
        
        # Médias Móveis - Mais responsivas
        self.sma_rapida = self.config.get("sma_rapida", 12)  # 20 → 12
        self.sma_lenta = self.config.get("sma_lenta", 26)    # 50 → 26
        self.ema_rapida = self.config.get("ema_rapida", 8)   # 12 → 8
        self.ema_lenta = self.config.get("ema_lenta", 21)    # 26 → 21
        
        # MACD - Sinais mais rápidos
        self.macd_rapida = self.config.get("macd_rapida", 8)   # 12 → 8
        self.macd_lenta = self.config.get("macd_lenta", 21)    # 26 → 21
        self.macd_sinal = self.config.get("macd_sinal", 5)     # 9 → 5
        
        # Bollinger Bands - Melhor detecção
        self.bb_periodo = self.config.get("bb_periodo", 14)    # 20 → 14
        self.bb_desvio = self.config.get("bb_desvio", 1.8)     # 2 → 1.8
        
        # Thresholds otimizados para sinais
        self.threshold_forte = 0.75  # Sinal forte
        self.threshold_medio = 0.65  # Sinal médio
        self.threshold_fraco = 0.55  # Sinal fraco
        
        self.logger.info("AnaliseTecnicaBasica OTIMIZADA inicializada com sucesso")
    
    def calcular_rsi(self, precos: pd.Series, periodo: int = None) -> pd.Series:
        """
        Calcula o RSI (Relative Strength Index) - OTIMIZADO
        """
        if periodo is None:
            periodo = self.rsi_periodo
            
        delta = precos.diff()
        ganho = (delta.where(delta > 0, 0)).rolling(window=periodo).mean()
        perda = (-delta.where(delta < 0, 0)).rolling(window=periodo).mean()
        
        # Evitar divisão por zero
        perda = perda.replace(0, 0.0001)
        
        rs = ganho / perda
        rsi = 100 - (100 / (1 + rs))
        
        return rsi
    
    def calcular_medias_moveis(self, precos: pd.Series) -> Dict[str, pd.Series]:
        """
        Calcula médias móveis OTIMIZADAS (mais responsivas)
        """
        return {
            'sma_rapida': precos.rolling(window=self.sma_rapida).mean(),
            'sma_lenta': precos.rolling(window=self.sma_lenta).mean(),
            'ema_rapida': precos.ewm(span=self.ema_rapida).mean(),
            'ema_lenta': precos.ewm(span=self.ema_lenta).mean()
        }
    
    def calcular_macd(self, precos: pd.Series) -> Dict[str, pd.Series]:
        """
        Calcula MACD OTIMIZADO (sinais mais rápidos)
        """
        ema_rapida = precos.ewm(span=self.macd_rapida).mean()
        ema_lenta = precos.ewm(span=self.macd_lenta).mean()
        
        macd_linha = ema_rapida - ema_lenta
        macd_sinal = macd_linha.ewm(span=self.macd_sinal).mean()
        macd_histograma = macd_linha - macd_sinal
        
        return {
            'macd_linha': macd_linha,
            'macd_sinal': macd_sinal,
            'macd_histograma': macd_histograma
        }
    
    def calcular_bollinger_bands(self, precos: pd.Series) -> Dict[str, pd.Series]:
        """
        Calcula Bollinger Bands OTIMIZADAS (melhor detecção)
        """
        sma = precos.rolling(window=self.bb_periodo).mean()
        std = precos.rolling(window=self.bb_periodo).std()
        
        return {
            'bb_superior': sma + (std * self.bb_desvio),
            'bb_media': sma,
            'bb_inferior': sma - (std * self.bb_desvio)
        }
    
    def calcular_stochastic(self, high: pd.Series, low: pd.Series, close: pd.Series, 
                           k_periodo: int = 14, d_periodo: int = 3) -> Dict[str, pd.Series]:
        """
        Calcula Stochastic Oscillator OTIMIZADO
        """
        lowest_low = low.rolling(window=k_periodo).min()
        highest_high = high.rolling(window=k_periodo).max()
        
        # Evitar divisão por zero
        denominador = highest_high - lowest_low
        denominador = denominador.replace(0, 0.0001)
        
        k_percent = 100 * ((close - lowest_low) / denominador)
        d_percent = k_percent.rolling(window=d_periodo).mean()
        
        return {
            'stoch_k': k_percent,
            'stoch_d': d_percent
        }
    
    def analisar_dados(self, df_klines: pd.DataFrame) -> Dict:
        """
        Análise técnica OTIMIZADA dos dados de klines
        """
        try:
            # Preparar dados
            if isinstance(df_klines, list):
                df = self._converter_klines_para_df(df_klines)
            else:
                df = df_klines.copy()
            
            # Garantir colunas necessárias
            if 'close' not in df.columns:
                if len(df.columns) >= 5:
                    df.columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume'] + list(df.columns[6:])
                else:
                    raise ValueError("DataFrame não tem colunas suficientes")
            
            # Converter para numérico
            for col in ['open', 'high', 'low', 'close', 'volume']:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce')
            
            precos = df['close']
            
            # Calcular indicadores OTIMIZADOS
            rsi = self.calcular_rsi(precos)
            medias = self.calcular_medias_moveis(precos)
            macd = self.calcular_macd(precos)
            bb = self.calcular_bollinger_bands(precos)
            
            # Stochastic (se disponível)
            stoch = {}
            if all(col in df.columns for col in ['high', 'low']):
                stoch = self.calcular_stochastic(df['high'], df['low'], df['close'])
            
            # Valores atuais (última linha)
            rsi_atual = rsi.iloc[-1] if not rsi.empty else 50
            preco_atual = precos.iloc[-1]
            
            # Médias móveis atuais
            sma_rapida_atual = medias['sma_rapida'].iloc[-1] if not medias['sma_rapida'].empty else preco_atual
            sma_lenta_atual = medias['sma_lenta'].iloc[-1] if not medias['sma_lenta'].empty else preco_atual
            ema_rapida_atual = medias['ema_rapida'].iloc[-1] if not medias['ema_rapida'].empty else preco_atual
            ema_lenta_atual = medias['ema_lenta'].iloc[-1] if not medias['ema_lenta'].empty else preco_atual
            
            # MACD atual
            macd_linha_atual = macd['macd_linha'].iloc[-1] if not macd['macd_linha'].empty else 0
            macd_sinal_atual = macd['macd_sinal'].iloc[-1] if not macd['macd_sinal'].empty else 0
            macd_histograma_atual = macd['macd_histograma'].iloc[-1] if not macd['macd_histograma'].empty else 0
            
            # Bollinger Bands atuais
            bb_superior_atual = bb['bb_superior'].iloc[-1] if not bb['bb_superior'].empty else preco_atual * 1.02
            bb_inferior_atual = bb['bb_inferior'].iloc[-1] if not bb['bb_inferior'].empty else preco_atual * 0.98
            
            # Análises OTIMIZADAS
            tendencia = self._analisar_tendencia_otimizada(medias, preco_atual, rsi_atual)
            volatilidade = self._calcular_volatilidade(precos)
            momentum = self._calcular_momentum(rsi_atual, macd_histograma_atual)
            
            return {
                'rsi': rsi_atual,
                'preco_atual': preco_atual,
                'sma_rapida': sma_rapida_atual,
                'sma_lenta': sma_lenta_atual,
                'ema_rapida': ema_rapida_atual,
                'ema_lenta': ema_lenta_atual,
                'macd_linha': macd_linha_atual,
                'macd_sinal': macd_sinal_atual,
                'macd_histograma': macd_histograma_atual,
                'bb_superior': bb_superior_atual,
                'bb_inferior': bb_inferior_atual,
                'tendencia': tendencia,
                'volatilidade': volatilidade,
                'momentum': momentum,
                'stochastic': stoch
            }
            
        except Exception as e:
            self.logger.error(f"Erro na análise técnica otimizada: {e}")
            return self._retornar_analise_padrao()
    
    def gerar_sinal(self, analise: Dict) -> Tuple[str, float, str]:
        """
        Gera sinal OTIMIZADO baseado na análise técnica
        
        MELHORIAS:
        - Lógica de scoring mais precisa
        - Thresholds otimizados
        - Confiança variável baseada em múltiplos fatores
        """
        try:
            rsi = analise['rsi']
            preco = analise['preco_atual']
            sma_rapida = analise['sma_rapida']
            sma_lenta = analise['sma_lenta']
            ema_rapida = analise['ema_rapida']
            ema_lenta = analise['ema_lenta']
            macd_linha = analise['macd_linha']
            macd_sinal = analise['macd_sinal']
            macd_histograma = analise['macd_histograma']
            bb_superior = analise['bb_superior']
            bb_inferior = analise['bb_inferior']
            tendencia = analise['tendencia']
            momentum = analise['momentum']
            
            # Sistema de scoring OTIMIZADO
            score_compra = 0
            score_venda = 0
            motivos = []
            
            # === ANÁLISE RSI OTIMIZADA ===
            if rsi < self.rsi_sobrevenda:  # < 25
                score_compra += 3
                motivos.append(f'RSI sobrevenda ({rsi:.1f})')
            elif rsi < 35:  # Zona de interesse para compra
                score_compra += 1
                motivos.append(f'RSI baixo ({rsi:.1f})')
            elif rsi > self.rsi_sobrecompra:  # > 75
                score_venda += 3
                motivos.append(f'RSI sobrecompra ({rsi:.1f})')
            elif rsi > 65:  # Zona de interesse para venda
                score_venda += 1
                motivos.append(f'RSI alto ({rsi:.1f})')
            
            # === ANÁLISE DE MÉDIAS MÓVEIS OTIMIZADA ===
            if sma_rapida > sma_lenta and ema_rapida > ema_lenta:
                if preco > sma_rapida:  # Confirmação adicional
                    score_compra += 2
                    motivos.append('Tendência alta confirmada')
                else:
                    score_compra += 1
                    motivos.append('Tendência alta')
            elif sma_rapida < sma_lenta and ema_rapida < ema_lenta:
                if preco < sma_rapida:  # Confirmação adicional
                    score_venda += 2
                    motivos.append('Tendência baixa confirmada')
                else:
                    score_venda += 1
                    motivos.append('Tendência baixa')
            
            # === ANÁLISE MACD OTIMIZADA ===
            if macd_linha > macd_sinal:
                if macd_histograma > 0:  # Histograma positivo = momentum forte
                    score_compra += 2
                    motivos.append('MACD bullish forte')
                else:
                    score_compra += 1
                    motivos.append('MACD bullish')
            elif macd_linha < macd_sinal:
                if macd_histograma < 0:  # Histograma negativo = momentum forte
                    score_venda += 2
                    motivos.append('MACD bearish forte')
                else:
                    score_venda += 1
                    motivos.append('MACD bearish')
            
            # === ANÁLISE BOLLINGER BANDS OTIMIZADA ===
            bb_posicao = (preco - bb_inferior) / (bb_superior - bb_inferior)
            if bb_posicao < 0.1:  # Muito próximo da banda inferior
                score_compra += 2
                motivos.append('Preço na BB inferior')
            elif bb_posicao < 0.3:  # Próximo da banda inferior
                score_compra += 1
                motivos.append('Preço próximo BB inferior')
            elif bb_posicao > 0.9:  # Muito próximo da banda superior
                score_venda += 2
                motivos.append('Preço na BB superior')
            elif bb_posicao > 0.7:  # Próximo da banda superior
                score_venda += 1
                motivos.append('Preço próximo BB superior')
            
            # === ANÁLISE DE MOMENTUM ===
            if momentum == 'FORTE_ALTA':
                score_compra += 1
                motivos.append('Momentum forte alta')
            elif momentum == 'FORTE_BAIXA':
                score_venda += 1
                motivos.append('Momentum forte baixa')
            
            # === DECISÃO FINAL OTIMIZADA ===
            score_total = score_compra + score_venda
            
            if score_compra > score_venda:
                acao = 'COMPRAR'
                # Confiança baseada na força do sinal
                if score_compra >= 5:
                    confianca = min(0.95, self.threshold_forte + (score_compra * 0.05))
                elif score_compra >= 3:
                    confianca = self.threshold_medio + (score_compra * 0.03)
                else:
                    confianca = self.threshold_fraco + (score_compra * 0.02)
            elif score_venda > score_compra:
                acao = 'VENDER'
                # Confiança baseada na força do sinal
                if score_venda >= 5:
                    confianca = min(0.95, self.threshold_forte + (score_venda * 0.05))
                elif score_venda >= 3:
                    confianca = self.threshold_medio + (score_venda * 0.03)
                else:
                    confianca = self.threshold_fraco + (score_venda * 0.02)
            else:
                acao = 'MANTER'
                # Confiança baseada na neutralidade do RSI
                confianca = 0.5 + (abs(rsi - 50) / 200)  # 0.5 a 0.75
                if not motivos:
                    motivos.append('Sinais neutros')
            
            motivo = ', '.join(motivos[:3])  # Limitar a 3 motivos principais
            
            return acao, confianca, motivo
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar sinal otimizado: {e}")
            return 'MANTER', 0.5, 'Erro na análise'
    
    def _converter_klines_para_df(self, klines: List) -> pd.DataFrame:
        """
        Converte lista de klines para DataFrame
        """
        if not klines:
            raise ValueError("Lista de klines vazia")
        
        df = pd.DataFrame(klines)
        
        if len(df.columns) >= 6:
            df.columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume'] + list(df.columns[6:])
        else:
            df.columns = ['timestamp', 'open', 'high', 'low', 'close'] + list(df.columns[5:])
            df['volume'] = 0
        
        return df
    
    def _analisar_tendencia_otimizada(self, medias: Dict, preco_atual: float, rsi: float) -> str:
        """
        Análise de tendência OTIMIZADA com múltiplos fatores
        """
        try:
            sma_rapida = medias['sma_rapida'].iloc[-1]
            sma_lenta = medias['sma_lenta'].iloc[-1]
            ema_rapida = medias['ema_rapida'].iloc[-1]
            ema_lenta = medias['ema_lenta'].iloc[-1]
            
            # Análise multi-fator
            fatores_alta = 0
            fatores_baixa = 0
            
            # Fator 1: Médias móveis
            if sma_rapida > sma_lenta:
                fatores_alta += 1
            else:
                fatores_baixa += 1
            
            # Fator 2: EMAs
            if ema_rapida > ema_lenta:
                fatores_alta += 1
            else:
                fatores_baixa += 1
            
            # Fator 3: Preço vs médias
            if preco_atual > sma_rapida:
                fatores_alta += 1
            else:
                fatores_baixa += 1
            
            # Fator 4: RSI
            if rsi > 50:
                fatores_alta += 1
            else:
                fatores_baixa += 1
            
            # Decisão baseada em múltiplos fatores
            if fatores_alta >= 3:
                return 'ALTA'
            elif fatores_baixa >= 3:
                return 'BAIXA'
            else:
                return 'LATERAL'
                
        except:
            return 'INDEFINIDA'
    
    def _calcular_volatilidade(self, precos: pd.Series, periodo: int = 14) -> float:
        """
        Calcula volatilidade OTIMIZADA (período menor para mais sensibilidade)
        """
        try:
            retornos = precos.pct_change().dropna()
            volatilidade = retornos.rolling(window=periodo).std().iloc[-1]
            return volatilidade if not pd.isna(volatilidade) else 0.02
        except:
            return 0.02
    
    def _calcular_momentum(self, rsi: float, macd_histograma: float) -> str:
        """
        Calcula momentum baseado em RSI e MACD
        """
        try:
            if rsi > 60 and macd_histograma > 0:
                return 'FORTE_ALTA'
            elif rsi < 40 and macd_histograma < 0:
                return 'FORTE_BAIXA'
            elif rsi > 50 and macd_histograma > 0:
                return 'MODERADA_ALTA'
            elif rsi < 50 and macd_histograma < 0:
                return 'MODERADA_BAIXA'
            else:
                return 'NEUTRO'
        except:
            return 'INDEFINIDO'
    
    def _retornar_analise_padrao(self) -> Dict:
        """
        Retorna análise padrão em caso de erro
        """
        return {
            'rsi': 50.0,
            'preco_atual': 0.0,
            'sma_rapida': 0.0,
            'sma_lenta': 0.0,
            'ema_rapida': 0.0,
            'ema_lenta': 0.0,
            'macd_linha': 0.0,
            'macd_sinal': 0.0,
            'macd_histograma': 0.0,
            'bb_superior': 0.0,
            'bb_inferior': 0.0,
            'tendencia': 'INDEFINIDA',
            'volatilidade': 0.02,
            'momentum': 'NEUTRO',
            'stochastic': {}
        }

# Função de conveniência OTIMIZADA
def analisar_e_gerar_sinal(df_klines, config=None):
    """
    Função de conveniência OTIMIZADA para análise técnica e geração de sinal
    """
    analisador = AnaliseTecnicaBasica(config)
    analise = analisador.analisar_dados(df_klines)
    acao, confianca, motivo = analisador.gerar_sinal(analise)
    
    return {
        'acao': acao,
        'confianca': confianca,
        'motivo': motivo,
        'analise': analise
    }

if __name__ == "__main__":
    print("🚀 Módulo de Análise Técnica OTIMIZADA carregado com sucesso!")
    print("✅ Parâmetros otimizados para maior sensibilidade e precisão")
    print("📊 RSI: 25/75, SMA: 12/26, MACD: 8,21,5, BB: 14,1.8")

