from binance.client import Client

api_key ="cwbskK8EbmXpGW8VV6HDgDa5jrrTYuQ2QwqAqHdzUxbfb3AodfEWl86GjpbmRIwM"
api_secret = "7Jmc24SJOzm9YFUW6NxHxBIwzdRBNyQAOU8QFvcKHPhCRfs6sB6P90dskUFjQx1z"

client = Client(api_key, api_secret)
print(client.get_account())
