#!/usr/bin/env python3
"""
Script MASTER para aplicar todas as correções restantes de uma vez
Corrige os 3 erros identificados:
1. RL Agent - método 'escolher_acao' faltante
2. AutoML - método 'analisar_ativo_completo' faltante
3. Neural Governance - erro NoneType
"""

import os
import shutil
import subprocess
from datetime import datetime

def fazer_backup_master(arquivo):
    """Cria backup master antes de todas as correções"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{arquivo}_backup_master_{timestamp}"
    shutil.copy2(arquivo, backup_path)
    print(f"✅ Backup master criado: {backup_path}")
    return backup_path

def verificar_sintaxe(arquivo):
    """Verifica se a sintaxe do arquivo está correta"""
    try:
        result = subprocess.run(['python3', '-m', 'py_compile', arquivo], 
                              capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✅ Sintaxe válida: {arquivo}")
            return True
        else:
            print(f"❌ Erro de sintaxe: {result.stderr}")
            return False
    except Exception as e:
        print(f"❌ Erro ao verificar sintaxe: {e}")
        return False

def executar_script_correcao(script_name):
    """Executa um script de correção específico"""
    print(f"\n🔧 Executando: {script_name}")
    print("-" * 50)
    
    try:
        result = subprocess.run(['python3', script_name], 
                              capture_output=True, text=True)
        
        print(result.stdout)
        
        if result.returncode == 0:
            print(f"✅ {script_name} executado com sucesso")
            return True
        else:
            print(f"❌ Erro em {script_name}: {result.stderr}")
            return False
            
    except Exception as e:
        print(f"❌ Erro ao executar {script_name}: {e}")
        return False

def verificar_correcoes_aplicadas(arquivo):
    """Verifica se todas as correções foram aplicadas"""
    print("\n🔍 Verificando correções aplicadas...")
    
    try:
        with open(arquivo, 'r', encoding='utf-8') as f:
            conteudo = f.read()
        
        verificacoes = {
            "RL Agent - escolher_acao": 'def escolher_acao(' in conteudo,
            "AutoML - analisar_ativo_completo": 'def analisar_ativo_completo(' in conteudo,
            "Neural Governance - função segura": 'def executar_neural_governance_seguro' in conteudo,
            "Prometheus - função segura": 'def inicializar_prometheus_seguro' in conteudo,
            "AutoML - stub completo": 'class AutoMLIntegrationStub' in conteudo
        }
        
        print("📋 VERIFICAÇÕES:")
        todas_ok = True
        for nome, status in verificacoes.items():
            emoji = "✅" if status else "❌"
            print(f"   {emoji} {nome}: {'OK' if status else 'FALTANDO'}")
            if not status:
                todas_ok = False
        
        return todas_ok
        
    except Exception as e:
        print(f"❌ Erro na verificação: {e}")
        return False

def testar_sistema_final(arquivo):
    """Testa o sistema após todas as correções"""
    print("\n🚀 Testando sistema final...")
    
    try:
        # Teste 1: Verificação de sintaxe
        if not verificar_sintaxe(arquivo):
            return False
        
        # Teste 2: Execução rápida do dashboard
        print("🔧 Testando execução do dashboard...")
        result = subprocess.run(['timeout', '5', 'python3', arquivo, '--modo', 'dashboard'], 
                              capture_output=True, text=True)
        
        if 'SISTEMA HÍBRIDO COMPLETO' in result.stdout:
            print("✅ Dashboard funcionando")
            return True
        else:
            print(f"⚠️ Dashboard com problemas: {result.stderr}")
            return False
            
    except Exception as e:
        print(f"❌ Erro no teste: {e}")
        return False

def main():
    """Função principal - aplica todas as correções"""
    print("🚀 SCRIPT MASTER - APLICAR TODAS AS CORREÇÕES")
    print("=" * 70)
    
    arquivo_main = "main.py"
    
    # Verifica se arquivo existe
    if not os.path.exists(arquivo_main):
        print(f"❌ Arquivo {arquivo_main} não encontrado no diretório atual")
        print("💡 Execute este script no diretório onde está o main.py")
        return
    
    # Verifica se scripts de correção existem
    scripts_correcao = [
        "corrigir_rl_agent_metodo.py",
        "corrigir_automl_metodo.py", 
        "corrigir_neural_governance.py"
    ]
    
    scripts_faltantes = [s for s in scripts_correcao if not os.path.exists(s)]
    if scripts_faltantes:
        print(f"❌ Scripts de correção não encontrados: {scripts_faltantes}")
        print("💡 Certifique-se de que todos os scripts estão no mesmo diretório")
        return
    
    # Faz backup master
    backup_path = fazer_backup_master(arquivo_main)
    
    # Executa correções em sequência
    print("\n🎯 APLICANDO CORREÇÕES EM SEQUÊNCIA:")
    
    sucessos = []
    
    # Correção 1: RL Agent
    sucesso_rl = executar_script_correcao("corrigir_rl_agent_metodo.py")
    sucessos.append(("RL Agent", sucesso_rl))
    
    if sucesso_rl:
        # Correção 2: AutoML
        sucesso_automl = executar_script_correcao("corrigir_automl_metodo.py")
        sucessos.append(("AutoML", sucesso_automl))
        
        if sucesso_automl:
            # Correção 3: Neural Governance
            sucesso_neural = executar_script_correcao("corrigir_neural_governance.py")
            sucessos.append(("Neural Governance", sucesso_neural))
    
    # Verifica resultados
    print("\n📊 RESUMO DAS CORREÇÕES:")
    print("=" * 50)
    
    todas_ok = True
    for nome, sucesso in sucessos:
        emoji = "✅" if sucesso else "❌"
        status = "SUCESSO" if sucesso else "FALHA"
        print(f"   {emoji} {nome}: {status}")
        if not sucesso:
            todas_ok = False
    
    if todas_ok:
        # Verifica se todas as correções foram aplicadas
        verificacao_ok = verificar_correcoes_aplicadas(arquivo_main)
        
        if verificacao_ok:
            # Testa sistema final
            teste_ok = testar_sistema_final(arquivo_main)
            
            if teste_ok:
                print("\n🎉 TODAS AS CORREÇÕES APLICADAS COM SUCESSO!")
                print("=" * 70)
                print("✅ RL Agent: Método 'escolher_acao' adicionado")
                print("✅ AutoML: Método 'analisar_ativo_completo' adicionado")
                print("✅ Neural Governance: Proteção NoneType adicionada")
                print("✅ Sistema: Testado e funcionando")
                print("\n🚀 SISTEMA AGORA ESTÁ 100% LIVRE DE ERROS!")
            else:
                print("\n⚠️ Correções aplicadas mas sistema com problemas no teste")
        else:
            print("\n⚠️ Algumas correções podem não ter sido aplicadas corretamente")
    else:
        print("\n❌ ALGUMAS CORREÇÕES FALHARAM")
        print(f"🔄 Backup disponível em: {backup_path}")

if __name__ == "__main__":
    main()

