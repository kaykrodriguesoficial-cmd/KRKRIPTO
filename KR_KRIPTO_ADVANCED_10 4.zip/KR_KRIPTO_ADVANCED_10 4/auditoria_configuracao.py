#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para configurar logs detalhados e analisar a configuração atual
do fluxo de execução de ordens da ferramenta KR_KRIPTO_ADVANCED.

Este script é parte da Fase 1 do Plano de Auditoria do Fluxo de Execução de Ordens.
"""

import os
import sys
import json
import logging
import argparse
from datetime import datetime

# Configurar logging
log_dir = "logs/auditoria"
os.makedirs(log_dir, exist_ok=True)
log_file = f"{log_dir}/auditoria_execucao_ordens_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger("auditoria_ordens")

def analisar_configuracao():
    """
    Analisa os arquivos de configuração para verificar estratégias ativas,
    modo de operação e credenciais da API.
    """
    logger.info("Iniciando análise de configuração")
    
    # Caminhos de arquivos de configuração
    config_paths = [
        "config/config.json",
        "config/estrategias.json",
        "config/api_keys.json",
        ".env"
    ]
    
    configs = {}
    
    # Verificar cada arquivo de configuração
    for path in config_paths:
        if os.path.exists(path):
            logger.info(f"Analisando arquivo de configuração: {path}")
            
            try:
                if path.endswith('.json'):
                    with open(path, 'r') as f:
                        config = json.load(f)
                        configs[path] = config
                        logger.debug(f"Conteúdo de {path}: {json.dumps(config, indent=2)}")
                elif path.endswith('.env'):
                    env_vars = {}
                    with open(path, 'r') as f:
                        for line in f:
                            if line.strip() and not line.startswith('#'):
                                key, value = line.strip().split('=', 1)
                                env_vars[key] = value
                    configs[path] = env_vars
                    logger.debug(f"Variáveis de ambiente em {path}: {env_vars}")
            except Exception as e:
                logger.error(f"Erro ao analisar {path}: {e}")
        else:
            logger.warning(f"Arquivo de configuração não encontrado: {path}")
    
    # Verificar estratégias ativas
    if "config/estrategias.json" in configs:
        estrategias = configs["config/estrategias.json"]
        estrategias_ativas = [e for e in estrategias if e.get("ativa", False)]
        logger.info(f"Estratégias ativas encontradas: {len(estrategias_ativas)}")
        for i, estrategia in enumerate(estrategias_ativas):
            logger.info(f"Estratégia {i+1}: {estrategia.get('nome', 'Sem nome')}")
    
    # Verificar modo de operação
    modo_simulacao = True  # Valor padrão
    if "config/config.json" in configs:
        config = configs["config/config.json"]
        modo_simulacao = config.get("modo_simulacao", True)
        logger.info(f"Modo de simulação: {'ATIVADO' if modo_simulacao else 'DESATIVADO'}")
        
        # Verificar outras configurações relevantes
        debug = config.get("debug", False)
        logger.info(f"Modo debug: {'ATIVADO' if debug else 'DESATIVADO'}")
        
        ambiente = config.get("ambiente", "desenvolvimento")
        logger.info(f"Ambiente configurado: {ambiente}")
    
    # Verificar credenciais da API
    credenciais_configuradas = False
    if "config/api_keys.json" in configs:
        api_keys = configs["config/api_keys.json"]
        if "binance" in api_keys:
            binance_keys = api_keys["binance"]
            api_key_presente = bool(binance_keys.get("api_key", ""))
            api_secret_presente = bool(binance_keys.get("api_secret", ""))
            credenciais_configuradas = api_key_presente and api_secret_presente
            
            logger.info(f"Credenciais da Binance configuradas: {'SIM' if credenciais_configuradas else 'NÃO'}")
            logger.info(f"API Key presente: {'SIM' if api_key_presente else 'NÃO'}")
            logger.info(f"API Secret presente: {'SIM' if api_secret_presente else 'NÃO'}")
            
            # Verificar permissões da API (se disponível)
            permissoes = binance_keys.get("permissoes", [])
            if permissoes:
                logger.info(f"Permissões configuradas: {', '.join(permissoes)}")
                trading_permitido = "trading" in permissoes
                logger.info(f"Trading permitido: {'SIM' if trading_permitido else 'NÃO'}")
    
    # Resumo da análise
    logger.info("=== RESUMO DA ANÁLISE DE CONFIGURAÇÃO ===")
    logger.info(f"Estratégias ativas: {len(estrategias_ativas) if 'estrategias_ativas' in locals() else 'Desconhecido'}")
    logger.info(f"Modo de simulação: {'ATIVADO' if modo_simulacao else 'DESATIVADO'}")
    logger.info(f"Credenciais configuradas: {'SIM' if credenciais_configuradas else 'NÃO'}")
    
    return {
        "estrategias_ativas": estrategias_ativas if "estrategias_ativas" in locals() else [],
        "modo_simulacao": modo_simulacao,
        "credenciais_configuradas": credenciais_configuradas
    }

def configurar_logs_detalhados():
    """
    Configura logs detalhados para cada componente relevante do sistema.
    """
    logger.info("Configurando logs detalhados para componentes do sistema")
    
    # Componentes a serem monitorados
    componentes = [
        "src.infrastructure.operador",
        "src.realtime.binance_stream",
        "src.infrastructure.executor_contextual",
        "src.risk_management.risk_manager",
        "src.strategies",
        "src.signals"
    ]
    
    # Configurar cada componente para nível DEBUG
    for componente in componentes:
        comp_logger = logging.getLogger(componente)
        comp_logger.setLevel(logging.DEBUG)
        
        # Adicionar handler de arquivo específico para o componente
        handler = logging.FileHandler(f"{log_dir}/{componente.split('.')[-1]}_debug.log")
        handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
        comp_logger.addHandler(handler)
        
        logger.info(f"Logs detalhados configurados para: {componente}")
    
    logger.info("Configuração de logs detalhados concluída")

def verificar_arquivos_codigo():
    """
    Verifica a existência e integridade dos arquivos de código principais.
    """
    logger.info("Verificando arquivos de código principais")
    
    # Arquivos críticos para o fluxo de execução de ordens
    arquivos_criticos = [
        "src/infrastructure/operador.py",
        "src/realtime/binance_stream.py",
        "src/infrastructure/executor_contextual.py",
        "src/risk_management/risk_manager.py"
    ]
    
    for arquivo in arquivos_criticos:
        if os.path.exists(arquivo):
            tamanho = os.path.getsize(arquivo) / 1024  # KB
            modificado = datetime.fromtimestamp(os.path.getmtime(arquivo))
            logger.info(f"Arquivo {arquivo} encontrado - Tamanho: {tamanho:.2f} KB, Última modificação: {modificado}")
        else:
            logger.error(f"Arquivo crítico não encontrado: {arquivo}")
    
    logger.info("Verificação de arquivos de código concluída")

def main():
    """
    Função principal para executar a análise inicial.
    """
    parser = argparse.ArgumentParser(description="Auditoria do fluxo de execução de ordens")
    parser.add_argument("--config-only", action="store_true", help="Executar apenas análise de configuração")
    args = parser.parse_args()
    
    logger.info("=== INICIANDO AUDITORIA DO FLUXO DE EXECUÇÃO DE ORDENS ===")
    logger.info(f"Log detalhado sendo salvo em: {log_file}")
    
    # Verificar arquivos de código
    verificar_arquivos_codigo()
    
    # Analisar configuração
    resultado_config = analisar_configuracao()
    
    if not args.config_only:
        # Configurar logs detalhados
        configurar_logs_detalhados()
    
    logger.info("=== ANÁLISE INICIAL CONCLUÍDA ===")
    
    # Salvar resultado da análise
    resultado_file = f"{log_dir}/resultado_analise_config.json"
    with open(resultado_file, 'w') as f:
        json.dump(resultado_config, f, indent=2)
    logger.info(f"Resultado da análise salvo em: {resultado_file}")
    
    return resultado_config

if __name__ == "__main__":
    main()
