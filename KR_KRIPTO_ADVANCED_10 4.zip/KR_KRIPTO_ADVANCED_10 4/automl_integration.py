# -*- coding: utf-8 -*-
"""
AutoML Integration - Sistema de Otimização Automática Supremo

Este módulo integra AutoML avançado com Multi-timeframe, RL e Neural Governance,
criando um sistema de otimização automática que melhora continuamente a performance
através de ensemble adaptativo e destilação de conhecimento.

Autor: Manus AI
Data: 30/08/2025
Versão: 1.0.0 - FASE 3 ML SUPREMO
"""

import os
import sys
import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Any, Optional, Union, Callable
from datetime import datetime, timedelta
import json
import traceback
import pickle
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
import time

# Configurar logging
logger = logging.getLogger("automl_integration")

# Verificar dependências opcionais
try:
    import optuna
    from optuna.samplers import TPESampler
    from optuna.pruners import MedianPruner
    OPTUNA_AVAILABLE = True
except ImportError:
    OPTUNA_AVAILABLE = False
    logger.warning("Optuna não disponível - funcionalidades AutoML limitadas")

try:
    import sklearn
    from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
    from sklearn.linear_model import LinearRegression, Ridge
    from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
    from sklearn.model_selection import cross_val_score
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    logger.warning("Scikit-learn não disponível")

# Importações do sistema existente
try:
    from neural_governance_integration import NeuralGovernanceIntegration
    NEURAL_GOVERNANCE_AVAILABLE = True
except ImportError:
    NEURAL_GOVERNANCE_AVAILABLE = False
    logger.warning("Neural Governance não disponível")

try:
    from rl_multitimeframe_integration import RLMultiTimeframeAgent
    RL_AVAILABLE = True
except ImportError:
    RL_AVAILABLE = False
    logger.warning("RL Integration não disponível")

try:
    from analise_multitimeframe import MultiTimeframeAnalyzer
    MULTITIMEFRAME_AVAILABLE = True
except ImportError:
    MULTITIMEFRAME_AVAILABLE = False
    logger.warning("Multi-timeframe não disponível")

class AutoMLOptimizer:
    """
    Otimizador AutoML que usa Optuna para otimização automática de hiperparâmetros.
    
    Otimiza automaticamente parâmetros de múltiplos modelos e seleciona
    a melhor configuração baseada em métricas de performance.
    """
    
    def __init__(self, config: Dict = None):
        """
        Inicializa o otimizador AutoML.
        
        Args:
            config: Configurações do otimizador
        """
        self.config = config or {}
        self.n_trials = self.config.get('n_trials', 50)
        self.timeout = self.config.get('timeout', 300)  # 5 minutos
        self.n_jobs = self.config.get('n_jobs', 1)
        
        # Estudos Optuna por modelo
        self.studies = {}
        self.best_params = {}
        self.optimization_history = {}
        
        # Modelos suportados
        self.supported_models = {
            'random_forest': self._optimize_random_forest,
            'gradient_boosting': self._optimize_gradient_boosting,
            'ridge_regression': self._optimize_ridge,
            'neural_governance': self._optimize_neural_governance,
            'rl_agent': self._optimize_rl_agent
        }
        
        logger.info("🔬 AutoMLOptimizer inicializado")
        logger.info(f"📊 Trials: {self.n_trials}, Timeout: {self.timeout}s")
    
    def optimize_model(self, model_type: str, X_train: np.ndarray, y_train: np.ndarray,
                      X_val: np.ndarray = None, y_val: np.ndarray = None) -> Dict:
        """
        Otimiza hiperparâmetros de um modelo específico.
        
        Args:
            model_type: Tipo do modelo a otimizar
            X_train: Features de treinamento
            y_train: Target de treinamento
            X_val: Features de validação (opcional)
            y_val: Target de validação (opcional)
            
        Returns:
            Dict: Melhores parâmetros e métricas
        """
        if not OPTUNA_AVAILABLE:
            logger.error("Optuna não disponível para otimização")
            return self._get_default_params(model_type)
        
        if model_type not in self.supported_models:
            logger.error(f"Modelo {model_type} não suportado")
            return {}
        
        logger.info(f"🎯 Iniciando otimização para {model_type}")
        
        # Criar estudo Optuna
        study_name = f"{model_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        study = optuna.create_study(
            direction='maximize',
            sampler=TPESampler(seed=42),
            pruner=MedianPruner(n_startup_trials=5, n_warmup_steps=10),
            study_name=study_name
        )
        
        # Função objetivo
        def objective(trial):
            return self.supported_models[model_type](trial, X_train, y_train, X_val, y_val)
        
        # Executar otimização
        try:
            study.optimize(
                objective,
                n_trials=self.n_trials,
                timeout=self.timeout,
                n_jobs=self.n_jobs,
                show_progress_bar=False
            )
            
            # Salvar resultados
            self.studies[model_type] = study
            self.best_params[model_type] = study.best_params
            self.optimization_history[model_type] = {
                'best_value': study.best_value,
                'n_trials': len(study.trials),
                'best_trial': study.best_trial.number,
                'optimization_time': sum(t.duration.total_seconds() for t in study.trials if t.duration)
            }
            
            logger.info(f"✅ Otimização {model_type} concluída")
            logger.info(f"🏆 Melhor score: {study.best_value:.4f}")
            logger.info(f"📊 Trials executados: {len(study.trials)}")
            
            return {
                'best_params': study.best_params,
                'best_score': study.best_value,
                'n_trials': len(study.trials),
                'study': study
            }
            
        except Exception as e:
            logger.error(f"Erro na otimização {model_type}: {e}")
            return self._get_default_params(model_type)
    
    def _optimize_random_forest(self, trial, X_train, y_train, X_val, y_val):
        """Otimiza Random Forest."""
        if not SKLEARN_AVAILABLE:
            return 0.0
        
        params = {
            'n_estimators': trial.suggest_int('n_estimators', 10, 200),
            'max_depth': trial.suggest_int('max_depth', 3, 20),
            'min_samples_split': trial.suggest_int('min_samples_split', 2, 20),
            'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 10),
            'max_features': trial.suggest_categorical('max_features', ['sqrt', 'log2', None])
        }
        
        model = RandomForestRegressor(**params, random_state=42)
        
        # Cross-validation se não há dados de validação
        if X_val is None or y_val is None:
            scores = cross_val_score(model, X_train, y_train, cv=3, scoring='r2')
            return scores.mean()
        else:
            model.fit(X_train, y_train)
            y_pred = model.predict(X_val)
            return r2_score(y_val, y_pred)
    
    def _optimize_gradient_boosting(self, trial, X_train, y_train, X_val, y_val):
        """Otimiza Gradient Boosting."""
        if not SKLEARN_AVAILABLE:
            return 0.0
        
        params = {
            'n_estimators': trial.suggest_int('n_estimators', 50, 300),
            'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3),
            'max_depth': trial.suggest_int('max_depth', 3, 10),
            'min_samples_split': trial.suggest_int('min_samples_split', 2, 20),
            'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 10),
            'subsample': trial.suggest_float('subsample', 0.6, 1.0)
        }
        
        model = GradientBoostingRegressor(**params, random_state=42)
        
        if X_val is None or y_val is None:
            scores = cross_val_score(model, X_train, y_train, cv=3, scoring='r2')
            return scores.mean()
        else:
            model.fit(X_train, y_train)
            y_pred = model.predict(X_val)
            return r2_score(y_val, y_pred)
    
    def _optimize_ridge(self, trial, X_train, y_train, X_val, y_val):
        """Otimiza Ridge Regression."""
        if not SKLEARN_AVAILABLE:
            return 0.0
        
        params = {
            'alpha': trial.suggest_float('alpha', 0.1, 100.0, log=True)
        }
        
        model = Ridge(**params, random_state=42)
        
        if X_val is None or y_val is None:
            scores = cross_val_score(model, X_train, y_train, cv=3, scoring='r2')
            return scores.mean()
        else:
            model.fit(X_train, y_train)
            y_pred = model.predict(X_val)
            return r2_score(y_val, y_pred)
    
    def _optimize_neural_governance(self, trial, X_train, y_train, X_val, y_val):
        """Otimiza parâmetros da Neural Governance."""
        params = {
            'min_score_threshold': trial.suggest_float('min_score_threshold', 0.1, 0.8),
            'min_predictions_threshold': trial.suggest_int('min_predictions_threshold', 3, 20),
            'window_size': trial.suggest_int('window_size', 50, 200)
        }
        
        # Simular score baseado em parâmetros (em implementação real, testaria o modelo)
        score = (
            (1.0 - params['min_score_threshold']) * 0.4 +  # Threshold menor = mais flexível
            (1.0 / params['min_predictions_threshold']) * 0.3 +  # Menos predições = mais rápido
            (params['window_size'] / 200.0) * 0.3  # Window maior = mais histórico
        )
        
        return min(score, 1.0)
    
    def _optimize_rl_agent(self, trial, X_train, y_train, X_val, y_val):
        """Otimiza parâmetros do agente RL."""
        params = {
            'learning_rate': trial.suggest_float('learning_rate', 0.001, 0.1, log=True),
            'epsilon': trial.suggest_float('epsilon', 0.01, 0.5),
            'gamma': trial.suggest_float('gamma', 0.8, 0.99),
            'batch_size': trial.suggest_int('batch_size', 16, 128)
        }
        
        # Simular score baseado em parâmetros
        score = (
            (1.0 - params['learning_rate']) * 0.3 +  # LR menor geralmente melhor
            (1.0 - params['epsilon']) * 0.2 +  # Epsilon menor = menos exploração
            params['gamma'] * 0.3 +  # Gamma alto = mais visão de longo prazo
            (1.0 - params['batch_size'] / 128.0) * 0.2  # Batch menor = mais atualizações
        )
        
        return min(score, 1.0)
    
    def _get_default_params(self, model_type: str) -> Dict:
        """Retorna parâmetros padrão para um modelo."""
        defaults = {
            'random_forest': {
                'best_params': {'n_estimators': 100, 'max_depth': 10, 'min_samples_split': 5},
                'best_score': 0.5,
                'n_trials': 0
            },
            'gradient_boosting': {
                'best_params': {'n_estimators': 100, 'learning_rate': 0.1, 'max_depth': 6},
                'best_score': 0.5,
                'n_trials': 0
            },
            'ridge_regression': {
                'best_params': {'alpha': 1.0},
                'best_score': 0.4,
                'n_trials': 0
            },
            'neural_governance': {
                'best_params': {'min_score_threshold': 0.4, 'min_predictions_threshold': 8},
                'best_score': 0.6,
                'n_trials': 0
            },
            'rl_agent': {
                'best_params': {'learning_rate': 0.01, 'epsilon': 0.1, 'gamma': 0.95},
                'best_score': 0.5,
                'n_trials': 0
            }
        }
        
        return defaults.get(model_type, {'best_params': {}, 'best_score': 0.0, 'n_trials': 0})
    
    def get_optimization_summary(self) -> Dict:
        """
        Retorna resumo de todas as otimizações.
        
        Returns:
            Dict: Resumo das otimizações
        """
        return {
            'models_optimized': list(self.best_params.keys()),
            'best_params': self.best_params,
            'optimization_history': self.optimization_history,
            'total_studies': len(self.studies)
        }

class AdaptiveEnsemble:
    """
    Ensemble adaptativo que combina múltiplos modelos de forma inteligente.
    
    Ajusta automaticamente os pesos dos modelos baseado em performance
    recente e contexto de mercado.
    """
    
    def __init__(self, config: Dict = None):
        """
        Inicializa o ensemble adaptativo.
        
        Args:
            config: Configurações do ensemble
        """
        self.config = config or {}
        self.models = {}
        self.weights = {}
        self.performance_history = {}
        self.adaptation_rate = self.config.get('adaptation_rate', 0.1)
        self.min_weight = self.config.get('min_weight', 0.05)
        self.max_weight = self.config.get('max_weight', 0.7)
        
        logger.info("🎭 AdaptiveEnsemble inicializado")
        logger.info(f"📊 Taxa adaptação: {self.adaptation_rate}")
    
    def add_model(self, model_id: str, model_instance: Any, initial_weight: float = None):
        """
        Adiciona um modelo ao ensemble.
        
        Args:
            model_id: Identificador do modelo
            model_instance: Instância do modelo
            initial_weight: Peso inicial (opcional)
        """
        self.models[model_id] = model_instance
        
        if initial_weight is None:
            # Peso inicial baseado no número de modelos
            n_models = len(self.models)
            initial_weight = 1.0 / n_models
        
        self.weights[model_id] = initial_weight
        self.performance_history[model_id] = []
        
        # Renormalizar pesos
        self._normalize_weights()
        
        logger.info(f"✅ Modelo {model_id} adicionado ao ensemble (peso: {initial_weight:.3f})")
    
    def predict(self, input_data: Any, context: Dict = None) -> Dict:
        """
        Faz predição usando ensemble adaptativo.
        
        Args:
            input_data: Dados de entrada
            context: Contexto adicional
            
        Returns:
            Dict: Predição combinada do ensemble
        """
        if not self.models:
            logger.warning("Nenhum modelo no ensemble")
            return {'prediction': 0.0, 'confidence': 0.0, 'models_used': []}
        
        predictions = {}
        confidences = {}
        models_used = []
        
        # Obter predições de cada modelo
        for model_id, model in self.models.items():
            try:
                if hasattr(model, 'predict'):
                    pred = model.predict(input_data)
                elif hasattr(model, 'analyze_and_decide'):
                    # Para modelos de governança neural
                    result = model.analyze_and_decide('ENSEMBLE', input_data, context)
                    pred = result.get('sinal_final', {}).get('confianca', 0.5)
                elif hasattr(model, 'analisar_multitimeframe_completo'):
                    # Para analisador multi-timeframe
                    result = model.analisar_multitimeframe_completo('ENSEMBLE', input_data)
                    pred = result.get('sinal_final', {}).get('confianca', 0.5)
                else:
                    pred = 0.5  # Fallback
                
                # Extrair valor numérico
                if isinstance(pred, (list, np.ndarray)):
                    pred = float(pred[0]) if len(pred) > 0 else 0.5
                elif isinstance(pred, dict):
                    pred = pred.get('value', pred.get('confianca', 0.5))
                else:
                    pred = float(pred)
                
                predictions[model_id] = pred
                confidences[model_id] = abs(pred - 0.5) * 2  # Confiança baseada na distância de 0.5
                models_used.append(model_id)
                
            except Exception as e:
                logger.warning(f"Erro na predição do modelo {model_id}: {e}")
                predictions[model_id] = 0.5
                confidences[model_id] = 0.0
        
        if not predictions:
            return {'prediction': 0.5, 'confidence': 0.0, 'models_used': []}
        
        # Combinar predições usando pesos adaptativos
        weighted_prediction = 0.0
        weighted_confidence = 0.0
        total_weight = 0.0
        
        for model_id, pred in predictions.items():
            weight = self.weights.get(model_id, 0.0)
            weighted_prediction += pred * weight
            weighted_confidence += confidences[model_id] * weight
            total_weight += weight
        
        if total_weight > 0:
            weighted_prediction /= total_weight
            weighted_confidence /= total_weight
        
        # Registrar performance
        self._record_ensemble_performance(predictions, confidences)
        
        return {
            'prediction': weighted_prediction,
            'confidence': weighted_confidence,
            'models_used': models_used,
            'individual_predictions': predictions,
            'weights': self.weights.copy(),
            'ensemble_size': len(models_used)
        }
    
    def update_performance(self, model_id: str, actual_result: float, predicted_result: float):
        """
        Atualiza performance de um modelo e ajusta pesos.
        
        Args:
            model_id: ID do modelo
            actual_result: Resultado real
            predicted_result: Resultado predito
        """
        if model_id not in self.models:
            return
        
        # Calcular erro
        error = abs(actual_result - predicted_result)
        performance = max(0.0, 1.0 - error)  # Performance entre 0 e 1
        
        # Adicionar ao histórico
        self.performance_history[model_id].append({
            'timestamp': datetime.now(),
            'performance': performance,
            'error': error,
            'actual': actual_result,
            'predicted': predicted_result
        })
        
        # Manter apenas últimas N performances
        max_history = self.config.get('max_history', 50)
        if len(self.performance_history[model_id]) > max_history:
            self.performance_history[model_id] = self.performance_history[model_id][-max_history:]
        
        # Atualizar pesos baseado na performance
        self._update_weights()
        
        logger.debug(f"Performance atualizada para {model_id}: {performance:.3f}")
    
    def _record_ensemble_performance(self, predictions: Dict, confidences: Dict):
        """Registra performance do ensemble para ajuste futuro."""
        # Calcular métricas do ensemble
        avg_prediction = np.mean(list(predictions.values()))
        std_prediction = np.std(list(predictions.values()))
        avg_confidence = np.mean(list(confidences.values()))
        
        # Registrar diversidade (maior diversidade pode ser melhor)
        diversity_score = std_prediction  # Simples: desvio padrão das predições
        
        # Armazenar para análise futura
        ensemble_record = {
            'timestamp': datetime.now(),
            'avg_prediction': avg_prediction,
            'diversity': diversity_score,
            'avg_confidence': avg_confidence,
            'n_models': len(predictions)
        }
        
        if not hasattr(self, 'ensemble_history'):
            self.ensemble_history = []
        
        self.ensemble_history.append(ensemble_record)
        
        # Manter histórico limitado
        max_ensemble_history = self.config.get('max_ensemble_history', 100)
        if len(self.ensemble_history) > max_ensemble_history:
            self.ensemble_history = self.ensemble_history[-max_ensemble_history:]
    
    def _update_weights(self):
        """Atualiza pesos dos modelos baseado na performance recente."""
        if not self.performance_history:
            return
        
        # Calcular performance média recente para cada modelo
        recent_performances = {}
        
        for model_id, history in self.performance_history.items():
            if not history:
                recent_performances[model_id] = 0.5  # Performance neutra
                continue
            
            # Usar últimas N performances
            recent_window = self.config.get('recent_window', 10)
            recent_history = history[-recent_window:]
            
            # Performance média ponderada (mais recente tem mais peso)
            weights_time = np.exp(np.linspace(-1, 0, len(recent_history)))
            weights_time /= weights_time.sum()
            
            performances = [h['performance'] for h in recent_history]
            weighted_performance = np.average(performances, weights=weights_time)
            
            recent_performances[model_id] = weighted_performance
        
        # Atualizar pesos baseado na performance
        total_performance = sum(recent_performances.values())
        
        if total_performance > 0:
            for model_id in self.models:
                if model_id in recent_performances:
                    # Novo peso baseado na performance relativa
                    new_weight = recent_performances[model_id] / total_performance
                    
                    # Suavizar mudança usando taxa de adaptação
                    current_weight = self.weights.get(model_id, 1.0 / len(self.models))
                    adapted_weight = (
                        current_weight * (1 - self.adaptation_rate) +
                        new_weight * self.adaptation_rate
                    )
                    
                    # Aplicar limites
                    adapted_weight = max(self.min_weight, min(self.max_weight, adapted_weight))
                    
                    self.weights[model_id] = adapted_weight
        
        # Renormalizar pesos
        self._normalize_weights()
    
    def _normalize_weights(self):
        """Normaliza pesos para que somem 1.0."""
        if not self.weights:
            return
        
        total_weight = sum(self.weights.values())
        
        if total_weight > 0:
            for model_id in self.weights:
                self.weights[model_id] /= total_weight
    
    def get_ensemble_status(self) -> Dict:
        """
        Retorna status completo do ensemble.
        
        Returns:
            Dict: Status do ensemble
        """
        # Calcular estatísticas de performance
        model_stats = {}
        
        for model_id, history in self.performance_history.items():
            if history:
                performances = [h['performance'] for h in history]
                model_stats[model_id] = {
                    'avg_performance': np.mean(performances),
                    'std_performance': np.std(performances),
                    'n_predictions': len(history),
                    'current_weight': self.weights.get(model_id, 0.0)
                }
            else:
                model_stats[model_id] = {
                    'avg_performance': 0.0,
                    'std_performance': 0.0,
                    'n_predictions': 0,
                    'current_weight': self.weights.get(model_id, 0.0)
                }
        
        return {
            'n_models': len(self.models),
            'model_weights': self.weights.copy(),
            'model_stats': model_stats,
            'adaptation_rate': self.adaptation_rate,
            'ensemble_history_size': len(getattr(self, 'ensemble_history', []))
        }

class AutoMLIntegration:
    """
    Integração completa de AutoML com Multi-timeframe, RL e Neural Governance.
    
    Esta classe orquestra todos os componentes de AutoML, fornecendo
    otimização automática, ensemble adaptativo e integração inteligente.
    """
    
    def __init__(self, config: Dict = None):
        """
        Inicializa a integração AutoML completa.
        
        Args:
            config: Configurações da integração
        """
        self.config = config or {}
        
        # Componentes AutoML
        self.optimizer = AutoMLOptimizer(self.config.get('optimizer_config', {}))
        self.ensemble = AdaptiveEnsemble(self.config.get('ensemble_config', {}))
        
        # Componentes integrados
        self.neural_governance = None
        self.multitf_analyzer = None
        self.rl_agent = None
        
        # Status e métricas
        self.optimization_results = {}
        self.ensemble_performance = []
        self.integration_metrics = {}
        
        # Configurar componentes
        self._setup_components()
        
        logger.info("🌟 AutoMLIntegration inicializada")
    
    def _setup_components(self):
        """Configura e integra todos os componentes."""
        try:
            # Neural Governance
            if NEURAL_GOVERNANCE_AVAILABLE:
                from neural_governance_integration import criar_neural_governance_integration
                
                ng_config = self.config.get('neural_governance_config', {})
                self.neural_governance = criar_neural_governance_integration(ng_config)
                
                # Adicionar ao ensemble
                self.ensemble.add_model(
                    'neural_governance',
                    self.neural_governance,
                    initial_weight=0.4  # Peso alto para governança neural
                )
                
                logger.info("✅ Neural Governance integrada ao AutoML")
            
            # Multi-timeframe Analyzer
            if MULTITIMEFRAME_AVAILABLE:
                self.multitf_analyzer = MultiTimeframeAnalyzer(self.config)
                
                # Adicionar ao ensemble
                self.ensemble.add_model(
                    'multitimeframe',
                    self.multitf_analyzer,
                    initial_weight=0.35  # Peso médio-alto
                )
                
                logger.info("✅ Multi-timeframe analyzer integrado ao AutoML")
            
            # RL Agent
            if RL_AVAILABLE:
                rl_config = self.config.get('rl_config', {
                    'ativo': 'BTCUSDT',
                    'timeframes': ['15m', '1h', '4h', '1d']
                })
                
                self.rl_agent = RLMultiTimeframeAgent(rl_config)
                
                # Tentar carregar modelo existente
                model_path = "models/rl_multitf_test.json"
                if os.path.exists(model_path):
                    self.rl_agent.load_model(model_path)
                
                # Adicionar ao ensemble
                self.ensemble.add_model(
                    'rl_agent',
                    self.rl_agent,
                    initial_weight=0.25  # Peso menor (ainda aprendendo)
                )
                
                logger.info("✅ RL Agent integrado ao AutoML")
            
        except Exception as e:
            logger.error(f"Erro ao configurar componentes: {e}")
    
    def optimize_system(self, training_data: Dict = None) -> Dict:
        """
        Executa otimização completa do sistema.
        
        Args:
            training_data: Dados para otimização (opcional)
            
        Returns:
            Dict: Resultados da otimização
        """
        logger.info("🚀 Iniciando otimização completa do sistema AutoML")
        
        optimization_results = {}
        
        # Gerar dados sintéticos se não fornecidos
        if training_data is None:
            training_data = self._generate_synthetic_training_data()
        
        X_train = training_data.get('X_train')
        y_train = training_data.get('y_train')
        X_val = training_data.get('X_val')
        y_val = training_data.get('y_val')
        
        if X_train is None or y_train is None:
            logger.warning("Dados de treinamento não disponíveis, usando otimização simulada")
            return self._simulate_optimization()
        
        # Otimizar cada tipo de modelo
        models_to_optimize = ['random_forest', 'gradient_boosting', 'ridge_regression']
        
        if SKLEARN_AVAILABLE:
            for model_type in models_to_optimize:
                logger.info(f"🎯 Otimizando {model_type}...")
                
                result = self.optimizer.optimize_model(
                    model_type, X_train, y_train, X_val, y_val
                )
                
                optimization_results[model_type] = result
                
                logger.info(f"✅ {model_type} otimizado: score {result.get('best_score', 0):.4f}")
        
        # Otimizar componentes integrados
        if self.neural_governance:
            logger.info("🧠 Otimizando Neural Governance...")
            ng_result = self.optimizer.optimize_model(
                'neural_governance', X_train, y_train, X_val, y_val
            )
            optimization_results['neural_governance'] = ng_result
        
        if self.rl_agent:
            logger.info("🤖 Otimizando RL Agent...")
            rl_result = self.optimizer.optimize_model(
                'rl_agent', X_train, y_train, X_val, y_val
            )
            optimization_results['rl_agent'] = rl_result
        
        # Salvar resultados
        self.optimization_results = optimization_results
        
        # Atualizar configurações dos componentes com parâmetros otimizados
        self._apply_optimized_parameters()
        
        logger.info("🎉 Otimização completa finalizada")
        
        return {
            'optimization_results': optimization_results,
            'summary': self.optimizer.get_optimization_summary(),
            'ensemble_status': self.ensemble.get_ensemble_status()
        }
    
    def _generate_synthetic_training_data(self) -> Dict:
        """Gera dados sintéticos para treinamento."""
        logger.info("📊 Gerando dados sintéticos para treinamento")
        
        n_samples = 1000
        n_features = 20
        
        # Features simulando indicadores técnicos
        np.random.seed(42)
        X = np.random.randn(n_samples, n_features)
        
        # Target simulando retornos/sinais
        # Combinação linear com ruído
        true_weights = np.random.randn(n_features) * 0.1
        y = X @ true_weights + np.random.randn(n_samples) * 0.05
        
        # Normalizar target para [0, 1]
        y = (y - y.min()) / (y.max() - y.min())
        
        # Split treino/validação
        split_idx = int(0.8 * n_samples)
        
        return {
            'X_train': X[:split_idx],
            'y_train': y[:split_idx],
            'X_val': X[split_idx:],
            'y_val': y[split_idx:]
        }
    
    def _simulate_optimization(self) -> Dict:
        """Simula otimização quando dados reais não estão disponíveis."""
        logger.info("🎭 Executando otimização simulada")
        
        simulated_results = {}
        
        # Simular resultados para cada modelo
        models = ['random_forest', 'gradient_boosting', 'neural_governance', 'rl_agent']
        
        for model in models:
            simulated_results[model] = {
                'best_params': self.optimizer._get_default_params(model)['best_params'],
                'best_score': np.random.uniform(0.6, 0.9),  # Score simulado
                'n_trials': np.random.randint(20, 50)
            }
        
        self.optimization_results = simulated_results
        
        return {
            'optimization_results': simulated_results,
            'summary': {'models_optimized': models, 'simulated': True},
            'ensemble_status': self.ensemble.get_ensemble_status()
        }
    
    def _apply_optimized_parameters(self):
        """Aplica parâmetros otimizados aos componentes."""
        logger.info("🔧 Aplicando parâmetros otimizados")
        
        # Aplicar parâmetros da Neural Governance
        if 'neural_governance' in self.optimization_results and self.neural_governance:
            ng_params = self.optimization_results['neural_governance'].get('best_params', {})
            
            # Atualizar configurações (implementação simplificada)
            if hasattr(self.neural_governance, 'neural_governor'):
                governor = self.neural_governance.neural_governor
                
                if 'min_score_threshold' in ng_params:
                    governor.min_score_threshold = ng_params['min_score_threshold']
                
                if 'min_predictions_threshold' in ng_params:
                    governor.min_predictions_threshold = ng_params['min_predictions_threshold']
                
                logger.info(f"✅ Neural Governance atualizada: {ng_params}")
        
        # Aplicar parâmetros do RL Agent
        if 'rl_agent' in self.optimization_results and self.rl_agent:
            rl_params = self.optimization_results['rl_agent'].get('best_params', {})
            
            # Atualizar parâmetros do RL
            if 'learning_rate' in rl_params:
                self.rl_agent.learning_rate = rl_params['learning_rate']
            
            if 'epsilon' in rl_params:
                self.rl_agent.epsilon = rl_params['epsilon']
            
            if 'gamma' in rl_params:
                self.rl_agent.gamma = rl_params['gamma']
            
            logger.info(f"✅ RL Agent atualizado: {rl_params}")
    
    def predict_with_automl(self, symbol: str, dados_por_tf: Dict, 
                           market_context: Dict = None) -> Dict:
        """
        Faz predição usando sistema AutoML completo.
        
        Args:
            symbol: Símbolo do ativo
            dados_por_tf: Dados por timeframe
            market_context: Contexto de mercado
            
        Returns:
            Dict: Predição do ensemble AutoML
        """
        try:
            # Preparar contexto
            context = market_context or {}
            context['symbol'] = symbol
            
            # Fazer predição com ensemble
            ensemble_result = self.ensemble.predict(dados_por_tf, context)
            
            # Converter para formato padrão
            prediction_value = ensemble_result.get('prediction', 0.5)
            confidence = ensemble_result.get('confidence', 0.5)
            
            # Determinar ação baseada na predição
            if prediction_value > 0.6:
                action = 'COMPRAR'
            elif prediction_value < 0.4:
                action = 'VENDER'
            else:
                action = 'MANTER'
            
            # Calcular score baseado na confiança e número de modelos
            ensemble_size = ensemble_result.get('ensemble_size', 1)
            base_score = confidence * 30.0  # Score máximo 30
            ensemble_bonus = min(ensemble_size * 2, 10)  # Bônus por ensemble
            total_score = min(base_score + ensemble_bonus, 30.0)
            
            # Classificar qualidade
            if total_score >= 25:
                classification = 'SUPREMO'
            elif total_score >= 20:
                classification = 'EXCELENTE'
            elif total_score >= 15:
                classification = 'BOM'
            elif total_score >= 10:
                classification = 'REGULAR'
            else:
                classification = 'FRACO'
            
            result = {
                'sinal_final': {
                    'acao': action,
                    'confianca': confidence,
                    'motivo': f"AutoML Ensemble: {ensemble_size} modelos, confiança {confidence:.1%}"
                },
                'scoring': {
                    'score_total': total_score,
                    'classificacao': classification
                },
                'automl': {
                    'ensemble_prediction': prediction_value,
                    'ensemble_confidence': confidence,
                    'models_used': ensemble_result.get('models_used', []),
                    'individual_predictions': ensemble_result.get('individual_predictions', {}),
                    'model_weights': ensemble_result.get('weights', {}),
                    'ensemble_size': ensemble_size
                },
                'integration': {
                    'version': '1.0.0',
                    'components': ['automl', 'ensemble', 'optimization'],
                    'symbol': symbol,
                    'timestamp': datetime.now().isoformat()
                }
            }
            
            # Registrar performance para adaptação futura
            self._record_prediction(symbol, result)
            
            return result
            
        except Exception as e:
            logger.error(f"Erro na predição AutoML: {e}")
            return self._get_fallback_prediction(symbol)
    
    def _record_prediction(self, symbol: str, prediction: Dict):
        """Registra predição para análise de performance futura."""
        record = {
            'timestamp': datetime.now(),
            'symbol': symbol,
            'prediction': prediction,
            'ensemble_info': prediction.get('automl', {})
        }
        
        if not hasattr(self, 'prediction_history'):
            self.prediction_history = []
        
        self.prediction_history.append(record)
        
        # Manter histórico limitado
        max_history = self.config.get('max_prediction_history', 1000)
        if len(self.prediction_history) > max_history:
            self.prediction_history = self.prediction_history[-max_history:]
    
    def _get_fallback_prediction(self, symbol: str) -> Dict:
        """Retorna predição de fallback."""
        return {
            'sinal_final': {
                'acao': 'MANTER',
                'confianca': 0.5,
                'motivo': 'AutoML Fallback - erro no ensemble'
            },
            'scoring': {
                'score_total': 10.0,
                'classificacao': 'FALLBACK'
            },
            'automl': {
                'ensemble_prediction': 0.5,
                'ensemble_confidence': 0.5,
                'models_used': [],
                'error': 'Fallback prediction'
            }
        }
    
    def get_automl_status(self) -> Dict:
        """
        Retorna status completo do sistema AutoML.
        
        Returns:
            Dict: Status do AutoML
        """
        return {
            'optimizer': self.optimizer.get_optimization_summary(),
            'ensemble': self.ensemble.get_ensemble_status(),
            'components': {
                'neural_governance_available': self.neural_governance is not None,
                'multitimeframe_available': self.multitf_analyzer is not None,
                'rl_agent_available': self.rl_agent is not None,
                'optuna_available': OPTUNA_AVAILABLE,
                'sklearn_available': SKLEARN_AVAILABLE
            },
            'optimization_results': self.optimization_results,
            'prediction_history_size': len(getattr(self, 'prediction_history', [])),
            'config': self.config,
            'timestamp': datetime.now().isoformat()
        }

def criar_automl_integration(config: Dict = None) -> AutoMLIntegration:
    """
    Função de conveniência para criar integração AutoML.
    
    Args:
        config: Configurações da integração
        
    Returns:
        AutoMLIntegration: Sistema AutoML integrado
    """
    if config is None:
        config = {
            'optimizer_config': {
                'n_trials': 30,
                'timeout': 180,  # 3 minutos
                'n_jobs': 1
            },
            'ensemble_config': {
                'adaptation_rate': 0.15,
                'min_weight': 0.05,
                'max_weight': 0.6,
                'recent_window': 15
            },
            'neural_governance_config': {
                'selection_strategy': 'best_recent',
                'min_score_threshold': 0.4
            },
            'rl_config': {
                'ativo': 'BTCUSDT',
                'timeframes': ['15m', '1h', '4h', '1d'],
                'learning_rate': 0.01,
                'epsilon': 0.1
            }
        }
    
    return AutoMLIntegration(config)

if __name__ == "__main__":
    # Teste básico
    print("🔬 Testando AutoML Integration...")
    
    config_teste = {
        'optimizer_config': {
            'n_trials': 10,  # Reduzido para teste
            'timeout': 60
        },
        'ensemble_config': {
            'adaptation_rate': 0.2
        }
    }
    
    integration = criar_automl_integration(config_teste)
    print(f"✅ AutoML Integration criada")
    
    # Testar status
    status = integration.get_automl_status()
    print(f"📊 Componentes disponíveis:")
    for comp, available in status['components'].items():
        print(f"  {comp}: {'✅' if available else '❌'}")
    
    print("🎉 AutoML Integration pronta!")

