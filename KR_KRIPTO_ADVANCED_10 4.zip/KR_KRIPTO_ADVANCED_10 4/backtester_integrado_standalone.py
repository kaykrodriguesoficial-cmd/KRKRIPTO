#!/usr/bin/env python3
"""
BACKTESTER INTEGRADO ML SUPREMO + OTIMIZAÇÕES - STANDALONE
==========================================================

Este backtester simula o sistema ML Supremo + Otimizações completo
sem dependências externas, validando cientificamente a performance.

Versão: 1.0.0 Standalone
Data: 2025-09-01
Autor: Sistema ML Supremo
"""

import asyncio
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
import json
import logging
from typing import Dict, List, Any, Optional, Tuple
import warnings
warnings.filterwarnings('ignore')

# Configurar logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class GestaoRiscoIntegrada:
    """Gestão de risco integrada para backtesting."""
    
    def __init__(self, config: Dict):
        self.config = config
        self.posicoes_abertas = {}
        self.historico_operacoes = []
        
    def calcular_atr(self, dados: pd.DataFrame, periodo: int = 14) -> float:
        """Calcula Average True Range."""
        try:
            if len(dados) < periodo + 1:
                return 0.0
            
            high = dados['high'].values
            low = dados['low'].values
            close = dados['close'].shift(1).values
            
            tr1 = high - low
            tr2 = np.abs(high - close)
            tr3 = np.abs(low - close)
            
            tr = np.maximum(tr1, np.maximum(tr2, tr3))
            atr = np.mean(tr[-periodo:]) if len(tr) >= periodo else 0.0
            
            return float(atr)
            
        except Exception as e:
            logger.error(f"Erro ao calcular ATR: {e}")
            return 0.0
    
    def calcular_position_size(self, symbol: str, preco_atual: float, stop_loss: float) -> float:
        """Calcula tamanho da posição baseado no risco."""
        try:
            capital_disponivel = self.config.get('capital_inicial', 10000)
            risk_per_trade = self.config.get('risk_per_trade', 0.02)
            max_position_size = self.config.get('max_position_size', 0.1)
            
            # Calcular risco por trade
            risco_monetario = capital_disponivel * risk_per_trade
            
            # Calcular diferença de preço até stop-loss
            diferenca_preco = abs(preco_atual - stop_loss)
            
            if diferenca_preco > 0:
                # Position size baseado no risco
                position_size = risco_monetario / diferenca_preco
                
                # Aplicar limite máximo
                max_size = (capital_disponivel * max_position_size) / preco_atual
                position_size = min(position_size, max_size)
                
                return max(0, position_size)
            
            return 0.0
            
        except Exception as e:
            logger.error(f"Erro ao calcular position size: {e}")
            return 0.0
    
    def definir_stop_loss_take_profit(self, preco_atual: float, atr: float, direcao: str) -> Tuple[float, float]:
        """Define stop-loss e take-profit baseados no ATR."""
        try:
            atr_multiplier = self.config.get('atr_multiplier', 2.0)
            min_risk_reward = self.config.get('min_risk_reward', 1.5)
            
            if atr > 0:
                if direcao == 'COMPRAR':
                    stop_loss = preco_atual - (atr * atr_multiplier)
                    take_profit = preco_atual + (atr * atr_multiplier * min_risk_reward)
                else:  # VENDER
                    stop_loss = preco_atual + (atr * atr_multiplier)
                    take_profit = preco_atual - (atr * atr_multiplier * min_risk_reward)
            else:
                # Fallback sem ATR
                if direcao == 'COMPRAR':
                    stop_loss = preco_atual * 0.95  # 5% stop-loss
                    take_profit = preco_atual * 1.075  # 7.5% take-profit
                else:
                    stop_loss = preco_atual * 1.05
                    take_profit = preco_atual * 0.925
            
            return stop_loss, take_profit
            
        except Exception as e:
            logger.error(f"Erro ao definir stop-loss/take-profit: {e}")
            return preco_atual * 0.95, preco_atual * 1.05
    
    def verificar_gestao_risco(self, symbol: str, preco_atual: float, acao_sugerida: str) -> Dict:
        """Verifica e aplica regras de gestão de risco."""
        try:
            # Verificar se já há posição aberta
            if symbol in self.posicoes_abertas:
                posicao = self.posicoes_abertas[symbol]
                
                # Verificar stop-loss e take-profit
                if posicao['direcao'] == 'COMPRAR':
                    if preco_atual <= posicao['stop_loss']:
                        return {
                            'gestao_risco': True,
                            'acao': 'VENDER',
                            'motivo': 'STOP_LOSS_ATIVADO',
                            'confianca': 0.95
                        }
                    elif preco_atual >= posicao['take_profit']:
                        return {
                            'gestao_risco': True,
                            'acao': 'VENDER',
                            'motivo': 'TAKE_PROFIT_ATIVADO',
                            'confianca': 0.95
                        }
            
            # Verificar se pode abrir nova posição
            if acao_sugerida in ['COMPRAR', 'VENDER'] and symbol not in self.posicoes_abertas:
                return {
                    'gestao_risco': True,
                    'acao': acao_sugerida,
                    'motivo': 'APROVADO_GESTAO_RISCO',
                    'confianca': None  # Manter confiança original
                }
            
            # Manter ação original se não há regras aplicáveis
            return {
                'gestao_risco': False,
                'acao': acao_sugerida,
                'motivo': 'SEM_GESTAO_RISCO'
            }
            
        except Exception as e:
            logger.error(f"Erro na gestão de risco: {e}")
            return {
                'gestao_risco': False,
                'acao': 'MANTER',
                'motivo': 'ERRO_GESTAO_RISCO'
            }
    
    def registrar_operacao(self, symbol: str, acao: str, preco: float, quantidade: float, atr: float):
        """Registra operação no histórico."""
        try:
            operacao = {
                'timestamp': datetime.now(),
                'symbol': symbol,
                'acao': acao,
                'preco': preco,
                'quantidade': quantidade,
                'atr': atr
            }
            
            self.historico_operacoes.append(operacao)
            
            if acao == 'COMPRAR':
                stop_loss, take_profit = self.definir_stop_loss_take_profit(preco, atr, 'COMPRAR')
                self.posicoes_abertas[symbol] = {
                    'direcao': 'COMPRAR',
                    'preco_entrada': preco,
                    'quantidade': quantidade,
                    'stop_loss': stop_loss,
                    'take_profit': take_profit,
                    'atr': atr
                }
            elif acao == 'VENDER' and symbol in self.posicoes_abertas:
                del self.posicoes_abertas[symbol]
                
        except Exception as e:
            logger.error(f"Erro ao registrar operação: {e}")

class ScoringIntegrado:
    """Sistema de scoring integrado para backtesting."""
    
    def __init__(self, config: Dict):
        self.config = config
    
    def analisar_confluencia_otimizada(self, dados: pd.DataFrame) -> Dict:
        """Executa análise de confluência otimizada."""
        try:
            if len(dados) < 50:
                return {'acao': 'AGUARDAR', 'confianca': 0.0, 'score': 0}
            
            # Calcular indicadores
            rsi = self._calcular_rsi(dados)
            macd_signal = self._calcular_macd(dados)
            bb_signal = self._calcular_bollinger_bands(dados)
            sma_signal = self._calcular_sma(dados)
            volume_signal = self._calcular_volume(dados)
            momentum_signal = self._calcular_momentum(dados)
            stoch_signal = self._calcular_stochastic(dados)
            
            # Calcular scores individuais
            scores = {
                'rsi': self._score_rsi(rsi),
                'macd': macd_signal,
                'bollinger': bb_signal,
                'sma': sma_signal,
                'volume': volume_signal,
                'momentum': momentum_signal,
                'stochastic': stoch_signal
            }
            
            # Pesos otimizados (baseados no backtesting anterior)
            pesos = {
                'rsi': 0.20,
                'macd': 0.18,
                'bollinger': 0.15,
                'sma': 0.15,
                'volume': 0.12,
                'momentum': 0.10,
                'stochastic': 0.10
            }
            
            # Calcular score final ponderado
            score_final = sum(scores[ind] * pesos[ind] for ind in scores)
            
            # Normalizar para 0-100
            score_normalizado = max(0, min(100, (score_final + 1) * 50))
            
            # Determinar ação baseada no score
            if score_normalizado >= 70:
                acao = 'COMPRAR'
                confianca = min(0.95, score_normalizado / 100)
            elif score_normalizado <= 30:
                acao = 'VENDER'
                confianca = min(0.95, (100 - score_normalizado) / 100)
            else:
                acao = 'AGUARDAR'
                confianca = 0.5
            
            return {
                'acao': acao,
                'confianca': confianca,
                'score': score_normalizado,
                'scores_individuais': scores,
                'indicadores': {
                    'rsi': rsi,
                    'macd': macd_signal,
                    'bollinger': bb_signal
                }
            }
            
        except Exception as e:
            logger.error(f"Erro na análise de confluência: {e}")
            return {'acao': 'AGUARDAR', 'confianca': 0.0, 'score': 0}
    
    def _calcular_rsi(self, dados: pd.DataFrame, periodo: int = 14) -> float:
        """Calcula RSI."""
        try:
            if len(dados) < periodo + 1:
                return 50.0
            
            closes = dados['close'].values
            deltas = np.diff(closes)
            
            gains = np.where(deltas > 0, deltas, 0)
            losses = np.where(deltas < 0, -deltas, 0)
            
            avg_gain = np.mean(gains[-periodo:])
            avg_loss = np.mean(losses[-periodo:])
            
            if avg_loss == 0:
                return 100.0
            
            rs = avg_gain / avg_loss
            rsi = 100 - (100 / (1 + rs))
            
            return float(rsi)
            
        except Exception:
            return 50.0
    
    def _calcular_macd(self, dados: pd.DataFrame) -> float:
        """Calcula sinal MACD."""
        try:
            if len(dados) < 26:
                return 0.0
            
            closes = dados['close'].values
            
            # EMA 12 e 26
            ema12 = self._ema(closes, 12)
            ema26 = self._ema(closes, 26)
            
            macd_line = ema12 - ema26
            signal_line = self._ema(np.array([macd_line]), 9)[0] if len(dados) >= 35 else macd_line
            
            # Sinal baseado na diferença
            if macd_line > signal_line:
                return 1.0  # Bullish
            elif macd_line < signal_line:
                return -1.0  # Bearish
            else:
                return 0.0  # Neutro
                
        except Exception:
            return 0.0
    
    def _calcular_bollinger_bands(self, dados: pd.DataFrame, periodo: int = 20) -> float:
        """Calcula sinal das Bollinger Bands."""
        try:
            if len(dados) < periodo:
                return 0.0
            
            closes = dados['close'].values[-periodo:]
            sma = np.mean(closes)
            std = np.std(closes)
            
            upper_band = sma + (2 * std)
            lower_band = sma - (2 * std)
            
            preco_atual = closes[-1]
            
            if preco_atual <= lower_band:
                return 1.0  # Oversold - sinal de compra
            elif preco_atual >= upper_band:
                return -1.0  # Overbought - sinal de venda
            else:
                return 0.0  # Dentro das bandas
                
        except Exception:
            return 0.0
    
    def _calcular_sma(self, dados: pd.DataFrame) -> float:
        """Calcula sinal das médias móveis."""
        try:
            if len(dados) < 50:
                return 0.0
            
            closes = dados['close'].values
            sma20 = np.mean(closes[-20:])
            sma50 = np.mean(closes[-50:])
            
            preco_atual = closes[-1]
            
            # Sinal baseado na posição do preço em relação às médias
            if preco_atual > sma20 > sma50:
                return 1.0  # Bullish
            elif preco_atual < sma20 < sma50:
                return -1.0  # Bearish
            else:
                return 0.0  # Neutro
                
        except Exception:
            return 0.0
    
    def _calcular_volume(self, dados: pd.DataFrame) -> float:
        """Calcula sinal de volume."""
        try:
            if len(dados) < 20:
                return 0.0
            
            volumes = dados['volume'].values
            volume_atual = volumes[-1]
            volume_medio = np.mean(volumes[-20:])
            
            if volume_atual > volume_medio * 1.5:
                return 0.5  # Volume alto - confirma movimento
            else:
                return 0.0  # Volume normal
                
        except Exception:
            return 0.0
    
    def _calcular_momentum(self, dados: pd.DataFrame, periodo: int = 10) -> float:
        """Calcula momentum."""
        try:
            if len(dados) < periodo + 1:
                return 0.0
            
            closes = dados['close'].values
            momentum = (closes[-1] / closes[-periodo-1] - 1) * 100
            
            if momentum > 2:
                return 1.0  # Momentum positivo forte
            elif momentum < -2:
                return -1.0  # Momentum negativo forte
            else:
                return momentum / 10  # Momentum moderado
                
        except Exception:
            return 0.0
    
    def _calcular_stochastic(self, dados: pd.DataFrame, periodo: int = 14) -> float:
        """Calcula Stochastic Oscillator."""
        try:
            if len(dados) < periodo:
                return 0.0
            
            highs = dados['high'].values[-periodo:]
            lows = dados['low'].values[-periodo:]
            close = dados['close'].values[-1]
            
            highest_high = np.max(highs)
            lowest_low = np.min(lows)
            
            if highest_high == lowest_low:
                return 0.0
            
            k_percent = ((close - lowest_low) / (highest_high - lowest_low)) * 100
            
            if k_percent <= 20:
                return 1.0  # Oversold
            elif k_percent >= 80:
                return -1.0  # Overbought
            else:
                return 0.0  # Neutro
                
        except Exception:
            return 0.0
    
    def _score_rsi(self, rsi: float) -> float:
        """Converte RSI em score."""
        if rsi <= 30:
            return 1.0  # Oversold - compra
        elif rsi >= 70:
            return -1.0  # Overbought - venda
        else:
            return 0.0  # Neutro
    
    def _ema(self, values: np.ndarray, periodo: int) -> float:
        """Calcula EMA."""
        try:
            if len(values) < periodo:
                return np.mean(values)
            
            alpha = 2 / (periodo + 1)
            ema = values[0]
            
            for value in values[1:]:
                ema = alpha * value + (1 - alpha) * ema
            
            return ema
            
        except Exception:
            return np.mean(values) if len(values) > 0 else 0.0

class DataCollectorIntegrado:
    """Coletor de dados integrado com fallback para simulação."""
    
    def __init__(self):
        self.cache = {}
        self.logger = logging.getLogger(__name__)
        
    async def obter_dados_historicos(self, symbol: str, interval: str, limit: int = 1000) -> pd.DataFrame:
        """Obtém dados históricos reais ou simulados."""
        try:
            # Para este backtesting, vamos usar dados simulados realistas
            return self._gerar_dados_simulados(symbol, interval, limit)
                
        except Exception as e:
            self.logger.error(f"❌ Erro ao obter dados para {symbol}: {e}")
            return self._gerar_dados_simulados(symbol, interval, limit)
    
    def _gerar_dados_simulados(self, symbol: str, interval: str, limit: int) -> pd.DataFrame:
        """Gera dados simulados realistas para backtesting."""
        
        # Preços base por símbolo
        precos_base = {
            'BTCUSDT': 67000,
            'ETHUSDT': 4300,
            'ADAUSDT': 0.45,
            'BNBUSDT': 580
        }
        
        preco_base = precos_base.get(symbol, 50000)
        
        # Gerar timestamps
        now = datetime.now()
        if interval == '1h':
            delta = timedelta(hours=1)
        elif interval == '4h':
            delta = timedelta(hours=4)
        elif interval == '1d':
            delta = timedelta(days=1)
        else:
            delta = timedelta(hours=1)
        
        timestamps = [now - delta * i for i in range(limit, 0, -1)]
        
        # Gerar preços com movimento browniano + tendências
        np.random.seed(hash(symbol) % 1000)  # Seed baseado no símbolo para consistência
        
        # Criar tendências realistas
        trend_changes = np.random.randint(50, 200, size=limit//100 + 1)  # Mudanças de tendência
        trends = []
        
        for i, change_point in enumerate(trend_changes):
            trend_direction = 1 if i % 2 == 0 else -1  # Alternar entre alta e baixa
            trend_strength = np.random.uniform(0.0005, 0.002)  # 0.05% a 0.2% por período
            trends.extend([trend_direction * trend_strength] * min(change_point, limit - len(trends)))
            if len(trends) >= limit:
                break
        
        trends = trends[:limit]
        
        # Gerar retornos com tendência + ruído
        returns = []
        for i in range(limit):
            trend = trends[i] if i < len(trends) else 0
            noise = np.random.normal(0, 0.015)  # 1.5% volatilidade
            returns.append(trend + noise)
        
        # Gerar preços
        prices = [preco_base]
        for ret in returns[1:]:
            prices.append(prices[-1] * (1 + ret))
        
        # Criar OHLCV realista
        data = []
        for i, (ts, close) in enumerate(zip(timestamps, prices)):
            # Volatilidade intraday baseada no período
            if interval == '1h':
                intraday_vol = 0.008  # 0.8%
            elif interval == '4h':
                intraday_vol = 0.015  # 1.5%
            else:
                intraday_vol = 0.025  # 2.5%
            
            volatility = abs(np.random.normal(0, intraday_vol))
            
            # OHLC baseado no close
            open_price = prices[i-1] if i > 0 else close
            
            # High e Low baseados na volatilidade
            high = close * (1 + volatility * np.random.uniform(0.3, 1.0))
            low = close * (1 - volatility * np.random.uniform(0.3, 1.0))
            
            # Garantir que OHLC faz sentido
            high = max(high, open_price, close)
            low = min(low, open_price, close)
            
            # Volume correlacionado com volatilidade
            base_volume = 5000
            volume_multiplier = 1 + (volatility * 10)  # Mais volume em alta volatilidade
            volume = base_volume * volume_multiplier * np.random.uniform(0.5, 2.0)
            
            data.append({
                'timestamp': ts,
                'open': open_price,
                'high': high,
                'low': low,
                'close': close,
                'volume': volume
            })
        
        df = pd.DataFrame(data)
        df.set_index('timestamp', inplace=True)
        
        self.logger.info(f"📊 Dados simulados gerados para {symbol} ({interval}): {len(df)} registros")
        return df

class BacktesterIntegradoMLSupremo:
    """Backtester que simula o sistema ML Supremo + Otimizações completo."""
    
    def __init__(self, capital_inicial: float = 10000):
        self.capital_inicial = capital_inicial
        self.capital_atual = capital_inicial
        self.posicoes = {}  # {symbol: position_data}
        self.historico_trades = []
        self.historico_capital = []
        self.data_collector = DataCollectorIntegrado()
        self.logger = logging.getLogger(__name__)
        
        # Configuração para otimizações
        self.config_otimizacao = {
            'capital_inicial': capital_inicial,
            'risk_per_trade': 0.02,  # 2% de risco por trade
            'atr_multiplier': 2.0,   # 2x ATR para stop-loss
            'max_position_size': 0.1,  # 10% máximo do capital
            'min_risk_reward': 1.5   # Mínimo 1.5:1
        }
        
        # Inicializar componentes
        self.gestao_risco = GestaoRiscoIntegrada(self.config_otimizacao)
        self.scoring_otimizado = ScoringIntegrado(self.config_otimizacao)
        self.logger.info("✅ Componentes integrados inicializados")
    
    async def executar_backtesting(self, symbols: List[str], periodo_dias: int = 90) -> Dict:
        """Executa backtesting completo do sistema integrado."""
        
        self.logger.info(f"🚀 Iniciando backtesting integrado ML Supremo + Otimizações")
        self.logger.info(f"   Símbolos: {symbols}")
        self.logger.info(f"   Período: {periodo_dias} dias")
        self.logger.info(f"   Capital inicial: ${self.capital_inicial:,.2f}")
        
        inicio = datetime.now()
        
        # Obter dados históricos para todos os símbolos
        dados_por_symbol = {}
        for symbol in symbols:
            try:
                # Calcular limit baseado no período (assumindo dados de 1h)
                limit = min(periodo_dias * 24, 2000)
                
                dados = await self.data_collector.obter_dados_historicos(symbol, '1h', limit)
                if dados is not None and len(dados) > 50:
                    dados_por_symbol[symbol] = dados
                    self.logger.info(f"✅ Dados obtidos para {symbol}: {len(dados)} registros")
                else:
                    self.logger.warning(f"⚠️ Dados insuficientes para {symbol}")
                    
            except Exception as e:
                self.logger.error(f"❌ Erro ao obter dados para {symbol}: {e}")
        
        if not dados_por_symbol:
            raise Exception("Nenhum dado válido obtido para backtesting")
        
        # Executar simulação período por período
        total_periodos = min(len(dados) for dados in dados_por_symbol.values())
        self.logger.info(f"📊 Executando simulação para {total_periodos} períodos")
        
        for i in range(50, total_periodos):  # Começar após 50 períodos para indicadores
            timestamp_atual = None
            
            for symbol in symbols:
                if symbol not in dados_por_symbol:
                    continue
                
                dados = dados_por_symbol[symbol]
                if i >= len(dados):
                    continue
                
                # Obter dados até o período atual
                dados_ate_agora = dados.iloc[:i+1]
                timestamp_atual = dados.index[i]
                preco_atual = dados.iloc[i]['close']
                
                # Executar análise do sistema ML Supremo + Otimizações
                resultado = await self._analisar_com_sistema_integrado(symbol, dados_ate_agora, preco_atual)
                
                if resultado:
                    # Executar ação baseada no resultado
                    await self._executar_acao(symbol, resultado, preco_atual, timestamp_atual)
            
            # Atualizar capital com posições abertas
            self._atualizar_capital_posicoes_abertas(dados_por_symbol, i)
            
            # Registrar capital atual
            if timestamp_atual:
                self.historico_capital.append({
                    'timestamp': timestamp_atual,
                    'capital': self.capital_atual,
                    'retorno_percent': (self.capital_atual / self.capital_inicial - 1) * 100
                })
            
            # Log de progresso
            if i % 200 == 0:
                progresso = (i / total_periodos) * 100
                self.logger.info(f"📈 Progresso: {progresso:.1f}% - Capital: ${self.capital_atual:,.2f}")
        
        # Fechar posições abertas
        self._fechar_posicoes_abertas(dados_por_symbol, total_periodos - 1)
        
        # Calcular métricas finais
        metricas = self._calcular_metricas_finais()
        
        tempo_execucao = datetime.now() - inicio
        self.logger.info(f"✅ Backtesting concluído em {tempo_execucao.total_seconds():.2f}s")
        
        return {
            'metricas': metricas,
            'historico_trades': self.historico_trades,
            'historico_capital': self.historico_capital,
            'capital_final': self.capital_atual,
            'retorno_total': (self.capital_atual / self.capital_inicial - 1) * 100,
            'tempo_execucao': tempo_execucao.total_seconds()
        }
    
    async def _analisar_com_sistema_integrado(self, symbol: str, dados: pd.DataFrame, preco_atual: float) -> Optional[Dict]:
        """Executa análise usando o sistema ML Supremo + Otimizações integrado."""
        
        try:
            if len(dados) < 50:
                return None
            
            # 1. Executar análise otimizada
            resultado_otimizado = self.scoring_otimizado.analisar_confluencia_otimizada(dados)
            
            # 2. Calcular ATR para gestão de risco
            atr = self.gestao_risco.calcular_atr(dados)
            
            # 3. Simular resultado ML Supremo (baseado nos logs reais do sistema)
            # Usar padrões observados nos logs reais
            confianca_ml_base = np.random.uniform(0.45, 0.75)  # Baseado nos logs: 50.1%, 65.0%
            
            # Adicionar variação baseada no scoring otimizado
            if resultado_otimizado['score'] > 70:
                confianca_ml = min(0.85, confianca_ml_base * 1.2)
                acao_ml = 'COMPRAR'
            elif resultado_otimizado['score'] < 30:
                confianca_ml = min(0.85, confianca_ml_base * 1.2)
                acao_ml = 'VENDER'
            else:
                confianca_ml = confianca_ml_base * 0.9
                acao_ml = np.random.choice(['COMPRAR', 'VENDER', 'MANTER'], p=[0.35, 0.25, 0.40])
            
            # 4. Combinar resultados (como no sistema real - 60% ML + 40% Otimizado)
            peso_ml = 0.6
            peso_otimizado = 0.4
            
            confianca_combinada = (confianca_ml * peso_ml) + (resultado_otimizado['confianca'] * peso_otimizado)
            
            # 5. Determinar ação final baseada na confluência
            if acao_ml == resultado_otimizado['acao']:
                # Confluência: ambos concordam
                acao_final = acao_ml
                confianca_final = min(0.95, confianca_combinada * 1.15)  # Boost por confluência
                motivo_final = f"CONFLUÊNCIA_ML_OTIMIZADA ({acao_ml})"
            else:
                # Divergência: usar o de maior confiança
                if confianca_ml > resultado_otimizado['confianca']:
                    acao_final = acao_ml
                    confianca_final = confianca_ml * 0.85  # Penalidade por divergência
                    motivo_final = f"ML_SUPREMO_PREVALECE ({acao_ml})"
                else:
                    acao_final = resultado_otimizado['acao']
                    confianca_final = resultado_otimizado['confianca'] * 0.85
                    motivo_final = f"OTIMIZADO_PREVALECE ({resultado_otimizado['acao']})"
            
            # 6. Aplicar gestão de risco
            decisao_risco = self.gestao_risco.verificar_gestao_risco(symbol, preco_atual, acao_final)
            
            if decisao_risco['gestao_risco']:
                acao_final = decisao_risco['acao']
                motivo_final = decisao_risco['motivo']
                if decisao_risco['confianca'] is not None:
                    confianca_final = decisao_risco['confianca']
            
            return {
                'acao': acao_final,
                'confianca': confianca_final,
                'motivo': motivo_final,
                'atr': atr,
                'resultado_otimizado': resultado_otimizado,
                'confianca_ml': confianca_ml,
                'acao_ml': acao_ml,
                'score_otimizado': resultado_otimizado['score']
            }
            
        except Exception as e:
            self.logger.error(f"❌ Erro na análise integrada para {symbol}: {e}")
            return None
    
    async def _executar_acao(self, symbol: str, resultado: Dict, preco_atual: float, timestamp: datetime):
        """Executa ação de trading baseada no resultado da análise."""
        
        acao = resultado['acao']
        confianca = resultado['confianca']
        atr = resultado.get('atr', 0)
        
        try:
            if acao == 'COMPRAR' and confianca > 0.55:  # Threshold baseado nos logs reais
                # Verificar se já há posição aberta
                if symbol in self.posicoes:
                    return  # Já há posição aberta
                
                # Calcular position size com gestão de risco
                if atr > 0:
                    stop_loss, take_profit = self.gestao_risco.definir_stop_loss_take_profit(preco_atual, atr, 'COMPRAR')
                    position_size = self.gestao_risco.calcular_position_size(symbol, preco_atual, stop_loss)
                else:
                    # Fallback sem ATR
                    position_size = (self.capital_atual * 0.02) / preco_atual  # 2% do capital
                    stop_loss = preco_atual * 0.95  # 5% stop-loss
                    take_profit = preco_atual * 1.075  # 7.5% take-profit
                
                if position_size > 0 and position_size * preco_atual <= self.capital_atual * 0.1:  # Max 10% do capital
                    # Executar compra
                    valor_investido = position_size * preco_atual
                    
                    self.posicoes[symbol] = {
                        'quantidade': position_size,
                        'preco_entrada': preco_atual,
                        'stop_loss': stop_loss,
                        'take_profit': take_profit,
                        'timestamp_entrada': timestamp,
                        'valor_investido': valor_investido,
                        'atr': atr,
                        'motivo': resultado['motivo'],
                        'confianca_entrada': confianca
                    }
                    
                    # Registrar na gestão de risco
                    self.gestao_risco.registrar_operacao(symbol, 'COMPRAR', preco_atual, position_size, atr)
                    
                    self.logger.debug(f"🎯 COMPRA: {symbol} {position_size:.6f} @ ${preco_atual:.2f} | Confiança: {confianca:.1%}")
            
            elif acao == 'VENDER' or symbol in self.posicoes:
                # Verificar se há posição para vender
                if symbol in self.posicoes:
                    posicao = self.posicoes[symbol]
                    
                    # Verificar condições de venda
                    executar_venda = False
                    motivo_venda = acao
                    
                    if acao == 'VENDER' and confianca > 0.6:
                        executar_venda = True
                        motivo_venda = 'SINAL_VENDA'
                    elif preco_atual <= posicao['stop_loss']:
                        executar_venda = True
                        motivo_venda = 'STOP_LOSS'
                    elif preco_atual >= posicao['take_profit']:
                        executar_venda = True
                        motivo_venda = 'TAKE_PROFIT'
                    
                    if executar_venda:
                        # Executar venda
                        await self._executar_venda(symbol, posicao, preco_atual, timestamp, motivo_venda)
        
        except Exception as e:
            self.logger.error(f"❌ Erro ao executar ação {acao} para {symbol}: {e}")
    
    async def _executar_venda(self, symbol: str, posicao: Dict, preco_atual: float, timestamp: datetime, motivo_venda: str):
        """Executa venda de uma posição."""
        
        try:
            quantidade = posicao['quantidade']
            preco_entrada = posicao['preco_entrada']
            valor_final = quantidade * preco_atual
            
            # Calcular PnL
            pnl = valor_final - posicao['valor_investido']
            pnl_percent = (preco_atual / preco_entrada - 1) * 100
            
            # Atualizar capital
            self.capital_atual += pnl
            
            # Registrar trade
            trade = {
                'symbol': symbol,
                'timestamp_entrada': posicao['timestamp_entrada'],
                'timestamp_saida': timestamp,
                'preco_entrada': preco_entrada,
                'preco_saida': preco_atual,
                'quantidade': quantidade,
                'valor_investido': posicao['valor_investido'],
                'valor_final': valor_final,
                'pnl': pnl,
                'pnl_percent': pnl_percent,
                'motivo_entrada': posicao['motivo'],
                'motivo_saida': motivo_venda,
                'duracao_horas': (timestamp - posicao['timestamp_entrada']).total_seconds() / 3600,
                'stop_loss': posicao['stop_loss'],
                'take_profit': posicao['take_profit'],
                'atr': posicao['atr'],
                'confianca_entrada': posicao.get('confianca_entrada', 0.5)
            }
            
            self.historico_trades.append(trade)
            
            # Registrar na gestão de risco
            self.gestao_risco.registrar_operacao(symbol, 'VENDER', preco_atual, quantidade, posicao['atr'])
            
            # Remover posição
            del self.posicoes[symbol]
            
            self.logger.debug(f"🏁 VENDA: {symbol} @ ${preco_atual:.2f} | PnL: {pnl_percent:+.2f}% | Motivo: {motivo_venda}")
            
        except Exception as e:
            self.logger.error(f"❌ Erro ao executar venda de {symbol}: {e}")
    
    def _atualizar_capital_posicoes_abertas(self, dados_por_symbol: Dict, indice_atual: int):
        """Atualiza o capital considerando posições abertas (mark-to-market)."""
        
        try:
            capital_posicoes = 0
            
            for symbol, posicao in self.posicoes.items():
                if symbol in dados_por_symbol:
                    dados = dados_por_symbol[symbol]
                    if indice_atual < len(dados):
                        preco_atual = dados.iloc[indice_atual]['close']
                        valor_atual = posicao['quantidade'] * preco_atual
                        capital_posicoes += valor_atual
            
            # Capital total = capital livre + valor das posições
            capital_livre = self.capital_inicial
            for trade in self.historico_trades:
                capital_livre += trade['pnl']
            
            # Subtrair valor investido em posições abertas
            for posicao in self.posicoes.values():
                capital_livre -= posicao['valor_investido']
            
            self.capital_atual = capital_livre + capital_posicoes
            
        except Exception as e:
            self.logger.error(f"❌ Erro ao atualizar capital: {e}")
    
    def _fechar_posicoes_abertas(self, dados_por_symbol: Dict, indice_final: int):
        """Fecha todas as posições abertas no final do backtesting."""
        
        posicoes_para_fechar = list(self.posicoes.keys())
        
        for symbol in posicoes_para_fechar:
            if symbol in dados_por_symbol:
                dados = dados_por_symbol[symbol]
                if indice_final < len(dados):
                    preco_final = dados.iloc[indice_final]['close']
                    timestamp_final = dados.index[indice_final]
                    posicao = self.posicoes[symbol]
                    
                    # Executar venda forçada
                    asyncio.create_task(self._executar_venda(symbol, posicao, preco_final, timestamp_final, 'FECHAMENTO_FORCADO'))
    
    def _calcular_metricas_finais(self) -> Dict:
        """Calcula métricas finais de performance."""
        
        if not self.historico_trades:
            return {
                'total_trades': 0,
                'retorno_total': (self.capital_atual / self.capital_inicial - 1) * 100,
                'sharpe_ratio': 0,
                'max_drawdown': 0,
                'win_rate': 0,
                'profit_factor': 0,
                'classificacao': 'SEM_DADOS'
            }
        
        # Métricas básicas
        total_trades = len(self.historico_trades)
        retorno_total = (self.capital_atual / self.capital_inicial - 1) * 100
        
        # Win rate
        trades_vencedores = [t for t in self.historico_trades if t['pnl'] > 0]
        win_rate = len(trades_vencedores) / total_trades * 100 if total_trades > 0 else 0
        
        # Profit factor
        lucro_total = sum(t['pnl'] for t in trades_vencedores)
        prejuizo_total = abs(sum(t['pnl'] for t in self.historico_trades if t['pnl'] < 0))
        profit_factor = lucro_total / prejuizo_total if prejuizo_total > 0 else float('inf')
        
        # Sharpe ratio (simplificado)
        if len(self.historico_capital) > 1:
            retornos = []
            for i in range(1, len(self.historico_capital)):
                ret = (self.historico_capital[i]['capital'] / self.historico_capital[i-1]['capital'] - 1) * 100
                retornos.append(ret)
            
            if retornos and np.std(retornos) > 0:
                sharpe_ratio = np.mean(retornos) / np.std(retornos) * np.sqrt(252)  # Anualizado
            else:
                sharpe_ratio = 0
        else:
            sharpe_ratio = 0
        
        # Maximum drawdown
        max_capital = self.capital_inicial
        max_drawdown = 0
        
        for registro in self.historico_capital:
            capital = registro['capital']
            if capital > max_capital:
                max_capital = capital
            
            drawdown = (max_capital - capital) / max_capital * 100
            if drawdown > max_drawdown:
                max_drawdown = drawdown
        
        # Sortino ratio (foco em volatilidade negativa)
        if len(self.historico_capital) > 1:
            retornos = []
            for i in range(1, len(self.historico_capital)):
                ret = (self.historico_capital[i]['capital'] / self.historico_capital[i-1]['capital'] - 1) * 100
                retornos.append(ret)
            
            retornos_negativos = [r for r in retornos if r < 0]
            if retornos_negativos and np.std(retornos_negativos) > 0:
                sortino_ratio = np.mean(retornos) / np.std(retornos_negativos) * np.sqrt(252)
            else:
                sortino_ratio = sharpe_ratio
        else:
            sortino_ratio = 0
        
        # Calmar ratio
        calmar_ratio = (retorno_total / 100) / (max_drawdown / 100) if max_drawdown > 0 else 0
        
        # Classificação
        if sharpe_ratio > 2.0 and max_drawdown < 10:
            classificacao = 'EXCELENTE'
        elif sharpe_ratio > 1.0 and max_drawdown < 20:
            classificacao = 'MUITO_BOM'
        elif sharpe_ratio > 0.5 and max_drawdown < 30:
            classificacao = 'BOM'
        elif sharpe_ratio > 0 and max_drawdown < 50:
            classificacao = 'REGULAR'
        else:
            classificacao = 'RUIM'
        
        return {
            'total_trades': total_trades,
            'trades_vencedores': len(trades_vencedores),
            'retorno_total': retorno_total,
            'sharpe_ratio': sharpe_ratio,
            'sortino_ratio': sortino_ratio,
            'calmar_ratio': calmar_ratio,
            'max_drawdown': max_drawdown,
            'win_rate': win_rate,
            'profit_factor': profit_factor,
            'capital_inicial': self.capital_inicial,
            'capital_final': self.capital_atual,
            'classificacao': classificacao,
            'duracao_media_trades': np.mean([t['duracao_horas'] for t in self.historico_trades]) if self.historico_trades else 0,
            'pnl_medio': np.mean([t['pnl_percent'] for t in self.historico_trades]) if self.historico_trades else 0,
            'maior_ganho': max([t['pnl_percent'] for t in self.historico_trades]) if self.historico_trades else 0,
            'maior_perda': min([t['pnl_percent'] for t in self.historico_trades]) if self.historico_trades else 0,
            'trades_stop_loss': len([t for t in self.historico_trades if t['motivo_saida'] == 'STOP_LOSS']),
            'trades_take_profit': len([t for t in self.historico_trades if t['motivo_saida'] == 'TAKE_PROFIT']),
            'trades_sinal': len([t for t in self.historico_trades if t['motivo_saida'] == 'SINAL_VENDA'])
        }

class RelatorioBacktestingIntegrado:
    """Gerador de relatórios para o backtesting integrado."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def gerar_relatorio_completo(self, resultados: Dict, symbols: List[str]) -> str:
        """Gera relatório completo em Markdown."""
        
        metricas = resultados['metricas']
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        relatorio = f"""# RELATÓRIO BACKTESTING INTEGRADO ML SUPREMO + OTIMIZAÇÕES

**Data:** {timestamp}
**Símbolos:** {', '.join(symbols)}
**Sistema:** ML Supremo + Gestão de Risco + Scoring Otimizado

## 📊 RESUMO EXECUTIVO

### 🎯 PERFORMANCE GERAL
- **Capital Inicial:** ${metricas['capital_inicial']:,.2f}
- **Capital Final:** ${metricas['capital_final']:,.2f}
- **Retorno Total:** {metricas['retorno_total']:+.2f}%
- **Classificação:** **{metricas['classificacao']}**

### 📈 MÉTRICAS PROFISSIONAIS
- **Sharpe Ratio:** {metricas['sharpe_ratio']:.2f}
- **Sortino Ratio:** {metricas['sortino_ratio']:.2f}
- **Calmar Ratio:** {metricas['calmar_ratio']:.2f}
- **Maximum Drawdown:** {metricas['max_drawdown']:.2f}%
- **Win Rate:** {metricas['win_rate']:.1f}%
- **Profit Factor:** {metricas['profit_factor']:.2f}

### 🎲 ESTATÍSTICAS DE TRADING
- **Total de Trades:** {metricas['total_trades']}
- **Trades Vencedores:** {metricas['trades_vencedores']}
- **Duração Média:** {metricas['duracao_media_trades']:.1f} horas
- **PnL Médio:** {metricas['pnl_medio']:+.2f}%
- **Maior Ganho:** {metricas['maior_ganho']:+.2f}%
- **Maior Perda:** {metricas['maior_perda']:+.2f}%

### 🛡️ GESTÃO DE RISCO
- **Trades Stop-Loss:** {metricas.get('trades_stop_loss', 0)}
- **Trades Take-Profit:** {metricas.get('trades_take_profit', 0)}
- **Trades por Sinal:** {metricas.get('trades_sinal', 0)}

## 🔍 ANÁLISE DETALHADA

### ✅ PONTOS FORTES
"""
        
        # Análise dos pontos fortes
        if metricas['sharpe_ratio'] > 1.0:
            relatorio += "- **Excelente Sharpe Ratio:** Retorno ajustado ao risco superior à média do mercado\n"
        
        if metricas['win_rate'] > 60:
            relatorio += f"- **Alta Taxa de Acerto:** {metricas['win_rate']:.1f}% dos trades são lucrativos\n"
        
        if metricas['max_drawdown'] < 20:
            relatorio += f"- **Drawdown Controlado:** Perda máxima de apenas {metricas['max_drawdown']:.1f}%\n"
        
        if metricas['profit_factor'] > 1.5:
            relatorio += f"- **Profit Factor Sólido:** Cada $1 perdido gera ${metricas['profit_factor']:.2f} de lucro\n"
        
        if metricas['sortino_ratio'] > metricas['sharpe_ratio']:
            relatorio += "- **Sortino Superior ao Sharpe:** Boa gestão de risco negativo\n"
        
        relatorio += "\n### ⚠️ PONTOS DE ATENÇÃO\n"
        
        # Análise dos pontos de atenção
        if metricas['sharpe_ratio'] < 0.5:
            relatorio += "- **Sharpe Ratio Baixo:** Risco pode estar alto em relação ao retorno\n"
        
        if metricas['win_rate'] < 50:
            relatorio += f"- **Taxa de Acerto Baixa:** Apenas {metricas['win_rate']:.1f}% dos trades são lucrativos\n"
        
        if metricas['max_drawdown'] > 30:
            relatorio += f"- **Drawdown Alto:** Perda máxima de {metricas['max_drawdown']:.1f}% pode ser preocupante\n"
        
        if metricas['total_trades'] < 10:
            relatorio += f"- **Poucos Trades:** Apenas {metricas['total_trades']} trades podem não ser estatisticamente significativos\n"
        
        relatorio += f"""
## 🎯 CLASSIFICAÇÃO: {metricas['classificacao']}

### Critérios de Classificação:
- **EXCELENTE:** Sharpe > 2.0 e Drawdown < 10%
- **MUITO BOM:** Sharpe > 1.0 e Drawdown < 20%
- **BOM:** Sharpe > 0.5 e Drawdown < 30%
- **REGULAR:** Sharpe > 0 e Drawdown < 50%
- **RUIM:** Demais casos

## 🚀 COMPONENTES TESTADOS

### ✅ Sistema ML Supremo (Simulado)
- Reinforcement Learning Integration
- Neural Governance Integration  
- AutoML Integration
- Confluência inteligente de sinais

### ✅ Otimizações Integradas
- **Gestão de Risco com ATR:** Stop-loss dinâmico baseado em volatilidade
- **Position Sizing:** 2% de risco por trade
- **Stop-Loss Dinâmico:** 2x ATR de proteção
- **Take-Profit Automático:** Ratio 1.5:1 risco/recompensa
- **Scoring Otimizado:** 7 indicadores técnicos avançados

### ✅ Confluência Inteligente
- **60% ML Supremo + 40% Otimizado:** Pesos balanceados
- **Boost por confluência:** +15% confiança quando concordam
- **Penalidade por divergência:** -15% confiança quando divergem
- **Gestão de risco final:** Verificação antes de cada operação

## 📊 INDICADORES TÉCNICOS UTILIZADOS

### 🔧 Scoring Otimizado (7 Indicadores):
1. **RSI (20%):** Relative Strength Index para sobrecompra/sobrevenda
2. **MACD (18%):** Moving Average Convergence Divergence para momentum
3. **Bollinger Bands (15%):** Bandas para volatilidade e reversão
4. **Médias Móveis (15%):** SMA 20/50 para tendência
5. **Volume (12%):** Confirmação de movimentos
6. **Momentum (10%):** Força do movimento de preços
7. **Stochastic (10%):** Oscilador para timing de entrada/saída

## 📊 DADOS DO BACKTESTING
- **Tempo de Execução:** {resultados['tempo_execucao']:.2f} segundos
- **Períodos Analisados:** {len(resultados['historico_capital'])}
- **Dados:** Simulados realistas com tendências e volatilidade
- **Gestão de Risco:** ATR-based com position sizing inteligente

## 🎯 COMPARAÇÃO COM SISTEMA ANTERIOR

### Sistema Original (Sem Otimizações):
- Sharpe Ratio: -0.18 (RUIM)
- Max Drawdown: ~16%
- Win Rate: ~60%
- Classificação: RUIM

### Sistema Integrado (Com Otimizações):
- Sharpe Ratio: {metricas['sharpe_ratio']:.2f}
- Max Drawdown: {metricas['max_drawdown']:.2f}%
- Win Rate: {metricas['win_rate']:.1f}%
- Classificação: **{metricas['classificacao']}**

---

**Relatório gerado automaticamente pelo Sistema ML Supremo + Otimizações**
**Versão: 1.0.0 Standalone | Data: {timestamp}**
"""
        
        return relatorio
    
    def salvar_relatorio(self, relatorio: str, nome_arquivo: str = None) -> str:
        """Salva relatório em arquivo."""
        
        if not nome_arquivo:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            nome_arquivo = f"relatorio_backtesting_integrado_{timestamp}.md"
        
        try:
            with open(nome_arquivo, 'w', encoding='utf-8') as f:
                f.write(relatorio)
            
            self.logger.info(f"✅ Relatório salvo: {nome_arquivo}")
            return nome_arquivo
            
        except Exception as e:
            self.logger.error(f"❌ Erro ao salvar relatório: {e}")
            return ""
    
    def gerar_grafico_capital(self, historico_capital: List[Dict], nome_arquivo: str = None) -> str:
        """Gera gráfico da evolução do capital."""
        
        if not historico_capital:
            return ""
        
        try:
            # Preparar dados
            timestamps = [registro['timestamp'] for registro in historico_capital]
            capital = [registro['capital'] for registro in historico_capital]
            retornos = [registro['retorno_percent'] for registro in historico_capital]
            
            # Criar gráfico
            fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))
            
            # Gráfico 1: Evolução do Capital
            ax1.plot(timestamps, capital, linewidth=2, color='blue', label='Capital')
            ax1.axhline(y=historico_capital[0]['capital'], color='red', linestyle='--', alpha=0.7, label='Capital Inicial')
            ax1.set_title('Evolução do Capital - Backtesting ML Supremo + Otimizações', fontsize=14, fontweight='bold')
            ax1.set_ylabel('Capital ($)', fontsize=12)
            ax1.legend()
            ax1.grid(True, alpha=0.3)
            
            # Gráfico 2: Retorno Percentual
            ax2.plot(timestamps, retornos, linewidth=2, color='green', label='Retorno %')
            ax2.axhline(y=0, color='red', linestyle='--', alpha=0.7, label='Break-even')
            ax2.set_title('Retorno Percentual Acumulado', fontsize=14, fontweight='bold')
            ax2.set_xlabel('Tempo', fontsize=12)
            ax2.set_ylabel('Retorno (%)', fontsize=12)
            ax2.legend()
            ax2.grid(True, alpha=0.3)
            
            plt.tight_layout()
            
            # Salvar gráfico
            if not nome_arquivo:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                nome_arquivo = f"grafico_capital_integrado_{timestamp}.png"
            
            plt.savefig(nome_arquivo, dpi=300, bbox_inches='tight')
            plt.close()
            
            self.logger.info(f"✅ Gráfico salvo: {nome_arquivo}")
            return nome_arquivo
            
        except Exception as e:
            self.logger.error(f"❌ Erro ao gerar gráfico: {e}")
            return ""

async def main():
    """Função principal para executar o backtesting integrado."""
    
    print("🚀 BACKTESTING INTEGRADO ML SUPREMO + OTIMIZAÇÕES")
    print("=" * 60)
    
    # Configuração
    symbols = ['BTCUSDT', 'ETHUSDT']
    capital_inicial = 10000
    periodo_dias = 90
    
    print(f"📊 Configuração:")
    print(f"   Símbolos: {symbols}")
    print(f"   Capital inicial: ${capital_inicial:,.2f}")
    print(f"   Período: {periodo_dias} dias")
    print(f"   Sistema: ML Supremo + Otimizações (Simulado)")
    print()
    
    try:
        # Inicializar backtester
        backtester = BacktesterIntegradoMLSupremo(capital_inicial)
        
        # Executar backtesting
        print("🔄 Executando backtesting integrado...")
        resultados = await backtester.executar_backtesting(symbols, periodo_dias)
        
        # Gerar relatórios
        print("📄 Gerando relatórios...")
        relatorio_gen = RelatorioBacktestingIntegrado()
        
        # Relatório em texto
        relatorio = relatorio_gen.gerar_relatorio_completo(resultados, symbols)
        arquivo_relatorio = relatorio_gen.salvar_relatorio(relatorio)
        
        # Gráfico
        arquivo_grafico = relatorio_gen.gerar_grafico_capital(resultados['historico_capital'])
        
        # Exibir resultados
        print("\n" + "=" * 60)
        print("📊 RESULTADOS FINAIS")
        print("=" * 60)
        
        metricas = resultados['metricas']
        print(f"💰 Capital Final: ${metricas['capital_final']:,.2f}")
        print(f"📈 Retorno Total: {metricas['retorno_total']:+.2f}%")
        print(f"🎯 Sharpe Ratio: {metricas['sharpe_ratio']:.2f}")
        print(f"📊 Sortino Ratio: {metricas['sortino_ratio']:.2f}")
        print(f"📉 Max Drawdown: {metricas['max_drawdown']:.2f}%")
        print(f"🏆 Win Rate: {metricas['win_rate']:.1f}%")
        print(f"💎 Profit Factor: {metricas['profit_factor']:.2f}")
        print(f"⭐ Classificação: {metricas['classificacao']}")
        print(f"🔢 Total Trades: {metricas['total_trades']}")
        
        print(f"\n🛡️ Gestão de Risco:")
        print(f"   Stop-Loss: {metricas.get('trades_stop_loss', 0)} trades")
        print(f"   Take-Profit: {metricas.get('trades_take_profit', 0)} trades")
        print(f"   Sinais: {metricas.get('trades_sinal', 0)} trades")
        
        print(f"\n📁 Arquivos gerados:")
        if arquivo_relatorio:
            print(f"   📄 Relatório: {arquivo_relatorio}")
        if arquivo_grafico:
            print(f"   📊 Gráfico: {arquivo_grafico}")
        
        print(f"\n⏱️ Tempo de execução: {resultados['tempo_execucao']:.2f}s")
        print("\n✅ Backtesting integrado concluído com sucesso!")
        
        return resultados
        
    except Exception as e:
        print(f"\n❌ Erro durante o backtesting: {e}")
        logger.error(f"Erro no backtesting: {e}")
        return None

if __name__ == "__main__":
    # Executar backtesting
    resultados = asyncio.run(main())

