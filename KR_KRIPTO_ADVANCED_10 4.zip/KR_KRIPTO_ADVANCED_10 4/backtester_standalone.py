# -*- coding: utf-8 -*-
"""
Backtester Standalone - Simulação do Sistema ML Supremo

Este módulo simula o comportamento do sistema ML Supremo para backtesting.

Autor: Manus AI
Data: 30/08/2025
Versão: 1.0.0
"""

import logging
import pandas as pd
import numpy as np
from typing import Dict, List, Any

class MLSupremoSimulator:
    """
    Simula o comportamento do Sistema ML Supremo para backtesting.
    """

    def __init__(self, config: Dict):
        """
        Inicializa o simulador ML Supremo.
        """
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Parâmetros da estratégia simulada
        self.rsi_period = 14
        self.ma_short = 20
        self.ma_long = 50
        self.limiar_compra = 0.6
        self.limiar_venda = 0.4

    def analisar_em_backtesting(self, dados_historicos: pd.DataFrame) -> Dict:
        """
        Simula a análise do ML Supremo para um ponto no tempo.
        
        Args:
            dados_historicos (pd.DataFrame): Dados históricos até o momento atual
            
        Returns:
            Dict: Decisão de trading simulada
        """
        if len(dados_historicos) < self.ma_long:
            return {'acao': 'AGUARDAR', 'confianca': 0.0, 'score': 0}

        # Calcular indicadores técnicos
        close_prices = dados_historicos['close']
        
        # RSI
        rsi = self._calculate_rsi(close_prices, self.rsi_period)
        
        # Médias móveis
        ma_short = close_prices.rolling(window=self.ma_short).mean()
        ma_long = close_prices.rolling(window=self.ma_long).mean()
        
        # MACD
        macd_line, macd_signal = self._calculate_macd(close_prices)
        
        # Volume
        volume_ma = dados_historicos['volume'].rolling(window=20).mean()
        volume_ratio = dados_historicos['volume'].iloc[-1] / volume_ma.iloc[-1]
        
        # Calcular score baseado nos indicadores
        score = 0
        signals = []
        
        # RSI signals
        current_rsi = rsi.iloc[-1]
        if current_rsi < 30:  # Oversold
            score += 2
            signals.append("RSI_OVERSOLD")
        elif current_rsi > 70:  # Overbought
            score -= 2
            signals.append("RSI_OVERBOUGHT")
        
        # MA signals
        if ma_short.iloc[-1] > ma_long.iloc[-1]:  # Bullish trend
            score += 1
            signals.append("MA_BULLISH")
        else:  # Bearish trend
            score -= 1
            signals.append("MA_BEARISH")
        
        # MACD signals
        if macd_line.iloc[-1] > macd_signal.iloc[-1]:  # MACD bullish
            score += 1
            signals.append("MACD_BULLISH")
        else:  # MACD bearish
            score -= 1
            signals.append("MACD_BEARISH")
        
        # Volume confirmation
        if volume_ratio > 1.5:  # High volume
            score += 1
            signals.append("VOLUME_HIGH")
        
        # Adicionar alguma aleatoriedade para simular ML
        np.random.seed(int(dados_historicos.index[-1].timestamp()) % 1000)
        ml_adjustment = np.random.normal(0, 0.5)
        score += ml_adjustment
        
        # Normalizar score para confiança (0-1)
        max_score = 6
        normalized_score = (score + max_score) / (2 * max_score)
        confianca = max(0.1, min(0.9, normalized_score))
        
        # Determinar ação
        if confianca >= self.limiar_compra:
            acao = 'COMPRAR'
        elif confianca <= self.limiar_venda:
            acao = 'VENDER'
        else:
            acao = 'AGUARDAR'
        
        return {
            'acao': acao,
            'confianca': confianca,
            'score': score,
            'signals': signals,
            'rsi': current_rsi,
            'ma_trend': 'BULLISH' if ma_short.iloc[-1] > ma_long.iloc[-1] else 'BEARISH'
        }

    def _calculate_rsi(self, prices: pd.Series, period: int = 14) -> pd.Series:
        """Calcula o RSI."""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return rsi

    def _calculate_macd(self, prices: pd.Series, fast=12, slow=26, signal=9):
        """Calcula o MACD."""
        ema_fast = prices.ewm(span=fast).mean()
        ema_slow = prices.ewm(span=slow).mean()
        macd_line = ema_fast - ema_slow
        macd_signal = macd_line.ewm(span=signal).mean()
        return macd_line, macd_signal

class BacktesterStandalone:
    """
    Backtester independente com simulador ML Supremo integrado.
    """

    def __init__(self, config: Dict):
        """
        Inicializa o backtester standalone.
        """
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.capital_inicial = config.get('capital_inicial', 10000)
        self.custo_operacao = config.get('custo_operacao', 0.001)
        
        # Inicializar simulador ML
        self.ml_simulator = MLSupremoSimulator(config)
        self.logger.info("✅ Backtester Standalone inicializado com simulador ML")

    def run(self, dados_historicos: pd.DataFrame) -> Dict:
        """
        Executa o backtesting com dados históricos.
        """
        self.logger.info(f"🚀 Iniciando backtesting com {len(dados_historicos)} registros")
        
        # Inicializar estado do portfólio
        capital = self.capital_inicial
        posicao = 0.0
        historico_capital = [self.capital_inicial]
        trades = []
        
        # Variáveis para tracking
        total_compras = 0
        total_vendas = 0
        
        # Loop principal do backtesting
        for i in range(50, len(dados_historicos)):  # Começar após período de aquecimento
            # Dados até o momento atual
            dados_ate_agora = dados_historicos.iloc[:i+1]
            
            # Obter decisão do ML Supremo simulado
            decisao = self.ml_simulator.analisar_em_backtesting(dados_ate_agora)
            
            preco_atual = dados_historicos.iloc[i]['close']
            timestamp_atual = dados_historicos.index[i]
            
            # Executar ordens baseadas na decisão
            if decisao['acao'] == 'COMPRAR' and capital > 100:  # Mínimo para compra
                # Comprar com todo o capital disponível
                valor_compra = capital * (1 - self.custo_operacao)
                quantidade_comprada = valor_compra / preco_atual
                posicao += quantidade_comprada
                capital = 0.0
                
                trades.append({
                    'tipo': 'COMPRA',
                    'preco': preco_atual,
                    'quantidade': quantidade_comprada,
                    'valor': valor_compra,
                    'timestamp': timestamp_atual,
                    'index': i,
                    'confianca': decisao['confianca'],
                    'signals': decisao['signals']
                })
                total_compras += 1
                
            elif decisao['acao'] == 'VENDER' and posicao > 0:
                # Vender toda a posição
                valor_venda = posicao * preco_atual * (1 - self.custo_operacao)
                capital += valor_venda
                
                trades.append({
                    'tipo': 'VENDA',
                    'preco': preco_atual,
                    'quantidade': posicao,
                    'valor': valor_venda,
                    'timestamp': timestamp_atual,
                    'index': i,
                    'confianca': decisao['confianca'],
                    'signals': decisao['signals']
                })
                total_vendas += 1
                posicao = 0.0
            
            # Calcular valor atual do portfólio
            valor_portfolio = capital + (posicao * preco_atual)
            historico_capital.append(valor_portfolio)
        
        # Fechar posição final se necessário
        if posicao > 0:
            preco_final = dados_historicos.iloc[-1]['close']
            valor_final = posicao * preco_final * (1 - self.custo_operacao)
            capital += valor_final
            
            trades.append({
                'tipo': 'VENDA_FINAL',
                'preco': preco_final,
                'quantidade': posicao,
                'valor': valor_final,
                'timestamp': dados_historicos.index[-1],
                'index': len(dados_historicos) - 1,
                'confianca': 1.0,
                'signals': ['CLOSE_POSITION']
            })
            posicao = 0.0
        
        capital_final = capital + (posicao * dados_historicos.iloc[-1]['close'])
        
        self.logger.info(f"✅ Backtesting concluído:")
        self.logger.info(f"   Capital inicial: ${self.capital_inicial:,.2f}")
        self.logger.info(f"   Capital final: ${capital_final:,.2f}")
        self.logger.info(f"   Total de trades: {len(trades)}")
        self.logger.info(f"   Compras: {total_compras}, Vendas: {total_vendas}")
        
        return {
            'capital_inicial': self.capital_inicial,
            'capital_final': capital_final,
            'historico_capital': historico_capital,
            'trades': trades,
            'total_compras': total_compras,
            'total_vendas': total_vendas,
            'periodo_dias': len(dados_historicos),
            'sucesso': True
        }

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    print("🚀 Testando Backtester Standalone...")
    
    # Configuração de teste
    config_teste = {
        'capital_inicial': 10000,
        'custo_operacao': 0.001
    }
    
    # Dados de exemplo
    dates = pd.date_range(start='2024-01-01', periods=200, freq='1H')
    np.random.seed(42)
    
    # Gerar dados sintéticos mais realistas
    base_price = 50000
    prices = [base_price]
    volumes = []
    
    for i in range(1, len(dates)):
        # Movimento browniano com tendência
        change = np.random.normal(0.0001, 0.02)
        new_price = prices[-1] * (1 + change)
        prices.append(new_price)
        volumes.append(np.random.uniform(1000, 5000))
    
    volumes.append(np.random.uniform(1000, 5000))  # Para o primeiro preço
    
    dados_teste = pd.DataFrame({
        'open': prices,
        'high': [p * (1 + np.random.uniform(0, 0.01)) for p in prices],
        'low': [p * (1 - np.random.uniform(0, 0.01)) for p in prices],
        'close': prices,
        'volume': volumes
    }, index=dates)
    
    # Executar teste
    backtester = BacktesterStandalone(config_teste)
    resultado = backtester.run(dados_teste)
    
    if resultado['sucesso']:
        retorno = (resultado['capital_final'] - resultado['capital_inicial']) / resultado['capital_inicial'] * 100
        print(f"\n📊 Resultado do teste:")
        print(f"   Retorno: {retorno:.2f}%")
        print(f"   Trades: {len(resultado['trades'])}")
        print(f"   Capital final: ${resultado['capital_final']:,.2f}")
    
    print("\n🎉 Backtester Standalone pronto!")

