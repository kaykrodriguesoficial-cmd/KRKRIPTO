#!/bin/bash
# Script de backup abrangente para o projeto KR_KRIPTO_ADVANCED_COPIA
# Implementa as recomendações de alta prioridade para backup e recuperação
# Autor: Manus AI
# Data: 16 de maio de 2025

# Configurações
PROJETO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_DIR="${PROJETO_DIR}/backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="${BACKUP_DIR}/kr_kripto_backup_${TIMESTAMP}.tar.gz"
LOG_FILE="${BACKUP_DIR}/backup_log_${TIMESTAMP}.log"
RETENTION_DAILY=7     # Dias para manter backups diários
RETENTION_WEEKLY=4    # Semanas para manter backups semanais
RETENTION_MONTHLY=12  # Meses para manter backups mensais

# Cores para saída
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para log
log() {
    local level=$1
    local message=$2
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    
    # Adicionar ao arquivo de log
    echo -e "${timestamp} - ${level} - ${message}" >> "${LOG_FILE}"
    
    # Exibir na tela com cores
    case ${level} in
        "INFO")
            echo -e "${BLUE}${timestamp} - INFO - ${message}${NC}"
            ;;
        "SUCCESS")
            echo -e "${GREEN}${timestamp} - SUCCESS - ${message}${NC}"
            ;;
        "WARNING")
            echo -e "${YELLOW}${timestamp} - WARNING - ${message}${NC}"
            ;;
        "ERROR")
            echo -e "${RED}${timestamp} - ERROR - ${message}${NC}"
            ;;
        *)
            echo -e "${timestamp} - ${level} - ${message}"
            ;;
    esac
}

# Função para verificar dependências
check_dependencies() {
    log "INFO" "Verificando dependências..."
    
    local missing_deps=0
    
    for cmd in tar gzip sha256sum find; do
        if ! command -v ${cmd} &> /dev/null; then
            log "ERROR" "Comando ${cmd} não encontrado. Por favor, instale-o."
            missing_deps=$((missing_deps + 1))
        fi
    done
    
    if [ ${missing_deps} -gt 0 ]; then
        log "ERROR" "${missing_deps} dependências não encontradas. Abortando."
        exit 1
    fi
    
    log "SUCCESS" "Todas as dependências estão instaladas."
}

# Função para criar diretório de backup
create_backup_dir() {
    log "INFO" "Criando diretório de backup: ${BACKUP_DIR}"
    
    if [ ! -d "${BACKUP_DIR}" ]; then
        mkdir -p "${BACKUP_DIR}"
        if [ $? -ne 0 ]; then
            log "ERROR" "Falha ao criar diretório de backup: ${BACKUP_DIR}"
            exit 1
        fi
        log "SUCCESS" "Diretório de backup criado com sucesso."
    else
        log "INFO" "Diretório de backup já existe."
    fi
    
    # Verificar permissões
    chmod 750 "${BACKUP_DIR}"
    log "INFO" "Permissões do diretório de backup ajustadas para 750 (rwxr-x---)."
}

# Função para criar backup
create_backup() {
    log "INFO" "Iniciando backup do projeto: ${PROJETO_DIR}"
    log "INFO" "Arquivo de backup: ${BACKUP_FILE}"
    
    # Criar lista de exclusões
    local EXCLUDE_FILE="${BACKUP_DIR}/exclude_temp_${TIMESTAMP}.txt"
    cat > "${EXCLUDE_FILE}" << EOF
*/venv/*
*/__pycache__/*
*/.pytest_cache/*
*/.git/*
*/backups/*
*.pyc
*.pyo
*.log.[0-9]*
EOF
    
    log "INFO" "Lista de exclusões criada em: ${EXCLUDE_FILE}"
    
    # Criar backup compactado
    log "INFO" "Criando arquivo de backup compactado..."
    
    tar -czf "${BACKUP_FILE}" \
        -X "${EXCLUDE_FILE}" \
        -C "$(dirname "${PROJETO_DIR}")" "$(basename "${PROJETO_DIR}")" \
        2>> "${LOG_FILE}"
    
    if [ $? -ne 0 ]; then
        log "ERROR" "Falha ao criar arquivo de backup."
        rm -f "${EXCLUDE_FILE}"
        exit 1
    fi
    
    # Remover arquivo de exclusões temporário
    rm -f "${EXCLUDE_FILE}"
    
    # Verificar se o backup foi criado com sucesso
    if [ -f "${BACKUP_FILE}" ]; then
        local size=$(du -h "${BACKUP_FILE}" | cut -f1)
        log "SUCCESS" "Backup criado com sucesso: ${BACKUP_FILE} (${size})"
        return 0
    else
        log "ERROR" "Arquivo de backup não foi criado."
        return 1
    fi
}

# Função para calcular e verificar hash
calculate_hash() {
    log "INFO" "Calculando hash SHA-256 do arquivo de backup..."
    
    local HASH_FILE="${BACKUP_FILE}.sha256"
    
    sha256sum "${BACKUP_FILE}" > "${HASH_FILE}"
    
    if [ $? -ne 0 ]; then
        log "ERROR" "Falha ao calcular hash SHA-256."
        return 1
    fi
    
    log "SUCCESS" "Hash SHA-256 calculado e salvo em: ${HASH_FILE}"
    log "INFO" "Hash: $(cat ${HASH_FILE} | cut -d' ' -f1)"
    
    return 0
}

# Função para rotação de backups
rotate_backups() {
    log "INFO" "Iniciando rotação de backups..."
    
    # Rotação de backups diários (manter os últimos RETENTION_DAILY)
    log "INFO" "Rotação de backups diários: manter os últimos ${RETENTION_DAILY} dias"
    local daily_count=$(find "${BACKUP_DIR}" -name "kr_kripto_backup_*.tar.gz" | wc -l)
    
    if [ ${daily_count} -gt ${RETENTION_DAILY} ]; then
        log "INFO" "Existem ${daily_count} backups diários, removendo os mais antigos..."
        find "${BACKUP_DIR}" -name "kr_kripto_backup_*.tar.gz" -type f -printf '%T@ %p\n' | \
            sort -n | head -n $((daily_count - RETENTION_DAILY)) | \
            while read -r line; do
                file=$(echo "${line}" | cut -d' ' -f2-)
                log "INFO" "Removendo backup antigo: ${file}"
                rm -f "${file}" "${file}.sha256"
            done
    else
        log "INFO" "Número de backups diários (${daily_count}) está dentro do limite (${RETENTION_DAILY})."
    fi
    
    # Criar backup semanal (domingo)
    if [ "$(date +%u)" = "7" ]; then
        log "INFO" "Hoje é domingo, criando backup semanal..."
        local WEEKLY_BACKUP="${BACKUP_DIR}/kr_kripto_backup_weekly_$(date +%Y%m%d).tar.gz"
        cp "${BACKUP_FILE}" "${WEEKLY_BACKUP}"
        cp "${BACKUP_FILE}.sha256" "${WEEKLY_BACKUP}.sha256"
        log "SUCCESS" "Backup semanal criado: ${WEEKLY_BACKUP}"
        
        # Rotação de backups semanais
        local weekly_count=$(find "${BACKUP_DIR}" -name "kr_kripto_backup_weekly_*.tar.gz" | wc -l)
        if [ ${weekly_count} -gt ${RETENTION_WEEKLY} ]; then
            log "INFO" "Existem ${weekly_count} backups semanais, removendo os mais antigos..."
            find "${BACKUP_DIR}" -name "kr_kripto_backup_weekly_*.tar.gz" -type f -printf '%T@ %p\n' | \
                sort -n | head -n $((weekly_count - RETENTION_WEEKLY)) | \
                while read -r line; do
                    file=$(echo "${line}" | cut -d' ' -f2-)
                    log "INFO" "Removendo backup semanal antigo: ${file}"
                    rm -f "${file}" "${file}.sha256"
                done
        fi
    fi
    
    # Criar backup mensal (primeiro dia do mês)
    if [ "$(date +%d)" = "01" ]; then
        log "INFO" "Hoje é o primeiro dia do mês, criando backup mensal..."
        local MONTHLY_BACKUP="${BACKUP_DIR}/kr_kripto_backup_monthly_$(date +%Y%m).tar.gz"
        cp "${BACKUP_FILE}" "${MONTHLY_BACKUP}"
        cp "${BACKUP_FILE}.sha256" "${MONTHLY_BACKUP}.sha256"
        log "SUCCESS" "Backup mensal criado: ${MONTHLY_BACKUP}"
        
        # Rotação de backups mensais
        local monthly_count=$(find "${BACKUP_DIR}" -name "kr_kripto_backup_monthly_*.tar.gz" | wc -l)
        if [ ${monthly_count} -gt ${RETENTION_MONTHLY} ]; then
            log "INFO" "Existem ${monthly_count} backups mensais, removendo os mais antigos..."
            find "${BACKUP_DIR}" -name "kr_kripto_backup_monthly_*.tar.gz" -type f -printf '%T@ %p\n' | \
                sort -n | head -n $((monthly_count - RETENTION_MONTHLY)) | \
                while read -r line; do
                    file=$(echo "${line}" | cut -d' ' -f2-)
                    log "INFO" "Removendo backup mensal antigo: ${file}"
                    rm -f "${file}" "${file}.sha256"
                done
        fi
    fi
    
    log "SUCCESS" "Rotação de backups concluída."
}

# Função para testar restauração
test_restore() {
    log "INFO" "Testando restauração do backup..."
    
    local TEST_DIR="${BACKUP_DIR}/test_restore_${TIMESTAMP}"
    mkdir -p "${TEST_DIR}"
    
    log "INFO" "Extraindo alguns arquivos para teste em: ${TEST_DIR}"
    
    # Extrair apenas alguns arquivos importantes para teste
    tar -xzf "${BACKUP_FILE}" -C "${TEST_DIR}" \
        --strip-components=1 \
        "$(basename "${PROJETO_DIR}")/config.json" \
        "$(basename "${PROJETO_DIR}")/main.py" \
        2>> "${LOG_FILE}"
    
    if [ $? -ne 0 ]; then
        log "ERROR" "Falha ao extrair arquivos para teste de restauração."
        rm -rf "${TEST_DIR}"
        return 1
    fi
    
    # Verificar se os arquivos foram extraídos corretamente
    if [ -f "${TEST_DIR}/config.json" ] && [ -f "${TEST_DIR}/main.py" ]; then
        log "SUCCESS" "Teste de restauração bem-sucedido."
        
        # Limpar diretório de teste
        rm -rf "${TEST_DIR}"
        return 0
    else
        log "ERROR" "Teste de restauração falhou. Arquivos não foram extraídos corretamente."
        rm -rf "${TEST_DIR}"
        return 1
    fi
}

# Função para gerar relatório
generate_report() {
    local REPORT_FILE="${BACKUP_DIR}/backup_report_${TIMESTAMP}.txt"
    
    log "INFO" "Gerando relatório de backup em: ${REPORT_FILE}"
    
    cat > "${REPORT_FILE}" << EOF
==========================================================
RELATÓRIO DE BACKUP - KR_KRIPTO_ADVANCED_COPIA
==========================================================
Data e hora: $(date +"%Y-%m-%d %H:%M:%S")
Diretório do projeto: ${PROJETO_DIR}
Arquivo de backup: ${BACKUP_FILE}
Tamanho do backup: $(du -h "${BACKUP_FILE}" | cut -f1)
Hash SHA-256: $(cat "${BACKUP_FILE}.sha256" | cut -d' ' -f1)

CONFIGURAÇÕES DE RETENÇÃO:
- Backups diários: ${RETENTION_DAILY} dias
- Backups semanais: ${RETENTION_WEEKLY} semanas
- Backups mensais: ${RETENTION_MONTHLY} meses

ESTATÍSTICAS DE BACKUP:
- Backups diários disponíveis: $(find "${BACKUP_DIR}" -name "kr_kripto_backup_*.tar.gz" | wc -l)
- Backups semanais disponíveis: $(find "${BACKUP_DIR}" -name "kr_kripto_backup_weekly_*.tar.gz" | wc -l)
- Backups mensais disponíveis: $(find "${BACKUP_DIR}" -name "kr_kripto_backup_monthly_*.tar.gz" | wc -l)
- Espaço total utilizado: $(du -sh "${BACKUP_DIR}" | cut -f1)

INSTRUÇÕES DE RESTAURAÇÃO:
Para restaurar o backup completo:
  mkdir -p /caminho/para/restauracao
  tar -xzf "${BACKUP_FILE}" -C /caminho/para/restauracao

Para restaurar arquivos específicos:
  tar -xzf "${BACKUP_FILE}" -C /caminho/para/restauracao --strip-components=1 "$(basename "${PROJETO_DIR}")/arquivo_desejado"

Para verificar a integridade do backup:
  sha256sum -c "${BACKUP_FILE}.sha256"
==========================================================
EOF
    
    log "SUCCESS" "Relatório de backup gerado: ${REPORT_FILE}"
    
    # Adicionar relatório ao log
    cat "${REPORT_FILE}" >> "${LOG_FILE}"
}

# Função principal
main() {
    log "INFO" "Iniciando processo de backup do KR_KRIPTO_ADVANCED_COPIA"
    log "INFO" "Data e hora: $(date +"%Y-%m-%d %H:%M:%S")"
    
    # Verificar dependências
    check_dependencies
    
    # Criar diretório de backup
    create_backup_dir
    
    # Criar backup
    create_backup
    if [ $? -ne 0 ]; then
        log "ERROR" "Processo de backup falhou na criação do arquivo."
        exit 1
    fi
    
    # Calcular hash
    calculate_hash
    if [ $? -ne 0 ]; then
        log "ERROR" "Processo de backup falhou no cálculo do hash."
        exit 1
    fi
    
    # Testar restauração
    test_restore
    if [ $? -ne 0 ]; then
        log "WARNING" "Teste de restauração falhou, mas o processo de backup continuará."
    fi
    
    # Rotação de backups
    rotate_backups
    
    # Gerar relatório
    generate_report
    
    log "SUCCESS" "Processo de backup concluído com sucesso."
    log "INFO" "Arquivo de backup: ${BACKUP_FILE}"
    log "INFO" "Arquivo de log: ${LOG_FILE}"
    
    return 0
}

# Executar função principal
main

exit $?
