import sys
import os
print("Current Working Directory:", os.getcwd())
print("sys.path:")
for p in sys.path:
    print(p)
