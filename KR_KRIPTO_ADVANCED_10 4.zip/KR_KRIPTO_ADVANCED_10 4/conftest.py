# conftest.py
import sys
import os

# Adiciona o diretório raiz do projeto e o diretório src ao sys.path
project_root = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, project_root)
sys.path.insert(0, os.path.join(project_root, 'src'))


