#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Correção abrangente para o teste de rotação de logs

Este script corrige todos os problemas de caminho absoluto no teste de rotação de logs,
substituindo qualquer referência a os.path.join(tempfile.gettempdir(), "ubuntu") por caminhos temporários que
funcionam em qualquer sistema operacional.
"""

import os
import sys
import tempfile
import shutil
import re

def corrigir_teste_log_rotation(arquivo_teste):
    """
    Corrige o teste de rotação de logs para usar caminhos temporários.
    
    Args:
        arquivo_teste: Caminho para o arquivo test_log_rotation.py
    
    Returns:
        bool: True se a correção foi aplicada com sucesso, False caso contrário
    """
    try:
        # Ler o conteúdo do arquivo
        with open(arquivo_teste, 'r') as f:
            conteudo = f.read()
        
        # Verificar se o arquivo contém o caminho problemático
        if os.path.join(tempfile.gettempdir(), "ubuntu") in conteudo:
            # Adicionar importações necessárias se não existirem
            if 'import tempfile' not in conteudo:
                conteudo = conteudo.replace(
                    "import os", 
                    "import os\nimport tempfile"
                )
            
            # Adicionar função auxiliar para criar diretório temporário
            if "def get_temp_log_dir():" not in conteudo:
                # Encontrar a posição após as importações
                import_section_end = 0
                lines = conteudo.split('\n')
                for i, line in enumerate(lines):
                    if line.strip() and not line.startswith('import ') and not line.startswith('from '):
                        import_section_end = i
                        break
                
                # Inserir a função auxiliar após as importações
                helper_function = """
# Função auxiliar para criar e obter diretório de logs temporário
def get_temp_log_dir():
    temp_log_dir = os.path.join(tempfile.gettempdir(), 'kr_kripto_test_logs')
    os.makedirs(temp_log_dir, exist_ok=True)
    return temp_log_dir
"""
                lines.insert(import_section_end, helper_function)
                conteudo = '\n'.join(lines)
            
            # Substituir todas as ocorrências de caminhos absolutos
            # Padrão para encontrar caminhos como os.path.join(tempfile.gettempdir(), "ubuntu")os.path.join(tempfile.gettempdir(), "logs")/...'
            pattern = r"['\"]\/home\/ubuntu(?:\/[^'\"]*)?['\"]"
            
            # Função para substituir cada ocorrência encontrada
            def replace_path(match):
                path = match.group(0).strip('\'"')
                # Extrair a parte após os.path.join(tempfile.gettempdir(), "ubuntu")
                subpath = path[12:] if len(path) > 12 else ''
                # Se for um caminho de log, usar o diretório temporário
                if subpath.startswith(os.path.join(tempfile.gettempdir(), "logs")) or not subpath:
                    if subpath:
                        return f"os.path.join(get_temp_log_dir(), '{subpath[5:]}')"
                    else:
                        return "get_temp_log_dir()"
                else:
                    # Para outros caminhos, usar apenas o nome do arquivo
                    filename = os.path.basename(path)
                    return f"os.path.join(get_temp_log_dir(), '{filename}')"
            
            # Substituir todos os caminhos encontrados
            conteudo_corrigido = re.sub(pattern, lambda m: replace_path(m), conteudo)
            
            # Salvar o arquivo corrigido
            with open(arquivo_teste, 'w') as f:
                f.write(conteudo_corrigido)
            
            print(f"Correção abrangente aplicada com sucesso ao arquivo {arquivo_teste}")
            return True
        else:
            print(f"O arquivo {arquivo_teste} não contém o caminho problemático os.path.join(tempfile.gettempdir(), "ubuntu")")
            return False
        
    except Exception as e:
        print(f"Erro ao corrigir o arquivo: {str(e)}")
        return False

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python correcao_abrangente_teste_log_rotation.py <caminho_para_test_log_rotation.py>")
        sys.exit(1)
    
    arquivo_teste = sys.argv[1]
    if not os.path.exists(arquivo_teste):
        print(f"Arquivo {arquivo_teste} não encontrado")
        sys.exit(1)
    
    # Fazer backup do arquivo original
    arquivo_backup = f"{arquivo_teste}.bak_correcao_abrangente"
    try:
        shutil.copy2(arquivo_teste, arquivo_backup)
        print(f"Backup do arquivo original salvo em {arquivo_backup}")
    except Exception as e:
        print(f"Erro ao criar backup: {str(e)}")
        sys.exit(1)
    
    # Aplicar correção
    if corrigir_teste_log_rotation(arquivo_teste):
        print("\nA correção abrangente substituiu todas as referências a os.path.join(tempfile.gettempdir(), "ubuntu") por")
        print("caminhos temporários que funcionam em qualquer sistema operacional.")
        print("\nAgora você pode executar novamente os testes unitários:")
        print("pytest tests/")
        sys.exit(0)
    else:
        print("Falha ao aplicar correção")
        sys.exit(1)
