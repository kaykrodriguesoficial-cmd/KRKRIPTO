#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Correção para o main.py do KR_KRIPTO_ADVANCED_COPIA

Este arquivo contém a correção para o erro de unpacking no AmbienteRLStub
durante a execução da simulação.
"""

import os
import sys
import re

def corrigir_ambiente_rl_stub(arquivo_main):
    """
    Corrige a implementação do AmbienteRLStub no arquivo main.py
    
    Args:
        arquivo_main: Caminho para o arquivo main.py
    
    Returns:
        bool: True se a correção foi aplicada com sucesso, False caso contrário
    """
    try:
        # Ler o conteúdo do arquivo
        with open(arquivo_main, 'r') as f:
            conteudo = f.read()
        
        # Padrão para encontrar a classe AmbienteRLStub
        padrao_classe = r'class AmbienteRLStub:.*?def step\(self, \*args, \*\*kwargs\):.*?return (.*?)\n'
        
        # Encontrar a implementação atual do método step
        match = re.search(padrao_classe, conteudo, re.DOTALL)
        if not match:
            print("Não foi possível encontrar a implementação do método step na classe AmbienteRLStub")
            return False
        
        # Verificar se já está corrigido
        implementacao_atual = match.group(1).strip()
        if ',' in implementacao_atual and not implementacao_atual.startswith('{'):
            print("A implementação já parece estar corrigida (retorna uma tupla)")
            return True
        
        # Substituir a implementação do método step
        nova_implementacao = """        logger.warning("STUB: step called")
        # Retorna uma tupla com 4 elementos (next_state, reward, done, info)
        # em vez de um dicionário, para evitar o erro de unpacking
        next_state = {"state": [0.0] * 10}
        reward = 0.0
        done = False
        info = {"step_info": "stub_info"}
        return next_state, reward, done, info"""
        
        # Padrão para substituir a implementação do método step
        padrao_metodo = r'def step\(self, \*args, \*\*kwargs\):.*?return .*?\n'
        
        # Substituir a implementação
        novo_conteudo = re.sub(padrao_metodo, 
                              f'def step(self, *args, **kwargs):\n{nova_implementacao}\n', 
                              match.group(0), 
                              flags=re.DOTALL)
        
        # Substituir a classe inteira no conteúdo do arquivo
        conteudo_corrigido = conteudo.replace(match.group(0), novo_conteudo)
        
        # Salvar o arquivo corrigido
        with open(arquivo_main, 'w') as f:
            f.write(conteudo_corrigido)
        
        print(f"Correção aplicada com sucesso ao arquivo {arquivo_main}")
        return True
        
    except Exception as e:
        print(f"Erro ao corrigir o arquivo: {str(e)}")
        return False

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python correcao_ambiente_rl_main.py <caminho_para_main.py>")
        sys.exit(1)
    
    arquivo_main = sys.argv[1]
    if not os.path.exists(arquivo_main):
        print(f"Arquivo {arquivo_main} não encontrado")
        sys.exit(1)
    
    # Fazer backup do arquivo original
    arquivo_backup = f"{arquivo_main}.bak_antes_correcao_rl"
    try:
        with open(arquivo_main, 'r') as f_src:
            with open(arquivo_backup, 'w') as f_dst:
                f_dst.write(f_src.read())
        print(f"Backup do arquivo original salvo em {arquivo_backup}")
    except Exception as e:
        print(f"Erro ao criar backup: {str(e)}")
        sys.exit(1)
    
    # Aplicar correção
    if corrigir_ambiente_rl_stub(arquivo_main):
        print("Correção aplicada com sucesso!")
        sys.exit(0)
    else:
        print("Falha ao aplicar correção")
        sys.exit(1)
