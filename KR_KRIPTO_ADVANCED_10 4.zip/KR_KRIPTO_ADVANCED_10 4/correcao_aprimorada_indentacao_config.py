#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de Correção Aprimorada de Indentação - KR_KRIPTO_ADVANCED_COPIA
----------------------------------------------------------------------

Este script corrige o erro de indentação persistente no arquivo test_config_loader.py
que está causando falhas na execução dos testes unitários.

Erro original:
IndentationError: unexpected indent

Uso:
    python correcao_aprimorada_indentacao_config.py <caminho_para_test_config_loader.py>

Exemplo:
    python correcao_aprimorada_indentacao_config.py "/Volumes/Extreme SSD/KR_KRIPTO_ADVANCED/tests/core/test_config_loader.py"
"""

import os
import sys
import re
import shutil
import datetime
import logging
from typing import Optional, List, Tuple

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("correcao_aprimorada_indentacao_config.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("CorrecaoAprimoradaIndentacaoConfig")

def fazer_backup(arquivo: str) -> Optional[str]:
    """Cria um backup do arquivo antes de modificá-lo."""
    try:
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path = f"{arquivo}.bak_{timestamp}"
        shutil.copy2(arquivo, backup_path)
        logger.info(f"Backup criado: {backup_path}")
        return backup_path
    except Exception as e:
        logger.error(f"Erro ao criar backup de {arquivo}: {e}")
        return None

def detectar_padrao_indentacao(linhas: List[str]) -> Tuple[str, int]:
    """Detecta o padrão de indentação usado no arquivo (espaços ou tabs)."""
    espacos_count = 0
    tabs_count = 0
    tamanho_indentacao = 4  # Padrão
    
    for linha in linhas:
        if linha.startswith(' '):
            # Conta quantos espaços no início
            espacos = len(linha) - len(linha.lstrip(' '))
            if espacos > 0:
                espacos_count += 1
                # Tenta determinar o tamanho da indentação
                if espacos % 2 == 0 and espacos <= 8:
                    tamanho_indentacao = min(tamanho_indentacao, espacos)
        elif linha.startswith('\t'):
            tabs_count += 1
    
    # Determina o tipo de indentação predominante
    if tabs_count > espacos_count:
        return '\t', 1
    else:
        return ' ', tamanho_indentacao

def corrigir_indentacao(arquivo: str) -> bool:
    """Corrige o erro de indentação no arquivo test_config_loader.py usando uma abordagem mais robusta."""
    try:
        # Verifica se o arquivo existe
        if not os.path.exists(arquivo):
            logger.error(f"Arquivo não encontrado: {arquivo}")
            return False
        
        # Lê o conteúdo do arquivo
        with open(arquivo, 'r', encoding='utf-8') as f:
            conteudo = f.read()
        
        # Cria backup do arquivo original
        backup = fazer_backup(arquivo)
        if not backup:
            logger.error("Falha ao criar backup, abortando correção")
            return False
        
        # Abordagem 1: Reescrever o arquivo com indentação corrigida
        linhas = conteudo.splitlines()
        
        # Detecta o padrão de indentação usado no arquivo
        char_indentacao, tamanho_indentacao = detectar_padrao_indentacao(linhas)
        logger.info(f"Padrão de indentação detectado: {repr(char_indentacao)} x {tamanho_indentacao}")
        
        # Procura a linha problemática
        linha_problema = None
        for i, linha in enumerate(linhas):
            if "config = carregar_config(non_existent_path)" in linha:
                linha_problema = i
                break
        
        if linha_problema is None:
            logger.error("Linha problemática não encontrada")
            return False
        
        logger.info(f"Linha problemática encontrada: {linha_problema + 1}")
        
        # Determina o nível de indentação correto analisando o contexto
        nivel_correto = 0
        for i in range(linha_problema - 1, -1, -1):
            linha = linhas[i].rstrip()
            if not linha or linha.isspace():
                continue
            
            # Encontra a linha anterior não vazia
            indentacao_anterior = len(linha) - len(linha.lstrip())
            if linha.rstrip().endswith(':'):
                # Se a linha anterior termina com ':', aumenta a indentação
                nivel_correto = indentacao_anterior + tamanho_indentacao
            else:
                # Caso contrário, mantém o mesmo nível
                nivel_correto = indentacao_anterior
            break
        
        logger.info(f"Nível de indentação correto determinado: {nivel_correto}")
        
        # Corrige a indentação da linha problemática
        linha_atual = linhas[linha_problema]
        conteudo_linha = linha_atual.strip()
        linha_corrigida = char_indentacao * nivel_correto + conteudo_linha
        
        logger.info(f"Linha original: '{linha_atual}'")
        logger.info(f"Linha corrigida: '{linha_corrigida}'")
        
        linhas[linha_problema] = linha_corrigida
        
        # Escreve o conteúdo corrigido no arquivo
        with open(arquivo, 'w', encoding='utf-8') as f:
            f.write('\n'.join(linhas) + '\n')
        
        logger.info(f"Indentação corrigida com sucesso em {arquivo}")
        return True
    
    except Exception as e:
        logger.error(f"Erro ao corrigir indentação em {arquivo}: {e}")
        return False

def main():
    """Função principal para execução do script."""
    if len(sys.argv) < 2:
        print(f"Uso: python {os.path.basename(__file__)} <caminho_para_test_config_loader.py>")
        sys.exit(1)
    
    arquivo = sys.argv[1]
    logger.info(f"Iniciando correção aprimorada de indentação em {arquivo}")
    
    if corrigir_indentacao(arquivo):
        logger.info("Correção concluída com sucesso!")
        print("\nArquivo corrigido com sucesso!")
        print(f"Um backup do arquivo original foi criado em {arquivo}.bak_*")
        print("\nPróximos passos:")
        print("1. Execute os testes unitários para validar a correção:")
        print("   pytest tests/core/test_config_loader.py -v")
        print("2. Se necessário, restaure o backup do arquivo original.")
    else:
        logger.error("Falha na correção!")
        print("\nOcorreu um erro durante a correção. Verifique o log para mais detalhes.")
        sys.exit(1)

if __name__ == "__main__":
    main()
