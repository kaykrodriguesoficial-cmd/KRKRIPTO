#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de Correção Aprimorada de Sintaxe - KR_KRIPTO_ADVANCED_COPIA
-------------------------------------------------------------------

Este script corrige o erro de sintaxe persistente no arquivo test_simulacao_continua.py
que está causando falhas na execução dos testes unitários.

Erro original:
SyntaxError: closing parenthesis ')' does not match opening parenthesis '{'

Uso:
    python correcao_aprimorada_sintaxe_simulacao.py <caminho_para_test_simulacao_continua.py>

Exemplo:
    python correcao_aprimorada_sintaxe_simulacao.py "/Volumes/Extreme SSD/KR_KRIPTO_ADVANCED/tests/test_simulacao_continua.py"
"""

import os
import sys
import re
import shutil
import datetime
import logging
from typing import Optional

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("correcao_aprimorada_sintaxe_simulacao.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("CorrecaoAprimoradaSintaxeSimulacao")

def fazer_backup(arquivo: str) -> Optional[str]:
    """Cria um backup do arquivo antes de modificá-lo."""
    try:
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path = f"{arquivo}.bak_{timestamp}"
        shutil.copy2(arquivo, backup_path)
        logger.info(f"Backup criado: {backup_path}")
        return backup_path
    except Exception as e:
        logger.error(f"Erro ao criar backup de {arquivo}: {e}")
        return None

def corrigir_sintaxe(arquivo: str) -> bool:
    """Corrige o erro de sintaxe no arquivo test_simulacao_continua.py."""
    try:
        # Verifica se o arquivo existe
        if not os.path.exists(arquivo):
            logger.error(f"Arquivo não encontrado: {arquivo}")
            return False
        
        # Lê o conteúdo do arquivo
        with open(arquivo, 'r', encoding='utf-8') as f:
            conteudo = f.read()
        
        # Cria backup do arquivo original
        backup = fazer_backup(arquivo)
        if not backup:
            logger.error("Falha ao criar backup, abortando correção")
            return False
        
        # Procura a linha com erro de sintaxe
        linhas = conteudo.splitlines()
        linha_problema = None
        
        for i, linha in enumerate(linhas):
            if "simulador = SimuladorContinuo(config=" in linha and "dados.csv" in linha:
                linha_problema = i
                break
        
        if linha_problema is None:
            logger.error("Linha com erro de sintaxe não encontrada")
            return False
        
        logger.info(f"Linha problemática encontrada: {linha_problema + 1}")
        
        # Analisa a linha para verificar o problema de parênteses
        linha_atual = linhas[linha_problema]
        logger.info(f"Linha original: '{linha_atual}'")
        
        # Conta parênteses de abertura e fechamento
        aberturas = linha_atual.count('(')
        fechamentos = linha_atual.count(')')
        
        # Verifica se há chaves desbalanceadas
        aberturas_chaves = linha_atual.count('{')
        fechamentos_chaves = linha_atual.count('}')
        
        logger.info(f"Parênteses: {aberturas} aberturas, {fechamentos} fechamentos")
        logger.info(f"Chaves: {aberturas_chaves} aberturas, {fechamentos_chaves} fechamentos")
        
        # Corrige a linha com base no problema identificado
        linha_corrigida = linha_atual
        
        # Se faltam chaves de fechamento
        if aberturas_chaves > fechamentos_chaves:
            # Adiciona chaves de fechamento faltantes
            linha_corrigida = linha_atual + "}" * (aberturas_chaves - fechamentos_chaves)
        
        # Se faltam parênteses de fechamento após adicionar as chaves
        aberturas = linha_corrigida.count('(')
        fechamentos = linha_corrigida.count(')')
        
        if aberturas > fechamentos:
            # Adiciona parênteses de fechamento faltantes
            linha_corrigida = linha_corrigida + ")" * (aberturas - fechamentos)
        
        # Abordagem alternativa: reescrever completamente a linha
        if "dados.csv'" in linha_atual and not linha_atual.endswith("})"):
            # Extrai os componentes da linha
            match = re.search(r"simulador\s*=\s*SimuladorContinuo\s*\(\s*config\s*=\s*\{([^}]*)\}\s*\)?", linha_atual)
            if match:
                config_content = match.group(1).strip()
                # Reescreve a linha com sintaxe correta
                linha_corrigida = f"simulador = SimuladorContinuo(config={{{config_content}}})"
            else:
                # Tenta uma abordagem mais genérica
                linha_corrigida = re.sub(
                    r"(simulador\s*=\s*SimuladorContinuo\s*\(\s*config\s*=\s*\{[^}]*\})\s*\)?",
                    r"\1)",
                    linha_atual
                )
        
        logger.info(f"Linha corrigida: '{linha_corrigida}'")
        
        # Substitui a linha no conteúdo
        linhas[linha_problema] = linha_corrigida
        
        # Escreve o conteúdo corrigido no arquivo
        with open(arquivo, 'w', encoding='utf-8') as f:
            f.write('\n'.join(linhas) + '\n')
        
        logger.info(f"Sintaxe corrigida com sucesso em {arquivo}")
        return True
    
    except Exception as e:
        logger.error(f"Erro ao corrigir sintaxe em {arquivo}: {e}")
        return False

def main():
    """Função principal para execução do script."""
    if len(sys.argv) < 2:
        print(f"Uso: python {os.path.basename(__file__)} <caminho_para_test_simulacao_continua.py>")
        sys.exit(1)
    
    arquivo = sys.argv[1]
    logger.info(f"Iniciando correção aprimorada de sintaxe em {arquivo}")
    
    if corrigir_sintaxe(arquivo):
        logger.info("Correção concluída com sucesso!")
        print("\nArquivo corrigido com sucesso!")
        print(f"Um backup do arquivo original foi criado em {arquivo}.bak_*")
        print("\nPróximos passos:")
        print("1. Execute os testes unitários para validar a correção:")
        print("   pytest tests/test_simulacao_continua.py -v")
        print("2. Se necessário, restaure o backup do arquivo original.")
    else:
        logger.error("Falha na correção!")
        print("\nOcorreu um erro durante a correção. Verifique o log para mais detalhes.")
        sys.exit(1)

if __name__ == "__main__":
    main()
