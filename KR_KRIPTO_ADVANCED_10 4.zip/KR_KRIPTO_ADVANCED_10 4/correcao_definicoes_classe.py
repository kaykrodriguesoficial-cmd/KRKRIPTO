#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de Correção de Definições de Classe - KR_KRIPTO_ADVANCED_COPIA
---------------------------------------------------------------------

Este script corrige o uso incorreto de config={} em definições de classe
que está causando falhas na execução dos testes unitários.

Erro original:
TypeError: MarketRegime.__init_subclass__() takes no keyword arguments

Arquivos afetados:
- src/intelligence/context_switcher.py: classe MarketRegime
- src/infrastructure/fallback_listener.py: classe FallbackListener
- src/intelligence/governance/neural_governance.py: classe PredictiveModel
- src/intelligence/rl/agente_rl.py: classe RealAgenteRL
- recuperacao_automatica.py: classe TipoFalha

Uso:
    python correcao_definicoes_classe.py <diretorio_projeto>

Exemplo:
    python correcao_definicoes_classe.py "/Volumes/Extreme SSD/KR_KRIPTO_ADVANCED"
"""

import os
import sys
import re
import shutil
import datetime
import logging
from typing import Optional, List, Dict, Tuple

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("correcao_definicoes_classe.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("CorrecaoDefinicoesClasse")

# Lista de arquivos e classes a serem corrigidos
ARQUIVOS_CLASSES = [
    ("src/intelligence/context_switcher.py", "MarketRegime"),
    ("src/infrastructure/fallback_listener.py", "FallbackListener"),
    ("src/intelligence/governance/neural_governance.py", "PredictiveModel"),
    ("src/intelligence/rl/agente_rl.py", "RealAgenteRL"),
    ("recuperacao_automatica.py", "TipoFalha")
]

def fazer_backup(arquivo: str) -> Optional[str]:
    """Cria um backup do arquivo antes de modificá-lo."""
    try:
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path = f"{arquivo}.bak_{timestamp}"
        shutil.copy2(arquivo, backup_path)
        logger.info(f"Backup criado: {backup_path}")
        return backup_path
    except Exception as e:
        logger.error(f"Erro ao criar backup de {arquivo}: {e}")
        return None

def corrigir_definicao_classe(arquivo: str, nome_classe: str) -> bool:
    """Corrige a definição de classe com uso incorreto de config={}."""
    try:
        # Verifica se o arquivo existe
        if not os.path.exists(arquivo):
            logger.error(f"Arquivo não encontrado: {arquivo}")
            return False
        
        # Lê o conteúdo do arquivo
        with open(arquivo, 'r', encoding='utf-8') as f:
            conteudo = f.read()
        
        # Procura a definição da classe com config={}
        padrao = rf'class\s+{nome_classe}\s*\(\s*config\s*=\s*{{\s*}}\s*\)\s*:'
        match = re.search(padrao, conteudo)
        
        if not match:
            # Tenta um padrão mais genérico se o específico não for encontrado
            padrao = rf'class\s+{nome_classe}\s*\([^)]*config\s*=[^)]*\)\s*:'
            match = re.search(padrao, conteudo)
            
            if not match:
                logger.error(f"Definição de classe com config={{}} não encontrada para {nome_classe} em {arquivo}")
                return False
        
        # Cria backup do arquivo original
        backup = fazer_backup(arquivo)
        if not backup:
            logger.error("Falha ao criar backup, abortando correção")
            return False
        
        # Corrige a definição da classe
        # Opção 1: Remover completamente o parâmetro config={}
        conteudo_corrigido = re.sub(
            rf'class\s+{nome_classe}\s*\(\s*config\s*=\s*{{\s*}}\s*\)\s*:',
            f'class {nome_classe}:',
            conteudo
        )
        
        # Se o padrão específico não funcionou, tenta o genérico
        if conteudo_corrigido == conteudo:
            conteudo_corrigido = re.sub(
                rf'class\s+{nome_classe}\s*\([^)]*config\s*=[^)]*\)\s*:',
                f'class {nome_classe}:',
                conteudo
            )
        
        # Verifica se a classe tem um construtor __init__
        tem_init = re.search(rf'class\s+{nome_classe}.*?def\s+__init__\s*\(\s*self', conteudo, re.DOTALL)
        
        # Se não tiver __init__, adiciona um com o parâmetro config
        if not tem_init and conteudo_corrigido != conteudo:
            # Encontra o final da definição da classe
            match_class = re.search(rf'class\s+{nome_classe}:', conteudo_corrigido)
            if match_class:
                pos_class = match_class.end()
                # Adiciona o construtor após a definição da classe
                init_code = '\n    def __init__(self, config=None):\n        self.config = config or {}\n'
                conteudo_corrigido = conteudo_corrigido[:pos_class] + init_code + conteudo_corrigido[pos_class:]
        
        # Escreve o conteúdo corrigido no arquivo
        with open(arquivo, 'w', encoding='utf-8') as f:
            f.write(conteudo_corrigido)
        
        logger.info(f"Definição de classe corrigida com sucesso para {nome_classe} em {arquivo}")
        return True
    
    except Exception as e:
        logger.error(f"Erro ao corrigir definição de classe {nome_classe} em {arquivo}: {e}")
        return False

def processar_arquivos(diretorio_base: str) -> Dict[str, bool]:
    """Processa todos os arquivos e classes que precisam ser corrigidos."""
    resultados = {}
    
    for caminho_relativo, nome_classe in ARQUIVOS_CLASSES:
        caminho_completo = os.path.join(diretorio_base, caminho_relativo)
        logger.info(f"Processando {nome_classe} em {caminho_completo}")
        
        resultado = corrigir_definicao_classe(caminho_completo, nome_classe)
        resultados[f"{caminho_relativo}:{nome_classe}"] = resultado
    
    return resultados

def main():
    """Função principal para execução do script."""
    if len(sys.argv) < 2:
        print(f"Uso: python {os.path.basename(__file__)} <diretorio_projeto>")
        sys.exit(1)
    
    diretorio_base = sys.argv[1]
    logger.info(f"Iniciando correção de definições de classe em {diretorio_base}")
    
    resultados = processar_arquivos(diretorio_base)
    
    # Exibe resumo dos resultados
    print("\n=== RESUMO DAS CORREÇÕES ===")
    sucesso = 0
    falha = 0
    
    for arquivo_classe, resultado in resultados.items():
        status = "✅ SUCESSO" if resultado else "❌ FALHA"
        print(f"{status}: {arquivo_classe}")
        if resultado:
            sucesso += 1
        else:
            falha += 1
    
    print(f"\nTotal: {len(resultados)} arquivos processados, {sucesso} corrigidos com sucesso, {falha} falhas")
    
    if falha == 0:
        logger.info("Todas as correções foram concluídas com sucesso!")
        print("\nTodas as correções foram concluídas com sucesso!")
        print("\nPróximos passos:")
        print("1. Execute os testes unitários para validar as correções:")
        print("   pytest tests/")
        print("2. Se necessário, restaure os backups dos arquivos originais.")
    else:
        logger.warning(f"Algumas correções falharam ({falha}/{len(resultados)})")
        print(f"\nAtenção: {falha} correções falharam. Verifique o log para mais detalhes.")
        sys.exit(1)

if __name__ == "__main__":
    main()
