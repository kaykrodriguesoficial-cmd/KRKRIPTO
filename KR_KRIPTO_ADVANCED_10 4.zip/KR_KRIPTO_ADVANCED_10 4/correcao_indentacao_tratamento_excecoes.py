#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de Correção de Indentação - KR_KRIPTO_ADVANCED_COPIA
-----------------------------------------------------------

Este script corrige o erro de indentação no arquivo test_tratamento_excecoes.py
que está causando falhas na execução dos testes unitários.

Erro original:
IndentationError: unexpected indent

Uso:
    python correcao_indentacao_tratamento_excecoes.py <caminho_para_test_tratamento_excecoes.py>

Exemplo:
    python correcao_indentacao_tratamento_excecoes.py "/Volumes/Extreme SSD/KR_KRIPTO_ADVANCED/tests/test_tratamento_excecoes.py"
"""

import os
import sys
import re
import shutil
import datetime
import logging
from typing import Optional, List, Tuple

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("correcao_indentacao_tratamento_excecoes.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("CorrecaoIndentacaoTratamentoExcecoes")

def fazer_backup(arquivo: str) -> Optional[str]:
    """Cria um backup do arquivo antes de modificá-lo."""
    try:
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path = f"{arquivo}.bak_{timestamp}"
        shutil.copy2(arquivo, backup_path)
        logger.info(f"Backup criado: {backup_path}")
        return backup_path
    except Exception as e:
        logger.error(f"Erro ao criar backup de {arquivo}: {e}")
        return None

def detectar_padrao_indentacao(linhas: List[str]) -> Tuple[str, int]:
    """Detecta o padrão de indentação usado no arquivo (espaços ou tabs)."""
    espacos_count = 0
    tabs_count = 0
    tamanho_indentacao = 4  # Padrão
    
    for linha in linhas:
        if linha.startswith(' '):
            # Conta quantos espaços no início
            espacos = len(linha) - len(linha.lstrip(' '))
            if espacos > 0:
                espacos_count += 1
                # Tenta determinar o tamanho da indentação
                if espacos % 2 == 0 and espacos <= 8:
                    tamanho_indentacao = min(tamanho_indentacao, espacos)
        elif linha.startswith('\t'):
            tabs_count += 1
    
    # Determina o tipo de indentação predominante
    if tabs_count > espacos_count:
        return '\t', 1
    else:
        return ' ', tamanho_indentacao

def corrigir_indentacao(arquivo: str) -> bool:
    """Corrige o erro de indentação no arquivo test_tratamento_excecoes.py."""
    try:
        # Verifica se o arquivo existe
        if not os.path.exists(arquivo):
            logger.error(f"Arquivo não encontrado: {arquivo}")
            return False
        
        # Lê o conteúdo do arquivo
        with open(arquivo, 'r', encoding='utf-8') as f:
            linhas = f.readlines()
        
        # Procura a linha com erro de indentação (linha 60)
        linha_erro = None
        for i, linha in enumerate(linhas):
            if "config = config_loader.carregar_config(config_path)" in linha:
                linha_erro = i
                break
        
        if linha_erro is None:
            # Tenta encontrar por número aproximado
            if len(linhas) >= 60:
                linha_erro = 59  # Índice 59 = linha 60
            else:
                logger.error(f"Linha com erro de indentação não encontrada em {arquivo}")
                return False
        
        # Detecta o padrão de indentação usado no arquivo
        char_indentacao, tamanho_indentacao = detectar_padrao_indentacao(linhas)
        
        # Analisa o contexto para determinar a indentação correta
        # Procura o bloco de código ao qual a linha pertence
        nivel_indentacao = 0
        for i in range(linha_erro - 1, -1, -1):
            linha_atual = linhas[i]
            if re.search(r'^\s*def\s+test_', linha_atual) or re.search(r'^\s*class\s+Test', linha_atual):
                # Encontrou a definição da função de teste ou classe
                indentacao_base = len(linha_atual) - len(linha_atual.lstrip())
                nivel_indentacao = indentacao_base + tamanho_indentacao
                break
            elif re.search(r'^\s*with\s+|^\s*if\s+|^\s*for\s+|^\s*try\s*:', linha_atual):
                # Encontrou um bloco de controle (with, if, for, try)
                indentacao_atual = len(linha_atual) - len(linha_atual.lstrip())
                nivel_indentacao = indentacao_atual + tamanho_indentacao
                break
        
        # Cria backup do arquivo original
        backup = fazer_backup(arquivo)
        if not backup:
            logger.error("Falha ao criar backup, abortando correção")
            return False
        
        # Corrige a indentação da linha com erro
        linha_com_erro = linhas[linha_erro]
        conteudo_linha = linha_com_erro.strip()
        linha_corrigida = char_indentacao * nivel_indentacao + conteudo_linha + '\n'
        linhas[linha_erro] = linha_corrigida
        
        # Escreve o conteúdo corrigido no arquivo
        with open(arquivo, 'w', encoding='utf-8') as f:
            f.writelines(linhas)
        
        logger.info(f"Indentação corrigida com sucesso em {arquivo}, linha {linha_erro + 1}")
        return True
    
    except Exception as e:
        logger.error(f"Erro ao corrigir indentação em {arquivo}: {e}")
        return False

def main():
    """Função principal para execução do script."""
    if len(sys.argv) < 2:
        print(f"Uso: python {os.path.basename(__file__)} <caminho_para_test_tratamento_excecoes.py>")
        sys.exit(1)
    
    arquivo = sys.argv[1]
    logger.info(f"Iniciando correção de indentação em {arquivo}")
    
    if corrigir_indentacao(arquivo):
        logger.info("Correção concluída com sucesso!")
        print("\nArquivo corrigido com sucesso!")
        print(f"Um backup do arquivo original foi criado em {arquivo}.bak_*")
        print("\nPróximos passos:")
        print("1. Execute os testes unitários para validar a correção:")
        print("   pytest tests/test_tratamento_excecoes.py -v")
        print("2. Se necessário, restaure o backup do arquivo original.")
    else:
        logger.error("Falha na correção!")
        print("\nOcorreu um erro durante a correção. Verifique o log para mais detalhes.")
        sys.exit(1)

if __name__ == "__main__":
    main()
