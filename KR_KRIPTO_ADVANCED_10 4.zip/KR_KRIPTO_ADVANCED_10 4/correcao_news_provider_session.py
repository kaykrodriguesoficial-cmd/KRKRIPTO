#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script para corrigir o erro de session não definido no arquivo test_news_provider.py

Este script corrige o problema de NameError: name 'session' is not defined
no arquivo test_news_provider.py, garantindo que o parâmetro session seja
corretamente inicializado no construtor da classe NewsProvider.
"""

import os
import re
import sys
import shutil
import logging
from datetime import datetime

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger('CorrecaoTestNewsProvider')

def fazer_backup(arquivo):
    """Cria uma cópia de backup do arquivo original."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{arquivo}.bak_{timestamp}"
    shutil.copy2(arquivo, backup_path)
    logger.info(f"Backup criado em: {backup_path}")
    return backup_path

def corrigir_news_provider_session(arquivo):
    """Corrige o problema de session não definido no arquivo news_provider.py."""
    if not os.path.exists(arquivo):
        logger.error(f"Arquivo não encontrado: {arquivo}")
        return False
    
    # Fazer backup do arquivo original
    backup_path = fazer_backup(arquivo)
    
    try:
        with open(arquivo, 'r', encoding='utf-8') as f:
            conteudo = f.read()
        
        # Padrão para encontrar a linha problemática
        padrao_session = r'self\._session\s*=\s*session'
        
        # Verificar se o padrão foi encontrado
        match = re.search(padrao_session, conteudo)
        if not match:
            logger.error("Não foi possível encontrar a linha problemática com 'self._session = session'")
            return False
        
        # Substituir a linha problemática
        conteudo_corrigido = re.sub(
            padrao_session, 
            'self._session = None  # Inicializado sob demanda em _get_session()', 
            conteudo
        )
        
        # Escrever o conteúdo corrigido de volta ao arquivo
        with open(arquivo, 'w', encoding='utf-8') as f:
            f.write(conteudo_corrigido)
        
        logger.info(f"Arquivo corrigido com sucesso: {arquivo}")
        logger.info(f"Linha 'self._session = session' substituída por 'self._session = None  # Inicializado sob demanda em _get_session()'")
        return True
    
    except Exception as e:
        logger.error(f"Erro ao corrigir o arquivo: {str(e)}")
        # Restaurar o backup em caso de erro
        shutil.copy2(backup_path, arquivo)
        logger.info(f"Arquivo original restaurado a partir do backup")
        return False

def main():
    if len(sys.argv) != 2:
        logger.error("Uso: python correcao_news_provider_session.py <caminho_para_news_provider.py>")
        sys.exit(1)
    
    arquivo = sys.argv[1]
    sucesso = corrigir_news_provider_session(arquivo)
    
    if sucesso:
        logger.info("Correção aplicada com sucesso!")
        sys.exit(0)
    else:
        logger.error("Falha ao aplicar a correção.")
        sys.exit(1)

if __name__ == "__main__":
    main()
