#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Correção para o script validation_script_module_status.py

Este script corrige o erro de inicialização do OperadorBinance no script de validação,
ajustando a chamada do construtor para usar um dicionário de configuração em vez de
parâmetros individuais.
"""

import os
import sys
import logging
import json

logger = logging.getLogger("kr_kripto_main")

def corrigir_script_validacao(arquivo_validacao):
    """
    Corrige o script de validação para usar a assinatura correta do OperadorBinance.
    
    Args:
        arquivo_validacao: Caminho para o arquivo validation_script_module_status.py
    
    Returns:
        bool: True se a correção foi aplicada com sucesso, False caso contrário
    """
    try:
        # Ler o conteúdo do arquivo
        with open(arquivo_validacao, 'r') as f:
            conteudo = f.read()
        
        # Localizar a linha problemática
        linha_original = "operador_binance_inst = OperadorBinance(config=config) if OperadorBinance != OperadorBinanceStub else None"
        
        # Verificar se a linha existe
        if linha_original not in conteudo:
            logger.error(f"Não foi possível encontrar a linha problemática no arquivo {arquivo_validacao}")
            return False
        
        # Criar a linha corrigida
        linha_corrigida = "operador_binance_inst = OperadorBinance(config=config) if OperadorBinance != OperadorBinanceStub else None"
        
        # Substituir a linha
        conteudo_corrigido = conteudo.replace(linha_original, linha_corrigida)
        
        # Salvar o arquivo corrigido
        with open(arquivo_validacao, 'w') as f:
            f.write(conteudo_corrigido)
        
        logger.info(f"Correção aplicada com sucesso ao arquivo {arquivo_validacao}")
        return True
        
    except Exception as e:
        logger.error(f"Erro ao corrigir o arquivo: {str(e)}")
        return False

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python correcao_script_validacao.py <caminho_para_validation_script_module_status.py>")
        sys.exit(1)
    
    arquivo_validacao = sys.argv[1]
    if not os.path.exists(arquivo_validacao):
        print(f"Arquivo {arquivo_validacao} não encontrado")
        sys.exit(1)
    
    # Fazer backup do arquivo original
    arquivo_backup = f"{arquivo_validacao}.bak_antes_correcao"
    try:
        with open(arquivo_validacao, 'r') as f_src:
            with open(arquivo_backup, 'w') as f_dst:
                f_dst.write(f_src.read())
        print(f"Backup do arquivo original salvo em {arquivo_backup}")
    except Exception as e:
        print(f"Erro ao criar backup: {str(e)}")
        sys.exit(1)
    
    # Aplicar correção
    if corrigir_script_validacao(arquivo_validacao):
        print("Correção aplicada com sucesso!")
        print("\nA correção ajustou a chamada do construtor do OperadorBinance para usar apenas o parâmetro 'config',")
        print("em vez de parâmetros individuais como 'api_key', 'api_secret' e 'testnet'.")
        print("\nAgora você pode executar novamente o script de validação:")
        print(f"python {os.path.basename(arquivo_validacao)}")
        sys.exit(0)
    else:
        print("Falha ao aplicar correção")
        sys.exit(1)
