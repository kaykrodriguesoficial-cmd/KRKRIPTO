#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script para corrigir o erro de fixture no arquivo test_fallback.py

Este script corrige o problema de NameError: name 'tmp_path' is not defined
no arquivo test_fallback.py, garantindo que o parâmetro tmp_path seja
corretamente declarado na assinatura do fixture.
"""

import os
import re
import sys
import shutil
import logging
from datetime import datetime

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger('CorrecaoTestFallback')

def fazer_backup(arquivo):
    """Cria uma cópia de backup do arquivo original."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{arquivo}.bak_{timestamp}"
    shutil.copy2(arquivo, backup_path)
    logger.info(f"Backup criado em: {backup_path}")
    return backup_path

def corrigir_fixture_fallback(arquivo):
    """Corrige o problema de fixture no arquivo test_fallback.py."""
    if not os.path.exists(arquivo):
        logger.error(f"Arquivo não encontrado: {arquivo}")
        return False
    
    # Fazer backup do arquivo original
    backup_path = fazer_backup(arquivo)
    
    try:
        with open(arquivo, 'r', encoding='utf-8') as f:
            conteudo = f.read()
        
        # Padrão para encontrar a definição do fixture fallback_manager
        padrao_fixture = r'@pytest\.fixture\s*\n\s*def\s+fallback_manager\s*\(([^)]*)\):'
        
        # Verificar se o padrão foi encontrado
        match = re.search(padrao_fixture, conteudo)
        if not match:
            logger.error("Não foi possível encontrar a definição do fixture fallback_manager")
            return False
        
        # Extrair os parâmetros atuais do fixture
        params_atuais = match.group(1).strip()
        
        # Verificar se tmp_path já está nos parâmetros
        if 'tmp_path' in params_atuais:
            logger.info("O parâmetro tmp_path já está presente na assinatura do fixture")
            return True
        
        # Adicionar tmp_path aos parâmetros se necessário
        if params_atuais:
            # Se já existem parâmetros, adicionar tmp_path
            if 'config={}' in params_atuais:
                # Substituir config={} por config={}, tmp_path
                novos_params = params_atuais.replace('config={}', 'config={}, tmp_path')
            else:
                # Adicionar tmp_path ao final dos parâmetros existentes
                novos_params = f"{params_atuais}, tmp_path"
        else:
            # Se não há parâmetros, adicionar tmp_path
            novos_params = "tmp_path"
        
        # Substituir a assinatura do fixture
        nova_assinatura = f"@pytest.fixture\ndef fallback_manager({novos_params}):"
        conteudo_corrigido = re.sub(padrao_fixture, nova_assinatura, conteudo)
        
        # Escrever o conteúdo corrigido de volta ao arquivo
        with open(arquivo, 'w', encoding='utf-8') as f:
            f.write(conteudo_corrigido)
        
        logger.info(f"Arquivo corrigido com sucesso: {arquivo}")
        logger.info(f"Assinatura do fixture atualizada para: def fallback_manager({novos_params}):")
        return True
    
    except Exception as e:
        logger.error(f"Erro ao corrigir o arquivo: {str(e)}")
        # Restaurar o backup em caso de erro
        shutil.copy2(backup_path, arquivo)
        logger.info(f"Arquivo original restaurado a partir do backup")
        return False

def main():
    if len(sys.argv) != 2:
        logger.error("Uso: python correcao_test_fallback.py <caminho_para_test_fallback.py>")
        sys.exit(1)
    
    arquivo = sys.argv[1]
    sucesso = corrigir_fixture_fallback(arquivo)
    
    if sucesso:
        logger.info("Correção aplicada com sucesso!")
        sys.exit(0)
    else:
        logger.error("Falha ao aplicar a correção.")
        sys.exit(1)

if __name__ == "__main__":
    main()
