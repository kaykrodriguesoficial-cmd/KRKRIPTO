#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Correção para o teste de rotação de logs

Este script corrige o problema de caminho absoluto no teste de rotação de logs,
substituindo o caminho hardcoded os.path.join(tempfile.gettempdir(), "ubuntu")
os.makedirs(os.path.join(tempfile.gettempdir(), "ubuntu"), exist_ok=True) por um caminho temporário que
funciona em qualquer sistema operacional.
"""

import os
import sys
import tempfile
import shutil

def corrigir_teste_log_rotation(arquivo_teste):
    """
    Corrige o teste de rotação de logs para usar caminhos temporários.
    
    Args:
        arquivo_teste: Caminho para o arquivo test_log_rotation.py
    
    Returns:
        bool: True se a correção foi aplicada com sucesso, False caso contrário
    """
    try:
        # Ler o conteúdo do arquivo
        with open(arquivo_teste, 'r') as f:
            conteudo = f.read()
        
        # Verificar se o arquivo contém o caminho problemático
        if os.path.join(tempfile.gettempdir(), "ubuntu") in conteudo:
            # Substituir o caminho absoluto por um caminho temporário
            conteudo_corrigido = conteudo.replace(
                "log_file = os.path.join(tempfile.gettempdir(), "ubuntu")/logs/test_rotation.log'", 
                "log_file = os.path.join(tempfile.gettempdir(), 'kr_kripto_test_logs', 'test_rotation.log')"
            )
            
            # Verificar se a importação de tempfile já existe
            if 'import tempfile' not in conteudo_corrigido:
                # Adicionar a importação de tempfile após as importações existentes
                conteudo_corrigido = conteudo_corrigido.replace(
                    "import os", 
                    "import os\nimport tempfile"
                )
            
            # Salvar o arquivo corrigido
            with open(arquivo_teste, 'w') as f:
                f.write(conteudo_corrigido)
            
            print(f"Correção aplicada com sucesso ao arquivo {arquivo_teste}")
            return True
        else:
            print(f"O arquivo {arquivo_teste} não contém o caminho problemático os.path.join(tempfile.gettempdir(), "ubuntu")")
            return False
        
    except Exception as e:
        print(f"Erro ao corrigir o arquivo: {str(e)}")
        return False

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python correcao_teste_log_rotation.py <caminho_para_test_log_rotation.py>")
        sys.exit(1)
    
    arquivo_teste = sys.argv[1]
    if not os.path.exists(arquivo_teste):
        print(f"Arquivo {arquivo_teste} não encontrado")
        sys.exit(1)
    
    # Fazer backup do arquivo original
    arquivo_backup = f"{arquivo_teste}.bak_antes_correcao"
    try:
        shutil.copy2(arquivo_teste, arquivo_backup)
        print(f"Backup do arquivo original salvo em {arquivo_backup}")
    except Exception as e:
        print(f"Erro ao criar backup: {str(e)}")
        sys.exit(1)
    
    # Aplicar correção
    if corrigir_teste_log_rotation(arquivo_teste):
        print("\nA correção substituiu o caminho absoluto os.path.join(tempfile.gettempdir(), "ubuntu")/logs/test_rotation.log' por um")
        print("caminho temporário que funciona em qualquer sistema operacional.")
        print("\nAgora você pode executar novamente os testes unitários:")
        print("pytest tests/")
        sys.exit(0)
    else:
        print("Falha ao aplicar correção")
        sys.exit(1)
