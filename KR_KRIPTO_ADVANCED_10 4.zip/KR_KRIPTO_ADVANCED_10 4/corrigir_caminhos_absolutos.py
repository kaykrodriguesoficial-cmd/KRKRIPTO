#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de Correção de Caminhos Absolutos - KR_KRIPTO_ADVANCED_COPIA
-------------------------------------------------------------------

Este script analisa e corrige automaticamente caminhos absolutos em arquivos de teste
do sistema KR_KRIPTO_ADVANCED_COPIA, substituindo-os por caminhos temporários portáveis
que funcionam em qualquer sistema operacional (MacOS, Linux, Windows).

Características:
- Detecção automática de caminhos absolutos hardcoded
- Substituição por tempfile.gettempdir() para portabilidade
- Correção específica para o teste de rotação de logs
- Backup automático de arquivos originais
- Relatório detalhado das alterações realizadas

Uso:
    python corrigir_caminhos_absolutos.py [--dir diretorio_projeto] [--dry-run]

Opções:
    --dir       Diretório raiz do projeto (padrão: diretório atual)
    --dry-run   Executa em modo de simulação, sem alterar arquivos
"""

import os
import sys
import re
import argparse
import shutil
import datetime
import logging
from typing import List, Dict, Tuple, Set, Optional

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("correcao_caminhos.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("CorrecaoCaminhos")

# Padrões de expressões regulares para identificar caminhos absolutos
PADRAO_CAMINHO_ABSOLUTO = r'[\'\"](/[a-zA-Z0-9_\-\.]+)+[\'\"]'
PADRAO_HOME_UBUNTU = r'[\'\"]/?home/ubuntu(?:/[a-zA-Z0-9_\-\.]+)*[\'\"]'
PADRAO_CAMINHO_MACOS = r'[\'\"]/?Volumes/[a-zA-Z0-9_\-\.]+(?:/[a-zA-Z0-9_\-\.]+)*[\'\"]'

class CorretorCaminhos:
    """Classe principal para correção automática de caminhos absolutos."""
    
    def __init__(self, diretorio_projeto: str, modo_simulacao: bool = False):
        """Inicializa o corretor de caminhos."""
        self.diretorio_projeto = os.path.abspath(diretorio_projeto)
        self.modo_simulacao = modo_simulacao
        self.arquivos_python = []
        self.arquivos_teste = []
        self.caminhos_encontrados = {}
        self.arquivos_modificados = set()
        self.diretorio_backup = os.path.join(
            self.diretorio_projeto, 
            f"backup_caminhos_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
        )
        
        if not self.modo_simulacao:
            os.makedirs(self.diretorio_backup, exist_ok=True)
            logger.info(f"Diretório de backup criado: {self.diretorio_backup}")
        
        logger.info(f"Corretor de Caminhos inicializado para: {self.diretorio_projeto}")
        logger.info(f"Modo de simulação: {'Ativado' if self.modo_simulacao else 'Desativado'}")
    
    def encontrar_arquivos_teste(self) -> List[str]:
        """Encontra todos os arquivos de teste Python no diretório do projeto."""
        arquivos = []
        
        for raiz, _, nomes_arquivos in os.walk(self.diretorio_projeto):
            # Ignora diretórios de ambiente virtual e cache
            if any(d in raiz for d in ['venv', '.venv', '__pycache__', '.git']):
                continue
            
            # Prioriza arquivos em diretórios de teste
            e_diretorio_teste = 'test' in os.path.basename(raiz).lower() or 'tests' in os.path.basename(raiz).lower()
            
            for nome in nomes_arquivos:
                if nome.endswith('.py'):
                    e_arquivo_teste = nome.startswith('test_') or 'test' in nome.lower()
                    caminho_completo = os.path.join(raiz, nome)
                    
                    # Adiciona à lista de todos os arquivos Python
                    self.arquivos_python.append(caminho_completo)
                    
                    # Adiciona à lista de arquivos de teste se for um teste
                    if e_diretorio_teste or e_arquivo_teste:
                        arquivos.append(caminho_completo)
        
        self.arquivos_teste = arquivos
        logger.info(f"Encontrados {len(arquivos)} arquivos de teste Python para análise")
        logger.info(f"Encontrados {len(self.arquivos_python)} arquivos Python no total")
        return arquivos
    
    def analisar_caminhos_absolutos(self) -> Dict[str, List[Tuple[int, str, str]]]:
        """Analisa os arquivos de teste para encontrar caminhos absolutos."""
        caminhos = {}
        
        for arquivo in self.arquivos_teste:
            try:
                with open(arquivo, 'r', encoding='utf-8') as f:
                    linhas = f.readlines()
                
                caminhos_arquivo = []
                for i, linha in enumerate(linhas):
                    # Procura caminhos absolutos
                    for padrao in [PADRAO_CAMINHO_ABSOLUTO, PADRAO_HOME_UBUNTU, PADRAO_CAMINHO_MACOS]:
                        for match in re.finditer(padrao, linha):
                            caminho = match.group(0).strip('\'"')
                            caminhos_arquivo.append((i+1, caminho, linha.strip()))
                
                if caminhos_arquivo:
                    caminhos[arquivo] = caminhos_arquivo
            
            except Exception as e:
                logger.error(f"Erro ao analisar arquivo {arquivo}: {e}")
        
        self.caminhos_encontrados = caminhos
        total_caminhos = sum(len(c) for c in caminhos.values())
        logger.info(f"Encontrados {total_caminhos} caminhos absolutos em {len(caminhos)} arquivos")
        return caminhos
    
    def fazer_backup_arquivo(self, arquivo: str) -> bool:
        """Cria um backup do arquivo antes de modificá-lo."""
        if self.modo_simulacao:
            return True
        
        try:
            nome_arquivo = os.path.basename(arquivo)
            destino = os.path.join(self.diretorio_backup, nome_arquivo)
            
            # Adiciona sufixo numérico se já existir
            contador = 1
            while os.path.exists(destino):
                base, ext = os.path.splitext(nome_arquivo)
                destino = os.path.join(self.diretorio_backup, f"{base}_{contador}{ext}")
                contador += 1
            
            shutil.copy2(arquivo, destino)
            logger.info(f"Backup criado: {destino}")
            return True
        
        except Exception as e:
            logger.error(f"Erro ao criar backup de {arquivo}: {e}")
            return False
    
    def corrigir_teste_log_rotation(self) -> bool:
        """Corrige especificamente o teste de rotação de logs que usa caminhos absolutos."""
        # Procura o arquivo test_log_rotation.py
        log_rotation_test = None
        for arquivo in self.arquivos_teste:
            if "test_log_rotation.py" in arquivo:
                log_rotation_test = arquivo
                break
        
        if not log_rotation_test:
            logger.warning("Arquivo test_log_rotation.py não encontrado")
            return False
        
        if self.modo_simulacao:
            logger.info(f"[SIMULAÇÃO] Correção do teste de rotação de logs: {log_rotation_test}")
            return True
        
        try:
            with open(log_rotation_test, 'r', encoding='utf-8') as f:
                conteudo = f.read()
            
            # Faz backup antes de modificar
            if log_rotation_test not in self.arquivos_modificados:
                if not self.fazer_backup_arquivo(log_rotation_test):
                    return False
                self.arquivos_modificados.add(log_rotation_test)
            
            # Adiciona import para tempfile se não existir
            if "import tempfile" not in conteudo:
                conteudo = re.sub(
                    r'import .*?\n',
                    r'\g<0>import tempfile\n',
                    conteudo,
                    count=1
                )
            
            # Substitui definições de caminhos absolutos
            conteudo_corrigido = re.sub(
                r'(log_file|log_dir)\s*=\s*[\'\"]/?home/ubuntu(?:/[a-zA-Z0-9_\-\.]+)*[\'\"]',
                r'\1 = os.path.join(tempfile.gettempdir(), "test_logs")',
                conteudo
            )
            
            # Substitui outros caminhos absolutos
            conteudo_corrigido = re.sub(
                r'[\'\"]/?home/ubuntu(?:/[a-zA-Z0-9_\-\.]+)*[\'\"]',
                r'os.path.join(tempfile.gettempdir(), "test_logs")',
                conteudo_corrigido
            )
            
            # Adiciona criação de diretório temporário se não existir
            if "os.makedirs" not in conteudo_corrigido:
                conteudo_corrigido = re.sub(
                    r'(log_dir|log_file)\s*=\s*os\.path\.join\(tempfile\.gettempdir\(\),\s*[\'\"]test_logs[\'\"].*?\)',
                    r'\g<0>\nos.makedirs(os.path.join(tempfile.gettempdir(), "test_logs"), exist_ok=True)',
                    conteudo_corrigido,
                    count=1
                )
            
            with open(log_rotation_test, 'w', encoding='utf-8') as f:
                f.write(conteudo_corrigido)
            
            logger.info(f"Teste de rotação de logs corrigido: {log_rotation_test}")
            return True
        
        except Exception as e:
            logger.error(f"Erro ao corrigir teste de rotação de logs {log_rotation_test}: {e}")
            return False
    
    def corrigir_caminhos_absolutos(self) -> int:
        """Corrige caminhos absolutos em todos os arquivos de teste."""
        total_corrigidos = 0
        
        for arquivo, caminhos in self.caminhos_encontrados.items():
            if "test_log_rotation.py" in arquivo:
                # Este arquivo é tratado separadamente
                continue
            
            try:
                with open(arquivo, 'r', encoding='utf-8') as f:
                    conteudo = f.read()
                
                # Verifica se há caminhos para corrigir
                if not caminhos:
                    continue
                
                # Faz backup antes de modificar
                if arquivo not in self.arquivos_modificados:
                    if not self.fazer_backup_arquivo(arquivo):
                        continue
                    self.arquivos_modificados.add(arquivo)
                
                # Adiciona import para tempfile se não existir
                if "import tempfile" not in conteudo:
                    conteudo = re.sub(
                        r'import .*?\n',
                        r'\g<0>import tempfile\n',
                        conteudo,
                        count=1
                    )
                
                # Substitui caminhos absolutos
                conteudo_modificado = conteudo
                for _, caminho, _ in caminhos:
                    # Extrai o nome do diretório ou arquivo final
                    partes_caminho = caminho.strip('/').split('/')
                    nome_final = partes_caminho[-1] if partes_caminho else "test_dir"
                    
                    # Substitui o caminho absoluto por tempfile
                    padrao_caminho = re.escape(caminho)
                    substituicao = f'os.path.join(tempfile.gettempdir(), "{nome_final}")'
                    conteudo_modificado = re.sub(
                        f'[\'\"]?{padrao_caminho}[\'\"]?',
                        substituicao,
                        conteudo_modificado
                    )
                
                # Adiciona criação de diretório temporário se necessário
                if "os.makedirs" not in conteudo_modificado and "tempfile.gettempdir()" in conteudo_modificado:
                    # Encontra a primeira ocorrência de tempfile.gettempdir()
                    match = re.search(r'os\.path\.join\(tempfile\.gettempdir\(\),\s*[\'\"]([a-zA-Z0-9_\-\.]+)[\'\"]\)', conteudo_modificado)
                    if match:
                        dir_name = match.group(1)
                        # Adiciona criação de diretório após a primeira ocorrência
                        conteudo_modificado = re.sub(
                            r'(os\.path\.join\(tempfile\.gettempdir\(\),\s*[\'\"]' + re.escape(dir_name) + r'[\'\"].*?\))',
                            r'\g<0>\nos.makedirs(os.path.join(tempfile.gettempdir(), "' + dir_name + '"), exist_ok=True)',
                            conteudo_modificado,
                            count=1
                        )
                
                # Salva as modificações
                if conteudo_modificado != conteudo:
                    with open(arquivo, 'w', encoding='utf-8') as f:
                        f.write(conteudo_modificado)
                    
                    total_corrigidos += 1
                    logger.info(f"Arquivo corrigido: {arquivo}")
            
            except Exception as e:
                logger.error(f"Erro ao corrigir caminhos em {arquivo}: {e}")
        
        return total_corrigidos
    
    def executar_correcoes(self) -> Tuple[int, bool]:
        """Executa todas as correções necessárias."""
        # Encontra arquivos de teste
        self.encontrar_arquivos_teste()
        
        # Analisa caminhos absolutos
        self.analisar_caminhos_absolutos()
        
        # Corrige especificamente o teste de rotação de logs
        log_rotation_corrigido = self.corrigir_teste_log_rotation()
        
        # Corrige outros caminhos absolutos
        total_arquivos_corrigidos = self.corrigir_caminhos_absolutos()
        
        return total_arquivos_corrigidos, log_rotation_corrigido
    
    def gerar_relatorio(self, total_arquivos_corrigidos: int, log_rotation_corrigido: bool) -> str:
        """Gera um relatório detalhado das correções realizadas."""
        modo = "SIMULAÇÃO" if self.modo_simulacao else "PRODUÇÃO"
        
        relatorio = [
            f"=== RELATÓRIO DE CORREÇÃO DE CAMINHOS ABSOLUTOS ({modo}) ===",
            f"Data e hora: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"Diretório do projeto: {self.diretorio_projeto}",
            f"",
            f"Arquivos de teste analisados: {len(self.arquivos_teste)}",
            f"Caminhos absolutos encontrados: {sum(len(c) for c in self.caminhos_encontrados.values())}",
            f"",
            f"=== CORREÇÕES REALIZADAS ===",
            f"Arquivos corrigidos: {total_arquivos_corrigidos}",
            f"Teste de rotação de logs corrigido: {'Sim' if log_rotation_corrigido else 'Não'}",
            f"",
            f"=== ARQUIVOS MODIFICADOS ===",
        ]
        
        for arquivo in sorted(self.arquivos_modificados):
            relatorio.append(f"- {os.path.relpath(arquivo, self.diretorio_projeto)}")
        
        if not self.arquivos_modificados:
            relatorio.append("Nenhum arquivo foi modificado.")
        
        relatorio.append("")
        relatorio.append("=== INSTRUÇÕES ADICIONAIS ===")
        relatorio.append("1. Verifique os arquivos modificados para garantir que as correções estão corretas")
        relatorio.append("2. Execute os testes unitários para validar as alterações:")
        relatorio.append("   pytest tests/")
        relatorio.append("3. Se necessário, restaure os backups dos arquivos originais do diretório:")
        relatorio.append(f"   {self.diretorio_backup}")
        relatorio.append("")
        
        relatorio_texto = "\n".join(relatorio)
        
        # Salva o relatório em arquivo
        nome_arquivo = f"relatorio_correcao_caminhos_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        with open(nome_arquivo, 'w', encoding='utf-8') as f:
            f.write(relatorio_texto)
        
        logger.info(f"Relatório gerado: {nome_arquivo}")
        return relatorio_texto

def main():
    """Função principal para execução do script."""
    parser = argparse.ArgumentParser(description="Corretor de Caminhos Absolutos para KR_KRIPTO_ADVANCED_COPIA")
    parser.add_argument("--dir", default=".", help="Diretório raiz do projeto")
    parser.add_argument("--dry-run", action="store_true", help="Executa em modo de simulação, sem alterar arquivos")
    args = parser.parse_args()
    
    corretor = CorretorCaminhos(args.dir, args.dry_run)
    total_arquivos_corrigidos, log_rotation_corrigido = corretor.executar_correcoes()
    relatorio = corretor.gerar_relatorio(total_arquivos_corrigidos, log_rotation_corrigido)
    
    print("\n" + relatorio)

if __name__ == "__main__":
    main()
