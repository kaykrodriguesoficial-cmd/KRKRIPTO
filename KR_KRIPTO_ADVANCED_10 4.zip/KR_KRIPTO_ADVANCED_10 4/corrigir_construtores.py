#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de Correção Automática de Construtores - KR_KRIPTO_ADVANCED_COPIA
------------------------------------------------------------------------

Este script analisa e corrige automaticamente problemas de assinatura de construtores
em componentes do sistema KR_KRIPTO_ADVANCED_COPIA, padronizando o uso do parâmetro
'config' em vez de parâmetros individuais.

Características:
- Detecção automática de construtores problemáticos
- Correção de assinaturas de métodos __init__
- Ajuste de chamadas de construtores em scripts de validação
- Backup automático de arquivos originais
- Relatório detalhado das alterações realizadas

Uso:
    python corrigir_construtores.py [--dir diretorio_projeto] [--dry-run]

Opções:
    --dir       Diretório raiz do projeto (padrão: diretório atual)
    --dry-run   Executa em modo de simulação, sem alterar arquivos
"""

import os
import sys
import re
import argparse
import shutil
import datetime
import logging
from typing import List, Dict, Tuple, Set, Optional

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("correcao_construtores.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("CorrecaoConstrutores")

# Padrões de expressões regulares para identificar construtores e chamadas
PADRAO_CONSTRUTOR = r'def\s+__init__\s*\(\s*self\s*,\s*(.*?)\s*\)\s*:'
PADRAO_CHAMADA_CONSTRUTOR = r'(\w+)\s*\(\s*(.*?)\s*\)'
PADRAO_PARAMETRO_CONFIG = r'config\s*=\s*\{.*?\}|config\s*=\s*config|config\s*:\s*dict'

class CorretorConstrutores:
    """Classe principal para correção automática de construtores."""
    
    def __init__(self, config: dict):
        """Inicializa o corretor de construtores."""
        self.diretorio_projeto = os.path.abspath(diretorio_projeto)
        self.modo_simulacao = modo_simulacao
        self.arquivos_python = []
        self.construtores_encontrados = {}
        self.chamadas_encontradas = {}
        self.arquivos_modificados = set()
        self.diretorio_backup = os.path.join(
            self.diretorio_projeto, 
            f"backup_construtores_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
        )
        
        if not self.modo_simulacao:
            os.makedirs(self.diretorio_backup, exist_ok=True)
            logger.info(f"Diretório de backup criado: {self.diretorio_backup}")
        
        logger.info(f"Corretor de Construtores inicializado para: {self.diretorio_projeto}")
        logger.info(f"Modo de simulação: {'Ativado' if self.modo_simulacao else 'Desativado'}")
    
    def encontrar_arquivos_python(self) -> List[str]:
        """Encontra todos os arquivos Python no diretório do projeto."""
        arquivos = []
        
        for raiz, _, nomes_arquivos in os.walk(self.diretorio_projeto):
            # Ignora diretórios de ambiente virtual e cache
            if any(d in raiz for d in ['venv', '.venv', '__pycache__', '.git']):
                continue
            
            for nome in nomes_arquivos:
                if nome.endswith('.py'):
                    caminho_completo = os.path.join(raiz, nome)
                    arquivos.append(caminho_completo)
        
        self.arquivos_python = arquivos
        logger.info(f"Encontrados {len(arquivos)} arquivos Python para análise")
        return arquivos
    
    def analisar_construtores(self) -> Dict[str, List[Tuple[int, str, str]]]:
        """Analisa os arquivos Python para encontrar construtores."""
        construtores = {}
        
        for arquivo in self.arquivos_python:
            try:
                with open(arquivo, 'r', encoding='utf-8') as f:
                    conteudo = f.read()
                
                # Encontra classes e seus construtores
                classes = re.finditer(r'class\s+(\w+)', conteudo)
                construtores_arquivo = []
                
                for classe in classes:
                    nome_classe = classe.group(1)
                    # Procura o construtor da classe
                    match_construtor = re.search(
                        f'class\\s+{nome_classe}.*?def\\s+__init__\\s*\\(\\s*self\\s*,\\s*(.*?)\\s*\\)\\s*:', 
                        conteudo, 
                        re.DOTALL
                    )
                    
                    if match_construtor:
                        linha_inicio = conteudo[:match_construtor.start()].count('\n') + 1
                        parametros = match_construtor.group(1)
                        construtores_arquivo.append((linha_inicio, nome_classe, parametros))
                
                if construtores_arquivo:
                    construtores[arquivo] = construtores_arquivo
            
            except Exception as e:
                logger.error(f"Erro ao analisar arquivo {arquivo}: {e}")
        
        self.construtores_encontrados = construtores
        total_construtores = sum(len(c) for c in construtores.values())
        logger.info(f"Encontrados {total_construtores} construtores em {len(construtores)} arquivos")
        return construtores
    
    def analisar_chamadas_construtor(self) -> Dict[str, List[Tuple[int, str, str]]]:
        """Analisa os arquivos Python para encontrar chamadas de construtores."""
        chamadas = {}
        
        # Obtém nomes de todas as classes com construtores
        classes_com_construtores = set()
        for construtores_arquivo in self.construtores_encontrados.values():
            for _, nome_classe, _ in construtores_arquivo:
                classes_com_construtores.add(nome_classe)
        
        # Procura chamadas para essas classes
        for arquivo in self.arquivos_python:
            try:
                with open(arquivo, 'r', encoding='utf-8') as f:
                    linhas = f.readlines()
                
                chamadas_arquivo = []
                for i, linha in enumerate(linhas):
                    # Procura chamadas de construtores
                    for nome_classe in classes_com_construtores:
                        padrao = fr'{nome_classe}\s*\(\s*(.*?)\s*\)'
                        match = re.search(padrao, linha)
                        if match:
                            parametros = match.group(1)
                            chamadas_arquivo.append((i+1, nome_classe, parametros))
                
                if chamadas_arquivo:
                    chamadas[arquivo] = chamadas_arquivo
            
            except Exception as e:
                logger.error(f"Erro ao analisar chamadas em {arquivo}: {e}")
        
        self.chamadas_encontradas = chamadas
        total_chamadas = sum(len(c) for c in chamadas.values())
        logger.info(f"Encontradas {total_chamadas} chamadas de construtores em {len(chamadas)} arquivos")
        return chamadas
    
    def identificar_construtores_problematicos(self) -> Dict[str, List[Tuple[int, str, str, bool]]]:
        """Identifica construtores que não seguem o padrão recomendado."""
        problematicos = {}
        
        for arquivo, construtores in self.construtores_encontrados.items():
            construtores_problematicos = []
            
            for linha, nome_classe, parametros in construtores:
                # Verifica se o construtor já usa config como único parâmetro
                usa_config_corretamente = bool(re.search(PADRAO_PARAMETRO_CONFIG, parametros))
                
                # Verifica se tem múltiplos parâmetros individuais
                tem_multiplos_parametros = ',' in parametros
                
                # Marca como problemático se não usa config corretamente ou tem múltiplos parâmetros
                if not usa_config_corretamente or tem_multiplos_parametros:
                    construtores_problematicos.append((linha, nome_classe, parametros, usa_config_corretamente))
            
            if construtores_problematicos:
                problematicos[arquivo] = construtores_problematicos
        
        total_problematicos = sum(len(p) for p in problematicos.values())
        logger.info(f"Identificados {total_problematicos} construtores problemáticos em {len(problematicos)} arquivos")
        return problematicos
    
    def identificar_chamadas_problematicas(self) -> Dict[str, List[Tuple[int, str, str, bool]]]:
        """Identifica chamadas de construtores que não seguem o padrão recomendado."""
        problematicas = {}
        
        for arquivo, chamadas in self.chamadas_encontradas.items():
            chamadas_problematicas = []
            
            for linha, nome_classe, parametros in chamadas:
                # Verifica se a chamada já usa config como único parâmetro
                usa_config_corretamente = bool(re.search(r'config\s*=', parametros)) and not re.search(r'api_key\s*=', parametros)
                
                # Verifica se tem múltiplos parâmetros nomeados
                tem_multiplos_parametros = parametros.count('=') > 1
                
                # Marca como problemática se não usa config corretamente ou tem múltiplos parâmetros nomeados
                if not usa_config_corretamente or tem_multiplos_parametros:
                    chamadas_problematicas.append((linha, nome_classe, parametros, usa_config_corretamente))
            
            if chamadas_problematicas:
                problematicas[arquivo] = chamadas_problematicas
        
        total_problematicas = sum(len(p) for p in problematicas.values())
        logger.info(f"Identificadas {total_problematicas} chamadas problemáticas em {len(problematicas)} arquivos")
        return problematicas
    
    def fazer_backup_arquivo(self, arquivo: str) -> bool:
        """Cria um backup do arquivo antes de modificá-lo."""
        if self.modo_simulacao:
            return True
        
        try:
            nome_arquivo = os.path.basename(arquivo)
            destino = os.path.join(self.diretorio_backup, nome_arquivo)
            
            # Adiciona sufixo numérico se já existir
            contador = 1
            while os.path.exists(destino):
                base, ext = os.path.splitext(nome_arquivo)
                destino = os.path.join(self.diretorio_backup, f"{base}_{contador}{ext}")
                contador += 1
            
            shutil.copy2(arquivo, destino)
            logger.info(f"Backup criado: {destino}")
            return True
        
        except Exception as e:
            logger.error(f"Erro ao criar backup de {arquivo}: {e}")
            return False
    
    def corrigir_construtor(self, arquivo: str, linha: int, nome_classe: str, parametros: str) -> bool:
        """Corrige um construtor problemático para usar o padrão recomendado."""
        if self.modo_simulacao:
            logger.info(f"[SIMULAÇÃO] Correção de construtor: {nome_classe} em {arquivo}:{linha}")
            return True
        
        try:
            with open(arquivo, 'r', encoding='utf-8') as f:
                linhas = f.readlines()
            
            # Encontra a linha exata do construtor
            linha_atual = linha
            while linha_atual <= len(linhas):
                if f"def __init__" in linhas[linha_atual-1] and "self" in linhas[linha_atual-1]:
                    break
                linha_atual += 1
            
            if linha_atual > len(linhas):
                logger.error(f"Não foi possível encontrar o construtor de {nome_classe} em {arquivo}")
                return False
            
            # Substitui a assinatura do construtor
            linha_original = linhas[linha_atual-1]
            linha_nova = re.sub(
                r'def\s+__init__\s*\(\s*self\s*,\s*.*?\s*\)',
                'def __init__(self, config: dict)',
                linha_original
            )
            
            # Atualiza o arquivo
            linhas[linha_atual-1] = linha_nova
            
            # Faz backup antes de modificar
            if arquivo not in self.arquivos_modificados:
                if not self.fazer_backup_arquivo(arquivo):
                    return False
                self.arquivos_modificados.add(arquivo)
            
            with open(arquivo, 'w', encoding='utf-8') as f:
                f.writelines(linhas)
            
            logger.info(f"Construtor corrigido: {nome_classe} em {arquivo}:{linha}")
            return True
        
        except Exception as e:
            logger.error(f"Erro ao corrigir construtor {nome_classe} em {arquivo}: {e}")
            return False
    
    def corrigir_chamada_construtor(self, arquivo: str, linha: int, nome_classe: str, parametros: str) -> bool:
        """Corrige uma chamada de construtor problemática para usar o padrão recomendado."""
        if self.modo_simulacao:
            logger.info(f"[SIMULAÇÃO] Correção de chamada: {nome_classe} em {arquivo}:{linha}")
            return True
        
        try:
            with open(arquivo, 'r', encoding='utf-8') as f:
                linhas = f.readlines()
            
            linha_original = linhas[linha-1]
            
            # Extrai os parâmetros nomeados da chamada
            params_nomeados = {}
            for param in re.finditer(r'(\w+)\s*=\s*([^,]+)', parametros):
                nome = param.group(1)
                valor = param.group(2).strip()
                params_nomeados[nome] = valor
            
            # Cria uma nova chamada usando config
            if 'config' in params_nomeados:
                # Se já tem config, mantém e remove outros parâmetros
                nova_chamada = f"{nome_classe}(config={params_nomeados['config']})"
            else:
                # Cria um dicionário config com todos os parâmetros
                config_dict = "{" + ", ".join([f"'{k}': {v}" for k, v in params_nomeados.items()]) + "}"
                nova_chamada = f"{nome_classe}(config={config_dict})"
            
            # Substitui a chamada original
            padrao_chamada = f"{nome_classe}\\s*\\({parametros}\\)"
            linha_nova = re.sub(padrao_chamada, nova_chamada, linha_original)
            
            # Faz backup antes de modificar
            if arquivo not in self.arquivos_modificados:
                if not self.fazer_backup_arquivo(arquivo):
                    return False
                self.arquivos_modificados.add(arquivo)
            
            # Atualiza o arquivo
            linhas[linha-1] = linha_nova
            with open(arquivo, 'w', encoding='utf-8') as f:
                f.writelines(linhas)
            
            logger.info(f"Chamada corrigida: {nome_classe} em {arquivo}:{linha}")
            return True
        
        except Exception as e:
            logger.error(f"Erro ao corrigir chamada {nome_classe} em {arquivo}: {e}")
            return False
    
    def corrigir_validation_script(self) -> bool:
        """Corrige especificamente o script de validação que usa parâmetros individuais."""
        # Procura o arquivo validation_script_module_status.py
        validation_script = None
        for arquivo in self.arquivos_python:
            if "validation_script_module_status.py" in arquivo:
                validation_script = arquivo
                break
        
        if not validation_script:
            logger.warning("Arquivo validation_script_module_status.py não encontrado")
            return False
        
        if self.modo_simulacao:
            logger.info(f"[SIMULAÇÃO] Correção do script de validação: {validation_script}")
            return True
        
        try:
            with open(validation_script, 'r', encoding='utf-8') as f:
                conteudo = f.read()
            
            # Faz backup antes de modificar
            if validation_script not in self.arquivos_modificados:
                if not self.fazer_backup_arquivo(validation_script):
                    return False
                self.arquivos_modificados.add(validation_script)
            
            # Corrige a chamada do OperadorBinance
            conteudo_corrigido = re.sub(
                r'operador_binance_inst\s*=\s*OperadorBinance\s*\(\s*api_key\s*=\s*api_key\s*,\s*api_secret\s*=\s*api_secret\s*,\s*config\s*=\s*config\s*,\s*testnet\s*=\s*testnet_mode\s*\)',
                'operador_binance_inst = OperadorBinance(config=config)',
                conteudo
            )
            
            # Corrige outras chamadas problemáticas
            for classe in ['GerenciadorFallback', 'MemoriaTemporal', 'AttackDetector', 'ModelPerformanceTracker']:
                conteudo_corrigido = re.sub(
                    f'{classe}\\s*\\(\\s*.*?\\s*\\)',
                    f'{classe}(config=config)',
                    conteudo_corrigido
                )
            
            with open(validation_script, 'w', encoding='utf-8') as f:
                f.write(conteudo_corrigido)
            
            logger.info(f"Script de validação corrigido: {validation_script}")
            return True
        
        except Exception as e:
            logger.error(f"Erro ao corrigir script de validação {validation_script}: {e}")
            return False
    
    def executar_correcoes(self) -> Tuple[int, int, int]:
        """Executa todas as correções necessárias."""
        # Encontra arquivos Python
        self.encontrar_arquivos_python()
        
        # Analisa construtores e chamadas
        self.analisar_construtores()
        self.analisar_chamadas_construtor()
        
        # Identifica problemas
        construtores_problematicos = self.identificar_construtores_problematicos()
        chamadas_problematicas = self.identificar_chamadas_problematicas()
        
        # Contadores
        total_construtores = 0
        total_chamadas = 0
        total_falhas = 0
        
        # Corrige construtores
        for arquivo, construtores in construtores_problematicos.items():
            for linha, nome_classe, parametros, _ in construtores:
                if self.corrigir_construtor(arquivo, linha, nome_classe, parametros):
                    total_construtores += 1
                else:
                    total_falhas += 1
        
        # Corrige chamadas
        for arquivo, chamadas in chamadas_problematicas.items():
            for linha, nome_classe, parametros, _ in chamadas:
                if self.corrigir_chamada_construtor(arquivo, linha, nome_classe, parametros):
                    total_chamadas += 1
                else:
                    total_falhas += 1
        
        # Corrige especificamente o script de validação
        if self.corrigir_validation_script():
            logger.info("Script de validação corrigido com sucesso")
        else:
            logger.warning("Não foi possível corrigir o script de validação")
            total_falhas += 1
        
        return total_construtores, total_chamadas, total_falhas
    
    def gerar_relatorio(self, total_construtores: int, total_chamadas: int, total_falhas: int) -> str:
        """Gera um relatório detalhado das correções realizadas."""
        modo = "SIMULAÇÃO" if self.modo_simulacao else "PRODUÇÃO"
        
        relatorio = [
            f"=== RELATÓRIO DE CORREÇÃO DE CONSTRUTORES ({modo}) ===",
            f"Data e hora: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"Diretório do projeto: {self.diretorio_projeto}",
            f"",
            f"Arquivos Python analisados: {len(self.arquivos_python)}",
            f"Construtores encontrados: {sum(len(c) for c in self.construtores_encontrados.values())}",
            f"Chamadas de construtores encontradas: {sum(len(c) for c in self.chamadas_encontradas.values())}",
            f"",
            f"=== CORREÇÕES REALIZADAS ===",
            f"Construtores corrigidos: {total_construtores}",
            f"Chamadas corrigidas: {total_chamadas}",
            f"Falhas de correção: {total_falhas}",
            f"",
            f"=== ARQUIVOS MODIFICADOS ===",
        ]
        
        for arquivo in sorted(self.arquivos_modificados):
            relatorio.append(f"- {os.path.relpath(arquivo, self.diretorio_projeto)}")
        
        if not self.arquivos_modificados:
            relatorio.append("Nenhum arquivo foi modificado.")
        
        relatorio.append("")
        relatorio.append("=== INSTRUÇÕES ADICIONAIS ===")
        relatorio.append("1. Verifique os arquivos modificados para garantir que as correções estão corretas")
        relatorio.append("2. Execute os testes unitários para validar as alterações")
        relatorio.append("3. Se necessário, restaure os backups dos arquivos originais do diretório:")
        relatorio.append(f"   {self.diretorio_backup}")
        relatorio.append("")
        
        relatorio_texto = "\n".join(relatorio)
        
        # Salva o relatório em arquivo
        nome_arquivo = f"relatorio_correcao_construtores_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        with open(nome_arquivo, 'w', encoding='utf-8') as f:
            f.write(relatorio_texto)
        
        logger.info(f"Relatório gerado: {nome_arquivo}")
        return relatorio_texto

def main():
    """Função principal para execução do script."""
    parser = argparse.ArgumentParser(description="Corretor de Construtores para KR_KRIPTO_ADVANCED_COPIA")
    parser.add_argument("--dir", default=".", help="Diretório raiz do projeto")
    parser.add_argument("--dry-run", action="store_true", help="Executa em modo de simulação, sem alterar arquivos")
    args = parser.parse_args()
    
    corretor = CorretorConstrutores(config={})
    total_construtores, total_chamadas, total_falhas = corretor.executar_correcoes()
    relatorio = corretor.gerar_relatorio(total_construtores, total_chamadas, total_falhas)
    
    print("\n" + relatorio)

if __name__ == "__main__":
    main()
