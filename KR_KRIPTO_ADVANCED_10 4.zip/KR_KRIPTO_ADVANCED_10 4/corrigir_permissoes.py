#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para corrigir permissões de arquivos sensíveis no projeto KR_KRIPTO_ADVANCED_COPIA.
Implementa as recomendações de segurança para garantir o princípio do menor privilégio.

Autor: Manus AI
Data: 16 de maio de 2025
"""

import os
import sys
import stat
import logging
import json
from logging.handlers import TimedRotatingFileHandler
from datetime import datetime
import argparse

# Configurar logging
log_dir = 'logs'
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, 'corrigir_permissoes.log')

# Configurar logger com rotação diária
logger = logging.getLogger("corrigir_permissoes")
handler = TimedRotatingFileHandler(
    filename=log_file,
    when='midnight',
    interval=1,
    backupCount=30,
    encoding='utf-8'
)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

# Adicionar handler para console também
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)

logger.setLevel(logging.INFO)

# Definir permissões recomendadas
PERMISSOES = {
    # Arquivos de configuração e credenciais
    "config.json": 0o600,  # rw-------
    "*.pem": 0o600,        # rw-------
    "*.key": 0o600,        # rw-------
    "*.env": 0o600,        # rw-------
    
    # Arquivos de log
    "*.log": 0o640,        # rw-r-----
    
    # Chaves públicas
    "*publica*.pem": 0o644,  # rw-r--r--
    
    # Scripts executáveis
    "*.py": 0o755,         # rwxr-xr-x
    "*.sh": 0o755,         # rwxr-xr-x
    
    # Arquivos de dados
    "*.csv": 0o644,        # rw-r--r--
    "*.json": 0o644,       # rw-r--r--
    
    # Diretórios
    "dir:logs": 0o750,     # rwxr-x---
    "dir:config": 0o750,   # rwxr-x---
}

# Arquivos sensíveis específicos que precisam de atenção especial
ARQUIVOS_SENSIVEIS = [
    "config.json",
    "config/chave_privada.pem",
    "config/chave_publica.pem",
    ".env",
    "backup.sh"
]

def verificar_permissao(arquivo, permissao_recomendada):
    """Verifica se o arquivo tem a permissão recomendada."""
    try:
        stat_info = os.stat(arquivo)
        permissao_atual = stat_info.st_mode & 0o777  # Extrair apenas os bits de permissão
        
        if permissao_atual == permissao_recomendada:
            return True, permissao_atual
        else:
            return False, permissao_atual
    except FileNotFoundError:
        logger.warning(f"Arquivo não encontrado: {arquivo}")
        return False, None
    except Exception as e:
        logger.error(f"Erro ao verificar permissões de {arquivo}: {e}")
        return False, None

def corrigir_permissao(arquivo, permissao_recomendada, simular=False):
    """Corrige a permissão do arquivo para a recomendada."""
    try:
        ok, permissao_atual = verificar_permissao(arquivo, permissao_recomendada)
        
        if ok:
            logger.info(f"✓ {arquivo}: Permissão já correta ({oct(permissao_atual)[2:]})")
            return True
        
        if permissao_atual is None:
            return False
        
        # Converter para formato octal legível
        perm_atual_oct = oct(permissao_atual)[2:]
        perm_recom_oct = oct(permissao_recomendada)[2:]
        
        if simular:
            logger.info(f"! {arquivo}: Permissão atual {perm_atual_oct}, seria alterada para {perm_recom_oct} (simulação)")
            return True
        
        # Aplicar nova permissão
        os.chmod(arquivo, permissao_recomendada)
        
        # Verificar se a alteração foi bem-sucedida
        ok, nova_permissao = verificar_permissao(arquivo, permissao_recomendada)
        if ok:
            logger.info(f"✓ {arquivo}: Permissão alterada de {perm_atual_oct} para {perm_recom_oct}")
            return True
        else:
            logger.error(f"✗ {arquivo}: Falha ao alterar permissão de {perm_atual_oct} para {perm_recom_oct}")
            return False
    except Exception as e:
        logger.error(f"✗ Erro ao corrigir permissão de {arquivo}: {e}")
        return False

def encontrar_arquivos_por_padrao(diretorio_base, padrao):
    """Encontra arquivos que correspondem ao padrão especificado."""
    import fnmatch
    
    arquivos_encontrados = []
    
    for root, dirs, files in os.walk(diretorio_base):
        for filename in files:
            if fnmatch.fnmatch(filename, padrao):
                arquivos_encontrados.append(os.path.join(root, filename))
    
    return arquivos_encontrados

def processar_diretorio(diretorio, permissao_recomendada, simular=False):
    """Processa um diretório, aplicando a permissão recomendada."""
    try:
        if not os.path.isdir(diretorio):
            logger.warning(f"Diretório não encontrado: {diretorio}")
            return False
        
        ok, permissao_atual = verificar_permissao(diretorio, permissao_recomendada)
        
        if ok:
            logger.info(f"✓ Diretório {diretorio}: Permissão já correta ({oct(permissao_atual)[2:]})")
            return True
        
        if permissao_atual is None:
            return False
        
        # Converter para formato octal legível
        perm_atual_oct = oct(permissao_atual)[2:]
        perm_recom_oct = oct(permissao_recomendada)[2:]
        
        if simular:
            logger.info(f"! Diretório {diretorio}: Permissão atual {perm_atual_oct}, seria alterada para {perm_recom_oct} (simulação)")
            return True
        
        # Aplicar nova permissão
        os.chmod(diretorio, permissao_recomendada)
        
        # Verificar se a alteração foi bem-sucedida
        ok, nova_permissao = verificar_permissao(diretorio, permissao_recomendada)
        if ok:
            logger.info(f"✓ Diretório {diretorio}: Permissão alterada de {perm_atual_oct} para {perm_recom_oct}")
            return True
        else:
            logger.error(f"✗ Diretório {diretorio}: Falha ao alterar permissão de {perm_atual_oct} para {perm_recom_oct}")
            return False
    except Exception as e:
        logger.error(f"✗ Erro ao processar diretório {diretorio}: {e}")
        return False

def gerar_relatorio(resultados):
    """Gera um relatório detalhado das alterações realizadas."""
    total = len(resultados)
    sucessos = sum(1 for r in resultados if r["status"] == "success")
    falhas = total - sucessos
    
    relatorio = {
        "timestamp": datetime.now().isoformat(),
        "total_arquivos": total,
        "sucessos": sucessos,
        "falhas": falhas,
        "detalhes": resultados
    }
    
    # Salvar relatório em JSON
    try:
        relatorio_file = os.path.join(log_dir, f"permissoes_relatorio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        with open(relatorio_file, 'w') as f:
            json.dump(relatorio, f, indent=2)
        logger.info(f"Relatório salvo em {relatorio_file}")
    except Exception as e:
        logger.error(f"Erro ao salvar relatório: {e}")
    
    # Exibir resumo
    logger.info("\n" + "="*50)
    logger.info(f"RESUMO DA CORREÇÃO DE PERMISSÕES")
    logger.info("="*50)
    logger.info(f"Total de arquivos processados: {total}")
    logger.info(f"Sucessos: {sucessos}")
    logger.info(f"Falhas: {falhas}")
    logger.info("="*50)
    
    return relatorio

def main(diretorio_base, simular=False):
    """Função principal para corrigir permissões de arquivos sensíveis."""
    logger.info(f"Iniciando correção de permissões em {diretorio_base}")
    logger.info(f"Modo de simulação: {'Ativado' if simular else 'Desativado'}")
    
    resultados = []
    
    # Processar arquivos sensíveis específicos
    for arquivo_sensivel in ARQUIVOS_SENSIVEIS:
        caminho_completo = os.path.join(diretorio_base, arquivo_sensivel)
        
        # Determinar permissão recomendada
        permissao = None
        for padrao, perm in PERMISSOES.items():
            if padrao.startswith("dir:"):
                continue
            
            import fnmatch
            if fnmatch.fnmatch(os.path.basename(arquivo_sensivel), padrao):
                permissao = perm
                break
        
        if permissao is None:
            # Usar permissão padrão para arquivos de configuração
            permissao = PERMISSOES["config.json"]
        
        if os.path.exists(caminho_completo):
            sucesso = corrigir_permissao(caminho_completo, permissao, simular)
            resultados.append({
                "arquivo": caminho_completo,
                "tipo": "sensível",
                "permissao_recomendada": oct(permissao)[2:],
                "status": "success" if sucesso else "error"
            })
    
    # Processar padrões de arquivos
    for padrao, permissao in PERMISSOES.items():
        if padrao.startswith("dir:"):
            # Processar diretórios
            nome_dir = padrao.split(":")[1]
            diretorio = os.path.join(diretorio_base, nome_dir)
            if os.path.exists(diretorio):
                sucesso = processar_diretorio(diretorio, permissao, simular)
                resultados.append({
                    "arquivo": diretorio,
                    "tipo": "diretório",
                    "permissao_recomendada": oct(permissao)[2:],
                    "status": "success" if sucesso else "error"
                })
        else:
            # Processar arquivos por padrão
            arquivos = encontrar_arquivos_por_padrao(diretorio_base, padrao)
            for arquivo in arquivos:
                # Pular arquivos já processados como sensíveis
                if any(arquivo.endswith(a) for a in ARQUIVOS_SENSIVEIS):
                    continue
                
                sucesso = corrigir_permissao(arquivo, permissao, simular)
                resultados.append({
                    "arquivo": arquivo,
                    "tipo": "padrão",
                    "padrao": padrao,
                    "permissao_recomendada": oct(permissao)[2:],
                    "status": "success" if sucesso else "error"
                })
    
    # Gerar relatório
    relatorio = gerar_relatorio(resultados)
    
    return relatorio

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Corrige permissões de arquivos sensíveis no projeto KR_KRIPTO_ADVANCED_COPIA.")
    parser.add_argument("--diretorio", "-d", default=".", help="Diretório base do projeto (padrão: diretório atual)")
    parser.add_argument("--simular", "-s", action="store_true", help="Modo de simulação (não altera permissões)")
    
    args = parser.parse_args()
    
    main(args.diretorio, args.simular)
