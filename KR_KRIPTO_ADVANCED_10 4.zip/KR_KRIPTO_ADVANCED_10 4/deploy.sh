#!/bin/bash

# Script de implantação aprimorado para KR Kripto Advanced

# --- Configuração ---
APP_DIR="/home/ubuntu/kripto_analysis/KR_KRIPTO_ADVANCED_REORGANIZED"
LOG_FILE="${APP_DIR}/logs/kripto_tool.log"
PYTHON_EXEC="python3.11"
MAIN_SCRIPT="../main.py" # Relativo ao diretório src

# --- Argument Parsing ---
MODE="standalone" # Modo padrão

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --mode)
            MODE="$2"
            shift # past argument
            shift # past value
            ;;
        -*|--*)
            echo "Opção desconhecida $1" >&2
            exit 1
            ;;
        *)
            # Argumento desconhecido (ignorar ou tratar como erro)
            shift # past argument
            ;;
    esac
done

# Validar modo
if [[ "$MODE" != "standalone" && "$MODE" != "master" && "$MODE" != "worker" ]]; then
    echo "Erro: Modo inválido '$MODE'. Use 'standalone', 'master' ou 'worker'." >&2
    exit 1
fi

echo "--- Iniciando Deploy KR Kripto Advanced (Modo: $MODE) ---"

# --- Parar Processos Antigos ---
echo "Parando processos antigos do KR Kripto (se houver)..."
# Tenta parar processos específicos do main.py para evitar matar outros processos python
pkill -f "${PYTHON_EXEC} ${APP_DIR}/main.py --mode"
sleep 2

# --- Configuração do Ambiente ---
echo "Configurando ambiente (verificando diretório)..."
cd "${APP_DIR}/src" || { echo "Erro: Não foi possível acessar o diretório ${APP_DIR}/src"; exit 1; }

# (Adicionar comandos de configuração adicionais aqui, se necessário)
# Ex: Verificação de dependências, etc.

# --- Iniciar Aplicação ---
echo "Iniciando KR Kripto Advanced em modo '$MODE'..."

# Comando de execução
CMD="${PYTHON_EXEC} ${MAIN_SCRIPT} --mode ${MODE}"

# Limpar log antigo antes de iniciar (opcional)
# > "${LOG_FILE}"

# Executar em background e redirecionar logs
nohup $CMD >> "${LOG_FILE}" 2>&1 &

# --- Verificação Pós-Início ---
sleep 3 # Aguardar um pouco para o processo iniciar

# Verificar se o processo específico iniciou
PROCESS_PID=$(pgrep -f "${CMD}")

if [[ -n "$PROCESS_PID" ]]; then
  echo "KR Kripto Advanced (modo $MODE) iniciado com sucesso (PID: $PROCESS_PID)"
  echo "Logs sendo escritos em: ${LOG_FILE}"
else
  echo "ERRO: Falha ao iniciar KR Kripto Advanced (modo $MODE). Verifique os logs em ${LOG_FILE}." >&2
  # Mostrar últimas linhas do log em caso de falha
  echo "--- Últimas linhas do log (${LOG_FILE}) ---"
  tail -n 20 "${LOG_FILE}"
  echo "-----------------------------------------"
  exit 1
fi

echo "--- Deploy Concluído (Modo: $MODE) ---"
exit 0

