# Arquitetura do Cluster KR Kripto Advanced (ZeroMQ)

Este documento descreve a arquitetura de cluster implementada no KR Kripto Advanced usando ZeroMQ para permitir escalabilidade horizontal e distribuição de carga.

## 1. Visão Geral

A arquitetura segue um padrão Mestre-Trabalhador (Master-Worker) com comunicação baseada em publicação/assinatura (Pub/Sub) e solicitação/resposta (Req/Rep) para diferentes tipos de mensagens.

- **Mestre (Master):** Nó central responsável por coordenar os workers, distribuir tarefas (ativos a serem processados), agregar resultados (se necessário) e potencialmente centralizar certas funcionalidades (como governança de modelos ou gerenciamento de risco global).
- **Trabalhador (Worker):** Nó responsável por executar as tarefas designadas pelo mestre, como conectar-se ao stream de dados de um ativo específico, processar os dados, aplicar estratégias, executar modelos de IA e gerar sinais de negociação.

## 2. Comunicação ZeroMQ

Três sockets ZeroMQ principais são usados para a comunicação entre o mestre e os workers:

1.  **Socket de Publicação (PUB/SUB):**
    *   **Endereço:** `tcp://*:5556` (Mestre publica)
    *   **Padrão:** PUB (Mestre), SUB (Workers)
    *   **Propósito:** O mestre publica mensagens gerais ou comandos para todos os workers inscritos. Os tópicos são usados para direcionar mensagens (ex: `control`, `data`, `config`).
        *   `control assign <asset>`: Mestre instrui um worker a começar a processar um ativo.
        *   `control stop <asset>`: Mestre instrui um worker a parar de processar um ativo.
        *   Outros comandos de controle podem ser adicionados.
    *   **Fluxo:** Mestre -> Workers

2.  **Socket de Sincronização (SYNC - REQ/REP):**
    *   **Endereço:** `tcp://*:5557` (Mestre responde)
    *   **Padrão:** REP (Mestre), REQ (Workers)
    *   **Propósito:** Usado durante a inicialização do worker. O worker envia uma solicitação de sincronização (REQ) ao mestre e aguarda uma resposta (REP) antes de prosseguir. Isso garante que o mestre esteja ciente do worker antes que ele comece a operar.
    *   **Fluxo:** Worker -> Mestre -> Worker

3.  **Socket de Heartbeat (HB - REQ/REP):**
    *   **Endereço:** `tcp://*:5558` (Mestre responde)
    *   **Padrão:** REP (Mestre), REQ (Workers)
    *   **Propósito:** Os workers enviam periodicamente mensagens de heartbeat (REQ) para o mestre. O mestre responde (REP) para confirmar o recebimento. O mestre monitora esses heartbeats para detectar workers inativos ou desconectados.
    *   **Fluxo:** Worker -> Mestre -> Worker (periodicamente)

## 3. Papéis e Responsabilidades

### 3.1. Mestre (`main.py --mode master`)

- Inicializa o `ClusterManager` em modo `master`.
- Vincula os sockets PUB, SYNC (REP) e HEARTBEAT (REP) aos endereços e portas configurados.
- Mantém uma lista de workers ativos e seus últimos heartbeats.
- Decide quais ativos (`config["ativos"]`) devem ser processados.
- Distribui as tarefas de processamento de ativos entre os workers disponíveis usando mensagens `control assign <asset>` no socket PUB.
- Monitora os heartbeats dos workers e remove workers inativos (timeout).
- (Opcional) Pode centralizar a lógica de governança neural, gerenciamento de risco agregado, ou outras tarefas globais.
- (Opcional) Pode receber resultados ou sinais dos workers (requer um socket adicional, ex: PULL).

### 3.2. Trabalhador (`main.py --mode worker`)

- Inicializa o `ClusterManager` em modo `worker`.
- Gera um ID único.
- Conecta-se ao socket SYNC (REQ) do mestre, envia uma solicitação e aguarda a resposta para sincronizar.
- Conecta-se ao socket HEARTBEAT (REQ) do mestre e inicia um loop para enviar heartbeats periódicos.
- Conecta-se ao socket PUB do mestre e se inscreve nos tópicos relevantes (ex: `control`).
- Aguarda por mensagens do mestre no socket SUB.
- Ao receber uma mensagem `control assign <asset>`:
    - Inicializa os componentes necessários para processar o ativo (ex: `BookProcessor`, `AmbienteRL`, `AgenteRL`).
    - Inicia a conexão com o stream de dados da Binance para o ativo (`conectar_binance`).
    - Processa os dados recebidos (`processar_mensagem`).
- Ao receber uma mensagem `control stop <asset>`:
    - Encerra a conexão com o stream de dados.
    - Libera os recursos associados ao ativo.
- (Opcional) Pode enviar resultados ou sinais para o mestre (requer um socket adicional, ex: PUSH).

## 4. Fluxo de Inicialização e Operação

1.  O Mestre é iniciado (`--mode master`). Ele vincula os sockets e aguarda workers.
2.  Um Worker é iniciado (`--mode worker`).
3.  O Worker envia uma mensagem SYNC para o Mestre.
4.  O Mestre recebe a SYNC, registra o Worker e responde.
5.  O Worker recebe a resposta SYNC, conecta-se aos sockets PUB e HEARTBEAT.
6.  O Worker começa a enviar Heartbeats periódicos para o Mestre.
7.  O Mestre publica uma mensagem `control assign <asset>` no socket PUB.
8.  O Worker recebe a mensagem, inicializa os componentes e começa a processar o ativo (conecta ao stream da Binance, etc.).
9.  O Worker continua enviando Heartbeats.
10. O Mestre monitora os Heartbeats. Se um Worker não enviar heartbeat por um tempo (timeout), o Mestre o considera inativo e pode redistribuir suas tarefas.

## 5. Considerações

- **Tolerância a Falhas:** A arquitetura atual tem um ponto único de falha no Mestre. Para maior robustez, mecanismos de eleição de mestre ou redundância poderiam ser implementados.
- **Distribuição de Carga:** O Mestre atualmente distribui tarefas, mas a lógica de balanceamento pode ser aprimorada (ex: considerar carga atual dos workers).
- **Comunicação Worker -> Mestre:** A arquitetura atual foca na comunicação Mestre -> Worker. Se os workers precisarem enviar dados significativos de volta ao mestre (ex: sinais gerados, métricas detalhadas), um padrão PUSH/PULL ou outro mecanismo deve ser adicionado.
- **Segurança:** A comunicação ZeroMQ não é criptografada por padrão. Em ambientes não confiáveis, mecanismos de segurança como CURVEZMQ devem ser considerados.
- **Configuração:** Endereços e portas dos sockets são atualmente fixos no código (`cluster_manager.py`) ou derivados (`utils.py`), mas poderiam ser movidos para o `config.json` para maior flexibilidade.

