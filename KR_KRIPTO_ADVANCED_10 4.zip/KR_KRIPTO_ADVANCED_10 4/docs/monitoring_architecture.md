# Arquitetura de Monitoramento e Logging (Fase 5)

Este documento descreve a arquitetura de monitoramento e logging implementada na Fase 5 do projeto KR Kripto Advanced.

## 1. Logging Estruturado JSON

O sistema utiliza um sistema de logging padronizado em formato JSON para facilitar a análise e agregação de logs.

*   **Formato:** JSON estruturado.
*   **Biblioteca:** `logging` padrão do Python em conjunto com `python-json-logger` para formatação.
*   **Configuração:** A configuração centralizada do logging é feita no arquivo `src/config/logging_config.py`. Ele define o formato JSON, o nível de log padrão e os handlers (atualmente, console).
*   **Loggers:** Cada módulo principal possui seu próprio logger nomeado (ex: `kr_kripto_processor`, `kr_kripto_stream`, `kr_kripto_fallback`, `kr_kripto_operador`) para permitir filtragem e análise granular.
*   **Captura de Erros:** Exceções são capturadas e logadas com `exc_info=True` para incluir stack traces detalhados nos logs JSON.
*   **Consistência:** A revisão confirmou que os módulos principais utilizam o sistema de logging de forma consistente, evitando o uso de `print` para saídas operacionais.

## 2. Métricas Prometheus

Um exportador Prometheus expõe métricas detalhadas sobre o desempenho e o estado do sistema.

*   **Implementação:** O exportador está implementado em `src/infrastructure/prometheus_exporter.py` utilizando a biblioteca `prometheus_client`.
*   **Acesso:** As métricas são expostas via HTTP na porta `8000` (configurável) no endpoint `/metrics` (ex: `http://localhost:8000/metrics`).
*   **Métricas Chave:**
    *   `kr_signals_processed_total`: Contagem de sinais processados (por ativo, regime, decisão).
    *   `kr_errors_total`: Contagem de erros (por componente, ativo).
    *   `kr_binance_connection_status`: Status das conexões Binance (websocket, rest_api).
    *   `kr_signal_processing_latency_seconds`: Histograma da latência de processamento de sinais.
    *   `kr_ai_response_time_seconds`: Tempo de resposta dos modelos de IA.
    *   `kr_circuit_breaker_state`: Estado dos circuit breakers (closed, open, half-open).
    *   `kr_circuit_breaker_failures_total`, `kr_circuit_breaker_successes_total`: Contadores de falhas/sucessos dos circuit breakers.
    *   `kr_fallback_activations_total`: Contagem de ativações do fallback.
    *   `kr_fallback_model_used_total`: Contagem de uso do modelo fallback.
    *   `kr_regime_identified_total`: Contagem de regimes de mercado identificados.
    *   `kr_validator_results_total`: Resultados das validações.
    *   `kr_governance_prediction_score`: Score da Governança Neural.
    *   `kr_news_provider_score`: Score de sentimento das notícias.
    *   `kr_rl_action_chosen_total`: Ações escolhidas pelo agente RL.
*   **Inicialização:** A função `start_metrics_server()` no exportador inicia o servidor HTTP.

## 3. Dashboards Grafana

Foram criados arquivos JSON de exemplo para importação no Grafana, permitindo a visualização das métricas Prometheus.

*   **Arquivos:**
    *   `docs/grafana_system_overview.json`: Visão geral do sistema (taxa de sinais, erros, conexões, circuit breakers).
    *   `docs/grafana_latency_performance.json`: Detalhes de latência e performance (processamento de sinais, tempo de resposta IA).
    *   `docs/grafana_governance_rl.json`: Métricas específicas da Governança Neural e do Reinforcement Learning.
*   **Funcionalidades:** Os dashboards incluem variáveis para filtrar métricas por ativo, regime, tipo de modelo, etc.

## 4. Sistema de Alertas

Um arquivo de exemplo com regras de alerta para o Prometheus/Alertmanager foi criado para monitorar condições críticas.

*   **Arquivo:** `docs/prometheus_alert_rules.yml`.
*   **Regras Definidas (Exemplos):**
    *   `BinanceConnectionDown`: Alerta se a conexão com a Binance ficar offline.
    *   `HighErrorRate`: Alerta sobre taxas de erro elevadas em componentes específicos.
    *   `CircuitBreakerOpen`: Alerta imediato quando um circuit breaker abre.
    *   `FallbackActivated`: Alerta quando o mecanismo de fallback é ativado.
    *   `HighSignalProcessingLatency`: Alerta sobre alta latência no processamento de sinais.
*   **Integração:** Estas regras devem ser carregadas em uma instância do Prometheus configurada para enviar alertas ao Alertmanager, que por sua vez pode encaminhá-los para canais como Telegram, Slack, etc. (A configuração do Alertmanager e a integração com `notifier.py` não foram realizadas nesta fase).

## 5. Testes

Os testes da Fase 5 envolveram a execução do sistema em modo de simulação para gerar logs e métricas. A verificação dos logs JSON foi bem-sucedida. A verificação direta do endpoint Prometheus apresentou dificuldades no ambiente de teste devido ao ciclo de vida do processo de simulação, mas a estrutura do exportador e das métricas foi validada.

