#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para corrigir o erro no teste end-to-end ajustando a assinatura do mock conectar_binance.

Este script modifica o arquivo test_end_to_end.py para garantir que o mock
de conectar_binance tenha a assinatura correta, compatível com a chamada em main.py.
"""

import os
import sys
import re

def fix_mock_conectar_binance():
    """
    Corrige a assinatura do mock conectar_binance no arquivo test_end_to_end.py
    para ser compatível com a chamada em main.py.
    """
    test_file_path = 'tests/test_end_to_end.py'
    
    # Verificar se o arquivo existe
    if not os.path.exists(test_file_path):
        print(f"Erro: Arquivo {test_file_path} não encontrado.")
        return False
    
    # Ler o conteúdo do arquivo
    with open(test_file_path, 'r') as file:
        content = file.read()
    
    # Procurar pela definição da função mock_connect_logic
    mock_connect_logic_pattern = r"async def mock_connect_logic\(.*?\):"
    mock_connect_logic_match = re.search(mock_connect_logic_pattern, content, re.DOTALL)
    
    if not mock_connect_logic_match:
        print("Aviso: Não foi possível encontrar a função mock_connect_logic no arquivo.")
        return False
    
    # Substituir a assinatura da função mock_connect_logic
    old_signature = mock_connect_logic_match.group(0)
    new_signature = "async def mock_connect_logic(config, stream_manager):"
    
    # Substituir a assinatura
    new_content = content.replace(old_signature, new_signature)
    
    # Verificar se a substituição foi feita
    if new_content == content:
        print("Aviso: Não foi possível substituir a assinatura da função mock_connect_logic.")
        return False
    
    # Procurar pelo corpo da função mock_connect_logic para ajustar
    mock_connect_logic_body_pattern = r"async def mock_connect_logic\(.*?\):(.*?)(?=\n\s*\w)"
    mock_connect_logic_body_match = re.search(mock_connect_logic_body_pattern, new_content, re.DOTALL)
    
    if not mock_connect_logic_body_match:
        print("Aviso: Não foi possível encontrar o corpo da função mock_connect_logic.")
        return False
    
    # Ajustar o corpo da função para usar os novos parâmetros
    old_body = mock_connect_logic_body_match.group(1)
    new_body = """
        # Extrair ativo do stream_manager para compatibilidade
        ativo = getattr(stream_manager, 'ativo', 'BTCUSDT')
        print(f"Mock conectar_binance called with config and stream_manager. Using ativo: {ativo}")
        try:
            while True:
                msg = await mock_websocket.recv()
                # Simulate processing or log receipt
                print(f"Mock received: {msg[:50]}...")
                # In a real test, you might call the actual process_message here
                # from core.binance_stream import processar_mensagem
                # await processar_mensagem(msg, ativo, stream_manager)
                await asyncio.sleep(0.1)
        except asyncio.CancelledError:
            print("Mock connect loop cancelled.")
        except Exception as e:
            print(f"Mock connect loop error: {e}")
        finally:
            print(f"Mock conectar_binance finished.")"""
    
    # Substituir o corpo da função
    new_content = new_content.replace(old_body, new_body)
    
    # Escrever o conteúdo modificado de volta para o arquivo
    with open(test_file_path, 'w') as file:
        file.write(new_content)
    
    print(f"Assinatura da função mock_connect_logic no {test_file_path} atualizada com sucesso.")
    return True

if __name__ == "__main__":
    print("Iniciando correção da assinatura do mock conectar_binance no teste end-to-end...")
    
    # Corrigir a assinatura do mock conectar_binance
    if fix_mock_conectar_binance():
        print("Assinatura do mock conectar_binance corrigida com sucesso.")
    else:
        print("Falha ao corrigir a assinatura do mock conectar_binance.")
        sys.exit(1)
    
    print("Correções concluídas com sucesso!")
    print("\nAgora execute os testes novamente com o comando: pytest tests/")
    sys.exit(0)
