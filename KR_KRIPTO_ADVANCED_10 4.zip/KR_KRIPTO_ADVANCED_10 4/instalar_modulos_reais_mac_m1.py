#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de integração de módulos reais para KR_KRIPTO_ADVANCED no Mac M1
Este script substitui os stubs por implementações reais dos módulos críticos
"""

import os
import sys
import shutil
import logging
import platform
import subprocess
from pathlib import Path

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("integracao_modulos")

# Verificar ambiente
is_mac_m1 = False
if platform.system() == "Darwin" and ("arm" in platform.machine().lower() or "M1" in platform.processor()):
    is_mac_m1 = True
    logger.info(f"Ambiente Mac M1 detectado: {platform.machine()} / {platform.processor()}")
else:
    logger.warning(f"Este script é destinado ao ambiente Mac M1, mas está sendo executado em: {platform.system()} / {platform.machine()}")

# Definir diretórios
KR_KRIPTO_DIR = "/Volumes/Extreme SSD/KR_KRIPTO_ADVANCED"
SOURCE_DIR = os.path.dirname(os.path.abspath(__file__))
BACKUP_DIR = os.path.join(KR_KRIPTO_DIR, "backup_stubs_" + platform.node() + "_" + 
                         str(int(os.path.getmtime(__file__))))

# Módulos a serem integrados
MODULES = [
    {
        "name": "AttackDetector",
        "source": os.path.join(SOURCE_DIR, "src/intelligence/attack_detector.py"),
        "target_dir": os.path.join(KR_KRIPTO_DIR, "src/intelligence"),
        "target_file": "attack_detector.py",
        "init_files": ["src/intelligence/__init__.py"]
    },
    {
        "name": "NeuralGovernor",
        "source": os.path.join(SOURCE_DIR, "src/intelligence/governance/neural_governance.py"),
        "target_dir": os.path.join(KR_KRIPTO_DIR, "src/intelligence/governance"),
        "target_file": "neural_governance.py",
        "init_files": ["src/intelligence/__init__.py", "src/intelligence/governance/__init__.py"]
    },
    {
        "name": "InstitutionalPatterns",
        "source": os.path.join(SOURCE_DIR, "src/realtime/institutional_patterns.py"),
        "target_dir": os.path.join(KR_KRIPTO_DIR, "src/intelligence"),
        "target_file": "institutional_patterns.py",
        "init_files": ["src/intelligence/__init__.py"]
    },
    {
        "name": "ClusterManager",
        "source": os.path.join(SOURCE_DIR, "src/infrastructure/cluster_manager.py"),
        "target_dir": os.path.join(KR_KRIPTO_DIR, "src/intelligence"),
        "target_file": "cluster_manager.py",
        "init_files": ["src/intelligence/__init__.py"]
    },
    {
        "name": "BookProcessor",
        "source": os.path.join(SOURCE_DIR, "src/core/book_imbalance.py"),
        "target_dir": os.path.join(KR_KRIPTO_DIR, "src/core"),
        "target_file": "book_imbalance.py",
        "init_files": ["src/core/__init__.py"]
    },
    {
        "name": "AmbienteRL",
        "source": os.path.join(SOURCE_DIR, "backup_construtores_20250516_200612/ambiente.py"),
        "target_dir": os.path.join(KR_KRIPTO_DIR, "src/intelligence/reinforcement"),
        "target_file": "ambiente.py",
        "init_files": ["src/intelligence/__init__.py", "src/intelligence/reinforcement/__init__.py"]
    },
    {
        "name": "AgenteRL",
        "source": os.path.join(SOURCE_DIR, "backup_construtores_20250516_200612/agente.py"),
        "target_dir": os.path.join(KR_KRIPTO_DIR, "src/intelligence/reinforcement"),
        "target_file": "agente.py",
        "init_files": ["src/intelligence/__init__.py", "src/intelligence/reinforcement/__init__.py"]
    }
]

# Dependências necessárias para os módulos
DEPENDENCIES = [
    "numpy==1.24.3",
    "pandas==2.0.3",
    "scikit-learn==1.3.0",
    "tensorflow-macos==2.13.0",
    "tensorflow-metal==1.0.0",
    "torch==2.0.1",
    "torchvision==0.15.2",
    "aiohttp==3.8.5",
    "websockets==11.0.3",
    "python-binance==1.0.17",
    "statsmodels==0.14.0",
    "matplotlib==3.7.2",
    "seaborn==0.12.2",
    "numba==0.57.1",
    "gym==0.26.0"
]

def create_backup():
    """Cria backup dos arquivos existentes"""
    logger.info(f"Criando backup em: {BACKUP_DIR}")
    os.makedirs(BACKUP_DIR, exist_ok=True)
    
    for module in MODULES:
        target_path = os.path.join(module["target_dir"], module["target_file"])
        backup_dir = os.path.join(BACKUP_DIR, os.path.dirname(target_path.replace(KR_KRIPTO_DIR + "/", "")))
        backup_path = os.path.join(BACKUP_DIR, target_path.replace(KR_KRIPTO_DIR + "/", ""))
        
        os.makedirs(backup_dir, exist_ok=True)
        
        if os.path.exists(target_path):
            logger.info(f"Fazendo backup de: {target_path} -> {backup_path}")
            shutil.copy2(target_path, backup_path)

def install_dependencies():
    """Instala dependências necessárias"""
    logger.info("Instalando dependências...")
    
    try:
        # Atualizar pip
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pip"], 
                      check=True, capture_output=True)
        
        # Instalar cada dependência
        for dependency in DEPENDENCIES:
            logger.info(f"Instalando: {dependency}")
            result = subprocess.run([sys.executable, "-m", "pip", "install", dependency], 
                                  check=True, capture_output=True)
            logger.debug(f"Resultado: {result.stdout.decode('utf-8')}")
            
        logger.info("Todas as dependências instaladas com sucesso")
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"Erro ao instalar dependências: {e}")
        logger.error(f"Saída: {e.stdout.decode('utf-8')}")
        logger.error(f"Erro: {e.stderr.decode('utf-8')}")
        return False

def create_init_files():
    """Cria arquivos __init__.py necessários"""
    logger.info("Criando arquivos __init__.py...")
    
    # Coletar todos os arquivos init necessários
    init_files = []
    for module in MODULES:
        for init_file in module["init_files"]:
            if init_file not in init_files:
                init_files.append(init_file)
    
    # Criar arquivos init
    for init_file in init_files:
        init_path = os.path.join(KR_KRIPTO_DIR, init_file)
        init_dir = os.path.dirname(init_path)
        
        # Criar diretório se não existir
        os.makedirs(init_dir, exist_ok=True)
        
        # Criar arquivo __init__.py se não existir
        if not os.path.exists(init_path):
            logger.info(f"Criando arquivo: {init_path}")
            with open(init_path, 'w') as f:
                f.write("# Arquivo gerado automaticamente pelo script de integração\n")
        else:
            logger.info(f"Arquivo já existe: {init_path}")

def copy_modules():
    """Copia módulos reais para os diretórios de destino"""
    logger.info("Copiando módulos reais...")
    
    for module in MODULES:
        # Verificar se o arquivo fonte existe
        if not os.path.exists(module["source"]):
            logger.warning(f"Arquivo fonte não encontrado: {module['source']}")
            continue
        
        # Criar diretório de destino se não existir
        os.makedirs(module["target_dir"], exist_ok=True)
        
        # Caminho completo do arquivo de destino
        target_path = os.path.join(module["target_dir"], module["target_file"])
        
        # Copiar arquivo
        logger.info(f"Copiando {module['name']}: {module['source']} -> {target_path}")
        shutil.copy2(module["source"], target_path)

def verify_installation():
    """Verifica se a instalação foi bem-sucedida"""
    logger.info("Verificando instalação...")
    
    success = True
    for module in MODULES:
        target_path = os.path.join(module["target_dir"], module["target_file"])
        if os.path.exists(target_path):
            logger.info(f"✅ Módulo {module['name']} instalado com sucesso: {target_path}")
        else:
            logger.error(f"❌ Falha ao instalar módulo {module['name']}: {target_path}")
            success = False
    
    return success

def main():
    """Função principal"""
    logger.info("Iniciando integração de módulos reais para KR_KRIPTO_ADVANCED no Mac M1")
    
    # Verificar se o diretório KR_KRIPTO_DIR existe
    if not os.path.exists(KR_KRIPTO_DIR):
        logger.error(f"Diretório KR_KRIPTO_ADVANCED não encontrado: {KR_KRIPTO_DIR}")
        logger.error("Por favor, verifique o caminho e tente novamente")
        return 1
    
    # Criar backup
    create_backup()
    
    # Instalar dependências
    if not install_dependencies():
        logger.error("Falha ao instalar dependências. Abortando.")
        return 1
    
    # Criar arquivos __init__.py
    create_init_files()
    
    # Copiar módulos
    copy_modules()
    
    # Verificar instalação
    if verify_installation():
        logger.info("Integração de módulos reais concluída com sucesso!")
        logger.info("Execute o sistema com o comando:")
        logger.info("python3 main.py --use-real-modules --diagnostic")
        return 0
    else:
        logger.error("Falha na integração de módulos reais.")
        logger.error("Verifique os logs acima para mais detalhes.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
