# Instruções para Instalação de Dependências
# Execute este script para instalar todas as dependências necessárias para o projeto KR_KRIPTO_ADVANCED

#!/bin/bash

# Ativar ambiente virtual
echo "Ativando ambiente virtual..."
source venv_m1/bin/activate

# Instalar dependências principais
echo "Instalando dependências principais..."
pip install python-binance python-dotenv prometheus_client

# Instalar dependências para TensorFlow otimizado para Mac M1
echo "Instalando TensorFlow otimizado para Mac M1..."
pip uninstall -y tensorflow
pip install tensorflow-macos
pip install tensorflow-metal  # Suporte para GPU

# Instalar outras dependências
echo "Instalando outras dependências..."
pip install pandas numpy matplotlib seaborn

echo "Instalação concluída!"
echo "Para ativar o ambiente, use: source venv_m1/bin/activate"
