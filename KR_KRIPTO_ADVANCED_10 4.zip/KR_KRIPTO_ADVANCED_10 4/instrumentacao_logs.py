#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Instrumentação de logs para diagnóstico do pipeline de sinais
Este script adiciona logs detalhados ao pipeline de decisão para identificar
por que o sistema não está gerando entradas reais.
"""

import logging
import json
import os
import sys
import time
from datetime import datetime

# Configuração do logger
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("diagnostico_sinais.log"),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger("diagnostico_sinais")

def instrumentar_main():
    """
    Instrumenta o arquivo main.py com logs detalhados para rastrear o fluxo de decisão.
    """
    try:
        # Ler o arquivo main.py
        with open("main.py", "r") as f:
            content = f.read()
        
        # Fazer backup do arquivo original
        with open("main.py.bak", "w") as f:
            f.write(content)
        
        # Adicionar logs detalhados na função processar_dados
        content = content.replace(
            "def processar_dados(df, ativo, intervalo):",
            """def processar_dados(df, ativo, intervalo):
    # Log detalhado para diagnóstico
    logger.debug(f"[DIAGNÓSTICO] Iniciando processamento de dados para {ativo} ({intervalo})")
    logger.debug(f"[DIAGNÓSTICO] DataFrame shape: {df.shape if df is not None else 'None'}")
    logger.debug(f"[DIAGNÓSTICO] Últimos preços: {df['Close'].iloc[-5:].tolist() if df is not None and len(df) >= 5 else 'Dados insuficientes'}")"""
        )
        
        # Adicionar logs após verificação de dados insuficientes
        content = content.replace(
            "return {\"status\": \"SKIP\", \"reason\": \"insufficient_data\"}",
            """logger.warning(f"[DIAGNÓSTICO] Processamento pulado para {ativo} ({intervalo}) - Dados insuficientes")
            return {"status": "SKIP", "reason": "insufficient_data"}"""
        )
        
        # Adicionar logs após detecção de ataques
        content = content.replace(
            "return {\"status\": \"SKIP\", \"reason\": \"attack_detected\"}",
            """logger.warning(f"[DIAGNÓSTICO] Processamento pulado para {ativo} ({intervalo}) - Ataque detectado")
                return {"status": "SKIP", "reason": "attack_detected"}"""
        )
        
        # Adicionar logs para previsão do modelo
        content = content.replace(
            "previsao = resultado.get(\"prediction\", 0.5)",
            """previsao = resultado.get("prediction", 0.5)
            logger.debug(f"[DIAGNÓSTICO] Previsão do modelo para {ativo} ({intervalo}): {previsao:.4f}")"""
        )
        
        # Adicionar logs para validação institucional
        content = content.replace(
            "return {\"status\": \"REJECT\", \"reason\": \"institutional_validation\"}",
            """logger.info(f"[DIAGNÓSTICO] Sinal rejeitado por validação institucional para {ativo} ({intervalo})")
                return {"status": "REJECT", "reason": "institutional_validation"}"""
        )
        
        # Adicionar logs para validação de risco
        content = content.replace(
            "return {\"status\": \"REJECT\", \"reason\": \"risk_management\"}",
            """logger.info(f"[DIAGNÓSTICO] Operação rejeitada por gerenciamento de risco para {ativo} ({intervalo})")
                return {"status": "REJECT", "reason": "risk_management"}"""
        )
        
        # Adicionar logs para decisão de sinal
        content = content.replace(
            "if previsao >= limiar_compra and confianca >= 0.6:",
            """# Log detalhado para diagnóstico de limiares
            logger.debug(f"[DIAGNÓSTICO] Avaliando limiares para {ativo} ({intervalo})")
            logger.debug(f"[DIAGNÓSTICO] Previsão: {previsao:.4f}, Limiar compra: {limiar_compra:.4f}")
            logger.debug(f"[DIAGNÓSTICO] Confiança: {confianca:.4f}, Limiar mínimo: 0.6")
            
            if previsao >= limiar_compra and confianca >= 0.6:"""
        )
        
        # Adicionar logs para cada tipo de sinal
        content = content.replace(
            "sinal = \"BUY\"",
            """sinal = "BUY"
            logger.info(f"[DIAGNÓSTICO] Sinal de COMPRA gerado para {ativo} ({intervalo})")"""
        )
        
        content = content.replace(
            "sinal = \"SELL\"",
            """sinal = "SELL"
            logger.info(f"[DIAGNÓSTICO] Sinal de VENDA gerado para {ativo} ({intervalo})")"""
        )
        
        content = content.replace(
            "sinal = \"HOLD\"",
            """sinal = "HOLD"
            logger.info(f"[DIAGNÓSTICO] Sinal de HOLD gerado para {ativo} ({intervalo})")"""
        )
        
        # Adicionar logs para executar_operacao
        content = content.replace(
            "def executar_operacao(sinal, ativo, preco, stop_loss=None, take_profit=None):",
            """def executar_operacao(sinal, ativo, preco, stop_loss=None, take_profit=None):
    # Log detalhado para diagnóstico
    logger.debug(f"[DIAGNÓSTICO] Tentando executar operação: {sinal} {ativo} @ {preco}")
    logger.debug(f"[DIAGNÓSTICO] Stop Loss: {stop_loss}, Take Profit: {take_profit}")"""
        )
        
        # Adicionar logs para sinal HOLD
        content = content.replace(
            "return {\"status\": \"SKIP\", \"reason\": \"hold_signal\"}",
            """logger.info(f"[DIAGNÓSTICO] Operação pulada para {ativo} - Sinal HOLD")
            return {"status": "SKIP", "reason": "hold_signal"}"""
        )
        
        # Adicionar logs para circuit breaker
        content = content.replace(
            "return {\"status\": \"SKIP\", \"reason\": \"circuit_breaker\"}",
            """logger.warning(f"[DIAGNÓSTICO] Operação pulada para {ativo} - Circuit breaker ativo")
                return {"status": "SKIP", "reason": "circuit_breaker"}"""
        )
        
        # Adicionar logs para execução de ordens
        content = content.replace(
            "resultado = operador.enviar_ordem(",
            """logger.info(f"[DIAGNÓSTICO] Enviando ordem {sinal} para {ativo} @ {preco}")
            resultado = operador.enviar_ordem("""
        )
        
        # Salvar o arquivo modificado
        with open("main_instrumentado.py", "w") as f:
            f.write(content)
        
        logger.info("Arquivo main.py instrumentado com sucesso. Salvo como main_instrumentado.py")
        return True
    except Exception as e:
        logger.error(f"Erro ao instrumentar main.py: {str(e)}")
        return False

def criar_config_permissiva():
    """
    Cria uma versão mais permissiva do arquivo de configuração para testes.
    """
    try:
        # Ler o arquivo config.json
        with open("config.json", "r") as f:
            config = json.load(f)
        
        # Fazer backup do arquivo original
        with open("config.json.bak", "w") as f:
            json.dump(config, f, indent=2)
        
        # Modificar limiares para serem mais permissivos
        config["limiar_compra"] = 0.55  # Reduzir de 0.65 para 0.55
        config["limiar_venda"] = 0.45   # Aumentar de 0.35 para 0.45
        
        # Desativar alguns validadores para teste
        if "strategy_config" in config:
            for strategy_name, strategy in config["strategy_config"].items():
                if "active_validators" in strategy:
                    # Manter apenas um validador para teste
                    strategy["active_validators"] = strategy["active_validators"][:1] if strategy["active_validators"] else []
        
        # Salvar o arquivo modificado
        with open("config_permissivo.json", "w") as f:
            json.dump(config, f, indent=2)
        
        logger.info("Arquivo config.json modificado com sucesso. Salvo como config_permissivo.json")
        return True
    except Exception as e:
        logger.error(f"Erro ao modificar config.json: {str(e)}")
        return False

def criar_script_teste():
    """
    Cria um script de teste que usa a configuração permissiva e o main instrumentado.
    """
    script_content = """#!/usr/bin/env python3
# -*- coding: utf-8 -*-

\"\"\"
Script de teste com configuração permissiva para diagnóstico de entradas
\"\"\"

import os
import sys
import json
import logging
import asyncio
import time
from datetime import datetime

# Configurar logging
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("teste_permissivo.log"),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger("teste_permissivo")

# Importar o main instrumentado
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import main_instrumentado as main

async def teste_permissivo():
    \"\"\"Executa o sistema com configuração permissiva para diagnóstico\"\"\"
    try:
        # Carregar configuração permissiva
        with open("config_permissivo.json", "r") as f:
            config = json.load(f)
        
        logger.info("Iniciando teste com configuração permissiva")
        logger.info(f"Limiar de compra: {config['limiar_compra']}")
        logger.info(f"Limiar de venda: {config['limiar_venda']}")
        
        # Substituir a configuração no main
        main.config = config
        
        # Inicializar componentes
        success = main.inicializar_componentes(config)
        if not success:
            logger.error("Falha ao inicializar componentes")
            return
        
        # Executar o loop principal por tempo limitado (30 minutos)
        logger.info("Iniciando loop principal com timeout de 30 minutos")
        start_time = time.time()
        max_runtime = 30 * 60  # 30 minutos
        
        while time.time() - start_time < max_runtime:
            # Processar cada ativo e intervalo
            for ativo in config["ativos"]:
                for intervalo in config["intervalos"]:
                    try:
                        # Obter dados históricos
                        if "operador_binance" in main.components:
                            operador = main.components["operador_binance"]
                            klines = await operador.obter_klines(ativo, intervalo, limit=100)
                            
                            if klines is not None and len(klines) > 0:
                                # Converter para DataFrame
                                import pandas as pd
                                df = pd.DataFrame(klines)
                                
                                # Processar dados
                                resultado = main.processar_dados(df, ativo, intervalo)
                                
                                # Verificar se gerou sinal
                                if resultado["status"] == "OK" and resultado["sinal"] != "HOLD":
                                    logger.info(f"SINAL GERADO: {resultado['sinal']} para {ativo} ({intervalo})")
                                    
                                    # Tentar executar operação
                                    op_result = main.executar_operacao(
                                        resultado["sinal"],
                                        ativo,
                                        resultado["ultimo_preco"],
                                        resultado.get("stop_loss"),
                                        resultado.get("take_profit")
                                    )
                                    
                                    logger.info(f"Resultado da operação: {op_result}")
                    except Exception as e:
                        logger.error(f"Erro ao processar {ativo} ({intervalo}): {str(e)}")
            
            # Aguardar antes do próximo ciclo
            await asyncio.sleep(60)
            logger.info(f"Tempo decorrido: {(time.time() - start_time) / 60:.1f} minutos")
        
        logger.info("Teste concluído após 30 minutos")
    except Exception as e:
        logger.error(f"Erro durante o teste: {str(e)}")
    finally:
        # Limpar recursos
        if hasattr(main, "components") and "operador_binance" in main.components:
            operador = main.components["operador_binance"]
            if hasattr(operador, "fechar_cliente"):
                await operador.fechar_cliente()

if __name__ == "__main__":
    asyncio.run(teste_permissivo())
"""
    
    try:
        with open("teste_permissivo.py", "w") as f:
            f.write(script_content)
        
        logger.info("Script de teste criado com sucesso: teste_permissivo.py")
        return True
    except Exception as e:
        logger.error(f"Erro ao criar script de teste: {str(e)}")
        return False

def main():
    """Função principal"""
    logger.info("Iniciando instrumentação de logs para diagnóstico")
    
    # Instrumentar main.py
    success_main = instrumentar_main()
    
    # Criar configuração permissiva
    success_config = criar_config_permissiva()
    
    # Criar script de teste
    success_script = criar_script_teste()
    
    if success_main and success_config and success_script:
        logger.info("Instrumentação concluída com sucesso!")
        logger.info("Para executar o teste permissivo, use: python teste_permissivo.py")
    else:
        logger.error("Houve erros durante a instrumentação")

if __name__ == "__main__":
    main()
