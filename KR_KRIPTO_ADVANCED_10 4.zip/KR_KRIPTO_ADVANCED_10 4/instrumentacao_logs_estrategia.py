#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script para adicionar logs detalhados de estratégia contextual ao main.py
Este script adiciona logs específicos para monitorar qual estratégia está sendo ativada
e quais validadores estão sendo aplicados em cada momento.
"""

import os
import sys
import re
import logging
import shutil
from datetime import datetime

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("instrumentacao_estrategia.log"),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger("instrumentacao_estrategia")

def backup_file(file_path):
    """Cria um backup do arquivo original"""
    backup_path = f"{file_path}.bak.{datetime.now().strftime('%Y%m%d%H%M%S')}"
    try:
        shutil.copy2(file_path, backup_path)
        logger.info(f"Backup criado: {backup_path}")
        return True
    except Exception as e:
        logger.error(f"Erro ao criar backup: {str(e)}")
        return False

def instrumentar_context_switcher(file_path):
    """Adiciona logs detalhados ao context switcher"""
    try:
        with open(file_path, 'r') as f:
            content = f.read()
        
        # Padrão para encontrar a função/método do context switcher
        # Procura por funções como select_strategy, switch_context, etc.
        context_switcher_patterns = [
            r'def\s+select_strategy\s*\(.*?\)',
            r'def\s+switch_context\s*\(.*?\)',
            r'def\s+determine_strategy\s*\(.*?\)',
            r'def\s+get_active_strategy\s*\(.*?\)',
            r'class\s+ContextSwitcher\s*\(.*?\):',
        ]
        
        found = False
        for pattern in context_switcher_patterns:
            matches = re.finditer(pattern, content, re.DOTALL)
            for match in matches:
                start_pos = match.start()
                # Encontrar o bloco de código da função
                open_braces = 0
                in_function = False
                function_end = start_pos
                
                for i in range(start_pos, len(content)):
                    if content[i] == '{':
                        open_braces += 1
                        in_function = True
                    elif content[i] == '}':
                        open_braces -= 1
                        if in_function and open_braces == 0:
                            function_end = i
                            break
                    elif content[i] == ':' and not in_function:
                        in_function = True
                    elif in_function and content[i:i+6] == 'return' and content[i-1].isspace():
                        # Encontrar o final da linha de return
                        line_end = content.find('\n', i)
                        if line_end == -1:
                            line_end = len(content)
                        
                        # Extrair o nome da variável que contém a estratégia
                        return_line = content[i:line_end]
                        strategy_var_match = re.search(r'return\s+([a-zA-Z0-9_]+)', return_line)
                        
                        if strategy_var_match:
                            strategy_var = strategy_var_match.group(1)
                            # Adicionar logs antes do return
                            log_code = f'\n        logger.info(f"[ESTRATÉGIA] Ativando estratégia contextual: {{self.current_strategy if hasattr(self, "current_strategy") else {strategy_var}}}")\n'
                            log_code += f'        logger.info(f"[ESTRATÉGIA] Condições de mercado atuais: ADX={{self.adx_value if hasattr(self, "adx_value") else "N/A"}}, ATR={{self.atr_value if hasattr(self, "atr_value") else "N/A"}}")\n'
                            log_code += f'        logger.info(f"[ESTRATÉGIA] Validadores ativos: {{{strategy_var}.get("active_validators", [])}}")\n'
                            
                            # Inserir os logs antes do return
                            content = content[:i] + log_code + content[i:]
                            found = True
                            break
                
                if found:
                    break
            
            if found:
                break
        
        if not found:
            logger.warning("Não foi possível encontrar o context switcher no código. Tentando abordagem alternativa...")
            
            # Abordagem alternativa: procurar por padrões de uso de estratégia
            strategy_patterns = [
                r'(strategy_config\[[\'"](.*?)[\'"]\])',
                r'(self\.current_strategy\s*=\s*[\'"](.*?)[\'"])',
                r'(active_strategy\s*=\s*[\'"](.*?)[\'"])',
            ]
            
            for pattern in strategy_patterns:
                matches = re.finditer(pattern, content, re.DOTALL)
                for match in matches:
                    full_match = match.group(1)
                    # Encontrar o final da linha
                    line_start = content.rfind('\n', 0, match.start()) + 1
                    line_end = content.find('\n', match.end())
                    if line_end == -1:
                        line_end = len(content)
                    
                    # Adicionar log após a linha
                    log_code = f'\n        logger.info(f"[ESTRATÉGIA] Ativando estratégia contextual: {{{full_match}}}")\n'
                    log_code += f'        logger.info(f"[ESTRATÉGIA] Validadores ativos: {{{full_match}.get("active_validators", [])}}")\n'
                    
                    # Inserir os logs após a linha
                    content = content[:line_end] + log_code + content[line_end:]
                    found = True
                    break
                
                if found:
                    break
        
        if not found:
            logger.warning("Não foi possível encontrar padrões de estratégia no código. Adicionando logs gerais...")
            
            # Adicionar imports no início do arquivo
            import_logging = "import logging\nlogger = logging.getLogger(__name__)\n\n"
            if "import logging" not in content:
                content = import_logging + content
            
            # Adicionar função de log de estratégia
            log_function = """
def log_strategy_info(strategy_name, strategy_config):
    # Log detailed information about the active strategy
    logger.info(f"[ESTRATÉGIA] Ativando estratégia contextual: {strategy_name}")
    logger.info(f"[ESTRATÉGIA] Limiares: Compra={strategy_config.get('limiar_compra', 'N/A')}, Venda={strategy_config.get('limiar_venda', 'N/A')}")
    logger.info(f"[ESTRATÉGIA] Validadores ativos: {strategy_config.get('active_validators', [])}")
    return strategy_config
"""
            # Adicionar a função após os imports
            first_def_pos = content.find("def ")
            if first_def_pos > 0:
                content = content[:first_def_pos] + log_function + content[first_def_pos:]
            else:
                content += "\n" + log_function
        
        # Salvar o arquivo modificado
        with open(file_path, 'w') as f:
            f.write(content)
        
        logger.info(f"Arquivo {file_path} instrumentado com logs de estratégia contextual")
        return True
    
    except Exception as e:
        logger.error(f"Erro ao instrumentar context switcher: {str(e)}")
        return False

def main():
    """Função principal"""
    logger.info("Iniciando instrumentação de logs de estratégia contextual")
    
    # Determinar o caminho do arquivo main.py
    main_path = os.path.join("/Volumes/Extreme SSD/KR_KRIPTO_ADVANCED", "main.py")
    if not os.path.exists(main_path):
        logger.error(f"Arquivo main.py não encontrado em {main_path}")
        return False
    
    # Criar backup do arquivo original
    if not backup_file(main_path):
        logger.error("Falha ao criar backup. Abortando instrumentação.")
        return False
    
    # Instrumentar o context switcher
    if instrumentar_context_switcher(main_path):
        logger.info("Instrumentação de logs de estratégia contextual concluída com sucesso!")
        logger.info("Agora você poderá ver nos logs qual estratégia contextual está sendo ativada")
        return True
    else:
        logger.error("Falha ao instrumentar logs de estratégia contextual")
        return False

if __name__ == "__main__":
    main()
