#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de integração manual de módulos reais para KR_KRIPTO_ADVANCED no Mac M1
Este script fornece instruções para copiar manualmente os módulos reais
"""

import os
import sys
import logging
import platform
from pathlib import Path

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("integracao_manual")

# Verificar ambiente
is_mac_m1 = False
if platform.system() == "Darwin" and ("arm" in platform.machine().lower() or "M1" in platform.processor()):
    is_mac_m1 = True
    logger.info(f"Ambiente Mac M1 detectado: {platform.machine()} / {platform.processor()}")
else:
    logger.warning(f"Este script é destinado ao ambiente Mac M1, mas está sendo executado em: {platform.system()} / {platform.machine()}")

# Definir diretórios
KR_KRIPTO_DIR = "/Volumes/Extreme SSD/KR_KRIPTO_ADVANCED"
ZIP_EXTRACT_DIR = input("Digite o caminho completo onde o ZIP foi extraído: ")

# Verificar se o diretório KR_KRIPTO_DIR existe
if not os.path.exists(KR_KRIPTO_DIR):
    logger.error(f"Diretório KR_KRIPTO_ADVANCED não encontrado: {KR_KRIPTO_DIR}")
    logger.error("Por favor, verifique o caminho e tente novamente")
    sys.exit(1)

# Verificar se o diretório ZIP_EXTRACT_DIR existe
if not os.path.exists(ZIP_EXTRACT_DIR):
    logger.error(f"Diretório de extração do ZIP não encontrado: {ZIP_EXTRACT_DIR}")
    logger.error("Por favor, verifique o caminho e tente novamente")
    sys.exit(1)

# Módulos a serem integrados
MODULES = [
    {
        "name": "AttackDetector",
        "source": os.path.join(ZIP_EXTRACT_DIR, "KR_KRIPTO_ADVANCED_COPIA/src/intelligence/attack_detector.py"),
        "target_dir": os.path.join(KR_KRIPTO_DIR, "src/intelligence"),
        "target_file": "attack_detector.py",
        "init_files": ["src/intelligence/__init__.py"]
    },
    {
        "name": "NeuralGovernor",
        "source": os.path.join(ZIP_EXTRACT_DIR, "KR_KRIPTO_ADVANCED_COPIA/src/intelligence/governance/neural_governance.py"),
        "target_dir": os.path.join(KR_KRIPTO_DIR, "src/intelligence/governance"),
        "target_file": "neural_governance.py",
        "init_files": ["src/intelligence/__init__.py", "src/intelligence/governance/__init__.py"]
    },
    {
        "name": "InstitutionalPatterns",
        "source": os.path.join(ZIP_EXTRACT_DIR, "KR_KRIPTO_ADVANCED_COPIA/src/realtime/institutional_patterns.py"),
        "target_dir": os.path.join(KR_KRIPTO_DIR, "src/intelligence"),
        "target_file": "institutional_patterns.py",
        "init_files": ["src/intelligence/__init__.py"]
    },
    {
        "name": "ClusterManager",
        "source": os.path.join(ZIP_EXTRACT_DIR, "KR_KRIPTO_ADVANCED_COPIA/src/infrastructure/cluster_manager.py"),
        "target_dir": os.path.join(KR_KRIPTO_DIR, "src/intelligence"),
        "target_file": "cluster_manager.py",
        "init_files": ["src/intelligence/__init__.py"]
    },
    {
        "name": "BookProcessor",
        "source": os.path.join(ZIP_EXTRACT_DIR, "KR_KRIPTO_ADVANCED_COPIA/src/core/book_imbalance.py"),
        "target_dir": os.path.join(KR_KRIPTO_DIR, "src/core"),
        "target_file": "book_imbalance.py",
        "init_files": ["src/core/__init__.py"]
    },
    {
        "name": "AmbienteRL",
        "source": os.path.join(ZIP_EXTRACT_DIR, "KR_KRIPTO_ADVANCED_COPIA/backup_construtores_20250516_200612/ambiente.py"),
        "target_dir": os.path.join(KR_KRIPTO_DIR, "src/intelligence/reinforcement"),
        "target_file": "ambiente.py",
        "init_files": ["src/intelligence/__init__.py", "src/intelligence/reinforcement/__init__.py"]
    },
    {
        "name": "AgenteRL",
        "source": os.path.join(ZIP_EXTRACT_DIR, "KR_KRIPTO_ADVANCED_COPIA/backup_construtores_20250516_200612/agente.py"),
        "target_dir": os.path.join(KR_KRIPTO_DIR, "src/intelligence/reinforcement"),
        "target_file": "agente.py",
        "init_files": ["src/intelligence/__init__.py", "src/intelligence/reinforcement/__init__.py"]
    }
]

# Dependências necessárias para os módulos
DEPENDENCIES = [
    "numpy==1.24.3",
    "pandas==2.0.3",
    "scikit-learn==1.3.0",
    "tensorflow-macos==2.13.0",
    "tensorflow-metal==1.0.0",
    "torch==2.0.1",
    "torchvision==0.15.2",
    "aiohttp==3.8.5",
    "websockets==11.0.3",
    "python-binance==1.0.17",
    "statsmodels==0.14.0",
    "matplotlib==3.7.2",
    "seaborn==0.12.2",
    "numba==0.57.1",
    "gym==0.26.0"
]

def print_manual_instructions():
    """Imprime instruções para instalação manual"""
    print("\n" + "="*80)
    print("INSTRUÇÕES PARA INSTALAÇÃO MANUAL DOS MÓDULOS REAIS")
    print("="*80)
    
    print("\n1. CRIAR DIRETÓRIOS NECESSÁRIOS")
    print("-"*50)
    for module in MODULES:
        print(f"mkdir -p {module['target_dir']}")
    
    print("\n2. CRIAR ARQUIVOS __init__.py")
    print("-"*50)
    init_files = []
    for module in MODULES:
        for init_file in module["init_files"]:
            if init_file not in init_files:
                init_files.append(init_file)
    
    for init_file in init_files:
        init_path = os.path.join(KR_KRIPTO_DIR, init_file)
        print(f"touch {init_path}")
    
    print("\n3. COPIAR MÓDULOS")
    print("-"*50)
    for module in MODULES:
        print(f"cp {module['source']} {os.path.join(module['target_dir'], module['target_file'])}")
    
    print("\n4. INSTALAR DEPENDÊNCIAS")
    print("-"*50)
    print("pip3 install --upgrade pip")
    for dependency in DEPENDENCIES:
        print(f"pip3 install {dependency}")
    
    print("\n5. VERIFICAR INSTALAÇÃO")
    print("-"*50)
    print("python3 main.py --use-real-modules --diagnostic")
    
    print("\n" + "="*80)
    print("NOTA: Execute estes comandos manualmente no terminal do Mac M1.")
    print("Se algum comando falhar, verifique permissões e caminhos.")
    print("="*80 + "\n")

def verify_files_exist():
    """Verifica se os arquivos fonte existem"""
    all_exist = True
    print("\nVerificando arquivos fonte...")
    
    for module in MODULES:
        if os.path.exists(module["source"]):
            print(f"✅ {module['name']}: {module['source']}")
        else:
            print(f"❌ {module['name']}: {module['source']} (NÃO ENCONTRADO)")
            all_exist = False
    
    return all_exist

def main():
    """Função principal"""
    logger.info("Iniciando verificação para integração manual de módulos reais")
    
    # Verificar se os arquivos fonte existem
    files_exist = verify_files_exist()
    if not files_exist:
        logger.error("Alguns arquivos fonte não foram encontrados.")
        logger.error("Verifique o caminho de extração do ZIP e tente novamente.")
        return 1
    
    # Imprimir instruções manuais
    print_manual_instructions()
    
    logger.info("Instruções para integração manual geradas com sucesso.")
    logger.info("Execute os comandos acima manualmente no terminal do Mac M1.")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
