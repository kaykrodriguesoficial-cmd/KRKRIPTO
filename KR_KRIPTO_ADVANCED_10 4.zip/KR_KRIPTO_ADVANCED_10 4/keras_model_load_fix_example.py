#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
keras_model_load_fix_example.py

Este script demonstra uma abordagem para carregar um modelo Keras (.h5)
que foi salvo com uma versão diferente do TensorFlow/Keras, resultando no erro:
'Unrecognized keyword arguments: ["batch_shape"]' ao tentar desserializar InputLayer.

A solução envolve definir a arquitetura do modelo usando a sintaxe da sua
versão atual do TensorFlow/Keras e, em seguida, carregar apenas os pesos
do arquivo .h5 original.

Versões do TensorFlow/Keras do usuário (exemplo): 2.14.0
"""

# Certifique-se de que seu ambiente virtual com TensorFlow/Keras está ativado
# pip install tensorflow==2.14.0  (ou a versão que você tem)

import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, LayerNormalization, Dropout, MultiHeadAttention, GlobalAveragePooling1D, Add
import numpy as np
import os

# --- ETAPA 1: Defina a arquitetura do seu modelo original --- 
# A arquitetura abaixo foi extraída de src/intelligence/modelos_treinamento/treinar_futuro_transformer_v1.py
# Esta deve ser a arquitetura do seu modelo 'modelo_transformer_futuro.h5'.

def build_your_model_architecture(input_shape):
    """
    Esta função define a arquitetura do modelo 'modelo_transformer_futuro.h5'
    conforme encontrado em src/intelligence/modelos_treinamento/treinar_futuro_transformer_v1.py.
    Use 'input_shape' para a camada de entrada.
    """
    inp = Input(shape=input_shape, name="input_layer_novo") 
    x = LayerNormalization(name="layer_norm_novo")(inp)
    # No arquivo original, a key_dim era 16, mas MultiHeadAttention em TF 2.14 espera que key_dim seja divisível pelo num_features da entrada se não for None.
    # Se input_shape[-1] (número de features) for 1, key_dim=16 pode causar problemas.
    # Se o número de features for diferente de 1, key_dim pode precisar ser ajustado ou pode funcionar como está.
    # Para maior segurança, e se o número de features for pequeno, pode-se tentar key_dim=input_shape[-1] ou um valor compatível.
    # Vamos manter key_dim=16 por enquanto, como no original, mas isso pode ser um ponto de ajuste.
    x = MultiHeadAttention(num_heads=4, key_dim=16, name="multi_head_attention_novo")(x, x)
    x = Dropout(0.1, name="dropout_novo")(x)
    x = Add(name="add_novo")([inp, x]) # A camada Add espera uma lista de tensores
    x = GlobalAveragePooling1D(name="global_avg_pool_novo")(x)

    direcao_out = Dense(2, activation='softmax', name='direcao_novo')(x)
    forca_out = Dense(1, activation='sigmoid', name='forca_novo')(x)

    model = Model(inputs=inp, outputs=[direcao_out, forca_out])
    print("Nova arquitetura do modelo construída (baseada em treinar_futuro_transformer_v1.py):")
    model.summary() # Imprime o resumo do modelo para depuração
    return model

# --- ETAPA 2: Especifique o caminho para o seu arquivo .h5 original --- 
OLD_MODEL_H5_PATH = "models/modelo_transformer_futuro.h5"

# --- ETAPA 3: Defina o input_shape esperado pelo seu modelo --- 
# No script de treinamento original (treinar_futuro_transformer_v1.py), o input_shape é (X_train.shape[1], 1).
# X_train.shape[1] é o número de features do seu dataset.
# ***** POR FAVOR, SUBSTITUA O '20' ABAIXO PELO NÚMERO CORRETO DE FEATURES DO SEU MODELO *****
# Se você não souber, verifique o número de colunas em X_train no script de treinamento.
NUMBER_OF_FEATURES = 5 # <--- ATENÇÃO: AJUSTE ESTE VALOR!
YOUR_MODEL_INPUT_SHAPE = (NUMBER_OF_FEATURES, 1)

# --- ETAPA 4: Construa a nova arquitetura e carregue os pesos --- 
def load_model_with_weights_only(model_architecture_fn, input_shape, weights_path):
    if not os.path.exists(weights_path):
        print(f"ERRO: Arquivo de pesos não encontrado em: {weights_path}")
        print("Por favor, verifique o caminho para 'modelo_transformer_futuro.h5'.")
        print("Ele deve estar em uma pasta 'models' na raiz do seu projeto KR_KRIPTO_ADVANCED,")
        print("e este script deve ser executado da raiz do projeto KR_KRIPTO_ADVANCED.")
        return None

    new_model = model_architecture_fn(input_shape)

    try:
        print(f"Tentando carregar pesos de: {weights_path}")
        new_model.load_weights(weights_path)
        print("Pesos carregados com sucesso na nova arquitetura do modelo!")
        return new_model
    except Exception as e:
        print(f"ERRO ao carregar os pesos na nova arquitetura: {e}")
        print("Verifique se a arquitetura definida em 'build_your_model_architecture' corresponde EXATAMENTE")
        print("à arquitetura do modelo salvo em 'modelo_transformer_futuro.h5' (número de camadas, tipos, unidades, etc.).")
        print("Certifique-se também que YOUR_MODEL_INPUT_SHAPE está correto.")
        return None

if __name__ == "__main__":
    print(f"Versão do TensorFlow: {tf.__version__}")
    print(f"Usando YOUR_MODEL_INPUT_SHAPE: {YOUR_MODEL_INPUT_SHAPE}. Se o número de features (primeiro elemento) não for {NUMBER_OF_FEATURES}, ajuste a variável NUMBER_OF_FEATURES no script.")

    loaded_model = load_model_with_weights_only(
        build_your_model_architecture,
        YOUR_MODEL_INPUT_SHAPE,
        OLD_MODEL_H5_PATH
    )

    if loaded_model:
        print("Modelo carregado e pronto para uso (ex: predição).")
        # Exemplo de como fazer uma predição (com dados dummy)
        # Crie dados de entrada dummy com o shape esperado (incluindo o batch size, ex: 1)
        dummy_input_data = np.random.rand(1, YOUR_MODEL_INPUT_SHAPE[0], YOUR_MODEL_INPUT_SHAPE[1])
        
        try:
            predictions = loaded_model.predict(dummy_input_data)
            print(f"Predição de exemplo (com dados dummy) - Direção: {predictions[0]}, Força: {predictions[1]}")
        except Exception as e:
            print(f"Erro ao tentar fazer predição com o modelo carregado: {e}")
    else:
        print("Falha ao carregar o modelo.")

    print("\nLembre-se de AJUSTAR a variável 'NUMBER_OF_FEATURES' no topo deste script para o número correto de features do seu modelo.")

