#!/bin/bash
echo "🧹 Limpando cache do Python..."
find . -name "*.pyc" -delete
find . -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
echo "✅ Cache Python limpo!"
