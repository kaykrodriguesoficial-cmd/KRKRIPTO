# Backup do atual
cp main.py main_backup_complexo.py

# Criar versão limpa
cat > main.py << 'EOF'
#!/usr/bin/env python3
"""
KR_KRIPTO_ADVANCED - Sistema Premium 20 Ativos
Versão Limpa e Corrigida
"""

import json
import asyncio
import logging
import argparse
from datetime import datetime

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def carregar_config(arquivo="config.json"):
    """Carrega configuração com validação"""
    try:
        with open(arquivo, 'r') as f:
            config = json.load(f)
        
        symbols = config.get('symbols', [])
        ativos = config.get('ativos', {})
        
        logger.critical(f"🔍 CONFIG CARREGADO: {len(symbols)} symbols, {len(ativos)} ativos")
        
        if len(symbols) != 20:
            logger.error(f"❌ ERRO: Esperado 20 symbols, encontrado {len(symbols)}")
            return None
        
        if len(ativos) != 20:
            logger.error(f"❌ ERRO: Esperado 20 ativos, encontrado {len(ativos)}")
            return None
        
        logger.critical("✅ CONFIGURAÇÃO VALIDADA: 20 ativos confirmados")
        return config
        
    except Exception as e:
        logger.error(f"❌ ERRO ao carregar config: {e}")
        return None

async def processar_ativo(symbol, config_ativo):
    """Processa um ativo individual"""
    try:
        logger.info(f"🎯 DEBUG: FUNÇÃO processar_ativo CHAMADA PARA: {symbol}")
        
        # Simular processamento (substitua pela lógica real)
        await asyncio.sleep(0.1)
        
        logger.info(f"✅ {symbol} processado com sucesso")
        return True
        
    except Exception as e:
        logger.error(f"❌ Erro processando {symbol}: {e}")
        return False

async def main_async():
    """Função principal assíncrona"""
    try:
        logger.critical("🚀 INICIANDO SISTEMA PREMIUM 20 ATIVOS")
        logger.critical("=" * 80)
        
        # Carregar configuração
        config = carregar_config()
        if not config:
            logger.error("❌ FALHA ao carregar configuração")
            return False
        
        # Obter ativos
        ativos = config.get('ativos', {})
        logger.critical(f"📊 Total de ativos: {len(ativos)}")
        
        if len(ativos) == 0:
            logger.critical("🚨 ERRO: NENHUM ATIVO ENCONTRADO!")
            return False
        
        # Listar todos os ativos
        logger.critical("🚀 20 ATIVOS PREMIUM CARREGADOS:")
        for i, (symbol, config_ativo) in enumerate(ativos.items(), 1):
            status = "ATIVO" if config_ativo.get('ativo', True) else "INATIVO"
            logger.critical(f"   {i:2d}. {symbol:<12} - {status}")
        
        # Processar ativos ativos
        tarefas = []
        for symbol, config_ativo in ativos.items():
            if config_ativo.get('ativo', True):
                tarefa = asyncio.create_task(processar_ativo(symbol, config_ativo))
                tarefas.append(tarefa)
        
        logger.critical(f"🚀 EXECUTANDO {len(tarefas)} TAREFAS CONCORRENTEMENTE")
        
        if tarefas:
            resultados = await asyncio.gather(*tarefas, return_exceptions=True)
            sucessos = sum(1 for r in resultados if r is True)
            logger.critical(f"✅ {sucessos}/{len(tarefas)} TAREFAS CONCLUÍDAS COM SUCESSO")
        
        logger.critical("🎉 SISTEMA 20 ATIVOS FUNCIONANDO CORRETAMENTE!")
        return True
        
    except Exception as e:
        logger.error(f"❌ Erro em main_async: {e}")
        return False

def main():
    """Ponto de entrada principal"""
    parser = argparse.ArgumentParser(description="KR_KRIPTO_ADVANCED - Sistema Premium 20 Ativos")
    parser.add_argument("--debug", action="store_true", help="Ativa logging DEBUG")
    parser.add_argument("--verbose", action="store_true", help="Ativa logging detalhado")
    
    args = parser.parse_args()
    
    if args.debug or args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
        logger.info("🔍 Modo DEBUG ativado")
    
    # Executar sistema
    try:
        logger.critical("🎯 INICIANDO KR_KRIPTO_ADVANCED")
        resultado = asyncio.run(main_async())
        
        if resultado:
            logger.critical("✅ SISTEMA FINALIZADO COM SUCESSO")
        else:
            logger.critical("❌ SISTEMA FINALIZADO COM ERROS")
            
    except KeyboardInterrupt:
        logger.info("⏹️  Sistema interrompido pelo usuário")
    except Exception as e:
        logger.error(f"❌ Erro fatal: {e}")

if __name__ == "__main__":
    main()

