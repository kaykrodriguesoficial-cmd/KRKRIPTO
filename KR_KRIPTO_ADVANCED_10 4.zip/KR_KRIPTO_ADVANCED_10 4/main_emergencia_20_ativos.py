#!/usr/bin/env python3
import json
import asyncio
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def main():
    # FORÇAR carregamento direto da configuração
    logger.critical("🚨 CARREGAMENTO FORÇADO DA CONFIGURAÇÃO")
    
    with open('config.json', 'r') as f:
        config = json.load(f)
    
    symbols = config.get('symbols', [])
    ativos = config.get('ativos', {})
    
    logger.critical(f"✅ FORÇADO: {len(symbols)} symbols carregados")
    logger.critical(f"✅ FORÇADO: {len(ativos)} ativos carregados")
    
    if len(symbols) == 20:
        logger.critical("🎉 SUCESSO: 20 ativos carregados corretamente!")
        for i, symbol in enumerate(symbols, 1):
            logger.critical(f"   {i:2d}. {symbol}")
    else:
        logger.error(f"❌ ERRO: Apenas {len(symbols)} symbols encontrados")

if __name__ == "__main__":
    asyncio.run(main())
