#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
KR_KRIPTO_ADVANCED - Sistema de Trading com Inteligência Artificial Avançada

Este é o módulo principal que coordena todos os componentes do sistema,
agora com implementações reais de IA em vez de stubs.

Versão: 4.0.0 - Inteligência Avançada Integrada
Data: Agosto 2025

Principais melhorias:
- ModelLoader real com suporte a múltiplos formatos
- NeuralGovernor com seleção inteligente de modelos
- Reinforcement Learning com agentes DQN/PPO
- Análise de padrões institucionais em tempo real
- Integração inteligente de todos os componentes
"""

import os
import sys
import json
import time
import logging
import argparse
import asyncio
import datetime
import traceback
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('kr_kripto_intelligent.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("kr_kripto_intelligent_main")

# Importar adaptador inteligente
try:
    from intelligent_main_adapter import create_intelligent_components, IntelligentMainAdapter
    INTELLIGENT_ADAPTER_AVAILABLE = True
    logger.info("Adaptador inteligente importado com sucesso")
except ImportError as e:
    INTELLIGENT_ADAPTER_AVAILABLE = False
    logger.error(f"Adaptador inteligente não disponível: {e}")

# Importações básicas necessárias
try:
    from binance import AsyncClient
    from binance.exceptions import BinanceAPIException, BinanceRequestException
    BINANCE_AVAILABLE = True
except ImportError:
    BINANCE_AVAILABLE = False
    logger.error("Biblioteca python-binance não encontrada")

try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False
    logger.error("Pandas não disponível")

# Variáveis globais
intelligent_components = {}
intelligent_adapter = None

class IntelligentKriptoSystem:
    """
    Sistema principal com inteligência artificial avançada integrada.
    """
    
    def __init__(self, config_path: str = "config.json"):
        """
        Inicializa o sistema inteligente.
        
        Args:
            config_path: Caminho para o arquivo de configuração
        """
        self.config_path = config_path
        self.config = self._load_config()
        self.components = {}
        self.is_initialized = False
        self.client_binance = None
        
        logger.info("Sistema KR_KRIPTO_ADVANCED Inteligente inicializado")
    
    def _load_config(self) -> Dict[str, Any]:
        """Carrega configuração do arquivo JSON."""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
            logger.info(f"Configuração carregada de {self.config_path}")
            return config
        except Exception as e:
            logger.error(f"Erro ao carregar configuração: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Retorna configuração padrão."""
        return {
            "modo_simulacao": False,
            "executar_ordens_reais": True,
            "ativos": {
                "BTCUSDT": {"ativo": True, "intervalo": "1h"},
                "ETHUSDT": {"ativo": True, "intervalo": "1h"}
            }
        }
    
    async def initialize_system(self) -> bool:
        """
        Inicializa todo o sistema com componentes inteligentes.
        
        Returns:
            bool: True se inicialização foi bem-sucedida
        """
        try:
            logger.info("=== INICIALIZANDO SISTEMA INTELIGENTE ===")
            
            # 1. Inicializar componentes inteligentes
            if INTELLIGENT_ADAPTER_AVAILABLE:
                logger.info("Inicializando componentes de IA avançada...")
                global intelligent_components, intelligent_adapter
                
                intelligent_components = await create_intelligent_components(self.config_path)
                intelligent_adapter = intelligent_components.get('adapter')
                
                if intelligent_components:
                    logger.info("✅ Componentes inteligentes inicializados com sucesso!")
                    
                    # Log dos componentes disponíveis
                    available_components = [k for k, v in intelligent_components.items() if v is not None]
                    logger.info(f"Componentes disponíveis: {available_components}")
                else:
                    logger.warning("⚠️ Componentes inteligentes não puderam ser inicializados completamente")
            else:
                logger.error("❌ Adaptador inteligente não disponível, usando stubs")
            
            # 2. Inicializar cliente Binance
            success_binance = await self._initialize_binance_client()
            if not success_binance:
                logger.error("❌ Falha na inicialização do cliente Binance")
                return False
            
            # 3. Configurar componentes do sistema
            self._setup_system_components()
            
            self.is_initialized = True
            logger.info("✅ Sistema inteligente inicializado com sucesso!")
            return True
            
        except Exception as e:
            logger.error(f"❌ Erro na inicialização do sistema: {e}")
            logger.error(traceback.format_exc())
            return False
    
    async def _initialize_binance_client(self) -> bool:
        """Inicializa cliente Binance."""
        try:
            if not BINANCE_AVAILABLE:
                logger.error("Biblioteca Binance não disponível")
                return False
            
            api_key = self.config.get("binance_api_key")
            api_secret = self.config.get("binance_api_secret")
            testnet = self.config.get("testnet", False)
            
            if not api_key or not api_secret:
                logger.error("Credenciais Binance não configuradas")
                return False
            
            self.client_binance = AsyncClient(api_key, api_secret, testnet=testnet)
            
            # Testar conexão
            await asyncio.wait_for(self.client_binance.ping(), timeout=10)
            logger.info("✅ Cliente Binance inicializado e conectado")
            return True
            
        except Exception as e:
            logger.error(f"Erro na inicialização do cliente Binance: {e}")
            return False
    
    def _setup_system_components(self):
        """Configura componentes do sistema."""
        try:
            # Usar componentes inteligentes se disponíveis
            if intelligent_components:
                self.components.update(intelligent_components)
                logger.info("Usando componentes inteligentes")
            else:
                logger.warning("Usando componentes stub")
                self._setup_stub_components()
            
        except Exception as e:
            logger.error(f"Erro na configuração dos componentes: {e}")
            self._setup_stub_components()
    
    def _setup_stub_components(self):
        """Configura componentes stub como fallback."""
        class ComponentStub:
            pass
        
        self.components = {
            'model_loader': ComponentStub(),
            'neural_governor': ComponentStub(),
            'agente_rl': ComponentStub(),
            'ambiente_rl': ComponentStub()
        }
    
    async def run_main_loop(self):
        """
        Executa o loop principal do sistema com inteligência avançada.
        """
        try:
            logger.info("=== INICIANDO LOOP PRINCIPAL INTELIGENTE ===")
            
            if not self.is_initialized:
                logger.error("Sistema não inicializado")
                return
            
            iteration = 0
            
            while True:
                iteration += 1
                start_time = time.time()
                
                logger.info(f"🔄 ITERAÇÃO {iteration} - PROCESSAMENTO INTELIGENTE")
                
                try:
                    # Processar cada ativo configurado
                    ativos = self.config.get("ativos", {})
                    
                    for ativo, config_ativo in ativos.items():
                        if config_ativo.get("ativo", False):
                            await self._process_asset_intelligently(ativo, config_ativo)
                    
                    # Calcular tempo de processamento
                    processing_time = time.time() - start_time
                    logger.info(f"⏱️ Iteração {iteration} concluída em {processing_time:.2f} segundos")
                    
                    # Aguardar próxima iteração (60 segundos por padrão)
                    wait_time = max(0, 60 - processing_time)
                    if wait_time > 0:
                        logger.info(f"⏳ Aguardando {wait_time:.2f} segundos para próxima iteração...")
                        await asyncio.sleep(wait_time)
                
                except KeyboardInterrupt:
                    logger.info("🛑 Interrupção manual detectada")
                    break
                except Exception as e:
                    logger.error(f"❌ Erro na iteração {iteration}: {e}")
                    logger.error(traceback.format_exc())
                    await asyncio.sleep(5)  # Aguardar antes de tentar novamente
            
        except Exception as e:
            logger.error(f"❌ Erro no loop principal: {e}")
            logger.error(traceback.format_exc())
        finally:
            await self._shutdown_system()
    
    async def _process_asset_intelligently(self, ativo: str, config_ativo: Dict[str, Any]):
        """
        Processa um ativo usando inteligência artificial avançada.
        
        Args:
            ativo: Símbolo do ativo (ex: 'BTCUSDT')
            config_ativo: Configuração específica do ativo
        """
        try:
            logger.info(f"🧠 Processamento inteligente iniciado para {ativo}")
            
            # 1. Obter dados de mercado
            df_klines = await self._get_market_data(ativo, config_ativo.get("intervalo", "1h"))
            
            if df_klines is None or (PANDAS_AVAILABLE and df_klines.empty):
                logger.warning(f"⚠️ Dados insuficientes para {ativo}")
                return
            
            logger.info(f"📊 Dados obtidos: {len(df_klines)} klines para {ativo}")
            
            # 2. Gerar predição inteligente
            prediction_result = await self._generate_intelligent_prediction(ativo, df_klines)
            
            predicao = prediction_result.get('predicao', 0.5)
            confianca = prediction_result.get('confianca', 0.5)
            metadata = prediction_result.get('metadata', {})
            
            logger.info(f"🎯 Predição inteligente para {ativo}: {predicao:.4f} (confiança: {confianca:.4f})")
            
            # 3. Determinar ação de trading
            acao = self._determine_trading_action(predicao, confianca, config_ativo)
            
            logger.critical(f"🚨 SINAL INTELIGENTE para {ativo}: {acao} | Predição: {predicao:.4f} | Confiança: {confianca:.4f}")
            
            # 4. Executar ação se necessário
            if acao != "MANTER" and not self.config.get("modo_simulacao", True):
                await self._execute_trading_action(ativo, acao, config_ativo)
            
            # 5. Log de metadados se disponível
            if metadata:
                logger.debug(f"📋 Metadados da predição para {ativo}: {metadata}")
            
        except Exception as e:
            logger.error(f"❌ Erro no processamento inteligente de {ativo}: {e}")
            logger.error(traceback.format_exc())
    
    async def _get_market_data(self, ativo: str, intervalo: str = "1h", limite: int = 100):
        """
        Obtém dados de mercado da Binance.
        
        Args:
            ativo: Símbolo do ativo
            intervalo: Timeframe
            limite: Número de klines
            
        Returns:
            DataFrame com dados ou None se erro
        """
        try:
            if not self.client_binance:
                logger.error("Cliente Binance não inicializado")
                return None
            
            # Obter klines da Binance
            klines = await asyncio.wait_for(
                self.client_binance.get_klines(symbol=ativo, interval=intervalo, limit=limite),
                timeout=10
            )
            
            if not klines or not PANDAS_AVAILABLE:
                return None
            
            # Converter para DataFrame
            df = pd.DataFrame(klines, columns=[
                'timestamp', 'open', 'high', 'low', 'close', 'volume',
                'close_time', 'quote_asset_volume', 'number_of_trades',
                'taker_buy_base_asset_volume', 'taker_buy_quote_asset_volume', 'ignore'
            ])
            
            # Converter tipos
            numeric_columns = ['open', 'high', 'low', 'close', 'volume']
            for col in numeric_columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
            
            return df
            
        except Exception as e:
            logger.error(f"Erro ao obter dados de mercado para {ativo}: {e}")
            return None
    
    async def _generate_intelligent_prediction(self, ativo: str, df_klines) -> Dict[str, Any]:
        """
        Gera predição usando inteligência artificial avançada.
        
        Args:
            ativo: Símbolo do ativo
            df_klines: DataFrame com dados históricos
            
        Returns:
            Dict com predição, confiança e metadados
        """
        try:
            # Usar adaptador inteligente se disponível
            if intelligent_adapter and intelligent_adapter.is_initialized:
                logger.info(f"🧠 Usando IA avançada para predição de {ativo}")
                return await intelligent_adapter.generate_intelligent_prediction(ativo, df_klines)
            
            # Fallback: usar ModelLoader se disponível
            model_loader = self.components.get('model_loader')
            if model_loader and hasattr(model_loader, 'carregar_modelo'):
                logger.info(f"🤖 Usando ModelLoader para predição de {ativo}")
                modelo = model_loader.carregar_modelo(ativo, '1h')
                
                if modelo and callable(modelo):
                    result = modelo(df_klines)
                    if isinstance(result, dict):
                        return result
            
            # Fallback final: predição básica melhorada
            logger.warning(f"⚠️ Usando predição básica melhorada para {ativo}")
            return self._generate_enhanced_basic_prediction(ativo, df_klines)
            
        except Exception as e:
            logger.error(f"Erro na predição inteligente para {ativo}: {e}")
            return self._generate_enhanced_basic_prediction(ativo, df_klines)
    
    def _generate_enhanced_basic_prediction(self, ativo: str, df_klines) -> Dict[str, Any]:
        """
        Gera predição básica melhorada usando análise técnica simples.
        
        Args:
            ativo: Símbolo do ativo
            df_klines: DataFrame com dados
            
        Returns:
            Dict com predição e confiança
        """
        try:
            if not PANDAS_AVAILABLE or df_klines is None or len(df_klines) < 10:
                # Fallback aleatório
                import random
                return {
                    'predicao': random.uniform(0.4, 0.6),
                    'confianca': random.uniform(0.5, 0.6),
                    'metadata': {'method': 'random_fallback'}
                }
            
            # Análise técnica básica
            closes = df_klines['close'].astype(float)
            
            # RSI simplificado
            delta = closes.diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
            rs = gain / loss
            rsi = 100 - (100 / (1 + rs))
            rsi_current = rsi.iloc[-1] if not pd.isna(rsi.iloc[-1]) else 50
            
            # Média móvel simples
            sma_20 = closes.rolling(window=20).mean()
            price_vs_sma = closes.iloc[-1] / sma_20.iloc[-1] if not pd.isna(sma_20.iloc[-1]) else 1
            
            # Volatilidade
            volatility = closes.pct_change().rolling(window=10).std().iloc[-1]
            volatility = volatility if not pd.isna(volatility) else 0.02
            
            # Combinar indicadores
            rsi_signal = (rsi_current - 50) / 50  # Normalizar para [-1, 1]
            trend_signal = (price_vs_sma - 1) * 10  # Amplificar sinal de tendência
            
            # Predição combinada
            combined_signal = (rsi_signal * 0.4 + trend_signal * 0.6)
            predicao = 0.5 + (combined_signal * 0.2)  # Manter entre 0.3 e 0.7
            predicao = max(0.3, min(0.7, predicao))  # Limitar range
            
            # Confiança baseada na volatilidade
            confianca = max(0.5, min(0.8, 0.7 - volatility * 10))
            
            return {
                'predicao': predicao,
                'confianca': confianca,
                'metadata': {
                    'method': 'enhanced_technical_analysis',
                    'rsi': rsi_current,
                    'price_vs_sma': price_vs_sma,
                    'volatility': volatility,
                    'timestamp': datetime.datetime.now().isoformat()
                }
            }
            
        except Exception as e:
            logger.error(f"Erro na predição básica melhorada: {e}")
            import random
            return {
                'predicao': random.uniform(0.4, 0.6),
                'confianca': random.uniform(0.5, 0.6),
                'metadata': {'method': 'error_fallback'}
            }
    
    def _determine_trading_action(self, predicao: float, confianca: float, config_ativo: Dict[str, Any]) -> str:
        """
        Determina ação de trading baseada na predição e confiança.
        
        Args:
            predicao: Valor da predição (0-1)
            confianca: Nível de confiança (0-1)
            config_ativo: Configuração do ativo
            
        Returns:
            Ação: 'COMPRAR', 'VENDER' ou 'MANTER'
        """
        try:
            limiar_compra = config_ativo.get('limiar_compra', 0.60)
            limiar_venda = config_ativo.get('limiar_venda', 0.40)
            confianca_minima = 0.65  # Confiança mínima para executar ordens
            
            # Verificar confiança mínima
            if confianca < confianca_minima:
                return "MANTER"
            
            # Determinar ação baseada na predição
            if predicao >= limiar_compra:
                return "COMPRAR"
            elif predicao <= limiar_venda:
                return "VENDER"
            else:
                return "MANTER"
                
        except Exception as e:
            logger.error(f"Erro ao determinar ação de trading: {e}")
            return "MANTER"
    
    async def _execute_trading_action(self, ativo: str, acao: str, config_ativo: Dict[str, Any]):
        """
        Executa ação de trading real.
        
        Args:
            ativo: Símbolo do ativo
            acao: Ação a executar
            config_ativo: Configuração do ativo
        """
        try:
            if not self.client_binance:
                logger.error("Cliente Binance não disponível para execução")
                return
            
            valor_ordem = config_ativo.get('valor_ordem', 10.0)
            
            logger.critical(f"🚨 EXECUTANDO ORDEM REAL: {acao} {ativo} - Valor: ${valor_ordem}")
            
            # Implementar lógica de execução real aqui
            # Por segurança, apenas log por enquanto
            logger.info(f"Ordem {acao} para {ativo} seria executada com valor ${valor_ordem}")
            
        except Exception as e:
            logger.error(f"Erro na execução da ordem: {e}")
    
    async def _shutdown_system(self):
        """Encerra o sistema graciosamente."""
        try:
            logger.info("🔄 Encerrando sistema inteligente...")
            
            if self.client_binance:
                await self.client_binance.close_connection()
                logger.info("✅ Cliente Binance encerrado")
            
            logger.info("✅ Sistema encerrado com sucesso")
            
        except Exception as e:
            logger.error(f"Erro no encerramento: {e}")


async def main():
    """Função principal."""
    parser = argparse.ArgumentParser(description="KR_KRIPTO_ADVANCED - Sistema Inteligente de Trading")
    parser.add_argument("--config", default="config.json", help="Arquivo de configuração")
    parser.add_argument("--modo", choices=["real", "simulacao"], default="simulacao", help="Modo de operação")
    parser.add_argument("--debug", action="store_true", help="Ativar modo debug")
    parser.add_argument("--verbose", action="store_true", help="Ativar logs verbosos")
    
    args = parser.parse_args()
    
    # Configurar nível de logging
    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)
    elif args.verbose:
        logging.getLogger().setLevel(logging.INFO)
    
    try:
        logger.info("🚀 INICIANDO KR_KRIPTO_ADVANCED - SISTEMA INTELIGENTE")
        logger.info(f"Modo: {args.modo}")
        logger.info(f"Configuração: {args.config}")
        
        # Inicializar sistema
        system = IntelligentKriptoSystem(args.config)
        
        # Atualizar configuração baseada nos argumentos
        if args.modo == "simulacao":
            system.config["modo_simulacao"] = True
            system.config["executar_ordens_reais"] = False
        else:
            system.config["modo_simulacao"] = False
            system.config["executar_ordens_reais"] = True
        
        # Inicializar e executar
        success = await system.initialize_system()
        if success:
            await system.run_main_loop()
        else:
            logger.error("❌ Falha na inicialização do sistema")
            return 1
        
        return 0
        
    except KeyboardInterrupt:
        logger.info("🛑 Sistema interrompido pelo usuário")
        return 0
    except Exception as e:
        logger.error(f"❌ Erro fatal: {e}")
        logger.error(traceback.format_exc())
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())

