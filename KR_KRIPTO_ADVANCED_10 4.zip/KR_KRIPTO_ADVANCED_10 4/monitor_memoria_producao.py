#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de Monitoramento de Memória para KR_KRIPTO_ADVANCED_COPIA
----------------------------------------------------------------

Este script monitora o uso de memória do sistema KR_KRIPTO_ADVANCED_COPIA em tempo real,
detecta possíveis vazamentos, gera alertas e cria snapshots periódicos para análise.

Características:
- Monitoramento contínuo do uso de memória
- Detecção de crescimento anormal (>5% em 1 hora)
- Alertas via log e opcionalmente e-mail/Slack
- Snapshots periódicos para análise posterior
- Relatórios diários de tendências

Uso:
    python monitor_memoria_producao.py [--config arquivo_config.json]

Configuração:
    O arquivo de configuração permite ajustar limites de alerta, 
    frequência de snapshots e métodos de notificação.
"""

import os
import sys
import time
import json
import logging
import argparse
import datetime
import psutil
import matplotlib.pyplot as plt
import numpy as np
from collections import deque

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("logs/monitor_memoria.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("MonitorMemoria")

class MonitorMemoria:
    """Classe principal para monitoramento de memória do sistema KR_KRIPTO_ADVANCED_COPIA."""
    
    def __init__(self, config: dict):
        """Inicializa o monitor de memória com configurações padrão ou personalizadas."""
        # Configurações padrão
        self.config = {
            "intervalo_verificacao_segundos": 60,
            "limite_crescimento_percentual": 5.0,
            "periodo_analise_horas": 1,
            "intervalo_snapshot_minutos": 30,
            "diretorio_snapshots": "logs/snapshots_memoria",
            "diretorio_graficos": "logs/graficos_memoria",
            "processos_monitorados": ["python", "main.py"],
            "notificacoes": {
                "email": {
                    "ativo": False,
                    "destinatarios": ["admin@exemplo.com"],
                    "servidor": "smtp.exemplo.com",
                    "porta": 587,
                    "usuario": "usuario",
                    "senha": "senha"
                },
                "slack": {
                    "ativo": False,
                    "webhook_url": "https://hooks.slack.com/services/XXX/YYY/ZZZ"
                }
            }
        }
        
        # Carrega configurações personalizadas se fornecidas
        if config_file:
            try:
                with open(config_file, 'r') as f:
                    custom_config = json.load(f)
                    self.config.update(custom_config)
                logger.info(f"Configurações carregadas de {config_file}")
            except Exception as e:
                logger.error(f"Erro ao carregar configurações: {e}")
        
        # Cria diretórios necessários
        os.makedirs(self.config["diretorio_snapshots"], exist_ok=True)
        os.makedirs(self.config["diretorio_graficos"], exist_ok=True)
        
        # Inicializa estruturas de dados para armazenar histórico
        self.amostras_por_hora = 3600 // self.config["intervalo_verificacao_segundos"]
        self.historico_memoria = deque(maxlen=self.amostras_por_hora * 24)  # 24 horas de histórico
        self.historico_timestamps = deque(maxlen=self.amostras_por_hora * 24)
        
        # Contadores e flags
        self.contador_snapshots = 0
        self.ultimo_snapshot = time.time()
        self.inicio_monitoramento = time.time()
        
        logger.info("Monitor de Memória inicializado com sucesso")
    
    def obter_uso_memoria(self):
        """Obtém o uso atual de memória do sistema e dos processos monitorados."""
        # Memória do sistema
        memoria_sistema = psutil.virtual_memory()
        
        # Memória dos processos monitorados
        memoria_processos = 0
        processos_encontrados = []
        
        for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'memory_info']):
            try:
                # Verifica se o processo corresponde aos critérios de monitoramento
                # Correção: Verifica se cmdline existe, não é None e é iterável
                cmdline = proc.info.get('cmdline', [])
                if cmdline and isinstance(cmdline, (list, tuple)) and any(item in ' '.join(cmdline) for item in self.config["processos_monitorados"]):
                    memoria_processos += proc.info['memory_info'].rss
                    processos_encontrados.append(proc.pid)
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess, TypeError, AttributeError):
                # Adicionado tratamento para TypeError e AttributeError
                pass
        
        return {
            "timestamp": time.time(),
            "sistema": {
                "total": memoria_sistema.total,
                "disponivel": memoria_sistema.available,
                "usado": memoria_sistema.used,
                "percentual": memoria_sistema.percent
            },
            "processos": {
                "usado_bytes": memoria_processos,
                "usado_mb": memoria_processos / (1024 * 1024),
                "pids": processos_encontrados
            }
        }
    
    def analisar_tendencia(self):
        """Analisa a tendência de uso de memória para detectar possíveis vazamentos."""
        if len(self.historico_memoria) < self.amostras_por_hora:
            logger.info("Histórico insuficiente para análise de tendência")
            return None
        
        # Obtém amostras da última hora
        amostras_ultima_hora = list(self.historico_memoria)[-self.amostras_por_hora:]
        
        # Calcula crescimento percentual
        memoria_inicial = amostras_ultima_hora[0]["processos"]["usado_mb"]
        memoria_final = amostras_ultima_hora[-1]["processos"]["usado_mb"]
        
        if memoria_inicial <= 0:
            return None
        
        crescimento_percentual = ((memoria_final - memoria_inicial) / memoria_inicial) * 100
        
        return {
            "memoria_inicial_mb": memoria_inicial,
            "memoria_final_mb": memoria_final,
            "crescimento_mb": memoria_final - memoria_inicial,
            "crescimento_percentual": crescimento_percentual,
            "periodo_horas": self.config["periodo_analise_horas"]
        }
    
    def verificar_vazamento(self):
        """Verifica se há indícios de vazamento de memória com base na tendência."""
        tendencia = self.analisar_tendencia()
        if not tendencia:
            return False
        
        limite = self.config["limite_crescimento_percentual"]
        if tendencia["crescimento_percentual"] > limite:
            logger.warning(
                f"Possível vazamento de memória detectado: crescimento de "
                f"{tendencia['crescimento_percentual']:.2f}% em {tendencia['periodo_horas']} hora(s)"
            )
            self.enviar_alerta(
                f"Possível vazamento de memória",
                f"Crescimento de {tendencia['crescimento_percentual']:.2f}% em {tendencia['periodo_horas']} hora(s)\n"
                f"Memória inicial: {tendencia['memoria_inicial_mb']:.2f} MB\n"
                f"Memória atual: {tendencia['memoria_final_mb']:.2f} MB"
            )
            return True
        
        return False
    
    def criar_snapshot(self, forcado=False):
        """Cria um snapshot do estado atual de memória para análise posterior."""
        agora = time.time()
        intervalo_snapshot = self.config["intervalo_snapshot_minutos"] * 60
        
        # Verifica se é hora de criar um snapshot
        if not forcado and (agora - self.ultimo_snapshot) < intervalo_snapshot:
            return
        
        self.ultimo_snapshot = agora
        self.contador_snapshots += 1
        
        # Obtém informações detalhadas de memória
        uso_memoria = self.obter_uso_memoria()
        tendencia = self.analisar_tendencia()
        
        # Adiciona informações de tendência ao snapshot
        snapshot = {
            "timestamp": uso_memoria["timestamp"],
            "datetime": datetime.datetime.fromtimestamp(uso_memoria["timestamp"]).isoformat(),
            "memoria": uso_memoria,
            "tendencia": tendencia,
            "duracao_monitoramento_horas": (agora - self.inicio_monitoramento) / 3600
        }
        
        # Salva snapshot em arquivo
        timestamp_str = datetime.datetime.fromtimestamp(agora).strftime("%Y%m%d_%H%M%S")
        arquivo_snapshot = os.path.join(
            self.config["diretorio_snapshots"], 
            f"snapshot_memoria_{timestamp_str}.json"
        )
        
        with open(arquivo_snapshot, 'w') as f:
            json.dump(snapshot, f, indent=2)
        
        logger.info(f"Snapshot de memória criado: {arquivo_snapshot}")
        
        # Gera gráfico se houver histórico suficiente
        if len(self.historico_memoria) > 10:
            self.gerar_grafico_tendencia(timestamp_str)
    
    def gerar_grafico_tendencia(self, timestamp_str):
        """Gera um gráfico da tendência de uso de memória."""
        # Prepara dados para o gráfico
        timestamps = list(self.historico_timestamps)
        memoria_mb = [amostra["processos"]["usado_mb"] for amostra in self.historico_memoria]
        
        # Converte timestamps para datetime
        datas = [datetime.datetime.fromtimestamp(ts) for ts in timestamps]
        
        # Cria o gráfico
        plt.figure(figsize=(12, 6))
        plt.plot(datas, memoria_mb, 'b-')
        plt.title('Tendência de Uso de Memória - KR_KRIPTO_ADVANCED_COPIA')
        plt.xlabel('Tempo')
        plt.ylabel('Memória Utilizada (MB)')
        plt.grid(True)
        
        # Adiciona linha de tendência
        if len(memoria_mb) > 2:
            x = np.arange(len(memoria_mb))
            z = np.polyfit(x, memoria_mb, 1)
            p = np.poly1d(z)
            plt.plot(datas, p(x), "r--", label=f"Tendência: {z[0]:.2f} MB/amostra")
            plt.legend()
        
        # Salva o gráfico
        arquivo_grafico = os.path.join(
            self.config["diretorio_graficos"], 
            f"tendencia_memoria_{timestamp_str}.png"
        )
        plt.savefig(arquivo_grafico)
        plt.close()
        
        logger.info(f"Gráfico de tendência gerado: {arquivo_grafico}")
    
    def enviar_alerta(self, titulo, mensagem):
        """Envia alertas pelos canais configurados (log, email, Slack)."""
        # Log sempre é usado
        logger.warning(f"ALERTA: {titulo} - {mensagem}")
        
        # Email (se configurado)
        if self.config["notificacoes"]["email"]["ativo"]:
            try:
                self._enviar_email_alerta(titulo, mensagem)
            except Exception as e:
                logger.error(f"Erro ao enviar alerta por email: {e}")
        
        # Slack (se configurado)
        if self.config["notificacoes"]["slack"]["ativo"]:
            try:
                self._enviar_slack_alerta(titulo, mensagem)
            except Exception as e:
                logger.error(f"Erro ao enviar alerta para Slack: {e}")
    
    def _enviar_email_alerta(self, titulo, mensagem):
        """Envia alerta por email."""
        # Implementação básica usando smtplib
        # Esta função seria expandida em uma implementação real
        logger.info(f"Simulando envio de email: {titulo}")
    
    def _enviar_slack_alerta(self, titulo, mensagem):
        """Envia alerta para Slack."""
        # Implementação básica usando requests
        # Esta função seria expandida em uma implementação real
        logger.info(f"Simulando envio para Slack: {titulo}")
    
    def gerar_relatorio_diario(self):
        """Gera um relatório diário com estatísticas de uso de memória."""
        if len(self.historico_memoria) < self.amostras_por_hora * 6:  # Pelo menos 6 horas de dados
            logger.info("Histórico insuficiente para relatório diário")
            return
        
        # Calcula estatísticas
        memoria_valores = [amostra["processos"]["usado_mb"] for amostra in self.historico_memoria]
        estatisticas = {
            "minimo_mb": min(memoria_valores),
            "maximo_mb": max(memoria_valores),
            "media_mb": sum(memoria_valores) / len(memoria_valores),
            "crescimento_24h_mb": memoria_valores[-1] - memoria_valores[0],
            "crescimento_24h_percentual": ((memoria_valores[-1] - memoria_valores[0]) / memoria_valores[0]) * 100 if memoria_valores[0] > 0 else 0,
            "timestamp": time.time(),
            "data": datetime.datetime.now().strftime("%Y-%m-%d")
        }
        
        # Salva relatório
        arquivo_relatorio = os.path.join(
            self.config["diretorio_snapshots"], 
            f"relatorio_diario_{estatisticas['data']}.json"
        )
        
        with open(arquivo_relatorio, 'w') as f:
            json.dump(estatisticas, f, indent=2)
        
        logger.info(f"Relatório diário gerado: {arquivo_relatorio}")
        
        # Gera gráfico de 24 horas
        self.gerar_grafico_tendencia(f"diario_{estatisticas['data']}")
    
    def executar(self):
        """Executa o loop principal de monitoramento."""
        logger.info("Iniciando monitoramento de memória")
        
        contador_ciclos = 0
        ultimo_relatorio_diario = time.time()
        
        try:
            while True:
                # Obtém uso atual de memória
                uso_memoria = self.obter_uso_memoria()
                
                # Armazena no histórico
                self.historico_memoria.append(uso_memoria)
                self.historico_timestamps.append(uso_memoria["timestamp"])
                
                # Verifica possível vazamento
                if len(self.historico_memoria) >= self.amostras_por_hora:
                    self.verificar_vazamento()
                
                # Cria snapshot periódico
                self.criar_snapshot()
                
                # Gera relatório diário (a cada 24 horas)
                agora = time.time()
                if (agora - ultimo_relatorio_diario) >= 86400:  # 24 horas
                    self.gerar_relatorio_diario()
                    ultimo_relatorio_diario = agora
                
                # Log periódico de status
                contador_ciclos += 1
                if contador_ciclos % 60 == 0:  # A cada 60 ciclos
                    logger.info(
                        f"Status: Monitorando há {(agora - self.inicio_monitoramento) / 3600:.1f} horas, "
                        f"Memória atual: {uso_memoria['processos']['usado_mb']:.2f} MB, "
                        f"Snapshots: {self.contador_snapshots}"
                    )
                
                # Aguarda até o próximo ciclo
                time.sleep(self.config["intervalo_verificacao_segundos"])
                
        except KeyboardInterrupt:
            logger.info("Monitoramento interrompido pelo usuário")
        except Exception as e:
            logger.error(f"Erro durante monitoramento: {e}", exc_info=True)
        finally:
            # Cria snapshot final
            self.criar_snapshot(forcado=True)
            logger.info("Monitoramento de memória finalizado")

def main():
    """Função principal para execução do script."""
    parser = argparse.ArgumentParser(description="Monitor de Memória para KR_KRIPTO_ADVANCED_COPIA")
    parser.add_argument("--config", help="Arquivo de configuração JSON")
    args = parser.parse_args()
    
    monitor = MonitorMemoria(config={'config_file': args.config})
    monitor.executar()

if __name__ == "__main__":
    main()
