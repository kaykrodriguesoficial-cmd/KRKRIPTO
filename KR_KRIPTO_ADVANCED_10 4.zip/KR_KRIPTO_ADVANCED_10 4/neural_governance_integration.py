# -*- coding: utf-8 -*-
"""
Integração Neural Governance + Multi-Timeframe + RL

Este módulo integra o sistema de governança neural com multi-timeframe e RL,
criando um sistema de decisão inteligente que seleciona automaticamente
os melhores modelos baseado em performance e contexto.

Autor: Manus AI
Data: 30/08/2025
Versão: 1.0.0 - FASE 2 ML SUPREMO
"""

import os
import sys
import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Any, Optional, Union
from datetime import datetime, timedelta
import json
import traceback

# Configurar logging
logger = logging.getLogger("neural_governance_integration")

# Importações do sistema existente
try:
    from analise_multitimeframe import MultiTimeframeAnalyzer
    MULTITIMEFRAME_AVAILABLE = True
except ImportError:
    MULTITIMEFRAME_AVAILABLE = False
    logger.warning("Sistema multi-timeframe não disponível")

try:
    from rl_multitimeframe_integration import RLMultiTimeframeAgent
    RL_AVAILABLE = True
except ImportError:
    RL_AVAILABLE = False
    logger.warning("Sistema RL não disponível")

try:
    from analise_tecnica_basica import AnaliseTecnicaBasica
    ANALISE_TECNICA_AVAILABLE = True
except ImportError:
    ANALISE_TECNICA_AVAILABLE = False
    logger.warning("Análise técnica básica não disponível")

class ModelPerformanceTracker:
    """
    Rastreador de performance de modelos em tempo real.
    
    Monitora métricas de performance de múltiplos modelos e
    mantém histórico para seleção inteligente.
    """
    
    def __init__(self, config: Dict = None):
        """
        Inicializa o rastreador de performance.
        
        Args:
            config: Configurações do rastreador
        """
        self.config = config or {}
        self.models_performance = {}
        self.performance_history = {}
        self.window_size = self.config.get('window_size', 100)
        self.min_predictions = self.config.get('min_predictions', 10)
        
        logger.info("🔍 ModelPerformanceTracker inicializado")
    
    def register_model(self, model_id: str, model_type: str = "unknown"):
        """
        Registra um novo modelo para rastreamento.
        
        Args:
            model_id: Identificador único do modelo
            model_type: Tipo do modelo (rl, multitf, neural, etc.)
        """
        if model_id not in self.models_performance:
            self.models_performance[model_id] = {
                'type': model_type,
                'predictions': 0,
                'correct_predictions': 0,
                'accuracy': 0.0,
                'avg_confidence': 0.0,
                'avg_score': 0.0,
                'total_profit': 0.0,
                'last_updated': datetime.now(),
                'status': 'active'
            }
            self.performance_history[model_id] = []
            logger.info(f"✅ Modelo {model_id} ({model_type}) registrado para rastreamento")
    
    def record_prediction(self, model_id: str, prediction: Dict, actual_result: Dict = None):
        """
        Registra uma predição e seu resultado.
        
        Args:
            model_id: ID do modelo
            prediction: Dados da predição
            actual_result: Resultado real (opcional)
        """
        if model_id not in self.models_performance:
            self.register_model(model_id, "unknown")
        
        model_perf = self.models_performance[model_id]
        
        # Atualizar contadores
        model_perf['predictions'] += 1
        model_perf['last_updated'] = datetime.now()
        
        # Extrair métricas da predição
        confidence = prediction.get('confianca', prediction.get('confidence', 0.5))
        score = prediction.get('score_total', prediction.get('score', 0))
        
        # Atualizar médias
        total_preds = model_perf['predictions']
        model_perf['avg_confidence'] = (
            (model_perf['avg_confidence'] * (total_preds - 1) + confidence) / total_preds
        )
        model_perf['avg_score'] = (
            (model_perf['avg_score'] * (total_preds - 1) + score) / total_preds
        )
        
        # Registrar no histórico
        record = {
            'timestamp': datetime.now(),
            'prediction': prediction,
            'confidence': confidence,
            'score': score,
            'actual_result': actual_result
        }
        
        self.performance_history[model_id].append(record)
        
        # Manter apenas últimas N predições
        if len(self.performance_history[model_id]) > self.window_size:
            self.performance_history[model_id] = self.performance_history[model_id][-self.window_size:]
        
        # Calcular accuracy se resultado disponível
        if actual_result:
            self._update_accuracy(model_id, prediction, actual_result)
    
    def _update_accuracy(self, model_id: str, prediction: Dict, actual_result: Dict):
        """
        Atualiza accuracy baseado no resultado real.
        
        Args:
            model_id: ID do modelo
            prediction: Predição feita
            actual_result: Resultado real
        """
        model_perf = self.models_performance[model_id]
        
        # Determinar se predição foi correta (simplificado)
        pred_action = prediction.get('acao', prediction.get('action', 'MANTER'))
        actual_profit = actual_result.get('profit', 0.0)
        
        # Lógica simples: predição correta se ação alinhada com lucro
        correct = False
        if pred_action == 'COMPRAR' and actual_profit > 0:
            correct = True
        elif pred_action == 'VENDER' and actual_profit < 0:
            correct = True
        elif pred_action == 'MANTER' and abs(actual_profit) < 0.01:
            correct = True
        
        if correct:
            model_perf['correct_predictions'] += 1
        
        # Atualizar accuracy
        model_perf['accuracy'] = model_perf['correct_predictions'] / model_perf['predictions']
        
        # Atualizar lucro total
        model_perf['total_profit'] += actual_profit
    
    def get_model_performance(self, model_id: str) -> Dict:
        """
        Retorna performance de um modelo específico.
        
        Args:
            model_id: ID do modelo
            
        Returns:
            Dict: Métricas de performance
        """
        if model_id not in self.models_performance:
            return {}
        
        perf = self.models_performance[model_id].copy()
        
        # Adicionar métricas calculadas
        if perf['predictions'] >= self.min_predictions:
            perf['reliability_score'] = self._calculate_reliability_score(model_id)
        else:
            perf['reliability_score'] = 0.0
        
        return perf
    
    def _calculate_reliability_score(self, model_id: str) -> float:
        """
        Calcula score de confiabilidade do modelo.
        
        Args:
            model_id: ID do modelo
            
        Returns:
            float: Score de confiabilidade (0-1)
        """
        perf = self.models_performance[model_id]
        
        # Componentes do score
        accuracy_weight = 0.4
        confidence_weight = 0.2
        score_weight = 0.2
        profit_weight = 0.2
        
        # Normalizar métricas
        accuracy_norm = min(perf['accuracy'], 1.0)
        confidence_norm = min(perf['avg_confidence'], 1.0)
        score_norm = min(perf['avg_score'] / 30.0, 1.0)  # Assumindo score máximo 30
        profit_norm = max(0, min(perf['total_profit'] / 0.1, 1.0))  # 10% profit = score 1.0
        
        reliability = (
            accuracy_norm * accuracy_weight +
            confidence_norm * confidence_weight +
            score_norm * score_weight +
            profit_norm * profit_weight
        )
        
        return reliability
    
    def get_best_models(self, top_n: int = 3) -> List[Tuple[str, float]]:
        """
        Retorna os melhores modelos baseado em performance.
        
        Args:
            top_n: Número de modelos a retornar
            
        Returns:
            List[Tuple[str, float]]: Lista de (model_id, reliability_score)
        """
        model_scores = []
        
        for model_id in self.models_performance:
            perf = self.get_model_performance(model_id)
            if perf.get('predictions', 0) >= self.min_predictions:
                reliability = perf.get('reliability_score', 0.0)
                model_scores.append((model_id, reliability))
        
        # Ordenar por reliability score
        model_scores.sort(key=lambda x: x[1], reverse=True)
        
        return model_scores[:top_n]

class NeuralGovernor:
    """
    Governador neural que seleciona automaticamente os melhores modelos
    baseado em performance, contexto e condições de mercado.
    """
    
    def __init__(self, config: Dict = None):
        """
        Inicializa o governador neural.
        
        Args:
            config: Configurações do governador
        """
        self.config = config or {}
        self.selection_strategy = self.config.get('selection_strategy', 'best_recent')
        self.min_score_threshold = self.config.get('min_score_threshold', 0.45)
        self.min_predictions_threshold = self.config.get('min_predictions_threshold', 8)
        
        # Componentes
        self.performance_tracker = ModelPerformanceTracker(config)
        self.available_models = {}
        
        # Registrar modelos padrão
        self._register_default_models()
        
        logger.info("🧠 NeuralGovernor inicializado")
        logger.info(f"📊 Estratégia: {self.selection_strategy}")
        logger.info(f"🎯 Threshold mínimo: {self.min_score_threshold}")
    
    def _register_default_models(self):
        """Registra modelos padrão do sistema."""
        # Modelo Multi-timeframe
        self.performance_tracker.register_model("multitimeframe", "multitf")
        
        # Modelo RL (se disponível)
        if RL_AVAILABLE:
            self.performance_tracker.register_model("rl_multitf", "rl")
        
        # Modelo de análise técnica básica
        self.performance_tracker.register_model("analise_tecnica", "technical")
        
        logger.info("✅ Modelos padrão registrados")
    
    def register_model(self, model_id: str, model_instance: Any, model_type: str = "custom"):
        """
        Registra um novo modelo no governador.
        
        Args:
            model_id: Identificador único do modelo
            model_instance: Instância do modelo
            model_type: Tipo do modelo
        """
        self.available_models[model_id] = {
            'instance': model_instance,
            'type': model_type,
            'registered_at': datetime.now()
        }
        
        self.performance_tracker.register_model(model_id, model_type)
        logger.info(f"✅ Modelo {model_id} ({model_type}) registrado no governador")
    
    def select_best_model(self, context: Dict = None) -> Tuple[str, Any]:
        """
        Seleciona o melhor modelo baseado na estratégia configurada.
        
        Args:
            context: Contexto adicional para seleção
            
        Returns:
            Tuple[str, Any]: (model_id, model_instance)
        """
        context = context or {}
        
        if self.selection_strategy == 'best_recent':
            return self._select_best_recent()
        elif self.selection_strategy == 'ensemble':
            return self._select_ensemble()
        elif self.selection_strategy == 'context_aware':
            return self._select_context_aware(context)
        else:
            return self._select_best_recent()
    
    def _select_best_recent(self) -> Tuple[str, Any]:
        """
        Seleciona modelo com melhor performance recente.
        
        Returns:
            Tuple[str, Any]: (model_id, model_instance)
        """
        best_models = self.performance_tracker.get_best_models(top_n=1)
        
        if best_models and best_models[0][1] >= self.min_score_threshold:
            model_id = best_models[0][0]
            if model_id in self.available_models:
                return model_id, self.available_models[model_id]['instance']
        
        # Fallback para multi-timeframe
        if 'multitimeframe' in self.available_models:
            return 'multitimeframe', self.available_models['multitimeframe']['instance']
        
        # Fallback final
        return 'default', None
    
    def _select_ensemble(self) -> Tuple[str, Any]:
        """
        Seleciona ensemble de modelos.
        
        Returns:
            Tuple[str, Any]: (ensemble_id, ensemble_instance)
        """
        # Implementação simplificada - retorna melhor modelo
        return self._select_best_recent()
    
    def _select_context_aware(self, context: Dict) -> Tuple[str, Any]:
        """
        Seleção baseada em contexto de mercado.
        
        Args:
            context: Contexto de mercado
            
        Returns:
            Tuple[str, Any]: (model_id, model_instance)
        """
        # Analisar contexto
        volatility = context.get('volatility', 'medium')
        trend = context.get('trend', 'neutral')
        
        # Lógica de seleção baseada em contexto
        if volatility == 'high' and RL_AVAILABLE:
            # RL é melhor em alta volatilidade
            if 'rl_multitf' in self.available_models:
                return 'rl_multitf', self.available_models['rl_multitf']['instance']
        
        # Fallback para melhor modelo
        return self._select_best_recent()
    
    def make_decision(self, dados_por_tf: Dict, context: Dict = None) -> Dict:
        """
        Toma decisão usando o modelo selecionado pelo governador.
        
        Args:
            dados_por_tf: Dados por timeframe
            context: Contexto adicional
            
        Returns:
            Dict: Decisão final com metadados
        """
        try:
            # Selecionar melhor modelo
            model_id, model_instance = self.select_best_model(context)
            
            # Fazer predição com modelo selecionado
            if model_id == 'multitimeframe' and MULTITIMEFRAME_AVAILABLE:
                # Usar analisador multi-timeframe
                if not hasattr(self, '_multitf_analyzer'):
                    self._multitf_analyzer = MultiTimeframeAnalyzer()
                
                symbol = context.get('symbol', 'BTCUSDT')
                result = self._multitf_analyzer.analisar_multitimeframe_completo(symbol, dados_por_tf)
                
            elif model_id == 'rl_multitf' and RL_AVAILABLE and model_instance:
                # Usar agente RL
                symbol = context.get('symbol', 'BTCUSDT')
                price_data = dados_por_tf.get('1h', pd.DataFrame())
                
                if not price_data.empty:
                    rl_result = model_instance.train_step(dados_por_tf, price_data, 0)
                    
                    # Converter resultado RL para formato padrão
                    action_map = {0: 'MANTER', 1: 'COMPRAR', 2: 'VENDER'}
                    result = {
                        'sinal_final': {
                            'acao': action_map.get(rl_result.get('action', 0), 'MANTER'),
                            'confianca': min(rl_result.get('reward', 0) / 10.0 + 0.5, 1.0),
                            'motivo': f"RL Decision: Reward {rl_result.get('reward', 0):.3f}"
                        },
                        'scoring': {
                            'score_total': rl_result.get('multitf_result', {}).get('scoring', {}).get('score_total', 0),
                            'classificacao': 'RL_DECISION'
                        },
                        'model_used': model_id,
                        'rl_metrics': rl_result
                    }
                else:
                    result = self._get_fallback_result()
            else:
                # Fallback
                result = self._get_fallback_result()
            
            # Adicionar metadados do governador
            result['governance'] = {
                'selected_model': model_id,
                'selection_strategy': self.selection_strategy,
                'model_performance': self.performance_tracker.get_model_performance(model_id),
                'timestamp': datetime.now().isoformat()
            }
            
            # Registrar predição
            self.performance_tracker.record_prediction(model_id, result.get('sinal_final', {}))
            
            return result
            
        except Exception as e:
            logger.error(f"Erro na decisão do governador: {e}")
            return self._get_fallback_result()
    
    def _get_fallback_result(self) -> Dict:
        """
        Retorna resultado de fallback.
        
        Returns:
            Dict: Resultado padrão
        """
        return {
            'sinal_final': {
                'acao': 'MANTER',
                'confianca': 0.5,
                'motivo': 'Fallback decision - Neural Governor'
            },
            'scoring': {
                'score_total': 10.0,
                'classificacao': 'FALLBACK'
            },
            'governance': {
                'selected_model': 'fallback',
                'selection_strategy': self.selection_strategy,
                'timestamp': datetime.now().isoformat()
            }
        }
    
    def get_governance_status(self) -> Dict:
        """
        Retorna status completo da governança.
        
        Returns:
            Dict: Status da governança
        """
        best_models = self.performance_tracker.get_best_models(top_n=5)
        
        return {
            'strategy': self.selection_strategy,
            'registered_models': len(self.available_models),
            'best_models': best_models,
            'thresholds': {
                'min_score': self.min_score_threshold,
                'min_predictions': self.min_predictions_threshold
            },
            'models_performance': {
                model_id: self.performance_tracker.get_model_performance(model_id)
                for model_id in self.performance_tracker.models_performance
            }
        }

class NeuralGovernanceIntegration:
    """
    Integração completa de Neural Governance com Multi-timeframe e RL.
    
    Esta classe orquestra todos os componentes de governança neural,
    fornecendo uma interface unificada para decisões inteligentes.
    """
    
    def __init__(self, config: Dict = None):
        """
        Inicializa a integração completa.
        
        Args:
            config: Configurações da integração
        """
        self.config = config or {}
        
        # Inicializar componentes
        self.neural_governor = NeuralGovernor(config.get('neural_governor_config', {}))
        
        # Registrar modelos disponíveis
        self._setup_models()
        
        logger.info("🌟 NeuralGovernanceIntegration inicializada")
    
    def _setup_models(self):
        """Configura e registra modelos disponíveis."""
        try:
            # Registrar analisador multi-timeframe
            if MULTITIMEFRAME_AVAILABLE:
                multitf_analyzer = MultiTimeframeAnalyzer(self.config)
                self.neural_governor.register_model(
                    "multitimeframe", 
                    multitf_analyzer, 
                    "multitf"
                )
                logger.info("✅ Multi-timeframe analyzer registrado")
            
            # Registrar agente RL
            if RL_AVAILABLE:
                rl_config = self.config.get('rl_config', {
                    'ativo': 'BTCUSDT',
                    'timeframes': ['15m', '1h', '4h', '1d']
                })
                rl_agent = RLMultiTimeframeAgent(rl_config)
                
                # Tentar carregar modelo treinado
                model_path = "models/rl_multitf_test.json"
                if os.path.exists(model_path):
                    rl_agent.load_model(model_path)
                    logger.info("✅ Modelo RL carregado")
                
                self.neural_governor.register_model(
                    "rl_multitf",
                    rl_agent,
                    "rl"
                )
                logger.info("✅ RL agent registrado")
            
        except Exception as e:
            logger.error(f"Erro ao configurar modelos: {e}")
    
    def analyze_and_decide(self, symbol: str, dados_por_tf: Dict, 
                          market_context: Dict = None) -> Dict:
        """
        Análise completa e decisão usando governança neural.
        
        Args:
            symbol: Símbolo do ativo
            dados_por_tf: Dados por timeframe
            market_context: Contexto de mercado
            
        Returns:
            Dict: Decisão final com governança neural
        """
        try:
            # Preparar contexto
            context = market_context or {}
            context['symbol'] = symbol
            
            # Fazer decisão usando governador neural
            decision = self.neural_governor.make_decision(dados_por_tf, context)
            
            # Adicionar informações de integração
            decision['integration'] = {
                'version': '1.0.0',
                'components': ['neural_governance', 'multi_timeframe', 'rl'],
                'symbol': symbol,
                'timestamp': datetime.now().isoformat()
            }
            
            return decision
            
        except Exception as e:
            logger.error(f"Erro na análise integrada: {e}")
            return {
                'sinal_final': {
                    'acao': 'MANTER',
                    'confianca': 0.5,
                    'motivo': f'Erro na integração: {str(e)}'
                },
                'scoring': {'score_total': 0, 'classificacao': 'ERROR'},
                'error': str(e)
            }
    
    async def analisar_com_governanca(self, ativo: str, dados_por_tf: Dict) -> Dict:
        """
        Método principal para análise com governança neural.
        
        Args:
            ativo: Símbolo do ativo (ex: BTCUSDT)
            dados_por_tf: Dados por timeframe
            
        Returns:
            Dict: Resultado da análise com governança
        """
        try:
            # Contexto para seleção de modelo
            context = {
                'symbol': ativo,
                'volatility': 'medium',  # Pode ser calculado dos dados
                'trend': 'neutral',      # Pode ser calculado dos dados
                'timeframes': list(dados_por_tf.keys())
            }
            
            # Usar governança neural para tomar decisão
            decision = self.neural_governor.make_decision(context, dados_por_tf)
            
            # Adicionar metadados específicos da governança
            decision['governance_metadata'] = {
                'ativo': ativo,
                'strategy_used': self.neural_governor.selection_strategy,
                'models_available': len(self.neural_governor.available_models),
                'timestamp': datetime.now().isoformat()
            }
            
            logger.debug(f"✅ Análise com governança concluída para {ativo}")
            return decision
            
        except Exception as e:
            logger.error(f"❌ Erro na análise com governança para {ativo}: {e}")
            # Retornar resultado de fallback
            return {
                'sinal_final': {
                    'acao': 'MANTER',
                    'confianca': 0.5,
                    'motivo': f"🧠 Neural Governance (fallback): {str(e)[:50]}"
                },
                'scoring': {
                    'score_total': 15,
                    'classificacao': 'GOVERNANCE_FALLBACK'
                },
                'governance_metadata': {
                    'ativo': ativo,
                    'error': str(e),
                    'fallback_used': True,
                    'timestamp': datetime.now().isoformat()
                }
            }

    def get_system_status(self) -> Dict:
        """
        Retorna status completo do sistema integrado.
        
        Returns:
            Dict: Status do sistema
        """
        return {
            'neural_governance': self.neural_governor.get_governance_status(),
            'components': {
                'multitimeframe_available': MULTITIMEFRAME_AVAILABLE,
                'rl_available': RL_AVAILABLE,
                'analise_tecnica_available': ANALISE_TECNICA_AVAILABLE
            },
            'config': self.config,
            'timestamp': datetime.now().isoformat()
        }

def criar_neural_governance_integration(config: Dict = None) -> NeuralGovernanceIntegration:
    """
    Função de conveniência para criar integração de governança neural.
    
    Args:
        config: Configurações da integração
        
    Returns:
        NeuralGovernanceIntegration: Sistema integrado
    """
    if config is None:
        config = {
            'neural_governor_config': {
                'selection_strategy': 'best_recent',
                'min_score_threshold': 0.45,
                'min_predictions_threshold': 8
            },
            'rl_config': {
                'ativo': 'BTCUSDT',
                'timeframes': ['15m', '1h', '4h', '1d'],
                'learning_rate': 0.001,
                'epsilon': 0.1
            }
        }
    
    return NeuralGovernanceIntegration(config)

if __name__ == "__main__":
    # Teste básico
    print("🧠 Testando Neural Governance Integration...")
    
    config_teste = {
        'neural_governor_config': {
            'selection_strategy': 'best_recent',
            'min_score_threshold': 0.4
        }
    }
    
    integration = criar_neural_governance_integration(config_teste)
    print(f"✅ Integração criada")
    
    # Testar status
    status = integration.get_system_status()
    print(f"📊 Componentes disponíveis:")
    for comp, available in status['components'].items():
        print(f"  {comp}: {'✅' if available else '❌'}")
    
    print("🎉 Neural Governance Integration pronta!")

