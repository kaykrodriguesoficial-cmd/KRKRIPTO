# Fluxo de Ordens e Design do Módulo Operador

## 1. Objetivo

Integrar o sistema KR Kripto Advanced com a Binance Testnet para execução e gerenciamento de ordens reais (simuladas na Testnet), utilizando os sinais gerados pelo `signal_processor` e os parâmetros de risco definidos.

## 2. Módulo Responsável

O módulo `src/infrastructure/operador.py` será **refatorado** para deixar de ser um simulador de DataFrame e passar a ser o responsável pela interação real com a API da Binance (Testnet inicialmente).

## 3. Biblioteca Utilizada

Utilizaremos a biblioteca `python-binance` para interagir com a API da Binance. Será necessário instalá-la (`pip install python-binance`).

## 4. Fluxo de Execução

1.  **Geração do Sinal:** O `signal_processor.py`, após calcular o score final e aplicar a lógica do `risk_manager.py`, determina a ação final (BUY, SELL, HOLD).
2.  **Chamada do Operador:** Se a ação for BUY ou SELL, o `signal_processor.py` (ou o `main.py`, dependendo da arquitetura final de passagem de contexto/sinal) invocará uma função no módulo `operador.py`.
3.  **Cálculo de Parâmetros:** Antes de chamar o operador, será necessário calcular:
    *   `quantity`: O tamanho da ordem (baseado no capital alocado, risco, preço atual).
    *   `stop_loss_price`: Preço de Stop Loss (pode ser calculado pelo `risk_manager.py` ou aqui).
    *   `take_profit_price`: Preço de Take Profit (pode ser calculado pelo `risk_manager.py` ou aqui).
4.  **Execução da Ordem:** O `operador.py` chamará a função `execute_order`.
5.  **Interação com API:** A função `execute_order` utilizará o cliente `python-binance` (configurado para Testnet) para enviar a ordem à Binance.
    *   **Tipo de Ordem:** Inicialmente, podemos usar ordens `MARKET` para simplificar, ou `LIMIT` se necessário.
    *   **SL/TP:** Recomenda-se o uso de ordens OCO (One-Cancels-the-Other) ou ordens `STOP_LOSS_LIMIT` e `TAKE_PROFIT_LIMIT` separadas, enviadas após a ordem principal ser preenchida.
6.  **Tratamento da Resposta:** O `operador.py` receberá a resposta da API, registrará o ID da ordem, status, e tratará possíveis erros.
7.  **Gerenciamento:** O `operador.py` (ou um módulo complementar) precisará manter o estado das ordens abertas e potencialmente implementar a lógica de cancelamento (`cancel_order`).

## 5. Estrutura do `operador.py` (Proposta)

```python
# src/infrastructure/operador.py
import logging
from binance.client import Client # Ou AsyncClient para asyncio
from binance.enums import *
from binance.exceptions import BinanceAPIException, BinanceOrderException

logger = logging.getLogger("kr_kripto_operador")

class OperadorBinance:
    def __init__(self, api_key: str, api_secret: str, testnet: bool = True):
        self.client = Client(api_key, api_secret, testnet=testnet)
        # Ou: self.client = await AsyncClient.create(api_key, api_secret, testnet=testnet)
        logger.info(f"OperadorBinance inicializado. Testnet: {testnet}")

    async def execute_order(self, symbol: str, side: SIDE_*, quantity: float, order_type: ORDER_TYPE_*, stop_loss_price: float = None, take_profit_price: float = None, **kwargs):
        """Envia uma ordem para a Binance."""
        try:
            # Lógica para criar a ordem principal (MARKET ou LIMIT)
            logger.info(f"Enviando ordem {side} {order_type} para {symbol}, Qtd: {quantity}")
            # Exemplo: Ordem MARKET
            # order = await self.client.create_order(
            #     symbol=symbol,
            #     side=side,
            #     type=ORDER_TYPE_MARKET,
            #     quantity=quantity
            # )
            # logger.info(f"Ordem principal criada: {order}")

            # Lógica para criar ordens SL/TP (ex: OCO) após a principal ser preenchida
            # if order and order.get('status') == ORDER_STATUS_FILLED and stop_loss_price and take_profit_price:
            #     logger.info(f"Enviando ordem OCO para {symbol}. SL: {stop_loss_price}, TP: {take_profit_price}")
            #     oco_order = await self.client.create_oco_order(
            #         symbol=symbol,
            #         side=SIDE_SELL if side == SIDE_BUY else SIDE_BUY, # Oposto da ordem principal
            #         quantity=quantity,
            #         price=take_profit_price, # Preço da ordem LIMIT (Take Profit)
            #         stopPrice=stop_loss_price, # Preço gatilho da ordem STOP
            #         stopLimitPrice=stop_loss_price, # Preço limite da ordem STOP (pode ser igual ao stopPrice)
            #         stopLimitTimeInForce=TIME_IN_FORCE_GTC
            #     )
            #     logger.info(f"Ordem OCO criada: {oco_order}")
            #     return order, oco_order
            
            # Placeholder - Implementar lógica real
            logger.warning("Lógica de execução de ordem ainda não implementada!")
            return None, None # Retorna None enquanto não implementado

        except BinanceAPIException as e:
            logger.error(f"Erro da API Binance ao executar ordem: {e}", exc_info=True)
            return None, None
        except BinanceOrderException as e:
            logger.error(f"Erro na ordem Binance: {e}", exc_info=True)
            return None, None
        except Exception as e:
            logger.error(f"Erro inesperado ao executar ordem: {e}", exc_info=True)
            return None, None

    async def cancel_order(self, symbol: str, order_id: int):
        """Cancela uma ordem específica na Binance."""
        try:
            logger.info(f"Cancelando ordem {order_id} para {symbol}...")
            # result = await self.client.cancel_order(symbol=symbol, orderId=order_id)
            # logger.info(f"Resultado do cancelamento: {result}")
            # return result
            
            # Placeholder - Implementar lógica real
            logger.warning("Lógica de cancelamento de ordem ainda não implementada!")
            return None
            
        except BinanceAPIException as e:
            logger.error(f"Erro da API Binance ao cancelar ordem: {e}", exc_info=True)
            return None
        except BinanceOrderException as e:
            logger.error(f"Erro ao cancelar ordem Binance: {e}", exc_info=True)
            return None
        except Exception as e:
            logger.error(f"Erro inesperado ao cancelar ordem: {e}", exc_info=True)
            return None

    # Outros métodos úteis:
    # async def get_order_status(self, symbol: str, order_id: int): ...
    # async def get_open_orders(self, symbol: str): ...
    # async def get_account_balance(self, asset: str): ...

```

## 6. Configuração

*   As chaves da API Binance (Testnet `api_key`, `api_secret`) devem ser adicionadas ao arquivo `config.json` ou gerenciadas via variáveis de ambiente.
*   O `main.py` deverá ler essas chaves e inicializar o `OperadorBinance`, passando a instância para o contexto compartilhado (`context['operador']`).
*   Um parâmetro de configuração (`use_testnet: true/false`) deve controlar qual ambiente (Testnet/Produção) o operador utilizará.

## 7. Próximos Passos (Plano)

1.  **Implementar `execute_order` e `cancel_order`:** Codificar a lógica real dentro das funções propostas no `operador.py`, usando `python-binance` e focando na Testnet.
2.  **Integrar com `main.py`:** Ler chaves, inicializar `OperadorBinance`, adicionar ao contexto.
3.  **Integrar com `signal_processor.py`:** Chamar `operador.execute_order` quando um sinal BUY/SELL for gerado, passando os parâmetros necessários (ativo, lado, quantidade, SL/TP).
4.  **Testar:** Executar o sistema e verificar se as ordens são enviadas corretamente para a Binance Testnet.

