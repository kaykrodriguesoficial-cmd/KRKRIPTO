# RELATÓRIO BACKTESTING SISTEMA HÍBRIDO

**Data:** 2025-09-01 17:21:13
**Sistema:** ML Supremo + Gestão de Risco + Scoring Híbrido
**Modo:** Backtesting Integrado

## 📊 RESUMO EXECUTIVO

### 🎯 PERFORMANCE GERAL
- **Capital Inicial:** $0.00
- **Capital Final:** $0.00
- **Retorno Total:** +0.00%
- **Classificação:** SEM_DADOS

### 📈 MÉTRICAS PROFISSIONAIS
- **Sharpe Ratio:** 0.00
- **Maximum Drawdown:** 0.00%
- **Win Rate:** 0.0%
- **Profit Factor:** 0.00
- **Total Trades:** 0

### 🛡️ GESTÃO DE RISCO
- **Position Sizing:** 2% de risco por trade
- **Stop-Loss:** Baseado em ATR dinâmico
- **Take-Profit:** Ratio 1.5:1
- **Máximo por posição:** 10% do capital

## 📋 ÚLTIMOS TRADES



---

**Relatório gerado automaticamente pelo Sistema Híbrido**
**Versão: 7.0.0 | Data: 2025-09-01 17:21:13**
