#!/usr/bin/env python3
"""
LOGGING DE EXPECTATIVA MATEMÁTICA - FASE 1
Sistema completo de logging para análise de expectativa matemática
Integração com Sistema Híbrido Supremo v8.0.0
"""

import json
import os
from datetime import datetime
from pathlib import Path
import numpy as np

class LoggingExpectativa:
    """Classe para logging de expectativa matemática"""
    
    def __init__(self, base_dir="roadmap_expectativa"):
        self.base_dir = Path(base_dir)
        self.logs_dir = self.base_dir / "logs"
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        
        self.trade_log_file = self.logs_dir / "trades_expectativa.jsonl"
        self.metricas_file = self.logs_dir / "metricas_acumuladas.json"
        
    def log_trade_expectativa(self, symbol, resultado, config_ativo=None):
        """Log detalhado para cálculo de expectativa matemática"""
        try:
            # Extrair dados do resultado
            acao = resultado.get('acao', 'HOLD')
            confianca = resultado.get('confianca', 0)
            preco_entrada = resultado.get('preco_entrada', 0)
            stop_loss = resultado.get('stop_loss', 0)
            take_profit = resultado.get('take_profit', 0)
            
            # Calcular R:R se possível
            rr_ratio = 0
            if preco_entrada > 0 and stop_loss > 0 and take_profit > 0:
                if acao == 'COMPRAR':
                    risco = abs(preco_entrada - stop_loss)
                    recompensa = abs(take_profit - preco_entrada)
                else:  # VENDER
                    risco = abs(stop_loss - preco_entrada)
                    recompensa = abs(preco_entrada - take_profit)
                
                rr_ratio = recompensa / risco if risco > 0 else 0
            
            # Calcular expectativa teórica (baseada em confiança)
            win_rate_estimado = min(confianca / 100.0, 0.95)  # Cap em 95%
            loss_rate_estimado = 1 - win_rate_estimado
            
            if rr_ratio > 0:
                expectativa_teorica = (win_rate_estimado * rr_ratio) - (loss_rate_estimado * 1)
            else:
                expectativa_teorica = 0
            
            # Calcular profit factor teórico
            if loss_rate_estimado > 0:
                profit_factor_teorico = (win_rate_estimado * rr_ratio) / loss_rate_estimado
            else:
                profit_factor_teorico = float('inf') if win_rate_estimado > 0 else 0
            
            trade_log = {
                'timestamp': datetime.now().isoformat(),
                'symbol': symbol,
                'acao': acao,
                'confianca': confianca,
                'preco_entrada': preco_entrada,
                'stop_loss': stop_loss,
                'take_profit': take_profit,
                'rr_ratio': rr_ratio,
                'win_rate_estimado': win_rate_estimado,
                'expectativa_teorica': expectativa_teorica,
                'profit_factor_teorico': profit_factor_teorico,
                'fase': 1,
                'sistema_versao': 'v8.0.0_roadmap',
                'config_ativo': config_ativo,
                
                # Dados adicionais para análise
                'indicadores': {
                    'ml_supremo': resultado.get('ml_supremo', 0),
                    'optimized': resultado.get('optimized', 0),
                    'premium': resultado.get('premium', 0),
                    'confianca_final': resultado.get('confianca_final', confianca)
                },
                'filtros': {
                    'horario_ok': resultado.get('horario_ok', False),
                    'volume_ok': resultado.get('volume_ok', False),
                    'confluencia_ok': resultado.get('confluencia_ok', False),
                    'filtros_premium': resultado.get('filtros_premium', {})
                },
                'motivo_rejeicao': resultado.get('motivo_rejeicao', ''),
                'dados_mercado': {
                    'volume_24h': resultado.get('volume_24h', 0),
                    'atr': resultado.get('atr', 0),
                    'volatilidade': resultado.get('volatilidade', 0)
                }
            }
            
            # Salvar no arquivo JSONL
            with open(self.trade_log_file, 'a') as f:
                f.write(json.dumps(trade_log, default=str) + '\n')
            
            # Log resumido no console para trades aprovados
            if acao in ['COMPRAR', 'VENDER']:
                print(f"📊 EXPECTATIVA: {symbol} - {acao} - Conf: {confianca:.1f}% - R:R: {rr_ratio:.2f} - Exp: {expectativa_teorica:.3f}")
            
            return trade_log
            
        except Exception as e:
            print(f"❌ Erro no log de expectativa: {e}")
            return None
    
    def calcular_metricas_acumuladas(self):
        """Calcula métricas acumuladas dos trades logados"""
        try:
            if not self.trade_log_file.exists():
                return None
            
            trades = []
            with open(self.trade_log_file, 'r') as f:
                for line in f:
                    try:
                        trades.append(json.loads(line))
                    except:
                        continue
            
            if not trades:
                return None
            
            # Filtrar apenas trades aprovados
            trades_aprovados = [t for t in trades if t.get('acao') in ['COMPRAR', 'VENDER']]
            
            if not trades_aprovados:
                return {
                    'total_sinais': len(trades),
                    'total_trades_aprovados': 0,
                    'taxa_aprovacao': 0,
                    'status': 'Aguardando trades aprovados'
                }
            
            # Calcular métricas básicas
            total_trades = len(trades_aprovados)
            confianca_media = np.mean([t.get('confianca', 0) for t in trades_aprovados])
            rr_medio = np.mean([t.get('rr_ratio', 0) for t in trades_aprovados])
            expectativa_media = np.mean([t.get('expectativa_teorica', 0) for t in trades_aprovados])
            profit_factor_medio = np.mean([t.get('profit_factor_teorico', 0) for t in trades_aprovados if t.get('profit_factor_teorico', 0) != float('inf')])
            
            # Distribuição por símbolo
            simbolos = {}
            for trade in trades_aprovados:
                symbol = trade.get('symbol', 'UNKNOWN')
                simbolos[symbol] = simbolos.get(symbol, 0) + 1
            
            # Análise de qualidade
            trades_rr_bom = len([t for t in trades_aprovados if t.get('rr_ratio', 0) >= 2.0])
            trades_expectativa_positiva = len([t for t in trades_aprovados if t.get('expectativa_teorica', 0) > 0])
            
            # Período de coleta
            timestamps = [datetime.fromisoformat(t['timestamp'].replace('Z', '+00:00')).replace(tzinfo=None) for t in trades]
            periodo_horas = (max(timestamps) - min(timestamps)).total_seconds() / 3600 if len(timestamps) > 1 else 0
            
            metricas = {
                'timestamp': datetime.now().isoformat(),
                'periodo_coleta': {
                    'inicio': min(timestamps).isoformat() if timestamps else None,
                    'fim': max(timestamps).isoformat() if timestamps else None,
                    'duracao_horas': periodo_horas
                },
                'contadores': {
                    'total_sinais': len(trades),
                    'total_trades_aprovados': total_trades,
                    'total_rejeitados': len(trades) - total_trades,
                    'taxa_aprovacao': (total_trades / len(trades)) * 100 if len(trades) > 0 else 0
                },
                'qualidade': {
                    'confianca_media': confianca_media,
                    'rr_medio': rr_medio,
                    'expectativa_media_teorica': expectativa_media,
                    'profit_factor_medio_teorico': profit_factor_medio,
                    'trades_rr_bom': trades_rr_bom,
                    'percent_rr_bom': (trades_rr_bom / total_trades) * 100 if total_trades > 0 else 0,
                    'trades_expectativa_positiva': trades_expectativa_positiva,
                    'percent_expectativa_positiva': (trades_expectativa_positiva / total_trades) * 100 if total_trades > 0 else 0
                },
                'distribuicao': {
                    'simbolos': simbolos,
                    'trades_por_hora': total_trades / max(periodo_horas, 1),
                    'trades_por_dia': total_trades / max(periodo_horas / 24, 1)
                },
                'status_coleta': {
                    'dados_suficientes': total_trades >= 20,
                    'qualidade_boa': expectativa_media > 0.3,
                    'rr_adequado': rr_medio >= 2.0,
                    'aprovacao_adequada': 5 <= (total_trades / len(trades)) * 100 <= 30
                }
            }
            
            # Salvar métricas
            with open(self.metricas_file, 'w') as f:
                json.dump(metricas, f, indent=2, default=str)
            
            return metricas
            
        except Exception as e:
            print(f"❌ Erro no cálculo de métricas: {e}")
            return None
    
    def imprimir_status_coleta(self):
        """Imprime status atual da coleta"""
        metricas = self.calcular_metricas_acumuladas()
        if not metricas:
            print("📊 FASE 1 - BASELINE: Aguardando primeiros trades...")
            return
        
        print(f"\n📊 STATUS COLETA BASELINE:")
        print(f"   Total sinais: {metricas['contadores']['total_sinais']}")
        print(f"   Trades aprovados: {metricas['contadores']['total_trades_aprovados']}")
        print(f"   Taxa aprovação: {metricas['contadores']['taxa_aprovacao']:.1f}%")
        print(f"   Confiança média: {metricas['qualidade']['confianca_media']:.1f}%")
        print(f"   R:R médio: {metricas['qualidade']['rr_medio']:.2f}")
        print(f"   Expectativa teórica: {metricas['qualidade']['expectativa_media_teorica']:.3f}")
        print(f"   Período coleta: {metricas['periodo_coleta']['duracao_horas']:.1f}h")
        
        # Status da coleta
        status = metricas['status_coleta']
        if status['dados_suficientes']:
            print("✅ DADOS SUFICIENTES PARA ANÁLISE BASELINE!")
        else:
            faltam = 20 - metricas['contadores']['total_trades_aprovados']
            print(f"⏳ Faltam {faltam} trades para análise completa")
        
        # Alertas de qualidade
        if not status['qualidade_boa']:
            print("⚠️ ALERTA: Expectativa teórica baixa - revisar filtros")
        
        if not status['rr_adequado']:
            print("⚠️ ALERTA: R:R médio baixo - otimizar SL/TP")
        
        if not status['aprovacao_adequada']:
            if metricas['contadores']['taxa_aprovacao'] > 30:
                print("⚠️ ALERTA: Taxa de aprovação alta - filtros podem estar frouxos")
            else:
                print("⚠️ ALERTA: Taxa de aprovação baixa - filtros podem estar rigorosos demais")
    
    def gerar_relatorio_detalhado(self):
        """Gera relatório detalhado da coleta"""
        metricas = self.calcular_metricas_acumuladas()
        if not metricas:
            print("❌ Sem dados para relatório")
            return None
        
        # Carregar todos os trades para análise detalhada
        trades = []
        with open(self.trade_log_file, 'r') as f:
            for line in f:
                try:
                    trades.append(json.loads(line))
                except:
                    continue
        
        trades_aprovados = [t for t in trades if t.get('acao') in ['COMPRAR', 'VENDER']]
        
        # Análise por símbolo
        analise_simbolos = {}
        for symbol in metricas['distribuicao']['simbolos']:
            trades_symbol = [t for t in trades_aprovados if t.get('symbol') == symbol]
            if trades_symbol:
                analise_simbolos[symbol] = {
                    'total_trades': len(trades_symbol),
                    'confianca_media': np.mean([t.get('confianca', 0) for t in trades_symbol]),
                    'rr_medio': np.mean([t.get('rr_ratio', 0) for t in trades_symbol]),
                    'expectativa_media': np.mean([t.get('expectativa_teorica', 0) for t in trades_symbol])
                }
        
        # Análise temporal
        timestamps = [datetime.fromisoformat(t['timestamp'].replace('Z', '+00:00')).replace(tzinfo=None) for t in trades_aprovados]
        if timestamps:
            horas = [t.hour for t in timestamps]
            analise_temporal = {
                'hora_mais_ativa': max(set(horas), key=horas.count),
                'distribuicao_horas': {h: horas.count(h) for h in set(horas)}
            }
        else:
            analise_temporal = {}
        
        relatorio = {
            'timestamp_relatorio': datetime.now().isoformat(),
            'metricas_gerais': metricas,
            'analise_por_simbolo': analise_simbolos,
            'analise_temporal': analise_temporal,
            'recomendacoes': self._gerar_recomendacoes(metricas, analise_simbolos)
        }
        
        # Salvar relatório
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        relatorio_file = self.base_dir / "reports" / f"relatorio_baseline_{timestamp}.json"
        relatorio_file.parent.mkdir(exist_ok=True)
        
        with open(relatorio_file, 'w') as f:
            json.dump(relatorio, f, indent=2, default=str)
        
        print(f"\n📄 Relatório detalhado salvo em: {relatorio_file}")
        return relatorio
    
    def _gerar_recomendacoes(self, metricas, analise_simbolos):
        """Gera recomendações baseadas na análise"""
        recomendacoes = []
        
        qualidade = metricas['qualidade']
        
        # Recomendações de R:R
        if qualidade['rr_medio'] < 2.0:
            recomendacoes.append({
                'tipo': 'rr_baixo',
                'prioridade': 'alta',
                'descricao': f"R:R médio de {qualidade['rr_medio']:.2f} está abaixo do ideal (2.0+)",
                'acao': "Implementar otimização de Stop Loss e Take Profit na Fase 2"
            })
        
        # Recomendações de expectativa
        if qualidade['expectativa_media_teorica'] < 0.3:
            recomendacoes.append({
                'tipo': 'expectativa_baixa',
                'prioridade': 'alta',
                'descricao': f"Expectativa teórica de {qualidade['expectativa_media_teorica']:.3f} está baixa",
                'acao': "Revisar filtros de qualidade e aumentar rigor na seleção"
            })
        
        # Recomendações de taxa de aprovação
        taxa_aprovacao = metricas['contadores']['taxa_aprovacao']
        if taxa_aprovacao > 30:
            recomendacoes.append({
                'tipo': 'aprovacao_alta',
                'prioridade': 'media',
                'descricao': f"Taxa de aprovação de {taxa_aprovacao:.1f}% pode estar alta",
                'acao': "Considerar filtros mais rigorosos para melhorar qualidade"
            })
        elif taxa_aprovacao < 5:
            recomendacoes.append({
                'tipo': 'aprovacao_baixa',
                'prioridade': 'media',
                'descricao': f"Taxa de aprovação de {taxa_aprovacao:.1f}% pode estar muito baixa",
                'acao': "Revisar filtros para não perder oportunidades válidas"
            })
        
        # Recomendações por símbolo
        for symbol, dados in analise_simbolos.items():
            if dados['expectativa_media'] < 0:
                recomendacoes.append({
                    'tipo': 'simbolo_problematico',
                    'prioridade': 'baixa',
                    'descricao': f"{symbol} tem expectativa negativa ({dados['expectativa_media']:.3f})",
                    'acao': f"Considerar ajustar parâmetros específicos para {symbol}"
                })
        
        return recomendacoes

# Instância global para uso fácil
_logger_expectativa = None

def inicializar_logging_expectativa(base_dir="roadmap_expectativa"):
    """Inicializa o sistema de logging de expectativa"""
    global _logger_expectativa
    _logger_expectativa = LoggingExpectativa(base_dir)
    print("✅ Sistema de logging de expectativa matemática inicializado")
    return _logger_expectativa

def log_trade_expectativa(symbol, resultado, config_ativo=None):
    """Função wrapper para logging de trade"""
    if _logger_expectativa:
        return _logger_expectativa.log_trade_expectativa(symbol, resultado, config_ativo)
    else:
        print("⚠️ Logger de expectativa não inicializado")
        return None

def imprimir_status_coleta():
    """Função wrapper para status da coleta"""
    if _logger_expectativa:
        _logger_expectativa.imprimir_status_coleta()
    else:
        print("⚠️ Logger de expectativa não inicializado")

def calcular_metricas_acumuladas():
    """Função wrapper para cálculo de métricas"""
    if _logger_expectativa:
        return _logger_expectativa.calcular_metricas_acumuladas()
    else:
        print("⚠️ Logger de expectativa não inicializado")
        return None

def gerar_relatorio_detalhado():
    """Função wrapper para relatório detalhado"""
    if _logger_expectativa:
        return _logger_expectativa.gerar_relatorio_detalhado()
    else:
        print("⚠️ Logger de expectativa não inicializado")
        return None

# Função para integração fácil no main.py
def integrar_logging_expectativa(base_dir="roadmap_expectativa"):
    """Função para ser chamada no main.py"""
    logger = inicializar_logging_expectativa(base_dir)
    print("🔍 Sistema de logging de expectativa matemática ativo")
    return {
        'log_trade': log_trade_expectativa,
        'calcular_metricas': calcular_metricas_acumuladas,
        'status': imprimir_status_coleta,
        'relatorio': gerar_relatorio_detalhado,
        'logger': logger
    }

if __name__ == "__main__":
    # Teste do sistema
    logger = inicializar_logging_expectativa()
    
    # Simular alguns trades para teste
    resultado_teste = {
        'acao': 'COMPRAR',
        'confianca': 75.5,
        'preco_entrada': 50000,
        'stop_loss': 48500,
        'take_profit': 53500,
        'ml_supremo': 72,
        'optimized': 68,
        'premium': 78
    }
    
    log_trade_expectativa('BTCUSDT', resultado_teste)
    imprimir_status_coleta()
    print("\n✅ Teste do sistema de logging concluído")

