# -*- coding: utf-8 -*-
"""
Executor Completo de Backtesting - Sistema ML Supremo

Este script executa o backtesting completo usando componentes standalone.

Autor: Manus AI
Data: 30/08/2025
Versão: 1.0.0
"""

import logging
import os
from datetime import datetime

# Importar componentes standalone
from data_collector import DataCollector
from backtester_standalone import BacktesterStandalone
from performance_metrics import PerformanceMetrics
from report_generator import ReportGenerator

def main():
    """
    Executa o backtesting completo do Sistema ML Supremo.
    """
    # Configurar logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    print("🚀 INICIANDO BACKTESTING COMPLETO DO SISTEMA ML SUPREMO")
    print("=" * 60)
    
    # Configuração
    config = {
        'capital_inicial': 10000,
        'custo_operacao': 0.001,  # 0.1%
        'binance_api_key': '',  # Cliente público
        'binance_api_secret': ''
    }
    
    # Símbolos para testar
    symbols = ['BTCUSDT', 'ETHUSDT']
    interval = '1h'
    start_date = '2024-01-01'
    end_date = '2024-03-01'  # 2 meses de dados
    
    # Inicializar componentes
    logger.info("🔧 Inicializando componentes...")
    data_collector = DataCollector(config)
    backtester = BacktesterStandalone(config)
    metrics_calculator = PerformanceMetrics()
    report_generator = ReportGenerator(config)
    
    results = {}
    
    # Processar cada símbolo
    for symbol in symbols:
        print(f"\n📊 PROCESSANDO {symbol}")
        print("-" * 40)
        
        try:
            # 1. Coletar dados históricos
            logger.info(f"📈 Coletando dados para {symbol}...")
            historical_data = data_collector.collect_historical_data(
                symbol=symbol,
                interval=interval,
                start_date=start_date,
                end_date=end_date
            )
            
            if historical_data.empty:
                logger.warning(f"⚠️ Nenhum dado encontrado para {symbol}")
                continue
            
            print(f"✅ Dados coletados: {len(historical_data)} registros")
            print(f"📅 Período: {historical_data.index[0]} até {historical_data.index[-1]}")
            
            # 2. Executar backtesting
            logger.info(f"🧪 Executando backtesting para {symbol}...")
            backtest_results = backtester.run(historical_data)
            
            if not backtest_results.get('sucesso', False):
                logger.warning(f"⚠️ Falha no backtesting para {symbol}")
                continue
            
            # 3. Calcular métricas
            logger.info(f"📊 Calculando métricas para {symbol}...")
            metrics = metrics_calculator.calculate_all_metrics(
                capital_history=backtest_results['historico_capital'],
                trades=backtest_results['trades'],
                initial_capital=config['capital_inicial']
            )
            
            # 4. Gerar relatório
            logger.info(f"📄 Gerando relatório para {symbol}...")
            report_path = report_generator.generate_report(
                metrics=metrics,
                capital_history=backtest_results['historico_capital'],
                symbol=symbol,
                interval=interval
            )
            
            # 5. Salvar resultados
            results[symbol] = {
                'metrics': metrics,
                'backtest_results': backtest_results,
                'report_path': report_path,
                'data_points': len(historical_data)
            }
            
            # Mostrar resumo
            print(f"💰 Capital inicial: ${config['capital_inicial']:,.2f}")
            print(f"💰 Capital final: ${backtest_results['capital_final']:,.2f}")
            print(f"📈 Retorno total: {metrics['retorno_total_pct']:.2f}%")
            print(f"📊 Sharpe Ratio: {metrics['sharpe_ratio']:.2f}")
            print(f"📉 Max Drawdown: {metrics['max_drawdown_pct']:.2f}%")
            print(f"🎯 Win Rate: {metrics['win_rate']:.1%}")
            print(f"🏆 Classificação: {metrics['classificacao']}")
            print(f"📄 Relatório: {os.path.basename(report_path)}")
            
        except Exception as e:
            logger.error(f"❌ Erro ao processar {symbol}: {e}")
            results[symbol] = {'error': str(e)}
    
    # Gerar relatório consolidado
    print(f"\n📋 RELATÓRIO CONSOLIDADO")
    print("=" * 60)
    
    if results:
        print("| Símbolo | Retorno | Sharpe | Drawdown | Win Rate | Classificação |")
        print("|---------|---------|--------|----------|----------|---------------|")
        
        for symbol, result in results.items():
            if 'error' not in result:
                m = result['metrics']
                print(f"| {symbol:7} | {m['retorno_total_pct']:6.2f}% | {m['sharpe_ratio']:6.2f} | {m['max_drawdown_pct']:7.2f}% | {m['win_rate']:7.1%} | {m['classificacao']:13} |")
            else:
                print(f"| {symbol:7} | ERRO: {result['error'][:50]}... |")
    
    # Análise final
    print(f"\n🎯 ANÁLISE FINAL")
    print("-" * 30)
    
    successful_results = [r for r in results.values() if 'error' not in r]
    
    if successful_results:
        avg_return = sum(r['metrics']['retorno_total_pct'] for r in successful_results) / len(successful_results)
        avg_sharpe = sum(r['metrics']['sharpe_ratio'] for r in successful_results) / len(successful_results)
        
        print(f"✅ Símbolos processados com sucesso: {len(successful_results)}")
        print(f"📈 Retorno médio: {avg_return:.2f}%")
        print(f"📊 Sharpe Ratio médio: {avg_sharpe:.2f}")
        
        # Classificação geral
        if avg_sharpe >= 1.5 and avg_return >= 15:
            classificacao_geral = "EXCELENTE"
        elif avg_sharpe >= 1.0 and avg_return >= 10:
            classificacao_geral = "MUITO BOM"
        elif avg_sharpe >= 0.5 and avg_return >= 5:
            classificacao_geral = "BOM"
        else:
            classificacao_geral = "REGULAR"
        
        print(f"🏆 Classificação geral do sistema: {classificacao_geral}")
        
        # Recomendações
        print(f"\n💡 RECOMENDAÇÕES:")
        if avg_sharpe >= 1.0:
            print("✅ Sistema mostra boa relação risco-retorno")
        else:
            print("⚠️ Considere ajustar parâmetros para melhorar Sharpe Ratio")
        
        if avg_return >= 10:
            print("✅ Retornos são promissores para trading real")
        else:
            print("⚠️ Retornos podem não cobrir custos operacionais reais")
    
    else:
        print("❌ Nenhum símbolo foi processado com sucesso")
    
    print(f"\n🎉 BACKTESTING COMPLETO FINALIZADO!")
    print(f"📁 Relatórios salvos em: backtesting_reports/")
    
    return results

if __name__ == '__main__':
    main()

