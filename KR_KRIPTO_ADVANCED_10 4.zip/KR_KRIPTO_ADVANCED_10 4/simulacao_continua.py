#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Implementação do modo de simulação contínua para o sistema KR_KRIPTO_ADVANCED_COPIA

Este módulo implementa um modo de simulação contínua que permite que o sistema
execute por períodos prolongados sem encerramento prematuro após processar
dados históricos, possibilitando testes de carga e validação de estabilidade.
"""

import os
import sys
import time
import json
import random
import logging
import argparse
import datetime
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from logging.handlers import TimedRotatingFileHandler

# Adicionar diretório pai ao path para importar módulos do projeto
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Importar módulos do projeto
from main import (
    carregar_config, 
    inicializar_componentes, 
    processar_dados, 
    global_state,
    logger
)

class SimuladorContinuo:
    """
    Classe para executar simulação contínua do sistema KR_KRIPTO_ADVANCED_COPIA.
    
    Esta classe permite que o sistema execute por períodos prolongados,
    gerando dados sintéticos baseados em dados históricos reais e
    monitorando o desempenho e estabilidade do sistema.
    """
    
    def __init__(self, config: dict):
        """
        Inicializa o simulador contínuo.
        
        Args:
            config_path: Caminho para o arquivo de configuração
            dados_historicos_path: Caminho para o arquivo de dados históricos (opcional)
        """
        self.config_path = config_path
        self.dados_historicos_path = dados_historicos_path
        self.config = {}
        self.dados_historicos = []
        self.running = False
        self.ciclos_executados = 0
        self.inicio_simulacao = None
        self.ultima_atualizacao = None
        self.metricas = {
            "ciclos_executados": 0,
            "erros_detectados": 0,
            "tempo_medio_processamento": 0.0,
            "memoria_utilizada": 0.0,
            "decisoes": {
                "BUY": 0,
                "SELL": 0,
                "HOLD": 0
            }
        }
        
        # Configurar logger específico para o simulador
        self.logger = logging.getLogger("simulador_continuo")
        if not self.logger.handlers:
            log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'logs')
            os.makedirs(log_dir, exist_ok=True)
            log_file = os.path.join(log_dir, 'simulador_continuo.log')
            
            handler = TimedRotatingFileHandler(
                filename=log_file,
                when='midnight',
                interval=1,
                backupCount=30,
                encoding='utf-8'
            )
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            
            # Adicionar handler para console também
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setFormatter(formatter)
            self.logger.addHandler(console_handler)
            
            self.logger.setLevel(logging.INFO)
            self.logger.info("Logger configurado com rotação diária para simulador_continuo")
    
    def carregar_dados_historicos(self) -> bool:
        """
        Carrega dados históricos para uso na simulação.
        
        Returns:
            bool: True se os dados foram carregados com sucesso, False caso contrário
        """
        if not self.dados_historicos_path:
            self.logger.warning("Caminho para dados históricos não fornecido. Usando dados sintéticos.")
            return False
        
        try:
            self.logger.info(f"Carregando dados históricos de {self.dados_historicos_path}")
            df = pd.read_csv(self.dados_historicos_path)
            
            # Verificar se as colunas necessárias estão presentes
            colunas_necessarias = ['timestamp', 'open', 'high', 'low', 'close', 'volume']
            for coluna in colunas_necessarias:
                if coluna not in df.columns:
                    self.logger.error(f"Coluna {coluna} não encontrada nos dados históricos")
                    return False
            
            # Converter para lista de dicionários
            self.dados_historicos = df.to_dict('records')
            self.logger.info(f"Dados históricos carregados com sucesso: {len(self.dados_historicos)} registros")
            return True
        except Exception as e:
            self.logger.error(f"Erro ao carregar dados históricos: {str(e)}", exc_info=True)
            return False
    
    def gerar_dados_sinteticos(self, base_dados: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Gera dados sintéticos para simulação contínua.
        
        Args:
            base_dados: Dados base para gerar variações (opcional)
            
        Returns:
            Dict[str, Any]: Dados sintéticos gerados
        """
        timestamp = datetime.datetime.now().isoformat()
        
        if base_dados:
            # Gerar variações a partir dos dados base
            variacao = random.uniform(-0.01, 0.01)  # Variação de até 1%
            
            open_price = base_dados['open'] * (1 + variacao)
            close_price = open_price * (1 + random.uniform(-0.005, 0.005))
            high_price = max(open_price, close_price) * (1 + random.uniform(0, 0.003))
            low_price = min(open_price, close_price) * (1 - random.uniform(0, 0.003))
            volume = base_dados['volume'] * (1 + random.uniform(-0.2, 0.2))
        else:
            # Gerar dados completamente aleatórios
            base_price = 50000.0  # Preço base para BTC
            variacao = random.uniform(-0.02, 0.02)  # Variação de até 2%
            
            open_price = base_price * (1 + variacao)
            close_price = open_price * (1 + random.uniform(-0.01, 0.01))
            high_price = max(open_price, close_price) * (1 + random.uniform(0, 0.005))
            low_price = min(open_price, close_price) * (1 - random.uniform(0, 0.005))
            volume = random.uniform(10.0, 100.0)
        
        return {
            "timestamp": timestamp,
            "open": open_price,
            "high": high_price,
            "low": low_price,
            "close": close_price,
            "volume": volume
        }
    
    def inicializar_sistema(self) -> bool:
        """
        Inicializa o sistema KR_KRIPTO_ADVANCED_COPIA para simulação.
        
        Returns:
            bool: True se o sistema foi inicializado com sucesso, False caso contrário
        """
        try:
            self.logger.info(f"Inicializando sistema com configuração de {self.config_path}")
            
            # Carregar configuração
            self.config = carregar_config(self.config_path)
            if not self.config:
                self.logger.error("Falha ao carregar configuração")
                return False
            
            # Inicializar componentes
            if not inicializar_componentes(self.config):
                self.logger.error("Falha ao inicializar componentes")
                return False
            
            self.logger.info("Sistema inicializado com sucesso")
            return True
        except Exception as e:
            self.logger.error(f"Erro ao inicializar sistema: {str(e)}", exc_info=True)
            return False
    
    def executar_ciclo_simulacao(self) -> Tuple[bool, Dict[str, Any]]:
        """
        Executa um ciclo de simulação, processando dados sintéticos.
        
        Returns:
            Tuple[bool, Dict[str, Any]]: (Sucesso, Resultado do processamento)
        """
        try:
            # Selecionar dados base para gerar variações
            if self.dados_historicos and len(self.dados_historicos) > 0:
                indice = random.randint(0, len(self.dados_historicos) - 1)
                base_dados = self.dados_historicos[indice]
            else:
                base_dados = None
            
            # Gerar dados sintéticos
            dados = self.gerar_dados_sinteticos(base_dados)
            
            # Registrar início do processamento
            inicio_processamento = time.time()
            
            # Processar dados
            resultado = processar_dados(self.config, dados)
            
            # Registrar fim do processamento
            fim_processamento = time.time()
            tempo_processamento = fim_processamento - inicio_processamento
            
            # Atualizar métricas
            self.metricas["ciclos_executados"] += 1
            self.metricas["tempo_medio_processamento"] = (
                (self.metricas["tempo_medio_processamento"] * (self.metricas["ciclos_executados"] - 1) + tempo_processamento) / 
                self.metricas["ciclos_executados"]
            )
            
            if "errors" in resultado and resultado["errors"]:
                self.metricas["erros_detectados"] += 1
            
            if "decisions" in resultado and "final_decision" in resultado["decisions"]:
                decisao = resultado["decisions"]["final_decision"]
                if decisao in self.metricas["decisoes"]:
                    self.metricas["decisoes"][decisao] += 1
            
            self.ciclos_executados += 1
            self.ultima_atualizacao = datetime.datetime.now()
            
            return True, resultado
        except Exception as e:
            self.logger.error(f"Erro ao executar ciclo de simulação: {str(e)}", exc_info=True)
            return False, {"errors": [f"Erro na simulação: {str(e)}"]}
    
    def iniciar_simulacao(self, duracao_segundos: int = 600, intervalo_segundos: float = 1.0) -> bool:
        """
        Inicia a simulação contínua por um período determinado.
        
        Args:
            duracao_segundos: Duração total da simulação em segundos
            intervalo_segundos: Intervalo entre ciclos de simulação em segundos
            
        Returns:
            bool: True se a simulação foi concluída com sucesso, False caso contrário
        """
        if not self.inicializar_sistema():
            self.logger.error("Falha ao inicializar sistema para simulação")
            return False
        
        if not self.dados_historicos_path:
            self.logger.warning("Dados históricos não fornecidos. Usando dados sintéticos aleatórios.")
        else:
            if not self.carregar_dados_historicos():
                self.logger.warning("Falha ao carregar dados históricos. Usando dados sintéticos aleatórios.")
        
        self.running = True
        self.inicio_simulacao = datetime.datetime.now()
        self.ultima_atualizacao = self.inicio_simulacao
        
        self.logger.info(f"Iniciando simulação contínua por {duracao_segundos} segundos com intervalo de {intervalo_segundos} segundos")
        
        try:
            tempo_inicio = time.time()
            tempo_atual = tempo_inicio
            
            while self.running and (tempo_atual - tempo_inicio) < duracao_segundos:
                # Executar ciclo de simulação
                sucesso, resultado = self.executar_ciclo_simulacao()
                
                if not sucesso:
                    self.logger.warning("Ciclo de simulação falhou")
                
                # Registrar progresso a cada 10 ciclos
                if self.ciclos_executados % 10 == 0:
                    tempo_decorrido = tempo_atual - tempo_inicio
                    tempo_restante = duracao_segundos - tempo_decorrido
                    self.logger.info(f"Simulação em andamento: {self.ciclos_executados} ciclos executados, {tempo_decorrido:.1f}s decorridos, {tempo_restante:.1f}s restantes")
                    self.registrar_metricas()
                
                # Aguardar intervalo
                time.sleep(intervalo_segundos)
                tempo_atual = time.time()
            
            tempo_total = time.time() - tempo_inicio
            self.logger.info(f"Simulação concluída: {self.ciclos_executados} ciclos executados em {tempo_total:.1f} segundos")
            self.registrar_metricas()
            
            return True
        except KeyboardInterrupt:
            self.logger.info("Simulação interrompida pelo usuário")
            self.running = False
            return False
        except Exception as e:
            self.logger.error(f"Erro durante simulação: {str(e)}", exc_info=True)
            self.running = False
            return False
    
    def parar_simulacao(self) -> None:
        """
        Para a simulação em andamento.
        """
        self.logger.info("Parando simulação")
        self.running = False
    
    def registrar_metricas(self) -> None:
        """
        Registra métricas da simulação no log.
        """
        if not self.inicio_simulacao:
            return
        
        tempo_total = (datetime.datetime.now() - self.inicio_simulacao).total_seconds()
        
        self.logger.info(f"Métricas da simulação após {tempo_total:.1f} segundos:")
        self.logger.info(f"  - Ciclos executados: {self.metricas['ciclos_executados']}")
        self.logger.info(f"  - Erros detectados: {self.metricas['erros_detectados']}")
        self.logger.info(f"  - Tempo médio de processamento: {self.metricas['tempo_medio_processamento'] * 1000:.2f} ms")
        self.logger.info(f"  - Decisões: BUY={self.metricas['decisoes']['BUY']}, SELL={self.metricas['decisoes']['SELL']}, HOLD={self.metricas['decisoes']['HOLD']}")
    
    def salvar_resultados(self, caminho_saida: str) -> bool:
        """
        Salva os resultados da simulação em um arquivo JSON.
        
        Args:
            caminho_saida: Caminho para o arquivo de saída
            
        Returns:
            bool: True se os resultados foram salvos com sucesso, False caso contrário
        """
        if not self.inicio_simulacao:
            self.logger.error("Nenhuma simulação foi executada")
            return False
        
        try:
            tempo_total = (datetime.datetime.now() - self.inicio_simulacao).total_seconds()
            
            resultados = {
                "inicio_simulacao": self.inicio_simulacao.isoformat(),
                "fim_simulacao": datetime.datetime.now().isoformat(),
                "duracao_segundos": tempo_total,
                "ciclos_executados": self.ciclos_executados,
                "metricas": self.metricas,
                "configuracao": {
                    "config_path": self.config_path,
                    "dados_historicos_path": self.dados_historicos_path
                }
            }
            
            with open(caminho_saida, 'w') as f:
                json.dump(resultados, f, indent=2)
            
            self.logger.info(f"Resultados da simulação salvos em {caminho_saida}")
            return True
        except Exception as e:
            self.logger.error(f"Erro ao salvar resultados: {str(e)}", exc_info=True)
            return False

def main():
    """
    Função principal para executar o simulador contínuo.
    """
    parser = argparse.ArgumentParser(description='Simulador Contínuo para KR_KRIPTO_ADVANCED_COPIA')
    parser.add_argument('--config', type=str, default='config.json', help='Caminho para o arquivo de configuração')
    parser.add_argument('--dados', type=str, help='Caminho para o arquivo de dados históricos')
    parser.add_argument('--duracao', type=int, default=600, help='Duração da simulação em segundos')
    parser.add_argument('--intervalo', type=float, default=1.0, help='Intervalo entre ciclos em segundos')
    parser.add_argument('--saida', type=str, help='Caminho para o arquivo de saída dos resultados')
    
    args = parser.parse_args()
    
    # Criar simulador
    simulador = SimuladorContinuo(config={'config_path': args.config, 'dados_historicos_path': args.dados})
    
    # Iniciar simulação
    sucesso = simulador.iniciar_simulacao(duracao_segundos=args.duracao, intervalo_segundos=args.intervalo)
    
    # Salvar resultados
    if sucesso and args.saida:
        simulador.salvar_resultados(args.saida)
    
    return 0 if sucesso else 1

if __name__ == "__main__":
    sys.exit(main())
