# src/config/logging_config.py

import logging
import os
from logging.handlers import TimedRotatingFileHandler
from pythonjsonlogger import jsonlogger

def setup_logging(log_level=logging.INFO, log_dir="logs"):
    """Configura o logging para usar formato JSON estruturado com rotação automática de logs."""
    # Criar diretório de logs se não existir
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))) # Navega 3 níveis acima (src -> KR_KRIPTO_ADVANCED_REORGANIZED)
    log_path = os.path.join(base_dir, log_dir)
    os.makedirs(log_path, exist_ok=True)
    log_file = os.path.join(log_path, "kripto_tool.log")
    print(f"DEBUG [logging_config]: Calculated log_file path: {os.path.abspath(log_file)}") # Debug print

    # Obter o logger raiz
    logger = logging.getLogger()
    logger.setLevel(log_level)

    # Remover handlers existentes para evitar duplicação
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)

    # Criar formatter JSON
    # Formato sugerido: timestamp, level, name (módulo), message, e campos extras
    formatter = jsonlogger.JsonFormatter(
        fmt="%(asctime)s %(levelname)s %(name)s %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S%z"
    )

    # Criar handler para console
    logHandlerStream = logging.StreamHandler()
    logHandlerStream.setFormatter(formatter)
    logger.addHandler(logHandlerStream)
    
    # Criar handler para arquivo com rotação
    logHandlerFile = TimedRotatingFileHandler(
        filename=log_file,
        when='midnight',
        interval=1,
        backupCount=30,
        encoding='utf-8'
    )
    logHandlerFile.setFormatter(formatter)
    logger.addHandler(logHandlerFile)

    logging.info(f"Logging configurado com formato JSON e rotação diária. Nível: {logging.getLevelName(log_level)}. Arquivo: {log_file}")

# Exemplo de como usar:
# from config.logging_config import setup_logging
# setup_logging()
# import logging
# logger = logging.getLogger(__name__)
# logger.info("Esta é uma mensagem de log estruturada.", extra={\'custom_field\': \'valor\'})
