# src/core/config_loader.py
"""Loads configuration from a JSON file."""

import json
import logging
import os # Import os for path joining if needed

# Constants required by main.py
CONFIG_FILE = "config.json"
# Assuming DATA_DIR should be relative to the project root
DATA_DIR = "data/"

logger = logging.getLogger(__name__)

def load_config(caminho_arquivo: str = CONFIG_FILE) -> dict:
    """Carrega a configuração de um arquivo JSON.

    Args:
        caminho_arquivo: O caminho para o arquivo config.json. Defaults to CONFIG_FILE.

    Returns:
        Um dicionário contendo a configuração.
    """
    try:
        with open(caminho_arquivo, 'r', encoding='utf-8') as f:
            config = json.load(f)
            logger.info(f"Configuração carregada com sucesso de {caminho_arquivo}")
            return config
    except FileNotFoundError:
        logger.error(f"Arquivo de configuração não encontrado: {caminho_arquivo}")
        return {}
    except json.JSONDecodeError as e:
        logger.error(f"Erro ao decodificar JSON em {caminho_arquivo}: {e}")
        return {}
    except Exception as e:
        logger.error(f"Erro inesperado ao carregar configuração de {caminho_arquivo}: {e}")
        return {}

