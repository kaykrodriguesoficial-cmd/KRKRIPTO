"""
Módulo Fundido: Streaming da Binance com Resiliência Avançada

Combina as funcionalidades de binance_stream.py e binance_stream_resilient.py,
incorporando:
- Mecanismos robustos de reconexão (backoff exponencial, jitter)
- Circuit breaker para evitar sobrecarga
- Logging avançado com rotação de arquivos
- Estatísticas detalhadas de conexão
- Cache de dados (kline, ticker)
- Sistema flexível de callbacks
- Integração com Prometheus
- Suporte a modos worker/master e comunicação ZMQ
- Simulação E2E para testes
- Monitoramento de heartbeat e silêncio de mensagens
"""

import asyncio
import aiohttp
import json
import logging
from logging.handlers import TimedRotatingFileHandler
import traceback
import pandas as pd
import zmq
import zmq.asyncio
from typing import Dict, Any, Optional, List, Callable, Coroutine, Set, Tuple
import os
import errno
import time
import datetime
import sys
import random
import functools

# Importar componentes internos necessários (ajustar caminhos se necessário)
try:
    from src.core.data_handler import carregar_dados_historicos
except ImportError:
    # Fallback ou log de erro se o módulo não for encontrado
    logging.warning("Módulo src.core.data_handler não encontrado. Funcionalidade de carregamento histórico pode ser limitada.")
    # Definir uma função dummy se necessário
    async def carregar_dados_historicos(*args, **kwargs):
        logging.error("Função carregar_dados_historicos não disponível.")
        return None

try:
    from src.realtime.book_processor import BookProcessor, BookState
except ImportError:
    logging.warning("Módulo src.realtime.book_processor não encontrado. Processamento de livro de ordens desativado.")
    BookProcessor = None
    BookState = None

try:
    from src.core.network_resilience import NetworkResilience, NetworkFailureType
except ImportError:
    logging.warning("Módulo src.core.network_resilience não encontrado. Usando implementação interna.")
    
    # Definição interna para manter compatibilidade
    class NetworkFailureType:
        """Tipos de falhas de rede."""
        CONNECTION_REFUSED = "connection_refused"
        TIMEOUT = "timeout"
        CONNECTION_RESET = "connection_reset"
        CONNECTION_CLOSED = "connection_closed"
        DNS_FAILURE = "dns_failure"
        SSL_ERROR = "ssl_error"
        UNKNOWN = "unknown"
    
    class NetworkResilience:
        """Implementação interna simplificada para manter compatibilidade."""
        def __init__(self, max_retries=5, base_delay=1.0, max_delay=60.0, jitter=0.1, timeout=30.0):
            self.max_retries = max_retries
            self.base_delay = base_delay
            self.max_delay = max_delay
            self.jitter = jitter
            self.timeout = timeout
        
        async def execute_with_retry(self, operation, operation_name, context=None):
            """Executa uma operação com retry em caso de falha."""
            retry_count = 0
            while True:
                try:
                    return await operation()
                except Exception as e:
                    retry_count += 1
                    if retry_count > self.max_retries:
                        raise
                    delay = min(self.base_delay * (2 ** (retry_count - 1)), self.max_delay)
                    delay = delay * (1 + random.uniform(-self.jitter, self.jitter))
                    logging.warning(f"Retry {retry_count}/{self.max_retries} para {operation_name} após {delay:.2f}s. Erro: {e}")
                    await asyncio.sleep(delay)

# Configurar logging com rotação
log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'logs')
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, 'binance_stream_fundido.log')

# Configurar logger com rotação diária
logger = logging.getLogger("kr_kripto_stream_fundido")
if not logger.handlers:
    # Remover handlers existentes para evitar duplicação em reloads
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
        handler.close()

    handler = TimedRotatingFileHandler(
        filename=log_file,
        when='midnight',
        interval=1,
        backupCount=30,
        encoding='utf-8'
    )
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Adicionar handler para console também
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    logger.setLevel(logging.INFO) # Nível padrão, pode ser ajustado via config
    logger.info("Logger configurado com rotação diária para binance_stream_fundido")

# Prometheus metrics
try:
    from src.infrastructure.prometheus_exporter import inc_errors, set_active_connection, update_last_signal_timestamp, websocket_message_counter, websocket_connection_status, websocket_reconnect_counter, rest_api_call_counter, cache_hit_counter, cache_miss_counter
    PROMETHEUS_AVAILABLE = True
    logger.info("Integração com Prometheus habilitada.")
except ImportError:
    PROMETHEUS_AVAILABLE = False
    logger.warning("Módulo Prometheus não encontrado. Métricas desativadas.")
    # Define stubs if Prometheus is not available
    def inc_errors(*args, **kwargs): pass
    def set_active_connection(*args, **kwargs): pass
    def update_last_signal_timestamp(*args, **kwargs): pass
    def websocket_message_counter(*args, **kwargs): pass
    def websocket_connection_status(*args, **kwargs): pass
    def websocket_reconnect_counter(*args, **kwargs): pass
    def rest_api_call_counter(*args, **kwargs): pass
    def cache_hit_counter(*args, **kwargs): pass
    def cache_miss_counter(*args, **kwargs): pass

# Constants
DEFAULT_MAX_RECONNECT_ATTEMPTS = 10
DEFAULT_BASE_DELAY = 2.0
DEFAULT_MAX_DELAY = 300.0  # 5 minutos
DEFAULT_JITTER = 0.1  # 10% de variação aleatória
DEFAULT_TIMEOUT = 30.0  # Timeout padrão para conexões
DATA_DIR = "data"
HEARTBEAT_INTERVAL = 30  # Segundos para verificar heartbeat
MAX_MESSAGE_SILENCE = 60  # Segundos máximos sem mensagens antes de considerar conexão inativa

# Default TTLs for aggressive cache (in seconds)
DEFAULT_CACHE_TTL = {
    "kline_1m": 60 * 2 + 10,  # 2 minutos + 10s buffer
    "kline_5m": 60 * 5 * 2 + 30,  # 10 minutos + 30s buffer
    "kline_15m": 60 * 15 * 2 + 60,  # 30 minutos + 60s buffer
    "kline_1h": 60 * 60 * 2 + 60,  # 2 horas + 60s buffer
    "kline_4h": 60 * 60 * 4 * 2 + 120,  # 8 horas + 120s buffer
    "kline_1d": 60 * 60 * 24 * 2 + 300,  # 2 dias + 300s buffer
    "ticker": 10,  # Tickers mudam muito rápido
    "depth": 5,  # Depth muda muito rápido
    "default": 60  # Valor padrão para outros tipos
}

# Default minimum interval between REST calls for the same resource (in seconds)
DEFAULT_MIN_REST_INTERVAL = {
    "kline": 5,
    "ticker": 2,
    "depth": 2,
    "default": 5
}

# --- Classes de Suporte --- #

class ConnectionStats:
    """Classe para rastrear estatísticas de conexão e mensagens."""
    def __init__(self, ativo: str = "BTCUSDT", config: Dict[str, Any] = None):
        self.ativo = ativo
        self.mensagens_recebidas = {"kline": 0, "depthUpdate": 0, "ticker": 0, "other": 0}
        self.ultima_mensagem_timestamp = 0
        self.conexao_estabelecida_timestamp = 0
        self.reconexoes = 0
        self.falhas_consecutivas = 0
        self.max_falhas_consecutivas = 0
        self.tempo_total_conectado = 0
        self.ultima_desconexao_timestamp = 0
        self.autenticacao_status = "unknown" # Pode ser expandido se autenticação for necessária
        self.circuit_breaker_ativo = False
        self.circuit_breaker_expiracao = 0
        self.falhas_por_tipo = {}
        self.status_conexao = "disconnected"

    def registrar_conexao(self):
        """Registra uma nova conexão estabelecida."""
        agora = time.time()
        self.conexao_estabelecida_timestamp = agora
        self.falhas_consecutivas = 0
        self.status_conexao = "connected"

        if self.ultima_desconexao_timestamp > 0:
            tempo_desconectado = agora - self.ultima_desconexao_timestamp
            logger.info(f"[{self.ativo}] Reconectado após {tempo_desconectado:.2f}s desconectado.")

        logger.info(f"[{self.ativo}] Conexão estabelecida em {datetime.datetime.fromtimestamp(agora).strftime('%Y-%m-%d %H:%M:%S')}")
        if PROMETHEUS_AVAILABLE: websocket_connection_status.labels(ativo=self.ativo).set(1)

    def registrar_desconexao(self, razao: str = "desconhecida"):
        """Registra uma desconexão."""
        agora = time.time()
        self.ultima_desconexao_timestamp = agora
        self.status_conexao = "disconnected"

        if self.conexao_estabelecida_timestamp > 0:
            tempo_conectado = agora - self.conexao_estabelecida_timestamp
            self.tempo_total_conectado += tempo_conectado
            logger.info(f"[{self.ativo}] Desconectado após {tempo_conectado:.2f}s conectado. Razão: {razao}")
            self.conexao_estabelecida_timestamp = 0 # Resetar timestamp de conexão

        if PROMETHEUS_AVAILABLE: websocket_connection_status.labels(ativo=self.ativo).set(0)

    def registrar_mensagem(self, tipo: str):
        """Registra uma mensagem recebida."""
        self.ultima_mensagem_timestamp = time.time()

        if tipo in self.mensagens_recebidas:
            self.mensagens_recebidas[tipo] += 1
        else:
            self.mensagens_recebidas["other"] += 1

        if PROMETHEUS_AVAILABLE: websocket_message_counter.labels(ativo=self.ativo, tipo=tipo).inc()

    def registrar_falha(self, tipo_falha: str):
        """Registra uma falha de conexão."""
        self.falhas_consecutivas += 1
        self.max_falhas_consecutivas = max(self.max_falhas_consecutivas, self.falhas_consecutivas)

        if tipo_falha not in self.falhas_por_tipo:
            self.falhas_por_tipo[tipo_falha] = 0
        self.falhas_por_tipo[tipo_falha] += 1

        if PROMETHEUS_AVAILABLE: inc_errors(f"websocket_failure_{tipo_falha}", self.ativo)

        # Verificar se deve ativar circuit breaker (ex: 5 falhas consecutivas)
        if self.falhas_consecutivas >= 5:
            self.ativar_circuit_breaker(60 * 5)  # 5 minutos

    def registrar_reconexao(self):
        """Registra uma tentativa de reconexão."""
        self.reconexoes += 1
        if PROMETHEUS_AVAILABLE: websocket_reconnect_counter.labels(ativo=self.ativo).inc()

    def ativar_circuit_breaker(self, duracao_segundos: int):
        """Ativa o circuit breaker por um período específico."""
        if not self.circuit_breaker_ativo:
            self.circuit_breaker_ativo = True
            self.circuit_breaker_expiracao = time.time() + duracao_segundos
            logger.warning(f"[{self.ativo}] Circuit breaker ativado por {duracao_segundos}s após {self.falhas_consecutivas} falhas consecutivas.")

    def verificar_circuit_breaker(self) -> bool:
        """Verifica se o circuit breaker está ativo."""
        if not self.circuit_breaker_ativo:
            return False

        if time.time() > self.circuit_breaker_expiracao:
            self.circuit_breaker_ativo = False
            logger.info(f"[{self.ativo}] Circuit breaker desativado após período de espera.")
            return False

        return True

    def tempo_desde_ultima_mensagem(self) -> float:
        """Retorna o tempo em segundos desde a última mensagem recebida."""
        if self.ultima_mensagem_timestamp == 0:
            # Se nunca recebeu mensagem, mas está conectado, retorna tempo desde conexão
            if self.conexao_estabelecida_timestamp > 0:
                return time.time() - self.conexao_estabelecida_timestamp
            return float('inf')
        return time.time() - self.ultima_mensagem_timestamp

    def obter_estatisticas(self) -> Dict[str, Any]:
        """Retorna um dicionário com todas as estatísticas de conexão."""
        agora = time.time()
        tempo_conectado_atual = 0

        if self.conexao_estabelecida_timestamp > 0 and self.status_conexao == "connected":
            tempo_conectado_atual = agora - self.conexao_estabelecida_timestamp

        return {
            "ativo": self.ativo,
            "status_conexao": self.status_conexao,
            "mensagens_total": sum(self.mensagens_recebidas.values()),
            "mensagens_por_tipo": self.mensagens_recebidas,
            "tempo_desde_ultima_mensagem": self.tempo_desde_ultima_mensagem(),
            "tempo_total_conectado": self.tempo_total_conectado + tempo_conectado_atual,
            "reconexoes": self.reconexoes,
            "falhas_consecutivas_atuais": self.falhas_consecutivas,
            "max_falhas_consecutivas_historico": self.max_falhas_consecutivas,
            "circuit_breaker_ativo": self.circuit_breaker_ativo,
            "falhas_por_tipo": self.falhas_por_tipo,
            "autenticacao_status": self.autenticacao_status
        }

# --- Funções Auxiliares --- #

async def carregar_dados_historicos_async_local(ativo: str, timeframe: str = '1m', data_dir: str = DATA_DIR):
    """Helper to load historical data asynchronously. Copied from binance_stream.py."""
    try:
        loop = asyncio.get_event_loop()
        # Usa a função importada (ou dummy)
        df = await loop.run_in_executor(None, functools.partial(carregar_dados_historicos, ativo, timeframe, data_dir))
        if df is not None and not df.empty:
            logger.info(f"[{ativo}] Historical data ({timeframe}) loaded: {len(df)} candles.")
            # Ensure columns are uppercase (should ideally be handled within carregar_dados_historicos)
            mapeamento_colunas_hist = {
                'open': 'Open', 'high': 'High', 'low': 'Low', 'close': 'Close', 'volume': 'Volume'
            }
            colunas_para_renomear_hist = {k: v for k, v in mapeamento_colunas_hist.items() if k in df.columns}
            if colunas_para_renomear_hist:
                df.rename(columns=colunas_para_renomear_hist, inplace=True)
            # Convert to numeric and drop NA
            for col in ['Open', 'High', 'Low', 'Close', 'Volume']:
                 if col in df.columns:
                     df[col] = pd.to_numeric(df[col], errors='coerce')
            df.dropna(subset=['Open', 'High', 'Low', 'Close', 'Volume'], inplace=True)
            return df
        else:
            logger.warning(f"[{ativo}] No historical data found or DataFrame empty.")
            return None
    except Exception as e:
        logger.error(f"[{ativo}] Error loading historical data asynchronously: {e}", exc_info=True)
        return None

# Dicionário global para rastrear estatísticas de conexão por ativo
connection_stats = {}

# --- Funções para compatibilidade com binance_stream_resilient --- #

async def processar_mensagem(ativo: str, msg: Dict[str, Any], context: Dict[str, Any], modo: str = "master", zmq_socket=None):
    """
    Processa uma mensagem recebida do WebSocket da Binance.
    
    Args:
        ativo: Símbolo do ativo (ex: "BTCUSDT")
        msg: Mensagem recebida do WebSocket
        context: Contexto global compartilhado
        modo: "master" ou "worker"
        zmq_socket: Socket ZMQ para comunicação (apenas no modo worker)
    """
    try:
        # Registrar estatísticas
        if ativo not in connection_stats:
            connection_stats[ativo] = ConnectionStats(ativo)
        
        # Determinar tipo de mensagem
        tipo_evento = msg.get("e", "unknown")
        connection_stats[ativo].registrar_mensagem(tipo_evento)
        
        # Processar kline
        if tipo_evento == "kline":
            kline_data = msg.get("k", {})
            is_closed = kline_data.get("x", False)
            
            if is_closed:
                # Atualizar DataFrame
                try:
                    # Verificar se o DataFrame já existe
                    if ativo not in context.get("dataframes", {}):
                        # Carregar dados históricos se necessário
                        df = await carregar_dados_historicos_async_local(ativo)
                        if df is None:
                            df = pd.DataFrame(columns=["Open", "High", "Low", "Close", "Volume"])
                            df.index.name = "timestamp"
                        context.setdefault("dataframes", {})[ativo] = df
                    
                    # Adicionar nova linha ao DataFrame
                    timestamp = pd.to_datetime(kline_data.get("t", 0), unit='ms')
                    new_row = pd.DataFrame({
                        "Open": [float(kline_data.get("o", 0))],
                        "High": [float(kline_data.get("h", 0))],
                        "Low": [float(kline_data.get("l", 0))],
                        "Close": [float(kline_data.get("c", 0))],
                        "Volume": [float(kline_data.get("v", 0))]
                    }, index=[timestamp])
                    
                    # Usar lock para evitar race conditions
                    async with context.get("dataframes_lock", asyncio.Lock()):
                        context["dataframes"][ativo] = pd.concat([context["dataframes"][ativo], new_row])
                        context["dataframes"][ativo] = context["dataframes"][ativo][~context["dataframes"][ativo].index.duplicated(keep='last')]
                        context["dataframes"][ativo] = context["dataframes"][ativo].sort_index()
                    
                    # Registrar timestamp da última kline
                    context.setdefault("last_kline_time", {})[ativo] = time.time()
                    
                    # Chamar função de análise de sinal se disponível
                    if "analisar_sinal_func" in context and modo == "master":
                        await context["analisar_sinal_func"](
                            ativo=ativo,
                            df=context["dataframes"][ativo],
                            context=context
                        )
                except Exception as e:
                    logger.error(f"[{ativo}] Erro ao processar kline: {e}", exc_info=True)
        
        # Processar atualização de profundidade (book)
        elif tipo_evento == "depthUpdate":
            if ativo in context.get("processadores_book", {}):
                try:
                    # Extrair dados do book
                    bids = [[float(p), float(q)] for p, q in msg.get("b", [])]
                    asks = [[float(p), float(q)] for p, q in msg.get("a", [])]
                    
                    # Processar atualização
                    await context["processadores_book"][ativo].process_book_update(bids, asks)
                    
                    # No modo worker, enviar para o master
                    if modo == "worker" and zmq_socket:
                        await zmq_socket.send_string(json.dumps({
                            "type": "book_update",
                            "ativo": ativo,
                            "timestamp": time.time(),
                            "data": {
                                "bids": bids[:5],  # Enviar apenas os 5 primeiros níveis para reduzir tráfego
                                "asks": asks[:5]
                            }
                        }))
                except Exception as e:
                    logger.error(f"[{ativo}] Erro ao processar book: {e}", exc_info=True)
        
        # Outros tipos de eventos podem ser adicionados conforme necessário
        
    except Exception as e:
        logger.error(f"[{ativo}] Erro ao processar mensagem: {e}", exc_info=True)

async def verificar_heartbeat(ativo: str, websocket_connections: Dict[str, Any], reconnect_tasks: Dict[str, asyncio.Task]):
    """
    Verifica periodicamente se o WebSocket está recebendo mensagens.
    
    Args:
        ativo: Símbolo do ativo
        websocket_connections: Dicionário de conexões WebSocket
        reconnect_tasks: Dicionário de tarefas de reconexão
    """
    try:
        while True:
            await asyncio.sleep(HEARTBEAT_INTERVAL)
            
            if ativo not in connection_stats:
                logger.warning(f"[{ativo}] Estatísticas de conexão não encontradas no heartbeat.")
                continue
            
            tempo_desde_ultima_msg = connection_stats[ativo].tempo_desde_ultima_mensagem()
            
            if tempo_desde_ultima_msg > MAX_MESSAGE_SILENCE:
                logger.warning(f"[{ativo}] Sem mensagens há {tempo_desde_ultima_msg:.1f}s. Fechando conexão para forçar reconexão.")
                
                # Fechar conexão para forçar reconexão
                if ativo in websocket_connections and websocket_connections[ativo]:
                    try:
                        await websocket_connections[ativo].close()
                    except Exception as e:
                        logger.error(f"[{ativo}] Erro ao fechar conexão no heartbeat: {e}")
                
                # Registrar desconexão
                connection_stats[ativo].registrar_desconexao("heartbeat_timeout")
                
                # Iniciar reconexão se não houver tarefa ativa
                if ativo not in reconnect_tasks or reconnect_tasks[ativo].done():
                    logger.info(f"[{ativo}] Iniciando reconexão após timeout de heartbeat.")
                    # A reconexão será tratada pelo loop principal
            else:
                logger.debug(f"[{ativo}] Heartbeat OK. Última mensagem há {tempo_desde_ultima_msg:.1f}s.")
    
    except asyncio.CancelledError:
        logger.info(f"[{ativo}] Tarefa de heartbeat cancelada.")
    except Exception as e:
        logger.error(f"[{ativo}] Erro na tarefa de heartbeat: {e}", exc_info=True)

async def conectar_binance_resiliente(ativo: str, context: Dict[str, Any], modo: str = "master", zmq_socket=None):
    """
    Conecta ao WebSocket da Binance com mecanismos de resiliência.
    
    Args:
        ativo: Símbolo do ativo (ex: "BTCUSDT")
        context: Contexto global compartilhado
        modo: "master" ou "worker"
        zmq_socket: Socket ZMQ para comunicação (apenas no modo worker)
    """
    # Inicializar estatísticas de conexão
    if ativo not in connection_stats:
        connection_stats[ativo] = ConnectionStats(ativo)
    
    # Obter configurações
    config = context.get("configuracao_global", {})
    use_testnet = config.get("testnet", False)
    ws_config = config.get("websocket", {})
    
    # Configurar resiliência
    resilience = NetworkResilience(
        max_retries=ws_config.get("max_reconnect_attempts", DEFAULT_MAX_RECONNECT_ATTEMPTS),
        base_delay=ws_config.get("base_delay", DEFAULT_BASE_DELAY),
        max_delay=ws_config.get("max_delay", DEFAULT_MAX_DELAY),
        jitter=ws_config.get("jitter", DEFAULT_JITTER),
        timeout=ws_config.get("timeout", DEFAULT_TIMEOUT)
    )
    
    # Inicializar conexões e tarefas
    context.setdefault("websocket_connections", {})
    context.setdefault("reconnect_tasks", {})
    context.setdefault("heartbeat_tasks", {})
    
    # Verificar modo de simulação E2E
    e2e_mode = os.environ.get("E2E_MOCK_WS_MODE", "")
    
    if e2e_mode == "LOAD":
        logger.info(f"[{ativo}] Modo de simulação E2E LOAD ativado. Gerando dados simulados.")
        # Simular carregamento de dados
        await asyncio.sleep(1)
        
        # Criar DataFrame simulado
        df = pd.DataFrame({
            "Open": [50000 + i * 10 for i in range(100)],
            "High": [50100 + i * 10 for i in range(100)],
            "Low": [49900 + i * 10 for i in range(100)],
            "Close": [50050 + i * 10 for i in range(100)],
            "Volume": [100 + i for i in range(100)]
        }, index=pd.date_range(start="2023-01-01", periods=100, freq="1min"))
        
        # Adicionar ao contexto
        context.setdefault("dataframes", {})[ativo] = df
        
        # Simular processamento contínuo
        while True:
            await asyncio.sleep(1)
            
            # Simular nova kline
            timestamp = pd.Timestamp.now()
            new_row = pd.DataFrame({
                "Open": [float(df["Close"].iloc[-1])],
                "High": [float(df["Close"].iloc[-1]) * 1.001],
                "Low": [float(df["Close"].iloc[-1]) * 0.999],
                "Close": [float(df["Close"].iloc[-1]) * (1 + random.uniform(-0.002, 0.002))],
                "Volume": [float(df["Volume"].iloc[-1]) * random.uniform(0.8, 1.2)]
            }, index=[timestamp])
            
            # Atualizar DataFrame
            async with context.get("dataframes_lock", asyncio.Lock()):
                context["dataframes"][ativo] = pd.concat([context["dataframes"][ativo], new_row])
                context["dataframes"][ativo] = context["dataframes"][ativo].iloc[-1000:]  # Manter apenas 1000 linhas
            
            # Registrar estatísticas
            connection_stats[ativo].registrar_mensagem("kline")
            
            # Chamar função de análise de sinal se disponível
            if "analisar_sinal_func" in context and modo == "master":
                await context["analisar_sinal_func"](
                    ativo=ativo,
                    df=context["dataframes"][ativo],
                    context=context
                )
    
    elif e2e_mode == "FAILURE":
        logger.info(f"[{ativo}] Modo de simulação E2E FAILURE ativado. Simulando falhas de conexão.")
        # Simular falhas de conexão
        while True:
            # Registrar falha
            connection_stats[ativo].registrar_falha(NetworkFailureType.CONNECTION_REFUSED)
            logger.error(f"[{ativo}] Simulação de falha de conexão.")
            
            # Aguardar antes da próxima falha
            await asyncio.sleep(2)
    
    else:
        # Modo normal - conectar ao WebSocket da Binance
        logger.info(f"[{ativo}] Iniciando conexão WebSocket para {ativo} (testnet={use_testnet}).")
        
        # Função para estabelecer conexão
        async def connect_to_websocket():
            # Determinar URL
            base_url = "wss://stream.binance.com:9443/ws/" if not use_testnet else "wss://testnet.binance.vision/ws/"
            stream = ativo.lower() + "@kline_1m"
            url = base_url + stream
            
            logger.info(f"[{ativo}] Conectando a {url}")
            
            # Verificar circuit breaker
            if connection_stats[ativo].verificar_circuit_breaker():
                logger.warning(f"[{ativo}] Circuit breaker ativo. Aguardando antes de tentar reconexão.")
                raise Exception("Circuit breaker ativo")
            
            # Registrar tentativa de reconexão
            connection_stats[ativo].registrar_reconexao()
            
            # Conectar ao WebSocket
            async with aiohttp.ClientSession() as session:
                async with session.ws_connect(url, timeout=ws_config.get("timeout", DEFAULT_TIMEOUT)) as ws:
                    # Armazenar conexão no contexto
                    context["websocket_connections"][ativo] = ws
                    
                    # Registrar conexão estabelecida
                    connection_stats[ativo].registrar_conexao()
                    logger.info(f"[{ativo}] Conexão WebSocket estabelecida.")
                    
                    # Iniciar tarefa de heartbeat se não existir
                    if ativo not in context["heartbeat_tasks"] or context["heartbeat_tasks"][ativo].done():
                        context["heartbeat_tasks"][ativo] = asyncio.create_task(
                            verificar_heartbeat(ativo, context["websocket_connections"], context["reconnect_tasks"])
                        )
                    
                    # Loop de recebimento de mensagens
                    async for msg in ws:
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            try:
                                data = json.loads(msg.data)
                                # Processar mensagem
                                await processar_mensagem(ativo, data, context, modo, zmq_socket)
                            except json.JSONDecodeError:
                                logger.error(f"[{ativo}] Erro ao decodificar JSON: {msg.data}")
                            except Exception as e:
                                logger.error(f"[{ativo}] Erro ao processar mensagem: {e}", exc_info=True)
                        elif msg.type == aiohttp.WSMsgType.CLOSED:
                            logger.warning(f"[{ativo}] WebSocket fechado.")
                            break
                        elif msg.type == aiohttp.WSMsgType.ERROR:
                            logger.error(f"[{ativo}] Erro no WebSocket: {ws.exception()}")
                            break
                    
                    # Registrar desconexão
                    connection_stats[ativo].registrar_desconexao("websocket_closed")
                    logger.info(f"[{ativo}] Conexão WebSocket encerrada.")
        
        # Loop principal com reconexão
        while True:
            try:
                # Usar resiliência para conectar
                await resilience.execute_with_retry(
                    operation=connect_to_websocket,
                    operation_name=f"websocket_{ativo}"
                )
            except Exception as e:
                logger.error(f"[{ativo}] Erro fatal na conexão WebSocket após várias tentativas: {e}", exc_info=True)
                # Registrar falha
                connection_stats[ativo].registrar_falha(NetworkFailureType.UNKNOWN)
                # Aguardar antes de tentar novamente
                await asyncio.sleep(ws_config.get("base_delay", DEFAULT_BASE_DELAY))

# --- Classe Principal: BinanceStreamManager --- #

class BinanceStreamManager:
    """
    Gerenciador de streams da Binance com recursos avançados de resiliência.
    """

    def __init__(self, config: Dict[str, Any], context_global: Dict[str, Any]):
        """
        Inicializa o gerenciador de streams.

        Args:
            config: Configuração geral do sistema (contém sub-config de websocket).
            context_global: Dicionário de contexto compartilhado com outros módulos.
        """
        self.config = config
        self.context_global = context_global
        self.callbacks = {}
        self.running = False
        self.tasks = []
        self.websockets = {}
        self.kline_cache = {}
        self.ticker_cache = {}
        self.depth_cache = {}
        self.connection_stats = {}
        self.active_streams = set()
        self.zmq_context = zmq.asyncio.Context()
        self.zmq_socket = None # Será inicializado se necessário
        self.mode = self.config.get("execution_mode", "master") # master ou worker

        # Configurações de WebSocket e Resiliência
        ws_config = self.config.get('websocket', {})
        self.base_url = ws_config.get('base_url', "wss://stream.binance.com:9443/ws/")
        self.testnet_url = ws_config.get('testnet_url', "wss://stream.testnet.binance.vision/stream")
        self.use_testnet = self.config.get('testnet', False)
        self.max_retries = ws_config.get('max_reconnect_attempts', DEFAULT_MAX_RECONNECT_ATTEMPTS)
        self.base_delay = ws_config.get('base_reconnect_delay', DEFAULT_BASE_DELAY)
        self.max_delay = ws_config.get('max_reconnect_delay', DEFAULT_MAX_DELAY)
        self.jitter = ws_config.get('reconnect_jitter', DEFAULT_JITTER)
        self.connect_timeout = ws_config.get('connect_timeout', DEFAULT_TIMEOUT)
        self.message_timeout = ws_config.get('message_timeout', MAX_MESSAGE_SILENCE)
        self.heartbeat_interval = ws_config.get('heartbeat_interval', HEARTBEAT_INTERVAL)

        # Configuração ZMQ (se modo worker)
        if self.mode == "worker":
            zmq_config = self.config.get("zmq", {})
            master_address = zmq_config.get("master_address", "tcp://localhost:5555")
            try:
                self.zmq_socket = self.zmq_context.socket(zmq.PUSH)
                self.zmq_socket.connect(master_address)
                logger.info(f"Worker ZMQ PUSH socket connected to {master_address}")
            except Exception as e:
                logger.error(f"Failed to create or connect ZMQ PUSH socket: {e}", exc_info=True)
                self.zmq_socket = None

        # Configurações de Otimização de Fonte de Dados
        ds_config = self.config.get('data_source_optimization', {})
        self.prioritize_streaming = ds_config.get('prioritize_streaming', True)
        self.fallback_to_rest = ds_config.get('fallback_to_rest', True)
        self.use_aggressive_cache = ds_config.get('use_aggressive_cache', True)
        self.cache_ttl_config = ds_config.get('cache_ttl_seconds', DEFAULT_CACHE_TTL)
        self.min_rest_interval_config = ds_config.get('min_rest_interval_seconds', DEFAULT_MIN_REST_INTERVAL)
        self.aggressive_cache = {}  # Cache mais persistente
        self.last_rest_call = {}  # Timestamp da última chamada REST por recurso

        logger.info(f"BinanceStreamManager initialized in {self.mode} mode with testnet={self.use_testnet}")

    async def start_stream(self, ativo: str, callback=None):
        """
        Inicia um stream para um ativo específico.

        Args:
            ativo: Símbolo do ativo (ex: "BTCUSDT")
            callback: Função de callback opcional para processar mensagens
        """
        if ativo in self.active_streams:
            logger.warning(f"Stream for {ativo} already active")
            return

        if callback:
            self.callbacks[ativo] = callback

        self.active_streams.add(ativo)
        task = asyncio.create_task(
            conectar_binance_resiliente(ativo, self.context_global, self.mode, self.zmq_socket)
        )
        self.tasks.append(task)
        logger.info(f"Started stream for {ativo}")

    async def stop_stream(self, ativo: str):
        """
        Para um stream específico.

        Args:
            ativo: Símbolo do ativo
        """
        if ativo not in self.active_streams:
            logger.warning(f"No active stream for {ativo}")
            return

        # Remover do conjunto de streams ativos
        self.active_streams.remove(ativo)

        # Fechar conexão WebSocket
        if ativo in self.context_global.get("websocket_connections", {}):
            try:
                await self.context_global["websocket_connections"][ativo].close()
            except Exception as e:
                logger.error(f"Error closing WebSocket for {ativo}: {e}")

        # Cancelar tarefas relacionadas
        for task_type in ["reconnect_tasks", "heartbeat_tasks"]:
            if ativo in self.context_global.get(task_type, {}):
                try:
                    self.context_global[task_type][ativo].cancel()
                except Exception as e:
                    logger.error(f"Error canceling {task_type} for {ativo}: {e}")

        logger.info(f"Stopped stream for {ativo}")

    async def start_all(self, ativos: List[str]):
        """
        Inicia streams para múltiplos ativos.

        Args:
            ativos: Lista de símbolos de ativos
        """
        for ativo in ativos:
            await self.start_stream(ativo)

    async def stop_all(self):
        """Para todos os streams ativos."""
        for ativo in list(self.active_streams):
            await self.stop_stream(ativo)

        # Cancelar todas as tarefas
        for task in self.tasks:
            if not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass

        self.tasks = []
        logger.info("All streams stopped")

    def get_connection_stats(self, ativo: str = None):
        """
        Obtém estatísticas de conexão.

        Args:
            ativo: Símbolo do ativo específico ou None para todos
        """
        if ativo:
            if ativo in connection_stats:
                return connection_stats[ativo].obter_estatisticas()
            return None

        # Retornar estatísticas para todos os ativos
        return {k: v.obter_estatisticas() for k, v in connection_stats.items()}

# Exportar símbolos para compatibilidade com código existente
__all__ = [
    'BinanceStreamManager',
    'ConnectionStats',
    'NetworkFailureType',
    'NetworkResilience',
    'conectar_binance_resiliente',
    'processar_mensagem',
    'verificar_heartbeat',
    'carregar_dados_historicos_async_local',
    'connection_stats'
]
