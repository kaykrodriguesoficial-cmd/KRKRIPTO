# src/strategies/validators/book_imbalance.py
""" Validador baseado no desequilíbrio (imbalance) do book de ofertas. """

import logging
from logging.handlers import TimedRotatingFileHandler
import os
import sys

# Configuração de logging com rotação para este módulo
log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), 'logs')
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, 'book_imbalance.log')

# Configurar logger com rotação diária
logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = TimedRotatingFileHandler(
        filename=log_file,
        when='midnight',
        interval=1,
        backupCount=30,
        encoding='utf-8'
    )
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    
    # Adicionar handler para console também
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    logger.setLevel(logging.INFO)
    logger.info("Logger configurado com rotação diária para book_imbalance")

def validar_book_institucional(book_state, tipo_sinal: str, tolerancia: float = 0.3) -> tuple[bool, str]:
    """
    Valida um sinal com base no desequilíbrio (imbalance) do book.
    A lógica é adaptada da função original `avaliar_orderflow`.
    Retorna True se o imbalance não contradisser fortemente o sinal, False caso contrário.

    Args:
        book_state: Objeto contendo o estado atual do book (espera-se ter o atributo `imbalance`).
        tipo_sinal: O tipo de sinal a ser validado ("compra", "venda", "nada").
        tolerancia: Limiar para considerar o imbalance significativo (padrão: 0.3).

    Returns:
        tuple[bool, str]: (Resultado da validação, Mensagem descritiva)
    """
    if tipo_sinal == "nada":
        logger.debug("Sinal neutro, validação de imbalance não aplicável.")
        return True, "Sinal neutro, validação de imbalance não aplicável."

    if book_state is None or not hasattr(book_state, "imbalance"):
        logger.warning("BookState inválido ou sem atributo imbalance para validação.")
        # Considera válido em caso de erro para não bloquear desnecessariamente
        return True, "WARN: BookState inválido ou sem imbalance, validação pulada."

    imbalance = book_state.imbalance
    mensagem = f"Imbalance: {imbalance:.2f}. Tolerância: {tolerancia}."
    logger.debug(f"Validando sinal {tipo_sinal} com {mensagem}")

    if tipo_sinal == "compra":
        if imbalance < -tolerancia:
            # Forte pressão vendedora contradiz sinal de compra
            logger.info(f"Validação falhou para COMPRA: Imbalance ({imbalance:.2f}) < {-tolerancia}")
            return False, f"FALHA (COMPRA): {mensagem} Forte pressão vendedora."
        else:
            # Imbalance neutro ou comprador confirma/não contradiz sinal de compra
            logger.debug(f"Validação OK para COMPRA: Imbalance ({imbalance:.2f}) >= {-tolerancia}")
            return True, f"OK (COMPRA): {mensagem}"

    elif tipo_sinal == "venda":
        if imbalance > tolerancia:
            # Forte pressão compradora contradiz sinal de venda
            logger.info(f"Validação falhou para VENDA: Imbalance ({imbalance:.2f}) > {tolerancia}")
            return False, f"FALHA (VENDA): {mensagem} Forte pressão compradora."
        else:
            # Imbalance neutro ou vendedor confirma/não contradiz sinal de venda
            logger.debug(f"Validação OK para VENDA: Imbalance ({imbalance:.2f}) <= {tolerancia}")
            return True, f"OK (VENDA): {mensagem}"

    else:
        logger.warning(f"Tipo de sinal desconhecido para validação de imbalance: {tipo_sinal}")
        return True, f"WARN: Tipo de sinal desconhecido ({tipo_sinal})."
