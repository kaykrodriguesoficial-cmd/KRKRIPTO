
import os
from binance.client import Client
from inteligencia.log_por_ativo import registrar_log

# Chaves da API Binance
API_KEY = os.getenv("BINANCE_API_KEY", "SUA_API_KEY")
API_SECRET = os.getenv("BINANCE_API_SECRET", "SEU_API_SECRET")
client = Client(API_KEY, API_SECRET)

def avaliar_orderflow(ativo="BTCUSDT", limite=10, tolerancia=0.3):
    '''
    Avalia desequilíbrio de ordem institucional.
    Retorna um dicionário com resultado da validação e detalhes do book.
    '''
    try:
        book = client.get_order_book(symbol=ativo, limit=limite)
        soma_bids = sum([float(x[1]) for x in book["bids"]])
        soma_asks = sum([float(x[1]) for x in book["asks"]])

        imbalance = (soma_bids - soma_asks) / (soma_bids + soma_asks)
        tipo_pressao = "neutro"
        if imbalance > tolerancia:
            tipo_pressao = "compra"
        elif imbalance < -tolerancia:
            tipo_pressao = "venda"

        registrar_log(ativo,
            f"📊 Book Imbalance: {imbalance:.2f} | Tipo: {tipo_pressao} | Bids: {soma_bids:.2f} | Asks: {soma_asks:.2f}",
            "book_imbalance")

        return {
            "valido": abs(imbalance) <= tolerancia,
            "imbalance": round(imbalance, 4),
            "tipo_pressao": tipo_pressao,
            "soma_bids": soma_bids,
            "soma_asks": soma_asks
        }

    except Exception as e:
        registrar_log(ativo, f"❌ Erro ao consultar order book: {e}", "book_imbalance", "ERROR")
        return {
            "valido": True,  # fallback neutro
            "erro": str(e),
            "imbalance": 0.0,
            "tipo_pressao": "desconhecido"
        }
