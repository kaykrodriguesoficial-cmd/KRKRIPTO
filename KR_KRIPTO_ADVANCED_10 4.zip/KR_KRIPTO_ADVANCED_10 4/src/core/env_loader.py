"""
Módulo para carregamento de variáveis de ambiente e gerenciamento de credenciais.
Este módulo fornece funções para carregar credenciais e configurações sensíveis
a partir de variáveis de ambiente, com fallback para valores padrão quando necessário.

Versão 2.1: Adicionado suporte ao parâmetro 'default' na função obter_credencial
para corrigir o erro 'obter_credencial() got an unexpected keyword argument 'default''
"""

import os
import logging
from typing import Dict, Any, Optional, Union

# Importar dotenv para carregar variáveis do arquivo .env
try:
    from dotenv import load_dotenv
    # Carregar variáveis do arquivo .env na raiz do projeto
    dotenv_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), '.env')
    load_dotenv(dotenv_path)
    dotenv_loaded = True
except ImportError:
    dotenv_loaded = False

logger = logging.getLogger(__name__)

# Log sobre o status do dotenv
if dotenv_loaded:
    logger.info(f"python-dotenv carregado com sucesso. Buscando variáveis em: {dotenv_path}")
else:
    logger.warning("python-dotenv não está instalado. Execute 'pip install python-dotenv' para habilitar o carregamento de variáveis do arquivo .env")

def carregar_variaveis_ambiente() -> Dict[str, Any]:
    """
    Carrega variáveis de ambiente relacionadas à configuração do sistema.
    
    Returns:
        Dict[str, Any]: Dicionário com as variáveis de ambiente carregadas
    """
    env_vars = {
        # Credenciais da Binance
        "binance_api_key": os.environ.get("KR_BINANCE_API_KEY", os.environ.get("binance_api_key", "")),
        "binance_api_secret": os.environ.get("KR_BINANCE_API_SECRET", os.environ.get("binance_api_secret", "")),
        "testnet": os.environ.get("KR_TESTNET", os.environ.get("testnet", "true")).lower() == "true",
        
        # Credenciais do Telegram
        "telegram_token": os.environ.get("KR_TELEGRAM_TOKEN", os.environ.get("telegram_token", "")),
        "telegram_chat_id": os.environ.get("KR_TELEGRAM_CHAT_ID", os.environ.get("telegram_chat_id", "")),
        
        # Outras chaves de API
        "news_api_key": os.environ.get("KR_NEWS_API_KEY", os.environ.get("news_api_key", ""))
    }
    
    # Log seguro (apenas para confirmação de carregamento, sem expor valores)
    for key in env_vars:
        if key in ["binance_api_key", "binance_api_secret", "telegram_token", "news_api_key"]:
            value = env_vars[key]
            if value:
                # Mostra apenas os primeiros 4 e últimos 4 caracteres, se houver pelo menos 12 caracteres
                if len(value) >= 12:
                    masked_value = f"{value[:4]}...{value[-4:]}"
                    logger.info(f"Variável de ambiente {key} carregada: {masked_value}")
                else:
                    logger.info(f"Variável de ambiente {key} carregada (valor curto)")
            else:
                logger.warning(f"Variável de ambiente {key} não encontrada")
        else:
            logger.info(f"Variável de ambiente {key}: {env_vars[key]}")
    
    return env_vars

def obter_credencial(nome: str, config: Optional[Dict[str, Any]] = None, default: Any = None) -> Union[str, bool, Any]:
    """
    Obtém uma credencial específica, priorizando variáveis de ambiente sobre o arquivo de configuração.
    
    Args:
        nome: Nome da credencial a ser obtida
        config: Dicionário de configuração (opcional, usado como fallback)
        default: Valor padrão a ser retornado se a credencial não for encontrada (opcional)
        
    Returns:
        Union[str, bool, Any]: Valor da credencial. Retorna o valor de 'default' se não encontrada,
                              exceto para 'testnet' que retorna um boolean se default não for especificado.
    """
    # Mapeamento entre nomes de credenciais e variáveis de ambiente
    env_mapping = {
        "binance_api_key": ["KR_BINANCE_API_KEY", "binance_api_key"],
        "binance_api_secret": ["KR_BINANCE_API_SECRET", "binance_api_secret"],
        "testnet": ["KR_TESTNET", "testnet"],
        "telegram_token": ["KR_TELEGRAM_TOKEN", "telegram_token"],
        "telegram_chat_id": ["KR_TELEGRAM_CHAT_ID", "telegram_chat_id"],
        "news_api_key": ["KR_NEWS_API_KEY", "news_api_key"]
    }
    
    # Verificar se existe uma variável de ambiente correspondente
    if nome in env_mapping:
        env_vars = env_mapping[nome]
        env_value = None
        
        # Tentar cada variável de ambiente na ordem
        for env_var in env_vars:
            env_value = os.environ.get(env_var)
            if env_value is not None:
                break
        
        # Caso especial para testnet (converter string para boolean)
        if nome == "testnet" and env_value is not None:
            return env_value.lower() == "true"
        
        # Se a variável de ambiente existir, retorná-la
        if env_value is not None:
            return env_value
    
    # Fallback para o arquivo de configuração
    if config is not None:
        # Caso especial para news_api_key que pode estar aninhada
        if nome == "news_api_key" and "news_provider_config" in config and "api_key" in config["news_provider_config"]:
            return config["news_provider_config"]["api_key"]
        
        # Busca direta no config
        if nome in config:
            return config[nome]
    
    # Não encontrado - retornar valor default se fornecido
    if default is not None:
        return default
        
    # Caso contrário, usar valores padrão específicos
    if nome == "testnet":
        return False  # Valor padrão para testnet é False
    
    # Para todas as outras credenciais, retornar string vazia
    return ""

# Exemplo de uso (se executado diretamente)
if __name__ == "__main__":
    # Configurar logging básico para teste
    logging.basicConfig(level=logging.INFO)
    
    # Testar carregamento de variáveis de ambiente
    env_vars = carregar_variaveis_ambiente()
    print(f"Variáveis de ambiente carregadas: {list(env_vars.keys())}")
    
    # Testar obtenção de credenciais específicas
    test_config = {"binance_api_key": "config_key", "testnet": True}
    print(f"Credencial da API Binance: {obter_credencial('binance_api_key', test_config)}")
    print(f"Testnet ativado: {obter_credencial('testnet', test_config)}")
    print(f"Credencial com default: {obter_credencial('api_inexistente', test_config, default='valor_padrao')}")
