# src/strategies/fakeout.py

import pandas as pd
import numpy as np
import logging

logger = logging.getLogger(__name__)

def detectar_fakeout(df: pd.DataFrame, lookback: int = 5) -> bool:
    """
    Detecta uma divergência bearish (fakeout de alta) baseada no RSI.
    Verifica se o preço fez um novo máximo nos últimos `lookback` períodos,
    mas o RSI fez um máximo mais baixo no mesmo período.

    Args:
        df (pd.DataFrame): DataFrame contendo pelo menos as colunas 
'high
' e 
'rsi_14
'.
        lookback (int): Número de períodos para verificar a divergência.

    Returns:
        bool: True se uma divergência bearish for detectada, False caso contrário.
    """
    # --- CORREÇÃO: Usar nomes minúsculos e padrão pandas_ta --- 
    required_columns = ["high", "rsi_14"]
    if not all(col in df.columns for col in required_columns):
        # Tentar fallback para RSI?
        if "high" in df.columns and "RSI" in df.columns:
            required_columns = ["high", "RSI"]
            logger.debug("[detectar_fakeout] Usando coluna 'RSI' como fallback para 'rsi_14'.")
        else:
            logger.warning(f"[detectar_fakeout] Colunas necessárias (['high', 'rsi_14']) não encontradas no DataFrame. Colunas presentes: {list(df.columns)}")
            return False
    # --- FIM CORREÇÃO ---

    if len(df) < lookback + 1: # Need at least lookback+1 points to compare peaks
        # logger.debug(f"[detectar_fakeout] Dados insuficientes ({len(df)} < {lookback + 1}) para detectar fakeout.")
        return False

    try:
        # --- CORREÇÃO: Usar nomes minúsculos --- 
        high_col = required_columns[0] # 'high'
        rsi_col = required_columns[1]  # 'rsi_14' or 'RSI'
        
        # Get the last `lookback` periods + 1 for comparison
        recent_data = df.iloc[-(lookback + 1):]
        
        # Find the index of the highest high in the recent data
        idx_max_high = recent_data[high_col].idxmax()
        
        # Check if the highest high is the most recent point (or within the lookback window)
        # We are looking for a peak within the lookback window, not necessarily the very last point.
        
        # Find the highest high in the last `lookback` periods (excluding the current candle if needed, but let's include it)
        high_window = df[high_col].iloc[-lookback:]
        rsi_window = df[rsi_col].iloc[-lookback:]
        
        idx_max_high_window = high_window.idxmax()
        rsi_at_max_high = rsi_window.loc[idx_max_high_window]
        
        # Find the previous high peak within a reasonable prior window (e.g., previous `lookback` periods)
        # This part is tricky and can be defined in many ways. Let's simplify:
        # Compare the peak in the last `lookback` window with the peak in the window before that.
        
        if len(df) < 2 * lookback:
             # logger.debug(f"[detectar_fakeout] Dados insuficientes ({len(df)} < {2 * lookback}) para comparar janelas.")
             return False
             
        prev_high_window = df[high_col].iloc[-2*lookback:-lookback]
        prev_rsi_window = df[rsi_col].iloc[-2*lookback:-lookback]
        
        if prev_high_window.empty:
            return False
            
        idx_prev_max_high_window = prev_high_window.idxmax()
        prev_rsi_at_max_high = prev_rsi_window.loc[idx_prev_max_high_window]
        prev_max_high = prev_high_window.loc[idx_prev_max_high_window]
        current_max_high = high_window.loc[idx_max_high_window]
        # --- FIM CORREÇÃO ---

        # Bearish Divergence Condition:
        # Current high peak is higher than the previous high peak
        # But RSI at the current high peak is lower than RSI at the previous high peak
        if current_max_high > prev_max_high and rsi_at_max_high < prev_rsi_at_max_high:
            logger.debug(f"[detectar_fakeout] Divergência Bearish detectada: Preço {current_max_high} > {prev_max_high}, RSI {rsi_at_max_high} < {prev_rsi_at_max_high}")
            return True
            
        return False

    except KeyError as e:
        logger.error(f"[detectar_fakeout] KeyError: Coluna {e} não encontrada.")
        return False
    except Exception as e:
        logger.error(f"[detectar_fakeout] Erro inesperado: {e}", exc_info=True)
        return False

# Exemplo de uso (para teste manual)
if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    # Dados do teste test_detectar_fakeout_bearish
    # --- CORREÇÃO: Usar nomes minúsculos --- 
    data = {
        'high':  [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 118], 
        'low':   [90,  91,  92,  93,  94,  95,  96,  97,  98,  99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 108, 107], 
        'close': [95,  96,  97,  98,  99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 112],
        'rsi_14':   [30,  35,  40,  45,  50,  55,  60,  65,  70,  75,  80,  78,  75,  70,  65,  60,  55,  50,  45,  40,  35,  40]  
    }
    # --- FIM CORREÇÃO ---
    df_test = pd.DataFrame(data)
    result = detectar_fakeout(df_test, lookback=5)
    print(f"Resultado para dados de teste (Bearish): {result}") # Esperado: True

    # Dados sem divergência
    # --- CORREÇÃO: Usar nomes minúsculos --- 
    data_no_div = {
        'high':  [100, 101, 102, 103, 104, 105, 106, 107, 108, 109] * 2,
        'low':   [90,  91,  92,  93,  94,  95,  96,  97,  98,  99 ] * 2,
        'close': [95,  96,  97,  98,  99, 100, 101, 102, 103, 104] * 2,
        'rsi_14':   [30,  35,  40,  45,  50,  55,  60,  65,  70,  75 ] * 2
    }
    # --- FIM CORREÇÃO ---
    df_no_div = pd.DataFrame(data_no_div)
    result_no_div = detectar_fakeout(df_no_div, lookback=5)
    print(f"Resultado para dados sem divergência: {result_no_div}") # Esperado: False

