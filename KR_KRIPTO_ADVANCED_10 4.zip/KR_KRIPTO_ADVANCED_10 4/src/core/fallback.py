#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Implementação híbrida do GerenciadorFallback com suporte a Mac M1 (ARM64)
e compatibilidade com o parâmetro 'operador' do sistema principal.

Esta versão mantém todas as funcionalidades avançadas da implementação híbrida
e adiciona suporte ao parâmetro 'operador' para integração perfeita com o main.py.

Autor: Manus
Data: 28/05/2025
Versão: 2.2
"""

import os
import sys
import time
import json
import logging
import platform
import threading
import traceback
from datetime import datetime, timedelta
from functools import wraps
from typing import Dict, List, Any, Callable, Optional, Union, Tuple

# Configurar logging
logger = logging.getLogger("kr_kripto_fallback")
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

# Verificar se estamos em um Mac M1
def is_mac_m1() -> bool:
    """Verifica se o ambiente atual é um Mac M1 (ARM64)."""
    return platform.system() == "Darwin" and ("arm" in platform.machine().lower())

# Tentar importar psutil para monitoramento de recursos
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    logger.warning("psutil não está disponível. Verificação de recursos limitada.")

class GerenciadorFallback:
    """
    Gerenciador de fallback híbrido com suporte a Mac M1 (ARM64).
    
    Fornece mecanismos de resiliência para o sistema, incluindo:
    - Circuit breakers para isolamento de falhas
    - Monitoramento de modelos para detecção de anomalias
    - Sistema de watchdog para tarefas críticas
    - Compatibilidade com diferentes ambientes
    
    Esta implementação é compatível com Mac M1 (ARM64) e ambientes Linux,
    e suporta o parâmetro 'operador' para integração com o main.py.
    """
    
    def __init__(self, config: Dict[str, Any] = None, operador_binance = None, operador = None):
        """
        Inicializa o GerenciadorFallback.
        
        Args:
            config: Configuração do gerenciador de fallback
            operador_binance: Operador Binance para acesso à exchange
            operador: Alias para operador_binance (compatibilidade com main.py)
        """
        # Configuração padrão
        self.config = {
            "max_falhas": 3,
            "janela_falhas": 60,  # segundos
            "tempo_reset": 300,   # segundos
            "limiar_alerta_modelo": 0.3,
            "limiar_critico_modelo": 0.5,
            "memoria_critica": 95.0,  # percentual
            "cpu_critica": 90.0,      # percentual
            "periodo_verificacao_rollback": 21600  # 6 horas em segundos
        }
        
        # Sobrescrever com configuração fornecida
        if config:
            self.config.update(config)
        
        # Compatibilidade com main.py: usar operador se fornecido, caso contrário usar operador_binance
        self.operador_binance = operador if operador is not None else operador_binance
        
        # Estado interno
        self.falhas = {}
        self.circuit_breakers = {}
        self.circuit_breaker_count = 0
        self.modelo_fallback = self._criar_modelo_fallback()
        self.alertas_modelo = {}
        self.watchdogs = {}
        self.watchdog_thread = None
        self.watchdog_running = False
        self.ambiente = "Mac M1" if is_mac_m1() else "Outro"
        
        # Iniciar thread de watchdog se necessário
        self._iniciar_watchdog_thread()
        
        logger.info("GerenciadorFallback inicializado com sucesso")
    
    def _criar_modelo_fallback(self) -> Dict[str, Any]:
        """
        Cria um modelo de fallback simples para uso quando os modelos principais falham.
        
        Returns:
            Modelo de fallback com função de predição
        """
        def predict(features: Dict[str, float]) -> Dict[str, float]:
            """Função de predição simples para o modelo de fallback."""
            return {"prediction": 0.5, "confidence": 0.5}
        
        return {"predict": predict, "type": "fallback", "created_at": datetime.now().isoformat()}
    
    def registrar_falha(self, componente: str, erro: Exception = None, detalhes: str = None) -> Dict[str, Any]:
        """
        Registra uma falha para um componente e verifica se o circuit breaker deve ser ativado.
        
        Args:
            componente: Nome do componente que falhou
            erro: Exceção que causou a falha (opcional)
            detalhes: Detalhes adicionais sobre a falha (opcional, compatibilidade com main.py)
            
        Returns:
            Estado atual do componente após o registro da falha
        """
        agora = datetime.now()
        
        # Inicializar registro do componente se não existir
        if componente not in self.falhas:
            self.falhas[componente] = []
        
        # Remover falhas antigas fora da janela de tempo
        janela_inicio = agora - timedelta(seconds=self.config["janela_falhas"])
        self.falhas[componente] = [f for f in self.falhas[componente] if f["timestamp"] >= janela_inicio]
        
        # Adicionar nova falha
        falha = {
            "timestamp": agora,
            "erro": str(erro) if erro else "Erro não especificado",
            "detalhes": detalhes if detalhes else ""  # Armazenar detalhes se fornecidos
        }
        self.falhas[componente].append(falha)
        
        # Verificar se o circuit breaker deve ser ativado
        falhas_recentes = len(self.falhas[componente])
        if falhas_recentes >= self.config["max_falhas"]:
            self.circuit_breakers[componente] = {
                "ativado_em": agora,
                "reset_em": agora + timedelta(seconds=self.config["tempo_reset"]),
                "falhas": falhas_recentes
            }
            self.circuit_breaker_count += 1
            logger.info(f"Circuit breaker ativado para {componente} após {falhas_recentes} falhas")
        else:
            logger.info(f"Falha registrada para {componente} ({falhas_recentes}/{self.config['max_falhas']})")
        
        return {
            "componente": componente,
            "falhas_recentes": falhas_recentes,
            "circuit_breaker": componente in self.circuit_breakers,
            "reset_em": self.circuit_breakers.get(componente, {}).get("reset_em")
        }
    
    def registrar_falha_especifica(self, componente: str, erro: str, detalhes: str = None) -> Dict[str, Any]:
        """
        Registra uma falha específica para um componente.
        
        Args:
            componente: Nome do componente que falhou
            erro: Descrição do erro
            detalhes: Detalhes adicionais sobre a falha (opcional, compatibilidade com main.py)
            
        Returns:
            Estado atual do componente após o registro da falha
        """
        agora = datetime.now()
        
        # Inicializar registro do componente se não existir
        if componente not in self.falhas:
            self.falhas[componente] = []
        
        # Remover falhas antigas fora da janela de tempo
        janela_inicio = agora - timedelta(seconds=self.config["janela_falhas"])
        self.falhas[componente] = [f for f in self.falhas[componente] if f["timestamp"] >= janela_inicio]
        
        # Adicionar nova falha
        falha = {
            "timestamp": agora,
            "erro": erro,
            "detalhes": detalhes if detalhes else ""  # Armazenar detalhes se fornecidos
        }
        self.falhas[componente].append(falha)
        
        # Verificar se o circuit breaker deve ser ativado
        falhas_recentes = len(self.falhas[componente])
        if falhas_recentes >= self.config["max_falhas"]:
            self.circuit_breakers[componente] = {
                "ativado_em": agora,
                "reset_em": agora + timedelta(seconds=self.config["tempo_reset"]),
                "falhas": falhas_recentes
            }
            self.circuit_breaker_count += 1
            logger.info(f"Circuit breaker ativado para {componente} após falha: {erro}")
        
        return {
            "componente": componente,
            "falhas_recentes": falhas_recentes,
            "circuit_breaker": componente in self.circuit_breakers,
            "reset_em": self.circuit_breakers.get(componente, {}).get("reset_em")
        }
    
    def verificar_circuit_breaker(self, componente: str) -> bool:
        """
        Verifica se o circuit breaker está ativo para um componente.
        
        Args:
            componente: Nome do componente a verificar
            
        Returns:
            True se o circuit breaker estiver ativo, False caso contrário
        """
        # Se o componente não tem circuit breaker, retorna False
        if componente not in self.circuit_breakers:
            return False
        
        # Verificar se o tempo de reset já passou
        agora = datetime.now()
        if agora >= self.circuit_breakers[componente]["reset_em"]:
            # Resetar o circuit breaker
            del self.circuit_breakers[componente]
            self.circuit_breaker_count -= 1
            return False
        
        return True
    
    def circuit_breaker_sincrono(self, componente: str):
        """
        Decorator para aplicar circuit breaker a uma função síncrona.
        
        Args:
            componente: Nome do componente para o circuit breaker
            
        Returns:
            Decorator configurado para o componente
        """
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                # Verificar se o circuit breaker está ativo
                if self.verificar_circuit_breaker(componente):
                    logger.warning(f"Circuit breaker ativo para {componente}. Operação bloqueada.")
                    return None
                
                try:
                    # Executar a função
                    return func(*args, **kwargs)
                except Exception as e:
                    # Registrar falha e propagar exceção
                    self.registrar_falha(componente, e)
                    raise
            
            return wrapper
        
        return decorator
    
    def circuit_breaker_assincrono(self, componente: str):
        """
        Decorator para aplicar circuit breaker a uma função assíncrona.
        
        Args:
            componente: Nome do componente para o circuit breaker
            
        Returns:
            Decorator configurado para o componente
        """
        def decorator(func):
            @wraps(func)
            async def wrapper(*args, **kwargs):
                # Verificar se o circuit breaker está ativo
                if self.verificar_circuit_breaker(componente):
                    logger.warning(f"Circuit breaker ativo para {componente}. Operação bloqueada.")
                    return None
                
                try:
                    # Executar a função assíncrona
                    return await func(*args, **kwargs)
                except Exception as e:
                    # Registrar falha e propagar exceção
                    self.registrar_falha(componente, e)
                    raise
            
            return wrapper
        
        return decorator
    
    def obter_modelo_fallback(self) -> Dict[str, Any]:
        """
        Obtém o modelo de fallback para uso quando os modelos principais falham.
        
        Returns:
            Modelo de fallback com função de predição
        """
        return self.modelo_fallback
    
    def monitorar_modelo(self, modelo_id: str, metricas: Dict[str, float]) -> Dict[str, Any]:
        """
        Monitora o desempenho de um modelo e registra alertas se necessário.
        
        Args:
            modelo_id: Identificador do modelo
            metricas: Métricas de desempenho do modelo
            
        Returns:
            Estado atual do monitoramento do modelo
        """
        # Inicializar registro do modelo se não existir
        if modelo_id not in self.alertas_modelo:
            self.alertas_modelo[modelo_id] = {
                "alertas": [],
                "total_alertas": 0
            }
        
        # Verificar métricas para alertas
        alertas = []
        for metrica, valor in metricas.items():
            if metrica.startswith("erro") and valor > self.config["limiar_alerta_modelo"]:
                alertas.append({
                    "timestamp": datetime.now(),
                    "metrica": metrica,
                    "valor": valor,
                    "limiar": self.config["limiar_alerta_modelo"]
                })
                logger.info(f"Alerta de desempenho para modelo {modelo_id}: {metrica}={valor:.4f}")
        
        # Atualizar alertas do modelo
        if alertas:
            self.alertas_modelo[modelo_id]["alertas"].extend(alertas)
            self.alertas_modelo[modelo_id]["total_alertas"] += len(alertas)
        
        # Verificar se o modelo está em estado crítico
        alertas_criticos = [a for a in self.alertas_modelo[modelo_id]["alertas"] 
                           if a["valor"] > self.config["limiar_critico_modelo"]]
        status = "CRITICAL" if alertas_criticos else "WARNING" if alertas else "OK"
        
        return {
            "modelo_id": modelo_id,
            "status": status,
            "alertas_total": self.alertas_modelo[modelo_id]["total_alertas"],
            "alertas_atual": len(alertas)
        }
    
    def registrar_watchdog(self, tarefa_id: str, intervalo_segundos: int, 
                          callback: Callable[..., bool], args: List[Any] = None) -> Dict[str, Any]:
        """
        Registra uma tarefa para monitoramento via watchdog.
        
        Args:
            tarefa_id: Identificador da tarefa
            intervalo_segundos: Intervalo de verificação em segundos
            callback: Função de callback para verificar/recuperar a tarefa
            args: Argumentos para a função de callback
            
        Returns:
            Estado do registro do watchdog
        """
        self.watchdogs[tarefa_id] = {
            "intervalo": intervalo_segundos,
            "callback": callback,
            "args": args or [],
            "ultima_verificacao": datetime.now(),
            "proxima_verificacao": datetime.now() + timedelta(seconds=intervalo_segundos),
            "status": "REGISTERED"
        }
        
        # Iniciar thread de watchdog se ainda não estiver rodando
        if not self.watchdog_running:
            self._iniciar_watchdog_thread()
        
        logger.info(f"Watchdog registrado para tarefa: {tarefa_id}")
        return {
            "tarefa_id": tarefa_id,
            "intervalo": intervalo_segundos,
            "status": "REGISTERED"
        }
    
    def _iniciar_watchdog_thread(self):
        """Inicia a thread de watchdog para monitoramento de tarefas."""
        if not self.watchdog_running and self.watchdogs:
            self.watchdog_running = True
            self.watchdog_thread = threading.Thread(target=self._executar_watchdog, daemon=True)
            self.watchdog_thread.start()
    
    def _executar_watchdog(self):
        """Executa o loop de watchdog para verificar tarefas registradas."""
        while self.watchdog_running:
            try:
                agora = datetime.now()
                
                # Verificar cada tarefa registrada
                for tarefa_id, info in list(self.watchdogs.items()):
                    if agora >= info["proxima_verificacao"]:
                        try:
                            # Executar callback
                            resultado = info["callback"](*info["args"])
                            
                            # Atualizar estado
                            self.watchdogs[tarefa_id]["ultima_verificacao"] = agora
                            self.watchdogs[tarefa_id]["proxima_verificacao"] = agora + timedelta(seconds=info["intervalo"])
                            self.watchdogs[tarefa_id]["status"] = "OK" if resultado else "FAILED"
                            
                            if not resultado:
                                logger.warning(f"Watchdog falhou para tarefa: {tarefa_id}")
                        except Exception as e:
                            logger.error(f"Erro no watchdog para tarefa {tarefa_id}: {str(e)}")
                            self.watchdogs[tarefa_id]["status"] = "ERROR"
                
                # Dormir por um curto período
                time.sleep(1)
            except Exception as e:
                logger.error(f"Erro no loop de watchdog: {str(e)}")
                time.sleep(5)  # Esperar um pouco mais em caso de erro
    
    def verificar_watchdogs(self) -> Dict[str, Any]:
        """
        Verifica o estado de todas as tarefas monitoradas por watchdog.
        
        Returns:
            Estado atual de todas as tarefas monitoradas
        """
        resultados = {}
        for tarefa_id, info in self.watchdogs.items():
            resultados[tarefa_id] = {
                "status": info["status"],
                "ultima_verificacao": info["ultima_verificacao"].isoformat(),
                "proxima_verificacao": info["proxima_verificacao"].isoformat()
            }
        
        return resultados
    
    def verificar_recursos_sistema(self) -> Dict[str, Any]:
        """
        Verifica os recursos do sistema (CPU, memória) e alerta se estiverem críticos.
        
        Returns:
            Informações sobre os recursos do sistema
        """
        if not PSUTIL_AVAILABLE:
            return {"erro": "psutil não disponível", "timestamp": datetime.now().isoformat()}
        
        try:
            # Obter uso de memória
            memoria = psutil.virtual_memory()
            memoria_percentual = memoria.percent
            
            # Obter uso de CPU
            cpu_percentual = psutil.cpu_percent(interval=0.1)
            
            # Verificar se os recursos estão críticos
            if memoria_percentual > self.config["memoria_critica"]:
                logger.warning(f"Uso de memória crítico (>{self.config['memoria_critica']}%). Considerando rollback.")
            
            if cpu_percentual > self.config["cpu_critica"]:
                logger.warning(f"Uso de CPU crítico (>{self.config['cpu_critica']}%). Considerando throttling.")
            
            return {
                "memoria_total": memoria.total,
                "memoria_disponivel": memoria.available,
                "memoria_percentual": memoria_percentual,
                "cpu_percentual": cpu_percentual,
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"Erro ao verificar recursos do sistema: {str(e)}")
            return {"erro": str(e), "timestamp": datetime.now().isoformat()}
    
    def obter_status(self) -> Dict[str, Any]:
        """
        Obtém o status geral do gerenciador de fallback.
        
        Returns:
            Status geral do gerenciador de fallback
        """
        # Verificar circuit breakers ativos
        circuit_breakers_ativos = {}
        for componente, info in list(self.circuit_breakers.items()):
            if self.verificar_circuit_breaker(componente):
                circuit_breakers_ativos[componente] = {
                    "ativado_em": info["ativado_em"].isoformat(),
                    "reset_em": info["reset_em"].isoformat(),
                    "falhas": info["falhas"]
                }
        
        # Obter recursos do sistema
        recursos = self.verificar_recursos_sistema()
        
        return {
            "status": "DEGRADED" if circuit_breakers_ativos else "OK",
            "circuit_breaker": bool(circuit_breakers_ativos),
            "componentes": circuit_breakers_ativos,
            "timestamp": datetime.now().isoformat(),
            "circuit_breaker_count": self.circuit_breaker_count,
            "watchdog_tasks": len(self.watchdogs),
            "recursos": recursos
        }
    
    def verificar_necessidade_de_rollback(self, componente: str) -> bool:
        """
        Verifica se um componente precisa de rollback para uma versão anterior.
        
        Esta função analisa o histórico de falhas recentes e o estado do circuit breaker
        para determinar se um componente deve ser revertido para uma versão anterior.
        
        Args:
            componente: Nome do componente a verificar
            
        Returns:
            bool: True se o componente precisa de rollback, False caso contrário
        """
        try:
            # Verificar se o componente está em circuit breaker
            if componente in self.circuit_breakers:
                # Verificar se o circuit breaker foi ativado recentemente
                agora = datetime.now()
                ativado_em = self.circuit_breakers[componente]["ativado_em"]
                
                # Se o circuit breaker foi ativado há menos de 10 minutos, não recomendar rollback ainda
                if (agora - ativado_em).total_seconds() < 600:  # 10 minutos
                    return False
                
                # Contar falhas recentes (dentro do período de verificação)
                periodo_verificacao = timedelta(seconds=self.config.get("periodo_verificacao_rollback", 21600))  # 6 horas padrão
                limite_tempo = agora - periodo_verificacao
                
                falhas_recentes = [
                    f for f in self.falhas.get(componente, [])
                    if f["timestamp"] >= limite_tempo
                ]
                
                # Se houver muitas falhas recentes (mais que o dobro do limiar de circuit breaker),
                # recomendar rollback
                if len(falhas_recentes) >= self.config["max_falhas"] * 2:
                    logger.warning(f"Recomendando rollback para componente {componente} após {len(falhas_recentes)} falhas recentes")
                    return True
            
            # Verificar recursos do sistema
            recursos = self.verificar_recursos_sistema()
            if isinstance(recursos, dict) and "erro" not in recursos:
                # Se o uso de memória estiver crítico, considerar rollback para componentes intensivos
                if recursos.get("memoria_percentual", 0) > self.config["memoria_critica"]:
                    # Lista de componentes conhecidos por serem intensivos em memória
                    componentes_intensivos = ["modelo_transformer", "processador_dados", "neural_governor"]
                    if componente in componentes_intensivos:
                        logger.warning(f"Recomendando rollback para componente intensivo {componente} devido a uso crítico de memória")
                        return True
            
            return False
            
        except Exception as e:
            logger.error(f"Erro ao verificar necessidade de rollback para {componente}: {str(e)}")
            return False
    
    def __del__(self):
        """Finaliza recursos ao destruir o objeto."""
        # Parar thread de watchdog
        self.watchdog_running = False
        if self.watchdog_thread and self.watchdog_thread.is_alive():
            self.watchdog_thread.join(timeout=1.0)
