#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Módulo para verificação de integridade de modelos no sistema KR_KRIPTO_ADVANCED.

Este módulo fornece funções para verificar a integridade dos modelos de ML/IA
utilizados pelo sistema, garantindo que não foram corrompidos ou adulterados.
"""

import os
import logging
import hashlib
from logging.handlers import TimedRotatingFileHandler
from typing import Dict, Any, Optional, Tuple

# Configurar logging com rotação
log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'logs')
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, 'model_integrity.log')

# Configurar logger com rotação diária
logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = TimedRotatingFileHandler(
        filename=log_file,
        when='midnight',
        interval=1,
        backupCount=30,
        encoding='utf-8'
    )
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    
    # Adicionar handler para console também
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    logger.setLevel(logging.INFO)
    logger.info("Logger configurado com rotação diária para model_integrity")

def calcular_hash_arquivo(caminho_arquivo: str) -> Optional[str]:
    """
    Calcula o hash SHA-256 de um arquivo.
    
    Args:
        caminho_arquivo: Caminho para o arquivo
        
    Returns:
        str: Hash SHA-256 do arquivo ou None se o arquivo não existir
    """
    if not os.path.exists(caminho_arquivo):
        logger.error(f"Arquivo não encontrado: {caminho_arquivo}")
        return None
    
    try:
        hash_sha256 = hashlib.sha256()
        with open(caminho_arquivo, "rb") as f:
            # Ler o arquivo em blocos para não sobrecarregar a memória
            for bloco in iter(lambda: f.read(4096), b""):
                hash_sha256.update(bloco)
        return hash_sha256.hexdigest()
    except Exception as e:
        logger.error(f"Erro ao calcular hash do arquivo {caminho_arquivo}: {e}")
        return None

def verificar_integridade_modelo(caminho_modelo: str, hash_esperado: Optional[str] = None) -> bool:
    """
    Verifica a integridade de um modelo de ML/IA.
    
    Se hash_esperado for fornecido, compara com o hash calculado.
    Caso contrário, apenas verifica se o arquivo existe e pode ser lido.
    
    Args:
        caminho_modelo: Caminho para o arquivo do modelo
        hash_esperado: Hash SHA-256 esperado para o modelo (opcional)
        
    Returns:
        bool: True se o modelo estiver íntegro, False caso contrário
    """
    # Verificar se o arquivo existe
    if not os.path.exists(caminho_modelo):
        logger.error(f"Arquivo de modelo não encontrado: {caminho_modelo}")
        return False
    
    # Se não foi fornecido hash esperado, apenas verifica se o arquivo existe e pode ser lido
    if not hash_esperado:
        try:
            # Tentar abrir o arquivo para leitura
            with open(caminho_modelo, "rb") as f:
                # Ler apenas alguns bytes para verificar se o arquivo pode ser lido
                f.read(1)
            logger.info(f"Modelo {caminho_modelo} existe e pode ser lido")
            return True
        except Exception as e:
            logger.error(f"Erro ao abrir modelo {caminho_modelo}: {e}")
            return False
    
    # Se foi fornecido hash esperado, calcular o hash do arquivo e comparar
    hash_calculado = calcular_hash_arquivo(caminho_modelo)
    if not hash_calculado:
        return False
    
    # Comparar hashes
    if hash_calculado.lower() == hash_esperado.lower():
        logger.info(f"Integridade do modelo {caminho_modelo} verificada com sucesso")
        return True
    else:
        logger.error(f"Falha na verificação de integridade do modelo {caminho_modelo}. Hash esperado: {hash_esperado}, Hash calculado: {hash_calculado}")
        return False

def registrar_hash_modelo(caminho_modelo: str, arquivo_registro: str) -> bool:
    """
    Calcula e registra o hash de um modelo em um arquivo de registro.
    
    Args:
        caminho_modelo: Caminho para o arquivo do modelo
        arquivo_registro: Caminho para o arquivo de registro de hashes
        
    Returns:
        bool: True se o registro foi bem-sucedido, False caso contrário
    """
    hash_calculado = calcular_hash_arquivo(caminho_modelo)
    if not hash_calculado:
        return False
    
    try:
        # Criar diretório do arquivo de registro se não existir
        os.makedirs(os.path.dirname(arquivo_registro), exist_ok=True)
        
        # Registrar hash no arquivo
        with open(arquivo_registro, "a") as f:
            f.write(f"{caminho_modelo}:{hash_calculado}\n")
        
        logger.info(f"Hash do modelo {caminho_modelo} registrado com sucesso em {arquivo_registro}")
        return True
    except Exception as e:
        logger.error(f"Erro ao registrar hash do modelo {caminho_modelo} em {arquivo_registro}: {e}")
        return False

def carregar_hashes_registrados(arquivo_registro: str) -> Dict[str, str]:
    """
    Carrega os hashes registrados de um arquivo de registro.
    
    Args:
        arquivo_registro: Caminho para o arquivo de registro de hashes
        
    Returns:
        Dict[str, str]: Dicionário com caminhos de modelos como chaves e hashes como valores
    """
    hashes = {}
    
    if not os.path.exists(arquivo_registro):
        logger.warning(f"Arquivo de registro de hashes não encontrado: {arquivo_registro}")
        return hashes
    
    try:
        with open(arquivo_registro, "r") as f:
            for linha in f:
                linha = linha.strip()
                if not linha or linha.startswith("#"):
                    continue
                
                partes = linha.split(":", 1)
                if len(partes) != 2:
                    logger.warning(f"Formato inválido na linha do arquivo de registro: {linha}")
                    continue
                
                caminho_modelo, hash_valor = partes
                hashes[caminho_modelo] = hash_valor
        
        logger.info(f"Carregados {len(hashes)} hashes de modelos do arquivo {arquivo_registro}")
        return hashes
    except Exception as e:
        logger.error(f"Erro ao carregar hashes do arquivo {arquivo_registro}: {e}")
        return {}

def verificar_integridade_todos_modelos(diretorio_modelos: str, arquivo_registro: str) -> Tuple[int, int]:
    """
    Verifica a integridade de todos os modelos em um diretório.
    
    Args:
        diretorio_modelos: Diretório contendo os modelos
        arquivo_registro: Arquivo com os hashes registrados
        
    Returns:
        Tuple[int, int]: (número de modelos verificados, número de modelos íntegros)
    """
    if not os.path.exists(diretorio_modelos):
        logger.error(f"Diretório de modelos não encontrado: {diretorio_modelos}")
        return 0, 0
    
    # Carregar hashes registrados
    hashes_registrados = carregar_hashes_registrados(arquivo_registro)
    
    # Contadores
    total_verificados = 0
    total_integros = 0
    
    # Verificar cada arquivo no diretório
    for raiz, _, arquivos in os.walk(diretorio_modelos):
        for arquivo in arquivos:
            # Verificar apenas arquivos com extensões de modelo
            if arquivo.endswith((".h5", ".pkl", ".pt", ".pth", ".onnx", ".pb")):
                caminho_completo = os.path.join(raiz, arquivo)
                caminho_relativo = os.path.relpath(caminho_completo, start=os.path.dirname(diretorio_modelos))
                
                total_verificados += 1
                
                # Verificar se o hash está registrado
                if caminho_relativo in hashes_registrados:
                    hash_esperado = hashes_registrados[caminho_relativo]
                    if verificar_integridade_modelo(caminho_completo, hash_esperado):
                        total_integros += 1
                else:
                    # Se não há hash registrado, apenas verifica se o arquivo pode ser lido
                    logger.warning(f"Modelo {caminho_relativo} não tem hash registrado")
                    if verificar_integridade_modelo(caminho_completo):
                        total_integros += 1
    
    logger.info(f"Verificação de integridade concluída: {total_integros}/{total_verificados} modelos íntegros")
    return total_verificados, total_integros

# Exemplo de uso (se executado diretamente)
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Uso: python model_integrity.py <caminho_modelo> [arquivo_registro]")
        sys.exit(1)
    
    caminho_modelo = sys.argv[1]
    
    if len(sys.argv) >= 3:
        arquivo_registro = sys.argv[2]
        registrar_hash_modelo(caminho_modelo, arquivo_registro)
    
    if verificar_integridade_modelo(caminho_modelo):
        print(f"Modelo {caminho_modelo} está íntegro")
        sys.exit(0)
    else:
        print(f"Modelo {caminho_modelo} não está íntegro ou não foi encontrado")
        sys.exit(1)
