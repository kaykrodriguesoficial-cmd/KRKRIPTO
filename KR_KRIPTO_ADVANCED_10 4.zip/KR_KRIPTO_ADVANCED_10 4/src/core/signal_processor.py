import pandas as pd
import logging
import asyncio
import traceback
import numpy as np # Added for NaN
from typing import Optional, Callable, Coroutine, Dict, Any # Added Optional, Callable, Coroutine, Dict, Any

# Initialize logger early to be available for all import attempts
logger = logging.getLogger("kr_kripto_processor")

# Import necessary components from other modules
# Note: These imports assume the refactored structure
from src.strategies.score_calculator import calcular_score_corrigido_v12 as calcular_score
from src.strategies.signal_classifier import prever_classe_corrigido_v12 as prever_classe
from src.strategies.fakeout import detectar_fakeout
from src.strategies.validators.input_validator import validar_entrada_sinal
from src.strategies.validators.book_imbalance import validar_book_institucional
from src.strategies.validators.filtros_institucionais import validar_filtro_institucional
from src.strategies.validators.volume_profile import validador_volume_profile
from src.strategies.validators.zonas_rejeicao import validador_zona_rejeicao
from src.strategies.risk_manager import aplicar_risco

from src.intelligence.ajustadores.heuristicas_controller import ajustar_heuristicas
from src.intelligence.feedback_loop_limited import rodar_feedback_condicional # Needs context (globals?)
from src.intelligence.competicoes.campeonato_modelos import executar_campeonato # Needs context
from src.intelligence.mutacoes.mutador_transformer import gerar_mutacao_transformer # Needs context
from src.intelligence.book_feedback import ajustar_score_por_book
# from ..intelligence.context_switcher import definir_modo_execucao_por_regime
from src.intelligence.context_switcher import ContextSwitcher, MarketRegime # Etapa 018
from src.intelligence.avaliar_decisor import avaliar_decisao_por_similaridade
from src.intelligence.aprendizado.aprendizado_rentabilidade import ajustar_pesos_por_lucro # Needs context
from src.intelligence.punitivo_falso_positivo import verificar_perda_sequencial # Needs context
from src.intelligence.ia_fusao_contextual import prever_score_fusao

from src.infrastructure.notifier import enviar_telegram, log_erro
from src.infrastructure.memory import MemoriaTemporal # Needs instance
from src.infrastructure.rollback import verificar_necessidade_de_rollback # Needs context

from src.realtime.book_processor import BookProcessor, BookState # Needs instance/context

# RL Imports (Etapa 016)
try:
    # Use absolute imports based on project structure
    from src.intelligence.rl.agente_rl import AgenteRL, RealAgenteRL # Added RealAgenteRL
    from src.intelligence.rl.ambiente_rl import AmbienteRL, RealAmbienteRL # Added RealAmbienteRL
    RL_AVAILABLE = True
except ImportError as e:
    logger.warning(f"Módulos RL não encontrados ou erro na importação: {e}. Funcionalidade RL desativada.")
    RL_AVAILABLE = False
    # Definir stubs se RL não estiver disponível
    class AgenteRL: pass
    class AmbienteRL: pass
    class RealAgenteRL: pass # Stub
    class RealAmbienteRL: pass # Stub

# Prometheus metrics
try:
    from src.infrastructure.prometheus_exporter import inc_signals_processed, inc_errors # Added inc_errors for potential future use
    PROMETHEUS_AVAILABLE = True
except ImportError:
    logger.warning("Módulo Prometheus Exporter não encontrado. Métricas Prometheus desativadas.")
    PROMETHEUS_AVAILABLE = False
    # Define stubs if Prometheus is not available
    def inc_signals_processed(*args, **kwargs): pass
    def inc_errors(*args, **kwargs): pass

# Import GerenciadorFallback for model access (Etapa 015)
from src.infrastructure.fallback import GerenciadorFallback

# Import Neural Governance components (Etapa 017)
try:
    from src.intelligence.governance.neural_governance import NeuralGovernor, ModelPerformanceTracker
    GOVERNANCE_AVAILABLE = True # Explicitly set flag
except ImportError as e:
    logger.critical(f"[CRÍTICO] Falha ao importar NeuralGovernor ou ModelPerformanceTracker de src.intelligence.governance.neural_governance: {e}. O processador de sinais não pode operar sem eles.")
    raise ImportError(f"Dependência crítica NeuralGovernor/ModelPerformanceTracker não encontrada: {e}") from e

# Import Attack Detector components
try:
    from src.intelligence.attack_detector import AttackDetector
    ATTACK_DETECTOR_AVAILABLE = True # Definindo a flag como True se a importação for bem-sucedida
except ImportError as e:
    logger.warning(f"Falha ao importar AttackDetector de src.intelligence.attack_detector: {e}. Funcionalidade AttackDetector desativada.")
    ATTACK_DETECTOR_AVAILABLE = False # Definindo a flag como False em caso de falha
    class AttackDetector: # Stub para evitar erros de NameError em outras partes do código
        def __init__(self, config: dict):
            logger.info("AttackDetector Stub inicializado devido à falha na importação do módulo real.")
        def detect_artificial_volume(self, *args, **kwargs):
            return False
        def was_spoofing_confirmed_recently(self, *args, **kwargs):
            return False

# Import News Provider components (Etapa 021)
try:
    from src.data_providers.news_provider import NewsProvider, NEWS_PROVIDER_AVAILABLE as NP_AVAILABLE_FLAG
    NEWS_PROVIDER_AVAILABLE = NP_AVAILABLE_FLAG # Use the flag from the module itself if available
except ImportError:
    logger.warning("Módulo NewsProvider não encontrado. Funcionalidade de notícias desativada.")
    NEWS_PROVIDER_AVAILABLE = False
    class NewsProvider: pass # Stub

def prever_score_final(score_raw, probabilidade, fakeout, w_score, w_prob, w_fake):
    fakeout_val = float(fakeout) if fakeout is not None else 0.0
    return (score_raw * w_score) + (probabilidade * w_prob) - (fakeout_val * w_fake)

async def analisar_sinal(
    ativo: str,
    df_original: pd.DataFrame,
    memoria_temporal: MemoriaTemporal,
    processadores_book: dict,
    agentes_rl: dict,
    ambientes_rl: dict,
    config: dict,
    fallback_manager: GerenciadorFallback,
    governor: Optional[NeuralGovernor] = None, 
    tracker: Optional[ModelPerformanceTracker] = None, 
    context_switcher: Optional[ContextSwitcher] = None, 
    strategy_config: Optional[dict] = None, 
    attack_detector: Optional[AttackDetector] = None, 
    news_provider: Optional[NewsProvider] = None 
):
    logger.info(f"[{ativo}] --- INICIO ANALISAR_SINAL ---")

    strategy_config = strategy_config or {}
    default_strategy = strategy_config.get("DEFAULT", {})
    default_strategy = default_strategy if isinstance(default_strategy, dict) else {}

    regime_name = MarketRegime.INDEFINIDO 
    final_decision_str = "descartado_inicio"

    try:
        valido, df = validar_entrada_sinal(df_original, ativo)
        logger.info(f"[{ativo}] Validacao entrada: valido={valido}, df is None={df is None}, df_shape={df.shape if df is not None else 'N/A'}")
        if not valido:
            if df is None:
                logger.debug(f"[{ativo}] Signal analysis waiting for more data.")
                final_decision_str = "aguardando_dados"
            else:
                logger.warning(f"[{ativo}] Signal analysis cancelled due to invalid input.")
                final_decision_str = "descartado_invalido"
            if PROMETHEUS_AVAILABLE:
                inc_signals_processed(ativo, regime_name, final_decision_str)
            return

        active_strategy = default_strategy 
        strategy_description = active_strategy.get("description", "Default")

        if context_switcher:
            try:
                identified_regime_value_str = context_switcher.identify_regime(df)
                regime_name = identified_regime_value_str
                
                regime_strategy = strategy_config.get(regime_name, default_strategy)
                active_strategy = regime_strategy if isinstance(regime_strategy, dict) else default_strategy
                strategy_description = active_strategy.get("description", "Default")
                logger.info(f"[{ativo}] Regime: {regime_name} | Strategy: {strategy_description}")
            except Exception as regime_err:
                logger.error(f"[{ativo}] Erro ao identificar regime: {regime_err}. Usando DEFAULT.")
                regime_name = MarketRegime.INDEFINIDO
                active_strategy = default_strategy
                strategy_description = active_strategy.get("description", "Default")
        else:
            logger.debug(f"[{ativo}] ContextSwitcher não disponível. Usando estratégia DEFAULT.")
            active_strategy = default_strategy
            strategy_description = active_strategy.get("description", "Default")

        default_limiar_compra = config.get("limiar_compra", 0.65)
        default_limiar_venda = config.get("limiar_venda", 0.35)
        limiar_compra = active_strategy.get("limiar_compra", default_limiar_compra)
        limiar_venda = active_strategy.get("limiar_venda", default_limiar_venda)
        active_validators = active_strategy.get("active_validators", [
            "zonas_rejeicao",
            "volume_profile",
            "filtros_institucionais",
            "book_imbalance"
        ])

        AUTOML_AVAILABLE = config.get("automl_available", False)

        if ATTACK_DETECTOR_AVAILABLE and attack_detector:
            try:
                logger.debug(f"[{ativo}] Calling attack_detector.detect_artificial_volume...")
                volume_spike_detected = attack_detector.detect_artificial_volume(df)
                logger.debug(f"[{ativo}] detect_artificial_volume returned: {volume_spike_detected}")
                if volume_spike_detected:
                    logger.warning(f"[{ativo}] Sinal descartado devido a possível volume artificial detectado.")
                    final_decision_str = "descartado_volume_artificial"
                    if PROMETHEUS_AVAILABLE:
                        inc_signals_processed(ativo, regime_name, final_decision_str)
                    return 
                logger.debug(f"[{ativo}] Calling attack_detector.was_spoofing_confirmed_recently...")
                spoofing_confirmed = attack_detector.was_spoofing_confirmed_recently()
                logger.debug(f"[{ativo}] was_spoofing_confirmed_recently returned: {spoofing_confirmed}")
                if spoofing_confirmed:
                    logger.warning(f"[{ativo}] Sinal descartado devido a spoofing confirmado recentemente.")
                    final_decision_str = "descartado_spoofing_recente"
                    if PROMETHEUS_AVAILABLE:
                        inc_signals_processed(ativo, regime_name, final_decision_str)
                    return
            except Exception as attack_err:
                logger.error(f"[{ativo}] Erro ao executar AttackDetector: {attack_err}")

        news_score = 0.5 
        if NEWS_PROVIDER_AVAILABLE and news_provider:
            try:
                news_score = await news_provider.get_recent_news_score(ativo)
                logger.info(f"[{ativo}] News Score: {news_score:.2f}")
            except Exception as news_err:
                logger.error(f"[{ativo}] Erro ao obter news score: {news_err}")
                news_score = 0.5 
        else:
            logger.debug(f"[{ativo}] News Provider não disponível ou não inicializado.")
        if not df.empty:
             df.loc[:, "news_score"] = news_score

        i = len(df) - 1
        processador_book = processadores_book.get(ativo)
        book_state = processador_book.get_state() if processador_book else BookState(config={})
        agente_rl = agentes_rl.get(ativo)
        ambiente_rl = ambientes_rl.get(ativo)
        acao_rl = 0 
        estado_rl = None
        recompensa_rl = 0.0

        rl_active_for_regime = active_strategy.get("rl_active", False)

        if RL_AVAILABLE and rl_active_for_regime and agente_rl and ambiente_rl:
            try:
                ambiente_rl.atualizar_dados(df, book_state)
                estado_rl = ambiente_rl.obter_estado()
                if estado_rl is not None:
                    acao_rl = agente_rl.escolher_acao(estado_rl, exploracao_ativa=True) 
                    prox_estado_rl, recompensa_rl, done_rl = ambiente_rl.step(acao_rl)
                    agente_rl.aprender(estado_rl, acao_rl, recompensa_rl, prox_estado_rl, done_rl)
                else:
                    logger.warning(f"[{ativo}] Estado RL é None, pulando escolha de ação e aprendizado RL.")
            except Exception as e_rl:
                logger.error(f"[{ativo}] Erro no ciclo RL: {e_rl}")
                log_erro(f"[{ativo}] Erro no ciclo RL: {e_rl}\n{traceback.format_exc()}")

        governor_active_for_regime = active_strategy.get("governor_active", False)
        logger.debug(f"DEBUG_GOVERNOR_ACTIVE: [{ativo}] Regime: {regime_name}, governor_active_for_regime: {governor_active_for_regime}, GOVERNANCE_AVAILABLE: {GOVERNANCE_AVAILABLE}")

        score_raw = calcular_score(df, i, config.get("weights", {}))
        logger.info(f"[{ativo}] Score Raw: {score_raw:.4f}")

        model_path_classifier, scaler_path_classifier = fallback_manager.get_model_and_scaler_paths("classifier")
        
        pred_class_name = "desconhecida"
        probabilidade = 0.0

        if GOVERNANCE_AVAILABLE and governor and governor_active_for_regime:
            try:
                pred_class_name, probabilidade = await governor.predict_with_active_model(df, model_type="classifier")
                logger.info(f"[{ativo}] Governor Prediction: Class={pred_class_name}, Prob={probabilidade:.4f}")
            except Exception as gov_err:
                logger.error(f"[{ativo}] Erro na predição com NeuralGovernor: {gov_err}. Tentando fallback...")
                pred_class_name, probabilidade = await prever_classe(df, i, model_path_classifier, scaler_path_classifier)
                logger.info(f"[{ativo}] Fallback Prediction: Class={pred_class_name}, Prob={probabilidade:.4f}")
        else:
            pred_class_name, probabilidade = await prever_classe(df, i, model_path_classifier, scaler_path_classifier)
            logger.info(f"[{ativo}] Direct Prediction: Class={pred_class_name}, Prob={probabilidade:.4f}")

        fakeout_detectado = detectar_fakeout(df, i, config.get("fakeout_threshold", 0.5))
        logger.info(f"[{ativo}] Fakeout Detectado: {fakeout_detectado}")

        # Corrected call to ajustar_heuristicas to match its 6-argument signature
        # Note: The stub for ajustar_heuristicas (in heuristicas_controller.py) returns a dict, 
        # while this assignment expects three values. This might cause a new error (e.g., ValueError)
        # if the stub is not updated to return three values as originally intended.
        score_raw, pred_class_name, probabilidade = ajustar_heuristicas(
            ativo,
            df,
            i,  # Corresponds to 'indice_atual' in ajustar_heuristicas signature
            score_raw,  # Corresponds to 'score'
            pred_class_name,  # Corresponds to 'classe'
            config.get("heuristics", {})  # Corresponds to 'config_heuristics'
        )
        logger.info(f"[{ativo}] Após Heurísticas: Score={score_raw:.4f}, Classe={pred_class_name}, Prob={probabilidade:.4f}")

        score_raw_val = score_raw if pd.notna(score_raw) else 0.0
        probabilidade_val = probabilidade if pd.notna(probabilidade) else 0.0
        fakeout_val_num = 1.0 if fakeout_detectado else 0.0
        news_score_val = news_score if pd.notna(news_score) else 0.5
        acao_rl_val = float(acao_rl)

        score_final = await prever_score_fusao(
            score_raw_val, 
            probabilidade_val, 
            fakeout_val_num, 
            news_score_val, 
            acao_rl_val, 
            active_strategy.get("decision_weights", config.get("decision_weights", {})),
            model_path_fusion=fallback_manager.get_model_path("fusion"),
            scaler_path_fusion=fallback_manager.get_scaler_path("fusion")
        )
        logger.info(f"[{ativo}] Score Final (Fusão): {score_final:.4f}")

        sinal_final_pre_risco = "NEUTRO"
        if score_final >= limiar_compra:
            sinal_final_pre_risco = "COMPRA"
        elif score_final <= limiar_venda:
            sinal_final_pre_risco = "VENDA"
        logger.info(f"[{ativo}] Sinal Pré-Risco: {sinal_final_pre_risco} (Score: {score_final:.4f}, L.Compra: {limiar_compra}, L.Venda: {limiar_venda})")

        validation_results = []
        if "book_imbalance" in active_validators:
            book_valido, book_msg = validar_book_institucional(book_state, config.get("book_imbalance", {}))
            validation_results.append(("Book Imbalance", book_valido, book_msg))
        if "filtros_institucionais" in active_validators:
            filtro_valido, filtro_msg = validar_filtro_institucional(df, i, config.get("filtros_institucionais", {}))
            validation_results.append(("Filtros Institucionais", filtro_valido, filtro_msg))
        if "volume_profile" in active_validators:
            vp_valido, vp_msg = validador_volume_profile(df, i, config.get("volume_profile", {}))
            validation_results.append(("Volume Profile", vp_valido, vp_msg))
        if "zonas_rejeicao" in active_validators:
            zr_valido, zr_msg = validador_zona_rejeicao(df, i, config.get("zonas_rejeicao", {}))
            validation_results.append(("Zonas Rejeição", zr_valido, zr_msg))

        passed_all_validators = True
        for name, is_valid, msg in validation_results:
            logger.info(f"[{ativo}] Validador [{name}]: Valido={is_valid}, Msg='{msg}'")
            if not is_valid:
                passed_all_validators = False
        
        sinal_final_pos_validadores = sinal_final_pre_risco
        if not passed_all_validators:
            logger.info(f"[{ativo}] Sinal '{sinal_final_pre_risco}' reprovado por um ou mais validadores. Considerado NEUTRO.")
            sinal_final_pos_validadores = "NEUTRO"
        else:
            logger.info(f"[{ativo}] Sinal '{sinal_final_pre_risco}' aprovado por todos os validadores ativos.")

        decisao_risco = aplicar_risco(df, i, sinal_final_pos_validadores, config.get("risk_params", {}), memoria_temporal, ativo)
        sinal_final = decisao_risco.get("sinal_final", "NEUTRO")
        logger.info(f"[{ativo}] Sinal Pós-Risco: {sinal_final}")

        if memoria_temporal and hasattr(memoria_temporal, 'registrar_sinal_para_feedback'):
            memoria_temporal.registrar_sinal_para_feedback(ativo, df.iloc[i], score_final, sinal_final, pred_class_name, probabilidade)
        
        if sinal_final != "NEUTRO" and sinal_final != "descartado":
            mensagem_telegram = f"Sinal: {sinal_final} para {ativo}\nScore: {score_final:.2f}\nRegime: {regime_name}\nEstratégia: {strategy_description}"
            await enviar_telegram(mensagem_telegram)

        final_decision_str = sinal_final.lower() 
        if PROMETHEUS_AVAILABLE:
            inc_signals_processed(ativo, regime_name, final_decision_str)
        
        logger.info(f"[{ativo}] --- FIM ANALISAR_SINAL: {sinal_final} ---")
        return {"sinal_final": sinal_final, "score": score_final, "classe": pred_class_name, "probabilidade": probabilidade, "regime": regime_name, "active_strategy": active_strategy, "strategy_description": strategy_description}

    except Exception as e:
        logger.error(f"Erro em analisar_sinal para {ativo}: {e}")
        logger.info(f"[{ativo}] LOG: Excecao capturada no bloco try-except final: {e}")
        tb_str = traceback.format_exc()
        log_erro(f"Erro em analisar_sinal para {ativo}: {e}\n{tb_str}")
        final_decision_str = "erro_analise"
        if PROMETHEUS_AVAILABLE:
            inc_signals_processed(ativo, regime_name, final_decision_str)
            inc_errors(ativo, regime_name, type(e).__name__)
        return None

