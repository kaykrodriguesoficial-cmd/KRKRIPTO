# src/strategies/validators/zonas_rejeicao.py

import pandas as pd
import logging

logger = logging.getLogger(__name__)

def validador_zona_rejeicao(df: pd.DataFrame) -> bool:
    """
    Valida o sinal verificando se o preço atual está em uma zona de potencial rejeição.

    Args:
        df (pd.DataFrame): DataFrame com dados de klines (ohlc em minúsculo).

    Returns:
        bool: True se não estiver em zona de rejeição óbvia, False caso contrário.
    """
    try:
        if df is None or df.empty:
            logger.warning("Zona Rejeição: DataFrame vazio ou None.")
            return False # Considera inválido por segurança

        # --- CORREÇÃO: Usar nomes minúsculos --- 
        required_cols = ["high", "low", "close", "open"]
        if not all(col in df.columns for col in required_cols):
            logger.warning(f"Zona Rejeição: Colunas ohlc ({required_cols}) não encontradas. Colunas presentes: {list(df.columns)}")
            return False
        # --- FIM CORREÇÃO ---

        periodo_analise = 10 # Analisar as últimas N velas
        if len(df) < periodo_analise:
            logger.info(f"Zona Rejeição: Dados insuficientes ({len(df)} < {periodo_analise}).")
            return True # Não há dados suficientes para confirmar rejeição

        df_recente = df.iloc[-periodo_analise:]
        ultimo_candle = df.iloc[-1]

        # --- CORREÇÃO: Usar nomes minúsculos --- 
        range_candle = ultimo_candle["high"] - ultimo_candle["low"]
        body_candle = abs(ultimo_candle["close"] - ultimo_candle["open"])

        # Evitar divisão por zero se range for 0
        if range_candle == 0:
             return True # Vela sem range, não indica rejeição clara

        # Calcula proporção da sombra superior e inferior
        # Evitar divisão por zero se range for 0 (já verificado, mas redundância segura)
        if range_candle == 0:
            sombra_superior = 0
            sombra_inferior = 0
            proporcao_corpo = 1 # Corpo ocupa todo o range (que é zero)
        else:
            sombra_superior = (ultimo_candle["high"] - max(ultimo_candle["close"], ultimo_candle["open"])) / range_candle
            sombra_inferior = (min(ultimo_candle["close"], ultimo_candle["open"]) - ultimo_candle["low"]) / range_candle
            proporcao_corpo = body_candle / range_candle
        # --- FIM CORREÇÃO ---

        # Define limiares para sombra longa e corpo pequeno
        limiar_sombra_longa = 0.6
        limiar_corpo_pequeno = 0.3

        long_upper_wick = sombra_superior > limiar_sombra_longa
        long_lower_wick = sombra_inferior > limiar_sombra_longa
        small_body = proporcao_corpo < limiar_corpo_pequeno

        # --- CORREÇÃO: Usar nomes minúsculos --- 
        # Verifica se o fechamento está perto de máximas/mínimas recentes
        maxima_recente = df_recente["high"].max()
        minima_recente = df_recente["low"].min()
        range_recente = maxima_recente - minima_recente

        # Evitar divisão por zero
        if range_recente == 0:
            return True # Preço estável, sem rejeição clara

        perto_maxima = (maxima_recente - ultimo_candle["close"]) / range_recente < 0.1 # Fechamento nos 10% superiores do range recente
        perto_minima = (ultimo_candle["close"] - minima_recente) / range_recente < 0.1 # Fechamento nos 10% inferiores do range recente
        # --- FIM CORREÇÃO ---

        # Condição de Rejeição:
        # 1. Última vela mostra rejeição clara (sombra superior longa e corpo pequeno) E preço perto da máxima recente
        if long_upper_wick and small_body and perto_maxima:
            # --- CORREÇÃO MANUAL REAL: Usar aspas simples internas na f-string --- 
            logger.info(f"Zona Rejeição: Detectada possível rejeição de alta (sombra superior longa perto da máxima recente). Último Fechamento: {ultimo_candle['close']:.2f}, Máxima Recente: {maxima_recente:.2f}")
            # --- FIM CORREÇÃO ---
            return False # Invalida o sinal (potencialmente uma COMPRA)

        # 2. Última vela mostra rejeição clara (sombra inferior longa e corpo pequeno) E preço perto da mínima recente
        if long_lower_wick and small_body and perto_minima:
            # --- CORREÇÃO MANUAL REAL: Usar aspas simples internas na f-string --- 
            logger.info(f"Zona Rejeição: Detectada possível rejeição de baixa (sombra inferior longa perto da mínima recente). Último Fechamento: {ultimo_candle['close']:.2f}, Mínima Recente: {minima_recente:.2f}")
            # --- FIM CORREÇÃO ---
            return False # Invalida o sinal (potencialmente uma VENDA)

        # Se nenhuma condição de rejeição clara foi encontrada
        return True

    except Exception as e:
        logger.error(f"Erro no validador_zona_rejeicao: {e}")
        return False # Falha na validação em caso de erro

