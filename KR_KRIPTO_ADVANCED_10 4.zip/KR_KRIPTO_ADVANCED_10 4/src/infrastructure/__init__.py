"""
Pacote de infraestrutura para o sistema KR_KRIPTO_ADVANCED.

Este pacote contém módulos relacionados à infraestrutura do sistema, como:
- Notificações (Telegram, email, etc.)
- Segurança
- Operações com APIs externas
- Gerenciamento de recursos
"""

# Exportar símbolos importantes para facilitar importação
from .notifier import enviar_telegram, enviar_email, enviar_sms, enviar_webhook
