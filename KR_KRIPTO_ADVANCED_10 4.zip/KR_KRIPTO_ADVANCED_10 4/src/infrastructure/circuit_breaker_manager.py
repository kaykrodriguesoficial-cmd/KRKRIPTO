import pybreaker
import logging
from functools import wraps
import asyncio

# Configuração do logger
logger = logging.getLogger(__name__)

# --- Configuração do Circuit Breaker (usando a biblioteca pybreaker) --- 

# Define os limites para abrir o disjuntor
FAIL_MAX = 5
RESET_TIMEOUT = 60 # Segundos para tentar fechar (half-open state)

# Cria uma instância global do Circuit Breaker com pybreaker
main_breaker = pybreaker.CircuitBreaker(
    fail_max=FAIL_MAX,
    reset_timeout=RESET_TIMEOUT,
    # expected_exception não é um parâmetro direto em pybreaker, o tratamento é feito no wrapper
    name="main_signal_processor",
    # Listeners podem ser adicionados se compatíveis com pybreaker
)

# --- Decorator para Facilidade de Uso --- 

def circuit_breaker(breaker=main_breaker):
    """Decorator para aplicar facilmente o circuit breaker (pybreaker) a uma função async."""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            state_before = breaker.current_state 

            try:
                # pybreaker não tem call_async, ele executa a função diretamente se o estado permitir
                # A verificação de estado aberto é feita internamente pelo pybreaker ao chamar a função
                if breaker.current_state == pybreaker.STATE_OPEN:
                    logger.error(f"CircuitBreaker \t{breaker.name}\t: Estado OPEN. Chamada para {func.__name__} rejeitada.")
                    # pybreaker levanta CircuitBreakerError automaticamente quando o breaker está aberto
                    # Para manter consistência, podemos simular o erro que seria levantado ou deixar o pybreaker tratar
                    raise pybreaker.CircuitBreakerError(f"Circuit {breaker.name} is OPEN")

                # Notifica listeners antes da chamada (se houver e for compatível com pybreaker)
                for listener in breaker.listeners:
                    if hasattr(listener, 'before_call'):
                        try:
                            listener.before_call(breaker, func, *args, **kwargs)
                        except Exception as listener_exc:
                            logger.error(f"Error in listener.before_call for {breaker.name}: {listener_exc}")

                result = await func(*args, **kwargs)
                # A ausência de exceção notifica o pybreaker sobre o sucesso.
                # Não é necessário chamar breaker.success() explicitamente.
                if state_before in [pybreaker.STATE_OPEN, pybreaker.STATE_HALF_OPEN] and breaker.current_state == pybreaker.STATE_CLOSED:
                     logger.info(f"CircuitBreaker \t{breaker.name}\t: Estado mudou para CLOSED (Operação normal retomada após sucesso)")
                return result
            except pybreaker.CircuitBreakerError as e:
                # Este bloco captura o erro levantado pelo pybreaker quando o circuito está aberto
                logger.error(f"CircuitBreaker \t{breaker.name}\t: Chamada para {func.__name__} rejeitada. Breaker está {breaker.current_state}. Erro: {e}")
                raise # Re-lança a CircuitBreakerError
            except Exception as e:
                # A exceção por si só notificará o pybreaker sobre a falha.
                # Não é necessário chamar breaker.fail(e) explicitamente.
                logger.warning(f"CircuitBreaker \t{breaker.name}\t: Falha detectada em {func.__name__}. Erro: {type(e).__name__}({e}). Falhas: {breaker.fail_counter}")
                if state_before != pybreaker.STATE_OPEN and breaker.current_state == pybreaker.STATE_OPEN:
                     logger.error(f"CircuitBreaker \t{breaker.name}\t: Estado mudou para OPEN devido à falha (Limite de {breaker.fail_max} falhas atingido)")
                raise
            finally:
                current_state_after = breaker.current_state
                if state_before != pybreaker.STATE_HALF_OPEN and current_state_after == pybreaker.STATE_HALF_OPEN:
                    logger.warning(f"CircuitBreaker \t{breaker.name}\t: Estado mudou para HALF_OPEN (Tentando fechar... após timeout)")
        return wrapper
    return decorator