# src/infrastructure/executor_contextual.py
"""
Módulo para execução contextual de sinais de trading.
Implementa o executor assíncrono para processamento de sinais.
"""

import os
import sys
import time
import json
import logging
import asyncio
import traceback
from typing import Dict, List, Optional, Any, Tuple, Union
from datetime import datetime, timedelta

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Tentar importar o OperadorBinance de diferentes locais possíveis
try:
    from src.infrastructure.operador import OperadorBinance
except ImportError:
    try:
        from infrastructure.operador import OperadorBinance
    except ImportError:
        try:
            # Criar diretório se não existir
            os.makedirs("src/infrastructure", exist_ok=True)
            
            # Criar arquivo stub se não existir
            operador_path = "src/infrastructure/operador.py"
            if not os.path.exists(operador_path):
                with open(operador_path, "w") as f:
                    f.write("""
class OperadorBinance:
    def __init__(self, api_key=None, api_secret=None, testnet=True, config=None):
        self.api_key = api_key
        self.api_secret = api_secret
        self.testnet = testnet
        self.config = config or {}
    
    async def inicializar(self):
        return True
    
    async def criar_ordem(self, simbolo, lado, tipo, quantidade=None, preco=None, **kwargs):
        return {"orderId": "123456"}
""")
            
            from src.infrastructure.operador import OperadorBinance
        except ImportError:
            logger.warning("OperadorBinance não encontrado. Usando stub interno.")
            
            # Definir stub interno
            class OperadorBinance:
                def __init__(self, api_key=None, api_secret=None, testnet=True, config=None):
                    self.api_key = api_key
                    self.api_secret = api_secret
                    self.testnet = testnet
                    self.config = config or {}
                
                async def inicializar(self):
                    return True
                
                async def criar_ordem(self, simbolo, lado, tipo, quantidade=None, preco=None, **kwargs):
                    return {"orderId": "123456"}


class ExecutorContextualAsync:
    """
    Classe para execução contextual de sinais de trading.
    Implementa o executor assíncrono para processamento de sinais.
    """
    
    def __init__(self, operador=None, config=None):
        """
        Inicializa o executor contextual.
        
        Args:
            operador: Instância de OperadorBinance ou None para criar uma nova
            config: Configurações adicionais
        """
        self.config = config or {}
        
        # Usar operador fornecido ou criar novo
        self.operador = operador
        if self.operador is None:
            api_key = self.config.get("api_key")
            api_secret = self.config.get("api_secret")
            testnet = self.config.get("testnet", True)
            
            self.operador = OperadorBinance(
                api_key=api_key,
                api_secret=api_secret,
                testnet=testnet,
                config=self.config
            )
        
        # Configurações de execução
        self.max_tentativas = self.config.get("max_tentativas", 3)
        self.delay_entre_tentativas = self.config.get("delay_entre_tentativas", 1)
        
        # Cache de contexto
        self._contexto_cache = {}
        self._contexto_lock = asyncio.Lock()
        
        # Inicializar operador
        self._operador_inicializado = False
        
        logger.info("ExecutorContextual inicializado")
    
    async def inicializar(self):
        """
        Inicializa o operador se ainda não estiver inicializado.
        
        Returns:
            bool: True se a inicialização foi bem-sucedida, False caso contrário
        """
        if self._operador_inicializado:
            return True
        
        try:
            resultado = await self.operador.inicializar()
            self._operador_inicializado = resultado
            return resultado
        except Exception as e:
            logger.error(f"Erro ao inicializar operador: {e}")
            return False
    
    async def obter_contexto(self, simbolo):
        """
        Obtém o contexto atual para um símbolo.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            
        Returns:
            dict: Contexto atual ou None em caso de falha
        """
        async with self._contexto_lock:
            # Verificar cache
            if simbolo in self._contexto_cache:
                return self._contexto_cache[simbolo]
            
            # Inicializar contexto
            try:
                # Obter preço atual
                preco_atual = await self.operador.obter_preco_atual(simbolo)
                if preco_atual is None:
                    logger.error(f"Não foi possível obter preço atual para {simbolo}")
                    return None
                
                # Obter histórico de klines
                klines = await self.operador.obter_historico_klines(simbolo, "1h", limite=100)
                if klines is None:
                    logger.error(f"Não foi possível obter histórico de klines para {simbolo}")
                    return None
                
                # Criar contexto
                contexto = {
                    "simbolo": simbolo,
                    "preco_atual": preco_atual,
                    "klines": klines,
                    "timestamp": time.time(),
                    "ordens_abertas": await self.operador.obter_ordens_abertas(simbolo)
                }
                
                # Armazenar no cache
                self._contexto_cache[simbolo] = contexto
                return contexto
            except Exception as e:
                logger.error(f"Erro ao obter contexto para {simbolo}: {e}")
                return None
    
    async def validar_sinal(self, sinal):
        """
        Valida um sinal de trading.
        
        Args:
            sinal: Dicionário com informações do sinal
            
        Returns:
            tuple: (valido, motivo)
        """
        try:
            # Validar campos obrigatórios
            campos_obrigatorios = ["simbolo", "lado", "tipo"]
            for campo in campos_obrigatorios:
                if campo not in sinal:
                    return False, f"Campo obrigatório ausente: {campo}"
            
            # Validar símbolo
            simbolo = sinal["simbolo"]
            preco_atual = await self.operador.obter_preco_atual(simbolo)
            if preco_atual is None:
                return False, f"Símbolo inválido ou não disponível: {simbolo}"
            
            # Validar lado
            lado = sinal["lado"]
            if lado not in ["BUY", "SELL"]:
                return False, f"Lado inválido: {lado}"
            
            # Validar tipo
            tipo = sinal["tipo"]
            tipos_validos = ["LIMIT", "MARKET", "STOP_LOSS", "STOP_LOSS_LIMIT", "TAKE_PROFIT", "TAKE_PROFIT_LIMIT"]
            if tipo not in tipos_validos:
                return False, f"Tipo inválido: {tipo}"
            
            # Validar quantidade ou valor
            if "quantidade" not in sinal and "valor" not in sinal:
                return False, "Quantidade ou valor deve ser fornecido"
            
            # Validar preço para ordens limit
            if tipo == "LIMIT" and "preco" not in sinal:
                return False, "Preço deve ser fornecido para ordens limit"
            
            return True, "OK"
        except Exception as e:
            logger.error(f"Erro ao validar sinal: {e}")
            return False, f"Erro ao validar sinal: {e}"
    
    async def executar_sinal(self, sinal):
        """
        Executa um sinal de trading.
        
        Args:
            sinal: Dicionário com informações do sinal
            
        Returns:
            dict: Resultado da execução ou None em caso de falha
        """
        # Inicializar operador se necessário
        if not self._operador_inicializado:
            if not await self.inicializar():
                logger.error("Não foi possível inicializar operador")
                return None
        
        # Validar sinal
        valido, motivo = await self.validar_sinal(sinal)
        if not valido:
            logger.warning(f"Sinal inválido: {motivo}")
            return None
        
        # Extrair parâmetros do sinal
        simbolo = sinal["simbolo"]
        lado = sinal["lado"]
        tipo = sinal["tipo"]
        quantidade = sinal.get("quantidade")
        preco = sinal.get("preco")
        
        # Se tiver valor mas não quantidade, calcular quantidade baseada no preço atual
        if not quantidade and "valor" in sinal and sinal["valor"]:
            try:
                preco_atual = await self.operador.obter_preco_atual(simbolo)
                if preco_atual:
                    quantidade = sinal["valor"] / preco_atual
                    logger.info(f"Calculando quantidade baseada no valor: {sinal['valor']} / {preco_atual} = {quantidade}")
            except Exception as e:
                logger.error(f"Erro ao calcular quantidade baseada no valor: {e}")
        
        # Filtrar apenas os parâmetros aceitos pela função criar_ordem
        # Parâmetros aceitos: simbolo, lado, tipo, quantidade, preco
        # Outros parâmetros específicos podem ser passados via kwargs, mas precisamos filtrar os conhecidos que causam erro
        kwargs = {}
        for k, v in sinal.items():
            # Excluir parâmetros já extraídos e parâmetros conhecidos que causam erro
            if k not in ["simbolo", "lado", "tipo", "quantidade", "preco", "valor", "timestamp", "estrategia", "motivo"]:
                kwargs[k] = v
        
        logger.debug(f"Parâmetros filtrados para criar_ordem: simbolo={simbolo}, lado={lado}, tipo={tipo}, quantidade={quantidade}, preco={preco}, kwargs={kwargs}")
        
        # Tentar executar ordem
        for tentativa in range(1, self.max_tentativas + 1):
            try:
                resultado = await self.operador.criar_ordem(
                    simbolo=simbolo,
                    lado=lado,
                    tipo=tipo,
                    quantidade=quantidade,
                    preco=preco,
                    **kwargs
                )
                
                if resultado:
                    logger.info(f"Sinal executado com sucesso: {resultado}")
                    
                    # Atualizar contexto
                    await self.atualizar_contexto(simbolo, {
                        "ultima_ordem": resultado,
                        "timestamp": time.time()
                    })
                    
                    return resultado
                else:
                    logger.warning(f"Falha ao executar sinal (tentativa {tentativa}/{self.max_tentativas})")
            except Exception as e:
                logger.error(f"Erro ao executar sinal (tentativa {tentativa}/{self.max_tentativas}): {e}")
            
            # Aguardar antes da próxima tentativa
            if tentativa < self.max_tentativas:
                await asyncio.sleep(self.delay_entre_tentativas)
        
        logger.error(f"Falha após {self.max_tentativas} tentativas")
        return None
    
    async def atualizar_contexto(self, simbolo, atualizacoes):
        """
        Atualiza o contexto para um símbolo.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            atualizacoes: Dicionário com atualizações
            
        Returns:
            dict: Contexto atualizado ou None em caso de falha
        """
        async with self._contexto_lock:
            try:
                # Obter contexto atual
                contexto = self._contexto_cache.get(simbolo)
                if contexto is None:
                    contexto = await self.obter_contexto(simbolo)
                    if contexto is None:
                        logger.error(f"Não foi possível obter contexto para {simbolo}")
                        return None
                
                # Atualizar contexto
                for chave, valor in atualizacoes.items():
                    contexto[chave] = valor
                
                # Armazenar no cache
                self._contexto_cache[simbolo] = contexto
                return contexto
            except Exception as e:
                logger.error(f"Erro ao atualizar contexto para {simbolo}: {e}")
                return None
    
    async def processar_sinais(self, sinais):
        """
        Processa múltiplos sinais de trading em paralelo.
        
        Args:
            sinais: Lista de sinais de trading
            
        Returns:
            list: Lista de resultados
        """
        if not sinais:
            return []
        
        # Inicializar operador se necessário
        if not self._operador_inicializado:
            if not await self.inicializar():
                logger.error("Não foi possível inicializar operador")
                return [None] * len(sinais)
        
        # Processar sinais em paralelo
        tarefas = [self.executar_sinal(sinal) for sinal in sinais]
        resultados = await asyncio.gather(*tarefas, return_exceptions=True)
        
        # Tratar exceções
        for i, resultado in enumerate(resultados):
            if isinstance(resultado, Exception):
                logger.error(f"Erro ao processar sinal {i}: {resultado}")
                resultados[i] = None
        
        return resultados
    
    async def fechar(self):
        """
        Fecha o executor e libera recursos.
        """
        try:
            if hasattr(self.operador, "fechar_cliente"):
                await self.operador.fechar_cliente()
            logger.info("Executor fechado com sucesso")
        except Exception as e:
            logger.error(f"Erro ao fechar executor: {e}")


# Alias para compatibilidade com código existente
ExecutorContextual = ExecutorContextualAsync


# Exemplo de uso
async def exemplo_uso():
    """
    Exemplo de uso do ExecutorContextual.
    """
    # Inicializar executor
    executor = ExecutorContextualAsync(config={
        "api_key": "sua_api_key",
        "api_secret": "seu_api_secret",
        "testnet": True
    })
    
    # Inicializar
    await executor.inicializar()
    
    try:
        # Obter contexto
        contexto = await executor.obter_contexto("BTCUSDT")
        print(f"Preço atual do BTC: {contexto['preco_atual']}")
        
        # Executar sinal
        sinal = {
            "simbolo": "BTCUSDT",
            "lado": "BUY",
            "tipo": "LIMIT",
            "quantidade": 0.001,
            "preco": contexto["preco_atual"] * 0.95
        }
        
        resultado = await executor.executar_sinal(sinal)
        print(f"Resultado da execução: {resultado}")
        
        # Processar múltiplos sinais
        sinais = [
            {
                "simbolo": "ETHUSDT",
                "lado": "BUY",
                "tipo": "MARKET",
                "quantidade": 0.01  # Quantidade calculada a partir do valor
            },
            {
                "simbolo": "BNBUSDT",
                "lado": "SELL",
                "tipo": "LIMIT",
                "quantidade": 0.1,
                "preco": 300
            }
        ]
        
        resultados = await executor.processar_sinais(sinais)
        print(f"Resultados: {resultados}")
    
    finally:
        # Fechar executor
        await executor.fechar()


# Executar exemplo se o script for executado diretamente
if __name__ == "__main__":
    import asyncio
    asyncio.run(exemplo_uso())
