#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# src/infrastructure/fallback.py

import os
import sys
import logging
import numpy as np
import psutil
import pickle
import asyncio
import time
import json  # Added for status file
import pybreaker
import aiobreaker # Added for async circuit breaker
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, Callable, Coroutine, Union

# Import TensorFlow and expose it as tf
try:
    import tensorflow as tf
    TF_AVAILABLE = True
    logger = logging.getLogger("kr_kripto_fallback") # Initialize logger after potential tf import
    logger.info("TensorFlow importado com sucesso como tf.")
except ImportError:
    tf = None # type: ignore
    TF_AVAILABLE = False
    logger = logging.getLogger("kr_kripto_fallback") # Initialize logger after potential tf import
    logger.warning("TensorFlow não pôde ser importado. Funcionalidades dependentes de TF não estarão disponíveis.")

# Importações dos módulos refatorados
from .fallback_listener import FallbackListener
from .fallback_utils import ModeloFallbackDecision
from .fallback_model_monitor import FallbackModelMonitor, KERAS_AVAILABLE # Importar KERAS_AVAILABLE daqui
from .fallback_task_watchdog import FallbackTaskWatchdog

# Configuração de logging (já inicializado acima, mas pode ser reconfigurado se necessário)
# logger = logging.getLogger("kr_kripto_fallback") # Movido para cima
logger.propagate = True

# Notifier e Prometheus são dependências opcionais, tratadas com stubs se ausentes.
try:
    from src.infrastructure.notifier import enviar_telegram
    NOTIFIER_AVAILABLE = True
except ImportError:
    NOTIFIER_AVAILABLE = False
    async def enviar_telegram(*args, **kwargs):  # Stub function
        logger.error("ERROR: Notifier module (enviar_telegram) not available in fallback.py.")
        if args:
            logger.info(f"[TELEGRAM STUB fallback.py] {args[0]}")

try:
    from src.monitoring.prometheus_exporter import fallback_metric as FALLBACK_ACTIVATIONS_TOTAL
    PROMETHEUS_AVAILABLE = True
    logger.info("Prometheus exporter and fallback_metric (FALLBACK_ACTIVATIONS_TOTAL) loaded in fallback.py.")
except ImportError:
    PROMETHEUS_AVAILABLE = False
    class MockCounter:
        def __init__(self, config: dict):
            self._name = config.get('name', 'unnamed_counter')
            logger.warning(f"MockCounter {self._name} initialized in fallback.py.")
        def inc(self, *args, **kwargs):
            logger.warning(f"MockCounter {self._name} .inc() called in fallback.py with args: {args}, kwargs: {kwargs}")
            pass
    FALLBACK_ACTIVATIONS_TOTAL = MockCounter(config={'name': "fallback_activations_total_fallback_stub"})
    logger.warning("WARNING: Prometheus exporter or FALLBACK_ACTIVATIONS_TOTAL not available in fallback.py. Using stub.")

class GerenciadorFallback:
    def __init__(self, config: dict, operador_binance=None, loop=None):
        self.config = config
        self.operador_binance = operador_binance
        self.loop = loop or asyncio.get_event_loop()

        self.modelos_fallback = {}
        self.ultima_verificacao_recursos = datetime.now() - timedelta(seconds=config.get("RESOURCE_CHECK_INTERVAL_SECONDS", 300) + 1)
        self.diretorio_fallback = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".fallback_cache")
        
        self.main_model_path = os.path.abspath(config.get("MAIN_MODEL_PATH", os.path.join(os.path.dirname(__file__), "..", "..", "models", "modelo_transformer_futuro.h5")))
        self.current_main_model: Optional[Any] = None 
        self.last_model_mtime: float = 0.0 
        self._model_load_lock = asyncio.Lock() 

        self.listener = FallbackListener(config={}, loop=self.loop)
        status_file_config_path = self.config.get("FALLBACK_STATUS_FILE_PATH")
        if status_file_config_path:
            self.listener.status_file_path = os.path.abspath(status_file_config_path)
        else:
            logger.info(f"FALLBACK_STATUS_FILE_PATH não configurado, listener usará o caminho padrão: {self.listener.status_file_path}")

        self.model_breaker = pybreaker.CircuitBreaker(fail_max=int(config.get("MODEL_BREAKER_FAIL_MAX", 2)), reset_timeout=int(config.get("MODEL_BREAKER_RESET_TIMEOUT", 300)), name="model_loading", listeners=[self.listener])
        self.ws_breaker = aiobreaker.CircuitBreaker(fail_max=int(config.get("WS_BREAKER_FAIL_MAX", 3)), timeout_duration=timedelta(seconds=int(config.get("WS_BREAKER_RESET_TIMEOUT", 60))), name="websocket", listeners=[self.listener])
        self.signal_breaker = pybreaker.CircuitBreaker(fail_max=int(config.get("SIGNAL_BREAKER_FAIL_MAX", 3)), reset_timeout=int(config.get("SIGNAL_BREAKER_RESET_TIMEOUT", 60)), name="signal_processing", listeners=[self.listener])
        self.binance_breaker = pybreaker.CircuitBreaker(fail_max=int(config.get("BINANCE_API_BREAKER_FAIL_MAX", 5)), reset_timeout=int(config.get("BINANCE_API_BREAKER_RESET_TIMEOUT", 120)), name="binance_api", listeners=[self.listener])

        self.model_monitor = FallbackModelMonitor(config={}, manager=self) 
        
        # Configurações para o TaskWatchdog
        max_failures_default = int(config.get("MAX_TASK_FAILURES", 3))
        failure_window_seconds = int(config.get("TASK_FAILURE_WINDOW_SECONDS", 3600))
        self._max_failures_config_internal: Dict[str, int] = config.get("TASK_MAX_FAILURES_OVERRIDES", {}) # Permitir overrides da config
        task_timeout_default = float(config.get("TASK_TIMEOUT_DEFAULT_SECONDS", 60.0))

        self.task_watchdog = FallbackTaskWatchdog(self, 
                                                  max_failures_default=max_failures_default,
                                                  failure_window=failure_window_seconds,
                                                  max_failures_config=self._max_failures_config_internal,
                                                  task_timeout_default_seconds=task_timeout_default)
        
        logger.info("GerenciadorFallback inicializado com circuit breakers, listener, model monitor e task watchdog.")
        os.makedirs(self.diretorio_fallback, exist_ok=True)
        self.setup_fallback_models()

    def setup_fallback_models(self):
        self.inicializar_fallbacks()

    async def start_model_monitoring(self, check_interval: float = 60.0):
        await self.model_monitor.start(check_interval=check_interval)

    async def stop_model_monitoring(self):
        await self.model_monitor.stop()

    def get_main_model(self) -> Any:
        if self.current_main_model is None:
            # Acessa _model_loader_task através da propriedade para compatibilidade
            if not (self._model_loader_task and not self._model_loader_task.done()):
                logger.info("Modelo principal não carregado e monitor não ativo. Tentando carregar agora (síncrono no get_main_model - pode bloquear)...")
                if self.loop and not self.loop.is_closed(): 
                    asyncio.ensure_future(self.model_monitor.load_main_model_with_breaker(), loop=self.loop)
            else:
                logger.debug("Modelo principal não carregado, mas o monitor está ativo e tentará carregar.")
        return self.current_main_model

    async def load_main_model_with_breaker(self) -> Any: 
        return await self.model_monitor.load_main_model_with_breaker()

    # Placeholder for tests expecting _load_main_model_with_breaker
    async def _load_main_model_with_breaker(self) -> Any:
        logger.warning("GerenciadorFallback._load_main_model_with_breaker (com underscore) foi chamado. Delegando para load_main_model_with_breaker (sem underscore).")
        return await self.load_main_model_with_breaker()

    # Propriedade para expor _model_loader_task do model_monitor
    @property
    def _model_loader_task(self) -> Optional[asyncio.Task]:
        # Delega o acesso ao _model_loader_task do model_monitor
        # Adicionado para compatibilidade com testes que esperam este atributo no GerenciadorFallback
        if hasattr(self.model_monitor, "_model_loader_task"):
            return self.model_monitor._model_loader_task
        return None

    # Métodos para compatibilidade com testes que acessavam atributos do watchdog diretamente
    def get_max_failures_for_task(self, task_name: str) -> int:
        return self.task_watchdog.get_max_failures_for_task(task_name)

    @property
    def failure_window(self) -> int:
        return self.task_watchdog.failure_window

    @failure_window.setter
    def failure_window(self, value: int):
        self.task_watchdog.failure_window = value
        logger.warning(f"fallback.py: failure_window foi alterado para {value} diretamente. Isso é geralmente para testes.")

    @property
    def max_failures_config(self) -> Dict[str, int]:
        return self.task_watchdog.max_failures_config

    @max_failures_config.setter
    def max_failures_config(self, value: Dict[str, int]):
        self.task_watchdog.max_failures_config = value
        logger.warning(f"fallback.py: max_failures_config foi alterado diretamente. Isso é geralmente para testes.")

    @property
    def max_failures_default(self) -> int:
        return self.task_watchdog.max_failures_default

    @max_failures_default.setter
    def max_failures_default(self, value: int):
        self.task_watchdog.max_failures_default = value
        logger.warning(f"fallback.py: max_failures_default foi alterado para {value} diretamente. Isso é geralmente para testes.")

    def registrar_tarefa(self, task_name: str, task: asyncio.Task, restart_func: Optional[Callable[[], Coroutine[Any, Any, Any]]] = None, max_failures_override: Optional[int] = None, critical: bool = False, restart_delay_seconds: int = 5, task_timeout_seconds_override: Optional[float] = None):
        self.task_watchdog.registrar_tarefa(task_name, task, restart_func, max_failures_override, critical, restart_delay_seconds, task_timeout_seconds_override=task_timeout_seconds_override)

    def remover_tarefa(self, task_name: str):
        self.task_watchdog.remover_tarefa(task_name)

    def atualizar_heartbeat_tarefa(self, task_name: str):
        self.task_watchdog.atualizar_heartbeat_tarefa(task_name)

    # Alias for test compatibility
    def update_heartbeat(self, task_name: str):
        self.atualizar_heartbeat_tarefa(task_name)

    async def iniciar_watchdog_tarefas(self, check_interval: Optional[float] = None, task_timeout: Optional[float] = None):
        if check_interval is not None:
            # Este log pode ser removido ou ajustado se o check_interval for usado pelo TaskWatchdog.start()
            logger.info(f"fallback.py: iniciar_watchdog_tarefas chamado com check_interval={check_interval}. O TaskWatchdog usa seu próprio intervalo de config.")
        # O task_timeout global não é mais usado aqui, é por tarefa ou default do watchdog.
        await self.task_watchdog.start(check_interval_override=check_interval)

    # Método adicionado para compatibilidade com testes
    async def iniciar_watchdog(self, intervalo: Optional[float] = None, check_interval: Optional[float] = None, task_timeout: Optional[float] = None):
        """Alias para iniciar_watchdog_tarefas para compatibilidade com testes, aceitando 'intervalo' como 'check_interval'."""
        logger.info("GerenciadorFallback.iniciar_watchdog chamado (alias para iniciar_watchdog_tarefas).")
        actual_check_interval = check_interval if check_interval is not None else intervalo
        # O task_timeout é passado, mas o iniciar_watchdog_tarefas atualmente não o utiliza diretamente para o start do watchdog.
        # O watchdog usa o task_timeout_default_seconds ou overrides por tarefa.
        await self.iniciar_watchdog_tarefas(check_interval=actual_check_interval, task_timeout=task_timeout)

    async def parar_watchdog_tarefas(self):
        await self.task_watchdog.stop()

    # Método adicionado para compatibilidade com testes
    async def parar_watchdog(self):
        """Alias para parar_watchdog_tarefas para compatibilidade com testes."""
        logger.info("GerenciadorFallback.parar_watchdog chamado (alias para parar_watchdog_tarefas).")
        await self.parar_watchdog_tarefas()

    async def start_watchdog(self, intervalo: Optional[float] = None, check_interval: Optional[float] = None, task_timeout: Optional[float] = None):
        """Alias para iniciar_watchdog para compatibilidade com testes e código legado que chama start_watchdog()."""
        logger.info("GerenciadorFallback.start_watchdog chamado (delegando para self.iniciar_watchdog).")
        # self.iniciar_watchdog já lida com a lógica de 'intervalo' vs 'check_interval'
        await self.iniciar_watchdog(intervalo=intervalo, check_interval=check_interval, task_timeout=task_timeout)

    async def stop_watchdog(self):
        """Alias para parar_watchdog para compatibilidade com testes e código legado que chama stop_watchdog()."""
        logger.info("GerenciadorFallback.stop_watchdog chamado (delegando para self.parar_watchdog).")
        await self.parar_watchdog()

    # Alias for test compatibility
    async def monitorar_e_recarregar_modelo_principal(self, intervalo_verificacao: float = 60.0):
        logger.warning("GerenciadorFallback.monitorar_e_recarregar_modelo_principal chamado. Delegando para start_model_monitoring.")
        await self.start_model_monitoring(check_interval=intervalo_verificacao)

    # Alias for test compatibility
    async def start_model_loader(self, intervalo_verificacao: float = 60.0):
        logger.warning("GerenciadorFallback.start_model_loader chamado. Delegando para start_model_monitoring.")
        await self.start_model_monitoring(check_interval=intervalo_verificacao)

    def inicializar_fallbacks(self):
        self.modelos_fallback = {"default": ModeloFallbackDecision()} 
        if not os.path.exists(self.diretorio_fallback):
            os.makedirs(self.diretorio_fallback)
        for filename in os.listdir(self.diretorio_fallback):
            if filename.endswith(".pkl"):
                model_name = filename[:-4]
                try:
                    with open(os.path.join(self.diretorio_fallback, filename), "rb") as f:
                        self.modelos_fallback[model_name] = pickle.load(f)
                except Exception as e:
                    logger.error(f"Falha ao carregar modelo de fallback {filename}: {e}")

    def obter_modelo_fallback(self, nome_modelo: Optional[str] = None) -> Any:
        return self.modelos_fallback.get(nome_modelo) or self.modelos_fallback.get("default")

    async def call_with_breaker_async(self, breaker: Union[pybreaker.CircuitBreaker, aiobreaker.CircuitBreaker], func: Callable[..., Coroutine[Any, Any, Any]], *args: Any, **kwargs: Any) -> Any:
        breaker_name = breaker.name if hasattr(breaker, "name") else "UnnamedBreaker"
        if isinstance(breaker, aiobreaker.CircuitBreaker):
            try:
                return await breaker.call_async(func, *args, **kwargs)
            except aiobreaker.CircuitBreakerError as e:
                logger.warning(f"AIOBreaker {breaker_name} está {breaker.current_state}. Chamada para {func.__name__} falhou: {e}")
                raise
        elif isinstance(breaker, pybreaker.CircuitBreaker):
            if breaker.current_state == pybreaker.STATE_OPEN:
                error_msg = f"CircuitBreakerError: Circuit {breaker_name} is OPEN."
                logger.warning(error_msg)
                for listener_obj in breaker.listeners:
                    if hasattr(listener_obj, "failure"):
                        listener_obj.failure(breaker, pybreaker.CircuitBreakerError(error_msg))
                raise pybreaker.CircuitBreakerError(error_msg)
            try:
                for listener_obj in breaker.listeners:
                    if hasattr(listener_obj, "before_call"):
                        listener_obj.before_call(breaker, func, *args, **kwargs)
                
                result = await func(*args, **kwargs)
                
                for listener_obj in breaker.listeners:
                    if hasattr(listener_obj, "success"):
                        listener_obj.success(breaker, func, *args, **kwargs)
                
                return result
            except Exception as e:
                for listener_obj in breaker.listeners:
                    if hasattr(listener_obj, "failure"):
                        listener_obj.failure(breaker, e)
                
                if breaker.fail_counter >= breaker.fail_max:
                    breaker._last_failure = datetime.now()
                    breaker._state = pybreaker.STATE_OPEN
                    logger.warning(f"Circuit {breaker_name} is now OPEN due to {breaker.fail_counter} failures.")
                
                raise
        else:
            logger.error(f"Tipo de breaker não suportado: {type(breaker)}")
            return await func(*args, **kwargs)  # Fallback para execução direta
