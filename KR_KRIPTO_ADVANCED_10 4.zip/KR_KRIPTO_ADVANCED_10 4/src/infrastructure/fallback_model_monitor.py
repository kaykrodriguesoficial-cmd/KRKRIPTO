# src/infrastructure/fallback_model_monitor.py
import os
import asyncio
import logging
from typing import Optional, Any, Callable, Coroutine, TYPE_CHECKING
import pybreaker # Adicionado para referenciar CircuitBreakerError diretamente

if TYPE_CHECKING:
    from .fallback import GerenciadorFallback # Evitar import circular em runtime

logger = logging.getLogger("kr_kripto_fallback.model_monitor")

try:
    import tensorflow as tf
    KERAS_AVAILABLE = True
except ImportError:
    KERAS_AVAILABLE = False
    tf = None

class FallbackModelMonitor:
    def __init__(self, config: dict, manager=None):
        self.manager = manager
        self._model_load_lock = asyncio.Lock()
        self._model_loader_task: Optional[asyncio.Task] = None
        self._stop_event = asyncio.Event() # Evento para parar o monitor

    async def _internal_load_main_model_logic(self) -> Any:
        async with self._model_load_lock:
            current_model_path = self.manager.main_model_path
            logger.info(f"[ModelMonitor] Tentando carregar modelo principal: {current_model_path}")
            if not os.path.exists(current_model_path):
                logger.error(f"[ModelMonitor] Arquivo do modelo principal não encontrado: {current_model_path}")
                self.manager.current_main_model = None
                self.manager.last_model_mtime = 0
                raise FileNotFoundError(f"Modelo principal {current_model_path} não encontrado.")
            try:
                if not KERAS_AVAILABLE or not tf:
                    logger.error("[ModelMonitor] TensorFlow/Keras não está disponível. Não é possível carregar o modelo .h5.")
                    self.manager.current_main_model = None
                    self.manager.last_model_mtime = 0
                    raise ImportError("TensorFlow/Keras não disponível para carregar modelo.")
                
                if current_model_path.endswith(".h5"):
                    logger.info(f"[ModelMonitor] Carregando modelo Keras (.h5) {current_model_path} com compile=False.")
                    loaded_model = tf.keras.models.load_model(current_model_path, compile=False)
                else:
                    logger.info(f"[ModelMonitor] Carregando modelo {current_model_path} (não .h5 ou tipo não especificado para compile=False).")
                    loaded_model = tf.keras.models.load_model(current_model_path)

                if loaded_model is None:
                    logger.error(f"[ModelMonitor] tf.keras.models.load_model retornou None para {current_model_path}")
                    self.manager.current_main_model = None
                    self.manager.last_model_mtime = 0
                    raise ValueError(f"Falha ao carregar modelo {current_model_path}, load_model retornou None.")
                
                self.manager.current_main_model = loaded_model
                self.manager.last_model_mtime = os.path.getmtime(current_model_path)
                logger.info(f"[ModelMonitor] Modelo principal {current_model_path} carregado com sucesso e atualizado no GerenciadorFallback.")
                return loaded_model
            except Exception as e:
                logger.error(f"[ModelMonitor] Falha ao carregar modelo principal {current_model_path}: {e!r}", exc_info=True)
                self.manager.current_main_model = None
                self.manager.last_model_mtime = 0
                raise

    async def load_main_model_with_breaker(self) -> Any:
        logger.info("[ModelMonitor] load_main_model_with_breaker chamado.")
        try:
            loaded_model = await self.manager.call_with_breaker_async(self.manager.model_breaker, self._internal_load_main_model_logic)
            return loaded_model
        except pybreaker.CircuitBreakerError: 
            logger.warning(f"[ModelMonitor] Circuit breaker {self.manager.model_breaker.name} está aberto. Falha ao carregar modelo principal.")
            self.manager.current_main_model = None
            self.manager.last_model_mtime = 0
            # Não levanta a exceção do breaker, apenas retorna None, pois o breaker já notificou
            return None 
        except Exception as e:
            logger.error(f"[ModelMonitor] Exceção não esperada ({type(e).__name__}) em load_main_model_with_breaker: {e!r}", exc_info=True)
            self.manager.current_main_model = None
            self.manager.last_model_mtime = 0
            raise # Re-levanta a exceção para que o chamador (teste) possa pegá-la

    async def monitor_and_reload_model(self, check_interval: float = 60.0):
        logger.info(f"[ModelMonitor] Monitor de modelo principal iniciado. Verificando {self.manager.main_model_path} a cada {check_interval}s.")
        while not self._stop_event.is_set():
            await asyncio.sleep(check_interval)
            if self._stop_event.is_set(): break
            try:
                current_model_path_to_check = self.manager.main_model_path
                if not os.path.exists(current_model_path_to_check):
                    if self.manager.current_main_model is not None:
                        logger.warning(f"[ModelMonitor] Arquivo do modelo principal {current_model_path_to_check} não existe mais. Descarregando modelo.")
                        self.manager.current_main_model = None
                        self.manager.last_model_mtime = 0
                    continue
                current_mtime = os.path.getmtime(current_model_path_to_check)
                if current_mtime != self.manager.last_model_mtime:
                    logger.info(f"[ModelMonitor] Alteração detectada no arquivo do modelo principal {current_model_path_to_check}. Recarregando...")
                    await self.load_main_model_with_breaker() # Esta chamada pode levantar exceção se o carregamento falhar
            except Exception as e:
                # Se load_main_model_with_breaker levantar uma exceção (que não seja CircuitBreakerError já tratada), ela será pega aqui.
                logger.error(f"[ModelMonitor] Erro durante o monitoramento do modelo principal (ciclo de recarga): {e!r}", exc_info=True)
        logger.info("[ModelMonitor] Monitor de modelo principal terminado.")

    async def start(self, check_interval: float = 60.0):
        if self._model_loader_task and not self._model_loader_task.done():
            logger.info("[ModelMonitor] Model loader já está em execução.")
            return
        
        self._stop_event.clear()

        if self.manager.current_main_model is None:
             logger.info("[ModelMonitor] Tentando carregamento inicial do modelo via start...")
             if self.manager.loop and not self.manager.loop.is_closed():
                try:
                    await self.load_main_model_with_breaker()
                except Exception as e: # Pega exceções do carregamento inicial para não quebrar o start
                    logger.error(f"[ModelMonitor] Falha no carregamento inicial do modelo durante o start: {e!r}", exc_info=True)
        
        if self.manager.loop and not self.manager.loop.is_closed():
            self._model_loader_task = self.manager.loop.create_task(self.monitor_and_reload_model(check_interval))
            logger.info("[ModelMonitor] Model loader task created and started.")

    async def stop(self):
        self._stop_event.set()
        if self._model_loader_task and not self._model_loader_task.done():
            self._model_loader_task.cancel()
            try:
                await self._model_loader_task
            except asyncio.CancelledError:
                logger.info("[ModelMonitor] Model loader task cancelled.")
            except Exception as e:
                 logger.error(f"[ModelMonitor] Exceção ao aguardar _model_loader_task cancelada: {e!r}", exc_info=True)
        self._model_loader_task = None
        logger.info("[ModelMonitor] Model loader task stopped/cleared.")

    def get_model(self) -> Any:
        return self.manager.current_main_model

