# src/infrastructure/fallback_task_watchdog.py
import asyncio
import logging
import time
import inspect # Added for checking coroutine functions
from typing import Dict, Any, Optional, Callable, Coroutine, TYPE_CHECKING
from datetime import datetime, timedelta

if TYPE_CHECKING:
    from .fallback import GerenciadorFallback # Evitar import circular em runtime

logger = logging.getLogger("kr_kripto_fallback") # Consistent logger name

class FallbackTaskWatchdog:
    def __init__(self, manager: "GerenciadorFallback", 
                 max_failures_default: int,
                 failure_window: int,
                 max_failures_config: Dict[str, int],
                 task_timeout_default_seconds: float):
        self.manager = manager
        self.tracked_tasks: Dict[str, Dict[str, Any]] = {}
        self._watchdog_task_obj: Optional[asyncio.Task] = None
        self._stop_watchdog_event = asyncio.Event()
        self._watchdog_check_interval = manager.config.get("WATCHDOG_CHECK_INTERVAL_SECONDS", 5.0)
        
        self.max_failures_default = max_failures_default
        self.failure_window = failure_window
        self.max_failures_config = max_failures_config # Dict to override max_failures_default per task
        self.task_timeout_default_seconds = task_timeout_default_seconds

    def get_max_failures_for_task(self, task_name: str) -> int:
        return self.max_failures_config.get(task_name, self.max_failures_default)

    def registrar_tarefa(
        self,
        task_name: str,
        task_obj: asyncio.Task,
        restart_func: Optional[Callable[[], Coroutine[Any, Any, Any]]] = None,
        max_failures_override: Optional[int] = None,
        critical: bool = False,
        restart_delay_seconds: int = 5,
        initial_failure_count: int = 0, # To carry over state on restart
        failure_timestamps: Optional[list] = None, # To carry over state on restart
        task_timeout_seconds_override: Optional[float] = None
    ):
        if task_name in self.tracked_tasks:
            logger.warning(f"Watchdog: Tarefa {task_name} já está sendo monitorada. Substituindo.")
            old_task_info = self.tracked_tasks.get(task_name)
            if old_task_info and old_task_info.get("task_obj") and not old_task_info['task_obj'].done():
                try:
                    old_task_info['task_obj'].cancel()
                except Exception as e_cancel:
                    logger.error(f"Watchdog: Erro ao cancelar tarefa antiga {task_name}: {e_cancel}")
        
        effective_max_failures = max_failures_override if max_failures_override is not None else self.get_max_failures_for_task(task_name)
        effective_task_timeout = task_timeout_seconds_override if task_timeout_seconds_override is not None else self.task_timeout_default_seconds
        
        current_failure_count = initial_failure_count
        current_failure_timestamps = failure_timestamps if failure_timestamps is not None else []

        self.tracked_tasks[task_name] = {
            "task_obj": task_obj,
            "restart_func": restart_func,
            "max_failures": effective_max_failures, 
            "failure_count": current_failure_count, 
            "failure_timestamps": current_failure_timestamps,
            "status": "running",
            "last_heartbeat": datetime.now(),
            "task_timeout_seconds": effective_task_timeout,
            "critical": critical,
            "restart_delay_seconds": restart_delay_seconds,
            "_marked_for_timeout": False
        }
        logger.info(f"Watchdog: Tarefa {task_name} registrada com max_failures={effective_max_failures}, timeout={effective_task_timeout}s, initial_failure_count={current_failure_count}.")
        
        # Correção: Verificar se o loop está disponível e não fechado antes de adicionar o callback
        if self.manager.loop and not self.manager.loop.is_closed():
            def done_callback_wrapper(task_name_captured: str, t: asyncio.Task):
                if self.manager.loop and not self.manager.loop.is_closed():
                    try:
                        self.manager.loop.create_task(self._handle_task_completion(task_name_captured, t))
                    except RuntimeError as e:
                        logger.warning(f"Watchdog: Erro ao agendar _handle_task_completion para {task_name_captured}: {e}")
                else:
                    logger.warning(f"Watchdog: Loop fechado, não é possível agendar _handle_task_completion para {task_name_captured}")

            task_obj.add_done_callback(lambda t: done_callback_wrapper(task_name, t))
        else:
            logger.warning(f"Watchdog: Loop não disponível ou fechado ao registrar tarefa {task_name}, callback não adicionado")


    def atualizar_heartbeat_tarefa(self, task_name: str):
        if task_name in self.tracked_tasks:
            self.tracked_tasks[task_name]['last_heartbeat'] = datetime.now()
            logger.debug(f"Watchdog: Heartbeat atualizado para tarefa {task_name}.")
        else:
            logger.warning(f"Watchdog: Tentativa de atualizar heartbeat para tarefa não rastreada: {task_name}")

    async def _handle_task_completion(self, task_name: str, task: asyncio.Task):
        logger.info(f"Watchdog_DEBUG: Entered _handle_task_completion for {task_name}.")
        if task_name not in self.tracked_tasks:
            logger.warning(f"Watchdog: Tarefa {task_name} não encontrada no rastreamento ao lidar com conclusão.")
            return

        task_info = self.tracked_tasks[task_name]
        try:
            task.result()  
            logger.info(f"Watchdog: Tarefa {task_name} concluída normalmente.") 
            task_info['status'] = "completed"
        except asyncio.CancelledError:
            if task_info.get("_marked_for_timeout", False):
                logger.warning(f"Watchdog: Tarefa {task_name} foi cancelada (asyncio.exceptions.TimeoutError). Isso é tratado como uma falha para fins de reinício.")
                logger.info(f"Watchdog_DEBUG: Timeout detected for {task_name}. Calling _handle_task_exception.")
                task_info['status'] = "failed_timeout"
                await self._handle_task_exception(task_name, asyncio.TimeoutError("Heartbeat timeout"))
            else:
                logger.info(f"Watchdog: Tarefa {task_name} foi cancelada externamente.")
                task_info['status'] = "cancelled"
        except Exception as e:
            logger.error(f"Watchdog: Tarefa {task_name} falhou com {type(e).__name__}: {e}.", exc_info=False) 
            logger.info(f"Watchdog_DEBUG: Exception detected for {task_name}. Calling _handle_task_exception.")
            task_info['status'] = "failed"
            await self._handle_task_exception(task_name, e)
        finally:
            task_info.pop("_marked_for_timeout", None)

    async def _handle_task_exception(self, task_name: str, exception: Exception):
        logger.info(f"Watchdog_DEBUG: Entered _handle_task_exception for {task_name} due to {type(exception).__name__}.")
        if task_name not in self.tracked_tasks:
            logger.warning(f"Watchdog_DEBUG: Task {task_name} not in tracked_tasks in _handle_task_exception. Returning.")
            return

        task_info = self.tracked_tasks[task_name]
        now = datetime.now()
        
        task_info['failure_timestamps'].append(now)
        task_info['failure_timestamps'] = [
            t for t in task_info['failure_timestamps'] 
            if now - t < timedelta(seconds=self.failure_window)
        ]
        task_info['failure_count'] = len(task_info['failure_timestamps'])

        exc_name = type(exception).__name__
        max_failures_for_this_task = task_info['max_failures']
        current_failure_count_in_window = task_info['failure_count']

        logger.info(f"Watchdog_DEBUG: {task_name} - failure_count_in_window: {current_failure_count_in_window}, max_failures: {max_failures_for_this_task}.")

        logger.warning(f"Watchdog: Falha na tarefa {task_name} ({exc_name}). Contagem de falhas na janela: {current_failure_count_in_window}/{max_failures_for_this_task}.")

        if current_failure_count_in_window > max_failures_for_this_task:
            logger.error(f"Watchdog_DEBUG: {task_name} EXCEEDED max failures. Current: {current_failure_count_in_window}, Max: {max_failures_for_this_task}. PREPARING TO RETURN AND NOT RESTART.") # Log de depuração adicionado
            logger.error(f"Watchdog_DEBUG: {task_name} exceeded max failures ({current_failure_count_in_window} > {max_failures_for_this_task}). Not restarting.")
            logger.error(f"Watchdog: Tarefa {task_name} falhou ({exc_name}) e atingiu o limite de reinícios ({max_failures_for_this_task}/{max_failures_for_this_task}) ou não possui função de reinício. Não será reiniciada.")
            task_info['status'] = "permanently_failed"
            if task_info.get("critical", False):
                logger.critical(f"Watchdog: TAREFA CRÍTICA {task_name} FALHOU PERMANENTEMENTE. O sistema pode estar instável.")
            if hasattr(self.manager, "NOTIFIER_AVAILABLE") and self.manager.NOTIFIER_AVAILABLE:
                 if hasattr(self.manager, "enviar_telegram") and callable(self.manager.enviar_telegram):
                    await self.manager.enviar_telegram(f"CRÍTICO Watchdog: Tarefa {task_name} ({exc_name}) falhou permanentemente e foi desativada.")
            return

        if task_info['restart_func']:
            logger.info(f"Watchdog_DEBUG: {task_name} has a restart_func. Proceeding to restart. current_failure_count_in_window: {current_failure_count_in_window}")
            logger.info(f"Watchdog: Tarefa {task_name} falhou ({exc_name}). Tentando reiniciar (tentativa {current_failure_count_in_window}/{max_failures_for_this_task})...")
            delay = task_info.get("restart_delay_seconds", 5)
            await asyncio.sleep(delay)
            try:
                logger.info(f"Watchdog_DEBUG: {task_name} - About to call restart_func.")
                # Correção: Verificar se o loop está disponível e não fechado antes de chamar restart_func
                if not self.manager.loop or self.manager.loop.is_closed():
                    logger.error(f"Watchdog: Loop não disponível ou fechado ao tentar reiniciar tarefa {task_name}")
                    task_info['status'] = "failed_no_restart_loop_closed"
                    return

                # Chamamos a factory UMA VEZ para obter a corotina.
                potential_coro = task_info['restart_func']()
                logger.info(f"Watchdog_DEBUG: {task_name} - restart_func called, result type: {type(potential_coro)}.")

                if not asyncio.iscoroutine(potential_coro):
                    logger.error(f"Watchdog: restart_func for {task_name} did not return a coroutine. Got {type(potential_coro)}. Cannot restart.")
                    task_info['status'] = "failed_no_restart_bad_coro_type"
                    return

                coro_to_schedule = potential_coro

                # Correção: Usar try/except para capturar erros ao criar a tarefa
                try:
                    new_task_obj = self.manager.loop.create_task(coro_to_schedule)
                except RuntimeError as e:
                    logger.error(f"Watchdog: Erro ao criar tarefa para {task_name}: {e}")
                    task_info['status'] = "failed_no_restart_task_creation_error"
                    return
                
                self.registrar_tarefa(
                    task_name,
                    new_task_obj,
                    task_info['restart_func'], 
                    max_failures_override=max_failures_for_this_task, 
                    critical=task_info['critical'],
                    restart_delay_seconds=task_info['restart_delay_seconds'],
                    initial_failure_count=current_failure_count_in_window, 
                    failure_timestamps=list(task_info['failure_timestamps']),
                    task_timeout_seconds_override=task_info['task_timeout_seconds']
                )
                logger.info(f"Watchdog: Tarefa {task_name} reiniciada com sucesso. Failure count for '{task_name}' is now {current_failure_count_in_window}.")
            except Exception as e_restart:
                logger.error(f"Watchdog: Falha ao tentar reiniciar a tarefa {task_name}: {e_restart}", exc_info=True)
                task_info['status'] = "failed_restart_exception" 
        else:
            logger.warning(f"Watchdog: Tarefa {task_name} ({exc_name}) falhou mas não possui função de reinício. Não será reiniciada.")
            task_info['status'] = "failed_no_restart"

    async def _task_watchdog_loop(self, effective_check_interval: float):
        logger.info(f"Watchdog: Loop do watchdog de tarefas iniciado. Verificando a cada {effective_check_interval}s.")
        while not self._stop_watchdog_event.is_set():
            try:
                now = datetime.now()
                for task_name, task_info in list(self.tracked_tasks.items()): 
                    task_obj = task_info.get("task_obj")
                    if not task_obj or task_obj.done():
                        if task_info['status'] not in ["completed", "cancelled", "failed", "failed_timeout", "permanently_failed", "failed_no_restart", "failed_restart_exception", "failed_no_restart_bad_async_func_type", "failed_no_restart_bad_final_coro", "failed_no_restart_loop_closed", "failed_no_restart_task_creation_error"]:
                            logger.warning(f"Watchdog_LOOP: Tarefa {task_name} está DONE (status: {task_info['status']}). Forçando _handle_task_completion.")
                            if task_obj: 
                                # Correção: Usar try/except para capturar erros ao chamar _handle_task_completion
                                try:
                                    await self._handle_task_completion(task_name, task_obj)
                                except Exception as e:
                                    logger.error(f"Watchdog: Erro ao chamar _handle_task_completion para {task_name}: {e}")
                        continue 

                    task_timeout_val = task_info['task_timeout_seconds']
                    if (now - task_info['last_heartbeat']).total_seconds() > task_timeout_val:
                        if not task_info.get("_marked_for_timeout", False): 
                            logger.warning(f"Watchdog: Tarefa {task_name} excedeu o timeout de heartbeat ({task_timeout_val}s). Cancelando e tratando como falha...")
                            task_info["_marked_for_timeout"] = True 
                            task_obj.cancel()
            except asyncio.CancelledError:
                logger.info("Watchdog: Loop do watchdog de tarefas cancelado.")
                break
            except Exception as e:
                logger.error(f"Watchdog: Erro inesperado no loop do watchdog de tarefas: {e}", exc_info=True)
            
            try:
                await asyncio.wait_for(self._stop_watchdog_event.wait(), timeout=effective_check_interval)
            except asyncio.TimeoutError:
                pass 
            except asyncio.CancelledError: 
                logger.info("Watchdog: Loop do watchdog (wait_for) cancelado.")
                break

        logger.info("Watchdog: Loop do watchdog de tarefas terminado.")

    async def start(self, check_interval_override: Optional[float] = None):
        if self._watchdog_task_obj and not self._watchdog_task_obj.done():
            logger.info("Watchdog: Watchdog de tarefas já está em execução.")
            return
        self._stop_watchdog_event.clear()
        
        effective_check_interval = check_interval_override if check_interval_override is not None else self._watchdog_check_interval
        logger.info(f"Watchdog: Iniciando com intervalo de checagem: {effective_check_interval}s.")

        # Correção: Verificar se o loop está disponível e não fechado antes de criar a tarefa
        if self.manager.loop and not self.manager.loop.is_closed():
            try:
                self._watchdog_task_obj = self.manager.loop.create_task(self._task_watchdog_loop(effective_check_interval=effective_check_interval))
                logger.info("Watchdog: Watchdog de tarefas iniciado.")
            except RuntimeError as e:
                logger.error(f"Watchdog: Erro ao criar tarefa do watchdog: {e}")
        else:
            logger.error("Watchdog: Loop do asyncio não disponível ou fechado. Watchdog não pode iniciar.")

    async def stop(self):
        logger.info("Watchdog: Solicitando parada do watchdog de tarefas...")
        self._stop_watchdog_event.set()
        if self._watchdog_task_obj and not self._watchdog_task_obj.done():
            try:
                # Correção: Usar try/except para capturar erros ao aguardar a tarefa
                try:
                    await asyncio.wait_for(self._watchdog_task_obj, timeout=self._watchdog_check_interval * 2)
                except asyncio.TimeoutError:
                    logger.warning("Watchdog: Timeout ao aguardar parada do watchdog task object. Cancelando forçadamente.")
                    self._watchdog_task_obj.cancel()
                    try:
                        await self._watchdog_task_obj
                    except asyncio.CancelledError:
                        logger.info("Watchdog: Watchdog de tarefas cancelado com sucesso durante stop.")
                    except Exception as e:
                        logger.error(f"Watchdog: Erro ao aguardar cancelamento do watchdog: {e}")
            except asyncio.CancelledError:
                logger.info("Watchdog: Watchdog de tarefas (task object) cancelado com sucesso durante stop.")
            except Exception as e:
                logger.error(f"Watchdog: Erro ao parar watchdog: {e}")
        
        logger.info("Watchdog: Watchdog de tarefas efetivamente parado.")
