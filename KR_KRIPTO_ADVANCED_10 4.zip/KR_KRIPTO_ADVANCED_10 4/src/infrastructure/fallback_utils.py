# src/infrastructure/fallback_utils.py

class ModeloFallbackDecision:
    def __init__(self):
        self.name = "ModeloFallbackDecision"
    def predict(self, data):
        return {"decisao": "neutro", "confianca": 0.5}

