# src/infrastructure/memory.py
import logging
from typing import Dict, Any

logger = logging.getLogger("kr_kripto_memory")

class MemoriaTemporal:
    """Armazena dados temporários em memória (stub)."""
    def __init__(self, config: dict): # Adicionado *args, **kwargs para flexibilidade
        self._storage: Dict[str, Any] = {}
        logger.info("MemoriaTemporal(config={}) inicializada.")

    def adicionar(self, chave: str, valor: Any):
        logger.debug(f"MemoriaTemporal: Adicionando chave 	{chave}	")
        self._storage[chave] = valor

    def obter(self, chave: str) -> Any:
        logger.debug(f"MemoriaTemporal: Obtendo chave 	{chave}	")
        return self._storage.get(chave)

    def remover(self, chave: str):
        if chave in self._storage:
            logger.debug(f"MemoriaTemporal: Removendo chave 	{chave}	")
            del self._storage[chave]

