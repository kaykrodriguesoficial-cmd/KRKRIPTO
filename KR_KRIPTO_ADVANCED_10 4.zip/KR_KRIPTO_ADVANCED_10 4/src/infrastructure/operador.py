# src/infrastructure/operador.py
import logging
import asyncio
import pandas as pd # Import pandas
import os
import sys
import time
import random
from datetime import datetime

# Garantir disponibilidade de tipos em qualquer ambiente Python
try:
    # Importação principal com todos os tipos necessários
    from typing import Optional, Tuple, Dict, Any, List, Union
    logger = logging.getLogger("kr_kripto_operador")
    logger.info("Tipos importados com sucesso: Optional, Tuple, Dict, Any, List, Union")
except ImportError as e:
    # Fallback para Python 3.5 ou anterior
    logger = logging.getLogger("kr_kripto_operador")
    logger.warning(f"Erro ao importar tipos completos: {e}. Usando fallback.")
    try:
        # Tentar importar individualmente
        from typing import Optional, Tuple, Dict, Any, List
        try:
            from typing import Union
        except ImportError:
            # Criar Union manualmente se não estiver disponível
            logger.warning("Union não disponível, criando definição alternativa")
            Union = lambda *args: Any
    except ImportError as e2:
        logger.critical(f"Falha ao importar tipos básicos: {e2}. Usando definições alternativas.")
        # Último recurso: definir tipos como Any
        Optional = lambda t: Any
        Tuple = lambda *args: Any
        Dict = lambda k, v: Any
        List = lambda t: Any
        Any = object
        Union = lambda *args: Any

# Garantir que os tipos estejam no namespace global
globals()["Optional"] = Optional
globals()["Tuple"] = Tuple
globals()["Dict"] = Dict
globals()["Any"] = Any
globals()["List"] = List
globals()["Union"] = Union

# Importar binance com tratamento de erro
try:
    from binance.client import Client  # Import Client for sync operations if needed
    try:
        from binance.async_client import AsyncClient  # Correct import for AsyncClient
    except ImportError:
        # Adaptação para versões mais recentes da biblioteca
        from binance.client import AsyncClient
        print("Usando AsyncClient da biblioteca binance.client")
    from binance.exceptions import BinanceAPIException, BinanceOrderException
    BINANCE_AVAILABLE = True
except ImportError as e:
    logging.critical(f"Falha ao importar biblioteca python-binance: {e}. Execute 'pip install python-binance' para resolver.")
    BINANCE_AVAILABLE = False
    # Definir enums necessários como fallback
    ORDER_TYPE_MARKET = "MARKET"
    ORDER_TYPE_LIMIT = "LIMIT"
    SIDE_BUY = "BUY"
    SIDE_SELL = "SELL"
    ORDER_STATUS_FILLED = "FILLED"
    TIME_IN_FORCE_GTC = "GTC"
    # Definir exceções como fallback
    class BinanceAPIException(Exception): pass
    class BinanceOrderException(Exception): pass
    # Definir AsyncClient como stub
    class AsyncClient:
        @staticmethod
        async def create(*args, **kwargs):
            logging.error("AsyncClient stub chamado. A biblioteca python-binance não está instalada.")
            return None

# Configuração do logger antes de qualquer uso
logger = logging.getLogger("kr_kripto_operador")

# Importar a classe RiskManager - CORRIGIDO PARA MAC M1
RISK_MANAGER_AVAILABLE = False
try:
    # Primeiro tenta importar do caminho correto (risk_management)
    from src.risk_management.risk_manager import RiskManager
    logger.info("RiskManager importado com sucesso de src.risk_management")
    RISK_MANAGER_AVAILABLE = True
except ImportError:
    try:
        # Tenta caminho alternativo
        from risk_management.risk_manager import RiskManager
        logger.info("RiskManager importado com sucesso de risk_management")
        RISK_MANAGER_AVAILABLE = True
    except ImportError as e:
        # Se ainda falhar, tenta o módulo de compatibilidade
        try:
            # Adiciona o diretório atual ao path
            sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
            # Cria o diretório risk_management se não existir
            risk_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "src", "risk_management")
            os.makedirs(risk_dir, exist_ok=True)
            
            # Verifica se existe o arquivo risk_manager_v2.py
            risk_v2_file = os.path.join(risk_dir, "risk_manager_v2.py")
            risk_file = os.path.join(risk_dir, "risk_manager.py")
            
            # Se existir v2 mas não existir o principal, copia
            if os.path.exists(risk_v2_file) and not os.path.exists(risk_file):
                import shutil
                shutil.copy2(risk_v2_file, risk_file)
                logger.info(f"Copiado {risk_v2_file} para {risk_file}")
            
            # Tenta importar novamente
            from src.risk_management.risk_manager import RiskManager
            logger.info("RiskManager importado com sucesso após correção de arquivos")
            RISK_MANAGER_AVAILABLE = True
        except ImportError as e2:
            logger.critical(f"Falha ao importar RiskManager de risk_management.risk_manager. Lógica SL/TP desabilitada.")
            RISK_MANAGER_AVAILABLE = False
            # Define um stub se a importação falhar
            class RiskManager:
                def __init__(self, config: dict):
                    logger.error("STUB: RiskManager inicializado, mas módulo real não encontrado.")
                async def validar_ordem(self, *args, **kwargs) -> Tuple[bool, str]:
                    logger.error("STUB: validar_ordem chamado, mas módulo real não encontrado.")
                    return True, "Validação simulada (stub)"
                async def calcular_sl_tp_dinamico_async(self, *args, **kwargs) -> Tuple[Optional[float], Optional[float]]:
                    logger.error("STUB: calcular_sl_tp_dinamico_async chamado, mas módulo real não encontrado.")
                    return None, None
                # Adicionar método síncrono stub para compatibilidade
                def calculate_sl_tp(self, *args, **kwargs) -> dict:
                    logger.error("STUB: calculate_sl_tp chamado, mas módulo real não encontrado.")
                    return {"stop_loss": None, "take_profit": None}

class OperadorBinance:
    """Gerencia a execução e cancelamento de ordens na Binance de forma assíncrona."""
    def __init__(self, api_key: str = "", api_secret: str = "", testnet: bool = True, config: Dict[str, Any] = None):
        """
        Inicializa o OperadorBinance com configurações e credenciais.
        
        Args:
            api_key: Chave de API da Binance
            api_secret: Segredo de API da Binance
            testnet: Se deve usar o ambiente de testes da Binance
            config: Dicionário de configuração adicional
        """
        # Verificar se a biblioteca está disponível
        if not BINANCE_AVAILABLE:
            logger.critical("OperadorBinance inicializado, mas a biblioteca python-binance não está disponível.")
            logger.critical("Execute 'pip install python-binance' e reinicie a aplicação.")
        
        # Inicializar configuração
        self.config = config or {}
        
        # Obter credenciais do config ou dos parâmetros
        self.api_key = api_key or self.config.get("binance_api_key", "")
        self.api_secret = api_secret or self.config.get("binance_api_secret", "")
        self.testnet = testnet if api_key else self.config.get("testnet", True)
        
        # Verificar se as credenciais estão completas (devem ter 64 caracteres)
        if len(self.api_key) < 64 or len(self.api_secret) < 64:
            logger.warning(f"Credenciais da API Binance parecem truncadas: key={len(self.api_key)} chars, secret={len(self.api_secret)} chars")
            
            # Tentar obter credenciais completas diretamente do arquivo .env
            try:
                from dotenv import load_dotenv
                import os
                load_dotenv()
                env_api_key = os.getenv("binance_api_key")
                env_api_secret = os.getenv("binance_api_secret")
                
                if env_api_key and len(env_api_key) > len(self.api_key):
                    logger.info(f"Usando credencial API key do ambiente (.env): {len(env_api_key)} chars")
                    self.api_key = env_api_key
                    
                if env_api_secret and len(env_api_secret) > len(self.api_secret):
                    logger.info(f"Usando credencial API secret do ambiente (.env): {len(env_api_secret)} chars")
                    self.api_secret = env_api_secret
            except Exception as e:
                logger.error(f"Erro ao tentar carregar credenciais do .env: {str(e)}")
        
        # Configurações de reconexão e retry
        self.max_reconnect_attempts = self.config.get("max_reconnect_attempts", 5)
        self.reconnect_delay = self.config.get("reconnect_delay", 5)
        self.max_retry_attempts = self.config.get("max_retry_attempts", 3)
        self.retry_delay_base = self.config.get("retry_delay_base", 2)
        
        # Controle de estado e reconexão
        self.client: Optional[AsyncClient] = None
        self.client_lock = asyncio.Lock()  # Para evitar múltiplas inicializações simultâneas
        self.last_reconnect_time = 0
        self.reconnect_count = 0
        self.reconnect_in_progress = False
        
        # Inicializa o RiskManager
        self.risk_manager = RiskManager(config=self.config)
        
        # Cache para precisão de símbolos
        self._precision_cache = {}
        self._precision_cache_lock = asyncio.Lock()
        
        # Validar credenciais
        if not self.api_key or not self.api_secret:
            logger.warning("Credenciais da API Binance não fornecidas ou vazias")
        
        # Log seguro (não expõe a chave completa)
        if self.api_key:
            masked_key = f"{self.api_key[:4]}...{self.api_key[-4:]}" if len(self.api_key) >= 8 else "****"
            logger.info(f"OperadorBinance preparado com API key {masked_key}. Testnet: {self.testnet}")
        else:
            logger.info(f"OperadorBinance preparado sem API key. Testnet: {self.testnet}")

    async def inicializar(self) -> bool:
        """
        Inicializa o AsyncClient com tratamento robusto de erros e reconexão.
        
        Returns:
            bool: True se o cliente foi inicializado com sucesso, False caso contrário
        """
        if not BINANCE_AVAILABLE:
            logger.error("Não é possível inicializar o cliente: biblioteca python-binance não está disponível.")
            return False
        
        # Evitar múltiplas inicializações simultâneas
        async with self.client_lock:
            # Verificar se o cliente já está inicializado
            if self.client is not None:
                return True
            
            # Verificar se estamos tentando reconectar muito rapidamente
            current_time = time.time()
            if self.reconnect_in_progress:
                logger.debug("Reconexão já em andamento, aguardando...")
                return False
            
            if current_time - self.last_reconnect_time < self.reconnect_delay and self.reconnect_count > 0:
                delay = self.reconnect_delay - (current_time - self.last_reconnect_time)
                logger.debug(f"Aguardando {delay:.2f}s antes de tentar reconectar novamente...")
                return False
            
            self.reconnect_in_progress = True
            self.last_reconnect_time = current_time
            self.reconnect_count += 1
            
            try:
                logger.info(f"Tentativa {self.reconnect_count}/{self.max_reconnect_attempts} de inicializar AsyncClient otimizado...")
                
                # Verificar credenciais
                if not self.api_key or not self.api_secret:
                    logger.error("Não é possível inicializar o cliente Binance: credenciais ausentes")
                    self.reconnect_in_progress = False
                    return False
                
                # Inicializar cliente
                masked_key = f"{self.api_key[:4]}...{self.api_key[-4:]}" if len(self.api_key) >= 8 else "****"
                logger.debug(f"Using API Key: {masked_key}")
                logger.debug(f"Testnet mode: {self.testnet}")
                
                # Garantir que as credenciais não estejam truncadas
                if len(self.api_key) < 64 or len(self.api_secret) < 64:
                    # Tentar obter credenciais completas diretamente do arquivo .env novamente
                    try:
                        from dotenv import load_dotenv
                        import os
                        
                        # Forçar recarregamento do .env
                        load_dotenv(override=True)
                        
                        env_api_key = os.getenv("binance_api_key")
                        env_api_secret = os.getenv("binance_api_secret")
                        
                        if env_api_key and len(env_api_key) > len(self.api_key):
                            logger.info(f"CORREÇÃO: Usando credencial API key completa do ambiente (.env): {len(env_api_key)} chars")
                            self.api_key = env_api_key
                            
                        if env_api_secret and len(env_api_secret) > len(self.api_secret):
                            logger.info(f"CORREÇÃO: Usando credencial API secret completa do ambiente (.env): {len(env_api_secret)} chars")
                            self.api_secret = env_api_secret
                    except Exception as e:
                        logger.error(f"Erro ao tentar recarregar credenciais do .env: {str(e)}")
                
                # Log detalhado das credenciais (apenas comprimento para segurança)
                logger.info(f"DIAGNÓSTICO: Comprimento final das credenciais - API key: {len(self.api_key)} chars, API secret: {len(self.api_secret)} chars")
                
                # Criar cliente assíncrono com abordagem simplificada
                try:
                    logger.info("Inicializando AsyncClient com configuração simplificada (tld='com')")
                    self.client = await AsyncClient.create(
                        api_key=self.api_key,
                        api_secret=self.api_secret,
                        testnet=self.testnet,
                        tld='com'  # Usar apenas o TLD principal
                    )
                    
                    # Verificar conexão com ping antes de tentar operações mais complexas
                    await self.client.ping()
                    logger.info("Ping bem-sucedido com configuração simplificada")
                    
                    # Verificar conexão com info da conta
                    account_info = await self.client.get_account()
                    logger.info(f"Conexão com API Binance {'Testnet' if self.testnet else 'Produção'} verificada. Pode operar: {account_info.get('canTrade')}")
                    self.reconnect_count = 0  # Resetar contador após sucesso
                    self.reconnect_in_progress = False
                    return True
                except Exception as conn_err:
                    logger.warning(f"Falha na tentativa com configuração simplificada: {conn_err}")
                    self.client = None
                    
                    # Tentar uma segunda vez com parâmetros mínimos
                    try:
                        logger.info("Tentando inicialização alternativa do AsyncClient com parâmetros mínimos...")
                        # Usar apenas os parâmetros essenciais
                        self.client = await AsyncClient.create(
                            api_key=self.api_key,
                            api_secret=self.api_secret,
                            testnet=self.testnet
                        )
                        
                        # Verificar conexão
                        await self.client.ping()
                        logger.info("AsyncClient inicializado com sucesso na segunda tentativa!")
                        
                        # Verificar conexão com info da conta
                        account_info = await self.client.get_account()
                        logger.info(f"Conexão com API Binance verificada na segunda tentativa. Pode operar: {account_info.get('canTrade')}")
                        self.reconnect_count = 0  # Resetar contador após sucesso
                        self.reconnect_in_progress = False
                        return True
                    except Exception as e2:
                        logger.error(f"Falha na segunda tentativa: {e2}")
                        self.client = None
                        self.reconnect_in_progress = False
                        return False
            except BinanceAPIException as api_err:
                logger.critical(f"Binance API Exception durante inicialização do AsyncClient: {api_err}", exc_info=True)
                self.client = None
                self.reconnect_in_progress = False
                return False
            except Exception as e:
                logger.critical(f"Falha genérica durante inicialização do AsyncClient: {e}", exc_info=True)
                self.client = None
                self.reconnect_in_progress = False
                return False

    async def inicializar_cliente(self):
        """
        Método de compatibilidade para versões anteriores.
        Redireciona para o método inicializar().
    
        Returns:
            bool: True se a inicialização foi bem-sucedida, False caso contrário
        """
        logger.info("Método inicializar_cliente() chamado (compatibilidade). Redirecionando para inicializar()")
        return await self.inicializar()

    async def verificar_e_reconectar_cliente(self) -> bool:
        """
        Verifica se o cliente está inicializado e tenta reconectar se necessário.
        
        Returns:
            bool: True se o cliente está disponível, False caso contrário
        """
        if self.client is not None:
            return True
        
        # Verificar se atingimos o limite de tentativas
        if self.reconnect_count >= self.max_reconnect_attempts:
            logger.error(f"Limite de tentativas de reconexão atingido ({self.max_reconnect_attempts}). Aguardando próximo ciclo.")
            # Resetar contador para permitir novas tentativas no futuro
            self.reconnect_count = 0
            self.last_reconnect_time = time.time()
            return False
        
        # Tentar inicializar o cliente
        logger.info("Cliente não inicializado. Tentando reconectar...")
        success = await self.inicializar()
        
        if not success:
            # Calcular delay com backoff exponencial
            delay = min(self.reconnect_delay * (2 ** (self.reconnect_count - 1)), 60)  # Máximo de 60 segundos
            logger.info(f"Falha ao reconectar. Aguardando {delay}s antes da próxima tentativa.")
            await asyncio.sleep(delay)
        
        return success

    async def fechar_cliente(self):
        """Fecha a sessão do AsyncClient de forma segura."""
        async with self.client_lock:
            if self.client:
                try:
                    await self.client.close_connection()
                    logger.info("Conexão do cliente Async Binance fechada.")
                except Exception as e:
                    logger.error(f"Erro ao fechar conexão do cliente: {e}")
                finally:
                    self.client = None

    async def _formatar_erro_binance(self, e: Exception) -> str:
        """Formata mensagens de erro da Binance para melhor legibilidade."""
        if isinstance(e, BinanceAPIException):
            return f"Binance API Error (code={e.code}): {e.message}"
        elif isinstance(e, BinanceOrderException):
            return f"Binance Order Error (code={e.code}): {e.message}"
        else:
            return f"Erro inesperado: {str(e)}"

    async def executar_com_retry(self, func_name: str, *args, **kwargs) -> Optional[Any]:
        """
        Executa uma função da API com retry automático em caso de falha.
        
        Args:
            func_name: Nome da função do cliente Binance a ser executada
            *args: Argumentos posicionais para a função
            **kwargs: Argumentos nomeados para a função
            
        Returns:
            Resultado da função ou None em caso de falha
        """
        # Verificar se o cliente está disponível
        if not await self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente não disponível para executar {func_name}")
            return None
        
        # Tentar executar a função com retry
        for attempt in range(1, self.max_retry_attempts + 1):
            try:
                if not hasattr(self.client, func_name):
                    logger.error(f"Função {func_name} não encontrada no cliente Binance")
                    return None
                
                func = getattr(self.client, func_name)
                result = await func(*args, **kwargs)
                return result
                
            except BinanceAPIException as api_err:
                # Tratar erros específicos da API
                erro_formatado = await self._formatar_erro_binance(api_err)
                if api_err.code == -1021:  # Timestamp for this request was 1000ms ahead of the server's time
                    logger.warning(f"Erro de timestamp na tentativa {attempt}/{self.max_retry_attempts}: {erro_formatado}")
                    # Não precisa de delay, apenas tentar novamente
                elif api_err.code == -1022:  # Signature for this request is not valid
                    logger.error(f"Erro de assinatura: {erro_formatado}. Verificar configurações de API.")
                    return None  # Não tentar novamente, problema de configuração
                elif api_err.code == -2010:  # Account has insufficient balance
                    logger.error(f"Saldo insuficiente: {erro_formatado}")
                    return None  # Não tentar novamente, problema de saldo
                elif api_err.code == -2011:  # Order não encontrada
                    logger.warning(f"Ordem não encontrada: {erro_formatado}")
                    return None # Ordem pode ter sido cancelada ou preenchida
                elif api_err.code == -1003: # Too many requests
                    logger.warning(f"Limite de requisições atingido na tentativa {attempt}/{self.max_retry_attempts}: {erro_formatado}")
                    # Aplicar delay exponencial
                    delay = min(self.retry_delay_base * (2 ** attempt), 60) + random.uniform(0, 1)
                    logger.info(f"Aguardando {delay:.2f}s antes de tentar novamente...")
                    await asyncio.sleep(delay)
                else:
                    logger.error(f"Erro API Binance na tentativa {attempt}/{self.max_retry_attempts}: {erro_formatado}")
                    # Aplicar delay exponencial para outros erros
                    delay = min(self.retry_delay_base * (2 ** attempt), 60) + random.uniform(0, 1)
                    logger.info(f"Aguardando {delay:.2f}s antes de tentar novamente...")
                    await asyncio.sleep(delay)
            
            except asyncio.TimeoutError:
                logger.warning(f"Timeout na tentativa {attempt}/{self.max_retry_attempts} ao chamar {func_name}")
                if attempt == self.max_retry_attempts:
                    logger.error(f"Falha ao executar {func_name} após {self.max_retry_attempts} tentativas de timeout.")
                    return None
                delay = min(self.retry_delay_base * (2 ** attempt), 60) + random.uniform(0, 1)
                logger.info(f"Aguardando {delay:.2f}s antes de tentar novamente...")
                await asyncio.sleep(delay)
            
            except Exception as e:
                erro_formatado = await self._formatar_erro_binance(e)
                logger.error(f"Erro inesperado na tentativa {attempt}/{self.max_retry_attempts} ao chamar {func_name}: {erro_formatado}", exc_info=True)
                if attempt == self.max_retry_attempts:
                    logger.error(f"Falha ao executar {func_name} após {self.max_retry_attempts} tentativas.")
                    return None
                # Aplicar delay exponencial
                delay = min(self.retry_delay_base * (2 ** attempt), 60) + random.uniform(0, 1)
                logger.info(f"Aguardando {delay:.2f}s antes de tentar novamente...")
                await asyncio.sleep(delay)
        
        logger.error(f"Falha ao executar {func_name} após {self.max_retry_attempts} tentativas.")
        return None

    async def _obter_precisao_simbolo(self, simbolo: str) -> Optional[Dict[str, int]]:
        """
        Obtém a precisão de quantidade e preço para um símbolo da Binance.
        Utiliza cache para evitar chamadas repetidas à API.
        
        Args:
            simbolo: O símbolo do par de trading (ex: BTCUSDT)
            
        Returns:
            Dicionário com 'quantidade' e 'preco' como chaves e o número de casas decimais como valor,
            ou None se não for possível obter a informação.
        """
        async with self._precision_cache_lock:
            if simbolo in self._precision_cache:
                return self._precision_cache[simbolo]
        
        logger.debug(f"Obtendo precisão para {simbolo} da API...")
        info = await self.executar_com_retry("get_symbol_info", symbol=simbolo)
        
        if info and "filters" in info:
            precisao = {"quantidade": 8, "preco": 8} # Default
            for f in info["filters"]:
                if f["filterType"] == "LOT_SIZE":
                    step_size = float(f["stepSize"])
                    precisao["quantidade"] = abs(str(step_size).find('.') - len(str(step_size))) -1 if '.' in str(step_size) else 0
                    precisao["quantidade"] = max(0, precisao["quantidade"]) # Garantir não negativo
                elif f["filterType"] == "PRICE_FILTER":
                    tick_size = float(f["tickSize"])
                    precisao["preco"] = abs(str(tick_size).find('.') - len(str(tick_size))) -1 if '.' in str(tick_size) else 0
                    precisao["preco"] = max(0, precisao["preco"]) # Garantir não negativo
            
            async with self._precision_cache_lock:
                self._precision_cache[simbolo] = precisao
            logger.info(f"Precisão para {simbolo}: Quantidade={precisao['quantidade']}, Preço={precisao['preco']}")
            return precisao
        else:
            logger.error(f"Não foi possível obter informações de precisão para {simbolo}")
            return None

    async def arredondar_quantidade(self, simbolo: str, quantidade: float) -> Optional[float]:
        """
        Arredonda a quantidade de acordo com a precisão do símbolo na Binance.
        
        Args:
            simbolo: O símbolo do par de trading (ex: BTCUSDT)
            quantidade: A quantidade a ser arredondada
            
        Returns:
            A quantidade arredondada ou None se a precisão não puder ser obtida.
        """
        precisao = await self._obter_precisao_simbolo(simbolo)
        if precisao is None:
            return None
        
        casas_decimais = precisao["quantidade"]
        fator = 10 ** casas_decimais
        # Arredonda para baixo para evitar exceder limites
        quantidade_arredondada = int(quantidade * fator) / fator 
        return quantidade_arredondada

    async def arredondar_preco(self, simbolo: str, preco: float) -> Optional[float]:
        """
        Arredonda o preço de acordo com a precisão do símbolo na Binance.
        
        Args:
            simbolo: O símbolo do par de trading (ex: BTCUSDT)
            preco: O preço a ser arredondado
            
        Returns:
            O preço arredondado ou None se a precisão não puder ser obtida.
        """
        precisao = await self._obter_precisao_simbolo(simbolo)
        if precisao is None:
            return None
        
        casas_decimais = precisao["preco"]
        fator = 10 ** casas_decimais
        # Arredonda para o tick mais próximo (pode ser necessário ajustar a lógica dependendo do lado da ordem)
        preco_arredondado = round(preco * fator) / fator
        return preco_arredondado

    async def obter_quantidade_minima(self, simbolo: str) -> float:
        """
        Obtém a quantidade mínima de negociação para um símbolo.
        
        Args:
            simbolo: O símbolo do par de trading (ex: BTCUSDT)
            
        Returns:
            A quantidade mínima ou 0.0 se não for possível obter.
        """
        info = await self.executar_com_retry("get_symbol_info", symbol=simbolo)
        if info and "filters" in info:
            for f in info["filters"]:
                if f["filterType"] == "LOT_SIZE":
                    return float(f["minQty"])
        logger.warning(f"Não foi possível obter quantidade mínima para {simbolo}, retornando 0.0")
        return 0.0

    async def criar_ordem(self, 
                          simbolo: str, 
                          lado: str, 
                          tipo: str, 
                          quantidade: Optional[float] = None, 
                          preco: Optional[float] = None, 
                          quote_order_qty: Optional[float] = None, 
                          stop_price: Optional[float] = None, 
                          time_in_force: Optional[str] = None, 
                          new_client_order_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Cria uma nova ordem na Binance.
        
        Args:
            simbolo: O símbolo do par de trading (ex: BTCUSDT)
            lado: 'BUY' ou 'SELL'
            tipo: Tipo de ordem (ex: 'MARKET', 'LIMIT', 'STOP_LOSS_LIMIT')
            quantidade: Quantidade a comprar/vender (obrigatório para MARKET e LIMIT)
            preco: Preço limite (obrigatório para LIMIT, STOP_LOSS_LIMIT)
            quote_order_qty: Quantidade da moeda de cotação (ex: USDT em BTCUSDT) para ordens MARKET
            stop_price: Preço de parada (obrigatório para STOP_LOSS_LIMIT)
            time_in_force: Tempo em vigor (ex: 'GTC', 'IOC', 'FOK')
            new_client_order_id: ID de ordem do cliente opcional
            
        Returns:
            Dicionário com o resultado da criação da ordem ou um dicionário de erro.
        """
        # Validar parâmetros básicos
        if not simbolo or not lado or not tipo:
            return {"status": "ERROR", "reason": "Parâmetros símbolo, lado e tipo são obrigatórios"}
        
        # Arredondar quantidade e preço se aplicável
        if quantidade is not None:
            quantidade_arredondada = await self.arredondar_quantidade(simbolo, quantidade)
            if quantidade_arredondada is None:
                return {"status": "ERROR", "reason": f"Não foi possível obter precisão para arredondar quantidade de {simbolo}"}
            quantidade = quantidade_arredondada
        
        if preco is not None:
            preco_arredondado = await self.arredondar_preco(simbolo, preco)
            if preco_arredondado is None:
                return {"status": "ERROR", "reason": f"Não foi possível obter precisão para arredondar preço de {simbolo}"}
            preco = preco_arredondado
            
        if stop_price is not None:
            stop_price_arredondado = await self.arredondar_preco(simbolo, stop_price)
            if stop_price_arredondado is None:
                return {"status": "ERROR", "reason": f"Não foi possível obter precisão para arredondar stop_price de {simbolo}"}
            stop_price = stop_price_arredondado

        # Verificar quantidade mínima
        if quantidade is not None:
            quantidade_minima = await self.obter_quantidade_minima(simbolo)
            if quantidade < quantidade_minima:
                logger.error(f"Quantidade {quantidade} menor que o mínimo {quantidade_minima} para {simbolo}")
                return {"status": "ERROR", "reason": f"Quantidade {quantidade} menor que o mínimo {quantidade_minima}"}

        # Validar com RiskManager antes de enviar
        if RISK_MANAGER_AVAILABLE:
            preco_atual_para_validacao = preco if preco else await self.obter_preco_atual(simbolo)
            if preco_atual_para_validacao is None:
                 logger.warning(f"Não foi possível obter preço atual para validação de risco de {simbolo}")
                 # Prosseguir sem validação de risco se o preço não puder ser obtido?
                 # Ou retornar erro? Por segurança, vamos retornar erro.
                 return {"status": "ERROR", "reason": f"Não foi possível obter preço atual para validação de risco de {simbolo}"}
            
            valido, motivo = await self.risk_manager.validar_ordem(simbolo, lado, quantidade, preco_atual_para_validacao)
            if not valido:
                logger.warning(f"Ordem {lado} {quantidade} {simbolo} rejeitada pelo RiskManager: {motivo}")
                return {"status": "REJECTED", "reason": motivo}
        else:
            logger.warning("RiskManager não disponível, pulando validação de ordem.")

        # Construir parâmetros da ordem
        params = {
            "symbol": simbolo,
            "side": lado,
            "type": tipo,
        }
        if quantidade is not None:
            params["quantity"] = quantidade
        if preco is not None:
            params["price"] = preco
        if quote_order_qty is not None:
            params["quoteOrderQty"] = quote_order_qty
        if stop_price is not None:
            params["stopPrice"] = stop_price
        if time_in_force is not None:
            params["timeInForce"] = time_in_force
        if new_client_order_id is not None:
            params["newClientOrderId"] = new_client_order_id

        logger.info(f"Tentando criar ordem: {params}")
        
        # Executar criação da ordem com retry
        resultado = await self.executar_com_retry("create_order", **params)
        
        if resultado:
            logger.info(f"Ordem criada com sucesso: {resultado}")
            return {"status": "SUCCESS", **resultado}
        else:
            logger.error(f"Falha ao criar ordem: {params}")
            return {"status": "ERROR", "reason": "Falha ao executar create_order após retries"}

    async def criar_ordem_stop_loss(self, simbolo: str, lado: str, quantidade: float, preco_stop: float) -> Optional[Dict]:
        """
        Cria uma ordem stop loss.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            lado: Lado da ordem (BUY ou SELL)
            quantidade: Quantidade a ser comprada/vendida
            preco_stop: Preço de ativação do stop loss
            
        Returns:
            Dicionário com informações da ordem ou None em caso de falha
        """
        logger.info(f"Criando ordem stop loss para {simbolo}: {lado} {quantidade} @ {preco_stop}")
        
        # Verificar se o cliente está disponível
        if not await self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar criar ordem stop loss")
            return None
        
        try:
            # Obter precisões
            precisao_qtd = await self._obter_precisao_simbolo(simbolo)
            if precisao_qtd is None:
                logger.error(f"Não foi possível obter precisão de quantidade para {simbolo}")
                return None
            precisao_preco = await self._obter_precisao_simbolo(simbolo)
            if precisao_preco is None:
                logger.error(f"Não foi possível obter precisão de preço para {simbolo}")
                return None
            
            # Arredondar valores
            quantidade_arredondada = await self.arredondar_quantidade(simbolo, quantidade)
            if quantidade_arredondada is None: return None
            preco_stop_arredondado = await self.arredondar_preco(simbolo, preco_stop)
            if preco_stop_arredondado is None: return None
            
            # Verificar quantidade mínima
            quantidade_minima = await self.obter_quantidade_minima(simbolo)
            if quantidade_arredondada < quantidade_minima:
                logger.error(f"Quantidade {quantidade_arredondada} menor que o mínimo {quantidade_minima} para {simbolo}")
                return None
            
            # Criar ordem
            ordem = await self.executar_com_retry("create_order",
                                                 symbol=simbolo,
                                                 side=lado,
                                                 type="STOP_LOSS_MARKET", # Usar STOP_LOSS_MARKET ou STOP_LOSS_LIMIT
                                                 quantity=quantidade_arredondada,
                                                 stopPrice=preco_stop_arredondado)
            
            if ordem:
                logger.info(f"Ordem stop loss criada com sucesso: {ordem.get('orderId')}")
                return ordem
            else:
                logger.error("Falha ao criar ordem stop loss: resposta vazia")
                return None
        except BinanceAPIException as api_err:
            logger.error(f"Erro da API Binance ao criar ordem stop loss: {api_err}")
            return None
        except Exception as e:
            logger.error(f"Erro ao criar ordem stop loss: {e}")
            return None

    async def criar_ordem_take_profit(self, simbolo: str, lado: str, quantidade: float, preco_tp: float) -> Optional[Dict]:
        """
        Cria uma ordem take profit.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            lado: Lado da ordem (BUY ou SELL)
            quantidade: Quantidade a ser comprada/vendida
            preco_tp: Preço de ativação do take profit
            
        Returns:
            Dicionário com informações da ordem ou None em caso de falha
        """
        logger.info(f"Criando ordem take profit para {simbolo}: {lado} {quantidade} @ {preco_tp}")
        
        # Verificar se o cliente está disponível
        if not await self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar criar ordem take profit")
            return None
        
        try:
            # Obter precisões
            precisao_qtd = await self._obter_precisao_simbolo(simbolo)
            if precisao_qtd is None: return None
            precisao_preco = await self._obter_precisao_simbolo(simbolo)
            if precisao_preco is None: return None
            
            # Arredondar valores
            quantidade_arredondada = await self.arredondar_quantidade(simbolo, quantidade)
            if quantidade_arredondada is None: return None
            preco_tp_arredondado = await self.arredondar_preco(simbolo, preco_tp)
            if preco_tp_arredondado is None: return None
            
            # Verificar quantidade mínima
            quantidade_minima = await self.obter_quantidade_minima(simbolo)
            if quantidade_arredondada < quantidade_minima:
                logger.error(f"Quantidade {quantidade_arredondada} menor que o mínimo {quantidade_minima} para {simbolo}")
                return None
            
            # Criar ordem
            ordem = await self.executar_com_retry("create_order",
                                                 symbol=simbolo,
                                                 side=lado,
                                                 type="TAKE_PROFIT_MARKET", # Usar TAKE_PROFIT_MARKET ou TAKE_PROFIT_LIMIT
                                                 quantity=quantidade_arredondada,
                                                 stopPrice=preco_tp_arredondado)
            
            if ordem:
                logger.info(f"Ordem take profit criada com sucesso: {ordem.get('orderId')}")
                return ordem
            else:
                logger.error("Falha ao criar ordem take profit: resposta vazia")
                return None
        except BinanceAPIException as api_err:
            logger.error(f"Erro da API Binance ao criar ordem take profit: {api_err}")
            return None
        except Exception as e:
            logger.error(f"Erro ao criar ordem take profit: {e}")
            return None

    async def cancelar_ordem(self, simbolo: str, order_id: Optional[str] = None, orig_client_order_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Cancela uma ordem aberta na Binance.
        
        Args:
            simbolo: O símbolo do par de trading (ex: BTCUSDT)
            order_id: O ID da ordem na Binance
            orig_client_order_id: O ID original da ordem do cliente
            
        Returns:
            Dicionário com o resultado do cancelamento ou um dicionário de erro.
        """
        if not simbolo or (order_id is None and orig_client_order_id is None):
            return {"status": "ERROR", "reason": "Símbolo e pelo menos um ID de ordem são obrigatórios"}
        
        params = {"symbol": simbolo}
        if order_id:
            params["orderId"] = order_id
        if orig_client_order_id:
            params["origClientOrderId"] = orig_client_order_id
            
        logger.info(f"Tentando cancelar ordem: {params}")
        
        # Executar cancelamento com retry
        resultado = await self.executar_com_retry("cancel_order", **params)
        
        if resultado:
            logger.info(f"Ordem cancelada com sucesso: {resultado}")
            return {"status": "SUCCESS", **resultado}
        else:
            logger.error(f"Falha ao cancelar ordem: {params}")
            # Verificar se o erro foi "Order does not exist" (código -2011)
            # Isso pode acontecer se a ordem já foi preenchida ou cancelada
            # Neste caso, podemos considerar como sucesso ou um status específico
            # Por enquanto, retornamos erro genérico
            return {"status": "ERROR", "reason": "Falha ao executar cancel_order após retries"}

    async def cancelar_todas_ordens(self, simbolo: str) -> bool:
        """
        Cancela todas as ordens abertas para um símbolo.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            
        Returns:
            True se as ordens foram canceladas com sucesso, False caso contrário
        """
        logger.info(f"Cancelando todas as ordens para {simbolo}")
        
        # Verificar se o cliente está disponível
        if not await self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar cancelar todas as ordens")
            return False
        
        try:
            # Cancelar todas as ordens
            resultado = await self.executar_com_retry("cancel_open_orders",
                                                     symbol=simbolo)
            
            if resultado is not None: # A API retorna uma lista de ordens canceladas
                logger.info(f"Todas as ordens para {simbolo} canceladas com sucesso")
                return True
            else:
                # A API pode retornar lista vazia se não houver ordens
                logger.info(f"Nenhuma ordem aberta encontrada para cancelar em {simbolo}")
                return True 
        except BinanceAPIException as api_err:
            logger.error(f"Erro da API Binance ao cancelar todas as ordens para {simbolo}: {api_err}")
            return False
        except Exception as e:
            logger.error(f"Erro ao cancelar todas as ordens para {simbolo}: {e}")
            return False

    async def obter_status_ordem(self, simbolo: str, order_id: Optional[str] = None, orig_client_order_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Obtém o status de uma ordem na Binance.
        
        Args:
            simbolo: O símbolo do par de trading (ex: BTCUSDT)
            order_id: O ID da ordem na Binance
            orig_client_order_id: O ID original da ordem do cliente
            
        Returns:
            Dicionário com os detalhes da ordem ou None em caso de falha.
        """
        if not simbolo or (order_id is None and orig_client_order_id is None):
            logger.error("Símbolo e pelo menos um ID de ordem são obrigatórios para obter status")
            return None
        
        params = {"symbol": simbolo}
        if order_id:
            params["orderId"] = order_id
        if orig_client_order_id:
            params["origClientOrderId"] = orig_client_order_id
            
        logger.debug(f"Obtendo status da ordem: {params}")
        
        # Executar consulta com retry
        resultado = await self.executar_com_retry("get_order", **params)
        
        if resultado:
            logger.debug(f"Status da ordem obtido: {resultado}")
            return resultado
        else:
            logger.error(f"Falha ao obter status da ordem: {params}")
            return None

    async def obter_ordens_abertas(self, simbolo: Optional[str] = None) -> Optional[List[Dict[str, Any]]]:
        """
        Obtém a lista de ordens abertas na Binance.
        
        Args:
            simbolo: O símbolo do par de trading (opcional, filtra por símbolo)
            
        Returns:
            Lista de dicionários com os detalhes das ordens abertas ou None em caso de falha.
        """
        params = {}
        if simbolo:
            params["symbol"] = simbolo
            
        logger.debug(f"Obtendo ordens abertas: {params}")
        
        # Executar consulta com retry
        resultado = await self.executar_com_retry("get_open_orders", **params)
        
        if resultado is not None: # Pode retornar lista vazia
            logger.debug(f"Ordens abertas obtidas: {len(resultado)} ordens")
            return resultado
        else:
            logger.error(f"Falha ao obter ordens abertas: {params}")
            return None

    async def obter_saldo(self, ativo: str) -> Optional[float]:
        """
        Obtém o saldo disponível de um ativo específico na conta Binance.
        
        Args:
            ativo: O símbolo do ativo (ex: BTC, USDT)
            
        Returns:
            O saldo disponível como float ou None em caso de falha.
        """
        logger.debug(f"Obtendo saldo para {ativo}...")
        
        # Executar consulta com retry
        resultado = await self.executar_com_retry("get_asset_balance", asset=ativo)
        
        if resultado and "free" in resultado:
            saldo = float(resultado["free"])
            logger.debug(f"Saldo de {ativo}: {saldo}")
            return saldo
        else:
            logger.error(f"Falha ao obter saldo para {ativo}. Resultado: {resultado}")
            return None

    async def obter_todos_saldos(self) -> Optional[Dict[str, float]]:
        """
        Obtém os saldos disponíveis de todos os ativos na conta Binance.
        
        Returns:
            Dicionário com o símbolo do ativo como chave e o saldo disponível como valor,
            ou None em caso de falha.
        """
        logger.debug("Obtendo todos os saldos...")
        
        # Executar consulta com retry
        account_info = await self.executar_com_retry("get_account")
        
        if account_info and "balances" in account_info:
            saldos = {}
            for balance in account_info["balances"]:
                saldo_livre = float(balance["free"])
                if saldo_livre > 0:
                    saldos[balance["asset"]] = saldo_livre
            logger.debug(f"Saldos obtidos: {len(saldos)} ativos com saldo > 0")
            return saldos
        else:
            logger.error(f"Falha ao obter informações da conta. Resultado: {account_info}")
            return None

    async def obter_preco_atual(self, simbolo: str) -> Optional[float]:
        """
        Obtém o preço atual de um símbolo na Binance.
        
        Args:
            simbolo: O símbolo do par de trading (ex: BTCUSDT)
            
        Returns:
            O preço atual como float ou None em caso de falha.
        """
        logger.debug(f"Obtendo preço atual para {simbolo}...")
        
        # Executar consulta com retry
        resultado = await self.executar_com_retry("get_symbol_ticker", symbol=simbolo)
        
        if resultado and "price" in resultado:
            preco = float(resultado["price"])
            logger.debug(f"Preço atual de {simbolo}: {preco}")
            return preco
        else:
            logger.error(f"Falha ao obter preço atual para {simbolo}. Resultado: {resultado}")
            return None

    async def obter_historico_klines(self, simbolo: str, intervalo: str, inicio: Optional[str] = None, fim: Optional[str] = None, limite: int = 500) -> Optional[List[List[Any]]]:
        """
        Obtém o histórico de klines (candlesticks) para um símbolo.
        
        Args:
            simbolo: O símbolo do par de trading (ex: BTCUSDT)
            intervalo: O intervalo do kline (ex: '1m', '1h', '1d')
            inicio: Timestamp de início (string ou int)
            fim: Timestamp de fim (string ou int)
            limite: Número máximo de klines a retornar (máx 1000)
            
        Returns:
            Lista de listas com os dados dos klines ou None em caso de falha.
            Formato: [timestamp, open, high, low, close, volume, ...]
        """
        logger.debug(f"Obtendo histórico de klines para {simbolo} ({intervalo})...")
        
        params = {
            "symbol": simbolo,
            "interval": intervalo,
            "limit": min(limite, 1000) # Garantir limite máximo da API
        }
        if inicio:
            params["startTime"] = inicio
        if fim:
            params["endTime"] = fim
            
        # Executar consulta com retry
        resultado = await self.executar_com_retry("get_klines", **params)
        
        if resultado is not None: # Pode retornar lista vazia
            logger.debug(f"Histórico de klines obtido: {len(resultado)} klines")
            return resultado
        else:
            logger.error(f"Falha ao obter histórico de klines para {simbolo}. Parâmetros: {params}")
            return None

    async def calcular_sl_tp(self, simbolo: str, lado: str, preco_entrada: float, df_historico: Optional[pd.DataFrame] = None) -> Dict[str, Optional[float]]:
        """
        Calcula Stop Loss e Take Profit usando o RiskManager.
        
        Args:
            simbolo: O símbolo do par de trading.
            lado: 'BUY' ou 'SELL'.
            preco_entrada: O preço de entrada da operação.
            df_historico: DataFrame opcional com dados históricos para cálculo.
            
        Returns:
            Dicionário com 'stop_loss' e 'take_profit'.
        """
        if not RISK_MANAGER_AVAILABLE:
            logger.warning("RiskManager não disponível, não é possível calcular SL/TP.")
            return {"stop_loss": None, "take_profit": None}
        
        try:
            # Se df_historico não for fornecido, tenta obter dados recentes
            if df_historico is None:
                logger.debug(f"DataFrame histórico não fornecido para {simbolo}, obtendo dados recentes...")
                # Obter klines suficientes para o cálculo do ATR (ex: 100 períodos)
                klines = await self.obter_historico_klines(simbolo, intervalo='1m', limite=100)
                if klines:
                    df_historico = pd.DataFrame(klines, columns=[
                        'timestamp', 'Open', 'High', 'Low', 'Close', 'Volume', 
                        'close_time', 'quote_asset_volume', 'number_of_trades', 
                        'taker_buy_base_asset_volume', 'taker_buy_quote_asset_volume', 'ignore'
                    ])
                    df_historico['timestamp'] = pd.to_datetime(df_historico['timestamp'], unit='ms')
                    df_historico.set_index('timestamp', inplace=True)
                    for col in ['Open', 'High', 'Low', 'Close', 'Volume']:
                        df_historico[col] = pd.to_numeric(df_historico[col])
                else:
                    logger.warning(f"Não foi possível obter dados históricos para {simbolo}. Cálculo de SL/TP pode ser impreciso.")
            
            # Chamar método assíncrono do RiskManager
            sl, tp = await self.risk_manager.calcular_sl_tp_dinamico_async(df_historico, preco_entrada, lado)
            
            # Arredondar SL/TP de acordo com a precisão do símbolo
            if sl is not None:
                sl = await self.arredondar_preco(simbolo, sl)
            if tp is not None:
                tp = await self.arredondar_preco(simbolo, tp)
                
            logger.info(f"SL/TP calculado para {simbolo} ({lado} @ {preco_entrada}): SL={sl}, TP={tp}")
            return {"stop_loss": sl, "take_profit": tp}
        
        except Exception as e:
            logger.error(f"Erro ao calcular SL/TP para {simbolo}: {e}", exc_info=True)
            return {"stop_loss": None, "take_profit": None}

    async def obter_historico_ordens(self, simbolo: str, limite: int = 500) -> Optional[List[Dict]]:
        """
        Obtém o histórico de ordens para um símbolo.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            limite: Número máximo de ordens a retornar
            
        Returns:
            Lista de ordens ou None em caso de falha
        """
        logger.debug(f"Obtendo histórico de ordens para {simbolo} com limite {limite}")
        
        # Verificar se o cliente está disponível
        if not await self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar obter histórico de ordens")
            return None
        
        try:
            # Obter histórico de ordens
            ordens = await self.executar_com_retry("get_all_orders",
                                                  symbol=simbolo,
                                                  limit=limite)
            
            if ordens is not None:
                logger.debug(f"Obtidas {len(ordens)} ordens do histórico para {simbolo}")
                return ordens
            else:
                logger.error(f"Falha ao obter histórico de ordens para {simbolo}: resposta vazia")
                return None
        except BinanceAPIException as api_err:
            logger.error(f"Erro da API Binance ao obter histórico de ordens para {simbolo}: {api_err}")
            return None
        except Exception as e:
            logger.error(f"Erro ao obter histórico de ordens para {simbolo}: {e}")
            return None

    async def obter_trades(self, simbolo: str, limite: int = 500, inicio: Optional[int] = None) -> Optional[List[Dict]]:
        """
        Obtém os trades recentes para um símbolo.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            limite: Número máximo de trades a retornar
            inicio: ID do trade a partir do qual obter (opcional)
            
        Returns:
            Lista de trades ou None em caso de falha
        """
        logger.debug(f"Obtendo trades para {simbolo} com limite {limite}")
        
        # Verificar se o cliente está disponível
        if not await self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar obter trades")
            return None
        
        try:
            # Preparar parâmetros
            params = {"symbol": simbolo, "limit": limite}
            if inicio:
                params["fromId"] = inicio
            
            # Obter trades
            trades = await self.executar_com_retry("get_my_trades", **params)
            
            if trades is not None:
                logger.debug(f"Obtidos {len(trades)} trades para {simbolo}")
                return trades
            else:
                logger.error(f"Falha ao obter trades para {simbolo}: resposta vazia")
                return None
        except BinanceAPIException as api_err:
            logger.error(f"Erro da API Binance ao obter trades para {simbolo}: {api_err}")
            return None
        except Exception as e:
            logger.error(f"Erro ao obter trades para {simbolo}: {e}")
            return None

# Exemplo de uso (pode ser removido ou movido para testes)
async def exemplo_uso():
    logging.basicConfig(level=logging.INFO)
    
    # Carregar config (simulado aqui)
    config = {
        "binance_api_key": os.environ.get("BINANCE_API_KEY", ""),
        "binance_api_secret": os.environ.get("BINANCE_API_SECRET", ""),
        "testnet": True,
        "max_reconnect_attempts": 3,
        "reconnect_delay": 2,
        "max_retry_attempts": 2,
        "retry_delay_base": 1
    }
    
    operador = OperadorBinance(config=config)
    
    # Inicializar cliente
    if not await operador.inicializar():
        logger.error("Falha ao inicializar operador")
        return
    
    # Obter preço
    preco_btc = await operador.obter_preco_atual("BTCUSDT")
    if preco_btc:
        logger.info(f"Preço atual BTCUSDT: {preco_btc}")
    
    # Obter saldo USDT
    saldo_usdt = await operador.obter_saldo("USDT")
    if saldo_usdt is not None:
        logger.info(f"Saldo USDT: {saldo_usdt}")
    
    # Criar ordem de compra (exemplo)
    if preco_btc and saldo_usdt and saldo_usdt > 10:
        quantidade_compra = 10 / preco_btc # Comprar $10 de BTC
        resultado_ordem = await operador.criar_ordem(
            simbolo="BTCUSDT",
            lado="BUY",
            tipo="MARKET",
            quantidade=quantidade_compra
        )
        logger.info(f"Resultado da criação da ordem: {resultado_ordem}")
        
        if resultado_ordem["status"] == "SUCCESS":
            order_id = resultado_ordem.get("orderId")
            if order_id:
                # Obter status da ordem
                await asyncio.sleep(2) # Esperar um pouco
                status_ordem = await operador.obter_status_ordem("BTCUSDT", order_id=order_id)
                logger.info(f"Status da ordem {order_id}: {status_ordem}")
                
                # Calcular SL/TP
                sl_tp = await operador.calcular_sl_tp("BTCUSDT", "BUY", float(status_ordem.get("price", preco_btc)))
                logger.info(f"SL/TP sugerido: {sl_tp}")
                
                # Cancelar ordem (se ainda estiver aberta - improvável para MARKET)
                # resultado_cancel = await operador.cancelar_ordem("BTCUSDT", order_id=order_id)
                # logger.info(f"Resultado do cancelamento: {resultado_cancel}")
    
    # Fechar cliente
    await operador.fechar_cliente()

if __name__ == "__main__":
    # Para executar o exemplo, descomente a linha abaixo
    # asyncio.run(exemplo_uso())
    pass

