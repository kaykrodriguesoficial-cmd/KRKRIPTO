# src/infrastructure/operador.py
import logging
import asyncio
import threading
import pandas as pd # Import pandas
import os
import sys
import time
import random
from datetime import datetime

# Garantir disponibilidade de tipos em qualquer ambiente Python
try:
    # Importação principal com todos os tipos necessários
    from typing import Optional, Tuple, Dict, Any, List, Union
    logger = logging.getLogger("kr_kripto_operador")
    logger.info("Tipos importados com sucesso: Optional, Tuple, Dict, Any, List, Union")
except ImportError as e:
    # Fallback para Python 3.5 ou anterior
    logger = logging.getLogger("kr_kripto_operador")
    logger.warning(f"Erro ao importar tipos completos: {e}. Usando fallback.")
    try:
        # Tentar importar individualmente
        from typing import Optional, Tuple, Dict, Any, List
        try:
            from typing import Union
        except ImportError:
            # Criar Union manualmente se não estiver disponível
            logger.warning("Union não disponível, criando definição alternativa")
            Union = lambda *args: Any
    except ImportError as e2:
        logger.critical(f"Falha ao importar tipos básicos: {e2}. Usando definições alternativas.")
        # Último recurso: definir tipos como Any
        Optional = lambda t: Any
        Tuple = lambda *args: Any
        Dict = lambda k, v: Any
        List = lambda t: Any
        Any = object
        Union = lambda *args: Any

# Garantir que os tipos estejam no namespace global
globals()['Optional'] = Optional
globals()['Tuple'] = Tuple
globals()['Dict'] = Dict
globals()['Any'] = Any
globals()['List'] = List
globals()['Union'] = Union

# Importar binance com tratamento de erro
try:
    from binance.client import Client  # Import Client for sync operations if needed
    try:
        from binance.async_client import AsyncClient  # Correct import for AsyncClient
    except ImportError:
        # Adaptação para versões mais recentes da biblioteca
        from binance.client import Client as AsyncClient
        print("Usando Client como AsyncClient (adaptação)")
    from binance.exceptions import BinanceAPIException, BinanceOrderException
    BINANCE_AVAILABLE = True
except ImportError as e:
    logging.critical(f"Falha ao importar biblioteca python-binance: {e}. Execute 'pip install python-binance' para resolver.")
    BINANCE_AVAILABLE = False
    # Definir enums necessários como fallback
    ORDER_TYPE_MARKET = 'MARKET'
    SIDE_BUY = 'BUY'
    SIDE_SELL = 'SELL'
    ORDER_STATUS_FILLED = 'FILLED'
    TIME_IN_FORCE_GTC = 'GTC'
    # Definir exceções como fallback
    class BinanceAPIException(Exception): pass
    class BinanceOrderException(Exception): pass
    # Definir AsyncClient como stub
    class AsyncClient:
        @staticmethod
        async def create(*args, **kwargs):
            logging.error("AsyncClient stub chamado. A biblioteca python-binance não está instalada.")
            return None

# Configuração do logger antes de qualquer uso
logger = logging.getLogger("kr_kripto_operador")

# Importar a classe RiskManager - CORRIGIDO PARA MAC M1
RISK_MANAGER_AVAILABLE = False
try:
    # Primeiro tenta importar do caminho correto (risk_management)
    from src.risk_management.risk_manager import RiskManager
    logger.info("RiskManager importado com sucesso de src.risk_management")
    RISK_MANAGER_AVAILABLE = True
except ImportError:
    try:
        # Tenta caminho alternativo
        from risk_management.risk_manager import RiskManager
        logger.info("RiskManager importado com sucesso de risk_management")
        RISK_MANAGER_AVAILABLE = True
    except ImportError as e:
        # Se ainda falhar, tenta o módulo de compatibilidade
        try:
            # Adiciona o diretório atual ao path
            sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
            # Cria o diretório risk_management se não existir
            risk_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "src", "risk_management")
            os.makedirs(risk_dir, exist_ok=True)
            
            # Verifica se existe o arquivo risk_manager_v2.py
            risk_v2_file = os.path.join(risk_dir, "risk_manager_v2.py")
            risk_file = os.path.join(risk_dir, "risk_manager.py")
            
            # Se existir v2 mas não existir o principal, copia
            if os.path.exists(risk_v2_file) and not os.path.exists(risk_file):
                import shutil
                shutil.copy2(risk_v2_file, risk_file)
                logger.info(f"Copiado {risk_v2_file} para {risk_file}")
            
            # Tenta importar novamente
            from src.risk_management.risk_manager import RiskManager
            logger.info("RiskManager importado com sucesso após correção de arquivos")
            RISK_MANAGER_AVAILABLE = True
        except ImportError as e2:
            logger.critical(f"Falha ao importar RiskManager de risk_management.risk_manager. Lógica SL/TP desabilitada.")
            RISK_MANAGER_AVAILABLE = False
            # Define um stub se a importação falhar
            class RiskManager:
                def __init__(self, config: dict):
                    logger.error("STUB: RiskManager inicializado, mas módulo real não encontrado.")
                def calculate_sl_tp(self, *args, **kwargs) -> dict:
                    logger.error("STUB: calculate_sl_tp chamado, mas módulo real não encontrado.")
                    return {"stop_loss": None, "take_profit": None}

class OperadorBinance:
    """Gerencia a execução e cancelamento de ordens na Binance."""
    def __init__(self, config: dict):
        """
        Inicializa o OperadorBinance com configurações e credenciais.
        
        Args:
            config: Dicionário de configuração que contém as credenciais e configurações
        """
        # Verificar se a biblioteca está disponível
        if not BINANCE_AVAILABLE:
            logger.critical("OperadorBinance inicializado, mas a biblioteca python-binance não está disponível.")
            logger.critical("Execute 'pip install python-binance' e reinicie a aplicação.")
        
        # Obter credenciais do config (já carregadas de variáveis de ambiente pelo config_loader)
        self.api_key = config.get("binance_api_key", "")
        self.api_secret = config.get("binance_api_secret", "")
        self.testnet = config.get("testnet", True)
        
        # Configurações de reconexão e retry
        self.max_reconnect_attempts = config.get("max_reconnect_attempts", 5)
        self.reconnect_delay = config.get("reconnect_delay", 5)
        self.max_retry_attempts = config.get("max_retry_attempts", 3)
        self.retry_delay_base = config.get("retry_delay_base", 2)
        
        # Controle de estado e reconexão
        self.client: Optional[AsyncClient] = None
        self.client_lock = threading.Lock()  # Para evitar múltiplas inicializações simultâneas
        self.last_reconnect_time = 0
        self.reconnect_count = 0
        self.reconnect_in_progress = False
        
        # Inicializa o RiskManager
        self.risk_manager = RiskManager(config={})
        
        # Cache para precisão de símbolos
        self._precision_cache = {}
        
        # Validar credenciais
        if not self.api_key or not self.api_secret:
            logger.warning("Credenciais da API Binance não fornecidas ou vazias")
        
        # Log seguro (não expõe a chave completa)
        if self.api_key:
            masked_key = f"{self.api_key[:4]}...{self.api_key[-4:]}" if len(self.api_key) >= 8 else "****"
            logger.info(f"OperadorBinance preparado com API key {masked_key}. Testnet: {self.testnet}")
        else:
            logger.info(f"OperadorBinance preparado sem API key. Testnet: {self.testnet}")

    def inicializar_cliente(self) -> bool:
        """
        Inicializa o AsyncClient com tratamento robusto de erros e reconexão.
        
        Returns:
            bool: True se o cliente foi inicializado com sucesso, False caso contrário
        """
        if not BINANCE_AVAILABLE:
            logger.error("Não é possível inicializar o cliente: biblioteca python-binance não está disponível.")
            return False
        
        # Evitar múltiplas inicializações simultâneas
        with self.client_lock:
            # Verificar se o cliente já está inicializado
            if self.client is not None:
                return True
            
            # Verificar se estamos tentando reconectar muito rapidamente
            current_time = time.time()
            if self.reconnect_in_progress:
                logger.debug("Reconexão já em andamento, aguardando...")
                return False
            
            if current_time - self.last_reconnect_time < self.reconnect_delay and self.reconnect_count > 0:
                delay = self.reconnect_delay - (current_time - self.last_reconnect_time)
                logger.debug(f"Aguardando {delay:.2f}s antes de tentar reconectar novamente...")
                return False
            
            self.reconnect_in_progress = True
            self.last_reconnect_time = current_time
            self.reconnect_count += 1
            
            try:
                logger.info(f"Tentativa {self.reconnect_count}/{self.max_reconnect_attempts} de inicializar AsyncClient...")
                
                # Verificar credenciais
                if not self.api_key or not self.api_secret:
                    logger.error("Não é possível inicializar o cliente Binance: credenciais ausentes")
                    self.reconnect_in_progress = False
                    return False
                
                # Inicializar cliente
                masked_key = f"{self.api_key[:4]}...{self.api_key[-4:]}" if len(self.api_key) >= 8 else "****"
                logger.debug(f"Using API Key: {masked_key}")
                logger.debug(f"Testnet mode: {self.testnet}")
                
                self.client = Client(self.api_key, self.api_secret)
                
                if self.client:
                    logger.info("AsyncClient created successfully.")
                    # Verificar conexão com ping ou info da conta
                    try:
                        account_info = self.client.get_account()
                        logger.info(f"Conexão com API Binance {'Testnet' if self.testnet else 'Produção'} verificada. Pode operar: {account_info.get('canTrade')}")
                        self.reconnect_count = 0  # Resetar contador após sucesso
                        self.reconnect_in_progress = False
                        return True
                    except Exception as conn_err:
                        logger.error(f"Erro ao verificar conexão com API após criação do cliente: {conn_err}", exc_info=True)
                        self.client = None
                        self.reconnect_in_progress = False
                        return False
                else:
                    logger.error("AsyncClient.create returned None without raising an exception.")
                    self.reconnect_in_progress = False
                    return False
            
            except BinanceAPIException as api_err:
                logger.critical(f"Binance API Exception during AsyncClient initialization: {api_err}", exc_info=True)
                self.client = None
                self.reconnect_in_progress = False
                return False
            except Exception as e:
                logger.critical(f"Generic failure during AsyncClient initialization: {e}", exc_info=True)
                self.client = None
                self.reconnect_in_progress = False
                return False

    def verificar_e_reconectar_cliente(self) -> bool:
        """
        Verifica se o cliente está inicializado e tenta reconectar se necessário.
        
        Returns:
            bool: True se o cliente está disponível, False caso contrário
        """
        if self.client is not None:
            return True
        
        # Verificar se atingimos o limite de tentativas
        if self.reconnect_count >= self.max_reconnect_attempts:
            logger.error(f"Limite de tentativas de reconexão atingido ({self.max_reconnect_attempts}). Aguardando próximo ciclo.")
            # Resetar contador para permitir novas tentativas no futuro
            self.reconnect_count = 0
            self.last_reconnect_time = time.time()
            return False
        
        # Tentar inicializar o cliente
        logger.info("Cliente não inicializado. Tentando reconectar...")
        success = self.inicializar_cliente()
        
        if not success:
            # Calcular delay com backoff exponencial
            delay = min(self.reconnect_delay * (2 ** (self.reconnect_count - 1)), 60)  # Máximo de 60 segundos
            logger.info(f"Falha ao reconectar. Aguardando {delay}s antes da próxima tentativa.")
            time.sleep(delay)
        
        return success

    def fechar_cliente(self):
        """Fecha a sessão do AsyncClient de forma segura."""
        with self.client_lock:
            if self.client:
                try:
                    # self.client.close_connection() # Removido await
                    logger.info("Conexão do cliente Async Binance fechada.")
                except Exception as e:
                    logger.error(f"Erro ao fechar conexão do cliente: {e}")
                finally:
                    self.client = None

    def executar_com_retry(self, func_name: str, *args, **kwargs) -> Optional[Any]:
        """
        Executa uma função da API com retry automático em caso de falha.
        
        Args:
            func_name: Nome da função do cliente Binance a ser executada
            *args: Argumentos posicionais para a função
            **kwargs: Argumentos nomeados para a função
            
        Returns:
            Resultado da função ou None em caso de falha
        """
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido durante retry de {func_name}")
            return None
            
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente não disponível para executar {func_name}")
            return None
        
        # Tentar executar a função com retry
        for attempt in range(1, self.max_retry_attempts + 1):
            try:
                if not hasattr(self.client, func_name):
                    logger.error(f"Função {func_name} não encontrada no cliente Binance")
                    return None
                
                func = getattr(self.client, func_name)
                result = func(*args, **kwargs)
                return result
                
            except BinanceAPIException as api_err:
                # Tratar erros específicos da API
                if api_err.code == -1021:  # Timestamp for this request was 1000ms ahead of the server's time
                    logger.warning(f"Erro de timestamp na tentativa {attempt}/{self.max_retry_attempts}: {api_err}")
                    # Não precisa de delay, apenas tentar novamente
                elif api_err.code == -1022:  # Signature for this request is not valid
                    logger.error(f"Erro de assinatura: {api_err}. Verificar configurações de API.")
                    return None  # Não tentar novamente, problema de configuração
                elif api_err.code == -2010:  # Account has insufficient balance
                    logger.error(f"Saldo insuficiente: {api_err}")
                    return None  # Não tentar novamente, problema de saldo
                elif api_err.code == -2011:  # Order não encontrada
                    logger.warning(f"Ordem não encontrada: {api_err}")
                    return None  # Não tentar novamente, ordem não existe
                elif api_err.code == -1003:  # Too many requests
                    logger.warning(f"Rate limit excedido: {api_err}")
                    # Esperar mais tempo antes da próxima tentativa
                    time.sleep(self.retry_delay_base * (2 ** attempt))
                else:
                    logger.error(f"Erro da API Binance na tentativa {attempt}/{self.max_retry_attempts}: {api_err}")
                    if attempt < self.max_retry_attempts:
                        # Calcular delay com backoff exponencial
                        delay = self.retry_delay_base * (2 ** (attempt - 1))
                        logger.info(f"Aguardando {delay}s antes da próxima tentativa...")
                        time.sleep(delay)
                    else:
                        return None
                        
            except Exception as e:
                logger.error(f"Erro ao executar {func_name} na tentativa {attempt}/{self.max_retry_attempts}: {e}")
                if attempt < self.max_retry_attempts:
                    # Calcular delay com backoff exponencial
                    delay = self.retry_delay_base * (2 ** (attempt - 1))
                    logger.info(f"Aguardando {delay}s antes da próxima tentativa...")
                    time.sleep(delay)
                else:
                    return None
        
        # Se chegou aqui, todas as tentativas falharam
        return None

    def obter_klines(self, simbolo: str, intervalo: str, limit: int = None, inicio: Optional[int] = None, fim: Optional[int] = None) -> Optional[List[Any]]:
        """
        Obtém dados de klines (candles) para um símbolo e intervalo específicos.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            intervalo: Intervalo de tempo (ex: 1m, 5m, 1h, 1d)
            limit: (Ignorado) Parâmetro mantido para compatibilidade com chamadores
            inicio: Timestamp de início em milissegundos (opcional)
            fim: Timestamp de fim em milissegundos (opcional)
            
        Returns:
            Lista de klines ou None em caso de falha
        """
        logger.info(f"Obtendo klines para {simbolo} em intervalo {intervalo}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar obter klines")
            return None
            
        # Preparar parâmetros
        params = {
            "symbol": simbolo,
            "interval": intervalo,
            # Removido o parâmetro "limit": limite
        }
        
        if inicio:
            params["startTime"] = inicio
            
        if fim:
            params["endTime"] = fim
            
        try:
            # Tentar usar o método get_klines do AsyncClient
            if hasattr(self.client, "get_klines"):
                logger.debug(f"Usando método get_klines do AsyncClient com params: {params}")
                # Garantir que o resultado seja awaited
                result = self.client.get_klines(**params)
                return result
            else:
                # Fallback para outro método se get_klines não existir
                logger.warning("Método get_klines não disponível no cliente")
                return None
        except Exception as e:
            logger.error(f"Erro ao obter klines: {e}")
            return None

    def get_klines_async(self, symbol: str, interval: str, limit: int = 500, start_time: Optional[int] = None, end_time: Optional[int] = None) -> Optional[List[List[Any]]]:
        """
        Obtém klines (candles) de forma assíncrona.
        
        Args:
            symbol: Par de trading (ex: BTCUSDT)
            interval: Intervalo de tempo (ex: 1m, 5m, 1h, 1d)
            limit: Número máximo de klines a retornar
            start_time: Timestamp de início em milissegundos (opcional)
            end_time: Timestamp de fim em milissegundos (opcional)
            
        Returns:
            Lista de klines ou None em caso de falha
        """
        # Usar a função obter_klines que já tem tratamento de erro
        result = self.obter_klines(symbol, interval, limit, start_time, end_time)
        return result

    def obter_historical_klines(self, simbolo: str, intervalo: str, inicio_str: str, fim_str: Optional[str] = None, limite: int = 1000) -> Optional[List[List[Any]]]:
        """
        Obtém klines históricos para um período específico.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            intervalo: Intervalo de tempo (ex: 1m, 5m, 1h, 1d)
            inicio_str: Data/hora de início em formato string (ex: "1 Jan, 2020")
            fim_str: Data/hora de fim em formato string (opcional)
            limite: Número máximo de klines por requisição
            
        Returns:
            Lista de klines ou None em caso de falha
        """
        logger.info(f"Obtendo klines históricos para {simbolo} em intervalo {intervalo} de {inicio_str} até {fim_str or 'agora'}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar obter klines históricos")
            return None
        
        try:
            # Tentar usar o método get_historical_klines do AsyncClient
            if hasattr(self.client, "get_historical_klines"):
                logger.debug(f"Usando método get_historical_klines do AsyncClient")
                # Remover o parâmetro limit para compatibilidade
                klines = self.executar_com_retry("get_historical_klines", 
                                                      simbolo, 
                                                      intervalo, 
                                                      start_str=inicio_str,
                                                      end_str=fim_str)
                return klines
            else:
                logger.warning("Método get_historical_klines não disponível no cliente")
                return None
        except Exception as e:
            logger.error(f"Erro ao obter klines históricos: {e}")
            return None

    def obter_ticker_price(self, simbolo: str) -> Optional[float]:
        """
        Obtém o preço atual de um símbolo.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            
        Returns:
            Preço atual ou None em caso de falha
        """
        logger.debug(f"Obtendo ticker price para {simbolo}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar obter ticker price")
            return None
        
        try:
            # Tentar usar o método get_symbol_ticker do AsyncClient
            ticker = self.executar_com_retry("get_symbol_ticker", symbol=simbolo)
            if ticker and "price" in ticker:
                price = float(ticker["price"])
                logger.debug(f"Ticker price para {simbolo}: {price}")
                return price
            else:
                logger.warning(f"Ticker price para {simbolo} não contém campo 'price': {ticker}")
                return None
        except Exception as e:
            logger.error(f"Erro ao obter ticker price para {simbolo}: {e}")
            return None

    def obter_book_tickers(self, simbolo: Optional[str] = None) -> Optional[Union[Dict, List[Dict]]]:
        """
        Obtém os melhores preços de compra/venda para um ou todos os símbolos.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT) ou None para todos os símbolos
            
        Returns:
            Dicionário com preços de compra/venda ou None em caso de falha
        """
        logger.debug(f"Obtendo book tickers para {simbolo or 'todos os símbolos'}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar obter book tickers")
            return None
        
        try:
            # Tentar usar o método get_orderbook_tickers ou get_order_book_ticker do AsyncClient
            if simbolo:
                # Para um símbolo específico
                if hasattr(self.client, "get_order_book_ticker"):
                    ticker = self.executar_com_retry("get_order_book_ticker", symbol=simbolo)
                    return ticker
                elif hasattr(self.client, "get_orderbook_ticker"):
                    ticker = self.executar_com_retry("get_orderbook_ticker", symbol=simbolo)
                    return ticker
                else:
                    logger.warning("Métodos get_order_book_ticker e get_orderbook_ticker não disponíveis no cliente")
                    return None
            else:
                # Para todos os símbolos
                if hasattr(self.client, "get_orderbook_tickers"):
                    tickers = self.executar_com_retry("get_orderbook_tickers")
                    return tickers
                elif hasattr(self.client, "get_order_book_tickers"):
                    tickers = self.executar_com_retry("get_order_book_tickers")
                    return tickers
                else:
                    logger.warning("Métodos get_orderbook_tickers e get_order_book_tickers não disponíveis no cliente")
                    return None
        except Exception as e:
            logger.error(f"Erro ao obter book tickers para {simbolo or 'todos os símbolos'}: {e}")
            return None

    def obter_order_book(self, simbolo: str, limite: int = 100) -> Optional[Dict]:
        """
        Obtém o livro de ordens para um símbolo.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            limite: Número de níveis de preço a retornar (máx. 5000)
            
        Returns:
            Dicionário com ordens de compra/venda ou None em caso de falha
        """
        logger.debug(f"Obtendo order book para {simbolo} com limite {limite}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar obter order book")
            return None
        
        try:
            # Tentar usar o método get_order_book do AsyncClient
            if hasattr(self.client, "get_order_book"):
                # Remover o parâmetro limit para compatibilidade
                order_book = self.executar_com_retry("get_order_book", symbol=simbolo)
                return order_book
            else:
                logger.warning("Método get_order_book não disponível no cliente")
                return None
        except Exception as e:
            logger.error(f"Erro ao obter order book para {simbolo}: {e}")
            return None

    def obter_exchange_info(self) -> Optional[Dict]:
        """
        Obtém informações sobre a exchange, incluindo limites e regras.
        
        Returns:
            Dicionário com informações da exchange ou None em caso de falha
        """
        logger.debug("Obtendo exchange info")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error("Cliente perdido ao tentar obter exchange info")
            return None
        
        try:
            # Tentar usar o método get_exchange_info do AsyncClient
            exchange_info = self.executar_com_retry("get_exchange_info")
            return exchange_info
        except Exception as e:
            logger.error(f"Erro ao obter exchange info: {e}")
            return None

    def obter_symbol_info(self, simbolo: str) -> Optional[Dict]:
        """
        Obtém informações detalhadas sobre um símbolo específico.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            
        Returns:
            Dicionário com informações do símbolo ou None em caso de falha
        """
        logger.debug(f"Obtendo symbol info para {simbolo}")
        
        # Verificar se já temos as informações em cache
        if simbolo in self._precision_cache:
            return self._precision_cache[simbolo]
        
        # Obter exchange info
        exchange_info = self.obter_exchange_info()
        if not exchange_info or "symbols" not in exchange_info:
            logger.error("Falha ao obter exchange info ou formato inválido")
            return None
        
        # Procurar o símbolo nas informações da exchange
        for symbol_info in exchange_info["symbols"]:
            if symbol_info["symbol"] == simbolo:
                # Armazenar em cache para uso futuro
                self._precision_cache[simbolo] = symbol_info
                return symbol_info
        
        logger.warning(f"Símbolo {simbolo} não encontrado nas informações da exchange")
        return None

    def obter_precisao_preco(self, simbolo: str) -> int:
        """
        Obtém a precisão de preço para um símbolo.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            
        Returns:
            Número de casas decimais para o preço ou 8 como fallback
        """
        symbol_info = self.obter_symbol_info(simbolo)
        if not symbol_info:
            logger.warning(f"Usando precisão de preço padrão (8) para {simbolo}")
            return 8
        
        # Tentar obter a precisão do preço
        if "pricePrecision" in symbol_info:
            return int(symbol_info["pricePrecision"])
        elif "filters" in symbol_info:
            # Procurar no filtro PRICE_FILTER
            for filter_info in symbol_info["filters"]:
                if filter_info["filterType"] == "PRICE_FILTER" and "tickSize" in filter_info:
                    tick_size = float(filter_info["tickSize"])
                    if tick_size > 0:
                        # Calcular precisão a partir do tickSize
                        precision = 0
                        tick_str = str(tick_size)
                        if "." in tick_str:
                            precision = len(tick_str.split(".")[1].rstrip("0"))
                        return precision
        
        logger.warning(f"Usando precisão de preço padrão (8) para {simbolo}")
        return 8

    def obter_precisao_quantidade(self, simbolo: str) -> int:
        """
        Obtém a precisão de quantidade para um símbolo.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            
        Returns:
            Número de casas decimais para a quantidade ou 8 como fallback
        """
        symbol_info = self.obter_symbol_info(simbolo)
        if not symbol_info:
            logger.warning(f"Usando precisão de quantidade padrão (8) para {simbolo}")
            return 8
        
        # Tentar obter a precisão da quantidade
        if "quantityPrecision" in symbol_info:
            return int(symbol_info["quantityPrecision"])
        elif "baseAssetPrecision" in symbol_info:
            return int(symbol_info["baseAssetPrecision"])
        elif "filters" in symbol_info:
            # Procurar no filtro LOT_SIZE
            for filter_info in symbol_info["filters"]:
                if filter_info["filterType"] == "LOT_SIZE" and "stepSize" in filter_info:
                    step_size = float(filter_info["stepSize"])
                    if step_size > 0:
                        # Calcular precisão a partir do stepSize
                        precision = 0
                        step_str = str(step_size)
                        if "." in step_str:
                            precision = len(step_str.split(".")[1].rstrip("0"))
                        return precision
        
        logger.warning(f"Usando precisão de quantidade padrão (8) para {simbolo}")
        return 8

    def obter_quantidade_minima(self, simbolo: str) -> float:
        """
        Obtém a quantidade mínima para ordens de um símbolo.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            
        Returns:
            Quantidade mínima ou 0.00001 como fallback
        """
        symbol_info = self.obter_symbol_info(simbolo)
        if not symbol_info or "filters" not in symbol_info:
            logger.warning(f"Usando quantidade mínima padrão (0.00001) para {simbolo}")
            return 0.00001
        
        # Procurar no filtro LOT_SIZE
        for filter_info in symbol_info["filters"]:
            if filter_info["filterType"] == "LOT_SIZE" and "minQty" in filter_info:
                return float(filter_info["minQty"])
        
        # Procurar no filtro MIN_NOTIONAL
        for filter_info in symbol_info["filters"]:
            if filter_info["filterType"] == "MIN_NOTIONAL" and "minNotional" in filter_info:
                # Obter preço atual
                price = self.obter_ticker_price(simbolo)
                if price:
                    return float(filter_info["minNotional"]) / price
        
        logger.warning(f"Usando quantidade mínima padrão (0.00001) para {simbolo}")
        return 0.00001

    def obter_notional_minimo(self, simbolo: str) -> float:
        """
        Obtém o valor notional mínimo para ordens de um símbolo.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            
        Returns:
            Valor notional mínimo ou 10.0 como fallback
        """
        symbol_info = self.obter_symbol_info(simbolo)
        if not symbol_info or "filters" not in symbol_info:
            logger.warning(f"Usando notional mínimo padrão (10.0) para {simbolo}")
            return 10.0
        
        # Procurar no filtro MIN_NOTIONAL
        for filter_info in symbol_info["filters"]:
            if filter_info["filterType"] == "MIN_NOTIONAL" and "minNotional" in filter_info:
                return float(filter_info["minNotional"])
        
        logger.warning(f"Usando notional mínimo padrão (10.0) para {simbolo}")
        return 10.0

    def arredondar_preco(self, simbolo: str, preco: float, precisao: Optional[int] = None) -> float:
        """
        Arredonda um preço para a precisão correta do símbolo.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            preco: Preço a ser arredondado
            precisao: Precisão a usar (opcional, será obtida automaticamente se não fornecida)
            
        Returns:
            Preço arredondado
        """
        # Usar precisão fornecida ou obter do cache
        if precisao is None:
            if simbolo in self._precision_cache and "pricePrecision" in self._precision_cache[simbolo]:
                precisao = self._precision_cache[simbolo]["pricePrecision"]
            else:
                # Usar valor padrão se não conseguirmos obter a precisão
                precisao = 8
                logger.warning(f"Usando precisão de preço padrão (8) para {simbolo}")
        
        # Arredondar para a precisão correta
        return round(preco, precisao)

    def arredondar_quantidade(self, simbolo: str, quantidade: float, precisao: Optional[int] = None) -> float:
        """
        Arredonda uma quantidade para a precisão correta do símbolo.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            quantidade: Quantidade a ser arredondada
            precisao: Precisão a usar (opcional, será obtida automaticamente se não fornecida)
            
        Returns:
            Quantidade arredondada
        """
        # Usar precisão fornecida ou obter do cache
        if precisao is None:
            if simbolo in self._precision_cache and "quantityPrecision" in self._precision_cache[simbolo]:
                precisao = self._precision_cache[simbolo]["quantityPrecision"]
            elif simbolo in self._precision_cache and "baseAssetPrecision" in self._precision_cache[simbolo]:
                precisao = self._precision_cache[simbolo]["baseAssetPrecision"]
            else:
                # Usar valor padrão se não conseguirmos obter a precisão
                precisao = 8
                logger.warning(f"Usando precisão de quantidade padrão (8) para {simbolo}")
        
        # Arredondar para a precisão correta
        return round(quantidade, precisao)

    def criar_ordem_mercado(self, simbolo: str, lado: str, quantidade: float) -> Optional[Dict]:
        """
        Cria uma ordem de mercado.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            lado: Lado da ordem (BUY ou SELL)
            quantidade: Quantidade a ser comprada/vendida
            
        Returns:
            Dicionário com informações da ordem ou None em caso de falha
        """
        logger.info(f"Criando ordem de mercado para {simbolo}: {lado} {quantidade}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar criar ordem de mercado")
            return None
        
        try:
            # Obter precisão de quantidade
            precisao_qtd = self.obter_precisao_quantidade(simbolo)
            
            # Arredondar quantidade
            quantidade_arredondada = self.arredondar_quantidade(simbolo, quantidade, precisao_qtd)
            
            # Verificar quantidade mínima
            quantidade_minima = self.obter_quantidade_minima(simbolo)
            if quantidade_arredondada < quantidade_minima:
                logger.error(f"Quantidade {quantidade_arredondada} menor que o mínimo {quantidade_minima} para {simbolo}")
                return None
            
            # Criar ordem
            ordem = self.executar_com_retry("create_order",
                                                 symbol=simbolo,
                                                 side=lado,
                                                 type="MARKET",
                                                 quantity=quantidade_arredondada)
            
            if ordem:
                logger.info(f"Ordem de mercado criada com sucesso: {ordem.get('orderId')}")
                
                # Calcular stop loss e take profit se RiskManager estiver disponível
                if RISK_MANAGER_AVAILABLE and hasattr(self.risk_manager, "calculate_sl_tp"):
                    try:
                        # Obter preço atual
                        preco_atual = self.obter_ticker_price(simbolo)
                        if preco_atual:
                            # Calcular SL/TP
                            sl_tp = self.risk_manager.calculate_sl_tp(
                                symbol=simbolo,
                                side=lado,
                                entry_price=preco_atual,
                                quantity=quantidade_arredondada
                            )
                            
                            # Adicionar SL/TP à resposta
                            ordem["stop_loss"] = sl_tp.get("stop_loss")
                            ordem["take_profit"] = sl_tp.get("take_profit")
                            
                            logger.info(f"SL/TP calculados: SL={sl_tp.get('stop_loss')}, TP={sl_tp.get('take_profit')}")
                    except Exception as e:
                        logger.error(f"Erro ao calcular SL/TP: {e}")
                
                return ordem
            else:
                logger.error("Falha ao criar ordem de mercado: resposta vazia")
                return None
        except BinanceAPIException as api_err:
            logger.error(f"Erro da API Binance ao criar ordem de mercado: {api_err}")
            return None
        except Exception as e:
            logger.error(f"Erro ao criar ordem de mercado: {e}")
            return None

    def criar_ordem_limite(self, simbolo: str, lado: str, quantidade: float, preco: float) -> Optional[Dict]:
        """
        Cria uma ordem limite.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            lado: Lado da ordem (BUY ou SELL)
            quantidade: Quantidade a ser comprada/vendida
            preco: Preço limite
            
        Returns:
            Dicionário com informações da ordem ou None em caso de falha
        """
        logger.info(f"Criando ordem limite para {simbolo}: {lado} {quantidade} @ {preco}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar criar ordem limite")
            return None
        
        try:
            # Obter precisões
            precisao_qtd = self.obter_precisao_quantidade(simbolo)
            precisao_preco = self.obter_precisao_preco(simbolo)
            
            # Arredondar valores
            quantidade_arredondada = self.arredondar_quantidade(simbolo, quantidade, precisao_qtd)
            preco_arredondado = self.arredondar_preco(simbolo, preco, precisao_preco)
            
            # Verificar quantidade mínima
            quantidade_minima = self.obter_quantidade_minima(simbolo)
            if quantidade_arredondada < quantidade_minima:
                logger.error(f"Quantidade {quantidade_arredondada} menor que o mínimo {quantidade_minima} para {simbolo}")
                return None
            
            # Verificar notional mínimo
            notional_minimo = self.obter_notional_minimo(simbolo)
            notional = quantidade_arredondada * preco_arredondado
            if notional < notional_minimo:
                logger.error(f"Valor notional {notional} menor que o mínimo {notional_minimo} para {simbolo}")
                return None
            
            # Criar ordem
            ordem = self.executar_com_retry("create_order",
                                                 symbol=simbolo,
                                                 side=lado,
                                                 type="LIMIT",
                                                 timeInForce="GTC",
                                                 quantity=quantidade_arredondada,
                                                 price=preco_arredondado)
            
            if ordem:
                logger.info(f"Ordem limite criada com sucesso: {ordem.get('orderId')}")
                
                # Calcular stop loss e take profit se RiskManager estiver disponível
                if RISK_MANAGER_AVAILABLE and hasattr(self.risk_manager, "calculate_sl_tp"):
                    try:
                        # Calcular SL/TP
                        sl_tp = self.risk_manager.calculate_sl_tp(
                            symbol=simbolo,
                            side=lado,
                            entry_price=preco_arredondado,
                            quantity=quantidade_arredondada
                        )
                        
                        # Adicionar SL/TP à resposta
                        ordem["stop_loss"] = sl_tp.get("stop_loss")
                        ordem["take_profit"] = sl_tp.get("take_profit")
                        
                        logger.info(f"SL/TP calculados: SL={sl_tp.get('stop_loss')}, TP={sl_tp.get('take_profit')}")
                    except Exception as e:
                        logger.error(f"Erro ao calcular SL/TP: {e}")
                
                return ordem
            else:
                logger.error("Falha ao criar ordem limite: resposta vazia")
                return None
        except BinanceAPIException as api_err:
            logger.error(f"Erro da API Binance ao criar ordem limite: {api_err}")
            return None
        except Exception as e:
            logger.error(f"Erro ao criar ordem limite: {e}")
            return None

    def criar_ordem_stop_loss(self, simbolo: str, lado: str, quantidade: float, preco_stop: float) -> Optional[Dict]:
        """
        Cria uma ordem stop loss.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            lado: Lado da ordem (BUY ou SELL)
            quantidade: Quantidade a ser comprada/vendida
            preco_stop: Preço de ativação do stop
            
        Returns:
            Dicionário com informações da ordem ou None em caso de falha
        """
        logger.info(f"Criando ordem stop loss para {simbolo}: {lado} {quantidade} @ {preco_stop}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar criar ordem stop loss")
            return None
        
        try:
            # Obter precisões
            precisao_qtd = self.obter_precisao_quantidade(simbolo)
            precisao_preco = self.obter_precisao_preco(simbolo)
            
            # Arredondar valores
            quantidade_arredondada = self.arredondar_quantidade(simbolo, quantidade, precisao_qtd)
            preco_stop_arredondado = self.arredondar_preco(simbolo, preco_stop, precisao_preco)
            
            # Verificar quantidade mínima
            quantidade_minima = self.obter_quantidade_minima(simbolo)
            if quantidade_arredondada < quantidade_minima:
                logger.error(f"Quantidade {quantidade_arredondada} menor que o mínimo {quantidade_minima} para {simbolo}")
                return None
            
            # Criar ordem
            ordem = self.executar_com_retry("create_order",
                                                 symbol=simbolo,
                                                 side=lado,
                                                 type="STOP_LOSS_MARKET",
                                                 quantity=quantidade_arredondada,
                                                 stopPrice=preco_stop_arredondado)
            
            if ordem:
                logger.info(f"Ordem stop loss criada com sucesso: {ordem.get('orderId')}")
                return ordem
            else:
                logger.error("Falha ao criar ordem stop loss: resposta vazia")
                return None
        except BinanceAPIException as api_err:
            logger.error(f"Erro da API Binance ao criar ordem stop loss: {api_err}")
            return None
        except Exception as e:
            logger.error(f"Erro ao criar ordem stop loss: {e}")
            return None

    async def criar_ordem_take_profit(self, simbolo: str, lado: str, quantidade: float, preco_tp: float) -> Optional[Dict]:
        """
        Cria uma ordem take profit.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            lado: Lado da ordem (BUY ou SELL)
            quantidade: Quantidade a ser comprada/vendida
            preco_tp: Preço de ativação do take profit
            
        Returns:
            Dicionário com informações da ordem ou None em caso de falha
        """
        logger.info(f"Criando ordem take profit para {simbolo}: {lado} {quantidade} @ {preco_tp}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar criar ordem take profit")
            return None
        
        try:
            # Obter precisões
            precisao_qtd = self.obter_precisao_quantidade(simbolo)
            precisao_preco = self.obter_precisao_preco(simbolo)
            
            # Arredondar valores
            quantidade_arredondada = self.arredondar_quantidade(simbolo, quantidade, precisao_qtd)
            preco_tp_arredondado = self.arredondar_preco(simbolo, preco_tp, precisao_preco)
            
            # Verificar quantidade mínima
            quantidade_minima = self.obter_quantidade_minima(simbolo)
            if quantidade_arredondada < quantidade_minima:
                logger.error(f"Quantidade {quantidade_arredondada} menor que o mínimo {quantidade_minima} para {simbolo}")
                return None
            
            # Criar ordem
            ordem = self.executar_com_retry("create_order",
                                                 symbol=simbolo,
                                                 side=lado,
                                                 type="TAKE_PROFIT_MARKET",
                                                 quantity=quantidade_arredondada,
                                                 stopPrice=preco_tp_arredondado)
            
            if ordem:
                logger.info(f"Ordem take profit criada com sucesso: {ordem.get('orderId')}")
                return ordem
            else:
                logger.error("Falha ao criar ordem take profit: resposta vazia")
                return None
        except BinanceAPIException as api_err:
            logger.error(f"Erro da API Binance ao criar ordem take profit: {api_err}")
            return None
        except Exception as e:
            logger.error(f"Erro ao criar ordem take profit: {e}")
            return None

    async def cancelar_ordem(self, simbolo: str, ordem_id: int) -> bool:
        """
        Cancela uma ordem específica.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            ordem_id: ID da ordem a ser cancelada
            
        Returns:
            True se a ordem foi cancelada com sucesso, False caso contrário
        """
        logger.info(f"Cancelando ordem {ordem_id} para {simbolo}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar cancelar ordem")
            return False
        
        try:
            # Cancelar ordem
            resultado = self.executar_com_retry("cancel_order",
                                                     symbol=simbolo,
                                                     orderId=ordem_id)
            
            if resultado:
                logger.info(f"Ordem {ordem_id} cancelada com sucesso")
                return True
            else:
                logger.error(f"Falha ao cancelar ordem {ordem_id}: resposta vazia")
                return False
        except BinanceAPIException as api_err:
            # Verificar se o erro é porque a ordem já foi executada ou cancelada
            if api_err.code == -2011:  # Order não encontrada
                logger.warning(f"Ordem {ordem_id} não encontrada (já executada ou cancelada)")
                return True
            else:
                logger.error(f"Erro da API Binance ao cancelar ordem {ordem_id}: {api_err}")
                return False
        except Exception as e:
            logger.error(f"Erro ao cancelar ordem {ordem_id}: {e}")
            return False

    async def cancelar_todas_ordens(self, simbolo: str) -> bool:
        """
        Cancela todas as ordens abertas para um símbolo.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            
        Returns:
            True se as ordens foram canceladas com sucesso, False caso contrário
        """
        logger.info(f"Cancelando todas as ordens para {simbolo}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar cancelar todas as ordens")
            return False
        
        try:
            # Cancelar todas as ordens
            resultado = self.executar_com_retry("cancel_all_orders",
                                                     symbol=simbolo)
            
            if resultado is not None:
                logger.info(f"Todas as ordens para {simbolo} canceladas com sucesso")
                return True
            else:
                logger.error(f"Falha ao cancelar todas as ordens para {simbolo}: resposta vazia")
                return False
        except BinanceAPIException as api_err:
            logger.error(f"Erro da API Binance ao cancelar todas as ordens para {simbolo}: {api_err}")
            return False
        except Exception as e:
            logger.error(f"Erro ao cancelar todas as ordens para {simbolo}: {e}")
            return False

    async def obter_ordens_abertas(self, simbolo: Optional[str] = None) -> Optional[List[Dict]]:
        """
        Obtém todas as ordens abertas para um símbolo ou para todos os símbolos.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT) ou None para todos os símbolos
            
        Returns:
            Lista de ordens abertas ou None em caso de falha
        """
        logger.debug(f"Obtendo ordens abertas para {simbolo or 'todos os símbolos'}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar obter ordens abertas")
            return None
        
        try:
            # Obter ordens abertas
            if simbolo:
                ordens = self.executar_com_retry("get_open_orders",
                                                      symbol=simbolo)
            else:
                ordens = self.executar_com_retry("get_open_orders")
            
            if ordens is not None:
                logger.debug(f"Obtidas {len(ordens)} ordens abertas para {simbolo or 'todos os símbolos'}")
                return ordens
            else:
                logger.error(f"Falha ao obter ordens abertas para {simbolo or 'todos os símbolos'}: resposta vazia")
                return None
        except BinanceAPIException as api_err:
            logger.error(f"Erro da API Binance ao obter ordens abertas para {simbolo or 'todos os símbolos'}: {api_err}")
            return None
        except Exception as e:
            logger.error(f"Erro ao obter ordens abertas para {simbolo or 'todos os símbolos'}: {e}")
            return None

    async def obter_ordem(self, simbolo: str, ordem_id: int) -> Optional[Dict]:
        """
        Obtém informações sobre uma ordem específica.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            ordem_id: ID da ordem
            
        Returns:
            Dicionário com informações da ordem ou None em caso de falha
        """
        logger.debug(f"Obtendo informações da ordem {ordem_id} para {simbolo}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar obter informações da ordem")
            return None
        
        try:
            # Obter informações da ordem
            ordem = self.executar_com_retry("get_order",
                                                 symbol=simbolo,
                                                 orderId=ordem_id)
            
            if ordem:
                logger.debug(f"Informações da ordem {ordem_id} obtidas com sucesso")
                return ordem
            else:
                logger.error(f"Falha ao obter informações da ordem {ordem_id}: resposta vazia")
                return None
        except BinanceAPIException as api_err:
            logger.error(f"Erro da API Binance ao obter informações da ordem {ordem_id}: {api_err}")
            return None
        except Exception as e:
            logger.error(f"Erro ao obter informações da ordem {ordem_id}: {e}")
            return None

    async def obter_historico_ordens(self, simbolo: str, limite: int = 500) -> Optional[List[Dict]]:
        """
        Obtém o histórico de ordens para um símbolo.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            limite: Número máximo de ordens a retornar
            
        Returns:
            Lista de ordens ou None em caso de falha
        """
        logger.debug(f"Obtendo histórico de ordens para {simbolo} com limite {limite}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar obter histórico de ordens")
            return None
        
        try:
            # Obter histórico de ordens
            # Remover o parâmetro limit para compatibilidade
            ordens = self.executar_com_retry("get_all_orders",
                                                  symbol=simbolo)
            
            if ordens is not None:
                logger.debug(f"Obtidas {len(ordens)} ordens do histórico para {simbolo}")
                # Limitar o número de ordens se necessário
                return ordens[-limite:] if len(ordens) > limite else ordens
            else:
                logger.error(f"Falha ao obter histórico de ordens para {simbolo}: resposta vazia")
                return None
        except BinanceAPIException as api_err:
            logger.error(f"Erro da API Binance ao obter histórico de ordens para {simbolo}: {api_err}")
            return None
        except Exception as e:
            logger.error(f"Erro ao obter histórico de ordens para {simbolo}: {e}")
            return None

    async def obter_saldo(self, ativo: Optional[str] = None) -> Optional[Union[Dict, float]]:
        """
        Obtém o saldo de um ativo específico ou de todos os ativos.
        
        Args:
            ativo: Símbolo do ativo (ex: BTC) ou None para todos os ativos
            
        Returns:
            Dicionário com saldos ou valor do saldo específico, ou None em caso de falha
        """
        logger.debug(f"Obtendo saldo para {ativo or 'todos os ativos'}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar obter saldo")
            return None
        
        try:
            # Obter informações da conta
            conta = self.executar_com_retry("get_account")
            
            if not conta or "balances" not in conta:
                logger.error(f"Falha ao obter informações da conta: resposta inválida")
                return None
            
            # Filtrar saldos não-zero
            saldos = {}
            for balance in conta["balances"]:
                free = float(balance["free"])
                locked = float(balance["locked"])
                total = free + locked
                
                if total > 0:
                    saldos[balance["asset"]] = {
                        "free": free,
                        "locked": locked,
                        "total": total
                    }
            
            # Retornar saldo específico ou todos os saldos
            if ativo:
                if ativo in saldos:
                    logger.debug(f"Saldo de {ativo}: {saldos[ativo]}")
                    return saldos[ativo]
                else:
                    logger.warning(f"Ativo {ativo} não encontrado ou saldo zero")
                    return {"free": 0.0, "locked": 0.0, "total": 0.0}
            else:
                logger.debug(f"Obtidos saldos para {len(saldos)} ativos")
                return saldos
        except BinanceAPIException as api_err:
            logger.error(f"Erro da API Binance ao obter saldo: {api_err}")
            return None
        except Exception as e:
            logger.error(f"Erro ao obter saldo: {e}")
            return None

    async def obter_trades(self, simbolo: str, limite: int = 500, inicio: Optional[int] = None) -> Optional[List[Dict]]:
        """
        Obtém os trades recentes para um símbolo.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            limite: Número máximo de trades a retornar
            inicio: ID do trade a partir do qual obter (opcional)
            
        Returns:
            Lista de trades ou None em caso de falha
        """
        logger.debug(f"Obtendo trades para {simbolo} com limite {limite}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar obter trades")
            return None
        
        try:
            # Preparar parâmetros
            params = {"symbol": simbolo}
            if inicio:
                params["fromId"] = inicio
            
            # Obter trades
            # Remover o parâmetro limit para compatibilidade
            trades = self.executar_com_retry("get_my_trades", **params)
            
            if trades is not None:
                logger.debug(f"Obtidos {len(trades)} trades para {simbolo}")
                # Limitar o número de trades se necessário
                return trades[-limite:] if len(trades) > limite else trades
            else:
                logger.error(f"Falha ao obter trades para {simbolo}: resposta vazia")
                return None
        except BinanceAPIException as api_err:
            logger.error(f"Erro da API Binance ao obter trades para {simbolo}: {api_err}")
            return None
        except Exception as e:
            logger.error(f"Erro ao obter trades para {simbolo}: {e}")
            return None

    async def obter_trades_agregados(self, simbolo: str, inicio: int, fim: int) -> Optional[List[Dict]]:
        """
        Obtém trades agregados (klines) para um período específico.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            inicio: Timestamp de início em milissegundos
            fim: Timestamp de fim em milissegundos
            
        Returns:
            Lista de trades agregados ou None em caso de falha
        """
        logger.debug(f"Obtendo trades agregados para {simbolo} de {inicio} a {fim}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar obter trades agregados")
            return None
        
        try:
            # Obter trades agregados
            trades = self.executar_com_retry("get_aggregate_trades",
                                                  symbol=simbolo,
                                                  startTime=inicio,
                                                  endTime=fim)
            
            if trades is not None:
                logger.debug(f"Obtidos {len(trades)} trades agregados para {simbolo}")
                return trades
            else:
                logger.error(f"Falha ao obter trades agregados para {simbolo}: resposta vazia")
                return None
        except BinanceAPIException as api_err:
            logger.error(f"Erro da API Binance ao obter trades agregados para {simbolo}: {api_err}")
            return None
        except Exception as e:
            logger.error(f"Erro ao obter trades agregados para {simbolo}: {e}")
            return None

    async def obter_ticker_24h(self, simbolo: Optional[str] = None) -> Optional[Union[Dict, List[Dict]]]:
        """
        Obtém estatísticas de 24 horas para um símbolo ou para todos os símbolos.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT) ou None para todos os símbolos
            
        Returns:
            Dicionário ou lista de dicionários com estatísticas de 24h, ou None em caso de falha
        """
        logger.debug(f"Obtendo ticker 24h para {simbolo or 'todos os símbolos'}")
        
        # Verificar se o cliente está disponível
        if not self.verificar_e_reconectar_cliente():
            logger.error(f"Cliente perdido ao tentar obter ticker 24h")
            return None
        
        try:
            # Obter ticker 24h
            if simbolo:
                ticker = self.executar_com_retry("get_ticker",
                                                      symbol=simbolo)
            else:
                ticker = self.executar_com_retry("get_ticker")
            
            if ticker is not None:
                if simbolo:
                    logger.debug(f"Ticker 24h obtido para {simbolo}")
                else:
                    logger.debug(f"Obtidos {len(ticker)} tickers 24h")
                return ticker
            else:
                logger.error(f"Falha ao obter ticker 24h para {simbolo or 'todos os símbolos'}: resposta vazia")
                return None
        except BinanceAPIException as api_err:
            logger.error(f"Erro da API Binance ao obter ticker 24h para {simbolo or 'todos os símbolos'}: {api_err}")
            return None
        except Exception as e:
            logger.error(f"Erro ao obter ticker 24h para {simbolo or 'todos os símbolos'}: {e}")
            return None

    def obter_klines_para_dataframe(self, simbolo: str, intervalo: str, limite: int = 500, inicio: Optional[int] = None, fim: Optional[int] = None) -> Optional[pd.DataFrame]:
        """
        Obtém klines e converte para DataFrame do pandas.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            intervalo: Intervalo de tempo (ex: 1m, 5m, 1h, 1d)
            limite: Número máximo de klines a retornar
            inicio: Timestamp de início em milissegundos (opcional)
            fim: Timestamp de fim em milissegundos (opcional)
            
        Returns:
            DataFrame com klines ou None em caso de falha
        """
        # Obter klines
        klines = self.obter_klines(simbolo, intervalo, limite, inicio, fim)
        
        if klines is None:
            return None
        
        # Converter para DataFrame
        try:
            df = pd.DataFrame(klines, columns=[
                'timestamp', 'open', 'high', 'low', 'close', 'volume',
                'close_time', 'quote_asset_volume', 'number_of_trades',
                'taker_buy_base_asset_volume', 'taker_buy_quote_asset_volume', 'ignore'
            ])
            
            # Converter tipos
            for col in ['open', 'high', 'low', 'close', 'volume', 'quote_asset_volume',
                        'taker_buy_base_asset_volume', 'taker_buy_quote_asset_volume']:
                df[col] = pd.to_numeric(df[col])
            
            # Converter timestamps para datetime
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df['close_time'] = pd.to_datetime(df['close_time'], unit='ms')
            
            # Definir timestamp como índice
            df.set_index('timestamp', inplace=True)
            
            return df
        except Exception as e:
            logger.error(f"Erro ao converter klines para DataFrame: {e}")
            return None

    def obter_historical_klines_para_dataframe(self, simbolo: str, intervalo: str, inicio_str: str, fim_str: Optional[str] = None, limite: int = 1000) -> Optional[pd.DataFrame]:
        """
        Obtém klines históricos e converte para DataFrame do pandas.
        
        Args:
            simbolo: Par de trading (ex: BTCUSDT)
            intervalo: Intervalo de tempo (ex: 1m, 5m, 1h, 1d)
            inicio_str: Data/hora de início em formato string (ex: "1 Jan, 2020")
            fim_str: Data/hora de fim em formato string (opcional)
            limite: Número máximo de klines por requisição
            
        Returns:
            DataFrame com klines históricos ou None em caso de falha
        """
        # Obter klines históricos
        klines = self.obter_historical_klines(simbolo, intervalo, inicio_str, fim_str, limite)
        
        if klines is None:
            return None
        
        # Converter para DataFrame
        try:
            df = pd.DataFrame(klines, columns=[
                'timestamp', 'open', 'high', 'low', 'close', 'volume',
                'close_time', 'quote_asset_volume', 'number_of_trades',
                'taker_buy_base_asset_volume', 'taker_buy_quote_asset_volume', 'ignore'
            ])
            
            # Converter tipos
            for col in ['open', 'high', 'low', 'close', 'volume', 'quote_asset_volume',
                        'taker_buy_base_asset_volume', 'taker_buy_quote_asset_volume']:
                df[col] = pd.to_numeric(df[col])
            
            # Converter timestamps para datetime
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df['close_time'] = pd.to_datetime(df['close_time'], unit='ms')
            
            # Definir timestamp como índice
            df.set_index('timestamp', inplace=True)
            
            return df
        except Exception as e:
            logger.error(f"Erro ao converter klines históricos para DataFrame: {e}")
            return None
