
import requests

TELEGRAM_TOKEN = "7584540591:AAGXWwqk6n-KZXPJiezOonRmD_uwekNDQdM"
TELEGRAM_CHAT_ID = "1068969834"

def enviar_telegram(mensagem):
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        payload = {
            "chat_id": TELEGRAM_CHAT_ID,
            "text": mensagem
        }
        response = requests.post(url, data=payload)
        if response.status_code != 200:
            print("❌ Erro ao enviar mensagem para o Telegram")
    except Exception as e:
        print(f"Erro no envio para Telegram: {e}")

