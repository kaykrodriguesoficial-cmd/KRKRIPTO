
import os
import pandas as pd
import numpy as np
import json
from datetime import datetime
from inteligencia.log_por_ativo import registrar_log

PASTA_AJUSTES = "ajustes_ativos"
os.makedirs(PASTA_AJUSTES, exist_ok=True)

def ajustar_parametros_por_ativo(ativo, historico_df):
    '''
    Ajusta parâmetros automaticamente com base no histórico do ativo.
    Salva em JSON + histórico CSV.
    '''

    try:
        df = historico_df.copy()

        # Verificação de colunas mínimas
        colunas_necessarias = ["classe_prevista", "resultado_5_candles", "score", "probabilidade"]
        if not all(col in df.columns for col in colunas_necessarias):
            registrar_log(ativo, "❌ Colunas obrigatórias ausentes no histórico para ajustes.", "ajustador", "ERROR")
            return {"status": "erro", "motivo": "colunas ausentes"}

        df = df[df["par"] == ativo] if "par" in df.columns else df
        df = df[df["classe_prevista"].isin(["compra", "venda"])]
        if len(df) < 30:
            registrar_log(ativo, f"⚠️ Histórico insuficiente ({len(df)}) para ajustes do ativo {ativo}.", "ajustador", "WARN")
            return {"status": "erro", "motivo": "histórico insuficiente"}

        # Métricas
        taxa_acerto = (df["resultado_5_candles"] > 0).mean()
        media_lucro = df["resultado_5_candles"].mean()
        media_score = df["score"].mean()
        media_prob = df["probabilidade"].mean()

        # Ajustes calculados
        novo_score_minimo = max(60, min(95, media_score + 10))
        nova_prob_minima = round(min(0.99, max(0.5, media_prob + 0.1)), 2)

        timestamp = datetime.now().isoformat()
        parametros = {
            "ativo": ativo,
            "score_minimo": round(novo_score_minimo, 2),
            "prob_minima": nova_prob_minima,
            "taxa_acerto": round(taxa_acerto, 4),
            "media_lucro": round(media_lucro, 4),
            "ultimo_ajuste": timestamp
        }

        # Salvar JSON por ativo
        json_path = os.path.join(PASTA_AJUSTES, f"{ativo}.json")
        with open(json_path, "w") as f:
            json.dump(parametros, f, indent=2)

        # Salvar histórico CSV
        csv_path = os.path.join(PASTA_AJUSTES, f"{ativo}_ajustes.csv")
        df_csv = pd.DataFrame([parametros])
        if os.path.exists(csv_path):
            df_csv.to_csv(csv_path, mode="a", index=False, header=False)
        else:
            df_csv.to_csv(csv_path, index=False)

        registrar_log(ativo, f"✅ Parâmetros ajustados com sucesso: {parametros}", "ajustador")
        return {"status": "sucesso", "parametros": parametros}

    except Exception as e:
        registrar_log(ativo, f"❌ Erro ao ajustar parâmetros: {e}", "ajustador", "ERROR")
        return {"status": "erro", "motivo": str(e)}
