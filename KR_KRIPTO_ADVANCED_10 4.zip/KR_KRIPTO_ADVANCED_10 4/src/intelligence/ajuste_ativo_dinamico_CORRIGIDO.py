
import os
import pickle
from inteligencia.log_por_ativo import registrar_log

PASTA_MEMORIA = "memoria_ativos"

def salvar_memoria_ativo(ativo, memoria):
    try:
        os.makedirs(PASTA_MEMORIA, exist_ok=True)
        caminho = os.path.join(PASTA_MEMORIA, f"{ativo}.pkl")
        with open(caminho, "wb") as f:
            pickle.dump(memoria, f)
        registrar_log(ativo, "✅ Memória salva com sucesso.", "ajuste_dinamico")
    except Exception as e:
        registrar_log(ativo, f"❌ Erro ao salvar memória: {e}", "ajuste_dinamico", "ERROR")

def carregar_memoria_ativo(ativo):
    caminho = os.path.join(PASTA_MEMORIA, f"{ativo}.pkl")
    try:
        if os.path.exists(caminho):
            with open(caminho, "rb") as f:
                return pickle.load(f)
    except Exception as e:
        registrar_log(ativo, f"❌ Erro ao carregar memória: {e}", "ajuste_dinamico", "ERROR")

    # Memória padrão em caso de erro ou ausência
    return {
        "score_medio": 50,
        "lucro_medio": 0.0,
        "acuracia": 0.5,
        "ultimo_lucro": 0.0,
        "qtd_trades": 0
    }

def atualizar_memoria_ativo(ativo, score_atual, lucro_obtido):
    try:
        if not isinstance(score_atual, (int, float)) or not isinstance(lucro_obtido, (int, float)):
            registrar_log(ativo, "❌ Valores inválidos ao atualizar memória (score/lucro).", "ajuste_dinamico", "ERROR")
            return {"status": "erro", "motivo": "valores inválidos"}

        memoria = carregar_memoria_ativo(ativo)
        memoria["qtd_trades"] += 1
        qtd = memoria["qtd_trades"]

        memoria["score_medio"] = (memoria["score_medio"] * (qtd - 1) + score_atual) / qtd
        memoria["lucro_medio"] = (memoria["lucro_medio"] * (qtd - 1) + lucro_obtido) / qtd
        memoria["ultimo_lucro"] = lucro_obtido

        salvar_memoria_ativo(ativo, memoria)
        registrar_log(ativo, f"🔁 Memória atualizada: {memoria}", "ajuste_dinamico")
        return {"status": "sucesso", "memoria": memoria}

    except Exception as e:
        registrar_log(ativo, f"❌ Erro no update da memória: {e}", "ajuste_dinamico", "ERROR")
        return {"status": "erro", "motivo": str(e)}
