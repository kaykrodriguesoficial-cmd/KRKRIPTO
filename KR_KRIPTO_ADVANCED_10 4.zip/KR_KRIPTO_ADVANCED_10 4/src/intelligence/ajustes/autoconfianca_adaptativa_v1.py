
criterio_performance = {}

def atualizar_pesos_taticos(historico):
    global criterio_performance

    for criterio, resultado in historico.items():
        if criterio not in criterio_performance:
            criterio_performance[criterio] = {"sucesso": 0, "total": 0}
        criterio_performance[criterio]["sucesso"] += int(resultado)
        criterio_performance[criterio]["total"] += 1

    pesos = {}
    for criterio, dados in criterio_performance.items():
        taxa = dados["sucesso"] / max(1, dados["total"])
        pesos[criterio] = round(min(1.5, max(0.1, taxa)), 2)

    total_peso = sum(abs(p) for p in pesos.values()) or 1
    pesos_normalizados = {k: v / total_peso for k, v in pesos.items()}
    return pesos_normalizados
