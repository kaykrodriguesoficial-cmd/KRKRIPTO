
import os
import pandas as pd
from datetime import datetime
from inteligencia.log_por_ativo import registrar_log

ARQUIVO_AUDITORIA = "auditoria/registro_ia.csv"
os.makedirs("auditoria", exist_ok=True)

def registrar_ia_que_gerou_sinal(sinal_id, cerebro, classe, probabilidade, ativo, timestamp=None):
    try:
        if timestamp is None:
            timestamp = datetime.now().isoformat()

        nova_linha = {
            "sinal_id": sinal_id,
            "ia": cerebro,
            "classe": classe,
            "probabilidade": probabilidade,
            "ativo": ativo,
            "timestamp": timestamp
        }

        if os.path.exists(ARQUIVO_AUDITORIA):
            df = pd.read_csv(ARQUIVO_AUDITORIA)
            if sinal_id in df["sinal_id"].values:
                registrar_log(ativo, f"⚠️ Sinal {sinal_id} já registrado. Ignorado.", "auditoria_neural", "WARN")
                return {"status": "duplicado", "sinal_id": sinal_id}
        else:
            df = pd.DataFrame(columns=nova_linha.keys())

        df = pd.concat([df, pd.DataFrame([nova_linha])], ignore_index=True)
        df.to_csv(ARQUIVO_AUDITORIA, index=False)
        registrar_log(ativo, f"✅ Sinal registrado com IA {cerebro}, classe {classe}", "auditoria_neural")
        return {"status": "sucesso", "sinal_id": sinal_id}

    except Exception as e:
        registrar_log(ativo, f"❌ Erro ao registrar auditoria: {e}", "auditoria_neural", "ERROR")
        return {"status": "erro", "motivo": str(e)}

def avaliar_desempenho_por_cerebro(filtro_ativo=None, inicio=None, fim=None):
    try:
        if not os.path.exists(ARQUIVO_AUDITORIA):
            print("[AUDITORIA IA] Nenhum dado registrado ainda.")
            return pd.DataFrame()

        df = pd.read_csv(ARQUIVO_AUDITORIA)

        if filtro_ativo:
            df = df[df["ativo"] == filtro_ativo]

        if inicio:
            df = df[df["timestamp"] >= inicio]
        if fim:
            df = df[df["timestamp"] <= fim]

        desempenho = df.groupby("ia").agg({
            "classe": "count",
            "probabilidade": "mean"
        }).rename(columns={"classe": "sinais_gerados", "probabilidade": "media_probabilidade"})

        print("[AUDITORIA IA] Desempenho por IA:")
        print(desempenho)
        return desempenho

    except Exception as e:
        print(f"[AUDITORIA IA] Erro ao avaliar desempenho: {e}")
        return pd.DataFrame()
