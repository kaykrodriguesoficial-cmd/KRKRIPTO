import pandas as pd
import os
from datetime import datetime
from validador_evolutivo import avaliar_modelo
from inteligencia.mutacoes.mutacao_cerebral import ciclo_auto_mutacao
from observador_metacognitivo import registrar_erro_metacognitivo

LIMITES = {
    "fitness_minimo": 0.3,
    "drawdown_maximo": 50,  # em dólares
    "penalidade_minima": 0.5
}

def avaliar_estado_e_reagir(ativo, df_sinais="historico_sinais.csv"):
    if not os.path.exists(df_sinais):
        return

    acuracia, lucro_total, drawdown, fitness = avaliar_modelo(ativo)

    # Pausar decisões se fitness for muito baixo
    if fitness < LIMITES["fitness_minimo"]:
        print(f"⚠️ AUTO-RECONFIG: Fitness crítico ({fitness}). Pausando decisões do ativo {ativo}.")
        return "pausar"

    # Mutação forçada se drawdown atingir limite
    if drawdown > LIMITES["drawdown_maximo"]:
        print(f"🔥 AUTO-RECONFIG: Drawdown extremo ({drawdown}). Mutação forçada em andamento...")
        ciclo_auto_mutacao()

    # Reforço ativo com sinais penalizados
    try:
        df = pd.read_csv(df_sinais)
        penalizados = df[df["penalidade"] >= LIMITES["penalidade_minima"]]
        for _, row in penalizados.iterrows():
            registrar_erro_metacognitivo(
                ativo=row["ativo"],
                timestamp=row["timestamp"],
                score_final=row["score_final"],
                classe_prevista=row["classe_prevista"],
                classe_real=row["classe_real"]
            )
        print(f"🔁 AUTO-RECONFIG: Reforço executado com {len(penalizados)} sinais críticos.")
    except Exception as e:
        print(f"[AutoReconfig] Erro no reforço direcionado: {e}")

    return "continuar"
