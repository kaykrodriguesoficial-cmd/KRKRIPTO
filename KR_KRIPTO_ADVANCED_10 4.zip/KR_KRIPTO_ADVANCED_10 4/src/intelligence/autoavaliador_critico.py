
import pandas as pd
import os

def avaliar_erro_ia(dados_input, resultado_real, caminho_log='logs/autoavaliador.csv'):
    '''
    Compara a predição da IA com o resultado real e registra se houve erro ou acerto.
    '''
    expected_label = 1 if dados_input.get('score_ia_fusao', 0) > 0.6 else 0
    resultado_binario = 1 if resultado_real > 0 else 0
    erro = expected_label != resultado_binario

    registro = dados_input.copy()
    registro['resultado_real'] = resultado_real
    registro['erro'] = erro

    df = pd.DataFrame([registro])

    if not os.path.exists(caminho_log):
        df.to_csv(caminho_log, index=False)
    else:
        df.to_csv(caminho_log, mode='a', header=False, index=False)

    return not erro  # retorna True se foi um acerto, False se erro
