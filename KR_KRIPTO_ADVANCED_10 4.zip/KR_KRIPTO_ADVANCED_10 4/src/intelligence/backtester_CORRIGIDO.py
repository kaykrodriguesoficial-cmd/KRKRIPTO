
import pandas as pd
from core.indicators import calcular_indicadores
from strategies.score_engine import calcular_score
from strategies.classificador import prever_classe
from strategies.fakeout import detectar_fakeout
from strategies.decision_engine import decidir_entrada
from inteligencia.filtros.filtros_institucionais import validar_filtro_institucional
from strategies.score_engine_v2 import prever_score_final
from executors.operador import executar_operacao
from inteligencia.capital.capital_tracker import inicializar_capital, atualizar_capital, capital_global
from inteligencia.reforco.reforco_lucro import ajustar_pesos_por_lucro
from inteligencia.log_por_ativo import registrar_log

def rodar_backtest(caminho_csv="btc_1m_completo.csv", salvar_resultados=True):
    try:
        df = pd.read_csv(caminho_csv, on_bad_lines='skip')
        df = calcular_indicadores(df)
        inicializar_capital()

        df['score'] = 0
        df['lucro'] = 0.0
        df['score_final'] = 0.0
        df['classe_prevista'] = ''
        df['probabilidade'] = 0.0
        df['fakeout_detectado'] = False
        df['resultado_real'] = 0.0

        total_sinais = 0
        sinais_positivos = 0
        capital_inicial = capital_global.get("BTCUSDT", 1000)

        for i in range(20, len(df) - 5):
            score = calcular_score(df, i, "BTCUSDT", None)
            classe, proba = prever_classe(df)
            fakeout = detectar_fakeout(df)
            validar, motivo = decidir_entrada(score, classe, proba, fakeout)

            if not validar or not validar_filtro_institucional(df, i):
                continue

            peso_score, peso_proba, peso_fake = ajustar_pesos_por_lucro()
            score_final = prever_score_final(score, proba, fakeout, peso_score, peso_proba, peso_fake)

            df.at[i, 'score'] = score
            df.at[i, 'classe_prevista'] = classe
            df.at[i, 'probabilidade'] = proba
            df.at[i, 'fakeout_detectado'] = fakeout
            df.at[i, 'score_final'] = score_final

            resultado, lucro = executar_operacao(df, i, "BTCUSDT", score_final)
            df.at[i, 'resultado_real'] = lucro
            df.at[i, 'lucro'] = lucro

            atualizar_capital("BTCUSDT", lucro)
            total_sinais += 1
            if lucro > 0:
                sinais_positivos += 1

            registrar_log("BTCUSDT", f"[BT] Sinal {classe} | Score {score} | Prob {proba:.2f} | Lucro: {lucro}", "backtester")

        # Resultados finais
        capital_final = capital_global.get("BTCUSDT", capital_inicial)
        total_lucro = capital_final - capital_inicial
        taxa_acerto = round((sinais_positivos / total_sinais) * 100, 2) if total_sinais else 0.0

        print(f"🏁 BACKTEST FINALIZADO")
        print(f"Total de sinais: {total_sinais}")
        print(f"Taxa de acerto: {taxa_acerto:.2f}%")
        print(f"Lucro total: {total_lucro:.2f} USD")

        if salvar_resultados:
            df.to_csv("resultado_backtest.csv", index=False)
            registrar_log("BTCUSDT", "✅ Resultado salvo em resultado_backtest.csv", "backtester")

        return {
            "status": "finalizado",
            "total_sinais": total_sinais,
            "taxa_acerto": taxa_acerto,
            "lucro_total": total_lucro
        }

    except Exception as e:
        registrar_log("BTCUSDT", f"❌ Erro no backtest: {e}", "backtester", "ERROR")
        return {"status": "erro", "motivo": str(e)}
