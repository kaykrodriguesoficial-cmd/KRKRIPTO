# src/infrastructure/cluster_manager.py

import zmq
import zmq.asyncio
import asyncio
import logging
import json
import time
import os # Added import
from typing import Dict, Any, Optional, Callable, Coroutine # Added Coroutine

logger = logging.getLogger("kr_kripto_cluster")

class ClusterManager:
    """Manages ZeroMQ communication for distributing tasks and state in a cluster."""

    def __init__(self, config: dict):
        """Initializes the ClusterManager.

        Args:
            config: Configuration dictionary, expecting a 'cluster_config' section.
        """
        self.config = config.get("cluster_config", {})
        # Corrigido: Definir node_type a partir do config ou usar 'worker' como padrão
        self.node_type = config.get("node_type", "worker")
        self.context = zmq.asyncio.Context()
        self.loop = asyncio.get_event_loop()

        # Socket configurations (defaults can be adjusted in config.json)
        self.pub_port = self.config.get("pub_port", 5555)
        self.sub_port = self.config.get("sub_port", 5556)
        self.sync_port = self.config.get("sync_port", 5557) # For worker synchronization
        self.heartbeat_port = self.config.get("heartbeat_port", 5558)
        self.master_host = self.config.get("master_host", "*") # Master binds to all interfaces
        self.worker_master_addr = self.config.get("worker_master_addr", "localhost") # Worker connects to master's address

        self.pub_socket: Optional[zmq.asyncio.Socket] = None
        self.sub_socket: Optional[zmq.asyncio.Socket] = None
        self.sync_socket: Optional[zmq.asyncio.Socket] = None # For PUB/SUB sync
        self.heartbeat_socket: Optional[zmq.asyncio.Socket] = None

        self.worker_id = f"worker-{int(time.time())}-{os.getpid()}" # Unique worker ID
        self.last_heartbeat_received: Dict[str, float] = {} # Track worker heartbeats (master only)
        self.heartbeat_interval = self.config.get("heartbeat_interval_sec", 5)
        self.heartbeat_timeout = self.config.get("heartbeat_timeout_sec", 15)

        logger.info(f"ClusterManager initialized as {self.node_type} with config: {self.config}")

    async def start(self):
        """Starts the appropriate sockets based on node type."""
        if self.node_type == "master":
            await self._start_master()
        elif self.node_type == "worker":
            await self._start_worker()
        else:
            logger.error(f"Invalid node_type: {self.node_type}")

    async def _start_master(self):
        """Initializes sockets for the master node."""
        try:
            # Publisher socket (distributes tasks/data)
            self.pub_socket = self.context.socket(zmq.PUB)
            pub_addr = f"tcp://{self.master_host}:{self.pub_port}"
            self.pub_socket.bind(pub_addr)
            logger.info(f"Master PUB socket bound to {pub_addr}")

            # Synchronization socket (waits for workers to connect)
            self.sync_socket = self.context.socket(zmq.REP) # REP for simple sync
            sync_addr = f"tcp://{self.master_host}:{self.sync_port}"
            self.sync_socket.bind(sync_addr)
            logger.info(f"Master SYNC socket bound to {sync_addr}")
            # Start sync task in background
            self.loop.create_task(self._master_sync_loop())

            # Heartbeat socket (receives worker heartbeats)
            self.heartbeat_socket = self.context.socket(zmq.REP) # REP to acknowledge heartbeats
            heartbeat_addr = f"tcp://{self.master_host}:{self.heartbeat_port}"
            self.heartbeat_socket.bind(heartbeat_addr)
            logger.info(f"Master HEARTBEAT socket bound to {heartbeat_addr}")
            # Start heartbeat task in background
            self.loop.create_task(self._master_heartbeat_loop())
            self.loop.create_task(self._check_worker_timeouts())

            # TODO: Add SUB socket if master needs to receive results from workers

            logger.info("Master node started successfully.")
        except Exception as e:
            logger.error(f"Error starting master node: {e}", exc_info=True)
            await self.stop()

    async def _start_worker(self):
        """Initializes sockets for a worker node."""
        try:
            # Subscriber socket (receives tasks/data from master)
            self.sub_socket = self.context.socket(zmq.SUB)
            sub_addr = f"tcp://{self.worker_master_addr}:{self.pub_port}"
            self.sub_socket.connect(sub_addr)
            self.sub_socket.subscribe("") # Subscribe to all topics initially
            logger.info(f"Worker SUB socket connected to {sub_addr}")

            # Synchronization socket (signals readiness to master)
            self.sync_socket = self.context.socket(zmq.REQ) # REQ for simple sync
            sync_addr = f"tcp://{self.worker_master_addr}:{self.sync_port}"
            self.sync_socket.connect(sync_addr)
            logger.info(f"Worker SYNC socket connected to {sync_addr}")
            # Send initial sync message
            await self.sync_socket.send_string(self.worker_id)
            await self.sync_socket.recv_string() # Wait for master confirmation
            logger.info(f"Worker {self.worker_id} synchronized with master.")

            # Heartbeat socket (sends heartbeats to master)
            self.heartbeat_socket = self.context.socket(zmq.REQ)
            heartbeat_addr = f"tcp://{self.worker_master_addr}:{self.heartbeat_port}"
            self.heartbeat_socket.connect(heartbeat_addr)
            logger.info(f"Worker HEARTBEAT socket connected to {heartbeat_addr}")
            # Start heartbeat task in background
            self.loop.create_task(self._worker_heartbeat_loop())

            # TODO: Add PUB socket if worker needs to send results back to master

            logger.info(f"Worker node {self.worker_id} started successfully.")
        except Exception as e:
            logger.error(f"Error starting worker node {self.worker_id}: {e}", exc_info=True)
            await self.stop()

    async def _master_sync_loop(self):
        """Master loop to wait for worker synchronization signals."""
        logger.info("Master sync loop started.")
        while True:
            try:
                worker_id = await self.sync_socket.recv_string()
                logger.info(f"Received sync request from worker: {worker_id}")
                await self.sync_socket.send_string("SYNC_ACK")
                # Optionally track connected workers here
            except asyncio.CancelledError:
                logger.info("Master sync loop cancelled.")
                break
            except Exception as e:
                logger.error(f"Error in master sync loop: {e}", exc_info=True)
                await asyncio.sleep(1) # Avoid tight loop on error

    async def _master_heartbeat_loop(self):
        """Master loop to receive and acknowledge worker heartbeats."""
        logger.info("Master heartbeat loop started.")
        while True:
            try:
                message = await self.heartbeat_socket.recv_json()
                worker_id = message.get("worker_id")
                timestamp = message.get("timestamp")
                if worker_id and timestamp:
                    self.last_heartbeat_received[worker_id] = timestamp
                    logger.debug(f"Heartbeat received from {worker_id} at {timestamp}")
                    await self.heartbeat_socket.send_string("HB_ACK")
                else:
                    logger.warning(f"Invalid heartbeat message received: {message}")
                    await self.heartbeat_socket.send_string("HB_INVALID")
            except asyncio.CancelledError:
                logger.info("Master heartbeat loop cancelled.")
                break
            except Exception as e:
                logger.error(f"Error in master heartbeat loop: {e}", exc_info=True)
                # Attempt to send an error response if possible
                try:
                    await self.heartbeat_socket.send_string("HB_ERROR")
                except Exception:
                    pass
                await asyncio.sleep(1)

    async def _check_worker_timeouts(self):
        """Periodically checks if any worker has timed out (master only)."""
        logger.info("Worker timeout check loop started.")
        while True:
            await asyncio.sleep(self.heartbeat_timeout)
            now = time.time()
            timed_out_workers = []
            for worker_id, last_hb in list(self.last_heartbeat_received.items()):
                if now - last_hb > self.heartbeat_timeout:
                    logger.warning(f"Worker {worker_id} timed out (last heartbeat: {last_hb}). Removing.")
                    timed_out_workers.append(worker_id)
                    del self.last_heartbeat_received[worker_id]
            # TODO: Implement logic to handle timed-out workers (e.g., reassign tasks)
            if timed_out_workers:
                logger.info(f"Timed out workers: {timed_out_workers}")

    async def _worker_heartbeat_loop(self):
        """Worker loop to send periodic heartbeats to the master."""
        logger.info(f"Worker {self.worker_id} heartbeat loop started.")
        while True:
            try:
                await asyncio.sleep(self.heartbeat_interval)
                timestamp = time.time()
                message = {"worker_id": self.worker_id, "timestamp": timestamp}
                await self.heartbeat_socket.send_json(message)
                ack = await self.heartbeat_socket.recv_string()
                if ack != "HB_ACK":
                    logger.warning(f"Received unexpected heartbeat ack: {ack}")
                else:
                    logger.debug(f"Heartbeat sent at {timestamp} and acknowledged.")
            except asyncio.CancelledError:
                logger.info(f"Worker {self.worker_id} heartbeat loop cancelled.")
                break
            except Exception as e:
                logger.error(f"Error in worker {self.worker_id} heartbeat loop: {e}", exc_info=True)
                # Implement reconnection logic if needed
                await asyncio.sleep(self.heartbeat_interval) # Wait before retrying

    async def publish(self, topic: str, message: Any):
        """Publishes a message (master only)."""
        if self.node_type != "master" or not self.pub_socket:
            logger.error("Cannot publish: Not a master node or PUB socket not initialized.")
            return
        try:
            payload = json.dumps(message).encode("utf-8")
            await self.pub_socket.send_multipart([topic.encode("utf-8"), payload])
            logger.debug(f"Published to topic 	{topic}	: {message}")
        except Exception as e:
            logger.error(f"Error publishing message to topic {topic}: {e}", exc_info=True)

    async def subscribe(self, handler: Callable[[str, Any], Coroutine]):
        """Subscribes to messages and calls the handler (worker only)."""
        if self.node_type != "worker" or not self.sub_socket:
            logger.error("Cannot subscribe: Not a worker node or SUB socket not initialized.")
            return
        logger.info(f"Worker {self.worker_id} starting subscription loop.")
        while True:
            try:
                topic_bytes, payload_bytes = await self.sub_socket.recv_multipart()
                topic = topic_bytes.decode("utf-8")
                message = json.loads(payload_bytes.decode("utf-8"))
                logger.debug(f"Received on topic 	{topic}	: {message}")
                # Call the provided handler coroutine
                await handler(topic, message)
            except asyncio.CancelledError:
                logger.info(f"Worker {self.worker_id} subscription loop cancelled.")
                break
            except Exception as e:
                logger.error(f"Error in worker {self.worker_id} subscription loop: {e}", exc_info=True)
                await asyncio.sleep(1) # Avoid tight loop on error

    async def stop(self):
        """Closes all sockets and terminates the context."""
        logger.info("Stopping ClusterManager(config={})...".format(config))
        sockets_to_close = [
            self.pub_socket,
            self.sub_socket,
            self.sync_socket,
            self.heartbeat_socket
        ]
        for socket in sockets_to_close:
            if socket and not socket.closed:
                socket.close()
        if self.context and not self.context.closed:
            self.context.term()
        logger.info("ClusterManager stopped.")

# Example Usage (for testing purposes)
async def worker_message_handler(topic, message):
    print(f"WORKER HANDLER: Received on topic 	{topic}	: {message}")
    # Simulate work
    await asyncio.sleep(0.1)

async def main_test():
    # Load dummy config
    config = {
        "cluster_config": {
            "pub_port": 5555,
            "sub_port": 5556,
            "sync_port": 5557,
            "heartbeat_port": 5558,
            "master_host": "*",
            "worker_master_addr": "127.0.0.1",
            "heartbeat_interval_sec": 2,
            "heartbeat_timeout_sec": 6
        }
    }

    # Start Master
    master = ClusterManager(config={'node_type': "master"})
    await master.start()

    # Start Workers
    worker1 = ClusterManager(config={'node_type': "worker"})
    await worker1.start()
    asyncio.create_task(worker1.subscribe(worker_message_handler))

    worker2 = ClusterManager(config={'node_type': "worker"})
    await worker2.start()
    asyncio.create_task(worker2.subscribe(worker_message_handler))

    # Give workers time to sync and start listening
    await asyncio.sleep(2)

    # Master publishes messages
    for i in range(5):
        await master.publish("signals/BTCUSDT", {"signal": "BUY", "score": 0.75 + i*0.01, "timestamp": time.time()})
        await master.publish("state/ETHUSDT", {"price": 3000 + i*10, "volume": 100 + i*5, "timestamp": time.time()})
        await asyncio.sleep(1)

    # Keep running for a while to observe heartbeats and potential timeouts
    print("Running for 15 seconds to observe...")
    await asyncio.sleep(15)

    # Stop everything
    print("Stopping...")
    await worker1.stop()
    await worker2.stop()
    await master.stop()

if __name__ == "__main__":
    # Basic logging for test
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    try:
        asyncio.run(main_test())
    except KeyboardInterrupt:
        print("Interrupted by user.")

