
class CoordenadorEstrategico:
    def __init__(self):
        self.memoria_contextual = {}

    def atualizar_contexto(self, ativo, contexto):
        self.memoria_contextual[ativo] = contexto

    def analisar_contextos(self, contextos):
        """
        Retorna ajustes por ativo com base nos contextos globais.
        Ex: Se BTC está com alta volatilidade e tendência de alta, ETH pode reforçar sinal.
        """
        ajustes = {}

        volatilidades = {k: v.get("volatilidade", 0.0) for k, v in contextos.items()}
        medias = sum(volatilidades.values()) / len(volatilidades) if volatilidades else 0

        for ativo, ctx in contextos.items():
            vol = ctx.get("volatilidade", 0.0)
            if vol > medias * 1.2:
                ajustes[ativo] = {"reforcar": True}
            elif vol < medias * 0.8:
                ajustes[ativo] = {"reavaliar": True}
            else:
                ajustes[ativo] = {"ok": True}
        return ajustes
