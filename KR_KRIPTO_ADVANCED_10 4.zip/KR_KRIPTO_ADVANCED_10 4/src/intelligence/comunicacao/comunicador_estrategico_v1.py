
from datetime import datetime
from executors.logger import log_erro

def comunicar_evento_estrategico(ativo, evento, contexto):
    try:
        agora = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        msg = f"[{agora}] [{ativo}] 📡 Evento: {evento.upper()} | Contexto: {contexto}"
        log_erro(msg)  # Aqui pode ser substituído por envio a API externa, Discord, etc.
    except Exception as e:
        log_erro(f"[COMUNICAÇÃO] Erro ao comunicar evento: {e}")
