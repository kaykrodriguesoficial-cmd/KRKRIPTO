# src/intelligence/ia_fusao_contextual.py

import pandas as pd

import joblib
import numpy as np
import logging
import os

logger = logging.getLogger(__name__)

# Variável global para armazenar o modelo carregado
modelo_fusao = None
modelo_path = 'modelo_fusao_contextual.pkl' # Definir o caminho esperado

def carregar_modelo_fusao():
    """Carrega o modelo de fusão do arquivo, se ainda não carregado."""
    global modelo_fusao
    if modelo_fusao is None:
        try:
            # Tentar carregar a partir do diretório atual ou um caminho específico
            # Ajuste o caminho conforme necessário se o modelo estiver em outro lugar
            if os.path.exists(modelo_path):
                modelo_fusao = joblib.load(modelo_path)
                logger.info(f"Modelo de fusão carregado de {modelo_path}")
            else:
                logger.error(f"Arquivo do modelo de fusão não encontrado em {modelo_path}. A função prever_score_fusao não funcionará corretamente.")
                # Poderia retornar um modelo dummy ou levantar um erro
                # Por enquanto, deixaremos modelo_fusao como None
        except Exception as e:
            logger.error(f"Erro ao carregar o modelo de fusão de {modelo_path}: {e}")
            # Lidar com o erro (ex: usar um modelo padrão, levantar exceção)
            modelo_fusao = None # Garante que não tentará usar um modelo inválido
    return modelo_fusao

def prever_score_fusao(ativo: str, df: pd.DataFrame, score_base: float, book_state, regime: str) -> float:
    """
    Recebe dados contextuais e retorna o score de fusão previsto.
    Adaptação para carregar o modelo de forma preguiçosa (lazy loading).
    Assinatura ajustada para refletir o uso em signal_processor.py.
    """
    modelo = carregar_modelo_fusao()

    if modelo is None:
        logger.warning("Modelo de fusão não carregado. Retornando score base sem fusão.")
        return score_base # Retorna o score original se o modelo não puder ser carregado

    try:
        # Extrair features necessárias do DataFrame, book_state, etc.
        # Esta parte precisa ser adaptada com base nas features REAIS usadas pelo modelo.
        # O código original usava um dicionário 'dados_input', precisamos mapear.
        # Exemplo (PRECISA SER VALIDADO COM AS FEATURES DO MODELO REAL):
        dados_input = {
            'score_final': score_base, # Mapeamento direto?
            'probabilidade': df['probabilidade'].iloc[-1] if 'probabilidade' in df else 0.5, # Exemplo, precisa existir
            'divergencia': df['divergencia_rsi'].iloc[-1] if 'divergencia_rsi' in df else 0, # Exemplo
            'contexto_regime': 1 if regime == 'tendencia_forte_alta' else 0, # Exemplo de codificação
            'fator_rentabilidade': 0, # Precisa vir de algum lugar (memoria?)
            'fakeout_detectado': 1 if df['fakeout'].iloc[-1] else 0 if 'fakeout' in df else 0, # Exemplo
            'previsao_lstm': 0, # Precisa vir de algum lugar
            'validador_volume_profile': 1, # Assumindo que passou se chegou aqui?
            'validador_book_imbalance': 1, # Assumindo que passou?
            'validador_zona_rejeicao': 1 # Assumindo que passou?
        }

        # Garantir a ordem correta das features conforme o treinamento
        features_ordem = [
            'score_final', 'probabilidade', 'divergencia', 'contexto_regime',
            'fator_rentabilidade', 'fakeout_detectado', 'previsao_lstm',
            'validador_volume_profile', 'validador_book_imbalance', 'validador_zona_rejeicao'
        ]

        valores = np.array([[dados_input.get(chave, 0) for chave in features_ordem]])

        # Prever a probabilidade da classe 1 (lucro)
        prob_lucro = float(modelo.predict_proba(valores)[0][1])

        # A lógica de fusão pode ser mais complexa, mas um exemplo simples:
        # Ponderar o score base com a probabilidade prevista pelo modelo de fusão
        score_fundido = score_base * 0.7 + prob_lucro * 0.3

        return round(score_fundido, 4)

    except Exception as e:
        logger.error(f"Erro em prever_score_fusao: {e}")
        return score_base # Retorna o score original em caso de erro

