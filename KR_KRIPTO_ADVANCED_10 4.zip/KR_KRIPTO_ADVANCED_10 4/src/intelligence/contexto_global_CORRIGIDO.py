
import requests
import numpy as np
from inteligencia.log_por_ativo import registrar_log

def obter_dominancia_btc():
    try:
        resposta = requests.get("https://api.alternative.me/fng/")
        if resposta.status_code == 200:
            dados = resposta.json()
            valor = float(dados["data"][0]["value"])
            registrar_log("BTC", f"📊 Dominância BTC (Fear & Greed): {valor}%", "contexto_global")
            return valor / 100  # normalizado
        registrar_log("BTC", "⚠️ Erro ao obter dominância BTC (status != 200)", "contexto_global", "WARN")
        return 0.5
    except Exception as e:
        registrar_log("BTC", f"❌ Falha na API de dominância BTC: {e}", "contexto_global", "ERROR")
        return 0.5

def calcular_contexto_global(simulacao=True):
    try:
        if simulacao:
            contexto = {
                "btc_dominance": np.random.uniform(0.4, 0.6),
                "sentimento_mercado": np.random.uniform(0.3, 0.7),
                "altcoin_strength": np.random.uniform(0.2, 0.8),
                "volatilidade_global": np.random.uniform(0.1, 0.4),
                "correlacao_btc_x_alt": np.random.uniform(-1.0, 1.0),
                "simulado": True
            }
            registrar_log("GERAL", "🌐 Contexto GLOBAL gerado via simulação", "contexto_global")
        else:
            contexto = {
                "btc_dominance": obter_dominancia_btc(),
                "sentimento_mercado": 0.5,  # Placeholder até fonte real
                "altcoin_strength": 0.5,
                "volatilidade_global": 0.25,
                "correlacao_btc_x_alt": 0.0,
                "simulado": False
            }
            registrar_log("GERAL", "🌐 Contexto GLOBAL real parcialmente carregado", "contexto_global")

        return contexto
    except Exception as e:
        registrar_log("GERAL", f"❌ Erro ao calcular contexto global: {e}", "contexto_global", "ERROR")
        return {
            "btc_dominance": 0.5,
            "sentimento_mercado": 0.5,
            "altcoin_strength": 0.5,
            "volatilidade_global": 0.25,
            "correlacao_btc_x_alt": 0.0,
            "simulado": True,
            "erro": str(e)
        }
