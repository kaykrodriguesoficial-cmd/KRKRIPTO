import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest

def detectar_anomalia_volatilidade(df):
    """
    Detecta padrões anômalos com base na volatilidade recente.
    """
    if len(df) < 30:
        return False

    returns = df['close'].pct_change().fillna(0).values.reshape(-1, 1)
    model = IsolationForest(contamination=0.1, random_state=42)
    model.fit(returns)
    is_outlier = model.predict(returns)[-1]
    return is_outlier == -1

def detectar_quebra_regime(df):
    """
    Detecta mudança súbita de regime usando variação acumulada.
    """
    if len(df) < 50:
        return False

    window = 20
    diffs = df['close'].diff().fillna(0)
    var_acumulada = diffs.rolling(window).std().fillna(0)
    atual = var_acumulada.iloc[-1]
    media_historica = var_acumulada.iloc[:-1].mean()
    return atual > media_historica * 1.5

def contexto_critico(df):
    """
    Combinador de alarmes contextuais.
    """
    anomalia = detectar_anomalia_volatilidade(df)
    ruptura = detectar_quebra_regime(df)
    return anomalia or ruptura
