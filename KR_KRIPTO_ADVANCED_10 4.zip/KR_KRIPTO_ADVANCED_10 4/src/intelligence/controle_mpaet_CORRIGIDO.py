
import os
import json
from datetime import datetime
from inteligencia.log_por_ativo import registrar_log

PASTA_MPAET = "mpaet"
os.makedirs(PASTA_MPAET, exist_ok=True)

def _caminho(ativo):
    return os.path.join(PASTA_MPAET, f"{ativo}_mpaet.json")

def inicializar_mpaet(ativo, capital_inicial=10000, meta_base=300, stop_base=-250):
    caminho = _caminho(ativo)
    if not os.path.exists(caminho):
        estrutura = {
            "data": str(datetime.now().date()),
            "capital_inicial": capital_inicial,
            "capital_atual": capital_inicial,
            "lucro_hoje": 0.0,
            "drawdown_hoje": 0.0,
            "meta_dinamica": meta_base,
            "stop_contextual": stop_base,
            "resiliencia": 1.0,
            "erros_consecutivos": 0,
            "acertos_consecutivos": 0,
            "ativo_bloqueado": False
        }
        with open(caminho, "w") as f:
            json.dump(estrutura, f, indent=4)

def atualizar_mpaet(ativo, resultado_operacao):
    caminho = _caminho(ativo)
    if not os.path.exists(caminho):
        inicializar_mpaet(ativo)

    with open(caminho, "r") as f:
        dados = json.load(f)

    hoje = str(datetime.now().date())
    if dados["data"] != hoje:
        dados["data"] = hoje
        dados["lucro_hoje"] = 0.0
        dados["drawdown_hoje"] = 0.0
        dados["resiliencia"] = 1.0
        dados["erros_consecutivos"] = 0
        dados["acertos_consecutivos"] = 0
        dados["ativo_bloqueado"] = False

    dados["capital_atual"] += resultado_operacao
    dados["lucro_hoje"] += resultado_operacao
    dados["drawdown_hoje"] = min(dados["drawdown_hoje"], resultado_operacao)

    if resultado_operacao > 0:
        dados["acertos_consecutivos"] += 1
        dados["erros_consecutivos"] = 0
    else:
        dados["erros_consecutivos"] += 1
        dados["acertos_consecutivos"] = 0

    if dados["lucro_hoje"] >= dados["meta_dinamica"]:
        dados["ativo_bloqueado"] = True
        registrar_log(ativo, f"🟢 META atingida. Ativo bloqueado. Lucro: {dados['lucro_hoje']}", "mpaet")
    elif dados["lucro_hoje"] <= dados["stop_contextual"]:
        dados["ativo_bloqueado"] = True
        registrar_log(ativo, f"🔴 STOP atingido. Ativo bloqueado. Prejuízo: {dados['lucro_hoje']}", "mpaet")

    with open(caminho, "w") as f:
        json.dump(dados, f, indent=4)

def pode_operar_mpaet(ativo):
    caminho = _caminho(ativo)
    if not os.path.exists(caminho):
        inicializar_mpaet(ativo)
    with open(caminho, "r") as f:
        dados = json.load(f)
    return not dados.get("ativo_bloqueado", False)

def status_mpaet(ativo):
    caminho = _caminho(ativo)
    if not os.path.exists(caminho):
        inicializar_mpaet(ativo)
    with open(caminho, "r") as f:
        return json.load(f)
