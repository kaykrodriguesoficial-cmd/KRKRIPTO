
import os
import csv
from datetime import datetime
from inteligencia.log_por_ativo import registrar_log

PASTA_CURVA = "curva_capital"
os.makedirs(PASTA_CURVA, exist_ok=True)

def registrar_curva(ativo, capital, lucro, score, probabilidade, classe_prevista, resultado):
    try:
        caminho = os.path.join(PASTA_CURVA, f"{ativo}_curva.csv")
        campos = [
            "timestamp", "capital", "lucro",
            "score", "probabilidade", "classe_prevista", "resultado"
        ]
        dados = {
            "timestamp": datetime.now().isoformat(),
            "capital": round(capital, 2),
            "lucro": round(lucro, 2),
            "score": round(score, 2),
            "probabilidade": round(probabilidade, 4),
            "classe_prevista": classe_prevista,
            "resultado": round(resultado, 2)
        }
        existe = os.path.exists(caminho)
        with open(caminho, "a", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=campos)
            if not existe:
                writer.writeheader()
            writer.writerow(dados)

        registrar_log(ativo, f"📊 Curva registrada: Capital={capital}, Lucro={lucro}, Resultado={resultado}", "curva_capital")
    except Exception as e:
        registrar_log(ativo, f"❌ Erro ao registrar curva: {e}", "curva_capital", "ERROR")

def carregar_curva(ativo):
    caminho = os.path.join(PASTA_CURVA, f"{ativo}_curva.csv")
    if not os.path.exists(caminho):
        return []

    try:
        with open(caminho, "r") as f:
            leitor = csv.DictReader(f)
            return list(leitor)
    except Exception as e:
        registrar_log(ativo, f"❌ Erro ao carregar curva: {e}", "curva_capital", "ERROR")
        return []
