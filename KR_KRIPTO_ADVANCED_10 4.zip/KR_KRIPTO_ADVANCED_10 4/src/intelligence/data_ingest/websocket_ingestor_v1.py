"""
Módulo: websocket_ingestor_v1.py
Responsável por iniciar o WebSocket da Binance para ingestão de dados em tempo real.
"""

from binance import ThreadedWebsocketManager
from src.intelligence.import_fix_memoria_temporal import MemoriaTemporal, memoria_temporal
from inteligencia.contexto.contexto_global import atualizar_contexto
from inteligencia.capital.capital_tracker_multi import atualizar_capital
from inteligencia.validadores.validador_cerebros import executar_validacao
from inteligencia.feedback.feedback_aprendiz_real import atualizar_qtable_com_feedback
from inteligencia.memoria.memoria_tatica import atualizar_memoria
from inteligencia.ajustes.autoconfianca_adaptativa_v1 import atualizar_pesos_taticos
from core.orquestrador_assincrono_asyncio import OrquestradorAsync
from executors.telegram import enviar_telegram
from executors.logger import log_erro



# ERRO: Função iniciar_stream_binance não encontrada.
