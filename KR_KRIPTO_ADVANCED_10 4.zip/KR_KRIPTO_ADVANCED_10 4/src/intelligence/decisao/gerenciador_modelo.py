
from inteligencia.meta.reforco_qtable import qtable
from inteligencia.evolucao.mutacao_baseada_em_feedback import mutar_com_base_em_feedback
from inteligencia.avaliadores.avaliador_modelo import avaliar_performance_por_modelo

def obter_modelo_valido(regime, hora, memoria_modelos=None, forcar_mutacao=False):
    '''
    Seleciona e valida um modelo para um dado regime/hora. 
    Se bloqueado, tenta mutação ou fallback.
    
    Parâmetros:
    - regime: str
    - hora: str
    - memoria_modelos: dict opcional com PnLs anteriores
    - forcar_mutacao: bool para testar mutante diretamente

    Retorna:
    - modelo_em_uso: modelo funcional ou None
    - nome_modelo: identificador textual
    '''

    modelos_disponiveis = qtable.qtable.get(regime, {}).get(hora, {})
    if not modelos_disponiveis:
        print(f"⚠️ Nenhum modelo disponível para regime {regime} às {hora}h")
        return None, None

    melhor_modelo = max(modelos_disponiveis.items(), key=lambda x: x[1].get('score', 0.0))
    nome_base, dados_base = melhor_modelo
    modelo_base = dados_base.get('modelo')

    if modelo_base is None:
        print(f"❌ Modelo {nome_base} está indisponível. Tentando fallback...")
        if memoria_modelos:
            mutado = mutar_com_base_em_feedback(regime, hora, memoria_modelos)
            if mutado:
                return mutado, mutado.nome
        return None, None

    if forcar_mutacao:
        memoria = memoria_modelos or avaliar_performance_por_modelo()
        mutado = mutar_com_base_em_feedback(regime, hora, memoria)
        if mutado:
            return mutado, mutado.nome

    return modelo_base, nome_base
