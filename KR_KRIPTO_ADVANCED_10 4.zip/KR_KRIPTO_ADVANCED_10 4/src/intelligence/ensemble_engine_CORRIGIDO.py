
from inteligencia.log_por_ativo import registrar_log

def votar_decisao(score, classe, probabilidade, direcao_ia, direcao_lstm, peso_custom=None, ativo="BTCUSDT"):
    '''
    Consolida múltiplas IAs em uma votação tática.
    Retorna decisão final, justificativa e score percentual.
    '''
    pesos = peso_custom or {
        "score": 1.0,
        "prob": 1.0,
        "direcao_ia": 1.0,
        "direcao_lstm": 1.0
    }

    votos = {
        "score_ok": score >= 70,
        "prob_ok": probabilidade >= 0.65,
        "ia_confirma": (
            (classe == "compra" and direcao_ia == 1) or
            (classe == "venda" and direcao_ia == -1)
        ),
        "lstm_confirma": (
            (classe == "compra" and direcao_lstm == 1) or
            (classe == "venda" and direcao_lstm == -1)
        )
    }

    score_final = (
        pesos["score"] * int(votos["score_ok"]) +
        pesos["prob"] * int(votos["prob_ok"]) +
        pesos["direcao_ia"] * int(votos["ia_confirma"]) +
        pesos["direcao_lstm"] * int(votos["lstm_confirma"])
    )

    total_peso = sum(pesos.values())
    percentual = round(score_final / total_peso, 2)

    status = "Aprovado" if percentual >= 0.75 else "Rejeitado"
    log_msg = f"🧠 Votação neural - {status} ({percentual*100:.0f}%) | Score={score} | Prob={probabilidade:.2f} | Classe={classe} | IA={direcao_ia} | LSTM={direcao_lstm}"
    registrar_log(ativo, log_msg, "ensemble_engine")

    return {
        "aprovado": percentual >= 0.75,
        "justificativa": status,
        "score_percentual": percentual,
        "votos": votos
    }
