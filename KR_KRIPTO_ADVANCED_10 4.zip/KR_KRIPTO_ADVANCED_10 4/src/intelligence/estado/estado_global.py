
from collections import defaultdict
from datetime import datetime

# Estado persistente em memória
estado = {
    "ultimos_sinais": defaultdict(list),  # ativo -> lista de sinais com timestamp
    "ordens_ativas": defaultdict(dict),   # ativo -> dict com info da ordem
    "regimes_atuais": {},                 # ativo -> regime atual detectado
    "modelo_ativo": {},                   # ativo -> modelo atualmente usado
    "timestamp_ultima_execucao": {},      # ativo -> datetime
}

# Funções auxiliares para manipulação

def registrar_sinal(ativo, sinal):
    estado["ultimos_sinais"][ativo].append({
        "timestamp": datetime.utcnow(),
        "sinal": sinal
    })

def atualizar_ordem(ativo, dados_ordem):
    estado["ordens_ativas"][ativo] = dados_ordem

def atualizar_regime(ativo, regime):
    estado["regimes_atuais"][ativo] = regime

def definir_modelo(ativo, modelo):
    estado["modelo_ativo"][ativo] = modelo

def atualizar_timestamp_execucao(ativo):
    estado["timestamp_ultima_execucao"][ativo] = datetime.utcnow()

def obter_estado(ativo):
    return {
        "sinais": estado["ultimos_sinais"].get(ativo, []),
        "ordem": estado["ordens_ativas"].get(ativo),
        "regime": estado["regimes_atuais"].get(ativo),
        "modelo": estado["modelo_ativo"].get(ativo),
        "ultimo_tick": estado["timestamp_ultima_execucao"].get(ativo),
    }
