import json
import os

ARQUIVO_PESOS = "pesos_reforco.json"

def carregar_pesos():
    if os.path.exists(ARQUIVO_PESOS):
        with open(ARQUIVO_PESOS, "r") as f:
            return json.load(f)
    return {}

def salvar_pesos(pesos):
    with open(ARQUIVO_PESOS, "w") as f:
        json.dump(pesos, f, indent=2)

def registrar_feedback_regime(regime, modelo, sucesso=True):
    pesos = carregar_pesos()
    if regime not in pesos:
        pesos[regime] = {}
    if modelo not in pesos[regime]:
        pesos[regime][modelo] = {"acertos": 0, "erros": 0}

    if sucesso:
        pesos[regime][modelo]["acertos"] += 1
    else:
        pesos[regime][modelo]["erros"] += 1

    salvar_pesos(pesos)

def modelo_mais_forte_para_regime(regime):
    pesos = carregar_pesos()
    if regime not in pesos:
        return "modelo_hibrido"

    melhorescore = -999
    melhor_modelo = "modelo_hibrido"

    for modelo, stats in pesos[regime].items():
        acertos = stats.get("acertos", 0)
        erros = stats.get("erros", 0)
        total = acertos + erros
        if total < 5:
            continue
        score = (acertos / total) - (0.1 * erros)
        if score > melhorescore:
            melhorescore = score
            melhor_modelo = modelo

    return melhor_modelo
