
import random
from inteligencia.evolucao.mutador_modelos import mutar_modelo
from inteligencia.meta.reforco_qtable import qtable

def mutar_com_base_em_feedback(regime, hora, desempenho_modelos, threshold_eficacia=0.05):
    '''
    Realiza mutação apenas se houver evidência de que o modelo atual está abaixo da média.
    
    Parâmetros:
    - regime: regime atual do mercado
    - hora: hora atual (str ou int)
    - desempenho_modelos: dict com {'modelo': media_pnl}
    - threshold_eficacia: mínimo de superação necessário para validar mutante

    Retorna:
    - novo_modelo (obj ou None)
    '''
    if not desempenho_modelos:
        return None  # Sem dados de base

    modelo_base, pnl_base = max(desempenho_modelos.items(), key=lambda x: x[1])

    # Gera mutante
    modelo_mutado = mutar_modelo(qtable.qtable[regime][hora][modelo_base]["modelo"])

    # Simula (ou conecta com resultado real): mutante precisa superar por delta mínimo
    pnl_mutante_simulado = pnl_base + random.uniform(-0.1, 0.2)

    if pnl_mutante_simulado > pnl_base + threshold_eficacia:
        print(f"🧬 Mutação APROVADA: {modelo_mutado.nome} superou {modelo_base}")
        qtable.qtable[regime][hora][modelo_mutado.nome] = {
            "modelo": modelo_mutado,
            "score": 0.0,
            "usos": 0,
            "acertos": 0
        }
        return modelo_mutado

    print(f"❌ Mutação REJEITADA: {modelo_mutado.nome} não superou base")
    return None
