
import os
import pandas as pd
from inteligencia.log_por_ativo import registrar_log

def ajustar_execucao_por_prioridade(ativo, score, probabilidade):
    '''
    Ajusta agressividade da execução com base na prioridade do ativo.
    Retorna dicionário com score ajustado, delay, exigência extra e prioridade.
    '''

    caminho_csv = f"ajustes_ativos/{ativo}_historico_ajustes.csv"
    prioridade = "media"

    if os.path.exists(caminho_csv):
        try:
            historico = pd.read_csv(caminho_csv)
            if len(historico) >= 3:
                recent = historico.tail(3)
                acuracia = recent["taxa_acerto"].mean()
                lucro = recent["media_lucro"].mean()

                if acuracia > 0.6 and lucro > 10:
                    prioridade = "alta"
                elif acuracia < 0.45 or lucro < 0:
                    prioridade = "baixa"
        except Exception as e:
            registrar_log(ativo, f"❌ Falha ao ler histórico de ajustes: {e}", "executor_dinamico", "ERROR")

    if prioridade == "alta":
        score_ajustado = score + 5
        delay = 0
        exigencia = 0
    elif prioridade == "baixa":
        score_ajustado = score - 5
        delay = 2
        exigencia = 0.05
    else:
        score_ajustado = score
        delay = 0
        exigencia = 0

    registrar_log(ativo, f"⚙️ Execução ajustada | Prioridade={prioridade} | Score={score} → {score_ajustado} | Delay={delay}s | Exigência extra={exigencia}", "executor_dinamico")

    return {
        "score_ajustado": score_ajustado,
        "delay": delay,
        "exigencia_extra": exigencia,
        "prioridade": prioridade
    }
