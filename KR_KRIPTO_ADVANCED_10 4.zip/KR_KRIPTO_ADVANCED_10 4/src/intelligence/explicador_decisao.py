import json
from datetime import datetime

def log_explicacao(ativo, score_raw, probabilidade, fatores, score_final, classe_final, modelo):
    """
    Gera log completo da decisão com detalhamento de fatores.
    """
    explicacao = {
        "timestamp": datetime.utcnow().isoformat(),
        "ativo": ativo,
        "modelo": modelo,
        "score_raw": round(score_raw, 4),
        "probabilidade": round(probabilidade, 4),
        "score_final": round(score_final, 4),
        "classe_final": classe_final,
        "fatores_ativados": fatores
    }

    log_line = json.dumps(explicacao, ensure_ascii=False)
    
    with open("log_explicacoes.txt", "a") as f:
        f.write(log_line + "\n")

    return log_line
