
import pandas as pd
import joblib
import os
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import accuracy_score
from inteligencia.log_por_ativo import registrar_log

HISTORICO_PATH = "historico_sinais.csv"
MODELO_PATH = "modelo_decisor_ia.pkl"
SCALER_PATH = "scaler_decisor_ia.pkl"

def rodar_feedback_engine():
    try:
        if not os.path.exists(HISTORICO_PATH) or not os.path.exists(MODELO_PATH):
            registrar_log("GERAL", "⚠️ Histórico ou modelo não encontrado para feedback.", "feedback_engine", "WARN")
            return

        df = pd.read_csv(HISTORICO_PATH, on_bad_lines='skip')
        df = df.dropna(subset=["score", "probabilidade", "fakeout_detectado", "resultado_5_candles"])

        df["classe_decisao"] = df["resultado_5_candles"].apply(lambda x: 1 if x > 0 else 0)

        features = ["score", "probabilidade", "fakeout_detectado", "previsao_lstm", "book_imbalance", "rejeicao_institucional", "atr"]
        for col in features:
            if col not in df.columns:
                df[col] = 0.0 if col != "rejeicao_institucional" else 0

        df["fakeout_detectado"] = df["fakeout_detectado"].astype(int)
        df["rejeicao_institucional"] = df["rejeicao_institucional"].astype(int)

        X = df[features]
        y = df["classe_decisao"]

        scaler = MinMaxScaler()
        X_scaled = scaler.fit_transform(X)
        joblib.dump(scaler, SCALER_PATH)

        model = joblib.load(MODELO_PATH)
        model.partial_fit(X_scaled, y)

        joblib.dump(model, MODELO_PATH)

        y_pred = model.predict(X_scaled)
        acuracia = round(accuracy_score(y, y_pred), 4)

        registrar_log("GERAL", f"🧠 Feedback aplicado com sucesso. Acurácia pós-ajuste: {acuracia}", "feedback_engine")

        return {
            "status": "ok",
            "acuracia": acuracia,
            "quantidade_amostras": len(df)
        }

    except Exception as e:
        registrar_log("GERAL", f"❌ Erro ao aplicar feedback: {e}", "feedback_engine", "ERROR")
        return {"erro": str(e)}
