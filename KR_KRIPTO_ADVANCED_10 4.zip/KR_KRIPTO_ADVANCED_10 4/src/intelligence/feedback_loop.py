
import pandas as pd
import os
from datetime import datetime
from strategies.reforco import ajustar_pesos_inteligente
from inteligencia.log_por_ativo import registrar_log

def rodar_feedback_loop(caminho="historico_sinais.csv", salvar_log=True):
    try:
        if not os.path.exists(caminho):
            registrar_log("GERAL", "❌ Arquivo histórico não encontrado para feedback.")
            return {"status": "erro", "motivo": "arquivo_inexistente"}

        df = pd.read_csv(caminho, on_bad_lines='skip').dropna()

        if "timestamp" in df.columns:
            df = df.sort_values(by="timestamp")

        sinais = df[
            (df['classe_prevista'].isin(['compra', 'venda'])) &
            (df['score_final'] > 0) &
            (df['resultado_5_candles'] != 0)
        ]

        if len(sinais) == 0:
            registrar_log("GERAL", "⚠️ Nenhum sinal com resultado real para feedback.")
            return {"status": "vazio", "sinais_processados": 0}

        acertos = sinais[
            ((sinais['classe_prevista'] == 'compra') & (sinais['resultado_5_candles'] > 0)) |
            ((sinais['classe_prevista'] == 'venda') & (sinais['resultado_5_candles'] < 0))
        ]

        erros = sinais[
            ((sinais['classe_prevista'] == 'compra') & (sinais['resultado_5_candles'] < 0)) |
            ((sinais['classe_prevista'] == 'venda') & (sinais['resultado_5_candles'] > 0))
        ]

        taxa_acerto = round(len(acertos) / len(sinais), 4)
        taxa_erro = round(len(erros) / len(sinais), 4)

        msg_resumo = f"📈 Feedback Loop: {len(acertos)} acertos | {len(erros)} erros | Taxa acerto: {taxa_acerto*100:.2f}%"
        registrar_log("GERAL", msg_resumo)
        registrar_log("GERAL", "🔄 Recalibrando pesos com base nos erros analisados...")

        ajustar_pesos_inteligente(taxa_acerto=taxa_acerto, taxa_erro=taxa_erro)

        if salvar_log:
            log_csv = "logs/feedback_loop.csv"
            if not os.path.exists("logs"):
                os.makedirs("logs")
            pd.DataFrame([{
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "acertos": len(acertos),
                "erros": len(erros),
                "taxa_acerto": taxa_acerto,
                "taxa_erro": taxa_erro
            }]).to_csv(log_csv, mode="a", header=not os.path.exists(log_csv), index=False)

        return {
            "status": "ok",
            "acertos": len(acertos),
            "erros": len(erros),
            "taxa_acerto": taxa_acerto,
            "taxa_erro": taxa_erro,
            "total": len(sinais)
        }

    except Exception as e:
        registrar_log("GERAL", f"❌ Erro no feedback_loop: {e}")
        return {"status": "erro", "motivo": str(e)}
