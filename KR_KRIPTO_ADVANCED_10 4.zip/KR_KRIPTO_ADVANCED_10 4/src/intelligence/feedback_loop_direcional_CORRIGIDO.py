
import pandas as pd
import os
from strategies.reforco import ajustar_pesos_inteligente
from inteligencia.log_por_ativo import registrar_log

def rodar_feedback_loop(caminho="historico_sinais.csv"):
    try:
        if not os.path.exists(caminho):
            registrar_log("GERAL", "❌ Arquivo histórico não encontrado.", "feedback_loop_direcional", "ERROR")
            return

        df = pd.read_csv(caminho, on_bad_lines='skip').dropna()
        sinais = df[
            (df["classe_prevista"].isin(["compra", "venda"])) &
            (df["score_final"] > 0) &
            (df["resultado_5_candles"] != 0)
        ]

        if sinais.empty:
            registrar_log("GERAL", "⚠️ Nenhum sinal com resultado real para feedback.", "feedback_loop_direcional")
            return

        acertos = sinais[
            ((sinais["classe_prevista"] == "compra") & (sinais["resultado_5_candles"] > 0)) |
            ((sinais["classe_prevista"] == "venda") & (sinais["resultado_5_candles"] < 0))
        ]

        erros = sinais[
            ((sinais["classe_prevista"] == "compra") & (sinais["resultado_5_candles"] < 0)) |
            ((sinais["classe_prevista"] == "venda") & (sinais["resultado_5_candles"] > 0))
        ]

        taxa_acerto = round(len(acertos) / len(sinais), 2)
        taxa_erro = round(len(erros) / len(sinais), 2)

        registrar_log("GERAL", f"📈 Feedback Loop: {len(acertos)} acertos | {len(erros)} erros | Taxa acerto: {taxa_acerto*100:.1f}%", "feedback_loop_direcional")

        if len(erros) >= 1:
            registrar_log("GERAL", "🔄 Recalibrando pesos com base nos erros analisados...", "feedback_loop_direcional")
            ajustar_pesos_inteligente()

        return {
            "sinais_processados": len(sinais),
            "acertos": len(acertos),
            "erros": len(erros),
            "taxa_acerto": taxa_acerto
        }

    except Exception as e:
        registrar_log("GERAL", f"❌ Erro no feedback loop direcional: {e}", "feedback_loop_direcional", "ERROR")
        return {"erro": str(e)}
