
import pandas as pd
from inteligencia.log_por_ativo import registrar_log

def detectar_rejeicao(df, index=-1, rejeicao_threshold=0.5):
    try:
        candle = df.iloc[index]
        corpo = abs(candle['close'] - candle['open'])
        sombra = abs(candle['high'] - candle['low'])

        if sombra == 0:
            return False

        proporcao_corpo = corpo / sombra
        return proporcao_corpo < rejeicao_threshold
    except Exception as e:
        return False

def detectar_volume_anormal(df, index=-1, fator=2.0):
    try:
        volume_atual = df.iloc[index]['volume']
        media_volume = df['volume'].iloc[index-10:index].mean()
        return volume_atual > media_volume * fator
    except Exception:
        return False

def detectar_fakeout(df, index=-1, n=5):
    try:
        candle = df.iloc[index]
        max_ultimos = df['high'].iloc[index-n:index].max()
        min_ultimos = df['low'].iloc[index-n:index].min()

        breakout = candle['high'] > max_ultimos or candle['low'] < min_ultimos
        reversao = candle['close'] < candle['open'] if candle['high'] > max_ultimos else candle['close'] > candle['open']
        return breakout and reversao
    except Exception:
        return False

def validar_filtro_institucional(df, index=-1, ativo="BTCUSDT", pesos=None):
    try:
        pesos = pesos or {"rejeicao": 1, "volume": 1, "fakeout": 1}
        rejeicao = detectar_rejeicao(df, index)
        volume_anormal = detectar_volume_anormal(df, index)
        fakeout = detectar_fakeout(df, index)

        score = 0
        motivos = []

        if rejeicao:
            score += pesos["rejeicao"]
            motivos.append("rejeição institucional")
        if volume_anormal:
            score += pesos["volume"]
            motivos.append("volume anormal")
        if fakeout:
            score += pesos["fakeout"]
            motivos.append("fakeout detectado")

        status = score >= 2  # Requer no mínimo 2 confirmações para considerar relevante

        if status:
            registrar_log(ativo, f"🛡️ Filtro institucional ativado. Motivos: {', '.join(motivos)}", "filtros_institucionais")
        else:
            registrar_log(ativo, f"✅ Nenhum filtro institucional relevante. Score={score}", "filtros_institucionais")

        return {
            "bloquear": status,
            "score_filtro": score,
            "motivos": motivos
        }

    except Exception as e:
        registrar_log(ativo, f"❌ Erro nos filtros institucionais: {e}", "filtros_institucionais", "ERROR")
        return {
            "bloquear": False,
            "erro": str(e)
        }
