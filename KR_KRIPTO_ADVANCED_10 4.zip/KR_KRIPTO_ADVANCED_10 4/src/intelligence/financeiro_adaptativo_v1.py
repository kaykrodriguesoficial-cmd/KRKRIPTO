
# inteligencia/financeiro_adaptativo_v1.py

from core.curva_capital.gestor_capital import obter_lucro_total_ativo

def ajustar_agressividade_por_capital(score, ativo):
    """
    Ajusta dinamicamente o score mínimo exigido com base no desempenho de capital do ativo.
    """
    try:
        lucro_total = obter_lucro_total_ativo(ativo)

        if lucro_total > 100:  # Ativo está lucrativo, liberar mais agressividade
            return score * 0.95
        elif lucro_total < -50:  # Ativo está em prejuízo, exigir score mais alto
            return score * 1.1
        else:  # Neutro
            return score

    except Exception as e:
        print(f"[FINANCEIRO] Erro ao ajustar agressividade: {e}")
        return score
