
def votar_decisao_tatica(criterios, pesos=None, limiar=0.5):
    """
    Executa uma votação ponderada com base nos critérios táticos fornecidos.
    Cada critério é um valor numérico entre -1 e 1. Pesos ajustam sua influência.
    """
    if pesos is None:
        pesos = {
            "score": 0.25,
            "probabilidade": 0.20,
            "entropia": -0.20,
            "feedback": 0.15,
            "simulacao": 0.10,
            "macro": 0.10
        }

    score_total = 0.0
    peso_total = 0.0

    for k, v in criterios.items():
        peso = pesos.get(k, 0.0)
        score_total += v * peso
        peso_total += abs(peso)

    if peso_total == 0:
        return False

    resultado = score_total / peso_total
    return resultado >= limiar
