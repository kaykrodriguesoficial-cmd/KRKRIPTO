
import pandas as pd
import os
import traceback
from inteligencia.log_por_ativo import registrar_log

LOG_VOTACAO_PATH = "logs/log_votacao.csv"
RELATORIO_ANALISE_PATH = "logs/relatorio_analise_logs.csv"

def analisar_logs_e_aprender():
    if not os.path.exists(LOG_VOTACAO_PATH):
        registrar_log("GERAL", "⚠️ Nenhum log de votação encontrado para análise.", "ia_analitica_logs", "WARN")
        return

    try:
        df = pd.read_csv(LOG_VOTACAO_PATH, on_bad_lines='skip')
        if 'classe_prevista' not in df.columns or 'classe_real' not in df.columns:
            registrar_log("GERAL", "❌ Colunas essenciais ausentes no log de votação.", "ia_analitica_logs", "ERROR")
            return

        df['acertou'] = df['classe_prevista'] == df['classe_real']
        taxa_acerto_total = round(df['acertou'].mean(), 4)

        erros_por_hora = df[~df['acertou']].groupby('hora').size().to_dict()
        erros_por_ativo = df[~df['acertou']].groupby('ativo').size().to_dict()

        analise = {
            "taxa_acerto_total": taxa_acerto_total,
            "erros_por_hora": erros_por_hora,
            "erros_por_ativo": erros_por_ativo
        }

        pd.DataFrame.from_dict(analise, orient='index').to_csv(RELATORIO_ANALISE_PATH)
        registrar_log("GERAL", f"📊 Análise concluída. Acurácia global: {taxa_acerto_total:.2%}", "ia_analitica_logs")

        # SUGESTÕES TÁTICAS (para futura IA):
        if taxa_acerto_total < 0.5:
            registrar_log("GERAL", "⚠️ Taxa de acerto abaixo do ideal. Reforço de pesos sugerido.", "ia_analitica_logs", "WARN")
        if len(erros_por_hora) > 0:
            hora_critica = max(erros_por_hora, key=erros_por_hora.get)
            registrar_log("GERAL", f"🕒 Hora com mais erros: {hora_critica}", "ia_analitica_logs")
        if len(erros_por_ativo) > 0:
            ativo_critico = max(erros_por_ativo, key=erros_por_ativo.get)
            registrar_log("GERAL", f"⚠️ Ativo com mais erros: {ativo_critico}", "ia_analitica_logs")

        return analise

    except Exception as e:
        registrar_log("GERAL", f"❌ Erro na análise dos logs: {e}", "ia_analitica_logs", "ERROR")
        traceback.print_exc()
        return {"erro": str(e)}
