
import pandas as pd
from collections import Counter
import os
from inteligencia.log_por_ativo import registrar_log

def analisar_erros_log(caminho="log_erros.txt", ativo="GERAL"):
    if not os.path.exists(caminho):
        msg = "🚫 Nenhum log encontrado para análise."
        registrar_log(ativo, msg)
        return

    with open(caminho, "r") as f:
        linhas = f.readlines()

    erros = [linha.strip().split(":")[0] for linha in linhas if "Erro" in linha]
    contagem = Counter(erros)

    registrar_log(ativo, f"🧠 Autoanálise de erros — Top {len(contagem)} categorias")
    for erro, qtd in contagem.most_common(10):
        registrar_log(ativo, f"🔸 {erro}: {qtd} ocorrências")

def avaliar_desempenho_sinais(csv="historico_sinais.csv", ativo="GERAL"):
    if not os.path.exists(csv):
        msg = "📉 Nenhum histórico de sinais encontrado."
        registrar_log(ativo, msg)
        return

    df = pd.read_csv(csv)
    if "classe_prevista" not in df.columns or "resultado_5_candles" not in df.columns:
        msg = "⚠️ Dados incompletos para análise."
        registrar_log(ativo, msg)
        return

    df = df.dropna(subset=["classe_prevista", "resultado_5_candles"])
    df["acertou"] = df.apply(lambda x: (x["classe_prevista"] == "compra" and x["resultado_5_candles"] > 0) or
                                         (x["classe_prevista"] == "venda" and x["resultado_5_candles"] < 0), axis=1)
    taxa_acerto = df["acertou"].mean()
    registrar_log(ativo, f"🎯 Taxa de acerto histórica: {taxa_acerto*100:.2f}%")

    erros_criticos = df[df["acertou"] == False]
    registrar_log(ativo, f"💥 Total de sinais perdidos: {len(erros_criticos)}")
    for _, row in erros_criticos.tail(5).iterrows():
        registrar_log(ativo, f"❌ {row['timestamp']} | Classe: {row['classe_prevista']} | Resultado: {row['resultado_5_candles']}")
