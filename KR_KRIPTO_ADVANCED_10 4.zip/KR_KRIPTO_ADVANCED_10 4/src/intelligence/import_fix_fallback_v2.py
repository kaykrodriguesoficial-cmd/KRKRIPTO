#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Módulo de correção de importação para fallback_v2 no projeto KR_KRIPTO_ADVANCED.
Compatível com Mac M1 (ARM64) e ambientes Linux/Windows (x86_64).

Este módulo implementa um mecanismo robusto de importação que:
1. Tenta importar a versão v2 (híbrida com suporte a Mac M1)
2. Se falhar, tenta importar a versão original
3. Se todas falharem, cria um stub básico para evitar erros de execução

Uso:
    from src.intelligence.import_fix_fallback_v2 import GerenciadorFallback, is_mac_m1
"""

import os
import sys
import logging
import shutil
import importlib.util
import platform
from typing import Dict, Any, Optional, List, Tuple, Callable, Union
from datetime import datetime, timedelta

# Configuração de logging
logger = logging.getLogger("kr_kripto_import_fix")

# Verificar se estamos em ambiente Mac M1
def is_mac_m1() -> bool:
    """Detecta se o ambiente de execução é um Mac com chip Apple Silicon (M1/M2/M3)."""
    return (
        platform.system() == "Darwin" and 
        platform.machine() == "arm64"
    )

# Variável global para controle de importação
FALLBACK_IMPORTED = False
FALLBACK_VERSION = None

# Lista de versões para tentar, em ordem de prioridade
versions_to_try = ["v2", ""]

for version in versions_to_try:
    # Pular iteração se já importou com sucesso
    if FALLBACK_IMPORTED:
        break
        
    suffix = f"_{version}" if version else ""
    
    try:
        # Primeiro tenta importar do caminho correto (src.core)
        module_path = f"src.core.fallback{suffix}"
            
        # Importar usando importlib para evitar problemas de cache
        if importlib.util.find_spec(module_path):
            module = importlib.import_module(module_path)
            GerenciadorFallback = module.GerenciadorFallback
                
            # Importar is_mac_m1 se disponível
            if hasattr(module, "is_mac_m1"):
                # Usar a função is_mac_m1 do módulo importado
                is_mac_m1_imported = module.is_mac_m1
            
            logger.info(f"GerenciadorFallback{suffix} importado com sucesso de {module_path}")
            FALLBACK_IMPORTED = True
            FALLBACK_VERSION = version if version else "original"
            break
    except ImportError:
        try:
            # Tenta caminho alternativo (src.infrastructure)
            module_path = f"src.infrastructure.fallback{suffix}"
                
            # Importar usando importlib para evitar problemas de cache
            if importlib.util.find_spec(module_path):
                module = importlib.import_module(module_path)
                GerenciadorFallback = module.GerenciadorFallback
                    
                # Importar is_mac_m1 se disponível
                if hasattr(module, "is_mac_m1"):
                    # Usar a função is_mac_m1 do módulo importado
                    is_mac_m1_imported = module.is_mac_m1
                
                logger.info(f"GerenciadorFallback{suffix} importado com sucesso de {module_path}")
                FALLBACK_IMPORTED = True
                FALLBACK_VERSION = version if version else "original"
                break
        except ImportError:
            # Se ainda falhar, tenta criar/copiar o arquivo
            try:
                # Adiciona o diretório atual ao path
                sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
                
                # Cria o diretório core se não existir
                core_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "src", "core")
                os.makedirs(core_dir, exist_ok=True)
                
                # Verifica se existe o arquivo fallback_v*.py
                target_file = os.path.join(core_dir, f"fallback{suffix}.py")
                
                # Se não existir o arquivo alvo, tenta encontrar em outros diretórios
                if not os.path.exists(target_file):
                    # Procurar em diretórios alternativos
                    alt_paths = [
                        os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "KR_KRIPTO_PATCH_HIBRIDO", "src", "core", f"fallback{suffix}.py"),
                        os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "KR_KRIPTO_PATCH_AMPLO", "src", "core", f"fallback{suffix}.py"),
                        os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "src", "infrastructure", f"fallback{suffix}.py"),
                    ]
                    
                    for alt_path in alt_paths:
                        if os.path.exists(alt_path):
                            shutil.copy2(alt_path, target_file)
                            logger.info(f"Copiado {alt_path} para {target_file}")
                            break
                
                # Tenta importar novamente após a correção
                if os.path.exists(target_file):
                    # Importar usando importlib para evitar problemas de cache
                    spec = importlib.util.spec_from_file_location(f"fallback{suffix}", target_file)
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    
                    GerenciadorFallback = module.GerenciadorFallback
                        
                    # Importar is_mac_m1 se disponível
                    if hasattr(module, "is_mac_m1"):
                        # Usar a função is_mac_m1 do módulo importado
                        is_mac_m1_imported = module.is_mac_m1
                    
                    logger.info(f"GerenciadorFallback{suffix} importado com sucesso após correção de arquivos")
                    FALLBACK_IMPORTED = True
                    FALLBACK_VERSION = version if version else "original"
                    break
                else:
                    logger.warning(f"Arquivo fallback{suffix}.py não encontrado.")
            except Exception as e:
                logger.error(f"Erro ao tentar importar GerenciadorFallback{suffix}: {e}")

# Se nenhuma versão foi importada com sucesso, cria um stub em memória
if not FALLBACK_IMPORTED:
    logger.critical("Falha ao importar GerenciadorFallback. Usando implementação stub em memória.")
    
    class GerenciadorFallback:
        """Stub para GerenciadorFallback quando nenhuma implementação real está disponível."""
        
        def __init__(self, config=None, operador_binance=None):
            self.config = config or {}
            self.operador_binance = operador_binance
            self.falhas = {}
            self.circuit_breakers = {}
            self.status = {"status": "STUB", "circuit_breaker": False, "componentes": {}}
            self.modelos_fallback = {"default": {"tipo": "stub", "criado_em": datetime.now()}}
            logger.warning("STUB EM MEMÓRIA: GerenciadorFallback inicializado, mas módulo real não encontrado.")
        
        def registrar_falha(self, componente, erro=None, detalhes=None):
            logger.warning(f"STUB EM MEMÓRIA: registrar_falha chamado para componente {componente}")
            return False
        
        def verificar_circuit_breaker(self, componente):
            logger.warning(f"STUB EM MEMÓRIA: verificar_circuit_breaker chamado para componente {componente}")
            return False
        
        def obter_status(self):
            logger.warning("STUB EM MEMÓRIA: obter_status chamado")
            self.status["timestamp"] = datetime.now().isoformat()
            return self.status
        
        def verificar_necessidade_de_rollback(self, metricas):
            logger.warning("STUB EM MEMÓRIA: verificar_necessidade_de_rollback chamado")
            return False
        
        def obter_modelo_fallback(self, nome_modelo=None):
            logger.warning(f"STUB EM MEMÓRIA: obter_modelo_fallback chamado para modelo {nome_modelo}")
            return self.modelos_fallback["default"]
        
        def salvar_modelo_fallback(self, nome_modelo, modelo):
            logger.warning(f"STUB EM MEMÓRIA: salvar_modelo_fallback chamado para modelo {nome_modelo}")
            return True
        
        def verificar_recursos_sistema(self):
            logger.warning("STUB EM MEMÓRIA: verificar_recursos_sistema chamado")
            return {"erro": "stub", "timestamp": datetime.now().isoformat()}
        
        def registrar_watchdog(self, tarefa_id, intervalo_segundos, callback, args=None, kwargs=None):
            logger.warning(f"STUB EM MEMÓRIA: registrar_watchdog chamado para tarefa {tarefa_id}")
            return True
        
        def verificar_watchdogs(self):
            logger.warning("STUB EM MEMÓRIA: verificar_watchdogs chamado")
            return {}
        
        def monitorar_modelo(self, modelo_id, metricas, limiar_alerta=0.3):
            logger.warning(f"STUB EM MEMÓRIA: monitorar_modelo chamado para modelo {modelo_id}")
            return {"status": "OK", "alertas": 0}

# Exportar informações sobre a importação
def get_fallback_info() -> Dict[str, Any]:
    """Retorna informações sobre a importação do GerenciadorFallback."""
    return {
        "imported": FALLBACK_IMPORTED,
        "version": FALLBACK_VERSION,
        "is_mac_m1": is_mac_m1(),
        "is_stub": FALLBACK_VERSION is None
    }

# Função para criar uma instância de GerenciadorFallback
def create_fallback_manager(config: Optional[Dict[str, Any]] = None, operador_binance=None) -> GerenciadorFallback:
    """
    Cria uma instância de GerenciadorFallback com a configuração fornecida.
    
    Args:
        config: Configuração opcional para o GerenciadorFallback
        operador_binance: Instância do OperadorBinance para interações com a exchange
        
    Returns:
        Instância de GerenciadorFallback
    """
    return GerenciadorFallback(config, operador_binance)

# Instância global para uso direto
fallback_manager = create_fallback_manager()
