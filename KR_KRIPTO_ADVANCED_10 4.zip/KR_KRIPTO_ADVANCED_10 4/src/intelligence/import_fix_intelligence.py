#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Módulo de correção de importações para o projeto KR_KRIPTO_ADVANCED.
Versão específica para corrigir referências de 'inteligencia' para 'intelligence'.

Este módulo identifica e corrige arquivos que tentam importar do módulo 'inteligencia'
(incorreto) para importar do módulo 'intelligence' (correto).
"""

import os
import sys
import re
import logging
import shutil
import subprocess
from datetime import datetime

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("kr_kripto_import_fix_intelligence")

def find_files_with_inteligencia_import(directory):
    """
    Encontra arquivos que contêm importações do módulo 'inteligencia'.
    
    Args:
        directory: Diretório raiz para iniciar a busca
        
    Returns:
        Lista de caminhos de arquivos que contêm importações de 'inteligencia'
    """
    files_with_import = []
    
    # Padrões de importação a procurar
    patterns = [
        r'from\s+inteligencia\s+import',
        r'from\s+src\.inteligencia\s+import',
        r'import\s+inteligencia\.',
        r'import\s+src\.inteligencia\.'
    ]
    
    # Compilar padrões regex
    compiled_patterns = [re.compile(pattern) for pattern in patterns]
    
    # Percorrer diretórios e arquivos
    for root, dirs, files in os.walk(directory):
        # Ignorar diretórios __pycache__ e .git
        if '__pycache__' in dirs:
            dirs.remove('__pycache__')
        if '.git' in dirs:
            dirs.remove('.git')
        
        # Verificar arquivos Python
        for file in files:
            if file.endswith('.py'):
                file_path = os.path.join(root, file)
                
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        
                        # Verificar se algum padrão corresponde
                        for pattern in compiled_patterns:
                            if pattern.search(content):
                                files_with_import.append(file_path)
                                logger.info(f"Arquivo com importação 'inteligencia' encontrado: {file_path}")
                                break
                except Exception as e:
                    logger.error(f"Erro ao ler arquivo {file_path}: {e}")
    
    return files_with_import

def fix_imports_in_file(file_path):
    """
    Corrige importações de 'inteligencia' para 'intelligence' em um arquivo.
    
    Args:
        file_path: Caminho do arquivo a ser corrigido
        
    Returns:
        True se o arquivo foi corrigido, False caso contrário
    """
    try:
        # Criar backup do arquivo
        backup_path = f"{file_path}.bak_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        shutil.copy2(file_path, backup_path)
        logger.info(f"Backup criado: {backup_path}")
        
        # Ler conteúdo do arquivo
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Substituir importações
        new_content = re.sub(r'from\s+inteligencia\b', 'from intelligence', content)
        new_content = re.sub(r'from\s+src\.inteligencia\b', 'from src.intelligence', new_content)
        new_content = re.sub(r'import\s+inteligencia\.', 'import intelligence.', new_content)
        new_content = re.sub(r'import\s+src\.inteligencia\.', 'import src.intelligence.', new_content)
        
        # Verificar se houve alterações
        if new_content != content:
            # Escrever conteúdo corrigido
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(new_content)
            
            logger.info(f"Arquivo corrigido: {file_path}")
            return True
        else:
            logger.info(f"Nenhuma correção necessária em: {file_path}")
            return False
    
    except Exception as e:
        logger.error(f"Erro ao corrigir arquivo {file_path}: {e}")
        return False

def create_compatibility_symlink():
    """
    Cria um link simbólico de 'inteligencia' para 'intelligence' para compatibilidade.
    
    Returns:
        True se o link foi criado, False caso contrário
    """
    try:
        # Determinar o diretório raiz do projeto
        current_dir = os.path.dirname(os.path.abspath(__file__))
        src_dir = os.path.dirname(current_dir)
        
        # Caminhos dos diretórios
        intelligence_dir = os.path.join(src_dir, "intelligence")
        inteligencia_dir = os.path.join(src_dir, "inteligencia")
        
        # Verificar se o diretório intelligence existe
        if not os.path.exists(intelligence_dir):
            logger.error(f"Diretório intelligence não encontrado: {intelligence_dir}")
            return False
        
        # Remover diretório inteligencia se existir
        if os.path.exists(inteligencia_dir):
            if os.path.islink(inteligencia_dir):
                os.unlink(inteligencia_dir)
                logger.info(f"Link simbólico removido: {inteligencia_dir}")
            else:
                shutil.rmtree(inteligencia_dir)
                logger.info(f"Diretório removido: {inteligencia_dir}")
        
        # Criar link simbólico
        os.symlink(intelligence_dir, inteligencia_dir)
        logger.info(f"Link simbólico criado: {inteligencia_dir} -> {intelligence_dir}")
        
        return True
    
    except Exception as e:
        logger.error(f"Erro ao criar link simbólico: {e}")
        return False

def clean_python_cache():
    """
    Limpa os caches Python (__pycache__) para garantir que as alterações sejam aplicadas.
    
    Returns:
        True se o cache foi limpo, False caso contrário
    """
    try:
        # Determinar o diretório raiz do projeto
        current_dir = os.path.dirname(os.path.abspath(__file__))
        src_dir = os.path.dirname(current_dir)
        project_root = os.path.dirname(src_dir)
        
        # Encontrar e remover diretórios __pycache__
        for root, dirs, files in os.walk(project_root):
            if '__pycache__' in dirs:
                pycache_dir = os.path.join(root, "__pycache__")
                shutil.rmtree(pycache_dir)
                logger.info(f"Cache removido: {pycache_dir}")
        
        # Limpar cache de importação
        for module_name in list(sys.modules.keys()):
            if module_name.startswith("src.") or module_name.startswith("inteligencia.") or module_name.startswith("intelligence."):
                del sys.modules[module_name]
                logger.info(f"Módulo removido do cache: {module_name}")
        
        return True
    
    except Exception as e:
        logger.error(f"Erro ao limpar cache Python: {e}")
        return False

def fix_imports():
    """
    Função principal para corrigir importações.
    
    Returns:
        Dicionário com resultados da correção
    """
    logger.info("Iniciando correção de importações 'inteligencia' -> 'intelligence'")
    
    # Determinar o diretório raiz do projeto
    current_dir = os.path.dirname(os.path.abspath(__file__))
    src_dir = os.path.dirname(current_dir)
    project_root = os.path.dirname(src_dir)
    
    # Resultados
    results = {
        "arquivos_encontrados": 0,
        "arquivos_corrigidos": 0,
        "link_simbolico_criado": False,
        "cache_limpo": False
    }
    
    # Encontrar arquivos com importações de 'inteligencia'
    files_with_import = find_files_with_inteligencia_import(project_root)
    results["arquivos_encontrados"] = len(files_with_import)
    
    # Corrigir importações em cada arquivo
    for file_path in files_with_import:
        if fix_imports_in_file(file_path):
            results["arquivos_corrigidos"] += 1
    
    # Criar link simbólico para compatibilidade
    results["link_simbolico_criado"] = create_compatibility_symlink()
    
    # Limpar cache Python
    results["cache_limpo"] = clean_python_cache()
    
    logger.info("Correção de importações concluída")
    logger.info(f"Arquivos encontrados: {results['arquivos_encontrados']}")
    logger.info(f"Arquivos corrigidos: {results['arquivos_corrigidos']}")
    logger.info(f"Link simbólico criado: {results['link_simbolico_criado']}")
    logger.info(f"Cache limpo: {results['cache_limpo']}")
    
    return results

if __name__ == "__main__":
    results = fix_imports()
    
    print("\nResultados da correção de importações:")
    print(f"Arquivos encontrados: {results['arquivos_encontrados']}")
    print(f"Arquivos corrigidos: {results['arquivos_corrigidos']}")
    print(f"Link simbólico criado: {results['link_simbolico_criado']}")
    print(f"Cache limpo: {results['cache_limpo']}")
    
    print("\nInstruções para verificar a correção:")
    print("1. Execute o sistema principal:")
    print("   python main.py --max-runtime 30 --debug")
    print("2. Verifique se o erro 'No module named inteligencia' não aparece mais")
    print("3. Verifique se o sistema não está mais usando o ModelPerformanceTrackerStub")
