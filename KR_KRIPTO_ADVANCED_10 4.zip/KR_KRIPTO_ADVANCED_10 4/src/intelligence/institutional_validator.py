import sys
import os

# Adiciona o diretório raiz do projeto (pai de 'src') ao sys.path
# Isso garante que 'from src.core...' funcione corretamente
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

import logging
import pandas as pd
from typing import Dict, Any, Tuple

# Importar a função de validação do core
try:
    from src.core.filtros_institucionais import validar_filtro_institucional
    FILTROS_CORE_AVAILABLE = True
except ImportError as e:
    # Log detalhado do erro de importação, incluindo o sys.path atual
    logging.getLogger(__name__).critical(f"Falha CRÍTICA ao importar validar_filtro_institucional de src.core.filtros_institucionais: {e}. Current sys.path: {sys.path}")
    FILTROS_CORE_AVAILABLE = False
    # Definir um stub para a função se a importação falhar
    def validar_filtro_institucional(df: pd.DataFrame, ativo: str, pesos: dict | None = None) -> tuple[bool, str]:
        logging.getLogger(__name__).error("STUB: validar_filtro_institucional chamado, mas módulo core não encontrado devido a ImportError.")
        return True, "STUB: Filtro Institucional Indisponível (ImportError)"

logger = logging.getLogger(__name__)

class InstitutionalValidator:
    """Classe wrapper para os filtros institucionais, em conformidade com a interface esperada."""

    def __init__(self, config: dict):
        self.config = config
        self.validator_config = self.config.get("institutional_validator_config", self.config.get("filtros_institucionais_config", {}))
        self.pesos = self.validator_config.get("pesos", {"rejeicao": 1, "volume": 1, "fakeout": 1})
        logger.info(f"InstitutionalValidator inicializado com pesos: {self.pesos}")
        if not FILTROS_CORE_AVAILABLE:
            logger.error("InstitutionalValidator está usando uma função stub devido à falha na importação de src.core.filtros_institucionais.")

    def validate(self, df_sinal: pd.DataFrame, ativo: str, **kwargs) -> Tuple[bool, str]:
        """Executa a validação institucional para um sinal.

        Args:
            df_sinal: DataFrame contendo os dados do kline para o sinal.
            ativo: O símbolo do ativo (ex: 'BTCUSDT').
            **kwargs: Argumentos adicionais (não usados diretamente aqui, mas podem ser úteis para extensões).

        Returns:
            Tuple[bool, str]: (is_valid, reason)
        """
        if not FILTROS_CORE_AVAILABLE:
            logger.warning(f"[{ativo}] Validação institucional pulada (módulo core indisponível). Retornando válido por padrão.")
            return True, "Validação Institucional Indisponível (Core Ausente)"
        
        try:
            is_valid, reason = validar_filtro_institucional(df_sinal, ativo, self.pesos)
            return is_valid, reason
        except Exception as e:
            logger.error(f"[{ativo}] Erro inesperado durante a validação institucional: {e}", exc_info=True)
            return True, f"Erro Interno no Validador Institucional: {e}" # Fail open

# Exemplo de como poderia ser usado (para referência, não para execução direta aqui):
# if __name__ == '__main__':
#     # Configuração de logging básica para teste
#     logging.basicConfig(level=logging.INFO)
#     test_config = {
#         "institutional_validator_config": {
#             "pesos": {"rejeicao": 1, "volume": 1, "fakeout": 1}
#         }
#     }
#     validator = InstitutionalValidator(config=test_config)
#     # Criar um DataFrame de exemplo
#     data = {
#         'Open': [10, 11, 12, 10, 9],
#         'High': [12, 12, 13, 11, 10],
#         'Low': [9, 10, 11, 9, 8],
#         'Close': [11, 12, 10, 9, 9.5],
#         'Volume': [100, 150, 120, 200, 300]
#     }
#     sample_df = pd.DataFrame(data)
#     is_valid, reason = validator.validate(sample_df, "BTCUSDT")
#     logger.info(f"Resultado da validação de exemplo: Válido={is_valid}, Razão='{reason}'")

