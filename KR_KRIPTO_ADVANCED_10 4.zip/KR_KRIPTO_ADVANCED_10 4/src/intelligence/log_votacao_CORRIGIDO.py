
import os
import pandas as pd
from datetime import datetime
from inteligencia.log_por_ativo import registrar_log

def logar_votacao(ativo, score_final, classe_heuristica, classe_lstm, classe_soberana, prob_soberana, decisao_final, resultado_5_candles=None):
    try:
        os.makedirs("log_votacao", exist_ok=True)
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        dados = {
            "timestamp": [timestamp],
            "ativo": [ativo],
            "score_final": [score_final],
            "classe_heuristica": [classe_heuristica],
            "classe_lstm": [classe_lstm],
            "classe_soberana": [classe_soberana],
            "probabilidade_soberana": [prob_soberana],
            "decisao_final": [decisao_final],
            "resultado_5_candles": [resultado_5_candles]
        }

        df = pd.DataFrame(dados)

        # Arquivo por ativo
        caminho_ativo = f"log_votacao/{ativo}.csv"
        df.to_csv(caminho_ativo, mode='a', header=not os.path.exists(caminho_ativo), index=False)

        # Arquivo consolidado global
        caminho_global = "log_votacao/log_votacao.csv"
        df.to_csv(caminho_global, mode='a', header=not os.path.exists(caminho_global), index=False)

        registrar_log(ativo, f"📝 Log de votação salvo com decisão={decisao_final}, score={score_final}, prob={prob_soberana:.2f}", "log_votacao")

        return True

    except Exception as e:
        registrar_log(ativo, f"❌ Erro ao registrar log de votação: {e}", "log_votacao", "ERROR")
        return False
