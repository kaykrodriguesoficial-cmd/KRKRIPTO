#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ModelLoader Inteligente com Análise Técnica Integrada
Versão aprimorada que usa análise técnica real quando modelos não estão disponíveis
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
from typing import Dict, Any, Optional, Tuple, List
import warnings
warnings.filterwarnings('ignore')

# Adicionar análise técnica ao path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

try:
    from analise_tecnica_basica import AnaliseTecnicaBasica, analisar_e_gerar_sinal
    ANALISE_TECNICA_DISPONIVEL = True
except ImportError as e:
    print(f"⚠️ Análise técnica não disponível: {e}")
    ANALISE_TECNICA_DISPONIVEL = False

logger = logging.getLogger("kr_kripto_model_loader")

class ModelLoader:
    """
    ModelLoader inteligente com análise técnica integrada
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger("kr_kripto_model_loader")
        self.models_dir = config.get("models_dir", "models")
        
        # Inicializar análise técnica
        if ANALISE_TECNICA_DISPONIVEL:
            self.analisador_tecnico = AnaliseTecnicaBasica(config)
            self.logger.info("🧠 ModelLoader com análise técnica inicializado")
        else:
            self.analisador_tecnico = None
            self.logger.warning("⚠️ ModelLoader sem análise técnica (fallback)")
        
        # Cache de modelos
        self.cache_modelos = {}
        
        # Estatísticas
        self.stats = {
            'modelos_carregados': 0,
            'analises_tecnicas': 0,
            'predicoes_stub': 0
        }
    
    def carregar_modelo(self, ativo: str, intervalo: str) -> Optional[Any]:
        """
        Carrega modelo para ativo e intervalo específicos
        """
        try:
            # Tentar carregar modelo real primeiro
            modelo_path = os.path.join(self.models_dir, ativo, f"{intervalo}.h5")
            
            if os.path.exists(modelo_path):
                # TODO: Implementar carregamento real de modelo TensorFlow/Keras
                self.logger.info(f"📊 Modelo encontrado para {ativo} ({intervalo}): {modelo_path}")
                self.stats['modelos_carregados'] += 1
                return self._carregar_modelo_real(modelo_path)
            else:
                self.logger.warning(f"Arquivo de modelo não encontrado para {ativo} ({intervalo}): {modelo_path}")
                
                # Tentar modelo genérico
                modelo_generico = os.path.join(self.models_dir, "generic", f"{intervalo}.h5")
                if os.path.exists(modelo_generico):
                    self.logger.info(f"📊 Usando modelo genérico para {ativo} ({intervalo})")
                    self.stats['modelos_carregados'] += 1
                    return self._carregar_modelo_real(modelo_generico)
                
                # Tentar outros intervalos para o mesmo ativo
                intervalos_alternativos = ["4h", "1d", "15m", "30m"]
                for intervalo_alt in intervalos_alternativos:
                    if intervalo_alt != intervalo:
                        modelo_alt = os.path.join(self.models_dir, ativo, f"{intervalo_alt}.h5")
                        if os.path.exists(modelo_alt):
                            self.logger.info(f"📊 Usando modelo alternativo {ativo} ({intervalo_alt}) para {intervalo}")
                            self.stats['modelos_carregados'] += 1
                            return self._carregar_modelo_real(modelo_alt)
                        else:
                            self.logger.warning(f"Arquivo de modelo não encontrado para {ativo} ({intervalo_alt}): {modelo_alt}")
                
                # Se chegou aqui, usar análise técnica ou stub
                if ANALISE_TECNICA_DISPONIVEL:
                    self.logger.info(f"🧠 Usando análise técnica para {ativo} ({intervalo})")
                    return ModeloAnaliseTecnica(ativo, intervalo, self.analisador_tecnico)
                else:
                    self.logger.warning(f"⚠️ Usando modelo stub para {ativo} ({intervalo})")
                    self.stats['predicoes_stub'] += 1
                    return ModeloStub(ativo, intervalo)
                    
        except Exception as e:
            self.logger.error(f"Erro ao carregar modelo para {ativo} ({intervalo}): {e}")
            if ANALISE_TECNICA_DISPONIVEL:
                return ModeloAnaliseTecnica(ativo, intervalo, self.analisador_tecnico)
            else:
                return ModeloStub(ativo, intervalo)
    
    def _carregar_modelo_real(self, modelo_path: str):
        """
        Carrega modelo real do arquivo (TensorFlow/Keras)
        """
        try:
            # TODO: Implementar carregamento real
            # import tensorflow as tf
            # modelo = tf.keras.models.load_model(modelo_path)
            # return ModeloReal(modelo)
            
            # Por enquanto, retornar stub até implementar carregamento real
            self.logger.warning(f"Carregamento real de modelo ainda não implementado: {modelo_path}")
            return ModeloStub("modelo_real", "1h")
            
        except Exception as e:
            self.logger.error(f"Erro ao carregar modelo real: {e}")
            return ModeloStub("erro", "1h")
    
    def obter_estatisticas(self) -> Dict:
        """
        Retorna estatísticas do ModelLoader
        """
        return self.stats.copy()


class ModeloAnaliseTecnica:
    """
    Modelo que usa análise técnica para gerar predições
    """
    
    def __init__(self, ativo: str, intervalo: str, analisador: AnaliseTecnicaBasica):
        self.ativo = ativo
        self.intervalo = intervalo
        self.analisador = analisador
        self.logger = logging.getLogger(f"modelo_analise_tecnica_{ativo}")
        
    def predict(self, dados) -> Tuple[float, float]:
        """
        Gera predição baseada em análise técnica
        """
        try:
            # Converter dados para formato adequado
            if isinstance(dados, list):
                df_klines = pd.DataFrame(dados)
            elif isinstance(dados, pd.DataFrame):
                df_klines = dados
            else:
                self.logger.error(f"Formato de dados não suportado: {type(dados)}")
                return 0.5, 0.5
            
            # Realizar análise técnica
            resultado = analisar_e_gerar_sinal(df_klines, self.analisador.config)
            
            acao = resultado['acao']
            confianca = resultado['confianca']
            motivo = resultado['motivo']
            analise = resultado['analise']
            
            # Converter ação para predição numérica
            if acao == 'COMPRAR':
                predicao = 0.7 + (confianca - 0.5) * 0.6  # 0.7 a 1.0
            elif acao == 'VENDER':
                predicao = 0.3 - (confianca - 0.5) * 0.6  # 0.0 a 0.3
            else:  # MANTER
                predicao = 0.4 + (confianca - 0.5) * 0.4  # 0.3 a 0.7
            
            # Garantir que está no range [0, 1]
            predicao = max(0.0, min(1.0, predicao))
            
            # Log detalhado
            rsi = analise.get('rsi', 50)
            tendencia = analise.get('tendencia', 'INDEFINIDA')
            volatilidade = analise.get('volatilidade', 0.02)
            
            self.logger.info(f"🧠 Análise técnica para {self.ativo}: RSI={rsi:.1f}, Tendência={tendencia}, Volatilidade={volatilidade:.3f}")
            self.logger.info(f"🎯 Sinal gerado: {acao} | Predição: {predicao:.4f} | Confiança: {confianca:.4f} | Motivo: {motivo}")
            
            return predicao, confianca
            
        except Exception as e:
            self.logger.error(f"Erro na predição com análise técnica: {e}")
            return 0.5, 0.5


class ModeloStub:
    """
    Modelo stub para fallback
    """
    
    def __init__(self, ativo: str, intervalo: str):
        self.ativo = ativo
        self.intervalo = intervalo
        self.logger = logging.getLogger(f"modelo_stub_{ativo}")
        
    def predict(self, dados) -> Tuple[float, float]:
        """
        Gera predição aleatória (stub)
        """
        import random
        predicao = random.uniform(0.3, 0.7)
        confianca = random.uniform(0.5, 0.6)
        
        self.logger.warning(f"⚠️ Usando predição stub para {self.ativo}: {predicao:.4f}")
        return predicao, confianca


# Função de conveniência para compatibilidade
def carregar_modelo(ativo: str, intervalo: str, config: Dict = None):
    """
    Função de conveniência para carregar modelo
    """
    if config is None:
        config = {}
    
    loader = ModelLoader(config)
    return loader.carregar_modelo(ativo, intervalo)


if __name__ == "__main__":
    # Teste básico
    print("ModelLoader com Análise Técnica carregado com sucesso!")
    
    # Teste de funcionalidade
    config = {"models_dir": "models"}
    loader = ModelLoader(config)
    
    # Simular dados de teste
    dados_teste = [[1629360000000, 45000, 46000, 44000, 45500, 1000] for _ in range(100)]
    
    modelo = loader.carregar_modelo("BTCUSDT", "1h")
    if modelo:
        predicao, confianca = modelo.predict(dados_teste)
        print(f"Teste: Predição={predicao:.4f}, Confiança={confianca:.4f}")
