
import json
import os
import pandas as pd
from datetime import datetime
from inteligencia.log_por_ativo import registrar_log

CAMINHO_JSON = "memoria_performance.json"
CAMINHO_CSV = "logs/memoria_performance.csv"

os.makedirs("logs", exist_ok=True)

def carregar_memoria():
    if not os.path.exists(CAMINHO_JSON):
        return {}
    try:
        with open(CAMINHO_JSON, "r") as f:
            return json.load(f)
    except Exception as e:
        print(f"⚠️ Erro ao carregar memória: {e}")
        return {}

def resetar_memoria(ativo):
    memoria = carregar_memoria()
    if ativo in memoria:
        del memoria[ativo]
        with open(CAMINHO_JSON, "w") as f:
            json.dump(memoria, f, indent=4)
        registrar_log(ativo, "🧹 Memória de performance resetada.", "memoria_performance")

def atualizar_memoria(ativo, score, classe_prevista, classe_real, lucro, prob):
    memoria = carregar_memoria()

    if ativo not in memoria:
        memoria[ativo] = {
            "score_medio": 0.0,
            "lucro_total": 0.0,
            "sinais": 0,
            "acertos": 0,
            "erros": 0,
            "probabilidade_media": 0.0,
            "ultima_atualizacao": ""
        }

    m = memoria[ativo]
    m["sinais"] += 1
    m["lucro_total"] += lucro
    m["score_medio"] = round((m["score_medio"] * (m["sinais"] - 1) + score) / m["sinais"], 4)
    m["probabilidade_media"] = round((m["probabilidade_media"] * (m["sinais"] - 1) + prob) / m["sinais"], 4)
    m["ultima_atualizacao"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    if classe_prevista == classe_real:
        m["acertos"] += 1
    else:
        m["erros"] += 1

    memoria[ativo] = m

    with open(CAMINHO_JSON, "w") as f:
        json.dump(memoria, f, indent=4)

    df_log = pd.DataFrame([{
        "timestamp": m["ultima_atualizacao"],
        "ativo": ativo,
        "score": score,
        "probabilidade": prob,
        "lucro": lucro,
        "classe_prevista": classe_prevista,
        "classe_real": classe_real,
        "acerto": classe_prevista == classe_real
    }])
    df_log.to_csv(CAMINHO_CSV, mode="a", header=not os.path.exists(CAMINHO_CSV), index=False)

    registrar_log(ativo, f"📊 Memória atualizada | ScoreM={m['score_medio']:.2f} | PnL={lucro:.2f} | Acertos={m['acertos']} | Sinais={m['sinais']}", "memoria_performance")
