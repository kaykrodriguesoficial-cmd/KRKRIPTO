
def prever_proxima_janela(df):
    """
    Mock de predição LSTM baseada em padrão de fechamento recente.
    A ser substituído por modelo real com aprendizado supervisionado.
    """
    try:
        df = df.tail(10).copy()
        media_diff = df["close"].diff().mean()
        if media_diff > 0.01:
            return "UP"
        elif media_diff < -0.01:
            return "DOWN"
        else:
            return "LATERAL"
    except:
        return "INDEFINIDO"
