
import numpy as np
import pandas as pd
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from sklearn.preprocessing import MinMaxScaler

# Modelo global (mock inicial, pode ser substituído por modelo treinado real)
modelo_lstm = None
scaler = MinMaxScaler()

def treinar_lstm_tatico(dados):
    """
    Treina um modelo LSTM real com base nos dados históricos.
    Espera colunas: ['close', 'score', 'entropia', 'feedback', 'regime_id', 'label']
    """
    global modelo_lstm, scaler

    dados = dados.dropna()
    if len(dados) < 100:
        raise ValueError("Dados insuficientes para treinamento")

    features = ['close', 'score', 'entropia', 'feedback', 'regime_id']
    X = scaler.fit_transform(dados[features])
    y = dados['label'].values

    X_seq = np.array([X[i-10:i] for i in range(10, len(X))])
    y_seq = y[10:]

    modelo_lstm = Sequential([
        LSTM(64, input_shape=(X_seq.shape[1], X_seq.shape[2]), return_sequences=False),
        Dropout(0.2),
        Dense(1, activation='sigmoid')
    ])
    modelo_lstm.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    modelo_lstm.fit(X_seq, y_seq, epochs=10, batch_size=16, verbose=0)

def prever_com_lstm(df):
    """
    Retorna probabilidade de acerto com base na janela recente.
    """
    global modelo_lstm, scaler

    if modelo_lstm is None or len(df) < 10:
        return 0.5  # Neutro

    df = df.tail(10).copy()
    features = ['close', 'score', 'entropia', 'feedback', 'regime_id']
    if not all(f in df.columns for f in features):
        return 0.5

    X = scaler.transform(df[features])
    X_seq = np.expand_dims(X, axis=0)
    pred = modelo_lstm.predict(X_seq, verbose=0)[0][0]
    return float(pred)
