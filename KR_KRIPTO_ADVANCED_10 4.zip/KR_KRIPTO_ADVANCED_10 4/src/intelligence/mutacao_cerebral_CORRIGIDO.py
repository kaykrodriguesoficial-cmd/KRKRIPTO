
import joblib
import numpy as np
import pandas as pd
import os
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
from datetime import datetime
from inteligencia.log_por_ativo import registrar_log

LOG_MUTACOES = "logs/log_mutacoes.csv"

def mutar_e_testar_cerebro(modelo_atual, X_treino, y_treino, X_teste, y_teste, caminho_salvar, ativo="GERAL"):
    try:
        mutacoes = []
        resultados = []

        for i in range(5):
            mutado = MLPClassifier(
                hidden_layer_sizes=(100 + i * 20,),
                activation='relu',
                solver='adam',
                max_iter=500,
                random_state=i
            )
            mutado.fit(X_treino, y_treino)
            y_pred = mutado.predict(X_teste)
            acc = accuracy_score(y_teste, y_pred)
            mutacoes.append((mutado, acc, i))
            resultados.append({
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "ativo": ativo,
                "tipo": "mutacao",
                "random_state": i,
                "acc": round(acc, 4)
            })

        mutacoes.sort(key=lambda x: x[1], reverse=True)
        melhor_mutante, melhor_acc, seed_vencedora = mutacoes[0]

        modelo_atual.fit(X_treino, y_treino)
        acc_atual = accuracy_score(y_teste, modelo_atual.predict(X_teste))

        log_resultado = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "ativo": ativo,
            "tipo": "comparacao",
            "acc_mutante": round(melhor_acc, 4),
            "acc_atual": round(acc_atual, 4),
            "mutacao_aceita": melhor_acc > acc_atual
        }

        registrar_log(ativo, f"🧬 Mutação testada. Atual={acc_atual:.4f}, Mutante={melhor_acc:.4f}", "mutacao_cerebral")

        if melhor_acc > acc_atual:
            registrar_log(ativo, f"✅ Mutação aceita (Seed {seed_vencedora}). Modelo atualizado!", "mutacao_cerebral")
            joblib.dump(melhor_mutante, caminho_salvar)
        else:
            registrar_log(ativo, f"❌ Mutação rejeitada. Mutante não superou o modelo atual.", "mutacao_cerebral")

        # Salvar log
        df_log = pd.DataFrame(resultados + [log_resultado])
        os.makedirs("logs", exist_ok=True)
        df_log.to_csv(LOG_MUTACOES, mode="a", header=not os.path.exists(LOG_MUTACOES), index=False)

        return log_resultado

    except Exception as e:
        registrar_log(ativo, f"❌ Erro na mutação cerebral: {e}", "mutacao_cerebral", "ERROR")
        return {"erro": str(e)}
