# src/data_providers/news_provider.py

"""Provedor de dados para buscar notícias da API CryptoPanic (Etapa 021)."""

import asyncio
import logging
from typing import Optional, List, Dict, Any

import aiohttp

logger = logging.getLogger(__name__)

# Flag to indicate availability (used in signal_processor)
NEWS_PROVIDER_AVAILABLE = True

class NewsProvider:
    """Busca e processa notícias da API CryptoPanic."""

    BASE_URL = "https://cryptopanic.com/api/v1/posts/"

    def __init__(self, config: dict):
        """Inicializa o provedor de notícias.

        Args:
            config: Dicionário de configuração global (espera-se que contenha 'cryptopanic_api_token').
            session: Uma sessão aiohttp.ClientSession existente (opcional).
        """
        self.api_token = config.get("cryptopanic_api_token")
        if not self.api_token:
            logger.warning("[NewsProvider] Token da API CryptoPanic (cryptopanic_api_token) não encontrado na configuração. O provedor de notícias será desativado.")
            global NEWS_PROVIDER_AVAILABLE
            NEWS_PROVIDER_AVAILABLE = False # Disable if no token
        # Gerencia a sessão aiohttp internamente se não for fornecida
        self._session = None  # Inicializado sob demanda em _get_session()
        self._created_session = False

    async def _get_session(self) -> aiohttp.ClientSession:
        """Retorna a sessão aiohttp, criando uma se necessário."""
        if self._session is None:
            self._session = aiohttp.ClientSession()
            self._created_session = True
        return self._session

    async def close_session(self):
        """Fecha a sessão aiohttp se ela foi criada internamente."""
        if self._session and self._created_session:
            await self._session.close()
            self._session = None
            self._created_session = False

    async def get_recent_news_score(self, currency: str) -> float:
        """Busca notícias recentes para uma moeda e calcula um score de sentimento.

        Args:
            currency: Símbolo da moeda (ex: "BTC").

        Returns:
            Um score normalizado entre -1 (muito negativo) e 1 (muito positivo),
            ou 0.5 (neutro) em caso de erro, sem notícias ou sem votos.
        """
        if not self.api_token or not NEWS_PROVIDER_AVAILABLE:
            return 0.5 # Retorna neutro se desativado

        # Formata o símbolo para a API (ex: BTC)
        currency_filter = currency.replace("USDT", "") # Remove USDT se presente

        params = {
            "auth_token": self.api_token,
            "public": "true",
            "currencies": currency_filter,
            "kind": "news", # Focar em notícias
            # "filter": "rising" # Opcional: focar em notícias com votos crescentes?
        }

        total_positive_votes = 0
        total_negative_votes = 0

        try:
            session = await self._get_session()
            logger.debug(f"[NewsProvider] Buscando notícias para {currency_filter}...")
            async with session.get(self.BASE_URL, params=params, timeout=10) as response:
                # Log status for debugging
                logger.debug(f"[NewsProvider] API Status para {currency_filter}: {response.status}")
                response.raise_for_status() # Levanta exceção para status >= 400
                data = await response.json()
                results = data.get("results", [])
                
                if not results:
                    logger.info(f"[NewsProvider] Nenhuma notícia encontrada para {currency_filter}. Retornando score neutro.")
                    return 0.5

                for news_item in results:
                    votes = news_item.get("votes", {})
                    total_positive_votes += votes.get("positive", 0)
                    total_negative_votes += votes.get("negative", 0)
                
                logger.debug(f"[NewsProvider] Votos para {currency_filter}: Pos={total_positive_votes}, Neg={total_negative_votes}")

                total_votes = total_positive_votes + total_negative_votes
                if total_votes == 0:
                    logger.info(f"[NewsProvider] Nenhuma votação encontrada para notícias de {currency_filter}. Retornando score neutro.")
                    return 0.5 # Score neutro se não houver votos

                # Calcula score bruto (0 a 1)
                raw_score = total_positive_votes / total_votes
                # Normaliza para -1 a 1
                scaled_score = (raw_score * 2) - 1
                logger.info(f"[NewsProvider] Score calculado para {currency_filter}: {scaled_score:.3f} (Raw: {raw_score:.3f})")
                return scaled_score

        except aiohttp.ClientResponseError as e:
            logger.error(f"[NewsProvider] Erro ao buscar notícias para {currency_filter}: Status {e.status} - {e.message}", exc_info=True)
            return 0.5 # Retorna neutro em caso de erro de API
        except aiohttp.ClientError as e:
            logger.error(f"[NewsProvider] Erro ao buscar notícias da API CryptoPanic (aiohttp) para {currency_filter}: {e}", exc_info=True)
            return 0.5
        except asyncio.TimeoutError:
            logger.error(f"[NewsProvider] Timeout ao buscar notícias da API CryptoPanic para {currency_filter}.", exc_info=True)
            return 0.5
        except Exception as e:
            logger.error(f"[NewsProvider] Erro inesperado ao processar notícias para {currency_filter}: {e}", exc_info=True)
            return 0.5

    # O método get_recent_news_count pode ser mantido ou removido se não for mais necessário
    async def get_recent_news_count(self, currencies: List[str]) -> int:
        """Busca notícias recentes para as moedas especificadas e retorna a contagem.
           (Mantido para compatibilidade ou uso futuro, mas get_recent_news_score é o principal agora)
        """
        # ... (implementação anterior mantida) ...
        if not self.api_token or not NEWS_PROVIDER_AVAILABLE:
            return 0
        if not currencies:
            return 0
        currency_filter = ",".join([c.replace("USDT", "") for c in currencies])
        params = {
            "auth_token": self.api_token,
            "public": "true",
            "currencies": currency_filter,
            "kind": "news",
        }
        try:
            session = await self._get_session()
            async with session.get(self.BASE_URL, params=params, timeout=10) as response:
                response.raise_for_status()
                data = await response.json()
                count = len(data.get("results", []))
                logger.debug(f"[NewsProvider] Encontradas {count} notícias recentes para {currency_filter}.")
                return count
        except Exception as e:
            logger.error(f"[NewsProvider] Erro em get_recent_news_count: {e}", exc_info=True)
            return 0

# Exemplo de uso (para teste rápido)
async def main_test():
    # Simula config e token
    # IMPORTANTE: Substitua 'SEU_TOKEN_AQUI' pelo seu token real para testar
    test_config = {"cryptopanic_api_token": "SEU_TOKEN_AQUI"} 
    provider = NewsProvider(config={})
    
    if not provider.api_token or provider.api_token == "SEU_TOKEN_AQUI":
        logger.warning("Token da API não configurado. Edite news_provider.py para testar.")
        await provider.close_session()
        return

    # Testar get_recent_news_score
    score_btc = await provider.get_recent_news_score("BTC")
    logger.info(f"Score de notícias para BTC: {score_btc}")

    score_eth = await provider.get_recent_news_score("ETH")
    logger.info(f"Score de notícias para ETH: {score_eth}")
    
    score_ada = await provider.get_recent_news_score("ADA")
    logger.info(f"Score de notícias para ADA: {score_ada}")

    # Testar get_recent_news_count (opcional)
    # count_btc = await provider.get_recent_news_count(["BTC"])
    # print(f"Notícias recentes para BTC: {count_btc}")

    await provider.close_session() # Fecha a sessão criada internamente

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO) # Changed to INFO for cleaner test output
    asyncio.run(main_test())

