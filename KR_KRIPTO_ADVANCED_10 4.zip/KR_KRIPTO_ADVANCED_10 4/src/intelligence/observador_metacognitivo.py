from datetime import datetime
import pandas as pd
import os

LOG_CAMINHO = "log_decisoes_erradas.csv"

def avaliar_erro(score_final, classe_prevista, classe_real):
    """Calcula penalidade com base no erro entre a classe prevista e real."""
    erro = int(classe_prevista != classe_real)
    penalidade = round(erro * abs(score_final), 3)
    return penalidade


def registrar_erro_metacognitivo(ativo, timestamp, score_final, classe_prevista, classe_real):
    """Registra a decisão incorreta para análises futuras e retreinamento."""
    penalidade = avaliar_erro(score_final, classe_prevista, classe_real)
    registro = {
        "timestamp": timestamp,
        "ativo": ativo,
        "classe_prevista": classe_prevista,
        "classe_real": classe_real,
        "score_final": score_final,
        "penalidade": penalidade,
    }

    if not os.path.exists(LOG_CAMINHO):
        pd.DataFrame(columns=registro.keys()).to_csv(LOG_CAMINHO, index=False)

    df_log = pd.read_csv(LOG_CAMINHO)
    df_log = pd.concat([df_log, pd.DataFrame([registro])])
    df_log.to_csv(LOG_CAMINHO, index=False)

    return penalidade
