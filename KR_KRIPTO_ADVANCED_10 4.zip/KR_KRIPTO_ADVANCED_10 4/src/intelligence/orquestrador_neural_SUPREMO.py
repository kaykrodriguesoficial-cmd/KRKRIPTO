
# orquestrador_neural_SUPREMO.py

import time
from datetime import datetime, timedelta
from inteligencia.detectores.divergencia_detector import detectar_divergencia
from inteligencia.memoria.memoria_estrategica import obter_memoria_estrategica
from inteligencia.mutacoes.mutacao_cerebral import atualizar_ensemble
from inteligencia.validadores.validador_cerebros import avaliar_cerebros
from inteligencia.feedback_loop import obter_resultado_5_candles
from inteligencia.detectores.armadilha_institucional import detectar_armadilha

ultimo_sinal = {}
pesos_dinamicos = {
    "score": 1.0,
    "prob": 1.0,
    "fakeout": 1.0,
    "divergencia": 1.0,
    "memoria": 1.0
}


def orquestrar_decisao(ativo, df, score, probabilidade, fakeout, contexto, regime):
    agora = datetime.now()

    # Cooldown por ativo
    if ativo in ultimo_sinal:
        if agora - ultimo_sinal[ativo] < timedelta(minutes=2):
            return False

    divergencia = detectar_divergencia(df)
    memoria = obter_memoria_estrategica(ativo) or {}
    memoria_score = memoria.get("score_medio", 0.5)
    memoria_prob = memoria.get("prob_medio", 0.5)

    # Score adaptativo com pesos dinâmicos
    score_composto = (
        score * pesos_dinamicos["score"] +
        probabilidade * pesos_dinamicos["prob"] +
        (1.0 - fakeout) * pesos_dinamicos["fakeout"] +
        divergencia * pesos_dinamicos["divergencia"] +
        memoria_score * pesos_dinamicos["memoria"]
    ) / sum(pesos_dinamicos.values())

    # Validação de armadilha oculta institucional
    if detectar_armadilha(df, ativo, contexto):
        print(f"[ORQUESTRAÇÃO] ⚠️ Armadilha detectada para {ativo}, sinal abortado.")
        return False

    # Decisão final
    decisao = score_composto >= 0.65
    if decisao:
        ultimo_sinal[ativo] = agora
        atualizar_pesos_com_feedback(ativo)
        return True
    return False


def atualizar_pesos_com_feedback(ativo):
    resultado = obter_resultado_5_candles(ativo)
    if resultado is None:
        return

    if resultado > 0:
        # Reforçar pesos que contribuíram para acerto
        pesos_dinamicos["score"] *= 1.05
        pesos_dinamicos["prob"] *= 1.05
        pesos_dinamicos["memoria"] *= 1.03
    else:
        # Penalizar em caso de erro
        pesos_dinamicos["fakeout"] *= 1.1
        pesos_dinamicos["divergencia"] *= 1.1

    # Normalizar pesos
    total = sum(pesos_dinamicos.values())
    for k in pesos_dinamicos:
        pesos_dinamicos[k] /= total

    # Evoluir ensemble se muitos erros consecutivos
    avaliar_cerebros()
    atualizar_ensemble()
