
import os
import json
from collections import defaultdict
from inteligencia.log_por_ativo import registrar_log

CAMINHO_PESOS = "inteligencia/pesos_dinamicos_memoria.json"

# Pesos padrões
pesos_iniciais = {
    "lstm": 1.0,
    "heuristico": 1.0,
    "orderflow": 1.0
}

def carregar_pesos():
    if not os.path.exists(CAMINHO_PESOS):
        return {}
    try:
        with open(CAMINHO_PESOS, "r") as f:
            return json.load(f)
    except Exception as e:
        registrar_log("GLOBAL", f"⚠️ Erro ao carregar pesos: {e}", "pesos_dinamicos", "ERROR")
        return {}

def salvar_pesos(dados):
    try:
        with open(CAMINHO_PESOS, "w") as f:
            json.dump(dados, f, indent=4)
    except Exception as e:
        registrar_log("GLOBAL", f"❌ Erro ao salvar pesos: {e}", "pesos_dinamicos", "ERROR")

def atualizar_pesos(ativo, contexto, desempenho):
    # desempenho = {"lstm": acertos, "heuristico": acertos, "orderflow": acertos}
    pesos = carregar_pesos()
    chave = f"{ativo}_{contexto}"

    if chave not in pesos:
        pesos[chave] = dict(pesos_iniciais)

    total = sum(desempenho.values()) or 1.0
    for k in desempenho:
        pesos[chave][k] = round(desempenho[k] / total, 3)

    salvar_pesos(pesos)
    registrar_log(ativo, f"🔁 Pesos atualizados ({contexto}): {pesos[chave]}", "pesos_dinamicos")

def get_pesos_atualizados(ativo, contexto):
    pesos = carregar_pesos()
    chave = f"{ativo}_{contexto}"
    if chave in pesos:
        registrar_log(ativo, f"📦 Pesos carregados ({contexto}): {pesos[chave]}", "pesos_dinamicos")
        return pesos[chave]
    return dict(pesos_iniciais)

def resetar_pesos(ativo=None):
    if not os.path.exists(CAMINHO_PESOS):
        return
    pesos = carregar_pesos()
    if ativo:
        novas_chaves = [k for k in pesos if not k.startswith(ativo)]
        pesos = {k: pesos[k] for k in novas_chaves}
        registrar_log(ativo, "🔄 Pesos resetados para esse ativo", "pesos_dinamicos")
    else:
        pesos = {}
        registrar_log("GLOBAL", "🧹 Todos os pesos foram resetados", "pesos_dinamicos")
    salvar_pesos(pesos)
