import pandas as pd
import os

LOG_CAMINHO = "historico_sinais.csv"

def calcular_prioridade_ativos(caminho=LOG_CAMINHO, ultimos_n=100):
    if not os.path.exists(caminho):
        return {}

    df = pd.read_csv(caminho)
    df = df[df["classe_real"].notna() & df["classe_prevista"].notna()]
    df = df.sort_values(by="timestamp", ascending=False).head(ultimos_n)

    ativos = df["ativo"].unique()
    ranking = {}

    for ativo in ativos:
        subset = df[df["ativo"] == ativo]
        if len(subset) < 10:
            continue

        acuracia = (subset["classe_prevista"] == subset["classe_real"]).sum() / len(subset)
        lucro_total = subset["lucro"].sum()
        freq_sinais = len(subset)

        score = round((acuracia * 0.4 + (lucro_total / 100) * 0.4 + freq_sinais / ultimos_n * 0.2), 4)

        ranking[ativo] = {
            "acuracia": round(acuracia, 4),
            "lucro_total": round(lucro_total, 2),
            "freq": freq_sinais,
            "score_prioridade": score
        }

    return dict(sorted(ranking.items(), key=lambda x: x[1]["score_prioridade"], reverse=True))
