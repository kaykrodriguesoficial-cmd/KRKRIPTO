
import os
import json
from inteligencia.log_por_ativo import registrar_log
from datetime import datetime
import pandas as pd

ARQUIVO_PROFIT = "memorias/profit_guard.json"
ARQUIVO_LOG = "logs/profit_guard.csv"
LIMITE_PERDA_PCT = -0.30  # Limite de queda de 30% a partir do lucro máximo

os.makedirs("memorias", exist_ok=True)
os.makedirs("logs", exist_ok=True)

def carregar_dados():
    if os.path.exists(ARQUIVO_PROFIT):
        try:
            with open(ARQUIVO_PROFIT, "r") as f:
                return json.load(f)
        except Exception as e:
            registrar_log("GLOBAL", f"⚠️ Erro ao carregar profit_guard: {e}", "profit_guard", "ERROR")
            return {}
    return {}

def salvar_dados(dados):
    try:
        with open(ARQUIVO_PROFIT, "w") as f:
            json.dump(dados, f, indent=4)
    except Exception as e:
        registrar_log("GLOBAL", f"❌ Erro ao salvar profit_guard: {e}", "profit_guard", "ERROR")

def resetar_profit_guard(ativo=None):
    dados = carregar_dados()
    if ativo:
        if ativo in dados:
            del dados[ativo]
            registrar_log(ativo, "🔄 Profit guard resetado para esse ativo", "profit_guard")
    else:
        dados = {}
        registrar_log("GLOBAL", "🧹 Profit guard resetado globalmente", "profit_guard")
    salvar_dados(dados)

def registrar_lucro(ativo, lucro):
    dados = carregar_dados()
    if ativo not in dados:
        dados[ativo] = {
            "lucro_total": 0,
            "max_lucro": 0,
            "ativo_pausado": False
        }

    dados[ativo]["lucro_total"] += lucro

    if dados[ativo]["lucro_total"] > dados[ativo]["max_lucro"]:
        dados[ativo]["max_lucro"] = dados[ativo]["lucro_total"]

    drawdown = dados[ativo]["lucro_total"] - dados[ativo]["max_lucro"]
    if drawdown < LIMITE_PERDA_PCT * max(1, abs(dados[ativo]["max_lucro"])):
        dados[ativo]["ativo_pausado"] = True
        registrar_log(ativo, f"🛑 ATIVO PAUSADO | Drawdown={drawdown:.2f}", "profit_guard")
    else:
        if dados[ativo]["ativo_pausado"]:
            registrar_log(ativo, "✅ ATIVO REATIVADO", "profit_guard")
        dados[ativo]["ativo_pausado"] = False

    salvar_dados(dados)

    # Log externo
    df = pd.DataFrame([{
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "ativo": ativo,
        "lucro_total": dados[ativo]["lucro_total"],
        "max_lucro": dados[ativo]["max_lucro"],
        "pausado": dados[ativo]["ativo_pausado"]
    }])
    df.to_csv(ARQUIVO_LOG, mode="a", header=not os.path.exists(ARQUIVO_LOG), index=False)

def pode_operar(ativo):
    dados = carregar_dados()
    if ativo not in dados:
        return True
    return not dados[ativo].get("ativo_pausado", False)
