
import numpy as np
import joblib
import os
from sklearn.preprocessing import StandardScaler
from inteligencia.log_por_ativo import registrar_log

CAMINHO_MODELO = "inteligencia/modelos/modelo_orderflow.pkl"
CAMINHO_SCALER = "inteligencia/modelos/scaler_orderflow.pkl"

try:
    modelo_orderflow = joblib.load(CAMINHO_MODELO)
    scaler_orderflow = joblib.load(CAMINHO_SCALER)
except Exception as e:
    modelo_orderflow = None
    scaler_orderflow = None
    print(f"❌ Erro ao carregar modelo/scaler de orderflow: {e}")

def avaliar_orderflow(book_data, ativo="GLOBAL"):
    try:
        if not modelo_orderflow or not scaler_orderflow:
            registrar_log(ativo, "⚠️ Modelo ou scaler não carregado.", "rede_orderflow", "ERROR")
            return 0.5  # neutro

        vetor = np.array([
            book_data.get("bid_volume", 0),
            book_data.get("ask_volume", 0),
            book_data.get("bid_price", 0),
            book_data.get("ask_price", 0),
            book_data.get("imbalance", 0),
        ]).reshape(1, -1)

        vetor_normalizado = scaler_orderflow.transform(vetor)
        score = modelo_orderflow.predict_proba(vetor_normalizado)[0][1]  # probabilidade de "compra"

        registrar_log(ativo, f"📊 OrderFlow score: {score:.4f}", "rede_orderflow")
        return round(score, 4)

    except Exception as e:
        registrar_log(ativo, f"❌ Erro em avaliar_orderflow: {e}", "rede_orderflow", "ERROR")
        return 0.5  # fallback neutro
