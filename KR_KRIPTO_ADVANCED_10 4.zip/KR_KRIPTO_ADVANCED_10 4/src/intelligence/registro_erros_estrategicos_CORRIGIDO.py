
import os
import pandas as pd
from datetime import datetime
from inteligencia.log_por_ativo import registrar_log

ERROS_PATH = "logs/erros_estrategicos.csv"

def registrar_erro_estrategico(tipo_erro, contexto, ativo, classe_ia, classe_real, score, probabilidade):
    try:
        if not os.path.exists("logs"):
            os.makedirs("logs")

        erro = {
            "data": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "tipo_erro": tipo_erro,
            "ativo": ativo,
            "classe_ia": classe_ia,
            "classe_real": classe_real,
            "score": score,
            "probabilidade": probabilidade,
            "hora": contexto.get("hora"),
            "direcao_hist": contexto.get("direcao_hist"),
            "memoria_score": contexto.get("memoria_score"),
            "book_imbalance": contexto.get("book_imbalance"),
            "zona_rejeicao": contexto.get("zona_rejeicao"),
            "prioridade_ativo": contexto.get("prioridade_ativo")
        }

        df = pd.DataFrame([erro])
        df.to_csv(ERROS_PATH, mode='a', header=not os.path.exists(ERROS_PATH), index=False)

        registrar_log(ativo, f"❗ Erro registrado: {tipo_erro} | Score={score} | IA={classe_ia} | Real={classe_real}", "registro_erros")

    except Exception as e:
        registrar_log("GLOBAL", f"❌ Falha ao registrar erro estratégico: {e}", "registro_erros", "ERROR")

def resetar_erros():
    try:
        if os.path.exists(ERROS_PATH):
            os.remove(ERROS_PATH)
            registrar_log("GLOBAL", "🧹 Erros estratégicos resetados", "registro_erros")
    except Exception as e:
        registrar_log("GLOBAL", f"❌ Erro ao resetar erros: {e}", "registro_erros", "ERROR")
