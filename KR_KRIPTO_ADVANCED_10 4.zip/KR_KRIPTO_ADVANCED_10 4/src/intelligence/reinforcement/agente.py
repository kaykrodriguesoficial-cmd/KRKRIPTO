"""
Módulo de compatibilidade para agentes de reinforcement learning.
Este arquivo serve como ponte para manter compatibilidade com importações de 'agente'.

Autor: Equipe KR_KRIPTO
Data: Junho 2025
Versão: 1.0
"""

# Importar classes de agente_rl.py
from src.intelligence.reinforcement.agente_rl import AgenteRL as AgenteRLTabular
from src.intelligence.reinforcement.agente_rl import RealAgenteRL

# Importar classes de agente_rl_avancado.py
from src.intelligence.reinforcement.agente_rl_avancado import AgenteRL as AgenteRLBase
from src.intelligence.reinforcement.agente_rl_avancado import AgenteDQN, AgentePPO

# Criar classe AgenteRL para compatibilidade direta
# Usar a implementação de agente_rl_avancado.py como base, pois é mais completa
AgenteRL = AgenteRLBase

# Definir __all__ para controlar o que é exportado
__all__ = [
    'AgenteRL',         # Classe principal que o sistema procura
    'AgenteRLTabular',  # Renomeado para evitar conflito
    'RealAgenteRL',
    'AgenteRLBase',     # Renomeado para evitar conflito
    'AgenteDQN',
    'AgentePPO'
]

# Log de inicialização
import logging
try:
    from src.utils.logger_config import setup_logger
    logger = setup_logger("reinforcement.agente")
except ImportError:
    # Fallback para logging padrão
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger("reinforcement.agente")

logger.info("Módulo de compatibilidade agente.py inicializado com sucesso")
