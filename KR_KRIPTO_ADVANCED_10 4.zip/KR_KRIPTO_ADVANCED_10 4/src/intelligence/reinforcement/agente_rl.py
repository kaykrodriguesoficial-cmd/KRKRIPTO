# src/intelligence/rl/agente_rl.py
import logging
import random
import numpy as np
import pickle
import os
from collections import defaultdict

logger = logging.getLogger("kr_kripto_rl_agent")

class AgenteRL:
    def __init__(self, ambiente, config=None, **kwargs):
        self.ambiente = ambiente
        self.config = config or {}
        self.extra = kwargs  # pode ser útil para rastrear parâmetros extras
        
        # Priorizar argumentos nomeados sobre config para compatibilidade com testes
        self.ativo = kwargs.get('ativo') or config.get('ativo', 'UNKNOWN')
        self.num_acoes = kwargs.get('num_acoes') or config.get('num_acoes', 3)
        self.acoes = list(range(self.num_acoes)) # 0: HOLD, 1: BUY, 2: SELL
        self.q_table_path = kwargs.get('q_table_path') or config.get('q_table_path', None)
        self.lr = kwargs.get('lr') or config.get('lr', 0.1) # Taxa de aprendizado
        self.gamma = kwargs.get('gamma') or config.get('gamma', 0.95) # Fator de desconto
        self.epsilon = kwargs.get('epsilon') or config.get('epsilon', 1.0) # Probabilidade de exploração
        self.epsilon_decay = kwargs.get('epsilon_decay') or config.get('epsilon_decay', 0.995)
        self.epsilon_min = kwargs.get('epsilon_min') or config.get('epsilon_min', 0.01)
        
        # Usar defaultdict para facilitar a criação de novas entradas na Q-table
        self.q_table = defaultdict(lambda: np.zeros(self.num_acoes))
        
        if self.q_table_path and os.path.exists(self.q_table_path):
            self.carregar_q_table()
            
        logger.info(f"[{self.ativo}] AgenteRL inicializado com {self.num_acoes} ações, lr={self.lr}, gamma={self.gamma}, epsilon={self.epsilon}.")

    def _discretizar_estado(self, estado):
        """Discretiza o estado contínuo (RSI, MACD_hist) em bins."""
        if estado is None:
            return None
            
        rsi = estado.get("rsi", 50) # Default to neutral if missing
        macd_hist = estado.get("macd_hist", 0) # Default to neutral if missing
        
        # Bins para RSI (exemplo: <20, 20-40, 40-60, 60-80, >=80)
        if rsi < 20:
            rsi_bin = 0
        elif rsi < 40:
            rsi_bin = 1
        elif rsi < 60:
            rsi_bin = 2
        elif rsi < 80:
            rsi_bin = 3
        else:
            rsi_bin = 4
            
        # Bins para MACD Hist (exemplo: < -0.001, -0.001 a 0.001, > 0.001)
        # Ajustar limites conforme necessário para a escala do seu MACD
        if macd_hist < -0.001:
            macd_bin = 0
        elif macd_hist <= 0.001:
            macd_bin = 1
        else:
            macd_bin = 2
            
        # Posição não incluída na discretização aqui, mas pode ser adicionada
        return (rsi_bin,)

    def escolher_acao(self, estado):
        """Escolhe uma ação usando a política epsilon-greedy."""
        logger.debug(f"[{self.ativo}] AgenteRL: escolher_acao chamado com estado {estado}.")
        estado_discreto = self._discretizar_estado(estado)
        
        if estado_discreto is None:
             logger.warning(f"[{self.ativo}] Estado inválido recebido, escolhendo HOLD.")
             return 0 # HOLD como ação segura

        if random.uniform(0, 1) < self.epsilon:
            acao = random.choice(self.acoes) # Exploração
            logger.debug(f"[{self.ativo}] Ação EXPLORATÓRIA: {acao}")
        else:
            acao = np.argmax(self.q_table[estado_discreto]) # Explotação
            logger.debug(f"[{self.ativo}] Ação EXPLOTADORA: {acao} (Q-values: {self.q_table[estado_discreto]})")
            
        return acao

    def aprender(self, estado, acao, recompensa, proximo_estado):
        """Atualiza a Q-table usando a equação de Bellman (Q-learning)."""
        logger.debug(f"[{self.ativo}] AgenteRL: aprender chamado com recompensa {recompensa}.")
        estado_discreto = self._discretizar_estado(estado)
        proximo_estado_discreto = self._discretizar_estado(proximo_estado)
        
        if estado_discreto is None:
            logger.warning(f"[{self.ativo}] Estado atual inválido, aprendizado ignorado.")
            return

        q_atual = self.q_table[estado_discreto][acao]
        
        # Se o próximo estado for inválido, consideramos o Q-value futuro como 0
        if proximo_estado_discreto is None:
            q_futuro_max = 0.0
            logger.debug(f"[{self.ativo}] Próximo estado inválido, Q-futuro considerado 0.")
        else:
            q_futuro_max = np.max(self.q_table[proximo_estado_discreto])
            logger.debug(f"[{self.ativo}] Q-futuro max para {proximo_estado_discreto}: {q_futuro_max}")

        # Equação de atualização do Q-learning
        q_novo = q_atual + self.lr * (recompensa + self.gamma * q_futuro_max - q_atual)
        self.q_table[estado_discreto][acao] = q_novo
        logger.debug(f"[{self.ativo}] Q-value para {estado_discreto}[{acao}] atualizado de {q_atual:.4f} para {q_novo:.4f}")

        # Decaimento do epsilon
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay
            # logger.debug(f"[{self.ativo}] Epsilon decaiu para {self.epsilon:.4f}")

    def salvar_q_table(self):
        """Salva a Q-table em um arquivo pickle."""
        if self.q_table_path:
            try:
                # Converter defaultdict para dict antes de salvar
                q_table_dict = dict(self.q_table)
                with open(self.q_table_path, "wb") as f:
                    pickle.dump(q_table_dict, f)
                logger.info(f"[{self.ativo}] Q-table salva em {self.q_table_path}")
            except Exception as e:
                logger.error(f"[{self.ativo}] Erro ao salvar Q-table: {e}")
        else:
            logger.warning(f"[{self.ativo}] Caminho da Q-table não definido, não foi possível salvar.")

    def carregar_q_table(self):
        """Carrega a Q-table de um arquivo pickle."""
        if self.q_table_path and os.path.exists(self.q_table_path):
            try:
                with open(self.q_table_path, "rb") as f:
                    q_table_dict = pickle.load(f)
                    # Converter dict carregado de volta para defaultdict
                    self.q_table = defaultdict(lambda: np.zeros(self.num_acoes), q_table_dict)
                logger.info(f"[{self.ativo}] Q-table carregada de {self.q_table_path}")
            except Exception as e:
                logger.error(f"[{self.ativo}] Erro ao carregar Q-table: {e}")
        else:
            logger.warning(f"[{self.ativo}] Arquivo Q-table não encontrado em {self.q_table_path}, iniciando com Q-table vazia.")

# Define a classe RealAgenteRL herdando de AgenteRL
class RealAgenteRL:
    def __init__(self, config=None):
        self.config = config or {}

    # Inicialmente, pode ser uma simples herança sem modificações adicionais.
    # Se houver lógica específica para RealAgenteRL, ela pode ser adicionada aqui.
    pass

