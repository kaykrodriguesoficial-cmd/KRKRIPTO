"""
Módulo de ambiente para reinforcement learning.
Implementação mínima para garantir operação contínua.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Any, Optional, Union
import logging

# Configurar logger
logger = logging.getLogger("kr_kripto_reinforcement")
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

class AmbienteRL:
    """Ambiente base para reinforcement learning."""
    
    def __init__(self, config: Dict[str, Any] = None):
        """Inicializa o ambiente de RL."""
        self.config = config or {}
        self.estado_atual = None
        self.recompensa_acumulada = 0.0
        self.historico_acoes = []
        self.historico_recompensas = []
        self.historico_estados = []
        self.episodio_atual = 0
        self.step_atual = 0
        self.done = False
        logger.info("AmbienteRL inicializado com sucesso")
    
    def reset(self) -> np.ndarray:
        """Reinicia o ambiente e retorna o estado inicial."""
        self.estado_atual = np.zeros(10)  # Estado padrão
        self.recompensa_acumulada = 0.0
        self.historico_acoes = []
        self.historico_recompensas = []
        self.historico_estados = []
        self.step_atual = 0
        self.done = False
        logger.info("Ambiente reiniciado")
        return self.estado_atual
    
    def step(self, acao: int) -> Tuple[np.ndarray, float, bool, Dict[str, Any]]:
        """Executa uma ação e retorna o próximo estado, recompensa, done e info."""
        self.historico_acoes.append(acao)
        
        # Simular próximo estado e recompensa
        proximo_estado = np.random.random(10)
        recompensa = 0.0
        
        if acao == 0:  # HOLD
            recompensa = 0.0
        elif acao == 1:  # BUY
            recompensa = 0.01
        elif acao == 2:  # SELL
            recompensa = -0.01
        
        self.estado_atual = proximo_estado
        self.historico_estados.append(proximo_estado)
        self.historico_recompensas.append(recompensa)
        self.recompensa_acumulada += recompensa
        self.step_atual += 1
        
        # Verificar se o episódio terminou
        if self.step_atual >= 100:
            self.done = True
            self.episodio_atual += 1
        
        info = {"acao": acao, "step": self.step_atual, "episodio": self.episodio_atual}
        return proximo_estado, recompensa, self.done, info
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """Retorna métricas de performance do ambiente."""
        return {
            "retorno_total": self.recompensa_acumulada,
            "retorno_anualizado": self.recompensa_acumulada * 252,
            "volatilidade": 0.0,
            "sharpe": 0.0,
            "max_drawdown": 0.0,
            "num_operacoes": len(self.historico_acoes),
            "acoes": {"buy": 0, "hold": 0, "sell": 0}
        }

class AmbienteRLAvancado(AmbienteRL):
    """Ambiente avançado para reinforcement learning."""
    
    def __init__(self, config: Dict[str, Any] = None):
        """Inicializa o ambiente avançado de RL."""
        super().__init__(config)
        self.dados = None
        self.indice_atual = 0
        self.janela = 10
        self.ativo = "BTCUSDT"
        self.ultima_acao = None
        self.portfolio_inicial = 1000.0
        self.portfolio_atual = 1000.0
        self.historico_portfolio = [self.portfolio_atual]
        logger.info("AmbienteRLAvancado inicializado com sucesso")
    
    def carregar_dados(self, dados: pd.DataFrame = None):
        """Carrega dados para o ambiente."""
        if dados is None:
            # Criar dados sintéticos se não fornecidos
            datas = pd.date_range(start="2023-01-01", periods=100, freq="h")
            precos = np.random.random(100) * 100 + 20000  # Preços de BTC simulados
            self.dados = pd.DataFrame({"timestamp": datas, "close": precos})
        else:
            self.dados = dados
        
        logger.info(f"Dados carregados: {len(self.dados)} registros")
        return self.dados
    
    def reset(self) -> np.ndarray:
        """Reinicia o ambiente e retorna o estado inicial."""
        if self.dados is None:
            self.carregar_dados()
        
        self.indice_atual = self.janela
        self.portfolio_atual = self.portfolio_inicial
        self.historico_portfolio = [self.portfolio_atual]
        self.ultima_acao = None
        self.recompensa_acumulada = 0.0
        self.historico_acoes = []
        self.historico_recompensas = []
        self.historico_estados = []
        self.step_atual = 0
        self.done = False
        
        # Obter estado inicial
        estado = self._obter_estado()
        self.estado_atual = estado
        self.historico_estados.append(estado)
        
        logger.info("Ambiente avançado reiniciado")
        return estado
    
    def _obter_estado(self) -> np.ndarray:
        """Obtém o estado atual baseado nos dados."""
        if self.indice_atual < self.janela:
            return np.zeros(self.janela)
        
        # Extrair janela de preços
        precos = self.dados["close"].iloc[self.indice_atual-self.janela:self.indice_atual].values
        
        # Normalizar preços
        if np.max(precos) > np.min(precos):
            precos_norm = (precos - np.min(precos)) / (np.max(precos) - np.min(precos))
        else:
            precos_norm = precos / precos[0]
        
        return precos_norm
    
    def step(self, acao: int) -> Tuple[np.ndarray, float, bool, Dict[str, Any]]:
        """Executa uma ação e retorna o próximo estado, recompensa, done e info."""
        if self.dados is None or self.indice_atual >= len(self.dados) - 1:
            self.done = True
            return self.estado_atual, 0.0, True, {"acao": acao, "razao": "sem_dados"}
        
        # Registrar ação
        self.historico_acoes.append(acao)
        self.ultima_acao = acao
        
        # Avançar para próximo passo
        self.indice_atual += 1
        self.step_atual += 1
        
        # Calcular retorno
        preco_anterior = self.dados["close"].iloc[self.indice_atual - 1]
        preco_atual = self.dados["close"].iloc[self.indice_atual]
        retorno = (preco_atual / preco_anterior) - 1
        
        # Calcular recompensa baseada na ação
        recompensa = 0.0
        if acao == 0:  # HOLD
            recompensa = 0.0
        elif acao == 1:  # BUY
            recompensa = retorno * 100  # Amplificar para treinamento
        elif acao == 2:  # SELL
            recompensa = -retorno * 100  # Amplificar para treinamento
        
        # Atualizar portfolio
        if acao == 1:  # BUY
            self.portfolio_atual *= (1 + retorno)
        elif acao == 2:  # SELL
            self.portfolio_atual *= (1 - retorno)
        
        self.historico_portfolio.append(self.portfolio_atual)
        self.historico_recompensas.append(recompensa)
        self.recompensa_acumulada += recompensa
        
        # Obter próximo estado
        proximo_estado = self._obter_estado()
        self.estado_atual = proximo_estado
        self.historico_estados.append(proximo_estado)
        
        # Verificar se episódio terminou
        if self.indice_atual >= len(self.dados) - 1:
            self.done = True
            self.episodio_atual += 1
        
        info = {
            "acao": acao,
            "preco": preco_atual,
            "retorno": retorno,
            "portfolio": self.portfolio_atual,
            "step": self.step_atual,
            "episodio": self.episodio_atual
        }
        
        return proximo_estado, recompensa, self.done, info
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """Retorna métricas de performance do ambiente avançado."""
        if len(self.historico_portfolio) < 2:
            return {
                "retorno_total": 0.0,
                "retorno_anualizado": 0.0,
                "volatilidade": 0.0,
                "sharpe": 0.0,
                "max_drawdown": 0.0,
                "num_operacoes": 0,
                "acoes": {"buy": 0, "hold": 0, "sell": 0}
            }
        
        # Calcular retorno total
        retorno_total = (self.historico_portfolio[-1] / self.historico_portfolio[0] - 1) * 100
        
        # Calcular retornos diários
        retornos = []
        for i in range(1, len(self.historico_portfolio)):
            retorno = self.historico_portfolio[i] / self.historico_portfolio[i-1] - 1
            retornos.append(retorno)
        
        # Calcular volatilidade
        volatilidade = 0.0
        if len(retornos) > 1:
            volatilidade = np.std(retornos) * 100
        
        # Calcular retorno anualizado
        retorno_anualizado = retorno_total * (252 / max(1, len(self.historico_portfolio)))
        
        # Calcular Sharpe Ratio (assumindo taxa livre de risco = 0)
        sharpe = 0
        if len(retornos) > 1 and np.std(retornos) > 0:
            sharpe = (np.mean(retornos) / np.std(retornos)) * np.sqrt(252)
        
        # Calcular máximo drawdown
        max_drawdown = 0
        peak = self.historico_portfolio[0]
        for valor in self.historico_portfolio:
            if valor > peak:
                peak = valor
            drawdown = (peak - valor) / peak
            if drawdown > max_drawdown:
                max_drawdown = drawdown
        
        # Contar operações por tipo
        acoes_count = {"buy": 0, "hold": 0, "sell": 0}
        for acao in self.historico_acoes:
            if acao == 0:
                acoes_count["hold"] += 1
            elif acao == 1:
                acoes_count["buy"] += 1
            elif acao == 2:
                acoes_count["sell"] += 1
        
        return {
            "retorno_total": retorno_total,
            "retorno_anualizado": retorno_anualizado,
            "volatilidade": volatilidade,
            "sharpe": sharpe,
            "max_drawdown": max_drawdown * 100,
            "num_operacoes": len(self.historico_acoes),
            "acoes": acoes_count
        }

class RealAmbienteRL:
    """Ambiente para reinforcement learning em tempo real."""
    
    def __init__(self, ativo: str = "BTCUSDT", config: Dict[str, Any] = None):
        """Inicializa o ambiente real de RL."""
        self.ativo = ativo
        self.config = config or {}
        self.estado_atual = np.zeros(10)
        self.ultima_acao = None
        self.portfolio_inicial = 1000.0
        self.portfolio_atual = 1000.0
        self.historico_portfolio = [self.portfolio_atual]
        self.historico_acoes = []
        self.historico_estados = []
        self.janela = 10
        self.dados_recentes = []
        logger.info(f"RealAmbienteRL inicializado para {ativo}")
    
    def obter_estado(self, dados_mercado: List[float] = None) -> np.ndarray:
        """Obtém o estado atual baseado nos dados de mercado."""
        if dados_mercado is not None:
            self.dados_recentes.append(dados_mercado[-1])  # Adicionar último preço
            
            # Manter apenas os últimos 'janela' dados
            if len(self.dados_recentes) > self.janela:
                self.dados_recentes = self.dados_recentes[-self.janela:]
        
        # Se não temos dados suficientes, retornar zeros
        if len(self.dados_recentes) < self.janela:
            return np.zeros(self.janela)
        
        # Normalizar dados
        dados = np.array(self.dados_recentes)
        if np.max(dados) > np.min(dados):
            dados_norm = (dados - np.min(dados)) / (np.max(dados) - np.min(dados))
        else:
            dados_norm = dados / dados[0]
        
        self.estado_atual = dados_norm
        self.historico_estados.append(dados_norm)
        return dados_norm
    
    def executar_acao(self, acao: int) -> Tuple[np.ndarray, float, Dict[str, Any]]:
        """Executa uma ação no ambiente real e retorna o próximo estado, recompensa e info."""
        self.historico_acoes.append(acao)
        self.ultima_acao = acao
        
        # Simular mudança no portfolio baseado na última ação
        if len(self.dados_recentes) >= 2:
            preco_anterior = self.dados_recentes[-2]
            preco_atual = self.dados_recentes[-1]
            retorno = (preco_atual / preco_anterior) - 1
            
            if acao == 1:  # BUY
                self.portfolio_atual *= (1 + retorno)
            elif acao == 2:  # SELL
                self.portfolio_atual *= (1 - retorno)
        else:
            retorno = 0.0
        
        self.historico_portfolio.append(self.portfolio_atual)
        
        # Calcular recompensa
        recompensa = 0.0
        if acao == 0:  # HOLD
            recompensa = 0.0
        elif acao == 1:  # BUY
            recompensa = retorno * 100
        elif acao == 2:  # SELL
            recompensa = -retorno * 100
        
        # Retornar próximo estado, recompensa e info
        proximo_estado = self.estado_atual
        
        return proximo_estado, recompensa, {"acao": acao}
    
    def get_performance_metrics(self):
        """Retorna métricas de performance do ambiente real."""
        if len(self.historico_portfolio) < 2:
            return {
                "retorno_total": 0.0,
                "retorno_anualizado": 0.0,
                "volatilidade": 0.0,
                "sharpe": 0.0,
                "max_drawdown": 0.0,
                "num_operacoes": 0,
                "acoes": {"buy": 0, "hold": 0, "sell": 0}
            }
        
        # Calcular retorno total
        retorno_total = (self.historico_portfolio[-1] / self.historico_portfolio[0] - 1) * 100
        
        # Calcular retornos diários
        retornos = []
        for i in range(1, len(self.historico_portfolio)):
            retorno = self.historico_portfolio[i] / self.historico_portfolio[i-1] - 1
            retornos.append(retorno)
        
        # Calcular volatilidade
        volatilidade = 0.0
        if len(retornos) > 1:
            volatilidade = np.std(retornos) * 100
        
        # Calcular retorno anualizado
        retorno_anualizado = retorno_total * (252 / max(1, len(self.historico_portfolio)))
        
        # Calcular Sharpe Ratio (assumindo taxa livre de risco = 0)
        sharpe = 0
        if len(retornos) > 1 and np.std(retornos) > 0:
            sharpe = (np.mean(retornos) / np.std(retornos)) * np.sqrt(252)
        
        # Calcular máximo drawdown
        max_drawdown = 0
        peak = self.historico_portfolio[0]
        for valor in self.historico_portfolio:
            if valor > peak:
                peak = valor
            drawdown = (peak - valor) / peak
            if drawdown > max_drawdown:
                max_drawdown = drawdown
        
        # Contar operações por tipo
        acoes_count = {"buy": 0, "hold": 0, "sell": 0}
        for acao in self.historico_acoes:
            if acao == 0:
                acoes_count["hold"] += 1
            elif acao == 1:
                acoes_count["buy"] += 1
            elif acao == 2:
                acoes_count["sell"] += 1
        
        return {
            "retorno_total": retorno_total,
            "retorno_anualizado": retorno_anualizado,
            "volatilidade": volatilidade,
            "sharpe": sharpe,
            "max_drawdown": max_drawdown * 100,
            "num_operacoes": len(self.historico_acoes),
            "acoes": acoes_count
        }

# Exportar classes
__all__ = ['AmbienteRL', 'AmbienteRLAvancado', 'RealAmbienteRL']
