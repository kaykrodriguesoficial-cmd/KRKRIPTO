"""
AmbienteRLAvançado - Ambiente de Reinforcement Learning Avançado para Trading

Este módulo implementa um ambiente de RL avançado para trading algorítmico,
com suporte a múltiplos ativos e timeframes.

Autor: Equipe KR_KRIPTO
Data: Maio 2025
Versão: 2.0
"""

import os
import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Any, Optional, Union
from datetime import datetime, timedelta

# Configurar logging
try:
    from src.utils.logger_config import setup_logger
    logger = setup_logger("reinforcement.ambiente_rl_avancado")
except ImportError:
    # Fallback para logging padrão
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger("reinforcement.ambiente_rl_avancado")

# Importar módulos internos
try:
    from src.intelligence.reinforcement.ambiente_rl import AmbienteRL
except ImportError:
    # Classe base para fallback
    class AmbienteRL:
        """Classe base para ambientes de RL."""
        
        def __init__(self, config=None):
            self.config = config or {}
            logger.info("AmbienteRL base inicializado")
        
        def reset(self):
            return {}
        
        def step(self, action):
            return {}, 0.0, False, {}

class AmbienteRLAvancado(AmbienteRL):
    """
    Ambiente de RL avançado para trading algorítmico.
    
    Esta classe implementa um ambiente de RL avançado para trading algorítmico,
    com suporte a múltiplos ativos e timeframes.
    
    Attributes:
        config (Dict): Configurações do ambiente
        ativo (str): Símbolo do ativo
        timeframe (str): Timeframe para análise
        capital_inicial (float): Capital inicial para simulação
        custo_transacao (float): Custo de transação (percentual)
        memoria_temporal (MemoriaTemporal): Memória temporal para acesso a dados históricos
        operador (OperadorBinance): Operador para execução de ordens
        posicao (float): Posição atual (quantidade)
        saldo (float): Saldo atual (moeda base)
        preco_entrada (float): Preço de entrada da posição atual
        historico_acoes (List): Histórico de ações tomadas
        historico_recompensas (List): Histórico de recompensas recebidas
        historico_posicoes (List): Histórico de posições
        historico_saldos (List): Histórico de saldos
        historico_precos (List): Histórico de preços
        estado_atual (Dict): Estado atual do ambiente
        done (bool): Indicador de término do episódio
    """
    
    def __init__(self, config: Dict = None):
        """
        Inicializa o ambiente avançado.
        
        Args:
            config: Configurações do ambiente (default: None)
        """
        super().__init__(config)
        
        self.config = config or {}
        
        # Parâmetros específicos
        self.ativos = self.config.get('ativos', ['BTCUSDT'])
        self.timeframes = self.config.get('timeframes', ['1h'])
        self.capital_inicial = self.config.get('capital_inicial', 1000.0)
        self.custo_transacao = self.config.get('custo_transacao', 0.001)
        self.max_posicao = self.config.get('max_posicao', 1.0)
        self.janela_observacao = self.config.get('janela_observacao', 24)
        self.modo_treinamento = self.config.get('modo_treinamento', True)
        
        # Componentes externos
        self.memoria_temporal = self.config.get('memoria_temporal', None)
        self.operador = self.config.get('operador', None)
        
        # Estado interno
        self.posicoes = {ativo: 0.0 for ativo in self.ativos}
        self.saldos = {ativo: self.capital_inicial for ativo in self.ativos}
        self.precos_entrada = {ativo: 0.0 for ativo in self.ativos}
        
        # Histórico
        self.historico_acoes = {(ativo, tf): [] for ativo in self.ativos for tf in self.timeframes}
        self.historico_recompensas = {(ativo, tf): [] for ativo in self.ativos for tf in self.timeframes}
        self.historico_posicoes = {(ativo, tf): [] for ativo in self.ativos for tf in self.timeframes}
        self.historico_saldos = {(ativo, tf): [] for ativo in self.ativos for tf in self.timeframes}
        self.historico_precos = {(ativo, tf): [] for ativo in self.ativos for tf in self.timeframes}
        
        # Estado atual
        self.estados_atuais = {(ativo, tf): {} for ativo in self.ativos for tf in self.timeframes}
        self.done = {(ativo, tf): False for ativo in self.ativos for tf in self.timeframes}
        
        # Índices para simulação
        self.indices = {(ativo, tf): 0 for ativo in self.ativos for tf in self.timeframes}
        self.max_indices = {(ativo, tf): 0 for ativo in self.ativos for tf in self.timeframes}
        
        # Dataframes
        self.dataframes = {(ativo, tf): None for ativo in self.ativos for tf in self.timeframes}
        
        # Inicializar dataframes se memória temporal disponível
        if self.memoria_temporal:
            self._inicializar_dataframes()
        
        logger.info(f"AmbienteRLAvancado inicializado para {len(self.ativos)} ativos em {len(self.timeframes)} timeframes")
    
    def _inicializar_dataframes(self):
        """
        Inicializa os dataframes a partir da memória temporal.
        """
        if not self.memoria_temporal:
            logger.error("Memória temporal não disponível para inicializar dataframes")
            return
        
        for ativo in self.ativos:
            for tf in self.timeframes:
                try:
                    # Obter dataframe da memória temporal
                    key = f"{ativo}_{tf}"
                    if key in self.memoria_temporal.dataframes:
                        self.dataframes[(ativo, tf)] = self.memoria_temporal.dataframes[key].copy()
                        self.max_indices[(ativo, tf)] = len(self.dataframes[(ativo, tf)]) - 1
                        logger.info(f"Dataframe para {ativo} em {tf} inicializado com {self.max_indices[(ativo, tf)] + 1} registros")
                    else:
                        logger.warning(f"Dataframe para {ativo} em {tf} não encontrado na memória temporal")
                except Exception as e:
                    logger.error(f"Erro ao inicializar dataframe para {ativo} em {tf}: {e}")
    
    def reset(self, ativo: str = None, timeframe: str = None):
        """
        Reinicia o ambiente para um novo episódio.
        
        Args:
            ativo: Símbolo do ativo (default: None, usa o primeiro ativo)
            timeframe: Timeframe para análise (default: None, usa o primeiro timeframe)
            
        Returns:
            Dict: Estado inicial
        """
        # Usar primeiro ativo/timeframe se não especificado
        ativo = ativo or self.ativos[0]
        timeframe = timeframe or self.timeframes[0]
        
        # Verificar se ativo/timeframe são válidos
        if ativo not in self.ativos or timeframe not in self.timeframes:
            logger.error(f"Ativo {ativo} ou timeframe {timeframe} inválido")
            return {}
        
        # Reiniciar estado interno para este ativo/timeframe
        self.posicoes[ativo] = 0.0
        self.saldos[ativo] = self.capital_inicial
        self.precos_entrada[ativo] = 0.0
        
        # Reiniciar histórico para este ativo/timeframe
        self.historico_acoes[(ativo, timeframe)] = []
        self.historico_recompensas[(ativo, timeframe)] = []
        self.historico_posicoes[(ativo, timeframe)] = []
        self.historico_saldos[(ativo, timeframe)] = []
        self.historico_precos[(ativo, timeframe)] = []
        
        # Reiniciar índice para simulação
        self.indices[(ativo, timeframe)] = self.janela_observacao
        self.done[(ativo, timeframe)] = False
        
        # Obter estado inicial
        estado = self._obter_estado(ativo, timeframe)
        self.estados_atuais[(ativo, timeframe)] = estado
        
        return estado
    
    def step(self, acao: int, ativo: str = None, timeframe: str = None):
        """
        Executa uma ação no ambiente.
        
        Args:
            acao: Ação a ser executada (0: HOLD, 1: BUY, 2: SELL)
            ativo: Símbolo do ativo (default: None, usa o primeiro ativo)
            timeframe: Timeframe para análise (default: None, usa o primeiro timeframe)
            
        Returns:
            Tuple: (próximo_estado, recompensa, done, info)
        """
        # Usar primeiro ativo/timeframe se não especificado
        ativo = ativo or self.ativos[0]
        timeframe = timeframe or self.timeframes[0]
        
        # Verificar se ativo/timeframe são válidos
        if ativo not in self.ativos or timeframe not in self.timeframes:
            logger.error(f"Ativo {ativo} ou timeframe {timeframe} inválido")
            return {}, 0.0, True, {'erro': 'Ativo ou timeframe inválido'}
        
        # Verificar se o episódio já terminou
        if self.done[(ativo, timeframe)]:
            logger.warning(f"Episódio para {ativo} em {timeframe} já terminou")
            return self.estados_atuais[(ativo, timeframe)], 0.0, True, {'aviso': 'Episódio já terminou'}
        
        # Executar ação
        info = self._executar_acao(acao, ativo, timeframe)
        
        # Avançar para o próximo passo
        self.indices[(ativo, timeframe)] += 1
        
        # Verificar se o episódio terminou
        if self.indices[(ativo, timeframe)] >= self.max_indices[(ativo, timeframe)]:
            self.done[(ativo, timeframe)] = True
            logger.info(f"Episódio para {ativo} em {timeframe} terminou")
        
        # Obter próximo estado
        proximo_estado = self._obter_estado(ativo, timeframe)
        self.estados_atuais[(ativo, timeframe)] = proximo_estado
        
        # Calcular recompensa
        recompensa = self._calcular_recompensa(ativo, timeframe, acao, info)
        
        # Atualizar histórico
        self.historico_acoes[(ativo, timeframe)].append(acao)
        self.historico_recompensas[(ativo, timeframe)].append(recompensa)
        self.historico_posicoes[(ativo, timeframe)].append(self.posicoes[ativo])
        self.historico_saldos[(ativo, timeframe)].append(self.saldos[ativo])
        
        if 'preco' in info:
            self.historico_precos[(ativo, timeframe)].append(info['preco'])
        
        return proximo_estado, recompensa, self.done[(ativo, timeframe)], info
    
    def _obter_estado(self, ativo: str, timeframe: str) -> Dict:
        """
        Obtém o estado atual do ambiente.
        
        Args:
            ativo: Símbolo do ativo
            timeframe: Timeframe para análise
            
        Returns:
            Dict: Estado atual
        """
        # Verificar se temos dataframe para este ativo/timeframe
        if (ativo, timeframe) not in self.dataframes or self.dataframes[(ativo, timeframe)] is None:
            logger.error(f"Dataframe para {ativo} em {timeframe} não disponível")
            return {}
        
        # Verificar se o índice é válido
        idx = self.indices[(ativo, timeframe)]
        if idx < self.janela_observacao or idx > self.max_indices[(ativo, timeframe)]:
            logger.error(f"Índice {idx} inválido para {ativo} em {timeframe}")
            return {}
        
        try:
            # Obter dados da janela de observação
            df = self.dataframes[(ativo, timeframe)]
            janela = df.iloc[idx-self.janela_observacao:idx]
            
            # Extrair features
            features = {}
            
            # Preços e volume
            if 'close' in janela.columns:
                features['close'] = janela['close'].values.tolist()
            if 'open' in janela.columns:
                features['open'] = janela['open'].values.tolist()
            if 'high' in janela.columns:
                features['high'] = janela['high'].values.tolist()
            if 'low' in janela.columns:
                features['low'] = janela['low'].values.tolist()
            if 'volume' in janela.columns:
                features['volume'] = janela['volume'].values.tolist()
            
            # Indicadores técnicos
            for col in janela.columns:
                if col.startswith(('rsi', 'macd', 'ema', 'sma', 'bollinger', 'atr', 'adx')):
                    features[col] = janela[col].values.tolist()
            
            # Adicionar informações de posição e saldo
            features['posicao'] = self.posicoes[ativo]
            features['saldo'] = self.saldos[ativo]
            
            # Adicionar preço atual
            if 'close' in janela.columns:
                features['preco_atual'] = float(janela['close'].iloc[-1])
            
            # Adicionar timestamp
            if isinstance(janela.index[0], pd.Timestamp):
                features['timestamp'] = janela.index[-1].isoformat()
            
            return features
            
        except Exception as e:
            logger.error(f"Erro ao obter estado para {ativo} em {timeframe}: {e}")
            return {}
    
    def _executar_acao(self, acao: int, ativo: str, timeframe: str) -> Dict:
        """
        Executa uma ação no ambiente.
        
        Args:
            acao: Ação a ser executada (0: HOLD, 1: BUY, 2: SELL)
            ativo: Símbolo do ativo
            timeframe: Timeframe para análise
            
        Returns:
            Dict: Informações sobre a execução da ação
        """
        # Verificar se temos dataframe para este ativo/timeframe
        if (ativo, timeframe) not in self.dataframes or self.dataframes[(ativo, timeframe)] is None:
            logger.error(f"Dataframe para {ativo} em {timeframe} não disponível")
            return {'erro': 'Dataframe não disponível'}
        
        # Verificar se o índice é válido
        idx = self.indices[(ativo, timeframe)]
        if idx < 0 or idx >= len(self.dataframes[(ativo, timeframe)]):
            logger.error(f"Índice {idx} inválido para {ativo} em {timeframe}")
            return {'erro': 'Índice inválido'}
        
        try:
            # Obter preço atual
            df = self.dataframes[(ativo, timeframe)]
            preco = float(df['close'].iloc[idx])
            
            # Informações básicas
            info = {
                'acao': acao,
                'ativo': ativo,
                'timeframe': timeframe,
                'preco': preco,
                'posicao_anterior': self.posicoes[ativo],
                'saldo_anterior': self.saldos[ativo]
            }
            
            # Executar ação
            if acao == 0:  # HOLD
                # Não faz nada
                info['tipo'] = 'HOLD'
                
            elif acao == 1:  # BUY
                if self.posicoes[ativo] > 0:
                    # Já tem posição comprada
                    logger.warning(f"[{ativo}] Já existe posição comprada, ignorando.")
                    info['tipo'] = 'BUY_IGNORADO'
                    info['motivo'] = 'Já existe posição comprada'
                else:
                    # Calcular quantidade a comprar
                    quantidade = self.saldos[ativo] / preco * self.max_posicao
                    
                    # Aplicar custo de transação
                    custo = quantidade * preco * self.custo_transacao
                    quantidade_liquida = quantidade * (1 - self.custo_transacao)
                    
                    # Atualizar posição e saldo
                    self.posicoes[ativo] = quantidade_liquida
                    self.saldos[ativo] = 0.0  # Todo o saldo é usado para comprar
                    self.precos_entrada[ativo] = preco
                    
                    # Registrar informações
                    info['tipo'] = 'BUY'
                    info['quantidade'] = quantidade_liquida
                    info['custo_transacao'] = custo
                    
                    # Log
                    logger.info(f"[{ativo}] BUY: {quantidade_liquida:.4f} @ {preco:.2f}")
                    
                    # Se temos operador, executar ordem real
                    if self.operador and not self.modo_treinamento:
                        try:
                            resultado = self.operador.executar_ordem(ativo, 'BUY', quantidade, preco)
                            info['ordem'] = resultado
                        except Exception as e:
                            logger.error(f"Erro ao executar ordem de compra: {e}")
                            info['erro_ordem'] = str(e)
                
            elif acao == 2:  # SELL
                if self.posicoes[ativo] <= 0:
                    # Não tem posição para vender
                    logger.warning(f"[{ativo}] Sem posição para vender, ignorando.")
                    info['tipo'] = 'SELL_IGNORADO'
                    info['motivo'] = 'Sem posição para vender'
                else:
                    # Calcular valor da venda
                    quantidade = self.posicoes[ativo]
                    valor_venda = quantidade * preco
                    
                    # Aplicar custo de transação
                    custo = valor_venda * self.custo_transacao
                    valor_liquido = valor_venda * (1 - self.custo_transacao)
                    
                    # Atualizar posição e saldo
                    self.posicoes[ativo] = 0.0
                    self.saldos[ativo] = valor_liquido
                    
                    # Registrar informações
                    info['tipo'] = 'SELL'
                    info['quantidade'] = quantidade
                    info['valor_venda'] = valor_venda
                    info['custo_transacao'] = custo
                    info['valor_liquido'] = valor_liquido
                    
                    # Calcular P&L
                    pl_absoluto = valor_liquido - (quantidade * self.precos_entrada[ativo])
                    pl_percentual = (preco / self.precos_entrada[ativo] - 1) * 100 if self.precos_entrada[ativo] > 0 else 0
                    
                    info['pl_absoluto'] = pl_absoluto
                    info['pl_percentual'] = pl_percentual
                    
                    # Log
                    logger.info(f"[{ativo}] SELL: {quantidade:.4f} @ {preco:.2f} -> {pl_percentual:.2f}%")
                    
                    # Se temos operador, executar ordem real
                    if self.operador and not self.modo_treinamento:
                        try:
                            resultado = self.operador.executar_ordem(ativo, 'SELL', quantidade, preco)
                            info['ordem'] = resultado
                        except Exception as e:
                            logger.error(f"Erro ao executar ordem de venda: {e}")
                            info['erro_ordem'] = str(e)
            
            # Calcular valor do portfólio
            valor_posicao = self.posicoes[ativo] * preco
            valor_portfolio = self.saldos[ativo] + valor_posicao
            
            info['posicao_atual'] = self.posicoes[ativo]
            info['saldo_atual'] = self.saldos[ativo]
            info['valor_posicao'] = valor_posicao
            info['valor_portfolio'] = valor_portfolio
            
            return info
            
        except Exception as e:
            logger.error(f"Erro ao executar ação {acao} para {ativo} em {timeframe}: {e}")
            return {'erro': str(e)}
    
    def _calcular_recompensa(self, ativo: str, timeframe: str, acao: int, info: Dict) -> float:
        """
        Calcula a recompensa para a ação executada.
        
        Args:
            ativo: Símbolo do ativo
            timeframe: Timeframe para análise
            acao: Ação executada
            info: Informações sobre a execução da ação
            
        Returns:
            float: Recompensa
        """
        # Recompensa padrão
        recompensa = 0.0
        
        # Verificar se temos informações suficientes
        if 'erro' in info:
            return -1.0  # Penalidade por erro
        
        # Calcular recompensa com base na variação do valor do portfólio
        if 'valor_portfolio' in info and 'saldo_anterior' in info and 'posicao_anterior' in info and 'preco' in info:
            valor_anterior = info['saldo_anterior'] + (info['posicao_anterior'] * info['preco'])
            valor_atual = info['valor_portfolio']
            
            # Recompensa proporcional à variação percentual
            if valor_anterior > 0:
                recompensa = (valor_atual / valor_anterior - 1) * 100
            
            # Penalidade por custos de transação excessivos
            if acao != 0 and 'custo_transacao' in info:
                recompensa -= info['custo_transacao'] * 0.1
        
        # Recompensas específicas por tipo de ação
        if 'tipo' in info:
            if info['tipo'] == 'BUY_IGNORADO' or info['tipo'] == 'SELL_IGNORADO':
                recompensa -= 0.1  # Pequena penalidade por ações ignoradas
            
            elif info['tipo'] == 'SELL' and 'pl_percentual' in info:
                # Bônus por lucro ou penalidade por prejuízo
                pl = info['pl_percentual']
                if pl > 0:
                    recompensa += pl * 0.1  # Bônus proporcional ao lucro
                else:
                    recompensa += pl * 0.05  # Penalidade menor por prejuízo
        
        return float(recompensa)
    
    def render(self, ativo: str = None, timeframe: str = None, modo: str = 'human'):
        """
        Renderiza o estado atual do ambiente.
        
        Args:
            ativo: Símbolo do ativo (default: None, usa o primeiro ativo)
            timeframe: Timeframe para análise (default: None, usa o primeiro timeframe)
            modo: Modo de renderização ('human' ou 'rgb_array')
            
        Returns:
            Union[None, np.ndarray]: None para modo 'human', array para modo 'rgb_array'
        """
        # Usar primeiro ativo/timeframe se não especificado
        ativo = ativo or self.ativos[0]
        timeframe = timeframe or self.timeframes[0]
        
        # Verificar se ativo/timeframe são válidos
        if ativo not in self.ativos or timeframe not in self.timeframes:
            logger.error(f"Ativo {ativo} ou timeframe {timeframe} inválido")
            return None
        
        # Obter informações para renderização
        estado = self.estados_atuais.get((ativo, timeframe), {})
        posicao = self.posicoes.get(ativo, 0.0)
        saldo = self.saldos.get(ativo, 0.0)
        
        # Renderização para humanos
        if modo == 'human':
            print(f"\n=== Estado do Ambiente RL para {ativo} em {timeframe} ===")
            print(f"Índice: {self.indices.get((ativo, timeframe), 0)}/{self.max_indices.get((ativo, timeframe), 0)}")
            print(f"Posição: {posicao:.4f}")
            print(f"Saldo: {saldo:.2f}")
            
            if 'preco_atual' in estado:
                print(f"Preço atual: {estado['preco_atual']:.2f}")
            
            if 'timestamp' in estado:
                print(f"Timestamp: {estado['timestamp']}")
            
            print("\nHistórico recente:")
            historico_acoes = self.historico_acoes.get((ativo, timeframe), [])
            historico_recompensas = self.historico_recompensas.get((ativo, timeframe), [])
            
            acoes_map = {0: 'HOLD', 1: 'BUY', 2: 'SELL'}
            
            for i in range(max(0, len(historico_acoes) - 5), len(historico_acoes)):
                acao = acoes_map.get(historico_acoes[i], historico_acoes[i])
                recompensa = historico_recompensas[i]
                print(f"  {i}: {acao} -> {recompensa:.4f}")
            
            print("\n")
            return None
        
        # Renderização como array (para visualização)
        elif modo == 'rgb_array':
            # Implementação simplificada - retorna um array vazio
            return np.zeros((10, 10, 3), dtype=np.uint8)
        
        else:
            logger.error(f"Modo de renderização desconhecido: {modo}")
            return None
    
    def close(self):
        """
        Fecha o ambiente e libera recursos.
        """
        # Nada a fazer por enquanto
        pass
    
    def get_status(self) -> Dict:
        """
        Obtém o status atual do ambiente.
        
        Returns:
            Dict: Status atual
        """
        status = {
            'ativos': self.ativos,
            'timeframes': self.timeframes,
            'modo_treinamento': self.modo_treinamento,
            'posicoes': self.posicoes,
            'saldos': self.saldos,
            'capital_inicial': self.capital_inicial,
            'custo_transacao': self.custo_transacao,
            'janela_observacao': self.janela_observacao,
            'dataframes_disponiveis': {
                f"{ativo}_{tf}": self.dataframes.get((ativo, tf)) is not None
                for ativo in self.ativos
                for tf in self.timeframes
            },
            'timestamp': datetime.now().isoformat()
        }
        
        return status
    
    def calcular_metricas(self, ativo: str = None, timeframe: str = None) -> Dict:
        """
        Calcula métricas de desempenho para um ativo e timeframe específicos.
        
        Args:
            ativo: Símbolo do ativo (default: None, usa o primeiro ativo)
            timeframe: Timeframe para análise (default: None, usa o primeiro timeframe)
            
        Returns:
            Dict: Métricas de desempenho
        """
        # Usar primeiro ativo/timeframe se não especificado
        ativo = ativo or self.ativos[0]
        timeframe = timeframe or self.timeframes[0]
        
        # Verificar se ativo/timeframe são válidos
        if ativo not in self.ativos or timeframe not in self.timeframes:
            logger.error(f"Ativo {ativo} ou timeframe {timeframe} inválido")
            return {'erro': 'Ativo ou timeframe inválido'}
        
        # Verificar se temos histórico suficiente
        historico_recompensas = self.historico_recompensas.get((ativo, timeframe), [])
        historico_acoes = self.historico_acoes.get((ativo, timeframe), [])
        historico_saldos = self.historico_saldos.get((ativo, timeframe), [])
        
        if not historico_recompensas or not historico_acoes or not historico_saldos:
            logger.warning(f"Histórico insuficiente para {ativo} em {timeframe}")
            return {'aviso': 'Histórico insuficiente'}
        
        try:
            # Calcular métricas básicas
            recompensa_total = sum(historico_recompensas)
            recompensa_media = recompensa_total / len(historico_recompensas) if historico_recompensas else 0
            
            # Calcular retorno total
            retorno_total = (historico_saldos[-1] / self.capital_inicial - 1) * 100 if self.capital_inicial > 0 else 0
            
            # Calcular Sharpe ratio (simplificado)
            if len(historico_recompensas) > 1:
                std_recompensas = np.std(historico_recompensas)
                sharpe = recompensa_media / std_recompensas if std_recompensas > 0 else 0
            else:
                sharpe = 0
            
            # Calcular máximo drawdown
            max_drawdown = 0
            peak = self.capital_inicial
            
            for saldo in historico_saldos:
                if saldo > peak:
                    peak = saldo
                drawdown = (peak - saldo) / peak if peak > 0 else 0
                max_drawdown = max(max_drawdown, drawdown)
            
            # Calcular distribuição de ações
            total_acoes = len(historico_acoes)
            distribuicao_acoes = {
                'HOLD': historico_acoes.count(0) / total_acoes if total_acoes > 0 else 0,
                'BUY': historico_acoes.count(1) / total_acoes if total_acoes > 0 else 0,
                'SELL': historico_acoes.count(2) / total_acoes if total_acoes > 0 else 0
            }
            
            # Calcular número de operações
            num_operacoes = historico_acoes.count(1) + historico_acoes.count(2)
            
            # Preparar métricas
            metricas = {
                'retorno_total': float(retorno_total),
                'recompensa_total': float(recompensa_total),
                'recompensa_media': float(recompensa_media),
                'sharpe': float(sharpe),
                'max_drawdown': float(max_drawdown),
                'num_operacoes': int(num_operacoes),
                'distribuicao_acoes': distribuicao_acoes,
                'timestamp': datetime.now().isoformat()
            }
            
            return metricas
            
        except Exception as e:
            logger.error(f"Erro ao calcular métricas para {ativo} em {timeframe}: {e}")
            return {'erro': str(e)}


class RealAmbienteRL(AmbienteRLAvancado):
    """
    Ambiente de RL para trading em tempo real.
    
    Esta classe estende o AmbienteRLAvancado para uso em trading em tempo real,
    com suporte a operações reais via operador.
    
    Attributes:
        config (Dict): Configurações do ambiente
        ativo (str): Símbolo do ativo
        timeframe (str): Timeframe para análise
        operador (OperadorBinance): Operador para execução de ordens
        memoria_temporal (MemoriaTemporal): Memória temporal para acesso a dados históricos
        modo_simulacao (bool): Indica se o ambiente está em modo de simulação
        janela_observacao (int): Tamanho da janela de observação
        estado_atual (Dict): Estado atual do ambiente
    """
    
    def __init__(self, config: Dict = None):
        """
        Inicializa o ambiente real.
        
        Args:
            config: Configurações do ambiente (default: None)
        """
        super().__init__(config)
        
        # Parâmetros específicos para ambiente real
        self.modo_treinamento = False
        self.modo_simulacao = self.config.get('modo_simulacao', False)
        self.ativo = self.config.get('ativo', 'BTCUSDT')
        self.timeframe = self.config.get('timeframe', '1h')
        
        # Verificar se temos operador
        if not self.operador and not self.modo_simulacao:
            logger.warning("Operador não disponível para ambiente real, usando modo de simulação")
            self.modo_simulacao = True
        
        # Verificar se temos memória temporal
        if not self.memoria_temporal:
            logger.warning("Memória temporal não disponível para ambiente real")
        
        # Estado atual
        self.estado_atual = {}
        
        logger.info(f"RealAmbienteRL inicializado para {self.ativo} em {self.timeframe}")
    
    def obter_estado(self) -> Dict:
        """
        Obtém o estado atual do mercado.
        
        Returns:
            Dict: Estado atual
        """
        try:
            # Verificar se temos memória temporal
            if not self.memoria_temporal:
                logger.error("Memória temporal não disponível para obter estado")
                return {}
            
            # Obter dados recentes
            key = f"{self.ativo}_{self.timeframe}"
            if key not in self.memoria_temporal.dataframes:
                logger.error(f"Dataframe para {key} não encontrado na memória temporal")
                return {}
            
            # Obter últimos dados
            df = self.memoria_temporal.dataframes[key]
            janela = df.iloc[-self.janela_observacao:]
            
            # Extrair features
            features = {}
            
            # Preços e volume
            if 'close' in janela.columns:
                features['close'] = janela['close'].values.tolist()
                features['preco_atual'] = float(janela['close'].iloc[-1])
            if 'open' in janela.columns:
                features['open'] = janela['open'].values.tolist()
            if 'high' in janela.columns:
                features['high'] = janela['high'].values.tolist()
            if 'low' in janela.columns:
                features['low'] = janela['low'].values.tolist()
            if 'volume' in janela.columns:
                features['volume'] = janela['volume'].values.tolist()
            
            # Indicadores técnicos
            for col in janela.columns:
                if col.startswith(('rsi', 'macd', 'ema', 'sma', 'bollinger', 'atr', 'adx')):
                    features[col] = janela[col].values.tolist()
            
            # Adicionar informações de posição e saldo
            if self.operador:
                try:
                    posicao = self.operador.obter_posicao(self.ativo)
                    saldo = self.operador.obter_saldo()
                    
                    features['posicao'] = posicao
                    features['saldo'] = saldo
                except Exception as e:
                    logger.error(f"Erro ao obter posição/saldo do operador: {e}")
            
            # Adicionar timestamp
            if isinstance(janela.index[0], pd.Timestamp):
                features['timestamp'] = janela.index[-1].isoformat()
            else:
                features['timestamp'] = datetime.now().isoformat()
            
            # Atualizar estado atual
            self.estado_atual = features
            
            return features
            
        except Exception as e:
            logger.error(f"Erro ao obter estado real: {e}")
            return {}
    
    def executar_acao(self, acao: int) -> Tuple[Dict, float, Dict]:
        """
        Executa uma ação no ambiente real.
        
        Args:
            acao: Ação a ser executada (0: HOLD, 1: BUY, 2: SELL)
            
        Returns:
            Tuple: (próximo_estado, recompensa, info)
        """
        try:
            # Obter estado atual
            estado_atual = self.obter_estado()
            
            # Verificar se temos informações suficientes
            if not estado_atual or 'preco_atual' not in estado_atual:
                logger.error("Estado atual insuficiente para executar ação")
                return {}, 0.0, {'erro': 'Estado atual insuficiente'}
            
            # Obter preço atual
            preco = estado_atual['preco_atual']
            
            # Informações básicas
            info = {
                'acao': acao,
                'ativo': self.ativo,
                'timeframe': self.timeframe,
                'preco': preco,
                'timestamp': datetime.now().isoformat()
            }
            
            # Executar ação
            if acao == 0:  # HOLD
                # Não faz nada
                info['tipo'] = 'HOLD'
                logger.info(f"[{self.ativo}] HOLD @ {preco:.2f}")
                
            elif acao == 1:  # BUY
                # Verificar se já tem posição
                posicao = 0.0
                if self.operador:
                    posicao = self.operador.obter_posicao(self.ativo)
                
                if posicao > 0:
                    # Já tem posição comprada
                    logger.warning(f"[{self.ativo}] Já existe posição comprada, ignorando.")
                    info['tipo'] = 'BUY_IGNORADO'
                    info['motivo'] = 'Já existe posição comprada'
                else:
                    # Calcular quantidade a comprar
                    saldo = self.capital_inicial
                    if self.operador:
                        saldo = self.operador.obter_saldo()
                    
                    quantidade = saldo / preco * self.max_posicao
                    
                    # Registrar informações
                    info['tipo'] = 'BUY'
                    info['quantidade'] = quantidade
                    
                    # Log
                    logger.info(f"[{self.ativo}] BUY: {quantidade:.4f} @ {preco:.2f}")
                    
                    # Se temos operador e não estamos em modo de simulação, executar ordem real
                    if self.operador and not self.modo_simulacao:
                        try:
                            resultado = self.operador.executar_ordem(self.ativo, 'BUY', quantidade, preco)
                            info['ordem'] = resultado
                            logger.info(f"[{self.ativo}] BUY: {quantidade:.4f} @ {preco:.2f} -> {resultado}")
                        except Exception as e:
                            logger.error(f"Erro ao executar ordem de compra: {e}")
                            info['erro_ordem'] = str(e)
                
            elif acao == 2:  # SELL
                # Verificar se tem posição para vender
                posicao = 0.0
                if self.operador:
                    posicao = self.operador.obter_posicao(self.ativo)
                
                if posicao <= 0:
                    # Não tem posição para vender
                    logger.warning(f"[{self.ativo}] Sem posição para vender, ignorando.")
                    info['tipo'] = 'SELL_IGNORADO'
                    info['motivo'] = 'Sem posição para vender'
                else:
                    # Registrar informações
                    info['tipo'] = 'SELL'
                    info['quantidade'] = posicao
                    
                    # Log
                    logger.info(f"[{self.ativo}] SELL: {posicao:.4f} @ {preco:.2f}")
                    
                    # Se temos operador e não estamos em modo de simulação, executar ordem real
                    if self.operador and not self.modo_simulacao:
                        try:
                            resultado = self.operador.executar_ordem(self.ativo, 'SELL', posicao, preco)
                            info['ordem'] = resultado
                            logger.info(f"[{self.ativo}] SELL: {posicao:.4f} @ {preco:.2f} -> {resultado}")
                        except Exception as e:
                            logger.error(f"Erro ao executar ordem de venda: {e}")
                            info['erro_ordem'] = str(e)
            
            # Calcular recompensa
            recompensa = 0.0
            
            # Obter próximo estado
            proximo_estado = self.obter_estado()
            
            return proximo_estado, recompensa, info
            
        except Exception as e:
            logger.error(f"Erro ao executar ação {acao} no ambiente real: {e}")
            return {}, 0.0, {'erro': str(e)}
    
    def avaliar_portfolio(self) -> Dict:
        """
        Avalia o estado atual do portfólio.
        
        Returns:
            Dict: Avaliação do portfólio
        """
        try:
            # Verificar se temos operador
            if not self.operador:
                logger.error("Operador não disponível para avaliar portfólio")
                return {'erro': 'Operador não disponível'}
            
            # Obter informações do portfólio
            posicao = self.operador.obter_posicao(self.ativo)
            saldo = self.operador.obter_saldo()
            
            # Obter preço atual
            estado = self.obter_estado()
            preco = estado.get('preco_atual', 0.0)
            
            # Calcular valor do portfólio
            valor_posicao = posicao * preco
            valor_portfolio = saldo + valor_posicao
            
            # Preparar avaliação
            avaliacao = {
                'ativo': self.ativo,
                'posicao': posicao,
                'saldo': saldo,
                'preco': preco,
                'valor_posicao': valor_posicao,
                'valor_portfolio': valor_portfolio,
                'timestamp': datetime.now().isoformat()
            }
            
            return avaliacao
            
        except Exception as e:
            logger.error(f"Erro ao avaliar portfólio: {e}")
            return {'erro': str(e)}
