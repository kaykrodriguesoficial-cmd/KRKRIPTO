
import numpy as np

def calcular_recompensa(sinal, df_atual, hold_period=5):
    try:
        timestamp_sinal = sinal['timestamp']
        close_sinal = df_atual.loc[timestamp_sinal]['close'] if timestamp_sinal in df_atual.index else None

        if close_sinal is None:
            return {'recompensa': 0.0, 'comentario': 'timestamp não encontrado'}

        # Seleciona candles após o sinal
        df_futuro = df_atual[df_atual.index > timestamp_sinal].head(hold_period)

        if df_futuro.empty:
            return {'recompensa': 0.0, 'comentario': 'sem dados futuros suficientes'}

        close_final = df_futuro['close'].iloc[-1]
        delta = close_final - close_sinal
        direcao_correta = (delta > 0 and sinal['classe'] == 'compra') or (delta < 0 and sinal['classe'] == 'venda')

        recompensa = abs(delta) if direcao_correta else -abs(delta)
        comentario = '✔️ Direção correta' if direcao_correta else '❌ Direção errada'

        return {'recompensa': recompensa, 'comentario': comentario}
    
    except Exception as e:
        return {'recompensa': 0.0, 'comentario': f'erro: {str(e)}'}
