
from executors.logger import log_erro

feedback_memoria = {}

def aplicar_feedback_execucao(ativo, retorno, score_previsto, probabilidade_prevista):
    try:
        if ativo not in feedback_memoria:
            feedback_memoria[ativo] = {"acumulado": 0, "ajuste": 1.0}

        erro = retorno - score_previsto
        ajuste = 1 - abs(erro)

        feedback_memoria[ativo]["acumulado"] += retorno
        feedback_memoria[ativo]["ajuste"] = max(0.5, min(1.5, ajuste))

        log_erro(f"[FEEDBACK] Ajuste para {ativo}: {feedback_memoria[ativo]}")
        return feedback_memoria[ativo]["ajuste"]
    except Exception as e:
        log_erro(f"[FEEDBACK] Erro ao aplicar feedback: {e}")
        return 1.0
