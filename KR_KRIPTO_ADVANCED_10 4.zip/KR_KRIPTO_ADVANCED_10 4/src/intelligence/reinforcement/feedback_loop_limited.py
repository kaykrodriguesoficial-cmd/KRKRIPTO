"""
Módulo: feedback_loop_limited.py
Objetivo: Executar o feedback loop apenas a cada N sinais válidos.
"""

import os
import json

# Caminho do arquivo de controle
ARQUIVO_CONTROLE = "contador_feedback.json"

# Quantidade de sinais antes de rodar feedback novamente
LIMITE_SINAIS = 50

def carregar_estado():
    if os.path.exists(ARQUIVO_CONTROLE):
        with open(ARQUIVO_CONTROLE, "r") as f:
            return json.load(f)
    return {"contador": 0}

def salvar_estado(estado):
    with open(ARQUIVO_CONTROLE, "w") as f:
        json.dump(estado, f)

def rodar_feedback_condicional(callback_feedback_func):
    estado = carregar_estado()
    estado["contador"] += 1

    if estado["contador"] >= LIMITE_SINAIS:
        print("⚙️ Rodando feedback loop — limite atingido")
        callback_feedback_func()
        estado["contador"] = 0
    else:
        print(f"⏸️ Feedback congelado — aguardando {LIMITE_SINAIS - estado['contador']} sinais")

    salvar_estado(estado)
