# src/core/signal_processor.py

import os # Added for env var check
import pandas as pd
import logging
import asyncio
import traceback
import numpy as np # Added for NaN
import time # Added for latency measurement
import json # Added for JSON serialization
from typing import Optional, Callable, Coroutine, Dict, List, Any, Tuple # Added Dict, List, Any, Tuple
from collections import defaultdict # Added for Ponto 7
from datetime import datetime # Added for timestamp formatting

# Configuration for Ponto 7 (ideally from main config)
DEFAULT_N_MINUTES_FOR_EVAL = 5 
DEFAULT_PROFIT_THRESHOLD_PERCENT = 0.05

# Module-level storage for pending evaluations (Ponto 7)
pending_model_evaluations: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

# Import necessary components from other modules
# Note: These imports assume the refactored structure
from src.strategies.score_calculator import calcular_score_corrigido_v12 as calcular_score
from src.strategies.signal_classifier import prever_classe_corrigido_v12 as prever_classe
from src.strategies.fakeout import detectar_fakeout
from src.strategies.validators.input_validator import validar_entrada_sinal
from src.strategies.validators.book_imbalance import validar_book_institucional
from src.strategies.validators.filtros_institucionais import validar_filtro_institucional
import pandas_ta as ta # Added for indicator calculation
# from src.strategies.validators.zonas_rejeicao import validador_zona_rejeicao # Commented out - Not found
from src.strategies.risk_manager import aplicar_risco

# from src.intelligence.ajustadores.heuristicas_controller import ajustar_heuristicas # Commented out - Not found
from src.intelligence.feedback_loop_limited import rodar_feedback_condicional # Needs context (globals?)
from src.intelligence.competicoes.campeonato_modelos import executar_campeonato # Needs context
from src.intelligence.mutacoes.mutador_transformer import gerar_mutacao_transformer # Needs context
from src.intelligence.book_feedback import ajustar_score_por_book
# from ..intelligence.context_switcher import definir_modo_execucao_por_regime
from intelligence.context_switcher import ContextSwitcher, MarketRegime # Etapa 018
from src.intelligence.avaliar_decisor import avaliar_decisao_por_similaridade
from src.intelligence.aprendizado.aprendizado_rentabilidade import ajustar_pesos_por_lucro # Needs context
from src.intelligence.punitivo_falso_positivo import verificar_perda_sequencial # Needs context
from src.intelligence.ia_fusao_contextual import prever_score_fusao

from src.infrastructure.notifier import enviar_telegram, log_erro
from src.infrastructure.memory import MemoriaTemporal # Needs instance
from src.infrastructure.rollback import verificar_necessidade_de_rollback # Needs context

from src.realtime.book_processor import BookProcessor, BookState # Needs instance/context

# RL Imports (Etapa 016)
try:
    from src.intelligence.rl.agente_rl import AgenteRL
    from src.intelligence.rl.ambiente_rl import AmbienteRL
    RL_AVAILABLE = True
except ImportError as e:
    # logger.warning(f"Módulos RL não encontrados ou erro na importação: {e}. Funcionalidade RL desativada.")
    RL_AVAILABLE = False
    # Definir stubs se RL não estiver disponível
    class AgenteRL: pass
    class AmbienteRL: pass

# Prometheus metrics
try:
    # Added signal_processing_latency_seconds
    from src.infrastructure.prometheus_exporter import inc_signals_processed, inc_errors, signal_processing_latency_seconds
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False
    # Define stubs if Prometheus is not available
    def inc_signals_processed(*args, **kwargs): pass
    def inc_errors(*args, **kwargs): pass
    # Stub for latency metric
    class MockHistogram:
        def observe(self, *args, **kwargs): pass
    signal_processing_latency_seconds = MockHistogram()
    # Use a generic logger if the specific one isn't available yet
    try:
        logger = logging.getLogger("kr_kripto_processor")
        logger.warning("Prometheus exporter or metrics not fully available. Using stubs.")
    except NameError:
        print("WARNING: Prometheus exporter or metrics not fully available. Using stubs.")

# Import GerenciadorFallback for model access (Etapa 015)
from infrastructure.fallback import GerenciadorFallback

# Import Neural Governance components (Etapa 017)
try:
    from intelligence.governance.neural_governance import NeuralGovernor, ModelPerformanceTracker
    GOVERNANCE_AVAILABLE = True
except ImportError as e:
    print(f"CRITICAL IMPORT ERROR: NeuralGovernor or ModelPerformanceTracker not found: {e}. GOVERNANCE_AVAILABLE set to False.")
    GOVERNANCE_AVAILABLE = False
    class NeuralGovernor: pass # Stub
    class ModelPerformanceTracker: pass # Stub
    raise ImportError(f"Dependência crítica NeuralGovernor/ModelPerformanceTracker não encontrada: {e}") from e

# Import Attack Detector components (Etapa 019)
try:
    from intelligence.attack_detector import AttackDetector
    ATTACK_DETECTOR_AVAILABLE = True # Flag is implicitly True if import succeeds and critical
except ImportError as e:
    logger.critical(f"[CRÍTICO] Falha ao importar AttackDetector de src.intelligence.attack_detector: {e}. O processador de sinais (inteligência) não pode operar sem ele.")
    raise ImportError(f"Dependência crítica AttackDetector não encontrada: {e}") from e

# Import News Provider components (Etapa 021)
try:
    from data_providers.news_provider import NewsProvider, NEWS_PROVIDER_AVAILABLE
except ImportError:
    NEWS_PROVIDER_AVAILABLE = False
    class NewsProvider: pass # Stub

# Import Circuit Breaker
from src.infrastructure.circuit_breaker_manager import circuit_breaker
from binance.enums import SIDE_BUY, SIDE_SELL # Import sides for order execution

# --- STUB for missing ajustar_heuristicas ---
def ajustar_heuristicas(df, score, classe):
    """Stub function for heuristic adjustments. Returns no adjustment."""
    logger.debug("Using STUB for ajustar_heuristicas. Real implementation missing.")
    return {"ajuste_score": 0.0}
# --- END STUB ---

# --- STUB for missing validador_zona_rejeicao ---
def validador_zona_rejeicao(df, i):
    """Stub function for rejection zone validation. Returns valid."""
    logger.debug("Using STUB for validador_zona_rejeicao. Real implementation missing.")
    return (True, "")
# --- END STUB ---

# --- STUB for missing validador_volume_profile ---
def validador_volume_profile(df, i):
    """Stub function for volume profile validation. Returns valid."""
    logger.debug("Using STUB for validador_volume_profile. Real implementation missing.")
    return (True, "")
# --- END STUB ---

logger = logging.getLogger("kr_kripto_processor")

# Placeholder for prever_score_final if it wasn't moved
def prever_score_final(score_raw, probabilidade, fakeout, w_score, w_prob, w_fake):
    return (score_raw * w_score) + (probabilidade * w_prob) - (fakeout * w_fake)

# TODO: Refactor to remove dependency on global variables from main.py
# Pass necessary state (memoria_temporal, processadores_book, agentes_rl, etc.) as arguments
@circuit_breaker() # Aplicando o Circuit Breaker global
async def analisar_sinal(
    ativo: str,
    df_original: pd.DataFrame,
    memoria_temporal: MemoriaTemporal,
    processadores_book: dict,
    agentes_rl: dict,
    ambientes_rl: dict,
    config: dict,
    fallback_manager: GerenciadorFallback,
    governor: Optional[NeuralGovernor] = None, # Added for Etapa 017
    tracker: Optional[ModelPerformanceTracker] = None, # Added for Etapa 017
    context_switcher: Optional[ContextSwitcher] = None, # Added for Etapa 018
    strategy_config: Optional[dict] = None, # Added for Etapa 018
    attack_detector: Optional[AttackDetector] = None, # Added for Etapa 019
    news_provider: Optional[NewsProvider] = None, # Added for Etapa 021
    operador: Optional["OperadorBinance"] = None # Added for Etapa 006 (Order Execution)
) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """
    Analyzes the signal for a given asset. Refactored from main.py.
    
    Returns:
        Tuple[Optional[Dict[str, Any]], Optional[str]]: A tuple containing:
            - signal_details: A dictionary with detailed information about the signal analysis
            - error_message: An error message if an error occurred, None otherwise
    """
    start_time_analysis = time.monotonic() # Start latency timer
    razao_invalidacao = ""  # Inicializa razao_invalidacao
    fakeout = 0.0  # Inicializa fakeout com valor padrão
    probabilidade = 0.0 # Inicializa probabilidade com valor padrão
    score_raw = 0.0 # Inicializa score_raw com valor padrão
    classe_raw = "manter" # Inicializa classe_raw com valor padrão
    
    # Inicializar o dicionário signal_details que será retornado
    signal_details = {
        "asset": ativo,
        "timestamp": None,  # Será preenchido se df_original tiver um índice de timestamp
        "market_regime": "INDEFINIDO",
        "active_strategy_description": "Estratégia Padrão",
        "input_summary": {
            "close_price": None,
            "volume": None
        },
        "processing_stages": {
            "raw_score": 0.0,
            "raw_class": "manter",
            "raw_probability": 0.0,
            "fakeout_detected": False,
            "fakeout_value": 0.0,
            "score_after_book_adjustment": 0.0,
            "score_after_heuristic_adjustment": 0.0,
            "final_score_pre_ai": 0.0
        },
        "ai_components": {
            "rl_agent": {
                "action": 0,
                "reward": 0.0,
                "state_summary": None
            },
            "neural_governance": {
                "prediction": None,
                "model_id": None,
                "pending_evaluation": False,
                "evaluation_target_timestamp": None
            },
            "news_provider": {
                "score": 0.5
            },
            "attack_detector": {
                "volume_spike_detected": False
            }
        },
        "validators": {
            "zonas_rejeicao": {
                "active": False,
                "passed": True,
                "reason": ""
            },
            "volume_profile": {
                "active": False,
                "passed": True,
                "reason": ""
            },
            "filtros_institucionais": {
                "active": False,
                "passed": True,
                "reason": ""
            },
            "book_imbalance": {
                "active": False,
                "passed": True,
                "reason": "",
                "imbalance_value": 0.0
            }
        },
        "final_decision": {
            "score": 0.5,
            "class": "manter",
            "probability": 0.5,
            "decision": "manter",
            "reason_for_invalidation": "",
            "thresholds_used": {
                "buy": 0.65,
                "sell": 0.35
            }
        },
        "component_versions": {
            "neural_governance_model": "unknown",
            "rl_agent_model": "unknown",
            "signal_classifier_model": "unknown",
            "strategy_logic_version": "unknown"
        },
        "active_strategy_parameters": {},
        "internal_alerts_warnings": [],
        "fallback_info": {
            "activated": False,
            "component": None,
            "reason": None,
            "fallback_used": None
        },
        "execution_latency_ms": 0.0
    }

    # Carregar pesos da configuração ou usar padrões
    weights_config = config.get("score_weights", {})
    w_score = weights_config.get("w_score", 1.0)
    w_prob = weights_config.get("w_prob", 0.5)
    w_fake = weights_config.get("w_fakeout", 0.5) # Corrigido para w_fakeout para consistência com outros usos

    # Atualizar signal_details com os pesos
    signal_details["active_strategy_parameters"]["w_score"] = w_score
    signal_details["active_strategy_parameters"]["w_prob"] = w_prob
    signal_details["active_strategy_parameters"]["w_fake"] = w_fake

    # --- Runtime Sanity Checks for Critical Components (Ponto 6 do plano de robustez) ---
    critical_component_errors = []
    logger_sp = logging.getLogger("kr_kripto_processor") # Ensure logger is available

    # Check NeuralGovernor
    gov_config = config.get("neural_governance_config", {})
    gov_enabled = gov_config.get("enabled", False)
    if gov_enabled and (governor is None or not isinstance(governor, NeuralGovernor)):
        msg = f"[{ativo}] CRÍTICO (analisar_sinal): NeuralGovernor habilitado mas inválido/ausente (tipo: {type(governor)}). Abortando análise."
        critical_component_errors.append(msg)

    # Check ModelPerformanceTracker(config={})
    if gov_enabled and (tracker is None or not isinstance(tracker, ModelPerformanceTracker)):
        msg = f"[{ativo}] CRÍTICO (analisar_sinal): ModelPerformanceTracker habilitado (via NeuralGovernor) mas inválido/ausente (tipo: {type(tracker)}). Abortando análise."
        critical_component_errors.append(msg)

    # Check AttackDetector
    ad_config = config.get("attack_detector_config", {})
    ad_enabled = ad_config.get("enabled", False)
    if ad_enabled and (attack_detector is None or not isinstance(attack_detector, AttackDetector)):
        msg = f"[{ativo}] CRÍTICO (analisar_sinal): AttackDetector habilitado mas inválido/ausente (tipo: {type(attack_detector)}). Abortando análise."
        critical_component_errors.append(msg)

    # Check ContextSwitcher
    cs_config = config.get("context_switcher_config", {}) # Assuming this config structure from main.py
    cs_enabled = cs_config.get("enabled", True) # Default to True as often used
    if cs_enabled and (context_switcher is None or not isinstance(context_switcher, ContextSwitcher)):
        msg = f"[{ativo}] CRÍTICO (analisar_sinal): ContextSwitcher habilitado mas inválido/ausente (tipo: {type(context_switcher)}). Abortando análise."
        critical_component_errors.append(msg)

    # Check NewsProvider
    np_config = config.get("news_provider_config", {})
    np_enabled = np_config.get("enabled", False)
    if np_enabled and (news_provider is None or not isinstance(news_provider, NewsProvider)):
        msg = f"[{ativo}] CRÍTICO (analisar_sinal): NewsProvider habilitado mas inválido/ausente (tipo: {type(news_provider)}). Abortando análise."
        critical_component_errors.append(msg)

    # Check OperadorBinance(config={})
    trading_config = config.get("trading_config", {})
    live_trading_enabled = trading_config.get("live_trading_enabled", False)
    # OperadorBinance class is not directly imported here for isinstance, relying on main.py's init checks.
    # If live_trading_enabled, operador must not be None.
    if live_trading_enabled and operador is None:
        msg = f"[{ativo}] CRÍTICO (analisar_sinal): Live trading habilitado mas OperadorBinance é None. Abortando análise."
        critical_component_errors.append(msg)

    if critical_component_errors:
        for error_msg in critical_component_errors:
            logger_sp.critical(error_msg)
        if PROMETHEUS_AVAILABLE:
            inc_errors(component="signal_processor_runtime_dependency_check", asset=ativo)
        # Consider sending a Telegram alert here if notifier is available and configured
        # await enviar_telegram(f"🚨 ALERTA CRÍTICO em analisar_sinal para {ativo}: Componentes essenciais em modo degradado. Análise abortada. Detalhes: {"; ".join(critical_component_errors)}")
        erros_str = "; ".join(critical_component_errors)
        
        # Atualizar signal_details com informações de erro
        signal_details["fallback_info"]["activated"] = True
        signal_details["fallback_info"]["component"] = "critical_components"
        signal_details["fallback_info"]["reason"] = erros_str
        signal_details["internal_alerts_warnings"].append({
            "type": "critical_error",
            "message": erros_str
        })
        
        return signal_details, f"Análise de sinal para {ativo} abortada devido a componentes críticos inválidos/ausentes em runtime. Erros: {erros_str}"
    # --- Fim dos Runtime Sanity Checks ---

    # --- Process Pending Model Evaluations (Ponto 7) ---
    # Ensure df_original and its index are valid before proceeding
    if df_original is not None and not df_original.empty and isinstance(df_original.index, pd.DatetimeIndex):
        # Atualizar timestamp no signal_details
        signal_details["timestamp"] = df_original.index[-1].isoformat()
        
        current_eval_time = df_original.index[-1]
        n_minutes_for_eval = config.get("n_minutes_for_eval", DEFAULT_N_MINUTES_FOR_EVAL)
        profit_threshold_percent = config.get("profit_threshold_percent", DEFAULT_PROFIT_THRESHOLD_PERCENT)

        if ativo in pending_model_evaluations:
            evaluated_indices = []
            for i_eval, eval_item in enumerate(pending_model_evaluations[ativo]):
                # Check if current_eval_time (timestamp of the current candle) is at or after the stored eval_timestamp
                if current_eval_time >= eval_item["eval_timestamp"]:
                    try:
                        # Price at the time of evaluation (using the current candle's close)
                        price_at_evaluation = df_original["Close"].iloc[-1]
                        price_at_decision = eval_item["price_at_decision"]
                        decision_made = eval_item["decision_made"]
                        actual_market_outcome = 0.5  # Default for "manter" or undefined

                        if decision_made == "comprar":
                            if price_at_evaluation > price_at_decision * (1 + profit_threshold_percent / 100.0):
                                actual_market_outcome = 1.0
                            else:
                                actual_market_outcome = 0.0
                        elif decision_made == "vender":
                            if price_at_evaluation < price_at_decision * (1 - profit_threshold_percent / 100.0):
                                actual_market_outcome = 1.0
                            else:
                                actual_market_outcome = 0.0
                        
                        if tracker and eval_item.get("model_id") and eval_item.get("prediction_value") is not None:
                            model_id_val = eval_item.get('model_id', 'N/A')
                            pred_value_val = eval_item.get('prediction_value', 'N/A')
                            eval_timestamp_val = eval_item.get('eval_timestamp', 'N/A')
                            # Format prices safely, handling potential None or non-numeric types if they sneak in
                            price_at_decision_fmt = f"{eval_item.get('price_at_decision', 0.0):.4f}"
                            price_at_evaluation_fmt = f"{price_at_evaluation:.4f}" if isinstance(price_at_evaluation, (int, float)) else "N/A"

                            log_message_parts = [
                                f"[{ativo}] EVALUATING past prediction for model {model_id_val}.",
                                f"Decision: {decision_made} at {price_at_decision_fmt}.",
                                f"Pred Value: {pred_value_val}.",
                                f"Eval Time: {current_eval_time} (Target: {eval_timestamp_val}).",
                                f"Eval Price: {price_at_evaluation_fmt}.",
                                f"Outcome: {actual_market_outcome}"
                            ]
                            logger_sp.info(" ".join(log_message_parts))
                            tracker.record_prediction(
                                model_id=eval_item["model_id"],
                                prediction=eval_item["prediction_value"],
                                actual_result=actual_market_outcome
                            )
                        evaluated_indices.append(i_eval)
                    except Exception as eval_err:
                        logger_sp.error(f"[{ativo}] Error evaluating past prediction: {eval_err}", exc_info=True)
                        if PROMETHEUS_AVAILABLE: inc_errors("model_evaluation", ativo)
                        evaluated_indices.append(i_eval)  # Still mark for removal even if evaluation fails
                        
                        # Adicionar alerta ao signal_details
                        signal_details["internal_alerts_warnings"].append({
                            "type": "model_evaluation_error",
                            "message": f"Erro ao avaliar predição passada: {str(eval_err)}"
                        })
            
            # Remove evaluated items (in reverse order to avoid index shifting issues)
            for i_to_remove in sorted(evaluated_indices, reverse=True):
                if i_to_remove < len(pending_model_evaluations[ativo]):
                    pending_model_evaluations[ativo].pop(i_to_remove)
    # --- End Process Pending Model Evaluations ---

    model_distiller = config.get("model_distiller")
    adaptive_ensemble = config.get("adaptive_ensemble")

    try:
        # 1. Validate Input
        valido, df = validar_entrada_sinal(df_original, ativo)
        if not valido:
            # If df is None, it means waiting for more data, not an error
            if df is None:
                logger.info(f"[{ativo}] Signal analysis waiting for more data.")
                
                # Atualizar signal_details com informação de espera
                signal_details["internal_alerts_warnings"].append({
                    "type": "waiting_for_data",
                    "message": "Análise de sinal aguardando mais dados"
                })
                
                return signal_details, None
            else:
                logger.warning(f"[{ativo}] Signal analysis cancelled due to invalid input.")
                
                # Atualizar signal_details com informação de entrada inválida
                signal_details["internal_alerts_warnings"].append({
                    "type": "invalid_input",
                    "message": "Análise de sinal cancelada devido a entrada inválida"
                })
                
                return signal_details, None

        # --- Etapa 018: Get strategy config based on regime (MOVED HERE) ---
        logger.info(f"[{ativo}] DEBUG: strategy_config tipo={type(strategy_config)}, valor={strategy_config}")
        logger.info(f"[{ativo}] DEBUG: context_switcher tipo={type(context_switcher)}, disponível={context_switcher is not None}")

        if df is not None:
            atr_cols = [col for col in df.columns if "ATR" in col]
            adx_cols = [col for col in df.columns if "ADX" in col or "DX" in col]
            logger.info(f"[{ativo}] DEBUG: Colunas ATR disponíveis: {atr_cols}")
            logger.info(f"[{ativo}] DEBUG: Colunas ADX disponíveis: {adx_cols}")
            if atr_cols and len(df) > 0:
                logger.info(f"[{ativo}] DEBUG: Último valor ATR: {df[atr_cols[0]].iloc[-1]}")
            if adx_cols and len(df) > 0:
                logger.info(f"[{ativo}] DEBUG: Último valor ADX: {df[adx_cols[0]].iloc[-1]}")
            
            # Atualizar input_summary no signal_details
            if "Close" in df.columns and len(df) > 0:
                signal_details["input_summary"]["close_price"] = float(df["Close"].iloc[-1])
            if "Volume" in df.columns and len(df) > 0:
                signal_details["input_summary"]["volume"] = float(df["Volume"].iloc[-1])
            
            # Adicionar alguns indicadores chave ao input_summary
            for indicator in ["RSI_14", "ATR_14", "ADX_14"]:
                if indicator in df.columns and len(df) > 0:
                    signal_details["input_summary"][indicator.lower()] = float(df[indicator].iloc[-1]) if not pd.isna(df[indicator].iloc[-1]) else None

        current_regime = MarketRegime.INDEFINIDO
        active_strategy = strategy_config.get("DEFAULT", {}) if strategy_config else {}
        if context_switcher and strategy_config:
            try:
                current_regime = context_switcher.identificar_regime(df)
                regime_name = current_regime # Use the string directly
                logger.info(f"[{ativo}] DEBUG: Regime identificado: {regime_name}")
                active_strategy = strategy_config.get(regime_name, strategy_config.get("DEFAULT", {}))
                strategy_description = active_strategy.get("description", "Default")
                logger.info(f"[{ativo}] Regime: {regime_name} | Strategy: {strategy_description}")
                
                # Atualizar regime e estratégia no signal_details
                signal_details["market_regime"] = regime_name
                signal_details["active_strategy_description"] = strategy_description
                
                # Adicionar parâmetros da estratégia ativa ao signal_details
                for param_key, param_value in active_strategy.items():
                    if param_key not in ["description", "active_validators"] and not isinstance(param_value, dict):
                        signal_details["active_strategy_parameters"][param_key] = param_value
                
            except Exception as regime_err:
                logger.error(f"[{ativo}] Erro ao identificar regime: {regime_err}. Usando DEFAULT.")
                current_regime = MarketRegime.INDEFINIDO
                active_strategy = strategy_config.get("DEFAULT", {})
                
                # Adicionar alerta ao signal_details
                signal_details["internal_alerts_warnings"].append({
                    "type": "regime_identification_error",
                    "message": f"Erro ao identificar regime: {str(regime_err)}. Usando DEFAULT."
                })
        else:
            logger.warning(f"[{ativo}] ContextSwitcher ou Strategy Config não disponíveis. Usando estratégia DEFAULT.")
            
            # Adicionar alerta ao signal_details
            signal_details["internal_alerts_warnings"].append({
                "type": "missing_components",
                "message": "ContextSwitcher ou Strategy Config não disponíveis. Usando estratégia DEFAULT."
            })

        limiar_compra = active_strategy.get("limiar_compra", config.get("limiar_compra", 0.65))
        limiar_venda = active_strategy.get("limiar_venda", config.get("limiar_venda", 0.35))
        active_validators = active_strategy.get("active_validators", [
            "zonas_rejeicao",
            "volume_profile",
            "filtros_institucionais"
        ])
        
        # Atualizar limiares no signal_details
        signal_details["final_decision"]["thresholds_used"]["buy"] = limiar_compra
        signal_details["final_decision"]["thresholds_used"]["sell"] = limiar_venda

        volume_spike_detectado = False
        if ATTACK_DETECTOR_AVAILABLE and attack_detector:
            try:
                volume_spike_detectado = attack_detector.detect_volume_spike(df)
                if volume_spike_detectado:
                    logger.warning(f"[{ativo}] Alerta de possível volume artificial (Volume Spike) detectado.")
                
                # Atualizar attack_detector no signal_details
                signal_details["ai_components"]["attack_detector"]["volume_spike_detected"] = volume_spike_detectado
                
                if volume_spike_detectado:
                    signal_details["internal_alerts_warnings"].append({
                        "type": "volume_spike",
                        "message": "Alerta de possível volume artificial (Volume Spike) detectado."
                    })
                
            except Exception as attack_err:
                logger.error(f"[{ativo}] Erro ao executar detect_volume_spike: {attack_err}", exc_info=True)
                
                # Adicionar alerta ao signal_details
                signal_details["internal_alerts_warnings"].append({
                    "type": "attack_detector_error",
                    "message": f"Erro ao executar detect_volume_spike: {str(attack_err)}"
                })

        news_score = 0.5 
        if NEWS_PROVIDER_AVAILABLE and news_provider:
            try:
                news_score = await news_provider.get_recent_news_score(ativo)
                logger.info(f"[{ativo}] News Score: {news_score:.2f}")
                
                # Atualizar news_score no signal_details
                signal_details["ai_components"]["news_provider"]["score"] = news_score
                
            except Exception as news_err:
                logger.error(f"[{ativo}] Erro ao obter news score: {news_err}")
                news_score = 0.5 
                
                # Adicionar alerta ao signal_details
                signal_details["internal_alerts_warnings"].append({
                    "type": "news_provider_error",
                    "message": f"Erro ao obter news score: {str(news_err)}"
                })
        else:
            logger.debug(f"[{ativo}] News Provider não disponível ou não inicializado.")
            
            # Atualizar news_score no signal_details (valor padrão)
            signal_details["ai_components"]["news_provider"]["score"] = news_score

        if df is not None: 
            df.loc[:, "news_score"] = news_score

        i = -1 
        if df is not None: 
            i = len(df) - 1

        processador_book = processadores_book.get(ativo)
        book_state = processador_book.current_state if processador_book else BookState(config={})
        agente_rl = agentes_rl.get(ativo)
        ambiente_rl = ambientes_rl.get(ativo)
        acao_rl = 0 
        estado_rl = None
        recompensa_rl = 0.0
        
        # Atualizar book_imbalance no signal_details
        if book_state:
            signal_details["validators"]["book_imbalance"]["imbalance_value"] = book_state.imbalance

        if RL_AVAILABLE and agente_rl and ambiente_rl:
            try:
                if df is not None and "RSI_14" not in df.columns:
                    logger.warning(f"[{ativo}] RSI_14 not found in DataFrame for RL. Calculating...")
                    try:
                        df.ta.rsi(length=14, append=True)
                        logger.info(f"[{ativo}] RSI_14 calculated and appended for RL.")
                    except Exception as rsi_calc_err:
                        logger.error(f"[{ativo}] Failed to calculate RSI_14 for RL: {rsi_calc_err}")
                        
                        # Adicionar alerta ao signal_details
                        signal_details["internal_alerts_warnings"].append({
                            "type": "rsi_calculation_error",
                            "message": f"Falha ao calcular RSI_14 para RL: {str(rsi_calc_err)}"
                        })
                        
                ambiente_rl.atualizar_dados(df)
                estado_rl = ambiente_rl.obter_estado()
                if estado_rl is not None: 
                    acao_rl = agente_rl.escolher_acao(estado_rl)
                    proximo_estado, recompensa_rl, _ = ambiente_rl.step(acao_rl)
                    if proximo_estado is not None:
                        agente_rl.aprender(estado_rl, acao_rl, recompensa_rl, proximo_estado)
                    else:
                        logger.warning(f"[{ativo}] RL: Próximo estado inválido, aprendizado pulado.")
                        
                        # Adicionar alerta ao signal_details
                        signal_details["internal_alerts_warnings"].append({
                            "type": "rl_learning_skipped",
                            "message": "Próximo estado inválido, aprendizado RL pulado."
                        })
                        
                    logger.info(f"[{ativo}] RL Ciclo: Estado={estado_rl}, Ação Escolhida={acao_rl}, Recompensa={recompensa_rl:.6f}")
                    
                    # Atualizar RL no signal_details
                    signal_details["ai_components"]["rl_agent"]["action"] = acao_rl
                    signal_details["ai_components"]["rl_agent"]["reward"] = recompensa_rl
                    signal_details["ai_components"]["rl_agent"]["state_summary"] = str(estado_rl)[:100] if estado_rl is not None else None
                    
                    # Atualizar versão do modelo RL no signal_details
                    if hasattr(agente_rl, 'model_version'):
                        signal_details["component_versions"]["rl_agent_model"] = agente_rl.model_version
                    
                else:
                    logger.warning(f"[{ativo}] RL: Estado inválido obtido, ciclo RL pulado.")
                    
                    # Adicionar alerta ao signal_details
                    signal_details["internal_alerts_warnings"].append({
                        "type": "rl_invalid_state",
                        "message": "Estado inválido obtido, ciclo RL pulado."
                    })
            except Exception as rl_err:
                logger.error(f"[{ativo}] Erro durante ciclo RL: {rl_err}")
                acao_rl = 0
                
                # Adicionar alerta ao signal_details
                signal_details["internal_alerts_warnings"].append({
                    "type": "rl_cycle_error",
                    "message": f"Erro durante ciclo RL: {str(rl_err)}"
                })

        governor_prediction_output = None
        selected_model_id = None
        # GOVERNANCE_AVAILABLE is implicitly true due to critical import check at module level
        if governor: # governor instance must be valid due to runtime check
            try:
                num_features = config.get("governance_model_num_features", 5) 
                window_size = config.get("governance_model_window_size", 10)
                # Ensure df has enough data and required columns for governance model input
                # This is a placeholder; actual feature engineering for governance model is needed.
                if df is not None and len(df) >= window_size and "Close" in df.columns: 
                    # Example: using last `window_size` close prices, reshaped. 
                    # Real implementation would use engineered features.
                    input_data_for_governance = df[["Close"]].iloc[-window_size:].values.reshape(1, window_size, 1) 
                    governor_prediction_output = governor.predict(input_data_for_governance)
                    selected_model_id = governor.get_selected_model_id()
                    logger.info(f"[{ativo}] Governança Neural: Modelo {selected_model_id} previu {governor_prediction_output}")
                    
                    # Atualizar governança neural no signal_details
                    if governor_prediction_output is not None:
                        if isinstance(governor_prediction_output, (np.ndarray, list)):
                            gov_pred_value = governor_prediction_output[0] if len(governor_prediction_output) > 0 else None
                            if isinstance(gov_pred_value, np.ndarray) and gov_pred_value.size > 0:
                                gov_pred_value = gov_pred_value.item(0)
                        else:
                            gov_pred_value = governor_prediction_output
                        
                        signal_details["ai_components"]["neural_governance"]["prediction"] = gov_pred_value
                    
                    signal_details["ai_components"]["neural_governance"]["model_id"] = selected_model_id
                    
                    # Atualizar versão do modelo de governança no signal_details
                    if hasattr(governor, 'model_version'):
                        signal_details["component_versions"]["neural_governance_model"] = governor.model_version
                    elif selected_model_id:
                        signal_details["component_versions"]["neural_governance_model"] = selected_model_id
                    
                    # Ponto 7: Store prediction for future evaluation instead of immediate tracking
                    # This replaces the old placeholder tracker.record_prediction call
                    # decisao_final will be determined later, so we store based on raw model output for now
                    # or we can store after decisao_final is known.
                    # Let's store it *after* decisao_final is known, so we have the actual decision.

                else:
                    logger.warning(f"[{ativo}] Dados insuficientes ou coluna 'Close' ausente para predição da Governança Neural. DF shape: {df.shape if df is not None else 'None'}, Len: {len(df) if df is not None else 'N/A'}")
                    
                    # Adicionar alerta ao signal_details
                    signal_details["internal_alerts_warnings"].append({
                        "type": "governance_insufficient_data",
                        "message": f"Dados insuficientes ou coluna 'Close' ausente para predição da Governança Neural. DF shape: {df.shape if df is not None else 'None'}, Len: {len(df) if df is not None else 'N/A'}"
                    })
            except Exception as gov_err:
                logger.error(f"[{ativo}] Erro durante predição da Governança Neural: {gov_err}", exc_info=True)
                if PROMETHEUS_AVAILABLE: inc_errors("neural_governance_predict", ativo)
                
                # Adicionar alerta ao signal_details
                signal_details["internal_alerts_warnings"].append({
                    "type": "governance_prediction_error",
                    "message": f"Erro durante predição da Governança Neural: {str(gov_err)}"
                })
        
        # 3. Calculate Score
        score_raw = calcular_score(df, i, ativo)
        tendencia = 0.0  # Placeholder, calcular_score foi simplificado
        forca = 0.0      # Placeholder
        volatilidade = 0.0  # Placeholder
        score = score_raw # Initial score
        
        # Atualizar score_raw no signal_details
        signal_details["processing_stages"]["raw_score"] = score_raw

        # 4. Classify Signal
        # The prever_classe function might use governor_prediction_output or its own model
        # For now, assume prever_classe uses score and other inputs. 
        # If governor is the sole decider, this logic changes.
        classe_raw, probabilidade_raw = await prever_classe(df, i, score, config, governor_prediction_output, current_regime)
        
        # Atualizar classe_raw e probabilidade_raw no signal_details
        signal_details["processing_stages"]["raw_class"] = classe_raw
        signal_details["processing_stages"]["raw_probability"] = probabilidade_raw
        
        # Atualizar versão do modelo de classificação no signal_details
        # Assumindo que prever_classe pode ter uma versão ou usar um modelo específico
        signal_details["component_versions"]["signal_classifier_model"] = "prever_classe_corrigido_v12"
        
        # 5. Detect Fakeout
        fakeout = detectar_fakeout(df, i)
        
        # Atualizar fakeout no signal_details
        signal_details["processing_stages"]["fakeout_detected"] = fakeout > 0.5
        signal_details["processing_stages"]["fakeout_value"] = fakeout

        # 6. Adjust Score (Book, Heuristics, RL)
        score_ajustado_book = ajustar_score_por_book(score, book_state, config, classe_raw)
        ajuste_heuristico = ajustar_heuristicas(df, score_ajustado_book, classe_raw) # Stubbed
        score_final_antes_rl = score_ajustado_book + ajuste_heuristico.get("ajuste_score", 0.0)
        
        # Atualizar scores ajustados no signal_details
        signal_details["processing_stages"]["score_after_book_adjustment"] = score_ajustado_book
        signal_details["processing_stages"]["score_after_heuristic_adjustment"] = score_final_antes_rl
        
        # Incorporar ação RL na decisão ou score (Exemplo: RL pode vetar ou confirmar)
        # Esta lógica de integração do RL precisa ser bem definida.
        # Exemplo simples: se RL diz HOLD (0), pode reduzir confiança de Compra/Venda.
        if acao_rl == 0 and (classe_raw == "comprar" or classe_raw == "vender"):
            score_final_com_rl = score_final_antes_rl * config.get("rl_hold_dampening_factor", 0.8) 
        else:
            score_final_com_rl = score_final_antes_rl
        score = score_final_com_rl
        
        # Atualizar score final pré-AI no signal_details
        signal_details["processing_stages"]["final_score_pre_ai"] = score_final_com_rl

        # 7. Final Classification (after all adjustments)
        classe, probabilidade = await prever_classe(df, i, score, config, governor_prediction_output, current_regime) # Re-classify with final score

        # 8. Validate Signal (Filters)
        validadores_ativos = active_strategy.get("active_validators", [])
        sinal_valido = True
        razao_invalidacao = ""
        
        # Atualizar validadores ativos no signal_details
        for validador in ["zonas_rejeicao", "volume_profile", "filtros_institucionais", "book_imbalance"]:
            signal_details["validators"][validador]["active"] = validador in validadores_ativos

        if "zonas_rejeicao" in validadores_ativos:
            valido_zr, razao_zr = validador_zona_rejeicao(df, i) # Stubbed
            if not valido_zr:
                sinal_valido = False
                razao_invalidacao += f"ZonaRejeicao: {razao_zr}; "
            
            # Atualizar validador zonas_rejeicao no signal_details
            signal_details["validators"]["zonas_rejeicao"]["passed"] = valido_zr
            signal_details["validators"]["zonas_rejeicao"]["reason"] = razao_zr
        
        if "volume_profile" in validadores_ativos:
            valido_vp, razao_vp = validador_volume_profile(df, i) # Stubbed
            if not valido_vp:
                sinal_valido = False
                razao_invalidacao += f"VolumeProfile: {razao_vp}; "
            
            # Atualizar validador volume_profile no signal_details
            signal_details["validators"]["volume_profile"]["passed"] = valido_vp
            signal_details["validators"]["volume_profile"]["reason"] = razao_vp

        if "filtros_institucionais" in validadores_ativos:
            valido_fi, razao_fi = validar_filtro_institucional(df, book_state)
            if not valido_fi:
                sinal_valido = False
                razao_invalidacao += f"FiltroInstitucional: {razao_fi}; "
            
            # Atualizar validador filtros_institucionais no signal_details
            signal_details["validators"]["filtros_institucionais"]["passed"] = valido_fi
            signal_details["validators"]["filtros_institucionais"]["reason"] = razao_fi
        
        if "book_imbalance" in validadores_ativos:
            valido_bi, razao_bi = validar_book_institucional(book_state, config, classe)
            if not valido_bi:
                sinal_valido = False
                razao_invalidacao += f"BookImbalance: {razao_bi}; "
            
            # Atualizar validador book_imbalance no signal_details
            signal_details["validators"]["book_imbalance"]["passed"] = valido_bi
            signal_details["validators"]["book_imbalance"]["reason"] = razao_bi

        # 9. Determine Final Decision
        decisao_final = "manter"
        if sinal_valido:
            if classe == "comprar" and score >= limiar_compra and not fakeout:
                decisao_final = "comprar"
            elif classe == "vender" and score <= limiar_venda and not fakeout:
                decisao_final = "vender"
        else:
            logger.info(f"[{ativo}] Sinal {classe} (score: {score:.4f}) invalidado. Razões: {razao_invalidacao}")
            decisao_final = "manter" # Ou uma decisão específica de rejeição
        
        # Atualizar decisão final no signal_details
        signal_details["final_decision"]["score"] = score
        signal_details["final_decision"]["class"] = classe
        signal_details["final_decision"]["probability"] = probabilidade
        signal_details["final_decision"]["decision"] = decisao_final
        signal_details["final_decision"]["reason_for_invalidation"] = razao_invalidacao

        # --- Ponto 7: Store prediction for future evaluation (after decisao_final is known) ---
        if tracker and selected_model_id and governor_prediction_output is not None and decisao_final in ["comprar", "vender", "manter"] and df is not None and not df.empty and isinstance(df.index, pd.DatetimeIndex):
            prediction_val_to_store = governor_prediction_output
            # Ensure prediction_val_to_store is a scalar value
            if isinstance(prediction_val_to_store, (np.ndarray, list)):
                prediction_val_to_store = prediction_val_to_store[0] if len(prediction_val_to_store) > 0 else 0.0
                if isinstance(prediction_val_to_store, np.ndarray):
                    prediction_val_to_store = prediction_val_to_store.item(0) if prediction_val_to_store.size > 0 else 0.0
            elif not isinstance(prediction_val_to_store, (int, float)):
                 logger_sp.warning(f"[{ativo}] governor_prediction_output (type: {type(prediction_val_to_store)}) is not a scalar, attempting to use score ({score:.4f}) for tracking instead.")
                 prediction_val_to_store = score # Fallback to overall score if governor output is not simple scalar
            
            decision_time = df.index[-1]
            n_minutes_for_eval_cfg = config.get("n_minutes_for_eval", DEFAULT_N_MINUTES_FOR_EVAL)
            eval_timestamp = decision_time + pd.Timedelta(minutes=n_minutes_for_eval_cfg)
            
            pending_eval_item = {
                "eval_timestamp": eval_timestamp,
                "model_id": selected_model_id,
                "prediction_value": float(prediction_val_to_store), # Ensure it's a float for the tracker
                "decision_made": decisao_final,
                "price_at_decision": df["Close"].iloc[-1],
                "asset": ativo
            }
            pending_model_evaluations[ativo].append(pending_eval_item)
            current_price_for_log = df["Close"].iloc[-1]
            log_msg_parts_stored_pred = [
                f"[{ativo}] Stored prediction by {selected_model_id} for evaluation at {eval_timestamp}.",
                f"Decision: {decisao_final}, Price: {current_price_for_log:.4f}, Pred Value: {prediction_val_to_store}"
            ]
            logger_sp.info(" ".join(log_msg_parts_stored_pred))
            
            # Atualizar informações de avaliação pendente no signal_details
            signal_details["ai_components"]["neural_governance"]["pending_evaluation"] = True
            signal_details["ai_components"]["neural_governance"]["evaluation_target_timestamp"] = eval_timestamp.isoformat()
        # --- End Ponto 7 Store --- 

        # 10. Log and Notify
        log_message = (
            f"[{ativo}] Sinal: {classe_raw} (Raw Score: {score_raw:.4f}) -> Score Final: {score:.4f} | Prob: {probabilidade:.2f} | Fakeout: {fakeout} | Decisão: {decisao_final.upper()} | Regime: {current_regime}"
            f" | Tendencia: {tendencia:.2f}, Forca: {forca:.2f}, Volatilidade: {volatilidade:.2f}"
            f" | Book Imbalance: {book_state.imbalance:.2f} | News: {news_score:.2f} | RL Action: {acao_rl}"
            f" | Gov Pred: {governor_prediction_output} (Model: {selected_model_id})"
        )
        logger.info(log_message)
        if decisao_final != "manter":
            await enviar_telegram(log_message)

        # 11. Execute Order (Etapa 006)
        if live_trading_enabled and operador and decisao_final != "manter":
            try:
                # Determine side and quantity based on decision
                side = SIDE_BUY if decisao_final == "comprar" else SIDE_SELL
                quantity = config.get("trading_config", {}).get("default_quantity", 0.001)
                
                # Execute order
                order_result = await operador.execute_order(ativo, side, quantity)
                logger.info(f"[{ativo}] Ordem executada: {order_result}")
                
                # Adicionar informação de execução de ordem ao signal_details
                signal_details["order_execution"] = {
                    "executed": True,
                    "side": side,
                    "quantity": quantity,
                    "result": str(order_result)
                }
                
            except Exception as order_err:
                logger.error(f"[{ativo}] Erro ao executar ordem: {order_err}", exc_info=True)
                if PROMETHEUS_AVAILABLE: inc_errors("order_execution", ativo)
                
                # Adicionar alerta ao signal_details
                signal_details["internal_alerts_warnings"].append({
                    "type": "order_execution_error",
                    "message": f"Erro ao executar ordem: {str(order_err)}"
                })
        elif decisao_final != "manter":
            logger.warning(f"[{ativo}] Operador Binance não disponível ou não inicializado. Ordem {decisao_final.upper()} não executada.")
            
            # Adicionar alerta ao signal_details
            signal_details["internal_alerts_warnings"].append({
                "type": "order_not_executed",
                "message": f"Operador Binance não disponível ou não inicializado. Ordem {decisao_final.upper()} não executada."
            })

        # 12. Fallback Check (Etapa 015)
        if fallback_manager:
            try:
                main_model = fallback_manager.get_main_model()
                if main_model is None:
                    logger.info(f"[{ativo}] Modelo principal não carregado e monitor não ativo. Tentando carregar agora (síncrono no get_main_model - pode bloquear)...")
                    
                    # Atualizar fallback_info no signal_details
                    signal_details["fallback_info"]["activated"] = True
                    signal_details["fallback_info"]["component"] = "main_model"
                    signal_details["fallback_info"]["reason"] = "Modelo principal não carregado"
                    signal_details["fallback_info"]["fallback_used"] = "fallback_decisor"
                    
                    # Adicionar alerta ao signal_details
                    signal_details["internal_alerts_warnings"].append({
                        "type": "main_model_not_loaded",
                        "message": "Modelo principal não carregado e monitor não ativo. Tentando carregar agora."
                    })
                    
                    # Fallback decision logic
                    logger.warning(f"[{ativo}] Modelo principal não disponível. Usando fallback decisor.")
                    fallback_decision = "neutro"
                    fallback_score = 0.5
                    logger.info(f"[{ativo}] Fallback Decisor: {fallback_decision} @ {fallback_score:.2f}")
                    
                    # Atualizar decisão final com fallback no signal_details
                    signal_details["final_decision"]["decision"] = "manter"  # Fallback to neutral
                    signal_details["final_decision"]["score"] = fallback_score
                    
                    # Log final decision with all components
                    logger.info(f"[{ativo}] Score: {score:.4f} (Raw: {score_raw:.2f}, Prob: {probabilidade:.2f}, Fakeout: {fakeout:.2f}, RL: {acao_rl}, Gov: {governor_prediction_output}, News: {news_score:.2f}) | Decisão: {fallback_decision.upper()}")
            except Exception as fallback_err:
                logger.error(f"[{ativo}] Erro ao verificar fallback: {fallback_err}", exc_info=True)
                if PROMETHEUS_AVAILABLE: inc_errors("fallback_check", ativo)
                
                # Adicionar alerta ao signal_details
                signal_details["internal_alerts_warnings"].append({
                    "type": "fallback_check_error",
                    "message": f"Erro ao verificar fallback: {str(fallback_err)}"
                })

        # Calculate and record latency
        end_time_analysis = time.monotonic()
        latency_ms = (end_time_analysis - start_time_analysis) * 1000
        if PROMETHEUS_AVAILABLE:
            signal_processing_latency_seconds.observe(latency_ms / 1000.0)
        
        # Atualizar latência no signal_details
        signal_details["execution_latency_ms"] = latency_ms

        # Return signal_details
        return signal_details, None
        
    except Exception as e:
        logger.error(f"[{ativo}] Erro não tratado em analisar_sinal: {e}", exc_info=True)
        if PROMETHEUS_AVAILABLE: inc_errors("signal_processor_unhandled", ativo)
        
        # Atualizar signal_details com informações de erro
        signal_details["internal_alerts_warnings"].append({
            "type": "unhandled_error",
            "message": f"Erro não tratado em analisar_sinal: {str(e)}"
        })
        
        # Calcular latência mesmo em caso de erro
        end_time_analysis = time.monotonic()
        latency_ms = (end_time_analysis - start_time_analysis) * 1000
        signal_details["execution_latency_ms"] = latency_ms
        
        return signal_details, f"Erro não tratado em analisar_sinal: {e}"
