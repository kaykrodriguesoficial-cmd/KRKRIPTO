"""Módulo do Simulador para backtesting de estratégias."""

import pandas as pd
import logging
import asyncio
import os
import json # Adicionado para salvar em JSON

logger = logging.getLogger(__name__)

class Simulator:
    """Classe para executar simulações de trading baseadas em dados históricos."""

    def __init__(self, config: dict):
        """Inicializa o simulador com a configuração fornecida e caminhos de simulação."""
        self.config = config
        self.simulation_file = simulation_file
        self.simulation_output = simulation_output
        self.historical_data = None
        self.metrics = {"signals_processed": 0, "errors": 0, "total_rows": 0}
        self.simulation_results = [] # Lista para armazenar resultados detalhados
        logger.info(f"Simulator inicializado com arquivo de simulação: {self.simulation_file} e saída: {self.simulation_output}")
        if self.simulation_file:
            self.load_historical_data(self.simulation_file)

    def load_historical_data(self, file_path: str):
        """Carrega dados históricos de um arquivo CSV."""
        logger.info(f"Tentando carregar dados históricos de: {file_path}")
        if not os.path.exists(file_path):
            logger.error(f"Arquivo não encontrado: {file_path}", exc_info=False)
            self.historical_data = None
            raise FileNotFoundError(f"Arquivo de dados históricos não encontrado: {file_path}")
        
        try:
            df = pd.read_csv(file_path, index_col='timestamp', parse_dates=['timestamp'], date_format='%Y-%m-%d %H:%M:%S')
            expected_cols = ["Open", "High", "Low", "Close", "Volume"]
            if not all(col in df.columns for col in expected_cols):
                logger.warning(f"Colunas esperadas {expected_cols} não encontradas em {file_path}. Colunas presentes: {list(df.columns)}")
            
            self.historical_data = df
            self.metrics["total_rows"] = len(df)
            logger.info(f"Dados históricos carregados com sucesso. {len(df)} linhas.")
        except ValueError as ve:
            logger.warning(f"Não foi possível aplicar o formato de data '%Y-%m-%d %H:%M:%S'. Tentando leitura sem formato explícito. Erro original: {ve}")
            df = pd.read_csv(file_path, index_col='timestamp', parse_dates=True)
            self.historical_data = df
            self.metrics["total_rows"] = len(df)
            logger.info(f"Dados históricos carregados com sucesso (fallback). {len(df)} linhas.")
        except Exception as e:
            logger.error(f"Erro ao carregar ou processar o arquivo CSV {file_path}: {e}")
            self.historical_data = None
            raise

    async def run_simulation(self, asset: str, processor_callback: callable, context: dict):
        """Executa a simulação iterando sobre os dados históricos."""
        logger.info(f"Iniciando simulação para o ativo: {asset}")
        self.metrics["signals_processed"] = 0 # Resetar métricas para nova execução
        self.metrics["errors"] = 0
        self.simulation_results = [] # Resetar resultados para nova execução

        if self.historical_data is None or self.historical_data.empty:
            logger.warning("Dados históricos não carregados ou vazios. Simulação não pode ser executada.")
            if not self.simulation_file:
                logger.info("Nenhum arquivo de simulação especificado para carregar dados.")
            self._save_results_to_file() # Salvar mesmo se não houver dados, para indicar tentativa
            return

        for i in range(1, len(self.historical_data) + 1):
            current_data_slice = self.historical_data.iloc[:i]
            timestamp = self.historical_data.index[i-1]
            signal_details = None # Inicializa como None
            try:
                # Assumindo que processor_callback (analisar_sinal) pode retornar detalhes do sinal
                signal_details = await processor_callback(asset, current_data_slice, context)
                self.metrics["signals_processed"] += 1
                self.simulation_results.append({
                    "timestamp": str(timestamp), # Converter timestamp para string para serialização JSON
                    "status": "processed",
                    "signal_details": signal_details # Pode ser None ou os detalhes retornados
                })
            except Exception as e:
                logger.error(f"Erro durante o processamento do sinal na simulação (linha {i}, timestamp: {timestamp}): {e}")
                self.metrics["errors"] += 1
                self.simulation_results.append({
                    "timestamp": str(timestamp),
                    "status": "error",
                    "error_message": str(e),
                    "signal_details": None
                })
        
        logger.info(f"Simulação concluída para {asset}. Sinais processados: {self.metrics['signals_processed']}, Erros: {self.metrics['errors']}")
        self._save_results_to_file()

    def _save_results_to_file(self):
        """Salva as métricas da simulação e os resultados detalhados em um arquivo JSON."""
        if not self.simulation_output:
            logger.warning("Nenhum arquivo de saída da simulação especificado. Resultados não serão salvos.")
            return

        output_data = {
            "simulation_metrics": self.metrics,
            "simulation_log": self.simulation_results
        }

        try:
            with open(self.simulation_output, 'w', encoding='utf-8') as f:
                json.dump(output_data, f, ensure_ascii=False, indent=4)
            logger.info(f"Resultados da simulação salvos com sucesso em: {self.simulation_output}")
        except IOError as e:
            logger.error(f"Erro ao salvar os resultados da simulação em {self.simulation_output}: {e}")
        except Exception as e:
            logger.error(f"Erro inesperado ao salvar os resultados da simulação: {e}")

    def get_metrics(self) -> dict:
        """Retorna as métricas coletadas durante a simulação."""
        if self.historical_data is None:
             return {}
        return self.metrics

