#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de teste para notificações Telegram do sistema KR_KRIPTO_FULL_Advanced
Este script envia uma mensagem de teste para o Telegram usando as credenciais configuradas.

Uso:
    python test_telegram_notification.py --config config/config.json
"""

import os
import sys
import json
import argparse
import logging
import requests
import datetime

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('telegram_test')

def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='Testar notificações Telegram')
    parser.add_argument('--config', type=str, default='config/config.json',
                        help='Caminho para o arquivo de configuração')
    parser.add_argument('--token', type=str, help='Token do bot Telegram (opcional)')
    parser.add_argument('--chat_id', type=str, help='ID do chat Telegram (opcional)')
    return parser.parse_args()

def load_config(config_path):
    """Carregar configuração do sistema."""
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
        return config
    except Exception as e:
        logger.error(f"Erro ao carregar configuração: {e}")
        return {}

def send_test_message(bot_token, chat_id):
    """Enviar mensagem de teste para o Telegram."""
    try:
        # Formatar mensagem de teste
        message = f"""🔔 TESTE KR_KRIPTO: *COMPRA* *BTCUSDT*

📊 Timeframe: *1h*
💰 Preço de Entrada: *50000.00000000*
🎯 Alvo de Saída: *52500.00000000*
🛑 Stop Loss: *49000.00000000*
⏱️ Duração Estimada: *médio prazo (horas/dias)*
🔒 Confiança: *85.00%*

👉 Ação Recomendada: *Executar compra com tamanho de posição normal*

[MENSAGEM DE TESTE - {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}]"""
        
        # Enviar mensagem
        url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        payload = {
            "chat_id": chat_id,
            "text": message,
            "parse_mode": "Markdown"
        }
        
        logger.info(f"Enviando mensagem de teste para chat_id: {chat_id}")
        logger.info(f"Usando bot_token: {bot_token[:5]}...{bot_token[-5:]}")
        
        response = requests.post(url, json=payload)
        
        # Verificar resposta
        if response.status_code == 200:
            logger.info("✅ Mensagem de teste enviada com sucesso!")
            logger.info(f"Resposta: {response.json()}")
            return True
        else:
            logger.error(f"❌ Erro ao enviar mensagem: {response.status_code}")
            logger.error(f"Resposta: {response.text}")
            return False
            
    except Exception as e:
        logger.error(f"❌ Erro ao enviar mensagem: {e}")
        return False

def verify_bot_token(bot_token):
    """Verificar se o token do bot é válido."""
    try:
        url = f"https://api.telegram.org/bot{bot_token}/getMe"
        response = requests.get(url)
        
        if response.status_code == 200:
            bot_info = response.json()
            logger.info(f"✅ Token válido! Bot: @{bot_info['result']['username']}")
            return True
        else:
            logger.error(f"❌ Token inválido! Resposta: {response.text}")
            return False
    except Exception as e:
        logger.error(f"❌ Erro ao verificar token: {e}")
        return False

def main():
    """Função principal."""
    args = parse_args()
    
    # Carregar configuração
    config = load_config(args.config)
    
    # Obter token e chat_id
    bot_token = args.token or config.get('telegram_bot_token', '')
    chat_id = args.chat_id or config.get('telegram_chat_id', '')
    
    # Verificar se token e chat_id estão definidos
    if not bot_token:
        logger.error("❌ Token do bot não definido!")
        sys.exit(1)
    
    if not chat_id:
        logger.error("❌ ID do chat não definido!")
        sys.exit(1)
    
    # Verificar token
    logger.info("Verificando token do bot...")
    if not verify_bot_token(bot_token):
        logger.error("❌ Verificação do token falhou!")
        sys.exit(1)
    
    # Enviar mensagem de teste
    logger.info("Enviando mensagem de teste...")
    if send_test_message(bot_token, chat_id):
        logger.info("✅ Teste concluído com sucesso!")
    else:
        logger.error("❌ Teste falhou!")
        sys.exit(1)

if __name__ == "__main__":
    main()
