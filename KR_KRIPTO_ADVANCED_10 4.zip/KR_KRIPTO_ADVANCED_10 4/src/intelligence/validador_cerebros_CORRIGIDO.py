
import os
import json
from collections import defaultdict
from inteligencia.log_por_ativo import registrar_log

ARQUIVO_VALIDACAO = "memoria/validacao_cerebros.json"

def carregar_memoria_validacao():
    if not os.path.exists(ARQUIVO_VALIDACAO):
        return {}
    try:
        with open(ARQUIVO_VALIDACAO, 'r') as f:
            return json.load(f)
    except Exception as e:
        registrar_log("GLOBAL", f"❌ Erro ao carregar memoria de validacao: {e}", "validador_cerebros", "ERROR")
        return {}

def salvar_memoria_validacao(memoria):
    try:
        with open(ARQUIVO_VALIDACAO, 'w') as f:
            json.dump(memoria, f, indent=2)
    except Exception as e:
        registrar_log("GLOBAL", f"❌ Erro ao salvar memoria de validacao: {e}", "validador_cerebros", "ERROR")

def registrar_resultado_cerebros(ativo, classe_real, decisoes_por_ia):
    memoria = carregar_memoria_validacao()

    if ativo not in memoria:
        memoria[ativo] = {}

    for cerebro, classe_prevista in decisoes_por_ia.items():
        if cerebro not in memoria[ativo]:
            memoria[ativo][cerebro] = {"acertos": 0, "total": 0}

        memoria[ativo][cerebro]["total"] += 1
        if classe_prevista == classe_real:
            memoria[ativo][cerebro]["acertos"] += 1

        registrar_log(ativo, f"📊 Resultado {cerebro}: Previsto={classe_prevista} | Real={classe_real}", "validador_cerebros")

    salvar_memoria_validacao(memoria)

def calcular_pesos_por_ia(ativo):
    memoria = carregar_memoria_validacao()
    pesos = {}

    if ativo not in memoria:
        return {"lstm": 1.0, "heuristica": 1.0, "soberana": 1.0}

    for cerebro, dados in memoria[ativo].items():
        if dados["total"] == 0:
            pesos[cerebro] = 1.0
        else:
            pesos[cerebro] = round(dados["acertos"] / dados["total"], 4)

    return pesos

def resetar_validacao_cerebros():
    if os.path.exists(ARQUIVO_VALIDACAO):
        os.remove(ARQUIVO_VALIDACAO)
        registrar_log("GLOBAL", "🧹 Reset completo da memoria de validacao dos cerebros", "validador_cerebros")
