
# inteligencia/validador_entrada_sinal_v1.py

from inteligencia.validadores.validador_temporal import validar_integridade_temporal
from inteligencia.estado.estado_global import obter_estado
from executors.logger import log_erro

def validar_entrada_sinal(df, ativo):
    """
    Verifica a integridade do DataFrame e do estado do ativo antes de processar o sinal.
    """
    try:
        if df is None or df.empty:
            log_erro(f"[VALIDADOR] ❌ DataFrame vazio para {ativo}")
            return False

        if not validar_integridade_temporal(df):
            log_erro(f"[VALIDADOR] ❌ Violação de integridade temporal para {ativo}")
            return False

        estado = obter_estado(ativo)
        if estado is None:
            log_erro(f"[VALIDADOR] ⚠️ Estado inexistente para {ativo}")
            return False

        return True

    except Exception as e:
        log_erro(f"[VALIDADOR] Erro ao validar entrada para {ativo}: {e}")
        return False
