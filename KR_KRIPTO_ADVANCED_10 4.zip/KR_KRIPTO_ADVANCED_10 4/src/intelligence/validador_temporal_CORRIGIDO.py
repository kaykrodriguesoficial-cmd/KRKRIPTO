
import time
from inteligencia.log_por_ativo import registrar_log

def validador_temporal(vetor_x, ativo="BTCUSDT", delay_segundos=10, limite_var_percentual=0.4, modo="scalp"):
    try:
        resultado = {"valido": True, "motivo": "Sinal aprovado"}

        tempo_sinal = vetor_x.get("timestamp_sinal", time.time())
        preco_sinal = vetor_x.get("preco_sinal", None)
        preco_atual = vetor_x.get("preco_atual", None)

        tempo_decorrido = time.time() - tempo_sinal

        if tempo_decorrido > delay_segundos:
            motivo = f"⏱️ Atraso de {tempo_decorrido:.1f}s excede o limite de {delay_segundos}s"
            registrar_log(ativo, motivo)
            return {"valido": False, "motivo": motivo}

        if preco_sinal is not None and preco_atual is not None:
            variacao = abs(preco_atual - preco_sinal) / preco_sinal
            if variacao > limite_var_percentual:
                motivo = f"📉 Variação de {variacao*100:.2f}% excede o limite de {limite_var_percentual*100:.2f}%"
                registrar_log(ativo, motivo)
                return {"valido": False, "motivo": motivo}

        return resultado
    except Exception as e:
        registrar_log(ativo, f"[ERRO TEMPORAL] {e}")
        return {"valido": False, "motivo": str(e)}
