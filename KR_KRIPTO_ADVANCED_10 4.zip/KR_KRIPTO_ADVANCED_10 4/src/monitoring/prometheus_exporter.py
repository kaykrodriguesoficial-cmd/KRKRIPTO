# -*- coding: utf-8 -*-
"""
Módulo unificado para gerenciar e exportar métricas Prometheus.
Versão compatível com Mac M1 (ARM64) com tratamento robusto de duplicidade de métricas.

Esta versão corrige o problema de inicialização das métricas no ambiente Mac M1,
garantindo que os argumentos obrigatórios sejam fornecidos corretamente e
evitando duplicidade de métricas no CollectorRegistry através de registros isolados.

Versão: 4.0.0 (Unificada)
Data: 2025-06-03
"""

import os
import sys
import time
import uuid
import logging
import platform
import re
import threading
import traceback
from typing import Dict, Any, Optional, List, Union, Callable

# Configuração de logging
logger = logging.getLogger("kr_kripto_prometheus")

# Verificar se estamos em um Mac M1
IS_MAC_M1 = platform.machine().lower() in ['arm64', 'arm']

def is_mac_m1():
    """Verifica se o ambiente atual é um Mac M1 (ARM64)."""
    return IS_MAC_M1

# Gerar um prefixo único para métricas para evitar duplicação
INSTANCE_ID = str(uuid.uuid4())[:8]
METRIC_PREFIX = f"kr_{INSTANCE_ID}_"
USE_UNIQUE_PREFIX = False  # Será ativado apenas se detectarmos duplicação

# Importar prometheus_client com tratamento de erro robusto
try:
    import prometheus_client
    from prometheus_client import Counter, Gauge, Histogram, Summary, start_http_server, REGISTRY
    from prometheus_client.registry import Collector, CollectorRegistry
    PROMETHEUS_AVAILABLE = True
    
    # Criar um registro isolado para esta instância
    # Isso evita completamente conflitos de métricas duplicadas
    ISOLATED_REGISTRY = CollectorRegistry()
    
    # Tentar limpar o registro para evitar duplicação
    try:
        # Criar um novo registro limpo
        NEW_REGISTRY = CollectorRegistry()
        # Não substituir REGISTRY global para manter compatibilidade
    except Exception as reg_e:
        logger.warning(f"Não foi possível criar novo registro Prometheus: {reg_e}")
        NEW_REGISTRY = REGISTRY
    
except ImportError as e:
    logger.warning(f"Falha ao importar biblioteca prometheus_client: {e}. Métricas serão armazenadas apenas em memória.")
    PROMETHEUS_AVAILABLE = False
    
    # Definir classes stub para métricas
    class MetricStub:
        def __init__(self, *args, **kwargs):
            self.name = kwargs.get('name', 'stub_metric')
            self.documentation = kwargs.get('documentation', 'Stub metric')
            self.labels_dict = {}
            
        def labels(self, **kwargs):
            key = tuple(sorted(kwargs.items()))
            if key not in self.labels_dict:
                self.labels_dict[key] = self
            return self.labels_dict[key]
            
        def inc(self, amount=1):
            logger.debug(f"STUB: {self.name}.inc({amount})")
            
        def set(self, value):
            logger.debug(f"STUB: {self.name}.set({value})")
            
        def observe(self, value):
            logger.debug(f"STUB: {self.name}.observe({value})")
            
        def set_to_current_time(self):
            logger.debug(f"STUB: {self.name}.set_to_current_time()")
    
    class Counter(MetricStub): 
        def __init__(self, name="stub_counter", documentation="Stub counter for environments without prometheus_client", *args, **kwargs):
            super().__init__(name=name, documentation=documentation, *args, **kwargs)
    
    class Gauge(MetricStub): 
        def __init__(self, name="stub_gauge", documentation="Stub gauge for environments without prometheus_client", *args, **kwargs):
            super().__init__(name=name, documentation=documentation, *args, **kwargs)
    
    class Histogram(MetricStub): 
        def __init__(self, name="stub_histogram", documentation="Stub histogram for environments without prometheus_client", *args, **kwargs):
            super().__init__(name=name, documentation=documentation, *args, **kwargs)
            
    class Summary(MetricStub):
        def __init__(self, name="stub_summary", documentation="Stub summary for environments without prometheus_client", *args, **kwargs):
            super().__init__(name=name, documentation=documentation, *args, **kwargs)
    
    # Definir função stub para start_http_server
    def start_http_server(*args, **kwargs):
        logger.warning("Não é possível iniciar servidor HTTP: biblioteca prometheus_client não está disponível.")
    
    # Definir REGISTRY stub
    class RegistryStub:
        def register(self, *args, **kwargs):
            pass
        def get_sample_value(self, *args, **kwargs):
            return None
    REGISTRY = RegistryStub()
    ISOLATED_REGISTRY = RegistryStub()
    NEW_REGISTRY = RegistryStub()
    
    class Collector:
        pass
    
    class CollectorRegistry:
        def __init__(self, *args, **kwargs):
            pass
        def register(self, *args, **kwargs):
            pass
        def get_sample_value(self, *args, **kwargs):
            return None

# Tentativa de importar notifier (ajustar caminhos se necessário)
try:
    from infrastructure.notifier import enviar_telegram
    NOTIFIER_AVAILABLE = True
except ImportError:
    try:
        from src.infrastructure.notifier import enviar_telegram
        NOTIFIER_AVAILABLE = True
    except ImportError:
        NOTIFIER_AVAILABLE = False
        async def enviar_telegram(*args, **kwargs): # Stub function
            logger.error("Notifier module (enviar_telegram) not available.")

# Dicionário para rastrear métricas já registradas
_registered_metrics = {}

class PrometheusExporterStub:
    """Stub para PrometheusExporter quando o Prometheus não está disponível."""
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Inicializa o stub do PrometheusExporter.
        
        Args:
            config: Configuração do sistema
        """
        self.config = config or {}
        self.metrics = {}
        self.instance_id = INSTANCE_ID
        logger.warning(f"STUB EM MEMÓRIA: PrometheusExporter inicializado, mas módulo real não encontrado. ID: {self.instance_id}")
        
    def counter(self, name: str, description: str, labels: List[str] = None) -> Any:
        """
        Cria um contador em memória.
        
        Args:
            name: Nome da métrica
            description: Descrição da métrica
            labels: Lista de labels para a métrica
            
        Returns:
            Objeto contador em memória
        """
        key = f"counter_{name}"
        if key not in self.metrics:
            self.metrics[key] = {
                "type": "counter",
                "name": name,
                "description": description,
                "labels": labels or [],
                "values": {}
            }
        return self.metrics[key]
        
    def gauge(self, name: str, description: str, labels: List[str] = None) -> Any:
        """
        Cria um gauge em memória.
        
        Args:
            name: Nome da métrica
            description: Descrição da métrica
            labels: Lista de labels para a métrica
            
        Returns:
            Objeto gauge em memória
        """
        key = f"gauge_{name}"
        if key not in self.metrics:
            self.metrics[key] = {
                "type": "gauge",
                "name": name,
                "description": description,
                "labels": labels or [],
                "values": {}
            }
        return self.metrics[key]
        
    def histogram(self, name: str, description: str, buckets: List[float] = None, labels: List[str] = None) -> Any:
        """
        Cria um histograma em memória.
        
        Args:
            name: Nome da métrica
            description: Descrição da métrica
            buckets: Lista de buckets para o histograma
            labels: Lista de labels para a métrica
            
        Returns:
            Objeto histograma em memória
        """
        key = f"histogram_{name}"
        if key not in self.metrics:
            self.metrics[key] = {
                "type": "histogram",
                "name": name,
                "description": description,
                "buckets": buckets or [0.1, 0.5, 1.0, 5.0, 10.0],
                "labels": labels or [],
                "values": {}
            }
        return self.metrics[key]
        
    def summary(self, name: str, description: str, labels: List[str] = None) -> Any:
        """
        Cria um summary em memória.
        
        Args:
            name: Nome da métrica
            description: Descrição da métrica
            labels: Lista de labels para a métrica
            
        Returns:
            Objeto summary em memória
        """
        key = f"summary_{name}"
        if key not in self.metrics:
            self.metrics[key] = {
                "type": "summary",
                "name": name,
                "description": description,
                "labels": labels or [],
                "values": {}
            }
        return self.metrics[key]
        
    def start_http_server(self, port: int = 8000) -> None:
        """
        Simula o início do servidor HTTP.
        
        Args:
            port: Porta para o servidor HTTP
        """
        logger.warning(f"STUB: start_http_server chamado com porta {port}, mas Prometheus não está disponível.")
        
    def get_metrics(self) -> Dict[str, Any]:
        """
        Retorna todas as métricas armazenadas em memória.
        
        Returns:
            Dicionário com todas as métricas
        """
        return self.metrics

# --- Funções de Verificação de Métricas ---
def _check_metric_exists(name):
    """Verifica se uma métrica já existe no registro."""
    if not PROMETHEUS_AVAILABLE:
        return False
    
    # Verificar no dicionário local primeiro (mais rápido)
    if name.upper() in _registered_metrics:
        return True
    
    # Verificar no registro global do Prometheus
    # Converter nome para formato Prometheus (kr_nome_metrica)
    prometheus_name = f"kr_{name.lower()}"
    if prometheus_name.endswith('_total'):
        base_name = prometheus_name[:-6]  # Remover _total para métricas Counter
    else:
        base_name = prometheus_name
    
    # Verificar se alguma das variantes existe
    for variant in [base_name, f"{base_name}_total", f"{base_name}_created"]:
        try:
            if REGISTRY.get_sample_value(variant) is not None:
                return True
        except:
            pass
    
    return False

def _register_metric(metric_class, name, documentation, labels=None, **extra_kwargs):
    """Helper para registrar métricas evitando ValueError se já existir."""
    global USE_UNIQUE_PREFIX
    
    # Aplicar prefixo único se necessário para evitar duplicação
    if USE_UNIQUE_PREFIX:
        original_name = name
        name = f"{METRIC_PREFIX}{name.replace('kr_', '')}"
        logger.debug(f"Usando prefixo único para métrica: {original_name} -> {name}")
    
    # Verificar se a métrica já existe
    metric_exists = _check_metric_exists(name)
    
    if not PROMETHEUS_AVAILABLE:
        logger.warning(f"Não é possível registrar métrica {name}: biblioteca prometheus_client não está disponível.")
        # Criar e armazenar um stub para a métrica
        if metric_class == Counter:
            metric_stub = Counter(name=name, documentation=documentation)
        elif metric_class == Gauge:
            metric_stub = Gauge(name=name, documentation=documentation)
        elif metric_class == Histogram:
            metric_stub = Histogram(name=name, documentation=documentation)
        else:
            metric_stub = metric_class(name=name, documentation=documentation)
        globals()[name.upper()] = metric_stub
        _registered_metrics[name.upper()] = metric_stub
        return metric_stub
    
    # Se a métrica já existe, tentar recuperá-la
    if metric_exists:
        logger.debug(f"Métrica {name} já registrada. Recuperando existente.")
        existing_metric = globals().get(name.upper())
        if existing_metric:
            return existing_metric
        
        # Se não conseguimos recuperar do global, criar um stub seguro
        if metric_class == Counter:
            safe_metric = Counter(name=f"_dummy_{name}", documentation=documentation)
        elif metric_class == Gauge:
            safe_metric = Gauge(name=f"_dummy_{name}", documentation=documentation)
        elif metric_class == Histogram:
            safe_metric = Histogram(name=f"_dummy_{name}", documentation=documentation)
        else:
            safe_metric = metric_class(name=f"_dummy_{name}", documentation=documentation)
        
        globals()[name.upper()] = safe_metric
        _registered_metrics[name.upper()] = safe_metric
        return safe_metric
    
    # Se a métrica não existe, tentar registrá-la
    try:
        # Usar o novo registro limpo para evitar duplicação
        kwargs = {"registry": ISOLATED_REGISTRY}
        if labels:
            kwargs["labelnames"] = labels
        # Adicionar quaisquer outros kwargs passados (ex: buckets para Histogram)
        kwargs.update(extra_kwargs)
        
        # Tentar registrar a métrica
        metric = metric_class(name, documentation, **kwargs)
        globals()[name.upper()] = metric # Store metric in globals for easy access
        _registered_metrics[name.upper()] = metric
        logger.debug(f"Métrica {name} registrada com sucesso.")
        return metric
    except ValueError as e:
        # Se falhar por duplicidade, ativar o uso de prefixo único para futuras métricas
        if "Duplicated timeseries" in str(e):
            USE_UNIQUE_PREFIX = True
            logger.warning(f"Detectada duplicação de métrica. Ativando prefixo único para futuras métricas.")
            
            # Tentar novamente com prefixo único
            if not name.startswith(METRIC_PREFIX):
                return _register_metric(metric_class, f"{METRIC_PREFIX}{name.replace('kr_', '')}", documentation, labels, **extra_kwargs)
        
        logger.debug(f"Erro ao registrar métrica {name}: {e}. Tentando recuperar existente.")
        
        # Criar um stub seguro para a métrica
        if metric_class == Counter:
            safe_metric = Counter(name=f"_dummy_{name}", documentation=documentation)
        elif metric_class == Gauge:
            safe_metric = Gauge(name=f"_dummy_{name}", documentation=documentation)
        elif metric_class == Histogram:
            safe_metric = Histogram(name=f"_dummy_{name}", documentation=documentation)
        else:
            safe_metric = metric_class(name=f"_dummy_{name}", documentation=documentation)
        
        globals()[name.upper()] = safe_metric
        _registered_metrics[name.upper()] = safe_metric
        return safe_metric
    except Exception as e:
        logger.error(f"Erro inesperado ao registrar métrica {name}: {e}", exc_info=True)
        # Criar e armazenar um stub para a métrica em caso de erro
        if metric_class == Counter:
            metric_stub = Counter(name=f"_dummy_{name}", documentation=documentation)
        elif metric_class == Gauge:
            metric_stub = Gauge(name=f"_dummy_{name}", documentation=documentation)
        elif metric_class == Histogram:
            metric_stub = Histogram(name=f"_dummy_{name}", documentation=documentation)
        else:
            metric_stub = metric_class(name=f"_dummy_{name}", documentation=documentation)
        
        globals()[name.upper()] = metric_stub
        _registered_metrics[name.upper()] = metric_stub
        return metric_stub

def _get_metric(metric_name):
    """Helper para obter a métrica global com segurança."""
    # Verificar no dicionário de métricas registradas
    metric = _registered_metrics.get(metric_name.upper())
    if metric is not None:
        return metric
    
    # Verificar nas variáveis globais
    metric = globals().get(metric_name.upper())
    if metric is not None:
        # Adicionar ao dicionário para futuras consultas
        _registered_metrics[metric_name.upper()] = metric
        return metric
    
    logger.warning(f"Métrica {metric_name} não encontrada.")
    return None

class PrometheusExporter:
    """
    Exportador de métricas Prometheus para o sistema KR_KRIPTO_ADVANCED.
    Implementa registros isolados para cada instância e sistema de prefixos únicos.
    """
    
    # Instância global para compatibilidade com código existente
    _instance = None
    
    @classmethod
    def get_instance(cls, *args, **kwargs):
        """Retorna a instância global ou cria uma nova se não existir."""
        if cls._instance is None:
            cls._instance = cls(*args, **kwargs)
        return cls._instance
    
    def __init__(self, config: Dict[str, Any] = None, prefix: str = "", use_isolated_registry: bool = True):
        """
        Inicializa o exportador de métricas.
        
        Args:
            config: Configuração do sistema
            prefix: Prefixo para as métricas (opcional)
            use_isolated_registry: Se True, usa um registro isolado para evitar conflitos
        """
        self.config = config or {}
        self.metrics = {}
        self.prefix = prefix
        self.instance_id = str(uuid.uuid4())[:8]
        self.duplicate_detected = False
        self.use_isolated_registry = use_isolated_registry
        
        # Criar stub para quando Prometheus não está disponível
        self._stub = PrometheusExporterStub(config)
        
        # Criar registro isolado se solicitado
        if PROMETHEUS_AVAILABLE and use_isolated_registry:
            self.registry = CollectorRegistry()
        else:
            self.registry = ISOLATED_REGISTRY
            
        logger.info(f"PrometheusExporter v4.0.0 inicializado. Compatível com Mac M1: {IS_MAC_M1}. ID: {self.instance_id}")
        
        # Inicializar métricas padrão
        self._initialize_default_metrics()
        
    def _initialize_default_metrics(self):
        """Inicializa métricas padrão usadas pelo sistema."""
        # Métricas de sistema
        self.system_uptime = self.gauge(
            "kr_system_uptime_seconds",
            "Tempo de execução do sistema em segundos"
        )
        
        # Métricas de erros
        self.errors_total = self.counter(
            "kr_errors_total",
            "Número total de erros encontrados em diferentes componentes",
            ["component", "asset"]
        )
        
        # Métricas de conexão
        self.binance_connection_status = self.gauge(
            "kr_binance_connection_status",
            "Status da conexão com a API/Stream da Binance (1: online, 0: offline)",
            ["connection_type"]
        )
        
        # Métricas de componentes
        self.component_operational_status = self.gauge(
            "kr_component_operational_status",
            "Status operacional de componentes críticos (1: Real/Ativo, 0: Stub/Degradado/Inativo)",
            ["component_name", "asset"]
        )
        
        # Iniciar thread de atualização de métricas de sistema
        self._start_system_metrics_updater()
        
    def _start_system_metrics_updater(self) -> None:
        """Inicia thread para atualização periódica de métricas de sistema."""
        def updater():
            start_time = time.time()
            while True:
                try:
                    # Atualizar tempo de execução
                    uptime = time.time() - start_time
                    self.system_uptime.set(uptime)
                    
                    # Dormir por 10 segundos
                    time.sleep(10)
                except Exception as e:
                    logger.error(f"Erro ao atualizar métricas de sistema: {e}")
                    time.sleep(30)  # Esperar mais tempo em caso de erro
                    
        # Iniciar thread como daemon para que não bloqueie o encerramento do programa
        thread = threading.Thread(target=updater, daemon=True)
        thread.start()
        
    def _get_metric_name(self, name: str) -> str:
        """
        Gera um nome de métrica com prefixo se necessário.
        Adiciona prefixo único se duplicação foi detectada.
        """
        if self.duplicate_detected:
            return f"{self.prefix}_{self.instance_id}_{name}"
        elif self.prefix:
            return f"{self.prefix}_{name}"
        return name
        
    def counter(self, name: str, description: str, labels: List[str] = None) -> Counter:
        """
        Cria um contador Prometheus.
        
        Args:
            name: Nome da métrica
            description: Descrição da métrica
            labels: Lista de labels para a métrica
            
        Returns:
            Objeto Counter do Prometheus
        """
        if not PROMETHEUS_AVAILABLE:
            return self._stub.counter(name, description, labels)
            
        try:
            # Usar prefixo único se necessário
            if USE_UNIQUE_PREFIX and not name.startswith(METRIC_PREFIX):
                name = f"{METRIC_PREFIX}{name.replace('kr_', '')}"
                
            # Usar o registro isolado para esta instância
            return Counter(name, description, labels or [], registry=self.registry)
        except ValueError as e:
            if "Duplicated timeseries" in str(e):
                logger.warning("Detectada duplicação de métrica. Ativando prefixo único para futuras métricas.")
                self.duplicate_detected = True
                # Tentar novamente com prefixo único
                metric_name = self._get_metric_name(name)
                return Counter(metric_name, description, labels or [], registry=self.registry)
            else:
                logger.error(f"Erro ao criar contador {name}: {e}")
                return self._stub.counter(name, description, labels)
        except Exception as e:
            logger.error(f"Erro ao criar contador {name}: {e}")
            return self._stub.counter(name, description, labels)
            
    def gauge(self, name: str, description: str, labels: List[str] = None) -> Gauge:
        """
        Cria um gauge Prometheus.
        
        Args:
            name: Nome da métrica
            description: Descrição da métrica
            labels: Lista de labels para a métrica
            
        Returns:
            Objeto Gauge do Prometheus
        """
        if not PROMETHEUS_AVAILABLE:
            return self._stub.gauge(name, description, labels)
            
        try:
            # Usar prefixo único se necessário
            if USE_UNIQUE_PREFIX and not name.startswith(METRIC_PREFIX):
                name = f"{METRIC_PREFIX}{name.replace('kr_', '')}"
                
            # Usar o registro isolado para esta instância
            return Gauge(name, description, labels or [], registry=self.registry)
        except ValueError as e:
            if "Duplicated timeseries" in str(e):
                logger.warning("Detectada duplicação de métrica. Ativando prefixo único para futuras métricas.")
                self.duplicate_detected = True
                # Tentar novamente com prefixo único
                metric_name = self._get_metric_name(name)
                return Gauge(metric_name, description, labels or [], registry=self.registry)
            else:
                logger.error(f"Erro ao criar gauge {name}: {e}")
                return self._stub.gauge(name, description, labels)
        except Exception as e:
            logger.error(f"Erro ao criar gauge {name}: {e}")
            return self._stub.gauge(name, description, labels)
            
    def histogram(self, name: str, description: str, buckets: List[float] = None, labels: List[str] = None) -> Histogram:
        """
        Cria um histograma Prometheus.
        
        Args:
            name: Nome da métrica
            description: Descrição da métrica
            buckets: Lista de buckets para o histograma
            labels: Lista de labels para a métrica
            
        Returns:
            Objeto Histogram do Prometheus
        """
        if not PROMETHEUS_AVAILABLE:
            return self._stub.histogram(name, description, buckets, labels)
            
        try:
            # Usar prefixo único se necessário
            if USE_UNIQUE_PREFIX and not name.startswith(METRIC_PREFIX):
                name = f"{METRIC_PREFIX}{name.replace('kr_', '')}"
                
            # Usar o registro isolado para esta instância
            kwargs = {"registry": self.registry}
            if buckets:
                kwargs["buckets"] = buckets
                
            return Histogram(name, description, labels or [], **kwargs)
        except ValueError as e:
            if "Duplicated timeseries" in str(e):
                logger.warning("Detectada duplicação de métrica. Ativando prefixo único para futuras métricas.")
                self.duplicate_detected = True
                # Tentar novamente com prefixo único
                metric_name = self._get_metric_name(name)
                kwargs = {"registry": self.registry}
                if buckets:
                    kwargs["buckets"] = buckets
                return Histogram(metric_name, description, labels or [], **kwargs)
            else:
                logger.error(f"Erro ao criar histograma {name}: {e}")
                return self._stub.histogram(name, description, buckets, labels)
        except Exception as e:
            logger.error(f"Erro ao criar histograma {name}: {e}")
            return self._stub.histogram(name, description, buckets, labels)
            
    def summary(self, name: str, description: str, labels: List[str] = None) -> Summary:
        """
        Cria um summary Prometheus.
        
        Args:
            name: Nome da métrica
            description: Descrição da métrica
            labels: Lista de labels para a métrica
            
        Returns:
            Objeto Summary do Prometheus
        """
        if not PROMETHEUS_AVAILABLE:
            return self._stub.summary(name, description, labels)
            
        try:
            # Usar prefixo único se necessário
            if USE_UNIQUE_PREFIX and not name.startswith(METRIC_PREFIX):
                name = f"{METRIC_PREFIX}{name.replace('kr_', '')}"
                
            # Usar o registro isolado para esta instância
            return Summary(name, description, labels or [], registry=self.registry)
        except ValueError as e:
            if "Duplicated timeseries" in str(e):
                logger.warning("Detectada duplicação de métrica. Ativando prefixo único para futuras métricas.")
                self.duplicate_detected = True
                # Tentar novamente com prefixo único
                metric_name = self._get_metric_name(name)
                return Summary(metric_name, description, labels or [], registry=self.registry)
            else:
                logger.error(f"Erro ao criar summary {name}: {e}")
                return self._stub.summary(name, description, labels)
        except Exception as e:
            logger.error(f"Erro ao criar summary {name}: {e}")
            return self._stub.summary(name, description, labels)
            
    def start_http_server(self, port: int = 8000) -> None:
        """
        Inicia o servidor HTTP para exposição das métricas.
        
        Args:
            port: Porta para o servidor HTTP
        """
        if not PROMETHEUS_AVAILABLE:
            self._stub.start_http_server(port)
            return
            
        try:
            # Usar o registro isolado para esta instância
            prometheus_client.start_http_server(port, registry=self.registry)
            logger.info(f"Servidor HTTP Prometheus iniciado na porta {port}")
        except Exception as e:
            logger.error(f"Erro ao iniciar servidor HTTP Prometheus na porta {port}: {e}")
            
    def get_registry(self) -> Optional[CollectorRegistry]:
        """
        Retorna o registro de coletores Prometheus.
        
        Returns:
            Registro de coletores Prometheus ou None se não disponível
        """
        if not PROMETHEUS_AVAILABLE:
            return None
            
        return self.registry
        
    def get_metric(self, name: str) -> Any:
        """
        Retorna uma métrica pelo nome.
        
        Args:
            name: Nome da métrica
            
        Returns:
            Objeto métrica ou None se não existir
        """
        return self.metrics.get(name)
        
    def create_counter(self, name: str, description: str, labels: List[str] = None) -> Any:
        """
        Cria um contador usando a interface unificada.
        
        Args:
            name: Nome da métrica
            description: Descrição da métrica
            labels: Lista de labels (opcional)
            
        Returns:
            Objeto Counter ou stub
        """
        counter = self.counter(name, description, labels)
        self.metrics[name] = counter
        return counter
        
    def create_gauge(self, name: str, description: str, labels: List[str] = None) -> Any:
        """
        Cria um gauge usando a interface unificada.
        
        Args:
            name: Nome da métrica
            description: Descrição da métrica
            labels: Lista de labels (opcional)
            
        Returns:
            Objeto Gauge ou stub
        """
        gauge = self.gauge(name, description, labels)
        self.metrics[name] = gauge
        return gauge
        
    def create_histogram(self, name: str, description: str, labels: List[str] = None, 
                        buckets: List[float] = None) -> Any:
        """
        Cria um histograma usando a interface unificada.
        
        Args:
            name: Nome da métrica
            description: Descrição da métrica
            labels: Lista de labels (opcional)
            buckets: Lista de buckets (opcional)
            
        Returns:
            Objeto Histogram ou stub
        """
        histogram = self.histogram(name, description, buckets, labels)
        self.metrics[name] = histogram
        return histogram
        
    def create_summary(self, name: str, description: str, labels: List[str] = None) -> Any:
        """
        Cria um summary usando a interface unificada.
        
        Args:
            name: Nome da métrica
            description: Descrição da métrica
            labels: Lista de labels (opcional)
            
        Returns:
            Objeto Summary ou stub
        """
        summary = self.summary(name, description, labels)
        self.metrics[name] = summary
        return summary
        
    def update_system_metrics(self) -> None:
        """Atualiza métricas de sistema (CPU, memória)."""
        try:
            import psutil
            
            # Atualizar uso de CPU
            cpu_metric = self.get_metric("system_cpu_usage_percent")
            if cpu_metric:
                cpu_metric.set(psutil.cpu_percent())
            
            # Atualizar uso de memória
            mem_metric = self.get_metric("system_memory_usage_bytes")
            if mem_metric:
                mem_metric.set(psutil.virtual_memory().used)
                
            logger.debug("Métricas de sistema atualizadas")
        except ImportError:
            logger.warning("Módulo psutil não disponível. Métricas de sistema não atualizadas.")
        except Exception as e:
            logger.error(f"Erro ao atualizar métricas de sistema: {e}")

# Criar uma instância global para compatibilidade com código existente
_exporter = PrometheusExporter()

# Métricas comuns pré-definidas para compatibilidade com código existente
SIGNALS_PROCESSED_TOTAL = _register_metric(Counter, 
    "kr_signals_processed_total", 
    "Número total de sinais processados pelo signal_processor", 
    labels=["asset", "regime", "final_decision"]
)
ERRORS_TOTAL = _register_metric(Counter, 
    "kr_errors_total", 
    "Número total de erros encontrados em diferentes componentes", 
    labels=["component", "asset"]
)
ACTIVE_CONNECTIONS = _register_metric(Gauge, 
    "kr_active_connections", 
    "Número atual de conexões WebSocket ativas com a Binance", 
    labels=["asset"]
)
LAST_SIGNAL_TIMESTAMP = _register_metric(Gauge, 
    "kr_last_signal_timestamp_seconds", 
    "Timestamp da última mensagem de sinal recebida", 
    labels=["asset"]
)

# Métricas Detalhadas
SIGNAL_PROCESSING_LATENCY = _register_metric(Histogram,
    "kr_signal_processing_latency_seconds", 
    "Latência do processamento de sinais na função analisar_sinal", 
    labels=["asset", "regime"], 
    # Buckets: 10ms, 50ms, 100ms, 250ms, 500ms, 1s, 2.5s, 5s, 10s
    buckets=[0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10]
)
AI_RESPONSE_TIME = _register_metric(Gauge,
    "kr_ai_response_time_seconds", 
    "Tempo de resposta do modelo de IA", 
    labels=["asset", "model_type"]
)
BINANCE_CONNECTION_STATUS = _register_metric(Gauge,
    "kr_binance_connection_status", 
    "Status da conexão com a API/Stream da Binance (1: online, 0: offline)", 
    labels=["connection_type"]
)
CIRCUIT_BREAKER_STATE = _register_metric(Gauge, 
    "kr_circuit_breaker_state", 
    "Estado atual do circuit breaker principal (0: closed, 1: open, 0.5: half-open)",
    labels=["breaker_name"]
)
CIRCUIT_BREAKER_FAILURES_TOTAL = _register_metric(Counter, 
    "kr_circuit_breaker_failures_total", 
    "Número total de falhas registradas pelo circuit breaker",
    labels=["breaker_name"]
)
CIRCUIT_BREAKER_SUCCESSES_TOTAL = _register_metric(Counter, 
    "kr_circuit_breaker_successes_total", 
    "Número total de sucessos registrados pelo circuit breaker",
    labels=["breaker_name"]
)

# Tratamento especial para FALLBACK_ACTIVATIONS_TOTAL que está causando duplicidade
try:
    # Verificar se a métrica já existe
    if _check_metric_exists("kr_fallback_activations_total"):
        logger.info("Métrica FALLBACK_ACTIVATIONS_TOTAL já existe. Usando existente.")
        # Criar um stub seguro para a métrica
        FALLBACK_ACTIVATIONS_TOTAL = Counter(
            name="_dummy_kr_fallback_activations_total",
            documentation="Número total de vezes que um circuit breaker foi ativado (estado OPEN)",
            registry=ISOLATED_REGISTRY
        )
    else:
        # Registrar normalmente
        FALLBACK_ACTIVATIONS_TOTAL = _register_metric(Counter,
            "kr_fallback_activations_total",
            "Número total de vezes que um circuit breaker foi ativado (estado OPEN)"
        )
except Exception as e:
    logger.warning(f"Erro ao registrar FALLBACK_ACTIVATIONS_TOTAL: {e}. Usando stub seguro.")
    # Criar um stub seguro para a métrica
    FALLBACK_ACTIVATIONS_TOTAL = Counter(
        name="_dummy_kr_fallback_activations_total",
        documentation="Número total de vezes que um circuit breaker foi ativado (estado OPEN)",
        registry=ISOLATED_REGISTRY
    )

FALLBACK_MODEL_USED_TOTAL = _register_metric(Counter, 
    "kr_fallback_model_used_total", 
    "Número de vezes que o modelo fallback foi utilizado",
    labels=["asset", "reason"]
)
REGIME_IDENTIFIED_TOTAL = _register_metric(Counter, 
    "kr_regime_identified_total", 
    "Contagem de regimes de mercado identificados",
    labels=["asset", "regime"]
)
VALIDATOR_RESULTS_TOTAL = _register_metric(Counter, 
    "kr_validator_results_total", 
    "Resultado das validações executadas",
    labels=["asset", "validator_name", "result"]
)
GOVERNANCE_PREDICTION = _register_metric(Gauge, 
    "kr_governance_prediction_score", 
    "Score de predição da Governança Neural",
    labels=["asset", "model_id"]
)
NEWS_SCORE = _register_metric(Gauge, 
    "kr_news_provider_score", 
    "Score de sentimento das notícias recentes",
    labels=["asset"]
)
RL_ACTION_CHOSEN = _register_metric(Counter, 
    "kr_rl_action_chosen_total", 
    "Contagem de ações escolhidas pelo agente RL",
    labels=["asset", "action"]
)
COMPONENT_OPERATIONAL_STATUS = _register_metric(Gauge,
    "kr_component_operational_status",
    "Status operacional de componentes críticos (1: Real/Ativo, 0: Stub/Degradado/Inativo)",
    labels=["component_name", "asset"]
)

# --- Funções de Atualização ---

def inc_signals_processed(asset: str, regime: str, final_decision: str):
    """Incrementa o contador de sinais processados."""
    metric = _get_metric("SIGNALS_PROCESSED_TOTAL")
    if metric: 
        try:
            metric.labels(asset=asset, regime=regime, final_decision=final_decision).inc()
        except Exception as e:
            logger.error(f"Erro ao incrementar SIGNALS_PROCESSED_TOTAL: {e}")

def inc_errors(component: str, asset: str = "N/A"):
    """Incrementa o contador de erros."""
    metric = _get_metric("ERRORS_TOTAL")
    if metric: 
        try:
            metric.labels(component=component, asset=asset).inc()
        except Exception as e:
            logger.error(f"Erro ao incrementar ERRORS_TOTAL: {e}")

def set_active_connection(asset: str, status: bool):
    """Define o status da conexão WebSocket ativa."""
    # Deprecated in favor of set_binance_connection_status
    # metric = _get_metric("ACTIVE_CONNECTIONS")
    # if metric: metric.labels(asset=asset).set(1 if status else 0)
    set_binance_connection_status("websocket", status)

def set_binance_connection_status(connection_type: str, status: bool):
    """Define o status da conexão com a Binance (WebSocket ou REST API)."""
    metric = _get_metric("BINANCE_CONNECTION_STATUS")
    if metric: 
        try:
            metric.labels(connection_type=connection_type).set(1 if status else 0)
        except Exception as e:
            logger.error(f"Erro ao definir BINANCE_CONNECTION_STATUS: {e}")

def update_last_signal_timestamp(asset: str):
    """Atualiza o timestamp do último sinal recebido."""
    metric = _get_metric("LAST_SIGNAL_TIMESTAMP")
    if metric: 
        try:
            metric.labels(asset=asset).set_to_current_time()
        except Exception as e:
            logger.error(f"Erro ao atualizar LAST_SIGNAL_TIMESTAMP: {e}")

def observe_signal_processing_latency(asset: str, regime: str, duration: float):
    """Observa a latência do processamento de sinais."""
    metric = _get_metric("SIGNAL_PROCESSING_LATENCY")
    if metric: 
        try:
            metric.labels(asset=asset, regime=regime).observe(duration)
        except Exception as e:
            logger.error(f"Erro ao observar SIGNAL_PROCESSING_LATENCY: {e}")

def set_ai_response_time(asset: str, model_type: str, duration: float):
    """Define o tempo de resposta do modelo de IA."""
    metric = _get_metric("AI_RESPONSE_TIME")
    if metric: 
        try:
            metric.labels(asset=asset, model_type=model_type).set(duration)
        except Exception as e:
            logger.error(f"Erro ao definir AI_RESPONSE_TIME: {e}")

def set_circuit_breaker_state(breaker_name: str, state: float):
    """Define o estado do circuit breaker."""
    metric = _get_metric("CIRCUIT_BREAKER_STATE")
    if metric: 
        try:
            metric.labels(breaker_name=breaker_name).set(state)
        except Exception as e:
            logger.error(f"Erro ao definir CIRCUIT_BREAKER_STATE: {e}")

def inc_circuit_breaker_failures(breaker_name: str):
    """Incrementa o contador de falhas do circuit breaker."""
    metric = _get_metric("CIRCUIT_BREAKER_FAILURES_TOTAL")
    if metric: 
        try:
            metric.labels(breaker_name=breaker_name).inc()
        except Exception as e:
            logger.error(f"Erro ao incrementar CIRCUIT_BREAKER_FAILURES_TOTAL: {e}")

def inc_circuit_breaker_successes(breaker_name: str):
    """Incrementa o contador de sucessos do circuit breaker."""
    metric = _get_metric("CIRCUIT_BREAKER_SUCCESSES_TOTAL")
    if metric: 
        try:
            metric.labels(breaker_name=breaker_name).inc()
        except Exception as e:
            logger.error(f"Erro ao incrementar CIRCUIT_BREAKER_SUCCESSES_TOTAL: {e}")

def inc_fallback_activations(component: str = "unknown"):
    """Incrementa o contador de ativações de fallback."""
    metric = _get_metric("FALLBACK_ACTIVATIONS_TOTAL")
    if metric: 
        try:
            metric.labels(component=component).inc()
        except:
            # Se falhar ao usar labels, tentar sem labels
            try:
                metric.inc()
            except Exception as e:
                logger.error(f"Erro ao incrementar FALLBACK_ACTIVATIONS_TOTAL: {e}")

def inc_fallback_model_used(asset: str, reason: str):
    """Incrementa o contador de uso do modelo fallback."""
    metric = _get_metric("FALLBACK_MODEL_USED_TOTAL")
    if metric: 
        try:
            metric.labels(asset=asset, reason=reason).inc()
        except Exception as e:
            logger.error(f"Erro ao incrementar FALLBACK_MODEL_USED_TOTAL: {e}")

def inc_regime_identified(asset: str, regime: str):
    """Incrementa o contador de regimes identificados."""
    metric = _get_metric("REGIME_IDENTIFIED_TOTAL")
    if metric: 
        try:
            metric.labels(asset=asset, regime=regime).inc()
        except Exception as e:
            logger.error(f"Erro ao incrementar REGIME_IDENTIFIED_TOTAL: {e}")

def inc_validator_results(asset: str, validator_name: str, result: str):
    """Incrementa o contador de resultados de validação."""
    metric = _get_metric("VALIDATOR_RESULTS_TOTAL")
    if metric: 
        try:
            metric.labels(asset=asset, validator_name=validator_name, result=result).inc()
        except Exception as e:
            logger.error(f"Erro ao incrementar VALIDATOR_RESULTS_TOTAL: {e}")

def set_governance_prediction(asset: str, model_id: str, score: float):
    """Define o score de predição da Governança Neural."""
    metric = _get_metric("GOVERNANCE_PREDICTION")
    if metric: 
        try:
            metric.labels(asset=asset, model_id=model_id).set(score)
        except Exception as e:
            logger.error(f"Erro ao definir GOVERNANCE_PREDICTION: {e}")

def set_news_score(asset: str, score: float):
    """Define o score de sentimento das notícias."""
    metric = _get_metric("NEWS_SCORE")
    if metric: 
        try:
            metric.labels(asset=asset).set(score)
        except Exception as e:
            logger.error(f"Erro ao definir NEWS_SCORE: {e}")

def inc_rl_action_chosen(asset: str, action: str):
    """Incrementa o contador de ações escolhidas pelo agente RL."""
    metric = _get_metric("RL_ACTION_CHOSEN")
    if metric: 
        try:
            metric.labels(asset=asset, action=action).inc()
        except Exception as e:
            logger.error(f"Erro ao incrementar RL_ACTION_CHOSEN: {e}")

def set_component_operational_status(component_name: str, asset: str, status: bool):
    """Define o status operacional de um componente crítico."""
    metric = _get_metric("COMPONENT_OPERATIONAL_STATUS")
    if metric: 
        try:
            metric.labels(component_name=component_name, asset=asset).set(1 if status else 0)
        except Exception as e:
            logger.error(f"Erro ao definir COMPONENT_OPERATIONAL_STATUS: {e}")

# --- Funções de Conveniência para Interface Unificada ---

def create_counter(name: str, description: str, labels: List[str] = None) -> Any:
    """Cria um contador usando a instância global."""
    return _exporter.create_counter(name, description, labels)

def create_gauge(name: str, description: str, labels: List[str] = None) -> Any:
    """Cria um gauge usando a instância global."""
    return _exporter.create_gauge(name, description, labels)

def create_histogram(name: str, description: str, labels: List[str] = None, 
                    buckets: List[float] = None) -> Any:
    """Cria um histograma usando a instância global."""
    return _exporter.create_histogram(name, description, labels, buckets)

def create_summary(name: str, description: str, labels: List[str] = None) -> Any:
    """Cria um summary usando a instância global."""
    return _exporter.create_summary(name, description, labels)

def start_metrics_server(port: int = 8000) -> bool:
    """Inicia o servidor de métricas usando a instância global."""
    try:
        _exporter.start_http_server(port)
        return True
    except Exception as e:
        logger.error(f"Erro ao iniciar servidor de métricas: {e}")
        return False

def get_metric(name: str) -> Any:
    """Retorna uma métrica pelo nome usando a instância global."""
    return _exporter.get_metric(name)

def update_system_metrics() -> None:
    """Atualiza métricas de sistema usando a instância global."""
    return _exporter.update_system_metrics()

# --- Funções de Verificação de Saúde ---

def check_health() -> bool:
    """Verifica se o módulo está funcionando corretamente."""
    try:
        # Verificar se as métricas padrão foram criadas
        if not SIGNALS_PROCESSED_TOTAL or not ERRORS_TOTAL:
            logger.warning("Métricas padrão não foram criadas corretamente")
            return False
        
        # Tentar criar uma nova métrica
        test_metric = create_gauge("prometheus_health_check", "Métrica de teste para verificar saúde do Prometheus")
        if not test_metric:
            logger.warning("Não foi possível criar métrica de teste")
            return False
        
        # Definir um valor para a métrica
        test_metric.set(1)
        
        logger.info("Verificação de saúde do PrometheusExporter concluída com sucesso")
        return True
    except Exception as e:
        logger.error(f"Erro na verificação de saúde do PrometheusExporter: {e}")
        return False

# Verificar saúde do módulo ao importar
if __name__ != "__main__":
    check_health()
