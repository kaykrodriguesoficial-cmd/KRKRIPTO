# src/realtime/binance_stream.py

import asyncio
import aiohttp
import json
import logging
import traceback
import pandas as pd
from typing import Dict, Any, List, Optional, Callable, Union, Tuple
import os # For environment variable
import errno # For error codes
import time # For load simulation
import functools

# Prometheus metrics
try:
    # Import the specific metric function for connection status
    from src.infrastructure.prometheus_exporter import inc_errors, set_binance_connection_status, update_last_signal_timestamp
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False
    # Define stubs if Prometheus is not available
    def inc_errors(*args, **kwargs): pass
    def set_binance_connection_status(*args, **kwargs): pass # Stub for connection status
    def update_last_signal_timestamp(*args, **kwargs): pass

logger = logging.getLogger("kr_kripto_stream")

# Constants (Consider moving to a central config)
DATA_DIR = "data"

class BinanceStreamManager:
    """
    Gerenciador de streams WebSocket da Binance com suporte totalmente assíncrono.
    Implementa conexão, reconexão automática, processamento de mensagens e simulação para testes.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Inicializa o gerenciador de streams.
        
        Args:
            config: Dicionário de configuração
        """
        self.config = config or {}
        self.websocket_connections = {}
        self.reconnect_attempts = {}
        self.last_kline_time = {}
        self.dataframes_lock = asyncio.Lock()
        self.dataframes = {}
        self.session = None
        self.running = False
        self.tasks = []
        
        # Configurações
        self.max_reconnect_attempts = self.config.get("max_reconnect_attempts", 10)
        self.reconnect_delay = self.config.get("reconnect_delay", 5)
        self.ping_interval = self.config.get("ping_interval", 30)
        self.ping_timeout = self.config.get("ping_timeout", 10)
        
        logger.info(f"BinanceStreamManager inicializado com configuração: {self.config}")
    
    async def inicializar(self):
        """Inicializa o gerenciador de streams."""
        if self.session is None:
            self.session = aiohttp.ClientSession()
            logger.info("Sessão aiohttp inicializada")
        self.running = True
    
    async def fechar(self):
        """Fecha todas as conexões e recursos."""
        self.running = False
        
        # Cancelar todas as tarefas
        for task in self.tasks:
            if not task.done():
                task.cancel()
        
        # Fechar todas as conexões WebSocket
        for ativo, ws in self.websocket_connections.items():
            try:
                if not ws.closed:
                    await ws.close()
                    logger.info(f"Conexão WebSocket para {ativo} fechada")
            except Exception as e:
                logger.error(f"Erro ao fechar conexão WebSocket para {ativo}: {e}")
        
        # Fechar sessão HTTP
        if self.session and not self.session.closed:
            await self.session.close()
            logger.info("Sessão aiohttp fechada")
            self.session = None
    
    async def carregar_dados_historicos_async(self, ativo: str, timeframe: str = '1m', data_dir: str = DATA_DIR):
        """
        Carrega dados históricos de forma assíncrona.
        
        Args:
            ativo: Par de trading (ex: BTCUSDT)
            timeframe: Intervalo de tempo (ex: 1m, 5m, 1h)
            data_dir: Diretório onde os dados estão armazenados
            
        Returns:
            DataFrame com dados históricos ou None em caso de falha
        """
        try:
            loop = asyncio.get_event_loop()
            df = await loop.run_in_executor(None, functools.partial(self._carregar_dados_historicos_sync, ativo, timeframe, data_dir))
            if df is not None and not df.empty:
                logger.info(f"[{ativo}] Dados históricos ({timeframe}) carregados: {len(df)} candles.")
                mapeamento_colunas_hist = {
                    'open': 'Open', 'high': 'High', 'low': 'Low', 'close': 'Close', 'volume': 'Volume'
                }
                colunas_para_renomear_hist = {k: v for k, v in mapeamento_colunas_hist.items() if k in df.columns}
                if colunas_para_renomear_hist:
                    df.rename(columns=colunas_para_renomear_hist, inplace=True)
                for col in ['Open', 'High', 'Low', 'Close', 'Volume']:
                     if col in df.columns:
                         df[col] = pd.to_numeric(df[col], errors='coerce')
                df.dropna(subset=['Open', 'High', 'Low', 'Close', 'Volume'], inplace=True)
                return df
            else:
                logger.warning(f"[{ativo}] Nenhum dado histórico encontrado ou DataFrame vazio.")
                return None
        except Exception as e:
            logger.error(f"[{ativo}] Erro ao carregar dados históricos de forma assíncrona: {e}")
            return None
    
    def _carregar_dados_historicos_sync(self, ativo: str, timeframe: str = '1m', data_dir: str = DATA_DIR):
        """
        Implementação síncrona do carregamento de dados históricos.
        Esta função é chamada em um executor para não bloquear o loop de eventos.
        """
        try:
            # Importar função de carregamento de dados
            from src.core.data_handler import carregar_dados_historicos
            return carregar_dados_historicos(ativo, timeframe, data_dir)
        except ImportError:
            try:
                # Tentar caminho alternativo
                from core.data_handler import carregar_dados_historicos
                return carregar_dados_historicos(ativo, timeframe, data_dir)
            except ImportError as e:
                logger.error(f"Erro ao importar carregar_dados_historicos: {e}")
                return None
        except Exception as e:
            logger.error(f"Erro ao carregar dados históricos: {e}")
            return None
    
    async def processar_mensagem(self, ativo: str, msg: Dict[str, Any], context: Dict[str, Any]):
        """
        Processa mensagens WebSocket (Kline, Depth).
        
        Args:
            ativo: Par de trading (ex: BTCUSDT)
            msg: Mensagem recebida do WebSocket
            context: Contexto com dados necessários para processamento
        """
        # Extrair contexto necessário
        dataframes = context.get("dataframes", self.dataframes)
        last_kline_time = context.get("last_kline_time", self.last_kline_time)
        dataframes_lock = context.get("dataframes_lock", self.dataframes_lock)
        processadores_book = context.get("processadores_book")
        memoria_temporal = context.get("memoria_temporal")
        agentes_rl = context.get("agentes_rl")
        ambientes_rl = context.get("ambientes_rl")
        config = context.get("configuracao_global", self.config)
        fallback_manager = context.get("fallback_manager")
        governor = context.get("governor")
        tracker = context.get("tracker")
        context_switcher = context.get("context_switcher")
        strategy_config = context.get("strategy_config")
        attack_detector = context.get("attack_detector")
        analisar_sinal = context.get("analisar_sinal_func")

        if not all([dataframes is not None, last_kline_time is not None, dataframes_lock is not None, analisar_sinal is not None]):
            logger.error(f"[{ativo}] Contexto incompleto em processar_mensagem. Não é possível prosseguir.")
            return

        try:
            if msg.get('e') == 'kline':
                kline_data = msg['k']
                if kline_data['x']:  # Kline fechado
                    timestamp = pd.to_datetime(kline_data['t'], unit='ms')
                    if ativo in last_kline_time and last_kline_time[ativo] == kline_data['t']:
                        return # Pular kline duplicado
                    last_kline_time[ativo] = kline_data['t']

                    novo_candle = pd.DataFrame([{
                        'Timestamp': timestamp,
                        'Open': float(kline_data['o']), 'High': float(kline_data['h']),
                        'Low': float(kline_data['l']), 'Close': float(kline_data['c']),
                        'Volume': float(kline_data['v'])
                    }]).set_index('Timestamp')

                    async with dataframes_lock:
                        if ativo not in dataframes:
                            df_historico = await self.carregar_dados_historicos_async(ativo)
                            dataframes[ativo] = pd.concat([df_historico, novo_candle]) if df_historico is not None else novo_candle
                        else:
                            if timestamp not in dataframes[ativo].index:
                                dataframes[ativo] = pd.concat([dataframes[ativo], novo_candle])
                            else:
                                dataframes[ativo].loc[timestamp] = novo_candle.iloc[0]
                        max_len = config.get("max_dataframe_rows", 5000)
                        if len(dataframes[ativo]) > max_len:
                            dataframes[ativo] = dataframes[ativo].iloc[-max_len:]
                        current_df = dataframes[ativo].copy()

                    # Chamar função de análise de sinal
                    if analisar_sinal:
                        # Verificar se a função é assíncrona
                        if asyncio.iscoroutinefunction(analisar_sinal):
                            await analisar_sinal(ativo, current_df, memoria_temporal, processadores_book, agentes_rl, ambientes_rl, config, fallback_manager, governor, tracker, context_switcher, strategy_config, attack_detector)
                        else:
                            # Se não for assíncrona, executar em um executor para não bloquear o loop
                            loop = asyncio.get_event_loop()
                            await loop.run_in_executor(None, lambda: analisar_sinal(ativo, current_df, memoria_temporal, processadores_book, agentes_rl, ambientes_rl, config, fallback_manager, governor, tracker, context_switcher, strategy_config, attack_detector))

            elif msg.get('e') == 'depthUpdate':
                if attack_detector and attack_detector.detect_spoofing(msg):
                    logger.warning(f"[{ativo}] Alerta de possível spoofing detectado no livro de ordens.")
                if processadores_book and ativo in processadores_book:
                    # Verificar se o método é assíncrono
                    if hasattr(processadores_book[ativo], 'process_book_update'):
                        if asyncio.iscoroutinefunction(processadores_book[ativo].process_book_update):
                            await processadores_book[ativo].process_book_update(msg)
                        else:
                            # Se não for assíncrono, executar em um executor
                            loop = asyncio.get_event_loop()
                            await loop.run_in_executor(None, lambda: processadores_book[ativo].process_book_update(msg))

        except Exception as e:
            logger.error(f"[{ativo}] Erro ao processar mensagem: {e}")
            logger.error(traceback.format_exc())
            if PROMETHEUS_AVAILABLE:
                inc_errors("message_processing_error")
    
    async def _simulate_websocket_messages(self, ativo: str, mode: str, process_message_func: Callable):
        """
        Simula mensagens WebSocket para testes E2E.
        
        Args:
            ativo: Par de trading (ex: BTCUSDT)
            mode: Modo de simulação ('FAILURE' ou 'LOAD')
            process_message_func: Função para processar mensagens
        """
        logger.info(f"DEBUG_LOG: [{ativo}] E2E MODE ({mode}): Entrando no loop de mensagens simuladas...")
        if PROMETHEUS_AVAILABLE: 
            set_binance_connection_status("websocket", True) # Simular atualização de métrica
        message_count = 0

        if mode == 'FAILURE':
            max_messages = 5
            interval = 0.2
            logger.info(f"DEBUG_LOG: [{ativo}] E2E MODE (FAILURE): Simulando {max_messages} mensagens antes da falha...")
            while message_count < max_messages:
                message_count += 1
                logger.debug(f"DEBUG_LOG: [{ativo}] E2E MODE (FAILURE): Simulando mensagem {message_count}...")
                fake_kline_data = {
                    "e": "kline", "E": int(time.time() * 1000), "s": ativo,
                    "k": {
                        "t": int(time.time() * 1000) - 60000, "T": int(time.time() * 1000) - 1, "s": ativo, "i": "1m",
                        "f": 100 + message_count, "L": 200 + message_count, "o": f"{27000.00 + message_count:.2f}",
                        "c": f"{27010.00 + message_count:.2f}", "h": f"{27020.00 + message_count:.2f}",
                        "l": f"{26990.00 + message_count:.2f}", "v": f"{10.5 + message_count:.1f}",
                        "n": 50 + message_count, "x": True, "q": "283552.50", "V": "5.0", "Q": "135025.00", "B": "0"
                    }
                }
                try:
                    await process_message_func(msg=fake_kline_data)
                    if PROMETHEUS_AVAILABLE: 
                        update_last_signal_timestamp(ativo)
                except Exception as proc_err:
                    logger.error(f"DEBUG_LOG: [{ativo}] E2E MODE (FAILURE): Erro de processamento de mensagem simulada: {proc_err}")
                    logger.error(traceback.format_exc())
                await asyncio.sleep(interval)

            logger.warning(f"DEBUG_LOG: [{ativo}] E2E MODE (FAILURE): SIMULANDO FALHA DE STREAM após {message_count} mensagens!")
            if PROMETHEUS_AVAILABLE: 
                set_binance_connection_status("websocket", False) # Simular atualização de métrica na falha
            mock_os_error = OSError(errno.ECONNREFUSED, "E2E Mock connection refused")
            raise mock_os_error

        elif mode == 'LOAD':
            # Obter parâmetros de carga de variáveis de ambiente ou usar padrões
            num_messages = int(os.environ.get("E2E_LOAD_MESSAGES", "500"))
            interval = float(os.environ.get("E2E_LOAD_INTERVAL", "0.005"))
            logger.info(f"DEBUG_LOG: [{ativo}] E2E MODE (LOAD): Simulando {num_messages} mensagens com intervalo de {interval*1000:.1f}ms...")
            total_start_time = time.monotonic()
            while message_count < num_messages:
                loop_start_time = time.monotonic()
                message_count += 1
                # logger.debug(f"DEBUG_LOG: [{ativo}] E2E MODE (LOAD): Simulando mensagem {message_count}...") # Muito verboso
                fake_kline_data = {
                    "e": "kline", "E": int(time.time() * 1000), "s": ativo,
                    "k": {
                        "t": int(time.time() * 1000) - 60000, "T": int(time.time() * 1000) - 1, "s": ativo, "i": "1m",
                        "f": 100 + message_count, "L": 200 + message_count, "o": f"{27000.00 + message_count:.2f}",
                        "c": f"{27010.00 + message_count:.2f}", "h": f"{27020.00 + message_count:.2f}",
                        "l": f"{26990.00 + message_count:.2f}", "v": f"{10.5 + message_count:.1f}",
                        "n": 50 + message_count, "x": True, "q": "283552.50", "V": "5.0", "Q": "135025.00", "B": "0"
                    }
                }
                process_start_time = time.monotonic()
                try:
                    await process_message_func(msg=fake_kline_data)
                    if PROMETHEUS_AVAILABLE: 
                        update_last_signal_timestamp(ativo)
                except Exception as proc_err:
                    logger.error(f"DEBUG_LOG: [{ativo}] E2E MODE (LOAD): Erro de processamento de mensagem simulada: {proc_err}")
                    logger.error(traceback.format_exc())
                    # Decidir se o erro de processamento deve interromper o loop de simulação
                    # break
                process_end_time = time.monotonic()
                sleep_start_time = time.monotonic()
                await asyncio.sleep(interval)
                sleep_end_time = time.monotonic()
                loop_end_time = time.monotonic()

                process_duration = process_end_time - process_start_time
                sleep_duration = sleep_end_time - sleep_start_time
                loop_duration = loop_end_time - loop_start_time
                # Registrar informações de tempo periodicamente ou se as durações excederem um limite
                if message_count % 50 == 0 or loop_duration > (interval * 2): # Registrar a cada 50 mensagens ou se o loop levar >2x o intervalo
                     logger.debug(f"DEBUG_LOG: [{ativo}] E2E MODE (LOAD): Msg {message_count} Timing - Process: {process_duration*1000:.2f}ms, Sleep: {sleep_duration*1000:.2f}ms, Loop: {loop_duration*1000:.2f}ms")

            total_end_time = time.monotonic()
            logger.info(f"DEBUG_LOG: [{ativo}] E2E MODE (LOAD): Concluído o envio de {message_count} mensagens em {total_end_time - total_start_time:.2f} segundos.")
            # Simular fechamento gracioso da conexão após o teste de carga
            logger.info(f"DEBUG_LOG: [{ativo}] E2E MODE (LOAD): Simulando fechamento gracioso da conexão.")
            if PROMETHEUS_AVAILABLE: 
                set_binance_connection_status("websocket", False) # Simular atualização de métrica no fechamento
            # Nenhuma exceção necessária aqui, apenas parar de enviar

        else:
            logger.error(f"DEBUG_LOG: [{ativo}] E2E MODE: Modo desconhecido '{mode}'. Não é possível simular.")
    
    async def conectar_binance(self, ativo: str, process_message_func: Callable, context: Dict[str, Any] = None):
        """
        Conecta ao WebSocket da Binance e gerencia mensagens/reconexões.
        Inclui lógica de simulação E2E baseada na variável de ambiente E2E_MOCK_WS_MODE.
        
        Args:
            ativo: Par de trading (ex: BTCUSDT)
            process_message_func: Função para processar mensagens
            context: Contexto adicional para processamento de mensagens
        """
        logger.info(f"DEBUG_LOG: [{ativo}] Entrando na função conectar_binance.")

        # Inicializar contexto se não fornecido
        if context is None:
            context = {}
        
        # Inicializar sessão se necessário
        if self.session is None:
            await self.inicializar()
        
        # Inicializar contadores de reconexão
        if ativo not in self.reconnect_attempts:
            self.reconnect_attempts[ativo] = 0
        
        # Configurar streams
        stream_kline = f"{ativo.lower()}@kline_1m"
        stream_depth = f"{ativo.lower()}@depth@100ms"
        url = f"wss://stream.binance.com:9443/stream?streams={stream_kline}/{stream_depth}"
        logger.info(f"DEBUG_LOG: [{ativo}] URL do WebSocket: {url}")

        # Verificar modo de simulação E2E
        e2e_mock_mode = os.environ.get("E2E_MOCK_WS_MODE", None)
        logger.info(f"DEBUG_LOG: [{ativo}] E2E_MOCK_WS_MODE={e2e_mock_mode}")

        # Criar função de processamento de mensagem com contexto
        async def process_message_with_context(msg):
            await self.processar_mensagem(ativo, msg, context)
        
        # Usar a função fornecida ou a função com contexto
        message_processor = process_message_func or process_message_with_context

        logger.info(f"DEBUG_LOG: [{ativo}] Iniciando loop de conexão (Máximo de tentativas: {self.max_reconnect_attempts}).")
        while self.running and self.reconnect_attempts.get(ativo, 0) < self.max_reconnect_attempts:
            try:
                # --- Caminho de Simulação E2E ---
                if e2e_mock_mode in ['LOAD', 'FAILURE']:
                    logger.info(f"DEBUG_LOG: [{ativo}] E2E MODE ({e2e_mock_mode}): Simulando conexão WebSocket (Tentativa {self.reconnect_attempts.get(ativo, 0) + 1})...")
                    await asyncio.sleep(0.1) # Simular atraso de conexão
                    logger.info(f"DEBUG_LOG: [{ativo}] E2E MODE ({e2e_mock_mode}): Conexão WebSocket simulada bem-sucedida.")
                    self.reconnect_attempts[ativo] = 0 # Resetar tentativas em conexão simulada bem-sucedida
                    if PROMETHEUS_AVAILABLE: 
                        set_binance_connection_status("websocket", True) # Definir status como True em conexão simulada bem-sucedida

                    # Executar o loop de simulação apropriado
                    await self._simulate_websocket_messages(ativo, e2e_mock_mode, message_processor)

                    # Após a simulação (LOAD termina, FAILURE lança erro), quebrar o loop externo
                    # Para LOAD, simulamos um fechamento gracioso, então quebramos.
                    # Para FAILURE, a exceção é capturada abaixo, e podemos tentar novamente ou desistir.
                    if e2e_mock_mode == 'LOAD':
                        logger.info(f"DEBUG_LOG: [{ativo}] E2E MODE (LOAD): Simulação completa, saindo do loop de conexão.")
                        break # Sair do loop while após simulação de carga bem-sucedida
                    # O modo de falha lançará uma exceção tratada abaixo

                # --- Caminho de Conexão Real ---
                else:
                    logger.info(f"DEBUG_LOG: [{ativo}] Tentando conexão WebSocket REAL (Tentativa {self.reconnect_attempts.get(ativo, 0) + 1})...")
                    async with self.session.ws_connect(url) as ws:
                        logger.info(f"DEBUG_LOG: [{ativo}] Conexão WebSocket REAL bem-sucedida.")
                        self.websocket_connections[ativo] = ws
                        self.reconnect_attempts[ativo] = 0 # Resetar tentativas em conexão bem-sucedida
                        if PROMETHEUS_AVAILABLE: 
                            set_binance_connection_status("websocket", True) # Definir status como True em conexão real bem-sucedida

                        # Iniciar tarefa de ping para manter a conexão viva
                        ping_task = asyncio.create_task(self._ping_websocket(ws, ativo))
                        self.tasks.append(ping_task)

                        logger.info(f"DEBUG_LOG: [{ativo}] Entrando no loop de recebimento de mensagens REAL...")
                        async for msg_text in ws:
                            logger.debug(f"DEBUG_LOG: [{ativo}] Mensagem REAL bruta recebida: Tipo={msg_text.type}")
                            if msg_text.type == aiohttp.WSMsgType.TEXT:
                                logger.debug(f"DEBUG_LOG: [{ativo}] Processando mensagem REAL...")
                                try:
                                    msg_json = json.loads(msg_text.data)
                                    if 'stream' in msg_json and 'data' in msg_json:
                                        await message_processor(msg_json['data']) # Chamar a função passada
                                        if PROMETHEUS_AVAILABLE: 
                                            update_last_signal_timestamp(ativo)
                                    else:
                                        logger.warning(f"DEBUG_LOG: [{ativo}] Formato de mensagem inesperado: {msg_json.keys()}")
                                except json.JSONDecodeError as json_err:
                                    logger.error(f"DEBUG_LOG: [{ativo}] Erro ao decodificar JSON: {json_err}")
                                    if PROMETHEUS_AVAILABLE: 
                                        inc_errors("json_decode_error")
                                except Exception as proc_err:
                                    logger.error(f"DEBUG_LOG: [{ativo}] Erro ao processar mensagem: {proc_err}")
                                    logger.error(traceback.format_exc())
                                    if PROMETHEUS_AVAILABLE: 
                                        inc_errors("message_processing_error")
                            elif msg_text.type == aiohttp.WSMsgType.CLOSED:
                                logger.warning(f"DEBUG_LOG: [{ativo}] Conexão WebSocket fechada pelo servidor.")
                                break
                            elif msg_text.type == aiohttp.WSMsgType.ERROR:
                                logger.error(f"DEBUG_LOG: [{ativo}] Erro na conexão WebSocket: {ws.exception()}")
                                break
                        
                        # Cancelar tarefa de ping quando a conexão for fechada
                        if not ping_task.done():
                            ping_task.cancel()
                        
                        logger.warning(f"DEBUG_LOG: [{ativo}] Saiu do loop de mensagens WebSocket.")
                        if PROMETHEUS_AVAILABLE: 
                            set_binance_connection_status("websocket", False)

            except (aiohttp.ClientError, asyncio.TimeoutError, OSError) as conn_err:
                self.reconnect_attempts[ativo] += 1
                logger.error(f"DEBUG_LOG: [{ativo}] Erro de conexão (tentativa {self.reconnect_attempts[ativo]}/{self.max_reconnect_attempts}): {conn_err}")
                if PROMETHEUS_AVAILABLE: 
                    set_binance_connection_status("websocket", False)
                    inc_errors("websocket_connection_error")
                
                # Remover conexão da lista
                if ativo in self.websocket_connections:
                    del self.websocket_connections[ativo]
                
                # Calcular delay com backoff exponencial
                delay = min(self.reconnect_delay * (2 ** (self.reconnect_attempts[ativo] - 1)), 60)
                logger.info(f"DEBUG_LOG: [{ativo}] Tentando reconectar em {delay}s...")
                await asyncio.sleep(delay)
                
            except asyncio.CancelledError:
                logger.info(f"DEBUG_LOG: [{ativo}] Tarefa de conexão WebSocket cancelada.")
                break
                
            except Exception as e:
                self.reconnect_attempts[ativo] += 1
                logger.error(f"DEBUG_LOG: [{ativo}] Erro inesperado (tentativa {self.reconnect_attempts[ativo]}/{self.max_reconnect_attempts}): {e}")
                logger.error(traceback.format_exc())
                if PROMETHEUS_AVAILABLE: 
                    set_binance_connection_status("websocket", False)
                    inc_errors("websocket_unexpected_error")
                
                # Remover conexão da lista
                if ativo in self.websocket_connections:
                    del self.websocket_connections[ativo]
                
                # Calcular delay com backoff exponencial
                delay = min(self.reconnect_delay * (2 ** (self.reconnect_attempts[ativo] - 1)), 60)
                logger.info(f"DEBUG_LOG: [{ativo}] Tentando reconectar em {delay}s...")
                await asyncio.sleep(delay)
        
        # Se saiu do loop, verificar se foi por exceder o limite de tentativas
        if self.reconnect_attempts.get(ativo, 0) >= self.max_reconnect_attempts:
            logger.critical(f"DEBUG_LOG: [{ativo}] Máximo de tentativas de reconexão atingido ({self.max_reconnect_attempts}). Desistindo.")
            if PROMETHEUS_AVAILABLE: 
                inc_errors("websocket_max_reconnect_attempts")
    
    async def _ping_websocket(self, ws, ativo: str):
        """
        Envia pings periódicos para manter a conexão WebSocket viva.
        
        Args:
            ws: Conexão WebSocket
            ativo: Par de trading associado à conexão
        """
        try:
            while not ws.closed:
                await asyncio.sleep(self.ping_interval)
                if not ws.closed:
                    logger.debug(f"DEBUG_LOG: [{ativo}] Enviando ping WebSocket...")
                    await ws.ping()
                    
                    # Verificar se recebemos resposta ao ping
                    try:
                        pong_waiter = ws.ping()
                        await asyncio.wait_for(pong_waiter, timeout=self.ping_timeout)
                        logger.debug(f"DEBUG_LOG: [{ativo}] Pong recebido.")
                    except asyncio.TimeoutError:
                        logger.warning(f"DEBUG_LOG: [{ativo}] Timeout ao aguardar pong. A conexão pode estar inativa.")
                        # Fechar conexão para forçar reconexão
                        await ws.close()
                        break
        except asyncio.CancelledError:
            logger.debug(f"DEBUG_LOG: [{ativo}] Tarefa de ping cancelada.")
        except Exception as e:
            logger.error(f"DEBUG_LOG: [{ativo}] Erro na tarefa de ping: {e}")
    
    async def iniciar_streams(self, ativos: List[str], analisar_sinal_func: Callable, context: Dict[str, Any] = None):
        """
        Inicia streams WebSocket para múltiplos ativos.
        
        Args:
            ativos: Lista de pares de trading
            analisar_sinal_func: Função para analisar sinais
            context: Contexto adicional para processamento de mensagens
        """
        # Inicializar contexto se não fornecido
        if context is None:
            context = {}
        
        # Adicionar função de análise de sinal ao contexto
        context["analisar_sinal_func"] = analisar_sinal_func
        
        # Adicionar dataframes e locks ao contexto se não fornecidos
        if "dataframes" not in context:
            context["dataframes"] = self.dataframes
        if "dataframes_lock" not in context:
            context["dataframes_lock"] = self.dataframes_lock
        if "last_kline_time" not in context:
            context["last_kline_time"] = self.last_kline_time
        
        # Inicializar sessão se necessário
        if self.session is None:
            await self.inicializar()
        
        # Iniciar streams para cada ativo
        for ativo in ativos:
            # Criar tarefa para cada stream
            task = asyncio.create_task(self.conectar_binance(ativo, None, context))
            self.tasks.append(task)
            logger.info(f"Stream iniciado para {ativo}")
        
        logger.info(f"Streams iniciados para {len(ativos)} ativos")

# Exemplo de uso
async def exemplo_uso():
    """Exemplo de como usar o BinanceStreamManager de forma assíncrona."""
    # Configurar logging
    logging.basicConfig(level=logging.INFO)
    
    # Criar instância do BinanceStreamManager
    manager = BinanceStreamManager({
        "max_reconnect_attempts": 10,
        "reconnect_delay": 5,
        "ping_interval": 30,
        "ping_timeout": 10
    })
    
    # Função de exemplo para analisar sinais
    async def analisar_sinal_exemplo(ativo, df, *args, **kwargs):
        logger.info(f"Analisando sinal para {ativo}, último preço: {df['Close'].iloc[-1]}")
    
    try:
        # Iniciar streams
        await manager.iniciar_streams(["BTCUSDT", "ETHUSDT"], analisar_sinal_exemplo)
        
        # Manter o programa rodando
        await asyncio.sleep(300)  # Rodar por 5 minutos
    finally:
        # Fechar todas as conexões
        await manager.fechar()

# Executar exemplo se o script for executado diretamente
if __name__ == "__main__":
    asyncio.run(exemplo_uso())
