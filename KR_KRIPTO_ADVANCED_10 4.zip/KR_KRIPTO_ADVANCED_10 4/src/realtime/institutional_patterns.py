"""
Detector de Padrões Institucionais para KR_KRIPTO_FULL
Implementa algoritmos para detecção de padrões de manipulação e atividade institucional.

Versão: 1.0
Data: Abril 2025
"""

import numpy as np
import pandas as pd
from datetime import datetime
import logging
from typing import Dict, List, Any, Optional, Tuple, Set
from collections import deque

# Configuração de logging
logger = logging.getLogger("kr_kripto.institutional_patterns")

class InstitutionalPatternDetector:
    """
    Detector avançado de padrões institucionais no livro de ofertas.
    Implementa algoritmos para detecção de manipulação e atividade institucional.
    """
    def __init__(self, config: dict):
        self.symbol = symbol
        self.historical_states = deque(maxlen=1000)  # Últimos 1000 estados
        
        # Configurações de limiares
        self.wall_threshold = 2.0  # Multiplicador para detectar paredes
        self.iceberg_threshold = 0.5  # Limiar para detectar icebergs
        self.absorption_threshold = 0.7  # Limiar para detectar absorção
        self.spoofing_threshold = 0.8  # Limiar para detectar spoofing
        self.significance_threshold = 0.6  # Limiar para considerar um padrão significativo
        
        # Métricas de detecção
        self.detection_stats = {
            'walls_detected': 0,
            'icebergs_detected': 0,
            'absorption_detected': 0,
            'spoofing_detected': 0,
            'total_significant': 0
        }
        
        logger.info(f"InstitutionalPatternDetector inicializado para {symbol}")

    def detect_walls(self, bids: Dict[float, float], asks: Dict[float, float]) -> Dict[str, Any]:
        """
        Detecta paredes de ordens (grandes ordens em níveis específicos).
        
        Paredes são ordens grandes que servem como suporte (compra) ou resistência (venda).
        Elas são frequentemente colocadas por instituições para defender níveis de preço.
        """
        result = {'significativo': False, 'nivel': 0.0, 'tamanho': 0.0, 'direcao': 0}
        
        if not bids or not asks:
            return result
        
        # Calcular tamanho médio das ordens
        bid_sizes = list(bids.values())
        ask_sizes = list(asks.values())
        
        avg_bid_size = np.mean(bid_sizes) if bid_sizes else 0
        avg_ask_size = np.mean(ask_sizes) if ask_sizes else 0
        
        # Encontrar ordens grandes (paredes)
        max_bid_size = max(bid_sizes) if bid_sizes else 0
        max_ask_size = max(ask_sizes) if ask_sizes else 0
        
        max_bid_price = None
        max_ask_price = None
        
        if max_bid_size > avg_bid_size * self.wall_threshold:
            max_bid_price = [price for price, size in bids.items() if size == max_bid_size][0]
        
        if max_ask_size > avg_ask_size * self.wall_threshold:
            max_ask_price = [price for price, size in asks.items() if size == max_ask_size][0]
        
        # Determinar qual parede é mais significativa
        if max_bid_price and max_ask_price:
            if max_bid_size / avg_bid_size > max_ask_size / avg_ask_size:
                result = {
                    'significativo': True,
                    'nivel': float(max_bid_price),
                    'tamanho': float(max_bid_size),
                    'direcao': 1,  # Parede de compra (suporte)
                    'ratio': float(max_bid_size / avg_bid_size)
                }
            else:
                result = {
                    'significativo': True,
                    'nivel': float(max_ask_price),
                    'tamanho': float(max_ask_size),
                    'direcao': -1,  # Parede de venda (resistência)
                    'ratio': float(max_ask_size / avg_ask_size)
                }
        elif max_bid_price:
            result = {
                'significativo': True,
                'nivel': float(max_bid_price),
                'tamanho': float(max_bid_size),
                'direcao': 1,  # Parede de compra (suporte)
                'ratio': float(max_bid_size / avg_bid_size)
            }
        elif max_ask_price:
            result = {
                'significativo': True,
                'nivel': float(max_ask_price),
                'tamanho': float(max_ask_size),
                'direcao': -1,  # Parede de venda (resistência)
                'ratio': float(max_ask_size / avg_ask_size)
            }
        
        # Verificar se a parede é realmente significativa
        if result['significativo']:
            if result['direcao'] == 1:
                significance = result['tamanho'] / (avg_bid_size * self.wall_threshold)
            else:
                significance = result['tamanho'] / (avg_ask_size * self.wall_threshold)
            
            result['significativo'] = significance > self.significance_threshold
            
            if result['significativo']:
                self.detection_stats['walls_detected'] += 1
        
        return result

    def detect_icebergs(self, bids: Dict[float, float], asks: Dict[float, float], historical_states: deque) -> Dict[str, Any]:
        """
        Detecta ordens iceberg (grandes ordens escondidas que aparecem gradualmente).
        
        Ordens iceberg são grandes ordens que são divididas em partes menores para esconder
        seu tamanho real. Elas são detectadas observando reposições frequentes em um nível.
        """
        result = {'significativo': False, 'nivel': 0.0, 'tamanho': 0.0, 'direcao': 0}
        
        if len(historical_states) < 10:
            return result
        
        # Analisar mudanças rápidas em níveis específicos
        bid_changes = {}
        ask_changes = {}
        
        # Obter estados recentes
        recent_states = list(historical_states)[-10:]
        
        # Analisar mudanças em cada nível de preço
        for i in range(1, len(recent_states)):
            prev_state = recent_states[i-1]
            curr_state = recent_states[i]
            
            # Analisar bids
            for price in set(list(prev_state.bids.keys()) + list(curr_state.bids.keys())):
                prev_qty = prev_state.bids.get(price, 0)
                curr_qty = curr_state.bids.get(price, 0)
                
                if curr_qty > prev_qty and price in prev_state.bids:
                    # Aumento de quantidade em nível existente
                    if price not in bid_changes:
                        bid_changes[price] = []
                    bid_changes[price].append(curr_qty - prev_qty)
            
            # Analisar asks
            for price in set(list(prev_state.asks.keys()) + list(curr_state.asks.keys())):
                prev_qty = prev_state.asks.get(price, 0)
                curr_qty = curr_state.asks.get(price, 0)
                
                if curr_qty > prev_qty and price in prev_state.asks:
                    # Aumento de quantidade em nível existente
                    if price not in ask_changes:
                        ask_changes[price] = []
                    ask_changes[price].append(curr_qty - prev_qty)
        
        # Identificar níveis com múltiplos aumentos (potenciais icebergs)
        iceberg_bids = {}
        iceberg_asks = {}
        
        for price, changes in bid_changes.items():
            if len(changes) >= 3:  # Pelo menos 3 aumentos
                iceberg_bids[price] = sum(changes)
        
        for price, changes in ask_changes.items():
            if len(changes) >= 3:  # Pelo menos 3 aumentos
                iceberg_asks[price] = sum(changes)
        
        # Determinar o iceberg mais significativo
        max_bid_iceberg = max(iceberg_bids.values()) if iceberg_bids else 0
        max_ask_iceberg = max(iceberg_asks.values()) if iceberg_asks else 0
        
        if max_bid_iceberg > 0 and max_bid_iceberg > max_ask_iceberg:
            max_bid_price = [price for price, size in iceberg_bids.items() if size == max_bid_iceberg][0]
            result = {
                'significativo': True,
                'nivel': float(max_bid_price),
                'tamanho': float(max_bid_iceberg),
                'direcao': 1,  # Iceberg de compra
                'reposicoes': len(bid_changes.get(max_bid_price, []))
            }
        elif max_ask_iceberg > 0:
            max_ask_price = [price for price, size in iceberg_asks.items() if size == max_ask_iceberg][0]
            result = {
                'significativo': True,
                'nivel': float(max_ask_price),
                'tamanho': float(max_ask_iceberg),
                'direcao': -1,  # Iceberg de venda
                'reposicoes': len(ask_changes.get(max_ask_price, []))
            }
        
        # Verificar se o iceberg é realmente significativo
        if result['significativo']:
            # Comparar com o volume médio do livro
            avg_volume = np.mean([sum(bids.values()), sum(asks.values())])
            significance = result['tamanho'] / avg_volume if avg_volume > 0 else 0
            
            result['significativo'] = significance > self.iceberg_threshold
            
            if result['significativo']:
                self.detection_stats['icebergs_detected'] += 1
        
        return result

    def detect_absorption(self, bids: Dict[float, float], asks: Dict[float, float], historical_states: deque) -> Dict[str, Any]:
        """
        Detecta absorção de ordens (grandes ordens sendo consumidas rapidamente).
        
        Absorção ocorre quando grandes ordens são consumidas rapidamente, indicando
        forte pressão de compra ou venda. Isso frequentemente precede movimentos de preço.
        """
        result = {'significativo': False, 'nivel': 0.0, 'tamanho': 0.0, 'direcao': 0}
        
        if len(historical_states) < 5:
            return result
        
        # Obter estados recentes
        recent_states = list(historical_states)[-5:]
        
        # Analisar desaparecimento rápido de grandes ordens
        bid_disappearances = {}
        ask_disappearances = {}
        
        for i in range(1, len(recent_states)):
            prev_state = recent_states[i-1]
            curr_state = recent_states[i]
            
            # Analisar bids
            for price, qty in prev_state.bids.items():
                curr_qty = curr_state.bids.get(price, 0)
                if curr_qty < qty:
                    # Diminuição de quantidade
                    if price not in bid_disappearances:
                        bid_disappearances[price] = 0
                    bid_disappearances[price] += (qty - curr_qty)
            
            # Analisar asks
            for price, qty in prev_state.asks.items():
                curr_qty = curr_state.asks.get(price, 0)
                if curr_qty < qty:
                    # Diminuição de quantidade
                    if price not in ask_disappearances:
                        ask_disappearances[price] = 0
                    ask_disappearances[price] += (qty - curr_qty)
        
        # Determinar a absorção mais significativa
        max_bid_absorption = max(bid_disappearances.values()) if bid_disappearances else 0
        max_ask_absorption = max(ask_disappearances.values()) if ask_disappearances else 0
        
        if max_bid_absorption > 0 and max_bid_absorption > max_ask_absorption:
            max_bid_price = [price for price, size in bid_disappearances.items() if size == max_bid_absorption][0]
            result = {
                'significativo': True,
                'nivel': float(max_bid_price),
                'tamanho': float(max_bid_absorption),
                'direcao': -1,  # Absorção de compra (pressão de venda)
                'velocidade': max_bid_absorption / 5  # Quantidade por atualização
            }
        elif max_ask_absorption > 0:
            max_ask_price = [price for price, size in ask_disappearances.items() if size == max_ask_absorption][0]
            result = {
                'significativo': True,
                'nivel': float(max_ask_price),
                'tamanho': float(max_ask_absorption),
                'direcao': 1,  # Absorção de venda (pressão de compra)
                'velocidade': max_ask_absorption / 5  # Quantidade por atualização
            }
        
        # Verificar se a absorção é realmente significativa
        if result['significativo']:
            # Comparar com o volume médio do livro
            avg_volume = np.mean([sum(bids.values()), sum(asks.values())])
            significance = result['tamanho'] / avg_volume if avg_volume > 0 else 0
            
            result['significativo'] = significance > self.absorption_threshold
            
            if result['significativo']:
                self.detection_stats['absorption_detected'] += 1
        
        return result

    def detect_spoofing(self, bids: Dict[float, float], asks: Dict[float, float], historical_states: deque) -> Dict[str, Any]:
        """
        Detecta spoofing (grandes ordens que aparecem e desaparecem rapidamente).
        
        Spoofing é uma tática manipulativa onde grandes ordens são colocadas sem intenção
        de execução, apenas para influenciar o preço, e depois são rapidamente canceladas.
        """
        result = {'significativo': False, 'nivel': 0.0, 'tamanho': 0.0, 'direcao': 0}
        
        if len(historical_states) < 10:
            return result
        
        # Obter estados recentes
        recent_states = list(historical_states)[-10:]
        
        # Analisar aparecimento e desaparecimento rápido de grandes ordens
        bid_spoofing = {}
        ask_spoofing = {}
        
        for i in range(2, len(recent_states)):
            prev_prev_state = recent_states[i-2]
            prev_state = recent_states[i-1]
            curr_state = recent_states[i]
            
            # Analisar bids
            for price, qty in prev_state.bids.items():
                prev_prev_qty = prev_prev_state.bids.get(price, 0)
                curr_qty = curr_state.bids.get(price, 0)
                
                # Ordem que apareceu e depois desapareceu rapidamente
                if prev_prev_qty < qty and curr_qty < qty:
                    if price not in bid_spoofing:
                        bid_spoofing[price] = 0
                    bid_spoofing[price] = max(bid_spoofing[price], qty)
            
            # Analisar asks
            for price, qty in prev_state.asks.items():
                prev_prev_qty = prev_prev_state.asks.get(price, 0)
                curr_qty = curr_state.asks.get(price, 0)
                
                # Ordem que apareceu e depois desapareceu rapidamente
                if prev_prev_qty < qty and curr_qty < qty:
                    if price not in ask_spoofing:
                        ask_spoofing[price] = 0
                    ask_spoofing[price] = max(ask_spoofing[price], qty)
        
        # Determinar o spoofing mais significativo
        max_bid_spoofing = max(bid_spoofing.values()) if bid_spoofing else 0
        max_ask_spoofing = max(ask_spoofing.values()) if ask_spoofing else 0
        
        if max_bid_spoofing > 0 and max_bid_spoofing > max_ask_spoofing:
            max_bid_price = [price for price, size in bid_spoofing.items() if size == max_bid_spoofing][0]
            result = {
                'significativo': True,
                'nivel': float(max_bid_price),
                'tamanho': float(max_bid_spoofing),
                'direcao': 1,  # Spoofing de compra (falsa pressão de compra)
                'duracao': 1  # Número de atualizações que a ordem esteve presente
            }
        elif max_ask_spoofing > 0:
            max_ask_price = [price for price, size in ask_spoofing.items() if size == max_ask_spoofing][0]
            result = {
                'significativo': True,
                'nivel': float(max_ask_price),
                'tamanho': float(max_ask_spoofing),
                'direcao': -1,  # Spoofing de venda (falsa pressão de venda)
                'duracao': 1  # Número de atualizações que a ordem esteve presente
            }
        
        # Verificar se o spoofing é realmente significativo
        if result['significativo']:
            # Comparar com o volume médio do livro
            avg_volume = np.mean([sum(bids.values()), sum(asks.values())])
            significance = result['tamanho'] / avg_volume if avg_volume > 0 else 0
            
            result['significativo'] = significance > self.spoofing_threshold
            
            if result['significativo']:
                self.detection_stats['spoofing_detected'] += 1
        
        return result

    def detect_layering(self, bids: Dict[float, float], asks: Dict[float, float]) -> Dict[str, Any]:
        """
        Detecta layering (múltiplas ordens em níveis próximos para criar falsa impressão de profundidade).
        
        Layering é uma forma avançada de spoofing onde múltiplas ordens são colocadas
        em níveis próximos para criar uma falsa impressão de profundidade de mercado.
        """
        result = {'significativo': False, 'niveis': [], 'tamanho_total': 0.0, 'direcao': 0}
        
        # Verificar se há ordens suficientes
        if len(bids) < 5 or len(asks) < 5:
            return result
        
        # Ordenar preços
        bid_prices = sorted(bids.keys(), reverse=True)  # Do maior para o menor
        ask_prices = sorted(asks.keys())  # Do menor para o maior
        
        # Verificar sequências de ordens com tamanhos similares
        bid_layers = self._find_layers(bid_prices, bids)
        ask_layers = self._find_layers(ask_prices, asks)
        
        # Determinar qual lado tem layering mais significativo
        max_bid_layering = max([layer['tamanho_total'] for layer in bid_layers]) if bid_layers else 0
        max_ask_layering = max([layer['tamanho_total'] for layer in ask_layers]) if ask_layers else 0
        
        if max_bid_layering > 0 and max_bid_layering > max_ask_layering:
            # Encontrar a camada com maior tamanho total
            max_layer = [layer for layer in bid_layers if layer['tamanho_total'] == max_bid_layering][0]
            result = {
                'significativo': True,
                'niveis': max_layer['niveis'],
                'tamanho_total': max_layer['tamanho_total'],
                'direcao': 1,  # Layering de compra
                'num_niveis': len(max_layer['niveis'])
            }
        elif max_ask_layering > 0:
            # Encontrar a camada com maior tamanho total
            max_layer = [layer for layer in ask_layers if layer['tamanho_total'] == max_ask_layering][0]
            result = {
                'significativo': True,
                'niveis': max_layer['niveis'],
                'tamanho_total': max_layer['tamanho_total'],
                'direcao': -1,  # Layering de venda
                'num_niveis': len(max_layer['niveis'])
            }
        
        # Verificar se o layering é realmente significativo
        if result['significativo']:
            # Comparar com o volume médio do livro
            avg_volume = np.mean([sum(bids.values()), sum(asks.values())])
            significance = result['tamanho_total'] / avg_volume if avg_volume > 0 else 0
            
            result['significativo'] = significance > self.significance_threshold and result['num_niveis'] >= 3
        
        return result

    def _find_layers(self, prices: List[float], orders: Dict[float, float]) -> List[Dict[str, Any]]:
        """
        Encontra camadas de ordens com tamanhos similares em níveis próximos.
        """
        layers = []
        current_layer = {'niveis': [], 'tamanho_total': 0.0}
        
        for i in range(1, len(prices)):
            prev_price = prices[i-1]
            curr_price = prices[i]
            
            # Verificar se os preços são próximos
            price_diff = abs(curr_price - prev_price)
            avg_price = (curr_price + prev_price) / 2
            relative_diff = price_diff / avg_price
            
            # Verificar se os tamanhos são similares
            prev_size = orders[prev_price]
            curr_size = orders[curr_price]
            size_ratio = min(prev_size, curr_size) / max(prev_size, curr_size)
            
            # Se os preços são próximos e os tamanhos são similares, adicionar à camada atual
            if relative_diff < 0.001 and size_ratio > 0.7:
                if not current_layer['niveis']:
                    current_layer['niveis'].append(prev_price)
                    current_layer['tamanho_total'] += prev_size
                
                current_layer['niveis'].append(curr_price)
                current_layer['tamanho_total'] += curr_size
            else:
                # Finalizar camada atual se tiver pelo menos 3 níveis
                if len(current_layer['niveis']) >= 3:
                    layers.append(current_layer)
                
                # Iniciar nova camada
                current_layer = {'niveis': [], 'tamanho_total': 0.0}
        
        # Adicionar última camada se tiver pelo menos 3 níveis
        if len(current_layer['niveis']) >= 3:
            layers.append(current_layer)
        
        return layers

    def detect_momentum_ignition(self, historical_states: deque) -> Dict[str, Any]:
        """
        Detecta ignição de momentum (padrão de ordens que tenta iniciar um movimento de preço).
        
        Ignição de momentum é uma tática onde grandes ordens são usadas para iniciar
        um movimento de preço, frequentemente seguido por ordens na direção oposta.
        """
        result = {'significativo': False, 'direcao_inicial': 0, 'direcao_final': 0, 'magnitude': 0.0}
        
        if len(historical_states) < 20:
            return result
        
        # Obter estados recentes
        recent_states = list(historical_states)[-20:]
        
        # Calcular desequilíbrios ao longo do tempo
        imbalances = [state.imbalance for state in recent_states]
        
        # Verificar mudança rápida de desequilíbrio
        if len(imbalances) < 10:
            return result
        
        # Calcular médias móveis
        early_avg = np.mean(imbalances[:10])
        late_avg = np.mean(imbalances[-10:])
        
        # Verificar mudança significativa
        change = late_avg - early_avg
        
        if abs(change) > 0.5:  # Mudança de pelo menos 50% no desequilíbrio
            result = {
                'significativo': True,
                'direcao_inicial': np.sign(early_avg),
                'direcao_final': np.sign(late_avg),
                'magnitude': abs(change)
            }
        
        return result

    def detect_all_patterns(self, state) -> Dict[str, Any]:
        """
        Detecta todos os padrões institucionais no estado atual do livro.
        """
        # Adicionar estado atual ao histórico
        self.historical_states.append(state)
        
        # Detectar padrões básicos
        patterns = {
            'paredes': self.detect_walls(state.bids, state.asks),
            'iceberg': self.detect_icebergs(state.bids, state.asks, self.historical_states),
            'absorção': self.detect_absorption(state.bids, state.asks, self.historical_states),
            'spoofing': self.detect_spoofing(state.bids, state.asks, self.historical_states),
            'significativo': False
        }
        
        # Detectar padrões avançados se houver dados suficientes
        if len(self.historical_states) >= 20:
            patterns['layering'] = self.detect_layering(state.bids, state.asks)
            patterns['momentum_ignition'] = self.detect_momentum_ignition(self.historical_states)
        else:
            patterns['layering'] = {'significativo': False}
            patterns['momentum_ignition'] = {'significativo': False}
        
        # Determinar se algum padrão é significativo
        patterns['significativo'] = any([
            patterns['paredes']['significativo'],
            patterns['iceberg']['significativo'],
            patterns['absorção']['significativo'],
            patterns['spoofing']['significativo'],
            patterns['layering']['significativo'],
            patterns['momentum_ignition']['significativo']
        ])
        
        # Atualizar estatísticas
        if patterns['significativo']:
            self.detection_stats['total_significant'] += 1
        
        return patterns

    def get_stats(self) -> Dict[str, Any]:
        """
        Retorna estatísticas de detecção.
        """
        return self.detection_stats

    def adjust_thresholds(self, sensitivity: float = 1.0) -> None:
        """
        Ajusta os limiares de detecção com base na sensibilidade desejada.
        
        Args:
            sensitivity: Fator de sensibilidade (1.0 = normal, <1.0 = menos sensível, >1.0 = mais sensível)
        """
        self.wall_threshold = 2.0 / sensitivity
        self.iceberg_threshold = 0.5 / sensitivity
        self.absorption_threshold = 0.7 / sensitivity
        self.spoofing_threshold = 0.8 / sensitivity
        self.significance_threshold = 0.6 / sensitivity
        
        logger.info(f"Limiares ajustados com sensibilidade {sensitivity}")
