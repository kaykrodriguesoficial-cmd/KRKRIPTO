# -*- coding: utf-8 -*-
"""
Módulo RiskManager para o sistema KR_KRIPTO_ADVANCED.
Versão assíncrona adaptada para compatibilidade com Mac M1 (ARM64).

Este módulo implementa gerenciamento de risco, cálculo de Stop Loss/Take Profit
e ajuste de scores baseado em volatilidade.
"""

import pandas as pd
import logging
import numpy as np
import platform
import sys
import asyncio
from typing import Optional, Tuple, Dict, Any, Union, List

# Configuração de logger
logger = logging.getLogger("kr_kripto_risk")

# Detecção de ambiente Mac M1
def is_mac_m1() -> bool:
    """Detecta se o ambiente de execução é um Mac M1 (ARM64)."""
    return (
        platform.system() == "Darwin" and 
        platform.machine() == "arm64"
    )

# Exportação explícita para garantir que a função possa ser importada diretamente
__all__ = ['RiskManager', 'is_mac_m1', 'calcular_volatilidade', 
           'aplicar_risco', 'calcular_sl_tp_dinamico']

# Tentativa de importar MarketRegime. Se falhar, define um stub.
try:
    from src.intelligence.context_switcher import MarketRegime
except ImportError:
    try:
        # Tentativa alternativa para Mac M1
        sys.path.append('.')
        from intelligence.context_switcher import MarketRegime
    except ImportError:
        from enum import Enum
        class MarketRegime:
            TENDENCIA_ALTA = 1
            TENDENCIA_BAIXA = 2
            LATERAL_ALTA_VOL = 3
            LATERAL_BAIXA_VOL = 4
            INDEFINIDO = 5
        logger.warning("MarketRegime not found, using stub enum.")

# Verificar se pandas_ta está disponível
try:
    import pandas_ta as ta
    PANDAS_TA_AVAILABLE = True
except ImportError:
    try:
        # Tentativa de instalação automática para Mac M1
        if is_mac_m1():
            import subprocess
            logger.info("Tentando instalar pandas_ta para Mac M1...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", "pandas_ta"])
            import pandas_ta as ta
            PANDAS_TA_AVAILABLE = True
        else:
            PANDAS_TA_AVAILABLE = False
    except Exception as e:
        PANDAS_TA_AVAILABLE = False
        logger.warning(f"pandas_ta não disponível ({str(e)}). Algumas funcionalidades de cálculo de ATR serão limitadas.")

class RiskManager:
    """
    Gerenciador de risco assíncrono para o sistema KR_KRIPTO_ADVANCED.
    Implementa cálculo de Stop Loss/Take Profit e ajuste de scores baseado em volatilidade.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Inicializa o gerenciador de risco.
        
        Args:
            config: Dicionário de configuração com parâmetros de risco
        """
        if config is None:
            config = {}
            
        # Parâmetros para ajuste de score
        self.fator_volatilidade_alta = config.get("risk_volatility_factor", 0.85)  # Reduz score em alta vol
        self.fator_regime_incerto = config.get("risk_uncertain_factor", 0.90)  # Reduz score em regime indefinido
        self.limite_volatilidade = config.get("risk_volatility_threshold", 0.6)  # Limite para alta volatilidade
        
        # Parâmetros para SL/TP
        self.atr_period = config.get("risk_atr_period", 14)
        self.sl_multiplier = config.get("risk_sl_multiplier", 1.5)
        self.tp_multiplier = config.get("risk_tp_multiplier", None)
        self.risk_reward_ratio = config.get("risk_reward_ratio", 2.0)
        
        # Parâmetros para validação de ordens
        self.limites_diarios = {}
        self.historico_operacoes = {}
        
        # Detecção de ambiente
        self.is_mac_m1 = is_mac_m1()
        self.environment_info = self._get_environment_info()
        
        # Lock para operações concorrentes
        self.lock = asyncio.Lock()
        
        logger.info(f"RiskManager inicializado com configuração: {config}")
        logger.info(f"Ambiente: {self.environment_info}")
    
    def _get_environment_info(self) -> Dict[str, str]:
        """Coleta informações sobre o ambiente de execução."""
        return {
            'system': platform.system(),
            'release': platform.release(),
            'machine': platform.machine(),
            'processor': platform.processor(),
            'python': platform.python_version(),
            'mac_m1': self.is_mac_m1
        }
    
    async def calcular_volatilidade_async(self, df: pd.DataFrame, window: int = 20) -> float:
        """
        Calcula a volatilidade histórica (desvio padrão dos retornos logarítmicos) de forma assíncrona.
        
        Args:
            df: DataFrame com dados históricos (requer coluna 'Close')
            window: Janela para cálculo da volatilidade
            
        Returns:
            Volatilidade anualizada
        """
        # Usar um executor para não bloquear o loop de eventos
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: self.calcular_volatilidade(df, window))
    
    def calcular_volatilidade(self, df: pd.DataFrame, window: int = 20) -> float:
        """
        Calcula a volatilidade histórica (desvio padrão dos retornos logarítmicos).
        
        Args:
            df: DataFrame com dados históricos (requer coluna 'Close')
            window: Janela para cálculo da volatilidade
            
        Returns:
            Volatilidade anualizada
        """
        if df is None or len(df) < window + 1:
            return 0.0  # Retorna 0 se não houver dados suficientes
            
        try:
            # Verificação de segurança para Mac M1
            if not isinstance(df, pd.DataFrame):
                logger.warning(f"Tipo de dados inválido: {type(df)}. Esperado: DataFrame")
                return 0.0
                
            if "Close" not in df.columns:
                logger.warning("Coluna 'Close' não encontrada no DataFrame")
                return 0.0
                
            log_returns = np.log(df["Close"] / df["Close"].shift(1))
            volatility = log_returns.rolling(window=window).std().iloc[-1]
            
            # Verificação de NaN para Mac M1
            if pd.isna(volatility):
                logger.warning("Volatilidade calculada é NaN, retornando 0.0")
                return 0.0
                
            return volatility * np.sqrt(252)  # Anualiza (ajustar se necessário para o timeframe)
        except Exception as e:
            logger.error(f"Erro ao calcular volatilidade: {e}", exc_info=True)
            return 0.0
    
    async def aplicar_risco_async(self, score: float, df: pd.DataFrame, regime: Any) -> float:
        """
        Aplica lógica de gerenciamento de risco ao score bruto de forma assíncrona.
        Ajusta o score com base no regime de mercado e volatilidade.
        
        Args:
            score: O score bruto calculado (geralmente entre 0 e 1)
            df: DataFrame com dados históricos recentes
            regime: O regime de mercado atual identificado
            
        Returns:
            Score ajustado pelo risco
        """
        # Usar um executor para não bloquear o loop de eventos
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: self.aplicar_risco(score, df, regime))
    
    def aplicar_risco(self, score: float, df: pd.DataFrame, regime: Any) -> float:
        """
        Aplica lógica de gerenciamento de risco ao score bruto.
        Ajusta o score com base no regime de mercado e volatilidade.
        
        Args:
            score: O score bruto calculado (geralmente entre 0 e 1)
            df: DataFrame com dados históricos recentes
            regime: O regime de mercado atual identificado
            
        Returns:
            Score ajustado pelo risco
        """
        # Validação de entrada para Mac M1
        if not isinstance(score, (int, float)):
            logger.warning(f"Score inválido: {score}. Usando 0.5 como padrão.")
            score = 0.5
            
        score_ajustado = score
        razao_ajuste = "Nenhum"
        
        # 1. Ajuste por Regime de Mercado
        try:
            if hasattr(regime, 'LATERAL_ALTA_VOL') and hasattr(regime, 'INDEFINIDO'):
                if regime in [regime.LATERAL_ALTA_VOL, regime.INDEFINIDO]:
                    score_ajustado *= self.fator_regime_incerto
                    regime_name = getattr(regime, 'name', str(regime))
                    razao_ajuste = f"Regime Incerto/Alta Vol ({regime_name})"
                    logger.debug(f"Ajuste de risco aplicado devido ao regime {regime_name}. Score: {score:.4f} -> {score_ajustado:.4f}")
        except Exception as e:
            logger.warning(f"Erro ao processar regime de mercado: {e}. Ignorando ajuste de regime.")
        
        # 2. Ajuste por Volatilidade
        try:
            volatilidade_atual = self.calcular_volatilidade(df)
            if volatilidade_atual > self.limite_volatilidade:
                # Aplica o fator apenas se reduzir ainda mais o score (evita aumentar)
                novo_score_vol = score_ajustado * self.fator_volatilidade_alta
                if novo_score_vol < score_ajustado:
                    score_ajustado = novo_score_vol
                    razao_ajuste += " + Alta Volatilidade" if razao_ajuste != "Nenhum" else "Alta Volatilidade"
                    logger.debug(f"Ajuste de risco aplicado devido à alta volatilidade ({volatilidade_atual:.3f} > {self.limite_volatilidade}). Score: {score:.4f} -> {score_ajustado:.4f}")
        except Exception as e:
            logger.warning(f"Erro ao processar volatilidade: {e}. Ignorando ajuste de volatilidade.")
        
        if score_ajustado != score:
            logger.info(f"Score ajustado pelo risco: {score:.4f} -> {score_ajustado:.4f}. Razão: {razao_ajuste.strip()}")
        else:
            logger.debug(f"Nenhum ajuste de risco aplicado. Score final: {score_ajustado:.4f}")
        
        # Garante que o score permaneça entre 0 e 1
        return max(0.0, min(1.0, score_ajustado))
    
    async def calcular_sl_tp_dinamico_async(self, df: pd.DataFrame, entry_price: float, side: str) -> Tuple[Optional[float], Optional[float]]:
        """
        Calcula Stop Loss (SL) e Take Profit (TP) dinâmicos com base no ATR de forma assíncrona.
        
        Args:
            df: DataFrame com dados históricos recentes (requer colunas 'High', 'Low', 'Close')
            entry_price: O preço de entrada da operação
            side: O lado da operação ('BUY' ou 'SELL')
            
        Returns:
            Tupla contendo (stop_loss_price, take_profit_price)
            Retorna (None, None) se não for possível calcular
        """
        # Usar um executor para não bloquear o loop de eventos
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: self.calcular_sl_tp_dinamico(df, entry_price, side))
    
    def calcular_sl_tp_dinamico(self, df: pd.DataFrame, entry_price: float, side: str) -> Tuple[Optional[float], Optional[float]]:
        """
        Calcula Stop Loss (SL) e Take Profit (TP) dinâmicos com base no ATR.
        
        Args:
            df: DataFrame com dados históricos recentes (requer colunas 'High', 'Low', 'Close')
            entry_price: O preço de entrada da operação
            side: O lado da operação ('BUY' ou 'SELL')
            
        Returns:
            Tupla contendo (stop_loss_price, take_profit_price)
            Retorna (None, None) se não for possível calcular
        """
        # Validação de entrada para Mac M1
        if not isinstance(entry_price, (int, float)) or entry_price <= 0:
            logger.warning(f"Preço de entrada inválido: {entry_price}")
            return None, None
            
        if side not in ['BUY', 'SELL']:
            logger.warning(f"Lado inválido: {side}. Deve ser 'BUY' ou 'SELL'.")
            return None, None
            
        if df is None or len(df) < self.atr_period or not all(col in df.columns for col in ["High", "Low", "Close"]):
            logger.warning("Dados insuficientes ou colunas ausentes (High, Low, Close) para calcular ATR.")
            return None, None
        
        try:
            # Calcula o ATR usando pandas_ta se disponível
            if PANDAS_TA_AVAILABLE:
                try:
                    # Cria uma cópia para evitar modificar o DataFrame original
                    df_copy = df.copy()
                    df_copy.ta.atr(length=self.atr_period, append=True)
                    atr_column_name = f"ATR_{self.atr_period}"
                    if atr_column_name not in df_copy.columns:
                        logger.error(f"Coluna ATR {atr_column_name} não foi adicionada ao DataFrame.")
                        raise ValueError(f"Coluna ATR {atr_column_name} não encontrada")
                    current_atr = df_copy[atr_column_name].iloc[-1]
                except Exception as e:
                    logger.warning(f"Erro ao usar pandas_ta para ATR: {e}. Usando cálculo manual.")
                    # Fallback para cálculo manual
                    high_low = df['High'] - df['Low']
                    high_close = abs(df['High'] - df['Close'].shift(1))
                    low_close = abs(df['Low'] - df['Close'].shift(1))
                    ranges = pd.concat([high_low, high_close, low_close], axis=1)
                    true_range = ranges.max(axis=1)
                    current_atr = true_range.rolling(window=self.atr_period).mean().iloc[-1]
            else:
                # Cálculo manual do ATR se pandas_ta não estiver disponível
                high_low = df['High'] - df['Low']
                high_close = abs(df['High'] - df['Close'].shift(1))
                low_close = abs(df['Low'] - df['Close'].shift(1))
                ranges = pd.concat([high_low, high_close, low_close], axis=1)
                true_range = ranges.max(axis=1)
                current_atr = true_range.rolling(window=self.atr_period).mean().iloc[-1]
            
            if pd.isna(current_atr) or current_atr <= 0:
                logger.warning(f"Valor do ATR inválido ({current_atr}). Não é possível calcular SL/TP.")
                return None, None
            
            logger.debug(f"Calculando SL/TP: Entry={entry_price}, Side={side}, ATR({self.atr_period})={current_atr:.5f}")
            
            # Calcula a distância do Stop Loss
            sl_distance = current_atr * self.sl_multiplier
            
            # Calcula o preço do Stop Loss
            if side == 'BUY':
                stop_loss_price = entry_price - sl_distance
            elif side == 'SELL':
                stop_loss_price = entry_price + sl_distance
            else:
                logger.error(f"Lado inválido fornecido: {side}")
                return None, None
            
            # Calcula o preço do Take Profit
            if self.tp_multiplier is not None:
                tp_distance = current_atr * self.tp_multiplier
            else:  # Usa risk_reward_ratio
                tp_distance = sl_distance * self.risk_reward_ratio
            
            if side == 'BUY':
                take_profit_price = entry_price + tp_distance
            elif side == 'SELL':
                take_profit_price = entry_price - tp_distance
            
            logger.info(f"SL/TP Calculado: SL={stop_loss_price:.5f}, TP={take_profit_price:.5f} (Baseado em ATR={current_atr:.5f})")
            return stop_loss_price, take_profit_price
        
        except Exception as e:
            logger.error(f"Erro ao calcular SL/TP dinâmico: {e}", exc_info=True)
            return None, None
    
    async def validar_ordem(self, ativo: str, tipo_ordem: str, quantidade: float, preco: Optional[float] = None) -> Tuple[bool, str]:
        """
        Valida uma ordem antes da execução de forma assíncrona.
        
        Args:
            ativo: Par de trading (ex: BTCUSDT)
            tipo_ordem: 'BUY' ou 'SELL'
            quantidade: Quantidade a comprar/vender
            preco: Preço limite (opcional)
            
        Returns:
            Tupla (valido, motivo) indicando se a ordem é válida e o motivo em caso negativo
        """
        try:
            # Validar parâmetros básicos de forma assíncrona
            parametros_validos, motivo = await self._validar_parametros_ordem(ativo, tipo_ordem, quantidade, preco)
            if not parametros_validos:
                return False, motivo
            
            # Verificar limites diários de forma assíncrona
            dentro_limites, motivo = await self._verificar_limites_diarios(ativo, tipo_ordem, quantidade, preco)
            if not dentro_limites:
                return False, motivo
            
            # Verificar risco de liquidez de forma assíncrona
            liquidez_ok, motivo = await self._verificar_risco_liquidez(ativo, tipo_ordem, quantidade)
            if not liquidez_ok:
                return False, motivo
            
            # Verificar volatilidade de forma assíncrona
            volatilidade_ok, motivo = await self._verificar_volatilidade(ativo)
            if not volatilidade_ok:
                return False, motivo
            
            # Ordem válida
            return True, "Ordem validada com sucesso"
        
        except Exception as e:
            logger.error(f"Erro ao validar ordem {ativo} {tipo_ordem} {quantidade}: {e}")
            return False, f"Erro na validação: {str(e)}"
    
    async def _validar_parametros_ordem(self, ativo: str, tipo_ordem: str, quantidade: float, preco: Optional[float] = None) -> Tuple[bool, str]:
        """Valida os parâmetros básicos da ordem de forma assíncrona."""
        # Validar ativo
        if not ativo or not isinstance(ativo, str):
            return False, "Ativo inválido"
        
        # Validar tipo de ordem
        if tipo_ordem not in ["BUY", "SELL"]:
            return False, f"Tipo de ordem inválido: {tipo_ordem}"
        
        # Validar quantidade
        if not quantidade or quantidade <= 0:
            return False, f"Quantidade inválida: {quantidade}"
        
        # Validar preço para ordens limite
        if preco is not None and preco <= 0:
            return False, f"Preço inválido: {preco}"
        
        # Simular operação assíncrona
        await asyncio.sleep(0.01)
        
        return True, "Parâmetros válidos"
    
    async def _verificar_limites_diarios(self, ativo: str, tipo_ordem: str, quantidade: float, preco: Optional[float] = None) -> Tuple[bool, str]:
        """Verifica se a ordem está dentro dos limites diários de forma assíncrona."""
        async with self.lock:
            # Obter limite diário para o ativo
            limite_diario = 1000  # Valor padrão
            
            # Obter volume já operado hoje
            volume_diario = self.limites_diarios.get(ativo, 0)
            
            # Calcular volume da ordem atual
            volume_ordem = quantidade
            if preco:
                volume_ordem *= preco
            
            # Verificar se excede o limite
            if volume_diario + volume_ordem > limite_diario:
                return False, f"Ordem excede limite diário para {ativo}: {volume_diario + volume_ordem} > {limite_diario}"
        
        # Simular operação assíncrona
        await asyncio.sleep(0.01)
        
        return True, "Dentro dos limites diários"
    
    async def _verificar_risco_liquidez(self, ativo: str, tipo_ordem: str, quantidade: float) -> Tuple[bool, str]:
        """Verifica o risco de liquidez de forma assíncrona."""
        # Obter limite de liquidez para o ativo
        limite_liquidez = 0.1  # Valor padrão
        
        # Em uma implementação real, aqui consultaríamos o livro de ordens
        # para verificar a liquidez disponível
        
        # Simular operação assíncrona
        await asyncio.sleep(0.01)
        
        # Para este exemplo, assumimos que a liquidez é suficiente
        return True, "Liquidez suficiente"
    
    async def _verificar_volatilidade(self, ativo: str) -> Tuple[bool, str]:
        """Verifica se a volatilidade está dentro dos limites aceitáveis de forma assíncrona."""
        # Obter limite de volatilidade para o ativo
        limite_volatilidade = 5.0  # Valor padrão
        
        # Em uma implementação real, aqui calcularíamos a volatilidade atual
        # com base em dados históricos recentes
        
        # Simular operação assíncrona
        await asyncio.sleep(0.01)
        
        # Para este exemplo, assumimos que a volatilidade está dentro dos limites
        return True, "Volatilidade dentro dos limites"
    
    async def registrar_operacao(self, ativo: str, tipo_ordem: str, quantidade: float, preco: float) -> None:
        """Registra uma operação executada de forma assíncrona."""
        async with self.lock:
            # Atualizar volume diário
            if ativo not in self.limites_diarios:
                self.limites_diarios[ativo] = 0
            
            volume_ordem = quantidade * preco
            self.limites_diarios[ativo] += volume_ordem
            
            # Registrar no histórico
            if ativo not in self.historico_operacoes:
                self.historico_operacoes[ativo] = []
            
            self.historico_operacoes[ativo].append({
                "tipo": tipo_ordem,
                "quantidade": quantidade,
                "preco": preco,
                "volume": volume_ordem,
                "timestamp": time.time()
            })
        
        logger.info(f"Operação registrada: {ativo} {tipo_ordem} {quantidade} @ {preco}")
    
    async def obter_metricas_risco(self, ativo: Optional[str] = None) -> Dict[str, Any]:
        """Obtém métricas de risco atuais de forma assíncrona."""
        async with self.lock:
            metricas = {
                "limites_diarios": self.limites_diarios.copy(),
                "total_operacoes": sum(len(ops) for ops in self.historico_operacoes.values()),
                "ativos_operados": list(self.historico_operacoes.keys())
            }
            
            if ativo and ativo in self.historico_operacoes:
                metricas["operacoes_ativo"] = len(self.historico_operacoes[ativo])
                metricas["volume_ativo"] = self.limites_diarios.get(ativo, 0)
        
        # Simular operação assíncrona
        await asyncio.sleep(0.01)
        
        return metricas
    
    async def resetar_limites_diarios(self) -> None:
        """Reseta os limites diários (geralmente chamado no início do dia) de forma assíncrona."""
        async with self.lock:
            self.limites_diarios = {}
        logger.info("Limites diários resetados")


# ========== FUNÇÕES PROCEDURAIS PARA COMPATIBILIDADE COM CÓDIGO LEGADO ==========
# Estas funções servem como wrappers para os métodos da classe RiskManager,
# mantendo a interface original para compatibilidade com código existente.

# Instância global do RiskManager para uso pelas funções procedurais
_risk_manager_instance = None

def _get_risk_manager(config=None):
    """Obtém ou cria uma instância global do RiskManager."""
    global _risk_manager_instance
    if _risk_manager_instance is None:
        _risk_manager_instance = RiskManager(config)
    return _risk_manager_instance

def calcular_volatilidade(df: pd.DataFrame, window: int = 20) -> float:
    """
    Wrapper procedural para o método calcular_volatilidade da classe RiskManager.
    Calcula a volatilidade histórica (desvio padrão dos retornos logarítmicos).
    """
    return _get_risk_manager().calcular_volatilidade(df, window)

async def calcular_volatilidade_async(df: pd.DataFrame, window: int = 20) -> float:
    """
    Wrapper procedural assíncrono para o método calcular_volatilidade_async da classe RiskManager.
    Calcula a volatilidade histórica (desvio padrão dos retornos logarítmicos) de forma assíncrona.
    """
    return await _get_risk_manager().calcular_volatilidade_async(df, window)

def aplicar_risco(
    score: float,
    df: pd.DataFrame,
    regime: Any,
    config: Optional[dict] = None
) -> float:
    """
    Wrapper procedural para o método aplicar_risco da classe RiskManager.
    Aplica lógica de gerenciamento de risco ao score bruto.
    Ajusta o score com base no regime de mercado e volatilidade.
    """
    # Se config for fornecido, cria uma nova instância do RiskManager
    if config is not None:
        risk_manager = RiskManager(config)
        return risk_manager.aplicar_risco(score, df, regime)
    else:
        return _get_risk_manager().aplicar_risco(score, df, regime)

async def aplicar_risco_async(
    score: float,
    df: pd.DataFrame,
    regime: Any,
    config: Optional[dict] = None
) -> float:
    """
    Wrapper procedural assíncrono para o método aplicar_risco_async da classe RiskManager.
    Aplica lógica de gerenciamento de risco ao score bruto de forma assíncrona.
    Ajusta o score com base no regime de mercado e volatilidade.
    """
    # Se config for fornecido, cria uma nova instância do RiskManager
    if config is not None:
        risk_manager = RiskManager(config)
        return await risk_manager.aplicar_risco_async(score, df, regime)
    else:
        return await _get_risk_manager().aplicar_risco_async(score, df, regime)

def calcular_sl_tp_dinamico(
    df: pd.DataFrame,
    entry_price: float,
    side: str,
    config: Optional[dict] = None
) -> Tuple[Optional[float], Optional[float]]:
    """
    Wrapper procedural para o método calcular_sl_tp_dinamico da classe RiskManager.
    Calcula Stop Loss (SL) e Take Profit (TP) dinâmicos com base no ATR.
    """
    # Se config for fornecido, cria uma nova instância do RiskManager
    if config is not None:
        risk_manager = RiskManager(config)
        return risk_manager.calcular_sl_tp_dinamico(df, entry_price, side)
    else:
        return _get_risk_manager().calcular_sl_tp_dinamico(df, entry_price, side)

async def calcular_sl_tp_dinamico_async(
    df: pd.DataFrame,
    entry_price: float,
    side: str,
    config: Optional[dict] = None
) -> Tuple[Optional[float], Optional[float]]:
    """
    Wrapper procedural assíncrono para o método calcular_sl_tp_dinamico_async da classe RiskManager.
    Calcula Stop Loss (SL) e Take Profit (TP) dinâmicos com base no ATR de forma assíncrona.
    """
    # Se config for fornecido, cria uma nova instância do RiskManager
    if config is not None:
        risk_manager = RiskManager(config)
        return await risk_manager.calcular_sl_tp_dinamico_async(df, entry_price, side)
    else:
        return await _get_risk_manager().calcular_sl_tp_dinamico_async(df, entry_price, side)

async def validar_ordem_async(
    ativo: str,
    tipo_ordem: str,
    quantidade: float,
    preco: Optional[float] = None,
    config: Optional[dict] = None
) -> Tuple[bool, str]:
    """
    Wrapper procedural assíncrono para o método validar_ordem da classe RiskManager.
    Valida uma ordem antes da execução de forma assíncrona.
    """
    # Se config for fornecido, cria uma nova instância do RiskManager
    if config is not None:
        risk_manager = RiskManager(config)
        return await risk_manager.validar_ordem(ativo, tipo_ordem, quantidade, preco)
    else:
        return await _get_risk_manager().validar_ordem(ativo, tipo_ordem, quantidade, preco)


# Exemplo de uso (para teste)
async def exemplo_uso():
    """Exemplo de como usar o RiskManager de forma assíncrona."""
    # Configurar logging
    logging.basicConfig(level=logging.DEBUG)
    
    # Informações do ambiente
    print(f"Executando em: {platform.system()} {platform.machine()}")
    print(f"Mac M1 detectado: {is_mac_m1()}")
    
    # Criar DataFrame de exemplo
    import time
    dates = pd.date_range(end="2023-01-31", periods=100, freq="1h")
    price = 100 * (1 + np.random.normal(0, 0.02, 100).cumsum())
    df_teste = pd.DataFrame({"Close": price}, index=dates)
    df_teste["High"] = df_teste["Close"] * 1.01
    df_teste["Low"] = df_teste["Close"] * 0.99
    
    # Teste usando a classe diretamente
    print("=== Teste usando a classe RiskManager ===")
    risk_manager = RiskManager(config={"risk_volatility_threshold": 0.3})
    
    # Testar cálculo de volatilidade
    volatilidade = await risk_manager.calcular_volatilidade_async(df_teste)
    print(f"Volatilidade calculada: {volatilidade:.4f}")
    
    # Testar ajuste de risco
    class TestRegime:
        INDEFINIDO = 5
    score_original = 0.75
    score_ajustado = await risk_manager.aplicar_risco_async(score_original, df_teste, TestRegime.INDEFINIDO)
    print(f"Score ajustado: {score_original:.2f} -> {score_ajustado:.2f}")
    
    # Testar cálculo de SL/TP
    sl, tp = await risk_manager.calcular_sl_tp_dinamico_async(df_teste, 100.0, "BUY")
    print(f"SL/TP calculado: SL={sl:.2f}, TP={tp:.2f}")
    
    # Testar validação de ordem
    valido, motivo = await risk_manager.validar_ordem("BTCUSDT", "BUY", 0.001, 50000)
    print(f"Ordem válida: {valido}, Motivo: {motivo}")
    
    # Testar funções procedurais
    print("\n=== Teste usando funções procedurais ===")
    vol_proc = await calcular_volatilidade_async(df_teste)
    print(f"Volatilidade (procedural): {vol_proc:.4f}")
    
    score_proc = await aplicar_risco_async(0.8, df_teste, TestRegime.INDEFINIDO)
    print(f"Score ajustado (procedural): {score_proc:.2f}")
    
    sl_proc, tp_proc = await calcular_sl_tp_dinamico_async(df_teste, 100.0, "SELL")
    print(f"SL/TP (procedural): SL={sl_proc:.2f}, TP={tp_proc:.2f}")
    
    valido_proc, motivo_proc = await validar_ordem_async("BTCUSDT", "SELL", 0.001, 50000)
    print(f"Ordem válida (procedural): {valido_proc}, Motivo: {motivo_proc}")

# Executar exemplo se o script for executado diretamente
if __name__ == "__main__":
    import asyncio
    asyncio.run(exemplo_uso())
