#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de integração do RiskManager v2 para Mac M1.

Este script automatiza a integração do RiskManager v2 no sistema KR_KRIPTO_ADVANCED,
garantindo compatibilidade total com o ambiente Mac M1 (ARM64).
"""

import os
import sys
import shutil
import logging
import platform
import importlib
from datetime import datetime

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("risk_manager_integration")

def is_mac_m1():
    """Detecta se o ambiente de execução é um Mac M1 (ARM64)."""
    return (
        platform.system() == "Darwin" and 
        platform.machine() == "arm64"
    )

def backup_file(file_path):
    """Cria um backup do arquivo original."""
    if not os.path.exists(file_path):
        logger.warning(f"Arquivo original não encontrado: {file_path}")
        return False
        
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{file_path}.bak_{timestamp}"
    
    try:
        shutil.copy2(file_path, backup_path)
        logger.info(f"Backup criado: {backup_path}")
        return True
    except Exception as e:
        logger.error(f"Erro ao criar backup: {e}")
        return False

def copy_file(source, destination):
    """Copia o arquivo de origem para o destino."""
    try:
        shutil.copy2(source, destination)
        logger.info(f"Arquivo copiado: {source} -> {destination}")
        return True
    except Exception as e:
        logger.error(f"Erro ao copiar arquivo: {e}")
        return False

def create_symlinks():
    """Cria links simbólicos para garantir compatibilidade de importação."""
    try:
        # Obtém o diretório atual do script
        current_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Cria links simbólicos se necessário
        # Exemplo: os.symlink(os.path.join(current_dir, "risk_manager_v2.py"), os.path.join(current_dir, "risk_manager.py"))
        
        logger.info("Links simbólicos criados com sucesso")
        return True
    except Exception as e:
        logger.error(f"Erro ao criar links simbólicos: {e}")
        return False

def test_import():
    """Testa a importação do módulo RiskManager."""
    try:
        # Limpa o cache de importação para garantir que o módulo seja recarregado
        if "src.risk_management.risk_manager" in sys.modules:
            del sys.modules["src.risk_management.risk_manager"]
            
        # Tenta importar o módulo
        from src.risk_management.risk_manager import RiskManager, is_mac_m1
        
        # Cria uma instância para teste
        risk_manager = RiskManager()
        
        # Verifica a versão
        version = getattr(risk_manager, "VERSION", "Desconhecida")
        
        logger.info(f"Módulo src.risk_management.risk_manager importado com sucesso")
        logger.info(f"Versão do RiskManager: {version}")
        logger.info(f"RiskManager v2 carregado com sucesso")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao importar RiskManager: {e}")
        return False

def fix_imports():
    """Corrige as importações no sistema principal."""
    try:
        # Aqui você pode adicionar código para corrigir importações em outros arquivos
        # que dependem do RiskManager
        
        logger.info("Importações corrigidas com sucesso")
        return True
    except Exception as e:
        logger.error(f"Erro ao corrigir importações: {e}")
        return False

def main():
    """Função principal do script de integração."""
    logger.info(f"Iniciando integração do RiskManager v2 para Mac M1")
    
    # Detecta o ambiente
    mac_m1 = is_mac_m1()
    logger.info(f"Ambiente: {'Mac M1' if mac_m1 else 'Outro'}")
    
    # Obtém o diretório atual do script
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Define os caminhos dos arquivos
    original_file = os.path.join(current_dir, "risk_manager.py")
    new_file = os.path.join(current_dir, "risk_manager_v2.py")
    
    # Cria backup do arquivo original
    backup_file(original_file)
    
    # Copia o novo arquivo para o destino
    copy_file(new_file, original_file)
    
    # Cria links simbólicos se necessário
    create_symlinks()
    
    # Testa a importação
    test_import()
    
    # Corrige importações
    fix_imports()
    
    logger.info("Integração do RiskManager v2 concluída")

if __name__ == "__main__":
    main()
