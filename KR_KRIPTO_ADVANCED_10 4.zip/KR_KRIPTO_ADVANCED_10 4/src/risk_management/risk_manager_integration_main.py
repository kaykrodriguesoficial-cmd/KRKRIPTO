#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de integração do RiskManager para o sistema KR_KRIPTO_ADVANCED.
Versão 2.0 - Compatível com Mac M1 (ARM64)

Este script corrige o problema de importação do RiskManager no sistema principal,
eliminando completamente o modo degradado no ambiente Mac M1.
"""

import os
import sys
import shutil
import logging
import platform
import importlib
from datetime import datetime

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("risk_manager_integration_main")

def is_mac_m1():
    """Detecta se o ambiente de execução é um Mac M1 (ARM64)."""
    return (
        platform.system() == "Darwin" and 
        platform.machine() == "arm64"
    )

def backup_file(file_path):
    """Cria um backup do arquivo original."""
    if not os.path.exists(file_path):
        logger.warning(f"Arquivo original não encontrado: {file_path}")
        return False
        
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{file_path}.bak_{timestamp}"
    
    try:
        shutil.copy2(file_path, backup_path)
        logger.info(f"Backup criado: {backup_path}")
        return True
    except Exception as e:
        logger.error(f"Erro ao criar backup: {e}")
        return False

def copy_file(source, destination):
    """Copia o arquivo de origem para o destino."""
    try:
        if not os.path.exists(source):
            logger.error(f"Arquivo de origem não encontrado: {source}")
            return False
            
        # Cria o diretório de destino se não existir
        os.makedirs(os.path.dirname(destination), exist_ok=True)
        
        shutil.copy2(source, destination)
        logger.info(f"Arquivo copiado: {source} -> {destination}")
        return True
    except Exception as e:
        logger.error(f"Erro ao copiar arquivo: {e}")
        return False

def modify_main_py():
    """Modifica o arquivo main.py para corrigir a importação do RiskManager."""
    try:
        # Caminho do arquivo main.py
        main_py = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'main.py'))
        
        if not os.path.exists(main_py):
            logger.error(f"Arquivo main.py não encontrado: {main_py}")
            return False
            
        # Cria backup do arquivo original
        backup_file(main_py)
        
        # Lê o conteúdo do arquivo
        with open(main_py, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Procura o bloco de importação do RiskManager
        import_pattern = r'# Importar RiskManager.*?try\s*:\s*from\s+risk_management\.risk_manager\s+import\s+RiskManager.*?except\s+ImportError.*?logger\.critical\(.*?Lógica\s+SL/TP\s+desabilitada.*?\)'
        
        # Novo bloco de importação com múltiplas tentativas
        new_import = """# Importar RiskManager
try:
    # Primeiro tenta importar do caminho correto
    from src.risk_management.risk_manager import RiskManager
    logger.info("RiskManager importado com sucesso de src.risk_management")
except ImportError:
    try:
        # Tenta caminho alternativo
        from risk_management.risk_manager import RiskManager
        logger.info("RiskManager importado com sucesso de risk_management")
    except ImportError as e:
        try:
            # Tenta caminho relativo
            import sys
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            from src.risk_management.risk_manager_v2 import RiskManager
            logger.info("RiskManager v2 importado com sucesso")
        except ImportError as e2:
            logger.critical(f"Falha ao importar RiskManager de risk_management.risk_manager. Lógica SL/TP desabilitada.")"""
        
        # Substitui o bloco de importação
        import re
        new_content = re.sub(import_pattern, new_import, content, flags=re.DOTALL)
        
        # Se não encontrou o padrão exato, tenta um padrão mais genérico
        if new_content == content:
            logger.warning("Padrão de importação exato não encontrado, tentando padrão genérico")
            
            # Padrão mais genérico
            generic_pattern = r'(# Importar RiskManager.*?try\s*:.*?from.*?risk_manager.*?import.*?RiskManager.*?except.*?ImportError.*?logger\.critical\(.*?Lógica\s+SL/TP\s+desabilitada.*?\))'
            
            # Tenta substituir com o padrão genérico
            new_content = re.sub(generic_pattern, new_import, content, flags=re.DOTALL)
            
            # Se ainda não encontrou, procura apenas pela mensagem de erro
            if new_content == content:
                logger.warning("Padrão genérico não encontrado, tentando localizar pela mensagem de erro")
                
                # Procura pela mensagem de erro
                error_pattern = r'(logger\.critical\(.*?Falha ao importar RiskManager.*?Lógica\s+SL/TP\s+desabilitada.*?\))'
                
                # Encontra a posição da mensagem de erro
                error_match = re.search(error_pattern, content, re.DOTALL)
                
                if error_match:
                    # Encontra o início do bloco try/except
                    try_pattern = r'# Importar RiskManager.*?try\s*:'
                    try_match = re.search(try_pattern, content[:error_match.start()], re.DOTALL)
                    
                    if try_match:
                        # Substitui todo o bloco
                        block_to_replace = content[try_match.start():error_match.end()]
                        new_content = content.replace(block_to_replace, new_import)
                        logger.info("Bloco de importação do RiskManager substituído com sucesso")
                    else:
                        logger.error("Não foi possível localizar o início do bloco try/except")
                        return False
                else:
                    logger.error("Não foi possível localizar a mensagem de erro do RiskManager")
                    return False
        
        # Escreve o conteúdo modificado
        with open(main_py, 'w', encoding='utf-8') as f:
            f.write(new_content)
        
        logger.info(f"Arquivo {main_py} modificado com sucesso")
        return True
    except Exception as e:
        logger.error(f"Erro ao modificar main.py: {e}")
        return False

def test_import():
    """Testa a importação do módulo RiskManager."""
    try:
        # Limpa o cache de importação para garantir que o módulo seja recarregado
        if "src.risk_management.risk_manager" in sys.modules:
            del sys.modules["src.risk_management.risk_manager"]
            
        # Tenta importar o módulo
        from src.risk_management.risk_manager import RiskManager, is_mac_m1
        
        # Cria uma instância para teste
        risk_manager = RiskManager()
        
        # Verifica o ambiente
        mac_m1 = is_mac_m1()
        
        logger.info(f"Módulo src.risk_management.risk_manager importado com sucesso")
        logger.info(f"Ambiente Mac M1: {mac_m1}")
        logger.info(f"RiskManager carregado com sucesso")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao importar RiskManager: {e}")
        return False

def main():
    """Função principal do script de integração."""
    logger.info(f"Iniciando integração do RiskManager para Mac M1")
    
    # Detecta o ambiente
    mac_m1 = is_mac_m1()
    logger.info(f"Ambiente: {'Mac M1' if mac_m1 else 'Outro'} ({platform.system()} {platform.machine()})")
    
    # Obtém o diretório atual do script
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Define os caminhos dos arquivos
    original_file = os.path.join(current_dir, "risk_manager.py")
    new_file = os.path.join(current_dir, "risk_manager_v2.py")
    
    # Verifica se os arquivos existem
    if not os.path.exists(new_file):
        logger.error(f"Arquivo risk_manager_v2.py não encontrado: {new_file}")
        return False
    
    # Cria backup do arquivo original se existir
    if os.path.exists(original_file):
        backup_file(original_file)
    
    # Copia o novo arquivo para o destino
    copy_file(new_file, original_file)
    
    # Modifica o arquivo main.py
    modify_main_py()
    
    # Testa a importação
    test_import()
    
    logger.info("Integração do RiskManager concluída")
    logger.info("Execute o sistema principal para verificar:")
    logger.info("python main.py --max-runtime 30 --debug")
    
    return True

if __name__ == "__main__":
    main()
