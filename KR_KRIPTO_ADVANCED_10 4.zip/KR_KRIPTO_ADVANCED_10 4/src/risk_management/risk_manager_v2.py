# -*- coding: utf-8 -*-
"""
Módulo RiskManager para o sistema KR_KRIPTO_ADVANCED.
Versão adaptada para compatibilidade com Mac M1 (ARM64).

Este módulo implementa gerenciamento de risco, cálculo de Stop Loss/Take Profit
e ajuste de scores baseado em volatilidade.
"""

import pandas as pd
import logging
import numpy as np
import platform
import sys
from typing import Optional, Tuple, Dict, Any, Union

# Configuração de logger
logger = logging.getLogger("kr_kripto_risk")

# Detecção de ambiente Mac M1
def is_mac_m1() -> bool:
    """Detecta se o ambiente de execução é um Mac M1 (ARM64)."""
    return (
        platform.system() == "Darwin" and 
        platform.machine() == "arm64"
    )

# Exportação explícita para garantir que a função possa ser importada diretamente
__all__ = ['RiskManager', 'is_mac_m1', 'calcular_volatilidade', 
           'aplicar_risco', 'calcular_sl_tp_dinamico']

# Tentativa de importar MarketRegime. Se falhar, define um stub.
try:
    from src.intelligence.context_switcher import MarketRegime
except ImportError:
    try:
        # Tentativa alternativa para Mac M1
        sys.path.append('.')
        from intelligence.context_switcher import MarketRegime
    except ImportError:
        from enum import Enum
        class MarketRegime:
            TENDENCIA_ALTA = 1
            TENDENCIA_BAIXA = 2
            LATERAL_ALTA_VOL = 3
            LATERAL_BAIXA_VOL = 4
            INDEFINIDO = 5
        logger.warning("MarketRegime not found, using stub enum.")

# Verificar se pandas_ta está disponível
try:
    import pandas_ta as ta
    PANDAS_TA_AVAILABLE = True
except ImportError:
    try:
        # Tentativa de instalação automática para Mac M1
        if is_mac_m1():
            import subprocess
            logger.info("Tentando instalar pandas_ta para Mac M1...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", "pandas_ta"])
            import pandas_ta as ta
            PANDAS_TA_AVAILABLE = True
        else:
            PANDAS_TA_AVAILABLE = False
    except Exception as e:
        PANDAS_TA_AVAILABLE = False
        logger.warning(f"pandas_ta não disponível ({str(e)}). Algumas funcionalidades de cálculo de ATR serão limitadas.")

class RiskManager:
    """
    Gerenciador de risco para o sistema KR_KRIPTO_ADVANCED.
    Implementa cálculo de Stop Loss/Take Profit e ajuste de scores baseado em volatilidade.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Inicializa o gerenciador de risco.
        
        Args:
            config: Dicionário de configuração com parâmetros de risco
        """
        if config is None:
            config = {}
            
        # Parâmetros para ajuste de score
        self.fator_volatilidade_alta = config.get("risk_volatility_factor", 0.85)  # Reduz score em alta vol
        self.fator_regime_incerto = config.get("risk_uncertain_factor", 0.90)  # Reduz score em regime indefinido
        self.limite_volatilidade = config.get("risk_volatility_threshold", 0.6)  # Limite para alta volatilidade
        
        # Parâmetros para SL/TP
        self.atr_period = config.get("risk_atr_period", 14)
        self.sl_multiplier = config.get("risk_sl_multiplier", 1.5)
        self.tp_multiplier = config.get("risk_tp_multiplier", None)
        self.risk_reward_ratio = config.get("risk_reward_ratio", 2.0)
        
        # Detecção de ambiente
        self.is_mac_m1 = is_mac_m1()
        self.environment_info = self._get_environment_info()
        
        logger.info(f"RiskManager inicializado com configuração: {config}")
        logger.info(f"Ambiente: {self.environment_info}")
    
    def _get_environment_info(self) -> Dict[str, str]:
        """Coleta informações sobre o ambiente de execução."""
        return {
            'system': platform.system(),
            'release': platform.release(),
            'machine': platform.machine(),
            'processor': platform.processor(),
            'python': platform.python_version(),
            'mac_m1': self.is_mac_m1
        }
    
    def calcular_volatilidade(self, df: pd.DataFrame, window: int = 20) -> float:
        """
        Calcula a volatilidade histórica (desvio padrão dos retornos logarítmicos).
        
        Args:
            df: DataFrame com dados históricos (requer coluna 'Close')
            window: Janela para cálculo da volatilidade
            
        Returns:
            Volatilidade anualizada
        """
        if df is None or len(df) < window + 1:
            return 0.0  # Retorna 0 se não houver dados suficientes
            
        try:
            # Verificação de segurança para Mac M1
            if not isinstance(df, pd.DataFrame):
                logger.warning(f"Tipo de dados inválido: {type(df)}. Esperado: DataFrame")
                return 0.0
                
            if "Close" not in df.columns:
                logger.warning("Coluna 'Close' não encontrada no DataFrame")
                return 0.0
                
            log_returns = np.log(df["Close"] / df["Close"].shift(1))
            volatility = log_returns.rolling(window=window).std().iloc[-1]
            
            # Verificação de NaN para Mac M1
            if pd.isna(volatility):
                logger.warning("Volatilidade calculada é NaN, retornando 0.0")
                return 0.0
                
            return volatility * np.sqrt(252)  # Anualiza (ajustar se necessário para o timeframe)
        except Exception as e:
            logger.error(f"Erro ao calcular volatilidade: {e}", exc_info=True)
            return 0.0
    
    def aplicar_risco(self, score: float, df: pd.DataFrame, regime: Any) -> float:
        """
        Aplica lógica de gerenciamento de risco ao score bruto.
        Ajusta o score com base no regime de mercado e volatilidade.
        
        Args:
            score: O score bruto calculado (geralmente entre 0 e 1)
            df: DataFrame com dados históricos recentes
            regime: O regime de mercado atual identificado
            
        Returns:
            Score ajustado pelo risco
        """
        # Validação de entrada para Mac M1
        if not isinstance(score, (int, float)):
            logger.warning(f"Score inválido: {score}. Usando 0.5 como padrão.")
            score = 0.5
            
        score_ajustado = score
        razao_ajuste = "Nenhum"
        
        # 1. Ajuste por Regime de Mercado
        try:
            if hasattr(regime, 'LATERAL_ALTA_VOL') and hasattr(regime, 'INDEFINIDO'):
                if regime in [regime.LATERAL_ALTA_VOL, regime.INDEFINIDO]:
                    score_ajustado *= self.fator_regime_incerto
                    regime_name = getattr(regime, 'name', str(regime))
                    razao_ajuste = f"Regime Incerto/Alta Vol ({regime_name})"
                    logger.debug(f"Ajuste de risco aplicado devido ao regime {regime_name}. Score: {score:.4f} -> {score_ajustado:.4f}")
        except Exception as e:
            logger.warning(f"Erro ao processar regime de mercado: {e}. Ignorando ajuste de regime.")
        
        # 2. Ajuste por Volatilidade
        try:
            volatilidade_atual = self.calcular_volatilidade(df)
            if volatilidade_atual > self.limite_volatilidade:
                # Aplica o fator apenas se reduzir ainda mais o score (evita aumentar)
                novo_score_vol = score_ajustado * self.fator_volatilidade_alta
                if novo_score_vol < score_ajustado:
                    score_ajustado = novo_score_vol
                    razao_ajuste += " + Alta Volatilidade" if razao_ajuste != "Nenhum" else "Alta Volatilidade"
                    logger.debug(f"Ajuste de risco aplicado devido à alta volatilidade ({volatilidade_atual:.3f} > {self.limite_volatilidade}). Score: {score:.4f} -> {score_ajustado:.4f}")
        except Exception as e:
            logger.warning(f"Erro ao processar volatilidade: {e}. Ignorando ajuste de volatilidade.")
        
        if score_ajustado != score:
            logger.info(f"Score ajustado pelo risco: {score:.4f} -> {score_ajustado:.4f}. Razão: {razao_ajuste.strip()}")
        else:
            logger.debug(f"Nenhum ajuste de risco aplicado. Score final: {score_ajustado:.4f}")
        
        # Garante que o score permaneça entre 0 e 1
        return max(0.0, min(1.0, score_ajustado))
    
    def calcular_sl_tp_dinamico(self, df: pd.DataFrame, entry_price: float, side: str) -> Tuple[Optional[float], Optional[float]]:
        """
        Calcula Stop Loss (SL) e Take Profit (TP) dinâmicos com base no ATR.
        
        Args:
            df: DataFrame com dados históricos recentes (requer colunas 'High', 'Low', 'Close')
            entry_price: O preço de entrada da operação
            side: O lado da operação ('BUY' ou 'SELL')
            
        Returns:
            Tupla contendo (stop_loss_price, take_profit_price)
            Retorna (None, None) se não for possível calcular
        """
        # Validação de entrada para Mac M1
        if not isinstance(entry_price, (int, float)) or entry_price <= 0:
            logger.warning(f"Preço de entrada inválido: {entry_price}")
            return None, None
            
        if side not in ['BUY', 'SELL']:
            logger.warning(f"Lado inválido: {side}. Deve ser 'BUY' ou 'SELL'.")
            return None, None
            
        if df is None or len(df) < self.atr_period or not all(col in df.columns for col in ["High", "Low", "Close"]):
            logger.warning("Dados insuficientes ou colunas ausentes (High, Low, Close) para calcular ATR.")
            return None, None
        
        try:
            # Calcula o ATR usando pandas_ta se disponível
            if PANDAS_TA_AVAILABLE:
                try:
                    # Cria uma cópia para evitar modificar o DataFrame original
                    df_copy = df.copy()
                    df_copy.ta.atr(length=self.atr_period, append=True)
                    atr_column_name = f"ATR_{self.atr_period}"
                    if atr_column_name not in df_copy.columns:
                        logger.error(f"Coluna ATR {atr_column_name} não foi adicionada ao DataFrame.")
                        raise ValueError(f"Coluna ATR {atr_column_name} não encontrada")
                    current_atr = df_copy[atr_column_name].iloc[-1]
                except Exception as e:
                    logger.warning(f"Erro ao usar pandas_ta para ATR: {e}. Usando cálculo manual.")
                    # Fallback para cálculo manual
                    high_low = df['High'] - df['Low']
                    high_close = abs(df['High'] - df['Close'].shift(1))
                    low_close = abs(df['Low'] - df['Close'].shift(1))
                    ranges = pd.concat([high_low, high_close, low_close], axis=1)
                    true_range = ranges.max(axis=1)
                    current_atr = true_range.rolling(window=self.atr_period).mean().iloc[-1]
            else:
                # Cálculo manual do ATR se pandas_ta não estiver disponível
                high_low = df['High'] - df['Low']
                high_close = abs(df['High'] - df['Close'].shift(1))
                low_close = abs(df['Low'] - df['Close'].shift(1))
                ranges = pd.concat([high_low, high_close, low_close], axis=1)
                true_range = ranges.max(axis=1)
                current_atr = true_range.rolling(window=self.atr_period).mean().iloc[-1]
            
            if pd.isna(current_atr) or current_atr <= 0:
                logger.warning(f"Valor do ATR inválido ({current_atr}). Não é possível calcular SL/TP.")
                return None, None
            
            logger.debug(f"Calculando SL/TP: Entry={entry_price}, Side={side}, ATR({self.atr_period})={current_atr:.5f}")
            
            # Calcula a distância do Stop Loss
            sl_distance = current_atr * self.sl_multiplier
            
            # Calcula o preço do Stop Loss
            if side == 'BUY':
                stop_loss_price = entry_price - sl_distance
            elif side == 'SELL':
                stop_loss_price = entry_price + sl_distance
            else:
                logger.error(f"Lado inválido fornecido: {side}")
                return None, None
            
            # Calcula o preço do Take Profit
            if self.tp_multiplier is not None:
                tp_distance = current_atr * self.tp_multiplier
            else:  # Usa risk_reward_ratio
                tp_distance = sl_distance * self.risk_reward_ratio
            
            if side == 'BUY':
                take_profit_price = entry_price + tp_distance
            elif side == 'SELL':
                take_profit_price = entry_price - tp_distance
            
            logger.info(f"SL/TP Calculado: SL={stop_loss_price:.5f}, TP={take_profit_price:.5f} (Baseado em ATR={current_atr:.5f})")
            return stop_loss_price, take_profit_price
        
        except Exception as e:
            logger.error(f"Erro ao calcular SL/TP dinâmico: {e}", exc_info=True)
            return None, None


# ========== FUNÇÕES PROCEDURAIS PARA COMPATIBILIDADE COM CÓDIGO LEGADO ==========
# Estas funções servem como wrappers para os métodos da classe RiskManager,
# mantendo a interface original para compatibilidade com código existente.

# Instância global do RiskManager para uso pelas funções procedurais
_risk_manager_instance = None

def _get_risk_manager(config=None):
    """Obtém ou cria uma instância global do RiskManager."""
    global _risk_manager_instance
    if _risk_manager_instance is None:
        _risk_manager_instance = RiskManager(config)
    return _risk_manager_instance

def calcular_volatilidade(df: pd.DataFrame, window: int = 20) -> float:
    """
    Wrapper procedural para o método calcular_volatilidade da classe RiskManager.
    Calcula a volatilidade histórica (desvio padrão dos retornos logarítmicos).
    """
    return _get_risk_manager().calcular_volatilidade(df, window)

def aplicar_risco(
    score: float,
    df: pd.DataFrame,
    regime: Any,
    config: Optional[dict] = None
) -> float:
    """
    Wrapper procedural para o método aplicar_risco da classe RiskManager.
    Aplica lógica de gerenciamento de risco ao score bruto.
    Ajusta o score com base no regime de mercado e volatilidade.
    """
    # Se config for fornecido, cria uma nova instância do RiskManager
    if config is not None:
        risk_manager = RiskManager(config)
        return risk_manager.aplicar_risco(score, df, regime)
    else:
        return _get_risk_manager().aplicar_risco(score, df, regime)

def calcular_sl_tp_dinamico(
    df: pd.DataFrame,
    entry_price: float,
    side: str,
    config: Optional[dict] = None
) -> Tuple[Optional[float], Optional[float]]:
    """
    Wrapper procedural para o método calcular_sl_tp_dinamico da classe RiskManager.
    Calcula Stop Loss (SL) e Take Profit (TP) dinâmicos com base no ATR.
    """
    # Se config for fornecido, cria uma nova instância do RiskManager
    if config is not None:
        risk_manager = RiskManager(config)
        return risk_manager.calcular_sl_tp_dinamico(df, entry_price, side)
    else:
        return _get_risk_manager().calcular_sl_tp_dinamico(df, entry_price, side)


# Exemplo de uso (para teste)
if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    
    # Informações do ambiente
    print(f"Executando em: {platform.system()} {platform.machine()}")
    print(f"Mac M1 detectado: {is_mac_m1()}")
    
    # Criar DataFrame de exemplo
    dates = pd.date_range(end="2023-01-31", periods=100, freq="1h")
    price = 100 * (1 + np.random.normal(0, 0.02, 100).cumsum())
    df_teste = pd.DataFrame({"Close": price}, index=dates)
    
    # Teste usando a classe diretamente
    print("=== Teste usando a classe RiskManager ===")
    risk_manager = RiskManager(config={"risk_volatility_threshold": 0.3})
    
    class TestRegime:
        TENDENCIA_ALTA = 1
        TENDENCIA_BAIXA = 2
        LATERAL_ALTA_VOL = 3
        LATERAL_BAIXA_VOL = 4
        INDEFINIDO = 5
        name = "TESTE"
    
    score_teste = 0.85
    regime_teste = TestRegime.LATERAL_ALTA_VOL
    score_final = risk_manager.aplicar_risco(score_teste, df_teste, regime_teste)
    print(f"Score Original: {score_teste}, Regime: {regime_teste}, Score Ajustado: {score_final:.4f}")
    
    # Teste usando as funções procedurais
    print("\n=== Teste usando as funções procedurais ===")
    score_teste = 0.85
    regime_teste = TestRegime.LATERAL_ALTA_VOL
    config_teste = {"risk_volatility_threshold": 0.3}
    score_final = aplicar_risco(score_teste, df_teste, regime_teste, config_teste)
    print(f"Score Original: {score_teste}, Regime: {regime_teste}, Score Ajustado: {score_final:.4f}")
    
    # Teste de cálculo de SL/TP
    data = {
        'High': np.random.uniform(101, 105, 100),
        'Low': np.random.uniform(95, 99, 100),
        'Close': np.random.uniform(99, 101, 100)
    }
    # Garante que Low <= Close <= High
    data['Low'] = np.minimum(data['Low'], data['Close'])
    data['High'] = np.maximum(data['High'], data['Close'])
    df_teste_sl_tp = pd.DataFrame(data, index=pd.date_range(end="2023-01-31", periods=100, freq="1h"))
    
    entry_price_buy = 100.50
    side_buy = 'BUY'
    sl_buy, tp_buy = calcular_sl_tp_dinamico(df_teste_sl_tp.copy(), entry_price_buy, side_buy)
    print(f"Entrada BUY @ {entry_price_buy:.2f} -> SL: {sl_buy}, TP: {tp_buy}")
