#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Gera dados sintéticos voláteis para o teste E2E."""

import pandas as pd
import numpy as np
import time

# Parâmetros
num_rows = 60  # Gerar um pouco mais que 50 para garantir
start_timestamp_ms = int(time.time() * 1000) - (num_rows * 60 * 1000) # Começa X minutos atrás
base_price = 24000
volatility_factor = 500 # Controla a amplitude High-Low (para ATR alto)
volume_base = 100
volume_variation = 50

# Gerar timestamps (intervalo de 1 minuto)
timestamps = [start_timestamp_ms + i * 60 * 1000 for i in range(num_rows)]

data = []

for i in range(num_rows):
    # Manter Open e Close relativamente estáveis para ADX baixo
    open_price = base_price + np.random.uniform(-50, 50)
    close_price = open_price + np.random.uniform(-50, 50)
    
    # Criar grande variação High/Low para ATR alto
    high_price = max(open_price, close_price) + np.random.uniform(volatility_factor * 0.8, volatility_factor * 1.2)
    low_price = min(open_price, close_price) - np.random.uniform(volatility_factor * 0.8, volatility_factor * 1.2)
    
    # Garantir OHLC válido
    high_price = max(high_price, open_price, close_price)
    low_price = min(low_price, open_price, close_price)
    
    volume = volume_base + np.random.uniform(-volume_variation, volume_variation)
    
    data.append({
        "timestamp": timestamps[i],
        "Open": round(open_price, 2),
        "High": round(high_price, 2),
        "Low": round(low_price, 2),
        "Close": round(close_price, 2),
        "Volume": round(volume, 2)
    })

df = pd.DataFrame(data)

# Salvar CSV
output_path = "/home/ubuntu/audit_kripto/KR_KRIPTO_ADVANCED_REORGANIZED/src/tests/e2e/data/e2e_volatile_data_synthetic.csv"
df.to_csv(output_path, index=False)

print(f"Dados sintéticos voláteis salvos em: {output_path}")

