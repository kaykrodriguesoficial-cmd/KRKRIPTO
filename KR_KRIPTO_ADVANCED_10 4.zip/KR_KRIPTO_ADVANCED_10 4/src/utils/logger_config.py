#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Configuração de Logger - Módulo para configuração centralizada de logging

Este módulo implementa funções para configuração centralizada de logging
com suporte a rotação de arquivos e formatação personalizada.

Autor: Equipe KR_KRIPTO
Data: Maio 2025
Versão: 2.0
"""

import os
import logging
from logging.handlers import TimedRotatingFileHandler
import sys
from datetime import datetime

def setup_logger(name, log_level=logging.INFO, log_dir=None, rotation='daily'):
    """
    Configura um logger com rotação de arquivos.
    
    Args:
        name (str): Nome do logger
        log_level (int): Nível de logging (default: logging.INFO)
        log_dir (str): Diretório para arquivos de log (default: None, usa ./logs)
        rotation (str): Tipo de rotação ('daily', 'hourly', 'weekly', 'none')
        
    Returns:
        logging.Logger: Logger configurado
    """
    # Criar logger
    logger = logging.getLogger(name)
    
    # Evitar duplicação de handlers
    if logger.handlers:
        return logger
    
    # Definir nível de logging
    logger.setLevel(log_level)
    
    # Criar formatador
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    # Adicionar handler para console
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # Adicionar handler para arquivo se log_dir for especificado
    if log_dir:
        # Criar diretório de logs se não existir
        os.makedirs(log_dir, exist_ok=True)
        
        # Definir nome do arquivo de log
        log_file = os.path.join(log_dir, f"{name.replace('.', '_')}.log")
        
        # Criar handler com rotação
        if rotation == 'none':
            file_handler = logging.FileHandler(log_file)
        else:
            when_map = {
                'hourly': 'H',
                'daily': 'D',
                'weekly': 'W0',
                'monthly': 'M'
            }
            when = when_map.get(rotation, 'D')  # Default para daily
            file_handler = TimedRotatingFileHandler(log_file, when=when, backupCount=30)
        
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    logger.info(f"Logger configurado com rotação {rotation} para {name}")
    return logger

def get_logger(name, log_level=None):
    """
    Obtém um logger existente ou cria um novo.
    
    Args:
        name (str): Nome do logger
        log_level (int): Nível de logging (default: None, usa o nível existente)
        
    Returns:
        logging.Logger: Logger existente ou novo
    """
    logger = logging.getLogger(name)
    
    if log_level is not None:
        logger.setLevel(log_level)
    
    # Se o logger não tem handlers, adicionar um handler para console
    if not logger.handlers:
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
    
    return logger

def configure_root_logger(log_level=logging.INFO, log_file=None):
    """
    Configura o logger raiz.
    
    Args:
        log_level (int): Nível de logging (default: logging.INFO)
        log_file (str): Caminho para arquivo de log (default: None)
        
    Returns:
        logging.Logger: Logger raiz configurado
    """
    # Configurar logger raiz
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)
    
    # Remover handlers existentes
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    
    # Criar formatador
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    # Adicionar handler para console
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    
    # Adicionar handler para arquivo se log_file for especificado
    if log_file:
        # Criar diretório de logs se não existir
        log_dir = os.path.dirname(log_file)
        if log_dir:
            os.makedirs(log_dir, exist_ok=True)
        
        # Criar handler para arquivo
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)
    
    return root_logger

def log_exception(logger, exc_info=None, level=logging.ERROR):
    """
    Registra uma exceção no logger.
    
    Args:
        logger (logging.Logger): Logger para registrar a exceção
        exc_info (tuple): Informações da exceção (default: None, usa sys.exc_info())
        level (int): Nível de logging (default: logging.ERROR)
    """
    if exc_info is None:
        exc_info = sys.exc_info()
    
    logger.log(level, "Exceção capturada:", exc_info=exc_info)
