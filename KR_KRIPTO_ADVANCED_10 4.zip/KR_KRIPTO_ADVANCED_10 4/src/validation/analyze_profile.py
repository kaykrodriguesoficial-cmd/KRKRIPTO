import pstats
import sys

profile_file = '/home/ubuntu/audit_kripto/KR_KRIPTO_ADVANCED_REORGANIZED/logs/phase3_profile.prof'
output_file = '/home/ubuntu/audit_kripto/KR_KRIPTO_ADVANCED_REORGANIZED/logs/phase3_profile_analysis.txt'

# Redirect output to file
original_stdout = sys.stdout
sys.stdout = open(output_file, 'w')

p = pstats.Stats(profile_file)

print("--- Stats ordenadas por tempo cumulativo (cumtime) ---")
p.sort_stats('cumulative').print_stats(50) # Top 50 por tempo cumulativo

print("\n--- Stats ordenadas por tempo total no próprio código (tottime) ---")
p.sort_stats('tottime').print_stats(50) # Top 50 por tempo total

print("\n--- Chamadores (Callers) ---")
p.print_callers(50) # Top 50 chamadores

print("\n--- Chamados (Callees) ---")
p.print_callees(50) # Top 50 chamados

# Restore stdout
sys.stdout.close()
sys.stdout = original_stdout

print(f"Análise do profile salva em {output_file}")

