# Placeholder for input validation logic

import pandas as pd
import logging
import pandas_ta as ta # Import pandas_ta

logger = logging.getLogger("kr_kripto_validators")

# Define a minimum length required for indicator calculation (adjust as needed)
MIN_DATAFRAME_LENGTH = 20 # Reduced from 50 to be compatible with tests

def validar_entrada_sinal(df_original: pd.DataFrame, ativo: str) -> tuple[bool, pd.DataFrame | None]:
    """Validates the input DataFrame, standardizes columns, and calculates required indicators.
    
    Args:
        df_original: The input DataFrame.
        ativo: The asset symbol.
        
    Returns:
        A tuple containing a boolean indicating validity and the processed DataFrame (or None).
    """
    if df_original is None or df_original.empty:
        logger.warning(f"[{ativo}] Input DataFrame is None or empty.")
        return False, None
    
    df = df_original.copy()
    
    # 1. Standardize column names to lowercase
    df.columns = [col.lower() for col in df.columns]
    
    # 2. Check for required columns (lowercase)
    required_columns = ["open", "high", "low", "close", "volume"]
    if not all(col in df.columns for col in required_columns):
        logger.warning(f"[{ativo}] Input DataFrame missing required columns ({required_columns}) after lowercasing. Found: {list(df.columns)}")
        return False, None
        
    # 3. Check for sufficient data (using MIN_DATAFRAME_LENGTH)
    if len(df) < MIN_DATAFRAME_LENGTH:
        logger.info(f"[{ativo}] Insufficient data for full indicator calculation ({len(df)} rows). Need at least {MIN_DATAFRAME_LENGTH}. Proceeding with available data.")
        # Don't return None here, let indicator calculation handle NaNs for short data
        pass # Allow short dataframes to proceed
        
    # 4. Check for NaNs in critical columns
    if df[required_columns].isnull().values.any():
        logger.warning(f"[{ativo}] Input DataFrame contains NaN values in critical columns. Attempting to drop NaNs.")
        df.dropna(subset=required_columns, inplace=True)
        # Re-check length after dropping NaNs
        if len(df) < MIN_DATAFRAME_LENGTH:
             logger.info(f"[{ativo}] Insufficient data after dropping NaN ({len(df)} rows). Need at least {MIN_DATAFRAME_LENGTH}. Proceeding with available data.")
             pass # Allow short dataframes to proceed
        if df.empty:
            logger.warning(f"[{ativo}] DataFrame became empty after dropping NaN values.")
            return False, None # Return False if empty after dropna

    # 5. Calculate required indicators using pandas_ta
    try:
        # Use default lengths for now, can be parameterized later via config
        df.ta.atr(length=14, append=True)
        df.ta.adx(length=14, append=True)
        df.ta.bbands(length=20, std=2, append=True)
        df.ta.rsi(length=14, append=True) # ADDED RSI CALCULATION
        
        # Ensure columns exist even if calculation fails partially (fill with NaN)
        # Updated list to include RSI
        indicator_cols_to_check = ["ATR_14", "ADX_14", "RSI_14", "BBL_20_2.0", "BBU_20_2.0", "BBB_20_2.0"]
        missing_indicators = []
        for col in indicator_cols_to_check:
            if col not in df.columns:
                df[col] = pd.NA
                missing_indicators.append(col)
        if missing_indicators:
             logger.warning(f"[{ativo}] Some indicators might be missing or failed calculation (filled with NA): {missing_indicators}. Check pandas_ta setup and data length ({len(df)} rows).")
             # Decide if this is critical. For now, let it pass but downstream modules might fail.
             
        # Drop rows with NaN in indicators if necessary (or handle in downstream logic)
        # df.dropna(subset=indicator_cols, inplace=True)
        # if len(df) < 1: # Check if all rows were dropped
        #     logger.warning(f"[{ativo}] All rows dropped after calculating indicators due to NaNs.")
        #     return True, None # Changed to False, None as it's likely unusable
        
    except Exception as e:
        logger.error(f"[{ativo}] Error calculating technical indicators: {e}")
        # Decide how to handle: return error or proceed without indicators?
        # For now, return error to highlight the issue
        return False, None

    logger.debug(f"[{ativo}] Input DataFrame validated and indicators calculated ({len(df)} rows).")
    return True, df
