#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Integração Telegram para ML Supremo
===================================

Script para configurar e testar a integração com Telegram.
Envia sinais de trading diretamente para o seu chat.

Autor: Sistema ML Supremo
Data: 2025-09-01
"""

import requests
import json
import os
from datetime import datetime
from typing import Dict, Optional
import logging

# Configuração de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TelegramIntegration:
    """
    Classe para integração com Telegram.
    
    Envia sinais de trading, resumos e alertas para o Telegram.
    """
    
    def __init__(self, bot_token: str = None, chat_id: str = None, config_file: str = None):
        """
        Inicializa a integração com Telegram.
        
        Args:
            bot_token: Token do bot do Telegram
            chat_id: ID do chat para enviar mensagens
            config_file: Arquivo de configuração (opcional)
        """
        self.bot_token = bot_token
        self.chat_id = chat_id
        self.config_file = config_file or 'config.json'
        
        # Carrega configurações se não fornecidas
        if not self.bot_token or not self.chat_id:
            self._load_config()
        
        # URL base da API do Telegram
        self.base_url = f"https://api.telegram.org/bot{self.bot_token}"
        
        logger.info("TelegramIntegration inicializada")
        logger.info(f"Bot token: {'Configurado' if self.bot_token else 'Faltando'}")
        logger.info(f"Chat ID: {'Configurado' if self.chat_id else 'Faltando'}")

    def _load_config(self):
        """Carrega configurações do arquivo config.json ou .env"""
        try:
            # Tenta carregar do config.json
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                
                telegram_config = config.get('telegram', {})
                self.bot_token = self.bot_token or telegram_config.get('bot_token')
                self.chat_id = self.chat_id or telegram_config.get('chat_id')
                
                logger.info("Configurações carregadas do config.json")
            
            # Tenta carregar do .env se ainda não tem as configurações
            if not self.bot_token or not self.chat_id:
                from dotenv import load_dotenv
                load_dotenv()
                
                self.bot_token = self.bot_token or os.getenv('TELEGRAM_BOT_TOKEN')
                self.chat_id = self.chat_id or os.getenv('TELEGRAM_CHAT_ID')
                
                logger.info("Configurações carregadas do .env")
                
        except Exception as e:
            logger.error(f"Erro ao carregar configurações: {e}")

    def test_connection(self) -> bool:
        """
        Testa a conexão com o Telegram.
        
        Returns:
            bool: True se a conexão estiver funcionando
        """
        try:
            if not self.bot_token:
                logger.error("Bot token não configurado")
                return False
            
            # Testa o bot
            url = f"{self.base_url}/getMe"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                bot_info = response.json()
                logger.info(f"✅ Bot conectado: {bot_info['result']['first_name']}")
                
                # Testa envio de mensagem
                if self.chat_id:
                    test_message = "🎯 TESTE ML SUPREMO\n\n✅ Sistema conectado com sucesso!"
                    return self.send_message(test_message)
                else:
                    logger.warning("Chat ID não configurado - não é possível testar envio")
                    return True
            else:
                logger.error(f"Erro na conexão: {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Erro ao testar conexão: {e}")
            return False

    def send_message(self, message: str, parse_mode: str = 'HTML') -> bool:
        """
        Envia mensagem para o Telegram.
        
        Args:
            message: Mensagem a ser enviada
            parse_mode: Modo de parsing (HTML ou Markdown)
            
        Returns:
            bool: True se enviado com sucesso
        """
        try:
            if not self.bot_token or not self.chat_id:
                logger.error("Bot token ou Chat ID não configurados")
                return False
            
            url = f"{self.base_url}/sendMessage"
            data = {
                'chat_id': self.chat_id,
                'text': message,
                'parse_mode': parse_mode
            }
            
            response = requests.post(url, data=data, timeout=10)
            
            if response.status_code == 200:
                logger.info("✅ Mensagem enviada com sucesso")
                return True
            else:
                logger.error(f"❌ Erro ao enviar mensagem: {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"❌ Erro ao enviar mensagem: {e}")
            return False

    def send_trading_signal(self, signal_data: Dict) -> bool:
        """
        Envia sinal de trading formatado.
        
        Args:
            signal_data: Dados do sinal de trading
            
        Returns:
            bool: True se enviado com sucesso
        """
        try:
            # Extrai dados do sinal
            ativo = signal_data.get('ativo', 'N/A')
            acao = signal_data.get('acao', 'MANTER')
            confianca = signal_data.get('confianca', 0)
            preco = signal_data.get('preco', 0)
            position_size = signal_data.get('position_size', 0)
            stop_loss = signal_data.get('stop_loss', 0)
            take_profit = signal_data.get('take_profit', 0)
            gestao_risco = signal_data.get('gestao_risco', 'N/A')
            
            # Emojis baseados na ação
            emoji_acao = {
                'COMPRAR': '🟢',
                'VENDER': '🔴', 
                'MANTER': '🟡'
            }.get(acao, '⚪')
            
            # Formata a mensagem
            message = f"""🎯 <b>SINAL ML SUPREMO</b>

💰 <b>{ativo}</b>
{emoji_acao} <b>Ação: {acao}</b>
📊 Confiança: {confianca:.1f}%
💵 Preço: ${preco:,.2f}"""

            if position_size > 0:
                message += f"\n📈 Position Size: {position_size:.6f}"
            
            if stop_loss > 0:
                message += f"\n🛑 Stop-Loss: ${stop_loss:,.2f}"
            
            if take_profit > 0:
                message += f"\n🎯 Take-Profit: ${take_profit:,.2f}"
            
            message += f"\n\n🛡️ Gestão de Risco: {gestao_risco}"
            message += f"\n⏰ {datetime.now().strftime('%H:%M:%S - %d/%m/%Y')}"
            
            return self.send_message(message)
            
        except Exception as e:
            logger.error(f"Erro ao enviar sinal de trading: {e}")
            return False

    def send_performance_summary(self, performance_data: Dict) -> bool:
        """
        Envia resumo de performance.
        
        Args:
            performance_data: Dados de performance
            
        Returns:
            bool: True se enviado com sucesso
        """
        try:
            # Extrai dados de performance
            total_trades = performance_data.get('total_trades', 0)
            successful_trades = performance_data.get('successful_trades', 0)
            win_rate = (successful_trades / max(1, total_trades)) * 100
            total_profit = performance_data.get('total_profit', 0)
            best_trade = performance_data.get('best_trade', 0)
            worst_trade = performance_data.get('worst_trade', 0)
            active_assets = performance_data.get('active_assets', [])
            
            # Formata a mensagem
            message = f"""📊 <b>RESUMO ML SUPREMO</b>

✅ Trades Realizados: {total_trades}
🎯 Taxa de Acerto: {win_rate:.1f}%
💰 Profit Total: {total_profit:+.2f}%
📈 Melhor Trade: {best_trade:+.2f}%
📉 Pior Trade: {worst_trade:+.2f}%

🏆 Ativos Ativos: {', '.join(active_assets)}
⏰ {datetime.now().strftime('%H:%M:%S - %d/%m/%Y')}"""
            
            return self.send_message(message)
            
        except Exception as e:
            logger.error(f"Erro ao enviar resumo de performance: {e}")
            return False

    def send_alert(self, alert_message: str, alert_type: str = 'INFO') -> bool:
        """
        Envia alerta do sistema.
        
        Args:
            alert_message: Mensagem do alerta
            alert_type: Tipo do alerta (INFO, WARNING, ERROR)
            
        Returns:
            bool: True se enviado com sucesso
        """
        try:
            # Emojis baseados no tipo
            emoji_type = {
                'INFO': 'ℹ️',
                'WARNING': '⚠️',
                'ERROR': '🚨',
                'SUCCESS': '✅'
            }.get(alert_type, 'ℹ️')
            
            # Formata a mensagem
            message = f"""{emoji_type} <b>ALERTA ML SUPREMO</b>

{alert_message}

⏰ {datetime.now().strftime('%H:%M:%S - %d/%m/%Y')}"""
            
            return self.send_message(message)
            
        except Exception as e:
            logger.error(f"Erro ao enviar alerta: {e}")
            return False

    def get_chat_info(self) -> Optional[Dict]:
        """
        Obtém informações do chat.
        
        Returns:
            Dict: Informações do chat ou None se erro
        """
        try:
            if not self.bot_token or not self.chat_id:
                return None
            
            url = f"{self.base_url}/getChat"
            data = {'chat_id': self.chat_id}
            
            response = requests.post(url, data=data, timeout=10)
            
            if response.status_code == 200:
                return response.json()['result']
            else:
                logger.error(f"Erro ao obter info do chat: {response.text}")
                return None
                
        except Exception as e:
            logger.error(f"Erro ao obter info do chat: {e}")
            return None


def setup_telegram_config():
    """
    Função interativa para configurar o Telegram.
    """
    print("🎯 CONFIGURAÇÃO DO TELEGRAM ML SUPREMO")
    print("=" * 50)
    
    # Solicita informações
    print("\n1. Crie um bot no Telegram:")
    print("   - Procure por @BotFather")
    print("   - Envie /newbot")
    print("   - Escolha nome e username")
    print("   - Copie o TOKEN fornecido")
    
    bot_token = input("\n📱 Cole o TOKEN do bot: ").strip()
    
    print("\n2. Obtenha seu Chat ID:")
    print("   - Envie uma mensagem para o bot")
    print(f"   - Acesse: https://api.telegram.org/bot{bot_token}/getUpdates")
    print("   - Procure por 'chat':{'id': e copie o número")
    
    chat_id = input("\n📱 Cole o CHAT ID: ").strip()
    
    # Testa a configuração
    print("\n🧪 Testando configuração...")
    telegram = TelegramIntegration(bot_token, chat_id)
    
    if telegram.test_connection():
        print("✅ Configuração funcionando!")
        
        # Salva no config.json
        config_file = 'config.json'
        config = {}
        
        if os.path.exists(config_file):
            with open(config_file, 'r') as f:
                config = json.load(f)
        
        config['telegram'] = {
            'ativo': True,
            'bot_token': bot_token,
            'chat_id': chat_id,
            'enviar_sinais': True,
            'enviar_resumos': True,
            'confianca_minima': 60
        }
        
        with open(config_file, 'w') as f:
            json.dump(config, f, indent=2)
        
        print(f"✅ Configuração salva em {config_file}")
        print("\n🚀 Reinicie o sistema ML Supremo para ativar o Telegram!")
        
    else:
        print("❌ Erro na configuração. Verifique TOKEN e CHAT ID.")


def test_telegram_integration():
    """
    Testa a integração com Telegram.
    """
    print("🧪 TESTANDO INTEGRAÇÃO TELEGRAM")
    print("=" * 40)
    
    # Inicializa integração
    telegram = TelegramIntegration()
    
    # Testa conexão
    if not telegram.test_connection():
        print("❌ Falha na conexão. Configure primeiro.")
        return
    
    # Testa sinal de trading
    print("\n📊 Testando sinal de trading...")
    signal_data = {
        'ativo': 'BTCUSDT',
        'acao': 'COMPRAR',
        'confianca': 76.5,
        'preco': 109084.01,
        'position_size': 0.009167,
        'stop_loss': 107812.65,
        'take_profit': 110991.05,
        'gestao_risco': 'APROVADO'
    }
    
    if telegram.send_trading_signal(signal_data):
        print("✅ Sinal de trading enviado!")
    
    # Testa resumo de performance
    print("\n📈 Testando resumo de performance...")
    performance_data = {
        'total_trades': 12,
        'successful_trades': 9,
        'total_profit': 2.3,
        'best_trade': 0.8,
        'worst_trade': -0.2,
        'active_assets': ['BTCUSDT', 'ETHUSDT']
    }
    
    if telegram.send_performance_summary(performance_data):
        print("✅ Resumo de performance enviado!")
    
    # Testa alerta
    print("\n🚨 Testando alerta...")
    if telegram.send_alert("Sistema ML Supremo funcionando perfeitamente!", "SUCCESS"):
        print("✅ Alerta enviado!")
    
    print("\n🎉 Todos os testes concluídos!")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "setup":
            setup_telegram_config()
        elif sys.argv[1] == "test":
            test_telegram_integration()
        else:
            print("Uso: python3 telegram_integration.py [setup|test]")
    else:
        print("🎯 INTEGRAÇÃO TELEGRAM ML SUPREMO")
        print("=" * 40)
        print("Comandos disponíveis:")
        print("  python3 telegram_integration.py setup  - Configurar Telegram")
        print("  python3 telegram_integration.py test   - Testar integração")

