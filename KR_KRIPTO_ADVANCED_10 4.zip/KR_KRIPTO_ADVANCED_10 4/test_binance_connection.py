#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de teste para verificar a conexão com a API da Binance
e a capacidade de obter dados do mercado.

Este script testa:
1. Conexão com a API da Binance
2. Obtenção de dados do mercado
3. Verificação de saldo da conta
4. Simulação do fluxo de envio de ordem (sem executar ordem real)

Uso:
    python3 test_binance_connection.py
"""

import os
import sys
import json
import asyncio
import logging
from datetime import datetime
from typing import Dict, Any, Optional

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger("binance_test")

# Adicionar o diretório atual ao sys.path para garantir importações corretas
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

# Importar módulos necessários
try:
    from src.core.env_loader import obter_credencial
    from src.core.config_loader import carregar_config
    logger.info("Módulos core importados com sucesso")
except ImportError as e:
    logger.critical(f"Erro ao importar módulos core: {e}")
    logger.critical("Verifique se você está executando o script do diretório raiz do projeto")
    sys.exit(1)

# Tentar importar a biblioteca python-binance
try:
    from binance.client import Client
    try:
        from binance.async_client import AsyncClient
    except ImportError:
        # Adaptação para versões mais recentes da biblioteca
        from binance.client import Client as AsyncClient
        logger.info("Usando Client como AsyncClient (adaptação)")
    from binance.exceptions import BinanceAPIException, BinanceOrderException
    BINANCE_AVAILABLE = True
except ImportError as e:
    logger.critical(f"Falha ao importar biblioteca python-binance: {e}")
    logger.critical("Execute 'pip install python-binance' para resolver")
    BINANCE_AVAILABLE = False
    sys.exit(1)

async def test_binance_connection():
    """Testa a conexão com a API da Binance."""
    logger.info("Iniciando teste de conexão com a API da Binance")
    
    # Carregar configuração
    try:
        config = carregar_config("config.json")
        logger.info("Configuração carregada com sucesso")
    except Exception as e:
        logger.error(f"Erro ao carregar configuração: {e}")
        config = {}
    
    # Obter credenciais
    api_key = obter_credencial("binance_api_key", config)
    api_secret = obter_credencial("binance_api_secret", config)
    testnet = obter_credencial("testnet", config, default=False)
    
    if not api_key or not api_secret:
        logger.critical("Credenciais da API Binance não encontradas")
        logger.critical("Verifique se as variáveis de ambiente ou o arquivo de configuração estão corretos")
        return False
    
    # Mascarar a chave para o log
    masked_key = f"{api_key[:4]}...{api_key[-4:]}" if len(api_key) >= 8 else "****"
    logger.info(f"Usando API Key: {masked_key}")
    logger.info(f"Testnet mode: {testnet}")
    
    # Criar cliente assíncrono
    try:
        client = await AsyncClient.create(api_key, api_secret, testnet=testnet)
        logger.info("Cliente Binance criado com sucesso")
    except Exception as e:
        logger.critical(f"Erro ao criar cliente Binance: {e}")
        return False
    
    # Testar ping para verificar conexão
    try:
        ping_result = await client.ping()
        logger.info(f"Ping para API Binance bem-sucedido: {ping_result}")
    except Exception as e:
        logger.error(f"Erro ao fazer ping para API Binance: {e}")
        return False
    
    # Obter informações do servidor
    try:
        server_time = await client.get_server_time()
        server_datetime = datetime.fromtimestamp(server_time['serverTime'] / 1000)
        logger.info(f"Horário do servidor Binance: {server_datetime}")
    except Exception as e:
        logger.error(f"Erro ao obter horário do servidor: {e}")
    
    # Obter informações da conta
    try:
        account_info = await client.get_account()
        logger.info(f"Informações da conta obtidas com sucesso")
        logger.info(f"Status da conta: Pode operar: {account_info.get('canTrade', False)}")
        
        # Mostrar saldos não-zero
        balances = [b for b in account_info.get('balances', []) if float(b['free']) > 0 or float(b['locked']) > 0]
        logger.info(f"Saldos disponíveis:")
        for balance in balances:
            logger.info(f"  {balance['asset']}: Livre = {balance['free']}, Bloqueado = {balance['locked']}")
    except Exception as e:
        logger.error(f"Erro ao obter informações da conta: {e}")
    
    # Obter dados de mercado para BTCUSDT
    try:
        ticker = await client.get_symbol_ticker(symbol="BTCUSDT")
        logger.info(f"Preço atual do BTCUSDT: {ticker['price']}")
    except Exception as e:
        logger.error(f"Erro ao obter preço do BTCUSDT: {e}")
    
    # Obter profundidade do livro de ordens (orderbook)
    try:
        depth = await client.get_order_book(symbol='BTCUSDT', limit=5)
        logger.info(f"Profundidade do livro de ordens BTCUSDT (5 níveis):")
        logger.info(f"  Melhores ofertas de compra:")
        for bid in depth['bids'][:3]:
            logger.info(f"    Preço: {bid[0]}, Quantidade: {bid[1]}")
        logger.info(f"  Melhores ofertas de venda:")
        for ask in depth['asks'][:3]:
            logger.info(f"    Preço: {ask[0]}, Quantidade: {ask[1]}")
    except Exception as e:
        logger.error(f"Erro ao obter profundidade do livro de ordens: {e}")
    
    # Obter klines (velas)
    try:
        klines = await client.get_klines(symbol='BTCUSDT', interval=Client.KLINE_INTERVAL_1HOUR, limit=5)
        logger.info(f"Últimas 5 velas de 1 hora para BTCUSDT:")
        for i, kline in enumerate(klines):
            open_time = datetime.fromtimestamp(kline[0] / 1000)
            open_price = kline[1]
            high_price = kline[2]
            low_price = kline[3]
            close_price = kline[4]
            volume = kline[5]
            logger.info(f"  Vela {i+1}: Abertura: {open_time}, Preço: O={open_price}, H={high_price}, L={low_price}, C={close_price}, Vol={volume}")
    except Exception as e:
        logger.error(f"Erro ao obter klines: {e}")
    
    # Simular fluxo de envio de ordem (sem executar)
    logger.info("Simulando fluxo de envio de ordem (sem executar ordem real)")
    
    # Verificar informações do símbolo para obter regras de negociação
    try:
        exchange_info = await client.get_exchange_info()
        symbol_info = None
        for s in exchange_info['symbols']:
            if s['symbol'] == 'BTCUSDT':
                symbol_info = s
                break
        
        if symbol_info:
            logger.info(f"Informações do símbolo BTCUSDT:")
            logger.info(f"  Status: {symbol_info['status']}")
            logger.info(f"  Ativo base: {symbol_info['baseAsset']}")
            logger.info(f"  Ativo de cotação: {symbol_info['quoteAsset']}")
            logger.info(f"  Tipos de ordem permitidos: {symbol_info['orderTypes']}")
            
            # Obter filtros (regras de negociação)
            price_filter = None
            lot_size_filter = None
            for f in symbol_info['filters']:
                if f['filterType'] == 'PRICE_FILTER':
                    price_filter = f
                elif f['filterType'] == 'LOT_SIZE':
                    lot_size_filter = f
            
            if price_filter:
                logger.info(f"  Filtro de preço:")
                logger.info(f"    Preço mínimo: {price_filter['minPrice']}")
                logger.info(f"    Preço máximo: {price_filter['maxPrice']}")
                logger.info(f"    Tick size: {price_filter['tickSize']}")
            
            if lot_size_filter:
                logger.info(f"  Filtro de tamanho de lote:")
                logger.info(f"    Quantidade mínima: {lot_size_filter['minQty']}")
                logger.info(f"    Quantidade máxima: {lot_size_filter['maxQty']}")
                logger.info(f"    Step size: {lot_size_filter['stepSize']}")
        else:
            logger.warning("Informações do símbolo BTCUSDT não encontradas")
    except Exception as e:
        logger.error(f"Erro ao obter informações do símbolo: {e}")
    
    # Fechar cliente
    await client.close_connection()
    logger.info("Conexão com a API Binance fechada")
    
    logger.info("Teste de conexão com a API Binance concluído com sucesso")
    return True

async def main():
    """Função principal."""
    success = await test_binance_connection()
    if success:
        logger.info("✅ Conexão com a API Binance está funcionando corretamente")
        logger.info("✅ O sistema está pronto para executar ordens")
    else:
        logger.critical("❌ Falha na conexão com a API Binance")
        logger.critical("❌ Verifique as credenciais e a conexão com a internet")

if __name__ == "__main__":
    asyncio.run(main())
