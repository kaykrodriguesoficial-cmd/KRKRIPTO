#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Testes para validar as correções implementadas nos módulos críticos.
Este script testa as correções feitas em config_loader e env_loader
para garantir que os erros reportados não ocorram mais.
"""

import os
import sys
import unittest
import logging
from unittest.mock import patch, MagicMock

# Configurar path para importar módulos do projeto
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Configurar logging básico para teste
logging.basicConfig(level=logging.INFO)

class TestCorrecoes(unittest.TestCase):
    """Testes para validar as correções implementadas."""
    
    def setUp(self):
        """Configuração inicial para os testes."""
        # Limpar variáveis de ambiente que podem interferir nos testes
        for env_var in ['KR_BINANCE_API_KEY', 'binance_api_key', 'KR_TESTNET', 'testnet']:
            if env_var in os.environ:
                del os.environ[env_var]
    
    def test_config_loader_tipo_caminho(self):
        """Testa se config_loader trata corretamente o tipo do caminho."""
        from src.core.config_loader_v2_1 import carregar_config
        
        # Teste com caminho válido
        config = carregar_config("caminho/inexistente.json")
        self.assertEqual(config, {}, "Deve retornar dicionário vazio para arquivo inexistente")
        
        # Teste com caminho inválido (dict)
        config = carregar_config({"caminho": "invalido"})
        self.assertEqual(config, {}, "Deve tratar caminho inválido (dict) e retornar dicionário vazio")
    
    def test_env_loader_parametro_default(self):
        """Testa se obter_credencial aceita e usa o parâmetro default."""
        from src.core.env_loader_v2_1 import obter_credencial
        
        # Teste com parâmetro default
        valor = obter_credencial("credencial_inexistente", default="valor_padrao")
        self.assertEqual(valor, "valor_padrao", "Deve retornar o valor default para credencial inexistente")
        
        # Teste com config e default
        config = {"chave_existente": "valor_config"}
        valor = obter_credencial("chave_existente", config, default="valor_padrao")
        self.assertEqual(valor, "valor_config", "Deve priorizar valor do config sobre default")
        
        valor = obter_credencial("chave_inexistente", config, default="valor_padrao")
        self.assertEqual(valor, "valor_padrao", "Deve usar default quando chave não existe no config")
    
    def test_integracao_config_env_loader(self):
        """Testa a integração entre config_loader e env_loader."""
        from src.core.config_loader_v2_1 import carregar_config
        from src.core.env_loader_v2_1 import obter_credencial
        
        # Simular variável de ambiente
        os.environ["KR_BINANCE_API_KEY"] = "chave_teste"
        
        # Criar config mock
        config = {"binance_api_key": "chave_config", "outra_chave": "outro_valor"}
        
        # Testar obtenção de credencial
        valor = obter_credencial("binance_api_key", config, default="valor_padrao")
        self.assertEqual(valor, "chave_teste", "Deve priorizar variável de ambiente")
        
        valor = obter_credencial("outra_chave", config, default="valor_padrao")
        self.assertEqual(valor, "outro_valor", "Deve usar valor do config quando não há variável de ambiente")
        
        valor = obter_credencial("chave_inexistente", config, default="valor_padrao")
        self.assertEqual(valor, "valor_padrao", "Deve usar default quando não há nem variável nem config")

if __name__ == "__main__":
    unittest.main()
