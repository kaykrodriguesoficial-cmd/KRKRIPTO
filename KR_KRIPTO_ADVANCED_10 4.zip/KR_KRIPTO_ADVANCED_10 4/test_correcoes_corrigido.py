#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Testes para validar as correções implementadas nos módulos críticos.
Este script testa as correções feitas em config_loader e env_loader
para garantir que os erros reportados não ocorram mais.

Versão corrigida para funcionar com os nomes de arquivo que usam ponto (.) em vez de sublinhado (_).
"""

import os
import sys
import unittest
import logging
from unittest.mock import patch, MagicMock
import importlib.util

# Configurar path para importar módulos do projeto
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Configurar logging básico para teste
logging.basicConfig(level=logging.INFO)

# Função auxiliar para importar módulos com ponto no nome
def import_module_from_file(module_name, file_path):
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

class TestCorrecoes(unittest.TestCase):
    """Testes para validar as correções implementadas."""
    
    def setUp(self):
        """Configuração inicial para os testes."""
        # Limpar variáveis de ambiente que podem interferir nos testes
        for env_var in ['KR_BINANCE_API_KEY', 'binance_api_key', 'KR_TESTNET', 'testnet']:
            if env_var in os.environ:
                del os.environ[env_var]
        
        # Importar os módulos corrigidos
        self.config_loader_path = os.path.join(os.path.dirname(__file__), '..', 'src', 'core', 'config_loader_v2.1.py')
        self.env_loader_path = os.path.join(os.path.dirname(__file__), '..', 'src', 'core', 'env_loader_v2.1.py')
        
        # Verificar se os arquivos existem
        if not os.path.exists(self.config_loader_path):
            self.skipTest(f"Arquivo {self.config_loader_path} não encontrado")
        if not os.path.exists(self.env_loader_path):
            self.skipTest(f"Arquivo {self.env_loader_path} não encontrado")
        
        # Importar os módulos
        self.config_loader = import_module_from_file('config_loader_v2_1', self.config_loader_path)
        self.env_loader = import_module_from_file('env_loader_v2_1', self.env_loader_path)
    
    def test_config_loader_tipo_caminho(self):
        """Testa se config_loader trata corretamente o tipo do caminho."""
        # Usar a função importada do módulo
        carregar_config = self.config_loader.carregar_config
        
        # Teste com caminho válido
        config = carregar_config("caminho/inexistente.json")
        self.assertEqual(config, {}, "Deve retornar dicionário vazio para arquivo inexistente")
        
        # Teste com caminho inválido (dict)
        config = carregar_config({"caminho": "invalido"})
        self.assertEqual(config, {}, "Deve tratar caminho inválido (dict) e retornar dicionário vazio")
    
    def test_env_loader_parametro_default(self):
        """Testa se obter_credencial aceita e usa o parâmetro default."""
        # Usar a função importada do módulo
        obter_credencial = self.env_loader.obter_credencial
        
        # Teste com parâmetro default
        valor = obter_credencial("credencial_inexistente", default="valor_padrao")
        self.assertEqual(valor, "valor_padrao", "Deve retornar o valor default para credencial inexistente")
        
        # Teste com config e default
        config = {"chave_existente": "valor_config"}
        valor = obter_credencial("chave_existente", config, default="valor_padrao")
        self.assertEqual(valor, "valor_config", "Deve priorizar valor do config sobre default")
        
        valor = obter_credencial("chave_inexistente", config, default="valor_padrao")
        self.assertEqual(valor, "valor_padrao", "Deve usar default quando chave não existe no config")
    
    def test_integracao_config_env_loader(self):
        """Testa a integração entre config_loader e env_loader."""
        # Usar as funções importadas dos módulos
        carregar_config = self.config_loader.carregar_config
        obter_credencial = self.env_loader.obter_credencial
        
        # Simular variável de ambiente
        os.environ["KR_BINANCE_API_KEY"] = "chave_teste"
        
        # Criar config mock
        config = {"binance_api_key": "chave_config", "outra_chave": "outro_valor"}
        
        # Testar obtenção de credencial
        valor = obter_credencial("binance_api_key", config, default="valor_padrao")
        self.assertEqual(valor, "chave_teste", "Deve priorizar variável de ambiente")
        
        valor = obter_credencial("outra_chave", config, default="valor_padrao")
        self.assertEqual(valor, "outro_valor", "Deve usar valor do config quando não há variável de ambiente")
        
        valor = obter_credencial("chave_inexistente", config, default="valor_padrao")
        self.assertEqual(valor, "valor_padrao", "Deve usar default quando não há nem variável nem config")

if __name__ == "__main__":
    unittest.main()
