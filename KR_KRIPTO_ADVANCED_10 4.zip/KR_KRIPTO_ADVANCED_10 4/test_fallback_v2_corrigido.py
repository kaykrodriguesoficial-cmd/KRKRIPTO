#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Testes de integração para o fallback_v2_corrigido.py
"""

import unittest
import os
import sys
import logging
import time
from datetime import datetime, timedelta
from unittest.mock import patch, MagicMock

# Configurar logging para testes
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("test_fallback_v2_corrigido")

# Adicionar diretórios ao path para importar os módulos
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class TestFallbackV2Corrigido(unittest.TestCase):
    """Testes para o fallback_v2_corrigido.py"""

    def setUp(self):
        """Configuração inicial para os testes"""
        # Importar o módulo fallback_v2_corrigido
        try:
            sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "auditoria"))
            from fallback_v2_corrigido import GerenciadorFallback
            self.GerenciadorFallback = GerenciadorFallback
            logger.info("✅ Módulo fallback_v2_corrigido importado com sucesso")
        except ImportError as e:
            logger.error(f"❌ Erro ao importar fallback_v2_corrigido: {e}")
            self.fail(f"Erro ao importar fallback_v2_corrigido: {e}")
        
        # Configuração básica para testes
        self.config = {
            "max_falhas": 3,
            "janela_falhas": 60,
            "tempo_reset": 300,
            "limiar_alerta_modelo": 0.3,
            "limiar_critico_modelo": 0.5,
            "memoria_critica": 95.0,
            "cpu_critica": 90.0,
            "periodo_verificacao_rollback": 3600  # 1 hora para testes
        }
        
        # Mock do operador
        self.mock_operador = MagicMock()
        
        # Instanciar o GerenciadorFallback
        self.fallback = self.GerenciadorFallback(config=self.config, operador=self.mock_operador)

    def test_registrar_falha_com_detalhes(self):
        """Testa se o método registrar_falha aceita o parâmetro detalhes"""
        try:
            # Registrar uma falha com detalhes
            resultado = self.fallback.registrar_falha(
                componente="test_component",
                erro=Exception("Erro de teste"),
                detalhes="Detalhes do erro para teste"
            )
            
            # Verificar se o registro foi bem-sucedido
            self.assertIsNotNone(resultado)
            self.assertEqual(resultado["componente"], "test_component")
            self.assertEqual(resultado["falhas_recentes"], 1)
            self.assertFalse(resultado["circuit_breaker"])
            
            # Verificar se os detalhes foram armazenados
            self.assertEqual(self.fallback.falhas["test_component"][0]["detalhes"], "Detalhes do erro para teste")
            
            logger.info("✅ Método registrar_falha aceita o parâmetro detalhes")
        except TypeError as e:
            logger.error(f"❌ Erro de tipo ao chamar registrar_falha com detalhes: {e}")
            self.fail(f"Erro de tipo ao chamar registrar_falha com detalhes: {e}")
        except Exception as e:
            logger.error(f"❌ Erro ao testar registrar_falha: {e}")
            self.fail(f"Erro ao testar registrar_falha: {e}")

    def test_registrar_falha_especifica_com_detalhes(self):
        """Testa se o método registrar_falha_especifica aceita o parâmetro detalhes"""
        try:
            # Registrar uma falha específica com detalhes
            resultado = self.fallback.registrar_falha_especifica(
                componente="test_component",
                erro="Erro específico de teste",
                detalhes="Detalhes específicos para teste"
            )
            
            # Verificar se o registro foi bem-sucedido
            self.assertIsNotNone(resultado)
            self.assertEqual(resultado["componente"], "test_component")
            self.assertEqual(resultado["falhas_recentes"], 1)
            self.assertFalse(resultado["circuit_breaker"])
            
            # Verificar se os detalhes foram armazenados
            self.assertEqual(self.fallback.falhas["test_component"][0]["detalhes"], "Detalhes específicos para teste")
            
            logger.info("✅ Método registrar_falha_especifica aceita o parâmetro detalhes")
        except TypeError as e:
            logger.error(f"❌ Erro de tipo ao chamar registrar_falha_especifica com detalhes: {e}")
            self.fail(f"Erro de tipo ao chamar registrar_falha_especifica com detalhes: {e}")
        except Exception as e:
            logger.error(f"❌ Erro ao testar registrar_falha_especifica: {e}")
            self.fail(f"Erro ao testar registrar_falha_especifica: {e}")

    def test_verificar_necessidade_de_rollback_existe(self):
        """Testa se o método verificar_necessidade_de_rollback existe"""
        try:
            # Verificar se o método existe
            self.assertTrue(hasattr(self.fallback, 'verificar_necessidade_de_rollback'))
            
            # Verificar se o método pode ser chamado
            resultado = self.fallback.verificar_necessidade_de_rollback("test_component")
            
            # Verificar se o resultado é um booleano
            self.assertIsInstance(resultado, bool)
            
            logger.info("✅ Método verificar_necessidade_de_rollback existe e retorna um booleano")
        except AttributeError as e:
            logger.error(f"❌ Método verificar_necessidade_de_rollback não existe: {e}")
            self.fail(f"Método verificar_necessidade_de_rollback não existe: {e}")
        except Exception as e:
            logger.error(f"❌ Erro ao testar verificar_necessidade_de_rollback: {e}")
            self.fail(f"Erro ao testar verificar_necessidade_de_rollback: {e}")

    def test_verificar_necessidade_de_rollback_logica(self):
        """Testa a lógica do método verificar_necessidade_de_rollback"""
        try:
            # Componente sem falhas não deve precisar de rollback
            self.assertFalse(self.fallback.verificar_necessidade_de_rollback("componente_sem_falhas"))
            
            # Simular muitas falhas para um componente
            componente = "componente_com_muitas_falhas"
            
            # Registrar falhas suficientes para ativar o circuit breaker
            for i in range(self.config["max_falhas"]):
                self.fallback.registrar_falha(
                    componente=componente,
                    erro=Exception(f"Erro {i}"),
                    detalhes=f"Detalhes do erro {i}"
                )
            
            # Verificar se o circuit breaker foi ativado
            self.assertTrue(componente in self.fallback.circuit_breakers)
            
            # Simular que o circuit breaker foi ativado há mais de 10 minutos
            self.fallback.circuit_breakers[componente]["ativado_em"] = datetime.now() - timedelta(minutes=15)
            
            # Registrar mais falhas para ultrapassar o limiar de rollback
            for i in range(self.config["max_falhas"] * 2):
                self.fallback.registrar_falha(
                    componente=componente,
                    erro=Exception(f"Erro adicional {i}"),
                    detalhes=f"Detalhes do erro adicional {i}"
                )
            
            # Agora o componente deve precisar de rollback
            self.assertTrue(self.fallback.verificar_necessidade_de_rollback(componente))
            
            logger.info("✅ Lógica do método verificar_necessidade_de_rollback funciona corretamente")
        except Exception as e:
            logger.error(f"❌ Erro ao testar lógica de verificar_necessidade_de_rollback: {e}")
            self.fail(f"Erro ao testar lógica de verificar_necessidade_de_rollback: {e}")

    def test_integracao_com_main(self):
        """Testa a integração com o main.py simulando chamadas esperadas"""
        try:
            # Simular chamadas que o main.py faria
            
            # 1. Registrar uma falha com detalhes
            resultado_falha = self.fallback.registrar_falha(
                componente="operador",
                erro=Exception("Erro de conexão"),
                detalhes="Falha ao conectar com a API Binance"
            )
            self.assertIsNotNone(resultado_falha)
            
            # 2. Verificar necessidade de rollback
            resultado_rollback = self.fallback.verificar_necessidade_de_rollback("operador")
            self.assertIsInstance(resultado_rollback, bool)
            
            logger.info("✅ Integração com main.py simulada com sucesso")
        except Exception as e:
            logger.error(f"❌ Erro ao testar integração com main.py: {e}")
            self.fail(f"Erro ao testar integração com main.py: {e}")

    def test_integracao_com_operador(self):
        """Testa a integração com o operador"""
        try:
            # Verificar se o operador foi armazenado corretamente
            self.assertEqual(self.fallback.operador_binance, self.mock_operador)
            
            # Simular uso do operador em um método do fallback
            # (Isso depende da implementação específica, aqui apenas verificamos se não há erro)
            self.assertIsNotNone(self.fallback.operador_binance)
            
            logger.info("✅ Integração com operador funciona corretamente")
        except Exception as e:
            logger.error(f"❌ Erro ao testar integração com operador: {e}")
            self.fail(f"Erro ao testar integração com operador: {e}")

    def test_compatibilidade_com_versao_anterior(self):
        """Testa a compatibilidade com a versão anterior do GerenciadorFallback"""
        try:
            # Verificar se os métodos da versão anterior ainda existem
            self.assertTrue(hasattr(self.fallback, 'registrar_falha'))
            self.assertTrue(hasattr(self.fallback, 'registrar_falha_especifica'))
            self.assertTrue(hasattr(self.fallback, 'verificar_circuit_breaker'))
            self.assertTrue(hasattr(self.fallback, 'circuit_breaker_sincrono'))
            self.assertTrue(hasattr(self.fallback, 'circuit_breaker_assincrono'))
            self.assertTrue(hasattr(self.fallback, 'obter_modelo_fallback'))
            self.assertTrue(hasattr(self.fallback, 'monitorar_modelo'))
            self.assertTrue(hasattr(self.fallback, 'registrar_watchdog'))
            self.assertTrue(hasattr(self.fallback, 'verificar_watchdogs'))
            self.assertTrue(hasattr(self.fallback, 'verificar_recursos_sistema'))
            self.assertTrue(hasattr(self.fallback, 'obter_status'))
            
            # Verificar se os métodos da versão anterior ainda funcionam
            self.fallback.registrar_falha_especifica("test_component", "Erro de teste")
            self.assertFalse(self.fallback.verificar_circuit_breaker("test_component"))
            self.assertIsNotNone(self.fallback.obter_modelo_fallback())
            self.assertIsNotNone(self.fallback.obter_status())
            
            logger.info("✅ Compatibilidade com versão anterior mantida")
        except Exception as e:
            logger.error(f"❌ Erro ao testar compatibilidade com versão anterior: {e}")
            self.fail(f"Erro ao testar compatibilidade com versão anterior: {e}")

if __name__ == "__main__":
    unittest.main()
