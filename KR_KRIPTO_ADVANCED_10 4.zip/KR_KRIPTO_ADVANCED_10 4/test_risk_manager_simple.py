#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Teste simplificado do RiskManager para Mac M1
"""

import sys
import os
import platform
import logging
import pandas as pd
import numpy as np

# Configuração de logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("test_risk_manager_simple")

# Adiciona o diretório raiz ao path
sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))

# Tenta importar o RiskManager
try:
    from src.risk_management.risk_manager import RiskManager, is_mac_m1
    logger.info("RiskManager importado com sucesso")
    
    # Verifica o ambiente
    mac_m1 = is_mac_m1()
    logger.info(f"Ambiente Mac M1: {mac_m1}")
    logger.info(f"Sistema: {platform.system()} {platform.machine()}")
    
    # Cria uma instância do RiskManager
    risk_manager = RiskManager()
    logger.info("RiskManager inicializado com sucesso")
    
    # Testa o cálculo de volatilidade
    dates = pd.date_range(end="2023-01-31", periods=100, freq="1h")
    price = 100 * (1 + np.random.normal(0, 0.02, 100).cumsum())
    df_test = pd.DataFrame({"Close": price}, index=dates)
    
    volatilidade = risk_manager.calcular_volatilidade(df_test)
    logger.info(f"Volatilidade calculada: {volatilidade}")
    
    # Testa o cálculo de SL/TP
    data = {
        'High': np.random.uniform(101, 105, 100),
        'Low': np.random.uniform(95, 99, 100),
        'Close': np.random.uniform(99, 101, 100)
    }
    df_sl_tp = pd.DataFrame(data, index=dates)
    
    sl, tp = risk_manager.calcular_sl_tp_dinamico(df_sl_tp, 100.0, 'BUY')
    logger.info(f"SL/TP calculados: {sl}, {tp}")
    
    logger.info("Todos os testes passaram com sucesso!")
    
except Exception as e:
    logger.error(f"Erro ao testar RiskManager: {e}")
    sys.exit(1)

logger.info("Teste do RiskManager concluído com sucesso")

