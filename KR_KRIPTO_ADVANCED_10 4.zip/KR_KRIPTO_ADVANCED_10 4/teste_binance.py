import asyncio
from binance import AsyncClient

async def teste_conexao():
    try:
        # Inicializar cliente (usando variáveis de ambiente ou config)
        client = await AsyncClient.create()
        
        # Testar ping
        ping = await client.ping()
        print(f"Ping bem-sucedido: {ping}")
        
        # Testar status do servidor
        status = await client.get_system_status()
        print(f"Status do servidor: {status}")
        
        # Testar obtenção de preço
        ticker = await client.get_ticker(symbol='BTCUSDT')
        print(f"Preço atual do BTC: {ticker['lastPrice']}")
        
        # Testar saldo (requer API key com permissões)
        try:
            account = await client.get_account()
            print("Saldos:")
            for balance in account['balances']:
                if float(balance['free']) > 0 or float(balance['locked']) > 0:
                    print(f"  {balance['asset']}: {balance['free']} (livre) / {balance['locked']} (bloqueado)")
            print("Conexão com API autenticada funcionando corretamente!")
        except Exception as e:
            print(f"Erro ao obter saldo (problema de autenticação): {e}")
        
        # Fechar cliente
        await client.close_connection()
    except Exception as e:
        print(f"Erro na conexão com a Binance: {e}")

if __name__ == "__main__":
    asyncio.run(teste_conexao())


