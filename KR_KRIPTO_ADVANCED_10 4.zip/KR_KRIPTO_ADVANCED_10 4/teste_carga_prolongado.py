#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Teste de Carga Prolongado para KR_KRIPTO_ADVANCED_COPIA

Este script realiza um teste de carga prolongado para validar a estabilidade,
uso de recursos e performance do sistema KR_KRIPTO_ADVANCED_COPIA durante
operação contínua por um período estendido.

Autor: Manus
Data: 16/05/2025
"""

import os
import sys
import time
import json
import logging
import asyncio
import argparse
import psutil
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
from logging.handlers import TimedRotatingFileHandler

# Adicionar diretório raiz ao path para importações relativas
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '.')))

# Configurar logging
log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logs')
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, 'teste_carga_prolongado.log')

# Configurar logger com rotação diária
logger = logging.getLogger("teste_carga_prolongado")
if not logger.handlers:
    handler = TimedRotatingFileHandler(
        filename=log_file,
        when='midnight',
        interval=1,
        backupCount=30,
        encoding='utf-8'
    )
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    
    # Adicionar handler para console também
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    logger.setLevel(logging.INFO)

class TesteCargaProlongado:
    """Classe para teste de carga prolongado."""
    
    def __init__(self, config: dict):
        """Inicializa o teste de carga prolongado."""
        self.config = config or self._carregar_config_padrao()
        self.resultados = {
            "inicio": datetime.now().isoformat(),
            "status_geral": "pendente",
            "metricas_sistema": {
                "cpu": [],
                "memoria": [],
                "disco": [],
                "rede": []
            },
            "metricas_performance": {
                "latencia": [],
                "throughput": [],
                "erros": []
            },
            "eventos": []
        }
        
        # Criar diretório para gráficos
        self.graficos_dir = os.path.join(log_dir, 'graficos_prolongado')
        os.makedirs(self.graficos_dir, exist_ok=True)
        
        # Inicializar contadores
        self.total_processado = 0
        self.total_erros = 0
        self.ciclos_completos = 0
        
        logger.info(f"Teste de Carga Prolongado inicializado com configuração: {json.dumps(self.config, indent=2)}")
    
    def _carregar_config_padrao(self):
        """Carrega configuração padrão para o teste."""
        return {
            "duracao_total_minutos": 180,  # 3 horas
            "intervalo_coleta_segundos": 60,  # Coleta de métricas a cada 1 minuto
            "intervalo_snapshot_minutos": 30,  # Snapshot completo a cada 30 minutos
            "carga": {
                "threads": 5,
                "intervalo_ms": 200,
                "ciclos_por_minuto": 20
            },
            "ativos": ["BTCUSDT", "ETHUSDT", "BNBUSDT", "ADAUSDT", "XRPUSDT", "SOLUSDT", "DOGEUSDT", "DOTUSDT"],
            "limites": {
                "cpu_max": 80,  # porcentagem
                "memoria_max": 80,  # porcentagem
                "memoria_crescimento_max": 5,  # porcentagem de crescimento máximo por hora
                "latencia_max_ms": 500,
                "erros_max_percentual": 1  # porcentagem máxima de erros
            }
        }
    
    def _gerar_dados_simulados(self, ativo, tamanho=100):
        """Gera dados simulados para teste."""
        # Data inicial (30 dias atrás)
        data_inicial = datetime.now() - timedelta(days=30)
        
        # Gerar timestamps
        timestamps = [data_inicial + timedelta(minutes=i*15) for i in range(tamanho)]
        
        # Gerar preços com tendência e volatilidade aleatória
        preco_base = {
            "BTCUSDT": 50000,
            "ETHUSDT": 3000,
            "BNBUSDT": 500,
            "ADAUSDT": 1.5,
            "XRPUSDT": 0.8,
            "SOLUSDT": 120,
            "DOGEUSDT": 0.15,
            "DOTUSDT": 20
        }.get(ativo, 100)
        
        # Adicionar tendência e volatilidade
        np.random.seed(int(time.time() * 1000) % 10000)
        tendencia = np.random.choice([-1, 1]) * np.random.uniform(0.0001, 0.001)
        volatilidade = np.random.uniform(0.005, 0.02)
        
        precos = []
        preco_atual = preco_base
        for _ in range(tamanho):
            # Aplicar tendência e volatilidade
            mudanca_percentual = tendencia + np.random.normal(0, volatilidade)
            preco_atual *= (1 + mudanca_percentual)
            precos.append(preco_atual)
        
        # Gerar volumes
        volumes = np.random.uniform(preco_base * 10, preco_base * 1000, tamanho)
        
        # Criar DataFrame
        df = pd.DataFrame({
            'timestamp': timestamps,
            'open': precos,
            'high': [p * (1 + np.random.uniform(0, 0.01)) for p in precos],
            'low': [p * (1 - np.random.uniform(0, 0.01)) for p in precos],
            'close': [p * (1 + np.random.uniform(-0.005, 0.005)) for p in precos],
            'volume': volumes
        })
        
        return df
    
    def _monitorar_recursos(self, intervalo=1.0, evento_parada=None):
        """Monitora recursos do sistema em thread separada."""
        logger.info(f"Iniciando monitoramento de recursos com intervalo={intervalo}s")
        
        # Valores iniciais para cálculo de taxa de transferência de rede
        rede_stats_anterior = psutil.net_io_counters()
        tempo_anterior = time.time()
        
        while not evento_parada.is_set():
            try:
                # Coletar métricas
                cpu_percent = psutil.cpu_percent(interval=None)
                memoria_info = psutil.virtual_memory()
                memoria_percent = memoria_info.percent
                disco_percent = psutil.disk_usage('/').percent
                
                # Coletar estatísticas de rede (bytes enviados/recebidos)
                rede_stats = psutil.net_io_counters()
                tempo_atual = time.time()
                
                # Calcular taxa de transferência em bytes/segundo
                tempo_decorrido = tempo_atual - tempo_anterior
                if tempo_decorrido > 0:
                    bytes_enviados_taxa = (rede_stats.bytes_sent - rede_stats_anterior.bytes_sent) / tempo_decorrido
                    bytes_recebidos_taxa = (rede_stats.bytes_recv - rede_stats_anterior.bytes_recv) / tempo_decorrido
                else:
                    bytes_enviados_taxa = 0
                    bytes_recebidos_taxa = 0
                
                # Atualizar valores anteriores
                rede_stats_anterior = rede_stats
                tempo_anterior = tempo_atual
                
                # Armazenar métricas
                timestamp = datetime.now().isoformat()
                self.resultados["metricas_sistema"]["cpu"].append((timestamp, cpu_percent))
                self.resultados["metricas_sistema"]["memoria"].append((timestamp, memoria_percent))
                self.resultados["metricas_sistema"]["disco"].append((timestamp, disco_percent))
                self.resultados["metricas_sistema"]["rede"].append((timestamp, {
                    "bytes_enviados_taxa": bytes_enviados_taxa,
                    "bytes_recebidos_taxa": bytes_recebidos_taxa,
                    "bytes_enviados_total": rede_stats.bytes_sent,
                    "bytes_recebidos_total": rede_stats.bytes_recv
                }))
                
                # Verificar limites
                if cpu_percent > self.config["limites"]["cpu_max"]:
                    logger.warning(f"Uso de CPU acima do limite: {cpu_percent}% > {self.config['limites']['cpu_max']}%")
                    self.registrar_evento("alerta", f"Uso de CPU acima do limite: {cpu_percent}%")
                
                if memoria_percent > self.config["limites"]["memoria_max"]:
                    logger.warning(f"Uso de memória acima do limite: {memoria_percent}% > {self.config['limites']['memoria_max']}%")
                    self.registrar_evento("alerta", f"Uso de memória acima do limite: {memoria_percent}%")
                
                # Verificar crescimento de memória (a cada hora)
                if len(self.resultados["metricas_sistema"]["memoria"]) > 60:  # Após 1 hora (com intervalo de 60s)
                    memoria_inicial = self.resultados["metricas_sistema"]["memoria"][0][1]
                    memoria_atual = memoria_percent
                    crescimento_hora = memoria_atual - memoria_inicial
                    
                    if crescimento_hora > self.config["limites"]["memoria_crescimento_max"]:
                        logger.warning(f"Crescimento de memória acima do limite: {crescimento_hora}% > {self.config['limites']['memoria_crescimento_max']}%")
                        self.registrar_evento("alerta", f"Possível vazamento de memória detectado: crescimento de {crescimento_hora}% em 1 hora")
                
                # Aguardar próximo intervalo
                time.sleep(intervalo)
                
            except Exception as e:
                logger.error(f"Erro ao monitorar recursos: {str(e)}", exc_info=True)
                time.sleep(intervalo)
    
    def registrar_evento(self, tipo, mensagem):
        """Registra um evento durante o teste."""
        evento = {
            "timestamp": datetime.now().isoformat(),
            "tipo": tipo,
            "mensagem": mensagem
        }
        self.resultados["eventos"].append(evento)
    
    async def _simular_processamento(self, ativo):
        """Simula o processamento de dados para um ativo específico."""
        try:
            # Gerar dados simulados
            df = self._gerar_dados_simulados(ativo, tamanho=100)
            
            # Simular processamento com diferentes cargas
            inicio = time.time()
            
            # Aplicar indicadores técnicos (simulação de carga de processamento)
            # SMA - Simple Moving Average
            janela = 20
            df['sma'] = df['close'].rolling(window=janela).mean()
            
            # EMA - Exponential Moving Average
            df['ema'] = df['close'].ewm(span=janela, adjust=False).mean()
            
            # Bollinger Bands
            df['std'] = df['close'].rolling(window=janela).std()
            df['upper_band'] = df['sma'] + (df['std'] * 2)
            df['lower_band'] = df['sma'] - (df['std'] * 2)
            
            # RSI - Relative Strength Index
            delta = df['close'].diff()
            ganhos = delta.copy()
            perdas = delta.copy()
            ganhos[ganhos < 0] = 0
            perdas[perdas > 0] = 0
            avg_ganho = ganhos.rolling(window=14).mean()
            avg_perda = abs(perdas.rolling(window=14).mean())
            rs = avg_ganho / avg_perda
            df['rsi'] = 100 - (100 / (1 + rs))
            
            # MACD - Moving Average Convergence Divergence
            df['ema12'] = df['close'].ewm(span=12, adjust=False).mean()
            df['ema26'] = df['close'].ewm(span=26, adjust=False).mean()
            df['macd'] = df['ema12'] - df['ema26']
            df['signal'] = df['macd'].ewm(span=9, adjust=False).mean()
            
            # Simular atraso baseado no nível de carga
            await asyncio.sleep(self.config["carga"]["intervalo_ms"] / 1000.0)
            
            # Calcular tempo de processamento
            tempo_processamento = time.time() - inicio
            
            # Atualizar métricas
            self.total_processado += len(df)
            
            # Registrar latência
            timestamp = datetime.now().isoformat()
            self.resultados["metricas_performance"]["latencia"].append((timestamp, tempo_processamento * 1000))  # em ms
            
            # Verificar latência máxima
            if tempo_processamento * 1000 > self.config["limites"]["latencia_max_ms"]:
                logger.warning(f"Latência acima do limite para {ativo}: {tempo_processamento*1000:.2f}ms > {self.config['limites']['latencia_max_ms']}ms")
                self.registrar_evento("alerta", f"Latência acima do limite para {ativo}: {tempo_processamento*1000:.2f}ms")
            
            return {
                "ativo": ativo,
                "tempo_processamento": tempo_processamento,
                "registros_processados": len(df),
                "indicadores_calculados": 7,  # SMA, EMA, Bollinger (3), RSI, MACD (2)
                "status": "sucesso"
            }
            
        except Exception as e:
            logger.error(f"Erro ao processar {ativo}: {str(e)}", exc_info=True)
            self.total_erros += 1
            
            # Registrar erro
            timestamp = datetime.now().isoformat()
            self.resultados["metricas_performance"]["erros"].append((timestamp, 1))
            
            return {
                "ativo": ativo,
                "tempo_processamento": 0,
                "registros_processados": 0,
                "indicadores_calculados": 0,
                "status": "erro",
                "erro": str(e)
            }
    
    async def _executar_ciclo_processamento(self):
        """Executa um ciclo de processamento para todos os ativos."""
        tarefas = []
        
        # Criar tarefas para cada ativo
        for _ in range(self.config["carga"]["threads"]):
            # Selecionar ativo aleatório
            ativo = np.random.choice(self.config["ativos"])
            # Criar tarefa de processamento
            tarefa = asyncio.create_task(self._simular_processamento(ativo))
            tarefas.append(tarefa)
        
        # Aguardar conclusão de todas as tarefas
        resultados = await asyncio.gather(*tarefas, return_exceptions=True)
        
        # Processar resultados
        sucessos = [r for r in resultados if isinstance(r, dict) and r.get('status') == 'sucesso']
        erros = [r for r in resultados if isinstance(r, Exception) or 
                (isinstance(r, dict) and r.get('status') != 'sucesso')]
        
        # Registrar throughput
        if sucessos:
            total_processado_ciclo = sum(r['registros_processados'] for r in sucessos)
            timestamp = datetime.now().isoformat()
            self.resultados["metricas_performance"]["throughput"].append((timestamp, total_processado_ciclo))
        
        # Incrementar contador de ciclos
        self.ciclos_completos += 1
        
        # Registrar progresso a cada 10 ciclos
        if self.ciclos_completos % 10 == 0:
            logger.info(f"Ciclos completos: {self.ciclos_completos}, "
                       f"Total processado: {self.total_processado}, "
                       f"Erros: {self.total_erros}")
        
        return len(sucessos), len(erros)
    
    async def _criar_snapshot(self):
        """Cria um snapshot completo do estado atual do sistema."""
        logger.info("Criando snapshot do sistema...")
        
        try:
            # Calcular métricas agregadas
            cpu_atual = self.resultados["metricas_sistema"]["cpu"][-1][1] if self.resultados["metricas_sistema"]["cpu"] else 0
            memoria_atual = self.resultados["metricas_sistema"]["memoria"][-1][1] if self.resultados["metricas_sistema"]["memoria"] else 0
            
            # Calcular médias de CPU e memória (últimos 10 minutos)
            amostras_recentes = min(10, len(self.resultados["metricas_sistema"]["cpu"]))
            cpu_media = sum(v for _, v in self.resultados["metricas_sistema"]["cpu"][-amostras_recentes:]) / amostras_recentes if amostras_recentes > 0 else 0
            memoria_media = sum(v for _, v in self.resultados["metricas_sistema"]["memoria"][-amostras_recentes:]) / amostras_recentes if amostras_recentes > 0 else 0
            
            # Calcular latência média (últimos 10 minutos)
            amostras_latencia = min(10 * self.config["carga"]["ciclos_por_minuto"], len(self.resultados["metricas_performance"]["latencia"]))
            latencia_media = sum(v for _, v in self.resultados["metricas_performance"]["latencia"][-amostras_latencia:]) / amostras_latencia if amostras_latencia > 0 else 0
            
            # Calcular throughput médio (últimos 10 minutos)
            amostras_throughput = min(10, len(self.resultados["metricas_performance"]["throughput"]))
            throughput_medio = sum(v for _, v in self.resultados["metricas_performance"]["throughput"][-amostras_throughput:]) / amostras_throughput if amostras_throughput > 0 else 0
            
            # Calcular taxa de erro
            taxa_erro = (self.total_erros / max(1, self.total_processado)) * 100
            
            # Criar snapshot
            snapshot = {
                "timestamp": datetime.now().isoformat(),
                "duracao_minutos": (datetime.now() - datetime.fromisoformat(self.resultados["inicio"])).total_seconds() / 60,
                "ciclos_completos": self.ciclos_completos,
                "total_processado": self.total_processado,
                "total_erros": self.total_erros,
                "taxa_erro_percentual": taxa_erro,
                "cpu": {
                    "atual": cpu_atual,
                    "media_10min": cpu_media
                },
                "memoria": {
                    "atual": memoria_atual,
                    "media_10min": memoria_media
                },
                "performance": {
                    "latencia_media_ms": latencia_media,
                    "throughput_medio": throughput_medio
                },
                "alertas": [
                    e for e in self.resultados["eventos"] 
                    if e["tipo"] == "alerta" and 
                    (datetime.now() - datetime.fromisoformat(e["timestamp"])).total_seconds() < 600  # Alertas dos últimos 10 minutos
                ]
            }
            
            # Salvar snapshot
            snapshot_file = os.path.join(log_dir, f'snapshot_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json')
            with open(snapshot_file, 'w') as f:
                json.dump(snapshot, f, indent=2)
            
            logger.info(f"Snapshot criado e salvo em {snapshot_file}")
            
            # Gerar gráficos do snapshot
            self._gerar_graficos_snapshot(snapshot)
            
            return snapshot
            
        except Exception as e:
            logger.error(f"Erro ao criar snapshot: {str(e)}", exc_info=True)
            self.registrar_evento("erro", f"Falha ao criar snapshot: {str(e)}")
            return None
    
    def _gerar_graficos_snapshot(self, snapshot):
        """Gera gráficos para o snapshot atual."""
        try:
            timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            # 1. Gráfico de uso de CPU e memória ao longo do tempo
            plt.figure(figsize=(12, 6))
            
            # Extrair dados para o gráfico
            timestamps_cpu = [datetime.fromisoformat(t) for t, _ in self.resultados["metricas_sistema"]["cpu"]]
            valores_cpu = [v for _, v in self.resultados["metricas_sistema"]["cpu"]]
            
            timestamps_memoria = [datetime.fromisoformat(t) for t, _ in self.resultados["metricas_sistema"]["memoria"]]
            valores_memoria = [v for _, v in self.resultados["metricas_sistema"]["memoria"]]
            
            # Plotar CPU
            plt.plot(timestamps_cpu, valores_cpu, 'b-', label='CPU (%)')
            plt.axhline(y=self.config["limites"]["cpu_max"], color='r', linestyle='--', label=f"Limite CPU ({self.config['limites']['cpu_max']}%)")
            
            # Plotar Memória
            plt.plot(timestamps_memoria, valores_memoria, 'g-', label='Memória (%)')
            plt.axhline(y=self.config["limites"]["memoria_max"], color='m', linestyle='--', label=f"Limite Memória ({self.config['limites']['memoria_max']}%)")
            
            plt.title('Uso de CPU e Memória Durante Teste Prolongado')
            plt.xlabel('Tempo')
            plt.ylabel('Uso (%)')
            plt.legend()
            plt.grid(True)
            plt.tight_layout()
            
            # Salvar gráfico
            caminho_grafico = os.path.join(self.graficos_dir, f'recursos_{timestamp_str}.png')
            plt.savefig(caminho_grafico)
            plt.close()
            
            # 2. Gráfico de latência ao longo do tempo
            plt.figure(figsize=(12, 6))
            
            # Extrair dados para o gráfico
            timestamps_latencia = [datetime.fromisoformat(t) for t, _ in self.resultados["metricas_performance"]["latencia"]]
            valores_latencia = [v for _, v in self.resultados["metricas_performance"]["latencia"]]
            
            # Plotar Latência
            plt.plot(timestamps_latencia, valores_latencia, 'r-', alpha=0.5)
            
            # Adicionar média móvel para suavizar
            window_size = min(20, len(valores_latencia))
            if window_size > 0:
                media_movel = pd.Series(valores_latencia).rolling(window=window_size).mean().tolist()
                plt.plot(timestamps_latencia, media_movel, 'b-', linewidth=2, label=f'Média Móvel ({window_size} amostras)')
            
            plt.axhline(y=self.config["limites"]["latencia_max_ms"], color='r', linestyle='--', label=f"Limite ({self.config['limites']['latencia_max_ms']}ms)")
            
            plt.title('Latência de Processamento Durante Teste Prolongado')
            plt.xlabel('Tempo')
            plt.ylabel('Latência (ms)')
            plt.legend()
            plt.grid(True)
            plt.tight_layout()
            
            # Salvar gráfico
            caminho_grafico = os.path.join(self.graficos_dir, f'latencia_{timestamp_str}.png')
            plt.savefig(caminho_grafico)
            plt.close()
            
            # 3. Gráfico de throughput ao longo do tempo
            plt.figure(figsize=(12, 6))
            
            # Extrair dados para o gráfico
            timestamps_throughput = [datetime.fromisoformat(t) for t, _ in self.resultados["metricas_performance"]["throughput"]]
            valores_throughput = [v for _, v in self.resultados["metricas_performance"]["throughput"]]
            
            # Plotar Throughput
            plt.plot(timestamps_throughput, valores_throughput, 'g-', alpha=0.5)
            
            # Adicionar média móvel para suavizar
            window_size = min(10, len(valores_throughput))
            if window_size > 0:
                media_movel = pd.Series(valores_throughput).rolling(window=window_size).mean().tolist()
                plt.plot(timestamps_throughput, media_movel, 'b-', linewidth=2, label=f'Média Móvel ({window_size} amostras)')
            
            plt.title('Throughput Durante Teste Prolongado')
            plt.xlabel('Tempo')
            plt.ylabel('Registros Processados')
            plt.legend()
            plt.grid(True)
            plt.tight_layout()
            
            # Salvar gráfico
            caminho_grafico = os.path.join(self.graficos_dir, f'throughput_{timestamp_str}.png')
            plt.savefig(caminho_grafico)
            plt.close()
            
            logger.info(f"Gráficos do snapshot gerados com sucesso no diretório: {self.graficos_dir}")
            
        except Exception as e:
            logger.error(f"Erro ao gerar gráficos do snapshot: {str(e)}", exc_info=True)
    
    async def executar_teste(self):
        """Executa o teste de carga prolongado."""
        logger.info(f"Iniciando teste de carga prolongado com duração de {self.config['duracao_total_minutos']} minutos")
        
        inicio_teste = time.time()
        duracao_total_segundos = self.config["duracao_total_minutos"] * 60
        
        # Iniciar evento de parada para monitoramento
        evento_parada = asyncio.Event()
        
        # Iniciar thread de monitoramento
        with ThreadPoolExecutor(max_workers=1) as executor:
            future_monitor = executor.submit(
                self._monitorar_recursos, 
                intervalo=self.config["intervalo_coleta_segundos"], 
                evento_parada=evento_parada
            )
            
            try:
                # Registrar início do teste
                self.registrar_evento("info", f"Teste iniciado com duração planejada de {self.config['duracao_total_minutos']} minutos")
                
                # Executar ciclos de processamento até atingir a duração total
                tempo_ultimo_snapshot = time.time()
                
                while time.time() - inicio_teste < duracao_total_segundos:
                    # Executar ciclo de processamento
                    sucessos, erros = await self._executar_ciclo_processamento()
                    
                    # Verificar se é hora de criar um snapshot
                    if (time.time() - tempo_ultimo_snapshot) >= (self.config["intervalo_snapshot_minutos"] * 60):
                        await self._criar_snapshot()
                        tempo_ultimo_snapshot = time.time()
                    
                    # Calcular tempo para próximo ciclo
                    ciclos_por_segundo = self.config["carga"]["ciclos_por_minuto"] / 60
                    tempo_por_ciclo = 1 / ciclos_por_segundo
                    
                    # Aguardar até o próximo ciclo
                    await asyncio.sleep(tempo_por_ciclo)
                
                # Criar snapshot final
                snapshot_final = await self._criar_snapshot()
                
                # Calcular resultado geral
                taxa_erro = (self.total_erros / max(1, self.total_processado)) * 100
                
                if taxa_erro > self.config["limites"]["erros_max_percentual"]:
                    self.resultados["status_geral"] = "falha"
                    logger.error(f"Taxa de erro acima do limite: {taxa_erro:.2f}% > {self.config['limites']['erros_max_percentual']}%")
                    self.registrar_evento("erro", f"Taxa de erro acima do limite: {taxa_erro:.2f}%")
                else:
                    self.resultados["status_geral"] = "sucesso"
                
                self.resultados["fim"] = datetime.now().isoformat()
                self.resultados["duracao_segundos"] = time.time() - inicio_teste
                self.resultados["resumo"] = {
                    "ciclos_completos": self.ciclos_completos,
                    "total_processado": self.total_processado,
                    "total_erros": self.total_erros,
                    "taxa_erro_percentual": taxa_erro
                }
                
                # Gerar relatório final
                self._gerar_relatorio_final()
                
                logger.info(f"Teste concluído. Status geral: {self.resultados['status_geral']}")
                logger.info(f"Resumo: {self.ciclos_completos} ciclos, {self.total_processado} registros processados, {self.total_erros} erros ({taxa_erro:.2f}%)")
                
                return self.resultados
                
            except Exception as e:
                logger.error(f"Erro ao executar teste: {str(e)}", exc_info=True)
                self.resultados["status_geral"] = "erro"
                self.resultados["erro"] = str(e)
                self.registrar_evento("erro", f"Falha crítica no teste: {str(e)}")
                return self.resultados
            
            finally:
                # Parar monitoramento
                evento_parada.set()
                future_monitor.result()  # Aguardar conclusão do monitoramento
                
                # Salvar resultados
                self._salvar_resultados()
    
    def _salvar_resultados(self):
        """Salva os resultados em arquivo JSON."""
        try:
            # Salvar resultados detalhados
            resultados_file = os.path.join(log_dir, 'teste_carga_prolongado_resultados.json')
            with open(resultados_file, 'w') as f:
                json.dump(self.resultados, f, indent=2)
            
            # Salvar resumo em formato mais legível
            resumo = {
                'status_geral': self.resultados['status_geral'],
                'inicio': self.resultados['inicio'],
                'fim': self.resultados.get('fim', ''),
                'duracao_segundos': self.resultados.get('duracao_segundos', 0),
                'resumo': self.resultados.get('resumo', {}),
                'eventos_criticos': [
                    e for e in self.resultados["eventos"] 
                    if e["tipo"] in ["erro", "alerta"]
                ]
            }
            
            resumo_file = os.path.join(log_dir, 'teste_carga_prolongado_resumo.json')
            with open(resumo_file, 'w') as f:
                json.dump(resumo, f, indent=2)
            
            logger.info(f"Resultados salvos em {resultados_file}")
            logger.info(f"Resumo salvo em {resumo_file}")
            
            return resultados_file, resumo_file
            
        except Exception as e:
            logger.error(f"Erro ao salvar resultados: {str(e)}", exc_info=True)
            return None, None
    
    def _gerar_relatorio_final(self):
        """Gera relatório final com análise dos resultados."""
        try:
            logger.info("Gerando relatório final")
            
            # Caminho para o relatório
            relatorio_file = os.path.join(log_dir, 'relatorio_carga_prolongado.html')
            
            # Analisar tendência de memória
            memoria_valores = [v for _, v in self.resultados["metricas_sistema"]["memoria"]]
            if len(memoria_valores) > 10:
                memoria_inicial = sum(memoria_valores[:5]) / 5  # Média das primeiras 5 amostras
                memoria_final = sum(memoria_valores[-5:]) / 5   # Média das últimas 5 amostras
                crescimento_memoria = memoria_final - memoria_inicial
                tendencia_memoria = "crescente" if crescimento_memoria > 2 else "estável" if abs(crescimento_memoria) <= 2 else "decrescente"
                possivel_vazamento = crescimento_memoria > self.config["limites"]["memoria_crescimento_max"]
            else:
                tendencia_memoria = "indeterminada"
                crescimento_memoria = 0
                possivel_vazamento = False
            
            # Analisar estabilidade de latência
            latencia_valores = [v for _, v in self.resultados["metricas_performance"]["latencia"]]
            if len(latencia_valores) > 10:
                latencia_media = sum(latencia_valores) / len(latencia_valores)
                latencia_std = np.std(latencia_valores)
                coef_variacao = (latencia_std / latencia_media) * 100 if latencia_media > 0 else 0
                estabilidade_latencia = "estável" if coef_variacao < 20 else "moderada" if coef_variacao < 50 else "instável"
            else:
                estabilidade_latencia = "indeterminada"
                latencia_media = 0
                coef_variacao = 0
            
            # Calcular duração real do teste
            duracao_real = self.resultados.get("duracao_segundos", 0) / 60  # em minutos
            
            # Gerar conteúdo HTML
            html_content = f"""
            <!DOCTYPE html>
            <html lang="pt-BR">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Relatório de Teste de Carga Prolongado - KR_KRIPTO_ADVANCED_COPIA</title>
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 0; padding: 20px; color: #333; }}
                    h1, h2, h3 {{ color: #2c3e50; }}
                    .container {{ max-width: 1200px; margin: 0 auto; }}
                    .header {{ background-color: #34495e; color: white; padding: 20px; margin-bottom: 20px; }}
                    .summary {{ display: flex; justify-content: space-between; margin-bottom: 20px; }}
                    .summary-box {{ background-color: #f8f9fa; border-radius: 5px; padding: 15px; width: 30%; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
                    .success {{ background-color: #d4edda; color: #155724; }}
                    .warning {{ background-color: #fff3cd; color: #856404; }}
                    .danger {{ background-color: #f8d7da; color: #721c24; }}
                    table {{ width: 100%; border-collapse: collapse; margin-bottom: 20px; }}
                    th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }}
                    th {{ background-color: #f2f2f2; }}
                    tr:hover {{ background-color: #f5f5f5; }}
                    .graph-container {{ display: flex; flex-wrap: wrap; justify-content: space-between; margin-bottom: 20px; }}
                    .graph {{ width: 48%; margin-bottom: 20px; }}
                    .graph img {{ width: 100%; border: 1px solid #ddd; border-radius: 5px; }}
                    .footer {{ background-color: #f8f9fa; padding: 15px; text-align: center; margin-top: 30px; font-size: 0.9em; color: #6c757d; }}
                    .events {{ margin-bottom: 20px; }}
                    .event {{ padding: 10px; margin-bottom: 5px; border-radius: 5px; }}
                    .event-info {{ background-color: #d1ecf1; color: #0c5460; }}
                    .event-alerta {{ background-color: #fff3cd; color: #856404; }}
                    .event-erro {{ background-color: #f8d7da; color: #721c24; }}
                    @media (max-width: 768px) {{
                        .summary {{ flex-direction: column; }}
                        .summary-box {{ width: 100%; margin-bottom: 10px; }}
                        .graph {{ width: 100%; }}
                    }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>Relatório de Teste de Carga Prolongado</h1>
                        <h2>KR_KRIPTO_ADVANCED_COPIA</h2>
                        <p>Gerado em: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}</p>
                    </div>
                    
                    <h2>Resumo</h2>
                    <div class="summary">
                        <div class="summary-box {self.resultados['status_geral']}">
                            <h3>Status Geral</h3>
                            <p><strong>{self.resultados['status_geral'].upper()}</strong></p>
                        </div>
                        <div class="summary-box">
                            <h3>Duração</h3>
                            <p><strong>{duracao_real:.2f} minutos</strong></p>
                            <p>({self.ciclos_completos} ciclos completos)</p>
                        </div>
                        <div class="summary-box">
                            <h3>Processamento</h3>
                            <p>Total: <strong>{self.total_processado}</strong> registros</p>
                            <p>Erros: <strong>{self.total_erros}</strong> ({(self.total_erros / max(1, self.total_processado) * 100):.2f}%)</p>
                        </div>
                    </div>
                    
                    <h2>Análise de Estabilidade</h2>
                    <table>
                        <tr>
                            <th>Métrica</th>
                            <th>Valor</th>
                            <th>Status</th>
                        </tr>
                        <tr>
                            <td>Tendência de Memória</td>
                            <td>{tendencia_memoria.capitalize()} ({crescimento_memoria:.2f}% de variação)</td>
                            <td class="{'danger' if possivel_vazamento else 'success'}">{
                                "Possível vazamento detectado" if possivel_vazamento else "Normal"
                            }</td>
                        </tr>
                        <tr>
                            <td>Estabilidade de Latência</td>
                            <td>{estabilidade_latencia.capitalize()} (Coef. Variação: {coef_variacao:.2f}%)</td>
                            <td class="{'danger' if estabilidade_latencia == 'instável' else 'warning' if estabilidade_latencia == 'moderada' else 'success'}">{
                                "Requer atenção" if estabilidade_latencia == 'instável' else 
                                "Aceitável" if estabilidade_latencia == 'moderada' else 
                                "Excelente"
                            }</td>
                        </tr>
                        <tr>
                            <td>Taxa de Erro</td>
                            <td>{(self.total_erros / max(1, self.total_processado) * 100):.2f}%</td>
                            <td class="{'danger' if (self.total_erros / max(1, self.total_processado) * 100) > self.config['limites']['erros_max_percentual'] else 'success'}">{
                                "Acima do limite" if (self.total_erros / max(1, self.total_processado) * 100) > self.config['limites']['erros_max_percentual'] else "Dentro do limite"
                            }</td>
                        </tr>
                    </table>
                    
                    <h2>Gráficos</h2>
                    <div class="graph-container">
            """
            
            # Adicionar gráficos mais recentes
            graficos = [f for f in os.listdir(self.graficos_dir) if f.endswith('.png')]
            graficos.sort(reverse=True)  # Ordenar por mais recente
            
            for tipo in ['recursos', 'latencia', 'throughput']:
                graficos_tipo = [g for g in graficos if g.startswith(tipo)]
                if graficos_tipo:
                    grafico_mais_recente = graficos_tipo[0]
                    html_content += f"""
                        <div class="graph">
                            <h3>{tipo.capitalize()}</h3>
                            <img src="logs/graficos_prolongado/{grafico_mais_recente}" alt="Gráfico de {tipo}">
                        </div>
                    """
            
            # Adicionar eventos críticos
            html_content += """
                    </div>
                    
                    <h2>Eventos Críticos</h2>
                    <div class="events">
            """
            
            eventos_criticos = [e for e in self.resultados["eventos"] if e["tipo"] in ["erro", "alerta"]]
            if eventos_criticos:
                for evento in eventos_criticos:
                    html_content += f"""
                        <div class="event event-{evento['tipo']}">
                            <strong>{datetime.fromisoformat(evento['timestamp']).strftime('%H:%M:%S')}</strong>: {evento['mensagem']}
                        </div>
                    """
            else:
                html_content += """
                    <p>Nenhum evento crítico registrado durante o teste.</p>
                """
            
            # Adicionar conclusão baseada nos resultados
            html_content += """
                    </div>
                    
                    <h2>Conclusão</h2>
            """
            
            if self.resultados['status_geral'] == 'sucesso':
                html_content += """
                    <p>O sistema KR_KRIPTO_ADVANCED_COPIA demonstrou excelente estabilidade durante o teste de carga prolongado. 
                    Todos os indicadores de performance permaneceram dentro dos limites aceitáveis, e o sistema manteve-se 
                    estável durante toda a duração do teste. Não foram detectados vazamentos de memória significativos 
                    ou degradação de performance ao longo do tempo. O sistema está pronto para o ambiente de produção.</p>
                """
            elif self.resultados['status_geral'] == 'falha':
                html_content += """
                    <p>O sistema KR_KRIPTO_ADVANCED_COPIA apresentou problemas durante o teste de carga prolongado. 
                    Foram identificadas falhas que precisam ser corrigidas antes de prosseguir para o ambiente de produção. 
                    Recomenda-se revisar os eventos críticos registrados, corrigir os problemas identificados e repetir o teste.</p>
                """
            else:
                html_content += """
                    <p>O teste de carga prolongado foi interrompido devido a um erro crítico. 
                    Recomenda-se investigar a causa do erro, corrigir o problema e repetir o teste.</p>
                """
            
            # Finalizar HTML
            html_content += """
                    <div class="footer">
                        <p>Teste de Carga Prolongado - KR_KRIPTO_ADVANCED_COPIA</p>
                        <p>Gerado automaticamente pelo script teste_carga_prolongado.py</p>
                    </div>
                </div>
            </body>
            </html>
            """
            
            # Salvar arquivo HTML
            with open(relatorio_file, 'w') as f:
                f.write(html_content)
            
            logger.info(f"Relatório final gerado com sucesso: {relatorio_file}")
            return relatorio_file
            
        except Exception as e:
            logger.error(f"Erro ao gerar relatório final: {str(e)}", exc_info=True)
            return None

async def main():
    """Função principal para execução do teste."""
    parser = argparse.ArgumentParser(description='Teste de Carga Prolongado para KR_KRIPTO_ADVANCED_COPIA')
    parser.add_argument('--config', type=str, help='Caminho para arquivo de configuração JSON')
    parser.add_argument('--duracao', type=int, help='Duração do teste em minutos (sobrescreve configuração)')
    args = parser.parse_args()
    
    # Carregar configuração personalizada se fornecida
    config = None
    if args.config:
        try:
            with open(args.config, 'r') as f:
                config = json.load(f)
            logger.info(f"Configuração carregada de {args.config}")
        except Exception as e:
            logger.error(f"Erro ao carregar configuração: {str(e)}")
            return
    
    # Sobrescrever duração se fornecida
    if args.duracao and (config is None):
        config = {}
        config["duracao_total_minutos"] = args.duracao
        logger.info(f"Duração do teste definida para {args.duracao} minutos")
    elif args.duracao:
        config["duracao_total_minutos"] = args.duracao
        logger.info(f"Duração do teste definida para {args.duracao} minutos")
    
    # Iniciar teste
    teste_runner = TesteCargaProlongado(config={})
    resultados = await teste_runner.executar_teste()
    
    # Exibir resumo
    print("\n" + "="*50)
    print(f"RESUMO DO TESTE DE CARGA PROLONGADO")
    print("="*50)
    print(f"Status geral: {resultados['status_geral'].upper()}")
    print(f"Duração: {resultados.get('duracao_segundos', 0)/60:.2f} minutos")
    print(f"Ciclos completos: {teste_runner.ciclos_completos}")
    print(f"Total processado: {teste_runner.total_processado} registros")
    print(f"Erros: {teste_runner.total_erros} ({(teste_runner.total_erros / max(1, teste_runner.total_processado) * 100):.2f}%)")
    print("="*50)
    
    # Exibir eventos críticos
    eventos_criticos = [e for e in resultados["eventos"] if e["tipo"] in ["erro", "alerta"]]
    if eventos_criticos:
        print("\nEVENTOS CRÍTICOS:")
        for evento in eventos_criticos:
            print(f"[{datetime.fromisoformat(evento['timestamp']).strftime('%H:%M:%S')}] {evento['tipo'].upper()}: {evento['mensagem']}")
    else:
        print("\nNenhum evento crítico registrado durante o teste.")
    
    print("\n" + "="*50)
    
    return resultados

if __name__ == "__main__":
    asyncio.run(main())
