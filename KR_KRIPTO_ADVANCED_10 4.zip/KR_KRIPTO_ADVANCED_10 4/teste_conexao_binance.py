#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de teste de conexão com a Binance
Este script realiza uma bateria de testes para verificar se a conexão
com a API da Binance está funcionando corretamente.
"""

import asyncio
import logging
import sys
import time
import json
from datetime import datetime
import traceback

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("teste_conexao_binance.log"),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger("teste_conexao_binance")

# Importar bibliotecas necessárias
try:
    from binance.client import Client
    from binance.async_client import AsyncClient
    from binance.exceptions import BinanceAPIException
    from binance.websockets import BinanceSocketManager
    logger.info("Bibliotecas Binance importadas com sucesso")
except ImportError as e:
    logger.error(f"Erro ao importar bibliotecas Binance: {e}")
    logger.error("Execute 'pip install python-binance' para instalar as dependências")
    sys.exit(1)

# Carregar configuração
def carregar_config():
    try:
        with open("config.json", "r") as f:
            config = json.load(f)
        return config
    except Exception as e:
        logger.error(f"Erro ao carregar config.json: {e}")
        return None

# Teste de conexão REST
async def testar_conexao_rest(api_key, api_secret, testnet=True):
    logger.info(f"Iniciando teste de conexão REST (Testnet: {testnet})")
    
    try:
        # Inicializar cliente assíncrono
        client = await AsyncClient.create(api_key, api_secret, testnet=testnet)
        logger.info("Cliente assíncrono inicializado com sucesso")
        
        # Teste 1: Ping
        logger.info("Teste 1: Ping")
        start_time = time.time()
        ping_result = await client.ping()
        ping_time = time.time() - start_time
        logger.info(f"Ping bem-sucedido. Tempo: {ping_time:.4f}s")
        
        # Teste 2: Tempo do servidor
        logger.info("Teste 2: Tempo do servidor")
        server_time = await client.get_server_time()
        server_time_dt = datetime.fromtimestamp(server_time['serverTime'] / 1000)
        logger.info(f"Tempo do servidor: {server_time_dt}")
        
        # Teste 3: Informações da conta
        logger.info("Teste 3: Informações da conta")
        try:
            account_info = await client.get_account()
            logger.info(f"Informações da conta obtidas com sucesso")
            logger.info(f"Status da conta: Pode operar: {account_info['canTrade']}")
            logger.info(f"Comissões: Maker: {account_info['makerCommission']}, Taker: {account_info['takerCommission']}")
            
            # Mostrar saldos não-zero
            balances = [b for b in account_info['balances'] if float(b['free']) > 0 or float(b['locked']) > 0]
            logger.info(f"Saldos não-zero: {len(balances)}")
            for balance in balances[:5]:  # Mostrar apenas os primeiros 5 para não poluir o log
                logger.info(f"  {balance['asset']}: Free: {balance['free']}, Locked: {balance['locked']}")
            
        except BinanceAPIException as e:
            logger.error(f"Erro ao obter informações da conta: {e}")
        
        # Teste 4: Obter klines
        logger.info("Teste 4: Obter klines")
        symbols = ["BTCUSDT", "ETHUSDT"]
        intervals = ["1m", "15m", "1h"]
        
        for symbol in symbols:
            for interval in intervals:
                try:
                    start_time = time.time()
                    klines = await client.get_klines(symbol=symbol, interval=interval, limit=10)
                    request_time = time.time() - start_time
                    
                    logger.info(f"Klines para {symbol} ({interval}) obtidas com sucesso. Tempo: {request_time:.4f}s")
                    logger.info(f"  Número de klines: {len(klines)}")
                    if klines:
                        latest_kline = klines[-1]
                        open_time = datetime.fromtimestamp(latest_kline[0] / 1000)
                        close_time = datetime.fromtimestamp(latest_kline[6] / 1000)
                        logger.info(f"  Última kline: Abertura: {open_time}, Fechamento: {close_time}")
                        logger.info(f"  Preços: O: {latest_kline[1]}, H: {latest_kline[2]}, L: {latest_kline[3]}, C: {latest_kline[4]}")
                except BinanceAPIException as e:
                    logger.error(f"Erro ao obter klines para {symbol} ({interval}): {e}")
        
        # Teste 5: Obter ticker
        logger.info("Teste 5: Obter ticker")
        for symbol in symbols:
            try:
                start_time = time.time()
                ticker = await client.get_ticker(symbol=symbol)
                request_time = time.time() - start_time
                
                logger.info(f"Ticker para {symbol} obtido com sucesso. Tempo: {request_time:.4f}s")
                logger.info(f"  Preço: {ticker['lastPrice']}")
                logger.info(f"  Volume 24h: {ticker['volume']}")
                logger.info(f"  Variação 24h: {ticker['priceChangePercent']}%")
            except BinanceAPIException as e:
                logger.error(f"Erro ao obter ticker para {symbol}: {e}")
        
        # Teste 6: Obter profundidade do livro de ordens
        logger.info("Teste 6: Obter profundidade do livro de ordens")
        for symbol in symbols:
            try:
                start_time = time.time()
                depth = await client.get_order_book(symbol=symbol, limit=5)
                request_time = time.time() - start_time
                
                logger.info(f"Profundidade para {symbol} obtida com sucesso. Tempo: {request_time:.4f}s")
                logger.info(f"  Número de ofertas de compra: {len(depth['bids'])}")
                logger.info(f"  Número de ofertas de venda: {len(depth['asks'])}")
                if depth['bids']:
                    logger.info(f"  Melhor oferta de compra: {depth['bids'][0]}")
                if depth['asks']:
                    logger.info(f"  Melhor oferta de venda: {depth['asks'][0]}")
            except BinanceAPIException as e:
                logger.error(f"Erro ao obter profundidade para {symbol}: {e}")
        
        # Fechar cliente
        await client.close_connection()
        logger.info("Conexão REST fechada com sucesso")
        
        return True
    except Exception as e:
        logger.error(f"Erro durante teste de conexão REST: {e}")
        logger.error(traceback.format_exc())
        return False

# Teste de conexão WebSocket
async def testar_conexao_websocket(api_key, api_secret, testnet=True):
    logger.info(f"Iniciando teste de conexão WebSocket (Testnet: {testnet})")
    
    try:
        # Inicializar cliente assíncrono
        client = await AsyncClient.create(api_key, api_secret, testnet=testnet)
        logger.info("Cliente assíncrono inicializado com sucesso para WebSocket")
        
        # Variáveis para controle
        messages_received = {
            "kline": 0,
            "ticker": 0,
            "depth": 0
        }
        
        # Callback para kline
        def process_kline_message(msg):
            if msg.get('e') == 'kline':
                messages_received["kline"] += 1
                k = msg.get('k', {})
                symbol = msg.get('s')
                interval = k.get('i')
                is_closed = k.get('x', False)
                open_price = k.get('o')
                close_price = k.get('c')
                
                logger.info(f"Kline recebida: {symbol} ({interval}), Fechada: {is_closed}")
                logger.info(f"  Preços: O: {open_price}, C: {close_price}")
                logger.info(f"  Total de klines recebidas: {messages_received['kline']}")
        
        # Callback para ticker
        def process_ticker_message(msg):
            if msg.get('e') == '24hrTicker':
                messages_received["ticker"] += 1
                symbol = msg.get('s')
                price = msg.get('c')
                volume = msg.get('v')
                
                logger.info(f"Ticker recebido: {symbol}")
                logger.info(f"  Preço: {price}, Volume: {volume}")
                logger.info(f"  Total de tickers recebidos: {messages_received['ticker']}")
        
        # Callback para depth
        def process_depth_message(msg):
            messages_received["depth"] += 1
            
            if messages_received["depth"] % 10 == 0:  # Logar apenas a cada 10 mensagens para não poluir
                logger.info(f"Atualização de profundidade recebida")
                logger.info(f"  Total de atualizações de profundidade recebidas: {messages_received['depth']}")
        
        # Inicializar socket manager
        bsm = BinanceSocketManager(client)
        
        # Iniciar sockets
        logger.info("Iniciando socket de kline para BTCUSDT (1m)")
        kline_socket = bsm.kline_socket('BTCUSDT', '1m', process_kline_message)
        
        logger.info("Iniciando socket de ticker para BTCUSDT")
        ticker_socket = bsm.ticker_socket('BTCUSDT', process_ticker_message)
        
        logger.info("Iniciando socket de profundidade para BTCUSDT")
        depth_socket = bsm.depth_socket('BTCUSDT', process_depth_message)
        
        # Iniciar sockets
        await kline_socket.__aenter__()
        await ticker_socket.__aenter__()
        await depth_socket.__aenter__()
        
        logger.info("Todos os sockets iniciados com sucesso")
        logger.info("Aguardando mensagens por 30 segundos...")
        
        # Aguardar por mensagens
        for i in range(30):
            await asyncio.sleep(1)
            if i % 5 == 0:
                logger.info(f"Aguardando... {i+1}/30s")
                logger.info(f"Mensagens recebidas: Klines: {messages_received['kline']}, Tickers: {messages_received['ticker']}, Depth: {messages_received['depth']}")
        
        # Fechar sockets
        await kline_socket.__aexit__(None, None, None)
        await ticker_socket.__aexit__(None, None, None)
        await depth_socket.__aexit__(None, None, None)
        
        logger.info("Sockets fechados com sucesso")
        
        # Fechar cliente
        await client.close_connection()
        logger.info("Conexão WebSocket fechada com sucesso")
        
        # Verificar se recebemos mensagens
        success = all(count > 0 for count in messages_received.values())
        if success:
            logger.info("Teste de WebSocket concluído com sucesso! Mensagens recebidas em todos os canais.")
        else:
            logger.warning("Teste de WebSocket concluído, mas não recebemos mensagens em todos os canais.")
            for channel, count in messages_received.items():
                if count == 0:
                    logger.warning(f"Nenhuma mensagem recebida no canal {channel}")
        
        return success
    except Exception as e:
        logger.error(f"Erro durante teste de conexão WebSocket: {e}")
        logger.error(traceback.format_exc())
        return False

# Teste do módulo de streaming otimizado
async def testar_modulo_streaming(config):
    logger.info("Iniciando teste do módulo de streaming otimizado")
    
    try:
        # Importar o módulo de streaming
        try:
            from src.core.binance_stream import BinanceStreamManager
            logger.info("Módulo de streaming importado com sucesso")
        except ImportError:
            try:
                sys.path.insert(0, ".")
                from binance_stream import BinanceStreamManager
                logger.info("Módulo de streaming importado com sucesso (caminho alternativo)")
            except ImportError as e:
                logger.error(f"Erro ao importar módulo de streaming: {e}")
                return False
        
        # Contexto simplificado para teste
        contexto = {
            "dataframes": {},
            "dataframes_lock": asyncio.Lock(),
            "memoria_temporal": {},
            "configuracao_global": config
        }
        
        # Callback para kline
        async def callback_kline(symbol, interval, data):
            logger.info(f"Callback de kline chamado: {symbol} ({interval})")
            logger.info(f"  Dados: {data}")
        
        # Callback para ticker
        async def callback_ticker(symbol, data):
            logger.info(f"Callback de ticker chamado: {symbol}")
            logger.info(f"  Dados: {data}")
        
        # Inicializar gerenciador de streaming
        manager = BinanceStreamManager(config, contexto)
        logger.info("Gerenciador de streaming inicializado com sucesso")
        
        # Registrar callbacks
        manager.registrar_callback("BTCUSDT", "1m", callback_kline)
        manager.registrar_callback("BTCUSDT", "ticker", callback_ticker)
        logger.info("Callbacks registrados com sucesso")
        
        # Definir streams para teste
        streams = [
            {'type': 'kline', 'symbol': 'BTCUSDT', 'interval': '1m'},
            {'type': 'ticker', 'symbol': 'BTCUSDT'}
        ]
        
        # Iniciar streams
        logger.info("Iniciando streams...")
        await manager.iniciar_streams(streams)
        logger.info("Streams iniciados com sucesso")
        
        # Aguardar por mensagens
        logger.info("Aguardando mensagens por 30 segundos...")
        for i in range(30):
            await asyncio.sleep(1)
            if i % 5 == 0:
                logger.info(f"Aguardando... {i+1}/30s")
                
                # Verificar estatísticas
                if hasattr(manager, "connection_stats"):
                    stats = manager.connection_stats
                    logger.info(f"Estatísticas de conexão: Reconexões: {stats.reconnect_count}, Mensagens recebidas: {stats.messages_received}")
        
        # Verificar cache
        if hasattr(manager, "kline_cache"):
            logger.info("Verificando cache de klines...")
            cache_key = "BTCUSDT_1m"
            if cache_key in manager.kline_cache:
                logger.info(f"Cache de kline para {cache_key} encontrado!")
                logger.info(f"  Dados: {manager.kline_cache[cache_key]}")
            else:
                logger.warning(f"Cache de kline para {cache_key} não encontrado")
        
        # Parar streams
        logger.info("Parando streams...")
        await manager.parar()
        logger.info("Streams parados com sucesso")
        
        return True
    except Exception as e:
        logger.error(f"Erro durante teste do módulo de streaming: {e}")
        logger.error(traceback.format_exc())
        return False

# Função principal
async def main():
    logger.info("Iniciando bateria de testes de conexão com a Binance")
    
    # Carregar configuração
    config = carregar_config()
    if not config:
        logger.error("Não foi possível carregar a configuração. Abortando testes.")
        return
    
    # Extrair credenciais
    api_key = config.get("binance_api_key", "")
    api_secret = config.get("binance_api_secret", "")
    testnet = config.get("testnet", True)
    
    if not api_key or not api_secret:
        logger.error("Credenciais da API Binance não encontradas na configuração. Abortando testes.")
        return
    
    # Mascarar credenciais para o log
    masked_key = f"{api_key[:4]}...{api_key[-4:]}" if len(api_key) >= 8 else "****"
    logger.info(f"Usando API key: {masked_key}")
    logger.info(f"Testnet: {testnet}")
    
    # Executar testes
    results = {}
    
    # Teste 1: Conexão REST
    logger.info("=== TESTE 1: CONEXÃO REST ===")
    results["rest"] = await testar_conexao_rest(api_key, api_secret, testnet)
    
    # Teste 2: Conexão WebSocket
    logger.info("=== TESTE 2: CONEXÃO WEBSOCKET ===")
    results["websocket"] = await testar_conexao_websocket(api_key, api_secret, testnet)
    
    # Teste 3: Módulo de streaming otimizado
    logger.info("=== TESTE 3: MÓDULO DE STREAMING OTIMIZADO ===")
    results["streaming"] = await testar_modulo_streaming(config)
    
    # Resumo dos resultados
    logger.info("=== RESUMO DOS RESULTADOS ===")
    for test, result in results.items():
        status = "SUCESSO" if result else "FALHA"
        logger.info(f"Teste de {test}: {status}")
    
    all_success = all(results.values())
    if all_success:
        logger.info("TODOS OS TESTES FORAM BEM-SUCEDIDOS!")
        logger.info("A conexão com a Binance está funcionando corretamente.")
    else:
        logger.warning("ALGUNS TESTES FALHARAM!")
        logger.warning("Verifique os logs para mais detalhes sobre as falhas.")
    
    return all_success

if __name__ == "__main__":
    asyncio.run(main())
