#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de teste de conexão com a Binance (versão atualizada)
Este script realiza uma bateria de testes para verificar se a conexão
com a API da Binance está funcionando corretamente.
Compatível com versões mais recentes da biblioteca python-binance.
"""

import asyncio
import logging
import sys
import time
import json
from datetime import datetime
import traceback

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("teste_conexao_binance.log"),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger("teste_conexao_binance")

# Importar bibliotecas necessárias
try:
    from binance.spot import Spot
    from binance.client import Client
    logger.info("Bibliotecas Binance importadas com sucesso")
except ImportError as e:
    logger.error(f"Erro ao importar bibliotecas Binance: {e}")
    logger.error("Execute 'pip3 install python-binance' para instalar as dependências")
    sys.exit(1)

# Carregar configuração
def carregar_config():
    try:
        with open("config.json", "r") as f:
            config = json.load(f)
        return config
    except Exception as e:
        logger.error(f"Erro ao carregar config.json: {e}")
        return None

# Teste de conexão REST
def testar_conexao_rest(api_key, api_secret, testnet=True):
    logger.info(f"Iniciando teste de conexão REST (Testnet: {testnet})")
    
    try:
        # Inicializar cliente
        base_url = "https://testnet.binance.vision" if testnet else None
        client = Spot(api_key=api_key, api_secret=api_secret, base_url=base_url)
        logger.info("Cliente inicializado com sucesso")
        
        # Teste 1: Ping
        logger.info("Teste 1: Ping")
        start_time = time.time()
        ping_result = client.ping()
        ping_time = time.time() - start_time
        logger.info(f"Ping bem-sucedido. Tempo: {ping_time:.4f}s")
        
        # Teste 2: Tempo do servidor
        logger.info("Teste 2: Tempo do servidor")
        server_time = client.time()
        server_time_dt = datetime.fromtimestamp(server_time['serverTime'] / 1000)
        logger.info(f"Tempo do servidor: {server_time_dt}")
        
        # Teste 3: Informações da conta
        logger.info("Teste 3: Informações da conta")
        try:
            account_info = client.account()
            logger.info(f"Informações da conta obtidas com sucesso")
            logger.info(f"Status da conta: Pode operar: {account_info['canTrade']}")
            logger.info(f"Comissões: Maker: {account_info['makerCommission']}, Taker: {account_info['takerCommission']}")
            
            # Mostrar saldos não-zero
            balances = [b for b in account_info['balances'] if float(b['free']) > 0 or float(b['locked']) > 0]
            logger.info(f"Saldos não-zero: {len(balances)}")
            for balance in balances[:5]:  # Mostrar apenas os primeiros 5 para não poluir o log
                logger.info(f"  {balance['asset']}: Free: {balance['free']}, Locked: {balance['locked']}")
            
        except Exception as e:
            logger.error(f"Erro ao obter informações da conta: {e}")
        
        # Teste 4: Obter klines
        logger.info("Teste 4: Obter klines")
        symbols = ["BTCUSDT", "ETHUSDT"]
        intervals = ["1m", "15m", "1h"]
        
        for symbol in symbols:
            for interval in intervals:
                try:
                    start_time = time.time()
                    klines = client.klines(symbol=symbol, interval=interval, limit=10)
                    request_time = time.time() - start_time
                    
                    logger.info(f"Klines para {symbol} ({interval}) obtidas com sucesso. Tempo: {request_time:.4f}s")
                    logger.info(f"  Número de klines: {len(klines)}")
                    if klines:
                        latest_kline = klines[-1]
                        open_time = datetime.fromtimestamp(latest_kline[0] / 1000)
                        close_time = datetime.fromtimestamp(latest_kline[6] / 1000)
                        logger.info(f"  Última kline: Abertura: {open_time}, Fechamento: {close_time}")
                        logger.info(f"  Preços: O: {latest_kline[1]}, H: {latest_kline[2]}, L: {latest_kline[3]}, C: {latest_kline[4]}")
                except Exception as e:
                    logger.error(f"Erro ao obter klines para {symbol} ({interval}): {e}")
        
        # Teste 5: Obter ticker
        logger.info("Teste 5: Obter ticker")
        for symbol in symbols:
            try:
                start_time = time.time()
                ticker = client.ticker_price(symbol=symbol)
                request_time = time.time() - start_time
                
                logger.info(f"Ticker para {symbol} obtido com sucesso. Tempo: {request_time:.4f}s")
                logger.info(f"  Preço: {ticker['price']}")
                
                # Obter estatísticas de 24h
                ticker_24h = client.ticker_24hr(symbol=symbol)
                logger.info(f"  Volume 24h: {ticker_24h['volume']}")
                logger.info(f"  Variação 24h: {ticker_24h['priceChangePercent']}%")
            except Exception as e:
                logger.error(f"Erro ao obter ticker para {symbol}: {e}")
        
        # Teste 6: Obter profundidade do livro de ordens
        logger.info("Teste 6: Obter profundidade do livro de ordens")
        for symbol in symbols:
            try:
                start_time = time.time()
                depth = client.depth(symbol=symbol, limit=5)
                request_time = time.time() - start_time
                
                logger.info(f"Profundidade para {symbol} obtida com sucesso. Tempo: {request_time:.4f}s")
                logger.info(f"  Número de ofertas de compra: {len(depth['bids'])}")
                logger.info(f"  Número de ofertas de venda: {len(depth['asks'])}")
                if depth['bids']:
                    logger.info(f"  Melhor oferta de compra: {depth['bids'][0]}")
                if depth['asks']:
                    logger.info(f"  Melhor oferta de venda: {depth['asks'][0]}")
            except Exception as e:
                logger.error(f"Erro ao obter profundidade para {symbol}: {e}")
        
        logger.info("Testes REST concluídos com sucesso")
        return True
    except Exception as e:
        logger.error(f"Erro durante teste de conexão REST: {e}")
        logger.error(traceback.format_exc())
        return False

# Teste de conexão WebSocket usando a biblioteca Client
def testar_conexao_websocket_client(api_key, api_secret, testnet=True):
    logger.info(f"Iniciando teste de conexão WebSocket via Client (Testnet: {testnet})")
    
    try:
        # Inicializar cliente
        base_url = "https://testnet.binance.vision" if testnet else None
        client = Client(api_key, api_secret, testnet=testnet)
        logger.info("Cliente inicializado com sucesso para WebSocket")
        
        # Variáveis para controle
        messages_received = 0
        
        # Callback para mensagens
        def process_message(msg):
            nonlocal messages_received
            messages_received += 1
            
            if isinstance(msg, dict):
                event_type = msg.get('e')
                if event_type == 'kline':
                    symbol = msg.get('s')
                    k = msg.get('k', {})
                    interval = k.get('i')
                    logger.info(f"Kline recebida: {symbol} ({interval})")
                elif event_type == '24hrTicker':
                    symbol = msg.get('s')
                    price = msg.get('c')
                    logger.info(f"Ticker recebido: {symbol}, Preço: {price}")
                elif event_type == 'depthUpdate':
                    symbol = msg.get('s')
                    logger.info(f"Atualização de profundidade recebida: {symbol}")
                else:
                    logger.info(f"Mensagem recebida: {event_type}")
            else:
                logger.info(f"Mensagem não estruturada recebida: {type(msg)}")
            
            logger.info(f"Total de mensagens recebidas: {messages_received}")
        
        # Iniciar socket para kline
        logger.info("Iniciando socket para BTCUSDT kline_1m")
        client.start_kline_socket('BTCUSDT', process_message, interval='1m')
        
        # Iniciar socket para ticker
        logger.info("Iniciando socket para BTCUSDT ticker")
        client.start_symbol_ticker_socket('BTCUSDT', process_message)
        
        # Iniciar socket para profundidade
        logger.info("Iniciando socket para BTCUSDT depth")
        client.start_depth_socket('BTCUSDT', process_message, depth=5)
        
        # Iniciar loop de processamento
        logger.info("Iniciando loop de processamento de WebSocket")
        client.start()
        
        # Aguardar por mensagens
        logger.info("Aguardando mensagens por 30 segundos...")
        for i in range(30):
            time.sleep(1)
            if i % 5 == 0:
                logger.info(f"Aguardando... {i+1}/30s")
                logger.info(f"Mensagens recebidas até agora: {messages_received}")
        
        # Parar cliente
        client.stop()
        logger.info("Cliente WebSocket parado com sucesso")
        
        # Verificar se recebemos mensagens
        success = messages_received > 0
        if success:
            logger.info(f"Teste de WebSocket concluído com sucesso! {messages_received} mensagens recebidas.")
        else:
            logger.warning("Teste de WebSocket concluído, mas nenhuma mensagem foi recebida.")
        
        return success
    except Exception as e:
        logger.error(f"Erro durante teste de conexão WebSocket: {e}")
        logger.error(traceback.format_exc())
        return False

# Teste do módulo de streaming do sistema
def testar_modulo_streaming(config):
    logger.info("Iniciando teste do módulo de streaming do sistema")
    
    try:
        # Tentar importar o módulo de streaming
        try:
            # Primeiro, tentar importar do caminho padrão
            sys.path.insert(0, ".")
            import binance_stream_otimizado as binance_stream
            logger.info("Módulo de streaming importado com sucesso (binance_stream_otimizado)")
        except ImportError:
            try:
                # Tentar importar o módulo fundido
                import binance_stream_fundido as binance_stream
                logger.info("Módulo de streaming importado com sucesso (binance_stream_fundido)")
            except ImportError:
                try:
                    # Tentar importar o módulo original
                    import binance_stream
                    logger.info("Módulo de streaming importado com sucesso (binance_stream)")
                except ImportError as e:
                    logger.error(f"Erro ao importar módulo de streaming: {e}")
                    logger.error("Nenhum dos módulos de streaming foi encontrado")
                    return False
        
        # Verificar se o módulo tem a classe BinanceStreamManager
        if not hasattr(binance_stream, 'BinanceStreamManager'):
            logger.error("Módulo de streaming não contém a classe BinanceStreamManager")
            return False
        
        logger.info("Módulo de streaming encontrado e contém a classe BinanceStreamManager")
        logger.info("Teste do módulo de streaming concluído com sucesso")
        return True
    except Exception as e:
        logger.error(f"Erro durante teste do módulo de streaming: {e}")
        logger.error(traceback.format_exc())
        return False

# Função principal
def main():
    logger.info("Iniciando bateria de testes de conexão com a Binance")
    
    # Carregar configuração
    config = carregar_config()
    if not config:
        logger.error("Não foi possível carregar a configuração. Abortando testes.")
        return
    
    # Extrair credenciais
    api_key = config.get("binance_api_key", "")
    api_secret = config.get("binance_api_secret", "")
    testnet = config.get("testnet", True)
    
    if not api_key or not api_secret:
        logger.error("Credenciais da API Binance não encontradas na configuração. Abortando testes.")
        return
    
    # Mascarar credenciais para o log
    masked_key = f"{api_key[:4]}...{api_key[-4:]}" if len(api_key) >= 8 else "****"
    logger.info(f"Usando API key: {masked_key}")
    logger.info(f"Testnet: {testnet}")
    
    # Executar testes
    results = {}
    
    # Teste 1: Conexão REST
    logger.info("=== TESTE 1: CONEXÃO REST ===")
    results["rest"] = testar_conexao_rest(api_key, api_secret, testnet)
    
    # Teste 2: Conexão WebSocket
    logger.info("=== TESTE 2: CONEXÃO WEBSOCKET ===")
    try:
        results["websocket"] = testar_conexao_websocket_client(api_key, api_secret, testnet)
    except Exception as e:
        logger.error(f"Erro ao iniciar teste de WebSocket: {e}")
        logger.error("Pulando teste de WebSocket devido a erro de inicialização")
        results["websocket"] = False
    
    # Teste 3: Módulo de streaming do sistema
    logger.info("=== TESTE 3: MÓDULO DE STREAMING DO SISTEMA ===")
    results["streaming"] = testar_modulo_streaming(config)
    
    # Resumo dos resultados
    logger.info("=== RESUMO DOS RESULTADOS ===")
    for test, result in results.items():
        status = "SUCESSO" if result else "FALHA"
        logger.info(f"Teste de {test}: {status}")
    
    all_success = all(results.values())
    if all_success:
        logger.info("TODOS OS TESTES FORAM BEM-SUCEDIDOS!")
        logger.info("A conexão com a Binance está funcionando corretamente.")
    else:
        logger.warning("ALGUNS TESTES FALHARAM!")
        logger.warning("Verifique os logs para mais detalhes sobre as falhas.")
    
    return all_success

if __name__ == "__main__":
    main()
