#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Teste end-to-end para validar o tratamento robusto de exceções no sistema

Este script executa testes end-to-end para verificar se o tratamento de exceções
implementado no sistema está funcionando corretamente em cenários reais de uso.
"""

import os
import sys
import json
import time
import logging
import argparse
import datetime
import subprocess
import traceback
from pathlib import Path

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("teste_end_to_end_excecoes.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("teste_end_to_end")

def executar_comando(comando, diretorio=None, timeout=60):
    """
    Executa um comando shell e retorna o resultado.
    
    Args:
        comando: Comando a ser executado
        diretorio: Diretório de trabalho
        timeout: Tempo máximo de execução em segundos
        
    Returns:
        tuple: (código de saída, stdout, stderr)
    """
    try:
        logger.info(f"Executando comando: {comando}")
        processo = subprocess.Popen(
            comando,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=diretorio,
            text=True
        )
        
        stdout, stderr = processo.communicate(timeout=timeout)
        codigo_saida = processo.returncode
        
        logger.info(f"Comando concluído com código de saída: {codigo_saida}")
        if codigo_saida != 0:
            logger.warning(f"Erro na execução do comando: {stderr}")
            
        return codigo_saida, stdout, stderr
    except subprocess.TimeoutExpired:
        processo.kill()
        logger.error(f"Timeout ao executar comando: {comando}")
        return -1, "", "Timeout"
    except Exception as e:
        logger.error(f"Erro ao executar comando: {str(e)}")
        logger.debug(f"Detalhes: {traceback.format_exc()}")
        return -1, "", str(e)

def testar_inicializacao_com_config_invalida():
    """
    Testa a inicialização do sistema com um arquivo de configuração inválido.
    
    Returns:
        bool: True se o teste passou, False caso contrário
    """
    logger.info("=== Teste: Inicialização com config inválida ===")
    
    # Criar arquivo de configuração inválido
    config_invalido = "config_invalido.json"
    with open(config_invalido, "w") as f:
        f.write("{invalid json")
    
    try:
        # Executar o sistema com o arquivo inválido
        comando = f"python -m main --config {config_invalido} --check"
        codigo, stdout, stderr = executar_comando(comando)
        
        # Verificar se o sistema não travou e retornou código de erro
        if codigo == 1:
            logger.info("✅ Teste passou: Sistema detectou config inválido e retornou código de erro")
            return True
        else:
            logger.error(f"❌ Teste falhou: Sistema retornou código {codigo} ao invés de 1")
            return False
    finally:
        # Limpar arquivo temporário
        if os.path.exists(config_invalido):
            os.remove(config_invalido)

def testar_inicializacao_com_componente_falho():
    """
    Testa a inicialização do sistema quando um componente falha.
    
    Returns:
        bool: True se o teste passou, False caso contrário
    """
    logger.info("=== Teste: Inicialização com componente falho ===")
    
    # Criar arquivo de configuração que ativa um componente que vai falhar
    config_componente_falho = "config_componente_falho.json"
    config = {
        "components_activation": {
            "attack_detector_active": True,
            "neural_governor_active": True
        },
        "attack_detector_config": {
            "spoofing_threshold": "string_invalida"  # Isso deve causar erro de tipo
        }
    }
    
    with open(config_componente_falho, "w") as f:
        json.dump(config, f)
    
    try:
        # Executar o sistema com o arquivo de configuração
        comando = f"python -m main --config {config_componente_falho} --check"
        codigo, stdout, stderr = executar_comando(comando)
        
        # Verificar se o sistema não travou e continuou a execução
        if codigo == 0:
            logger.info("✅ Teste passou: Sistema continuou a execução apesar do componente falho")
            return True
        else:
            logger.error(f"❌ Teste falhou: Sistema retornou código {codigo} ao invés de 0")
            return False
    finally:
        # Limpar arquivo temporário
        if os.path.exists(config_componente_falho):
            os.remove(config_componente_falho)

def testar_simulacao_com_dados_invalidos():
    """
    Testa a simulação com dados históricos inválidos.
    
    Returns:
        bool: True se o teste passou, False caso contrário
    """
    logger.info("=== Teste: Simulação com dados inválidos ===")
    
    # Criar arquivo de dados inválido
    dados_invalidos = "dados_invalidos.csv"
    with open(dados_invalidos, "w") as f:
        f.write("timestamp,open,high\n")  # Faltam colunas necessárias
        f.write("2023-01-01,50000,51000\n")
    
    try:
        # Executar o sistema com os dados inválidos
        comando = f"python -m main --simulate {dados_invalidos}"
        codigo, stdout, stderr = executar_comando(comando)
        
        # Verificar se o sistema não travou e retornou código de erro
        if codigo == 1:
            logger.info("✅ Teste passou: Sistema detectou dados inválidos e retornou código de erro")
            return True
        else:
            logger.error(f"❌ Teste falhou: Sistema retornou código {codigo} ao invés de 1")
            return False
    finally:
        # Limpar arquivo temporário
        if os.path.exists(dados_invalidos):
            os.remove(dados_invalidos)

def testar_simulacao_com_dados_validos():
    """
    Testa a simulação com dados históricos válidos.
    
    Returns:
        bool: True se o teste passou, False caso contrário
    """
    logger.info("=== Teste: Simulação com dados válidos ===")
    
    # Criar arquivo de dados válido
    dados_validos = "dados_validos.csv"
    with open(dados_validos, "w") as f:
        f.write("timestamp,open,high,low,close,volume\n")
        f.write("2023-01-01T00:00:00,50000,51000,49000,50500,100\n")
        f.write("2023-01-01T01:00:00,50500,52000,50000,51000,120\n")
    
    try:
        # Executar o sistema com os dados válidos
        comando = f"python -m main --simulate {dados_validos} --simulation_output sim_output_test.json"
        codigo, stdout, stderr = executar_comando(comando)
        
        # Verificar se o sistema executou com sucesso
        if codigo == 0 and os.path.exists("sim_output_test.json"):
            logger.info("✅ Teste passou: Sistema processou dados válidos e gerou saída")
            return True
        else:
            logger.error(f"❌ Teste falhou: Sistema retornou código {codigo} ou não gerou saída")
            return False
    finally:
        # Limpar arquivos temporários
        if os.path.exists(dados_validos):
            os.remove(dados_validos)
        if os.path.exists("sim_output_test.json"):
            os.remove("sim_output_test.json")

def testar_simulacao_com_erro_durante_processamento():
    """
    Testa a simulação quando ocorre um erro durante o processamento.
    
    Returns:
        bool: True se o teste passou, False caso contrário
    """
    logger.info("=== Teste: Simulação com erro durante processamento ===")
    
    # Criar arquivo de dados válido
    dados_validos = "dados_validos.csv"
    with open(dados_validos, "w") as f:
        f.write("timestamp,open,high,low,close,volume\n")
        f.write("2023-01-01T00:00:00,50000,51000,49000,50500,100\n")
        # Adicionar uma linha com valor inválido que causará erro durante processamento
        f.write("2023-01-01T01:00:00,invalid,52000,50000,51000,120\n")
        f.write("2023-01-01T02:00:00,51000,53000,50500,52000,150\n")
    
    # Criar config que ativa componentes que vão processar os dados
    config_processamento = "config_processamento.json"
    config = {
        "components_activation": {
            "attack_detector_active": True,
            "neural_governor_active": True
        }
    }
    
    with open(config_processamento, "w") as f:
        json.dump(config, f)
    
    try:
        # Executar o sistema com os dados e config
        comando = f"python -m main --config {config_processamento} --simulate {dados_validos} --simulation_output sim_output_erro.json"
        codigo, stdout, stderr = executar_comando(comando)
        
        # Verificar se o sistema continuou a execução apesar do erro
        if os.path.exists("sim_output_erro.json"):
            # Verificar se o arquivo de saída contém resultados
            with open("sim_output_erro.json", "r") as f:
                try:
                    resultados = json.load(f)
                    if len(resultados) > 0:
                        logger.info("✅ Teste passou: Sistema continuou processamento apesar de erro em um registro")
                        return True
                except json.JSONDecodeError:
                    pass
                    
            logger.error("❌ Teste falhou: Sistema não gerou saída válida")
            return False
        else:
            logger.error("❌ Teste falhou: Sistema não gerou arquivo de saída")
            return False
    finally:
        # Limpar arquivos temporários
        if os.path.exists(dados_validos):
            os.remove(dados_validos)
        if os.path.exists(config_processamento):
            os.remove(config_processamento)
        if os.path.exists("sim_output_erro.json"):
            os.remove("sim_output_erro.json")

def executar_testes_unitarios():
    """
    Executa os testes unitários para o tratamento de exceções.
    
    Returns:
        bool: True se os testes passaram, False caso contrário
    """
    logger.info("=== Executando testes unitários ===")
    
    comando = "python -m unittest tests/test_tratamento_excecoes.py"
    codigo, stdout, stderr = executar_comando(comando)
    
    if codigo == 0:
        logger.info("✅ Testes unitários passaram com sucesso")
        return True
    else:
        logger.error(f"❌ Testes unitários falharam com código {codigo}")
        logger.error(f"Saída de erro: {stderr}")
        return False

def main():
    """
    Função principal que coordena a execução dos testes end-to-end.
    """
    logger.info("Iniciando testes end-to-end para tratamento de exceções")
    
    # Verificar se estamos no diretório correto
    if not os.path.exists("main.py"):
        logger.error("Arquivo main.py não encontrado. Certifique-se de estar no diretório raiz do projeto.")
        return 1
    
    # Substituir o main.py original pelo melhorado
    if os.path.exists("main.py.improved"):
        logger.info("Substituindo main.py pelo arquivo melhorado")
        if os.path.exists("main.py.original"):
            logger.warning("Backup main.py.original já existe, não será sobrescrito")
        else:
            executar_comando("cp main.py main.py.original")
        executar_comando("cp main.py.improved main.py")
    else:
        logger.error("Arquivo main.py.improved não encontrado. Não é possível continuar os testes.")
        return 1
    
    # Executar testes unitários
    testes_unitarios_ok = executar_testes_unitarios()
    
    # Executar testes end-to-end
    resultados = {
        "inicializacao_config_invalida": testar_inicializacao_com_config_invalida(),
        "inicializacao_componente_falho": testar_inicializacao_com_componente_falho(),
        "simulacao_dados_invalidos": testar_simulacao_com_dados_invalidos(),
        "simulacao_dados_validos": testar_simulacao_com_dados_validos(),
        "simulacao_erro_processamento": testar_simulacao_com_erro_durante_processamento()
    }
    
    # Restaurar o main.py original
    if os.path.exists("main.py.original"):
        logger.info("Restaurando main.py original")
        executar_comando("cp main.py.original main.py")
    
    # Gerar relatório de resultados
    logger.info("=== Relatório de Resultados ===")
    testes_passaram = True
    for nome_teste, resultado in resultados.items():
        status = "✅ PASSOU" if resultado else "❌ FALHOU"
        logger.info(f"{nome_teste}: {status}")
        if not resultado:
            testes_passaram = False
    
    if testes_unitarios_ok and testes_passaram:
        logger.info("✅ TODOS OS TESTES PASSARAM COM SUCESSO")
        return 0
    else:
        logger.error("❌ ALGUNS TESTES FALHARAM")
        return 1

if __name__ == "__main__":
    try:
        exit_code = main()
        sys.exit(exit_code)
    except Exception as e:
        logger.critical(f"Erro fatal não tratado: {str(e)}")
        logger.critical(f"Detalhes: {traceback.format_exc()}")
        sys.exit(1)
