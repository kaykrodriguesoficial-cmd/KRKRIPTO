#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para testar forçadamente a execução de ordens e verificar a resposta da Binance.
Este script é parte da Fase 2 do Plano de Auditoria do Fluxo de Execução de Ordens.
"""

import os
import sys
import json
import time
import logging
import asyncio
import argparse
from datetime import datetime

# Configurar logging
log_dir = "logs/auditoria"
os.makedirs(log_dir, exist_ok=True)
log_file = f"{log_dir}/teste_execucao_ordens_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger("teste_execucao_ordens")

# Tentar importar os módulos necessários
try:
    # Adicionar diretório raiz ao path
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    
    # Tentar importar os módulos necessários
    try:
        from src.infrastructure.operador import OperadorBinance
    except ImportError:
        logger.warning("Não foi possível importar OperadorBinance do caminho principal")
        try:
            from infrastructure.operador import OperadorBinance
        except ImportError:
            logger.critical("Não foi possível importar OperadorBinance")
            raise
    
    try:
        from src.infrastructure.executor_contextual import ExecutorContextual
    except ImportError:
        logger.warning("Não foi possível importar ExecutorContextual do caminho principal")
        try:
            from src.infrastructure.executor_contextual import ExecutorContextualAsync as ExecutorContextual
        except ImportError:
            try:
                from infrastructure.executor_contextual import ExecutorContextual
            except ImportError:
                try:
                    from infrastructure.executor_contextual import ExecutorContextualAsync as ExecutorContextual
                except ImportError:
                    logger.critical("Não foi possível importar ExecutorContextual")
                    raise
    
    try:
        from src.risk_management.risk_manager import RiskManager
    except ImportError:
        logger.warning("Não foi possível importar RiskManager do caminho principal")
        try:
            from risk_management.risk_manager import RiskManager
        except ImportError:
            logger.critical("Não foi possível importar RiskManager")
            raise
except Exception as e:
    logger.critical(f"Erro ao importar módulos: {e}")
    sys.exit(1)

class TestadorExecucaoOrdens:
    """
    Classe para testar a execução de ordens e verificar a resposta da Binance.
    """
    
    def __init__(self, config_file=None, modo_simulacao=True):
        """
        Inicializa o testador de execução de ordens.
        
        Args:
            config_file (str): Caminho para o arquivo de configuração
            modo_simulacao (bool): Se True, executa em modo de simulação
        """
        self.modo_simulacao = modo_simulacao
        self.config = self._carregar_config(config_file)
        
        # Inicializar componentes
        self.operador = None
        self.executor = None
        self.risk_manager = None
        
        logger.info(f"Testador inicializado em modo {'SIMULAÇÃO' if modo_simulacao else 'REAL'}")
    
    def _carregar_config(self, config_file):
        """
        Carrega a configuração do arquivo ou usa valores padrão.
        
        Args:
            config_file (str): Caminho para o arquivo de configuração
            
        Returns:
            dict: Configuração carregada
        """
        config = {
            "api_key": "",
            "api_secret": "",
            "testnet": True,
            "simbolos_teste": ["BTCUSDT", "ETHUSDT", "BNBUSDT"],
            "valor_ordem_teste": 10.0,
            "quantidade_ordem_teste": 0.001
        }
        
        if config_file and os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    loaded_config = json.load(f)
                    config.update(loaded_config)
                logger.info(f"Configuração carregada de {config_file}")
            except Exception as e:
                logger.error(f"Erro ao carregar configuração: {e}")
        
        return config
    
    async def inicializar_componentes(self):
        """
        Inicializa os componentes necessários para os testes.
        
        Returns:
            bool: True se a inicialização foi bem-sucedida, False caso contrário
        """
        try:
            # Inicializar OperadorBinance
            logger.info("Inicializando OperadorBinance...")
            self.operador = OperadorBinance(
                api_key=self.config.get("api_key"),
                api_secret=self.config.get("api_secret"),
                testnet=self.config.get("testnet", True),
                config=self.config
            )
            
            # Inicializar operador
            await self.operador.inicializar()
            logger.info("OperadorBinance inicializado com sucesso")
            
            # Inicializar RiskManager
            logger.info("Inicializando RiskManager...")
            self.risk_manager = RiskManager(config=self.config)
            logger.info("RiskManager inicializado com sucesso")
            
            # Inicializar ExecutorContextual
            logger.info("Inicializando ExecutorContextual...")
            self.executor = ExecutorContextual(
                operador=self.operador,
                config=self.config
            )
            await self.executor.inicializar()
            logger.info("ExecutorContextual inicializado com sucesso")
            
            return True
        except Exception as e:
            logger.critical(f"Erro ao inicializar componentes: {e}")
            return False
    
    async def testar_conexao_binance(self):
        """
        Testa a conexão com a Binance.
        
        Returns:
            bool: True se a conexão foi bem-sucedida, False caso contrário
        """
        try:
            logger.info("Testando conexão com a Binance...")
            
            # Verificar se o operador está inicializado
            if not self.operador:
                logger.error("OperadorBinance não inicializado")
                return False
            
            # Testar obtenção de preço atual
            simbolo = self.config["simbolos_teste"][0]
            preco = await self.operador.obter_preco_atual(simbolo)
            
            if preco is None:
                logger.error(f"Não foi possível obter preço atual para {simbolo}")
                return False
            
            logger.info(f"Conexão com Binance OK. Preço atual de {simbolo}: {preco}")
            return True
        except Exception as e:
            logger.critical(f"Erro ao testar conexão com a Binance: {e}")
            return False
    
    async def testar_geracao_sinal(self, simbolo=None):
        """
        Testa a geração de um sinal de trading.
        
        Args:
            simbolo (str): Símbolo para o sinal
            
        Returns:
            dict: Sinal gerado ou None em caso de falha
        """
        try:
            simbolo = simbolo or self.config["simbolos_teste"][0]
            logger.info(f"Gerando sinal de teste para {simbolo}...")
            
            # Obter preço atual
            preco_atual = await self.operador.obter_preco_atual(simbolo)
            if preco_atual is None:
                logger.error(f"Não foi possível obter preço atual para {simbolo}")
                return None
            
            # Gerar sinal de teste
            sinal = {
                "simbolo": simbolo,
                "lado": "BUY",
                "tipo": "LIMIT",
                "preco": round(preco_atual * 0.95, 2),  # 5% abaixo do preço atual
                "quantidade": self.config["quantidade_ordem_teste"],
                "timestamp": time.time(),
                "estrategia": "TESTE_AUDITORIA",
                "motivo": "Teste de auditoria do fluxo de execução de ordens"
            }
            
            logger.info(f"Sinal gerado: {json.dumps(sinal, indent=2)}")
            return sinal
        except Exception as e:
            logger.critical(f"Erro ao gerar sinal de teste: {e}")
            return None
    
    async def testar_validacao_sinal(self, sinal=None):
        """
        Testa a validação de um sinal pelo RiskManager e ExecutorContextual.
        
        Args:
            sinal (dict): Sinal a ser validado ou None para gerar um novo
            
        Returns:
            tuple: (sinal_valido, motivo)
        """
        try:
            if sinal is None:
                sinal = await self.testar_geracao_sinal()
                if sinal is None:
                    return False, "Falha ao gerar sinal"
            
            logger.info(f"Validando sinal: {json.dumps(sinal, indent=2)}")
            
            # Validar sinal com ExecutorContextual
            valido, motivo = await self.executor.validar_sinal(sinal)
            
            logger.info(f"Resultado da validação: {'VÁLIDO' if valido else 'INVÁLIDO'} - {motivo}")
            return valido, motivo
        except Exception as e:
            logger.critical(f"Erro ao validar sinal: {e}")
            return False, f"Erro: {e}"
    
    async def testar_execucao_ordem(self, sinal=None, validar_primeiro=True):
        """
        Testa a execução de uma ordem.
        
        Args:
            sinal (dict): Sinal a ser executado ou None para gerar um novo
            validar_primeiro (bool): Se True, valida o sinal antes de executar
            
        Returns:
            dict: Resultado da execução ou None em caso de falha
        """
        try:
            if sinal is None:
                sinal = await self.testar_geracao_sinal()
                if sinal is None:
                    return None
            
            # Validar sinal se necessário
            if validar_primeiro:
                valido, motivo = await self.testar_validacao_sinal(sinal)
                if not valido:
                    logger.warning(f"Sinal inválido, não será executado: {motivo}")
                    return None
            
            logger.info(f"Executando ordem: {json.dumps(sinal, indent=2)}")
            
            # Se estiver em modo de simulação, não executar realmente
            if self.modo_simulacao:
                logger.info("MODO SIMULAÇÃO: Ordem seria executada")
                return {
                    "orderId": "simulado_123456",
                    "simbolo": sinal["simbolo"],
                    "lado": sinal["lado"],
                    "tipo": sinal["tipo"],
                    "preco": sinal.get("preco"),
                    "quantidade": sinal.get("quantidade"),
                    "status": "SIMULADO",
                    "timestamp": time.time()
                }
            
            # Executar ordem
            resultado = await self.executor.executar_sinal(sinal)
            
            if resultado:
                logger.info(f"Ordem executada com sucesso: {json.dumps(resultado, indent=2)}")
            else:
                logger.error("Falha ao executar ordem")
            
            return resultado
        except Exception as e:
            logger.critical(f"Erro ao executar ordem: {e}")
            return None
    
    async def testar_fluxo_completo(self):
        """
        Testa o fluxo completo de geração, validação e execução de ordens.
        
        Returns:
            bool: True se o teste foi bem-sucedido, False caso contrário
        """
        try:
            logger.info("=== INICIANDO TESTE DE FLUXO COMPLETO ===")
            
            # Testar conexão com a Binance
            if not await self.testar_conexao_binance():
                logger.error("Falha no teste de conexão com a Binance")
                return False
            
            # Testar geração de sinal
            sinal = await self.testar_geracao_sinal()
            if sinal is None:
                logger.error("Falha no teste de geração de sinal")
                return False
            
            # Testar validação de sinal
            valido, motivo = await self.testar_validacao_sinal(sinal)
            if not valido:
                logger.error(f"Falha no teste de validação de sinal: {motivo}")
                return False
            
            # Testar execução de ordem
            resultado = await self.testar_execucao_ordem(sinal, validar_primeiro=False)
            if resultado is None:
                logger.error("Falha no teste de execução de ordem")
                return False
            
            logger.info("=== TESTE DE FLUXO COMPLETO CONCLUÍDO COM SUCESSO ===")
            return True
        except Exception as e:
            logger.critical(f"Erro no teste de fluxo completo: {e}")
            return False
    
    async def fechar(self):
        """
        Fecha os componentes e libera recursos.
        """
        try:
            if self.executor:
                await self.executor.fechar()
            
            if self.operador and hasattr(self.operador, "fechar_cliente"):
                await self.operador.fechar_cliente()
            
            logger.info("Componentes fechados com sucesso")
        except Exception as e:
            logger.error(f"Erro ao fechar componentes: {e}")

async def main():
    """
    Função principal para executar os testes.
    """
    parser = argparse.ArgumentParser(description="Teste de execução de ordens")
    parser.add_argument("--config", help="Caminho para o arquivo de configuração")
    parser.add_argument("--real", action="store_true", help="Executar em modo real (não simulação)")
    parser.add_argument("--simbolo", help="Símbolo para teste (ex: BTCUSDT)")
    args = parser.parse_args()
    
    logger.info("=== INICIANDO TESTE DE EXECUÇÃO DE ORDENS ===")
    logger.info(f"Log detalhado sendo salvo em: {log_file}")
    
    # Criar testador
    testador = TestadorExecucaoOrdens(
        config_file=args.config,
        modo_simulacao=not args.real
    )
    
    try:
        # Inicializar componentes
        if not await testador.inicializar_componentes():
            logger.critical("Falha ao inicializar componentes. Abortando teste.")
            return 1
        
        # Testar conexão com a Binance
        if not await testador.testar_conexao_binance():
            logger.critical("Falha ao conectar com a Binance. Abortando teste.")
            return 1
        
        # Testar fluxo completo
        simbolo = args.simbolo or testador.config["simbolos_teste"][0]
        
        # Gerar sinal
        sinal = await testador.testar_geracao_sinal(simbolo)
        if sinal is None:
            logger.critical("Falha ao gerar sinal. Abortando teste.")
            return 1
        
        # Validar sinal
        valido, motivo = await testador.testar_validacao_sinal(sinal)
        logger.info(f"Sinal válido: {valido} - {motivo}")
        
        # Executar ordem (mesmo se inválido, para testar o fluxo de rejeição)
        resultado = await testador.testar_execucao_ordem(sinal, validar_primeiro=False)
        
        # Salvar resultado
        resultado_file = f"{log_dir}/resultado_teste_execucao.json"
        with open(resultado_file, 'w') as f:
            json.dump({
                "sinal": sinal,
                "validacao": {"valido": valido, "motivo": motivo},
                "resultado_execucao": resultado
            }, f, indent=2)
        logger.info(f"Resultado do teste salvo em: {resultado_file}")
        
        logger.info("=== TESTE DE EXECUÇÃO DE ORDENS CONCLUÍDO ===")
        return 0
    except Exception as e:
        logger.critical(f"Erro durante o teste: {e}")
        return 1
    finally:
        # Fechar componentes
        await testador.fechar()

if __name__ == "__main__":
    asyncio.run(main())
