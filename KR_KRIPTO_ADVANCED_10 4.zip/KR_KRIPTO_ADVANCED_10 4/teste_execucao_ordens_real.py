#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de teste de execução de ordens para KR_KRIPTO_ADVANCED
Executa testes incrementais com sinais forçados para validar o fluxo completo
VERSÃO PARA MODO REAL
"""

import os
import sys
import json
import logging
import asyncio
import platform
import time
from datetime import datetime
from typing import Dict, Any, Optional, List, Tuple

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('teste_execucao_ordens_real.log')
    ]
)

logger = logging.getLogger('kr_kripto_teste_execucao')

# Tentar importar os módulos necessários
try:
    # Primeiro tenta importar do caminho principal
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    
    # Tenta diferentes caminhos de importação
    try:
        from src.infrastructure.operador import OperadorBinance
        from src.infrastructure.executor_contextual import ExecutorContextual, ExecutorOrdens
        from src.risk_management.risk_manager import RiskManager
        logger.info("✅ Módulos importados com sucesso do caminho src.infrastructure")
    except ImportError:
        try:
            # Tenta com caminho relativo
            sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "upload"))
            # Usar diretamente os stubs para evitar problemas de permissão
            logger.warning("⚠️ Usando classes stub para testes")
            raise ImportError("Forçando uso de stubs para evitar problemas de permissão")
        except ImportError:
            # Tenta com caminho kr_kripto
            try:
                sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "kr_kripto", "refatoracao"))
                from operador_async_completo_v4_corrigido import OperadorBinance
                from executor_contextual_corrigido import ExecutorContextual, ExecutorOrdens
                from risk_manager_async_completo import RiskManager
                logger.info("✅ Módulos importados com sucesso do diretório kr_kripto/refatoracao")
            except ImportError:
                raise ImportError("Não foi possível importar de nenhum caminho conhecido")
except ImportError as e:
    logger.warning(f"⚠️ Usando classes stub para testes: {e}")
    
    # Criar classes stub para testes básicos
    class OperadorBinance:
        def __init__(self, api_key="", api_secret="", testnet=True, config=None):
            self.api_key = api_key
            self.api_secret = api_secret
            self.testnet = testnet
            self.config = config or {}
            
        async def inicializar(self):
            logger.info("STUB: OperadorBinance.inicializar() chamado")
            return True
            
        async def criar_ordem(self, simbolo, lado, tipo, quantidade=None, preco=None, **kwargs):
            logger.info(f"STUB: OperadorBinance.criar_ordem() chamado: {simbolo} {lado} {tipo} {quantidade} {preco}")
            return {"status": "SIMULADO", "symbol": simbolo, "orderId": 12345, "side": lado}
            
        async def fechar_cliente(self):
            logger.info("STUB: OperadorBinance.fechar_cliente() chamado")
            return True
    
    class ExecutorContextual:
        @staticmethod
        async def executar_com_contexto_async(vetor_x, classe, prob, score_final, direcao_hist, 
                                             prioridade_ativo, score_orderflow, fakeout_detectado, 
                                             desvio_score_medio, min_conf=0.5, min_gatilhos=2, ativo="N/A"):
            logger.info(f"STUB: ExecutorContextual.executar_com_contexto_async() chamado para {ativo}")
            return prob >= min_conf
    
    class ExecutorOrdens:
        def __init__(self, operador=None, risk_manager=None):
            self.operador = operador
            self.risk_manager = risk_manager
            
        async def validar_e_executar(self, sinal):
            logger.info(f"STUB: ExecutorOrdens.validar_e_executar() chamado para {sinal.get('ativo')}")
            return {"status": "SIMULADO", "symbol": sinal.get("ativo"), "orderId": 12345}
    
    class RiskManager:
        def __init__(self, config=None):
            self.config = config or {}
            
        async def validar_ordem(self, simbolo, lado, quantidade, preco):
            logger.info(f"STUB: RiskManager.validar_ordem() chamado: {simbolo} {lado} {quantidade} {preco}")
            return True, "Validação simulada"

# Detectar ambiente Mac M1/ARM64
def detectar_mac_m1() -> bool:
    """Detecta se o ambiente é um Mac M1/ARM64."""
    system = platform.system()
    machine = platform.machine()
    is_mac_m1 = system == 'Darwin' and ('arm' in machine.lower() or 'aarch64' in machine.lower())
    logger.info(f"Sistema: {system}")
    logger.info(f"Arquitetura: {machine}")
    logger.info(f"Versão: {platform.version()}")
    if is_mac_m1:
        logger.info("✅ Detectado ambiente Mac M1/ARM64")
    return is_mac_m1

# Carregar configuração
def carregar_configuracao(arquivo: str = 'config.json') -> Dict[str, Any]:
    """Carrega a configuração do arquivo especificado."""
    try:
        if os.path.exists(arquivo):
            with open(arquivo, 'r') as f:
                config = json.load(f)
            logger.info(f"✅ Configuração carregada de {arquivo}")
            
            # Forçar modo real para este teste
            config["modo_simulacao"] = False
            config["executar_ordens_reais"] = True
            config["testnet"] = False  # Forçar ambiente de produção real
            logger.info("⚠️ ATENÇÃO: Configuração alterada para MODO REAL em ambiente de PRODUÇÃO")
            
            return config
        else:
            logger.warning(f"⚠️ Arquivo de configuração {arquivo} não encontrado. Usando configuração padrão.")
            # Configuração padrão para testes
            return {
                "testnet": False,  # Forçar ambiente de produção real
                "modo_simulacao": False,  # Forçar modo real
                "executar_ordens_reais": True,  # Forçar execução real
                "pares_trading": ["BTCUSDT", "ETHUSDT", "BNBUSDT"],
                "estrategias": [
                    {
                        "nome": "Cruzamento de Médias",
                        "simbolo": "BTCUSDT",
                        "intervalo": "1m",
                        "parametros": {
                            "media_rapida": 9,
                            "media_lenta": 21
                        }
                    },
                    {
                        "nome": "RSI",
                        "simbolo": "ETHUSDT",
                        "intervalo": "1m",
                        "parametros": {
                            "periodo_rsi": 14,
                            "sobrevenda": 30,
                            "sobrecompra": 70
                        }
                    }
                ]
            }
    except Exception as e:
        logger.error(f"❌ Erro ao carregar configuração: {e}")
        return {}

# Obter credenciais da API
def obter_credenciais() -> Tuple[str, str]:
    """Obtém as credenciais da API das variáveis de ambiente ou do config.json."""
    # Primeiro tenta carregar do config.json
    config = carregar_configuracao()
    api_key = config.get("binance_api_key", "")
    api_secret = config.get("binance_api_secret", "")
    
    # Se não encontrar no config, tenta variáveis de ambiente
    if not api_key or not api_secret:
        api_key = os.environ.get('BINANCE_API_KEY', '')
        api_secret = os.environ.get('BINANCE_API_SECRET', '')
    
    if not api_key or not api_secret:
        logger.warning("⚠️ Credenciais da API Binance não encontradas no config.json nem nas variáveis de ambiente.")
        return "", ""
    
    # Verificar formato básico das credenciais
    masked_key = f"{api_key[:4]}...{api_key[-4:]}" if len(api_key) >= 8 else "****"
    logger.info(f"✅ Credenciais da API Binance encontradas. API Key: {masked_key}")
    
    return api_key, api_secret

# Criar sinal de teste
def criar_sinal_teste(simbolo: str = "BTCUSDT", tipo: str = "compra", probabilidade: float = 0.85) -> Dict[str, Any]:
    """Cria um sinal de teste para validação do fluxo."""
    logger.info(f"🔄 Criando sinal de teste: {simbolo} {tipo} (prob: {probabilidade})")
    
    return {
        "ativo": simbolo,
        "classe": tipo,
        "probabilidade": probabilidade,
        "score_final": 75 if tipo == "compra" else 25,
        "direcao_historica": tipo,
        "prioridade": "alta",
        "score_orderflow": 0.7,
        "fakeout": False,
        "desvio_score": 0.2,
        "vetor_x": [1, 2, 3, 4],  # Exemplo simplificado
        "quantidade": 0.001,
        "preco": None,  # Ordem a mercado
        "timestamp": datetime.now().timestamp(),
        "estrategia": "Teste Forçado"
    }

# Teste de validação contextual
async def testar_validacao_contextual(sinal: Dict[str, Any]) -> bool:
    """Testa a validação contextual de um sinal."""
    logger.info(f"🔍 Testando validação contextual para sinal: {sinal['ativo']} {sinal['classe']}")
    
    try:
        # Extrair informações do sinal
        resultado = await ExecutorContextual.executar_com_contexto_async(
            vetor_x=sinal["vetor_x"],
            classe=sinal["classe"],
            prob=sinal["probabilidade"],
            score_final=sinal["score_final"],
            direcao_hist=sinal["direcao_historica"],
            prioridade_ativo=sinal["prioridade"],
            score_orderflow=sinal["score_orderflow"],
            fakeout_detectado=sinal["fakeout"],
            desvio_score_medio=sinal["desvio_score"],
            ativo=sinal["ativo"]
        )
        
        if resultado:
            logger.info(f"✅ Validação contextual APROVADA para {sinal['ativo']} {sinal['classe']}")
        else:
            logger.warning(f"⚠️ Validação contextual REJEITADA para {sinal['ativo']} {sinal['classe']}")
        
        return resultado
    except Exception as e:
        logger.error(f"❌ Erro na validação contextual: {e}")
        return False

# Teste de validação de risco
async def testar_validacao_risco(config: Dict[str, Any], sinal: Dict[str, Any]) -> Tuple[bool, str]:
    """Testa a validação de risco de um sinal."""
    logger.info(f"🔍 Testando validação de risco para sinal: {sinal['ativo']} {sinal['classe']}")
    
    try:
        # Inicializar RiskManager
        risk_manager = RiskManager(config=config)
        
        # Mapear tipo para formato da Binance
        lado = "BUY" if sinal["classe"].lower() == "compra" else "SELL"
        
        # Obter preço atual (simulado para teste)
        preco_atual = 30000.0 if sinal["ativo"] == "BTCUSDT" else 2000.0
        
        # Validar ordem
        valido, motivo = await risk_manager.validar_ordem(
            sinal["ativo"], 
            lado, 
            sinal["quantidade"], 
            preco_atual
        )
        
        if valido:
            logger.info(f"✅ Validação de risco APROVADA para {sinal['ativo']} {sinal['classe']}")
        else:
            logger.warning(f"⚠️ Validação de risco REJEITADA para {sinal['ativo']} {sinal['classe']}: {motivo}")
        
        return valido, motivo
    except Exception as e:
        logger.error(f"❌ Erro na validação de risco: {e}")
        return False, f"Erro: {str(e)}"

# Teste de execução de ordem
async def testar_execucao_ordem(config: Dict[str, Any], sinal: Dict[str, Any], api_key: str, api_secret: str) -> Dict[str, Any]:
    """Testa a execução de uma ordem."""
    logger.info(f"🔍 Testando execução de ordem para sinal: {sinal['ativo']} {sinal['classe']}")
    
    try:
        # Verificar modo de simulação
        modo_simulacao = config.get('modo_simulacao', False)  # Default para modo real
        executar_ordens_reais = config.get('executar_ordens_reais', True)  # Default para executar ordens reais
        testnet = config.get('testnet', True)
        
        if modo_simulacao:
            logger.warning("⚠️ Sistema em modo de simulação. Ordem NÃO será enviada para a Binance.")
            # Simular resultado de ordem
            resultado_simulado = {
                "status": "SIMULADO",
                "symbol": sinal["ativo"],
                "orderId": int(time.time() * 1000),
                "clientOrderId": f"simulated_{int(time.time() * 1000)}",
                "transactTime": int(time.time() * 1000),
                "price": "0.00000000",
                "origQty": str(sinal["quantidade"]),
                "executedQty": str(sinal["quantidade"]),
                "status": "FILLED",
                "timeInForce": "GTC",
                "type": "MARKET",
                "side": "BUY" if sinal["classe"].lower() == "compra" else "SELL"
            }
            logger.info(f"✅ Ordem SIMULADA executada com sucesso: {resultado_simulado}")
            return {"status": "SIMULADO", **resultado_simulado}
        
        if not executar_ordens_reais:
            logger.warning("⚠️ Execução de ordens reais DESATIVADA. Ordem NÃO será enviada para a Binance.")
            return {"status": "DISABLED", "reason": "Execução de ordens reais desativada"}
        
        # Inicializar OperadorBinance
        operador = OperadorBinance(
            api_key=api_key,
            api_secret=api_secret,
            testnet=testnet,
            config=config
        )
        
        # Inicializar cliente
        inicializado = await operador.inicializar()
        if not inicializado:
            logger.error("❌ Falha ao inicializar cliente Binance.")
            return {"status": "ERROR", "reason": "Falha ao inicializar cliente Binance"}
        
        # Mapear tipo para formato da Binance
        lado = "BUY" if sinal["classe"].lower() == "compra" else "SELL"
        
        # Executar ordem
        resultado = await operador.criar_ordem(
            simbolo=sinal["ativo"],
            lado=lado,
            tipo="MARKET",
            quantidade=sinal["quantidade"],
            preco=sinal["preco"]
        )
        
        # Fechar cliente
        await operador.fechar_cliente()
        
        if resultado.get("status") == "SUCCESS":
            logger.info(f"✅ Ordem REAL executada com sucesso: {resultado}")
        else:
            logger.warning(f"⚠️ Falha ao executar ordem REAL: {resultado}")
        
        return resultado
    except Exception as e:
        logger.error(f"❌ Erro na execução de ordem: {e}")
        return {"status": "ERROR", "reason": str(e)}

# Teste de fluxo completo
async def testar_fluxo_completo(config: Dict[str, Any], api_key: str, api_secret: str) -> Dict[str, Any]:
    """Testa o fluxo completo de execução de ordens."""
    logger.info("\n" + "=" * 50)
    logger.info("INICIANDO TESTE DE FLUXO COMPLETO EM MODO REAL")
    logger.info("=" * 50)
    
    resultados = {}
    
    # Testar diferentes tipos de sinais
    sinais_teste = [
        # Sinal de compra com alta probabilidade (deve passar)
        criar_sinal_teste(simbolo="BTCUSDT", tipo="compra", probabilidade=0.85),
        # Sinal de venda com alta probabilidade (deve passar)
        criar_sinal_teste(simbolo="ETHUSDT", tipo="venda", probabilidade=0.82),
        # Sinal de compra com baixa probabilidade (deve falhar na validação contextual)
        criar_sinal_teste(simbolo="BNBUSDT", tipo="compra", probabilidade=0.45),
        # Sinal de venda com quantidade muito pequena (deve falhar na validação de risco)
        {**criar_sinal_teste(simbolo="BTCUSDT", tipo="venda", probabilidade=0.80), "quantidade": 0.00001}
    ]
    
    for idx, sinal in enumerate(sinais_teste):
        logger.info(f"\n--- Testando Sinal #{idx+1}: {sinal['ativo']} {sinal['classe']} (prob: {sinal['probabilidade']}) ---")
        
        # Etapa 1: Validação Contextual
        validacao_contextual = await testar_validacao_contextual(sinal)
        if not validacao_contextual:
            logger.warning(f"⚠️ Sinal #{idx+1} rejeitado na validação contextual. Pulando próximas etapas.")
            resultados[f"sinal_{idx+1}"] = {
                "sinal": sinal,
                "validacao_contextual": False,
                "validacao_risco": None,
                "execucao_ordem": None
            }
            continue
        
        # Etapa 2: Validação de Risco
        validacao_risco, motivo_risco = await testar_validacao_risco(config, sinal)
        if not validacao_risco:
            logger.warning(f"⚠️ Sinal #{idx+1} rejeitado na validação de risco: {motivo_risco}. Pulando próxima etapa.")
            resultados[f"sinal_{idx+1}"] = {
                "sinal": sinal,
                "validacao_contextual": True,
                "validacao_risco": False,
                "motivo_risco": motivo_risco,
                "execucao_ordem": None
            }
            continue
        
        # Etapa 3: Execução de Ordem
        resultado_ordem = await testar_execucao_ordem(config, sinal, api_key, api_secret)
        
        resultados[f"sinal_{idx+1}"] = {
            "sinal": sinal,
            "validacao_contextual": True,
            "validacao_risco": True,
            "execucao_ordem": resultado_ordem
        }
    
    # Resumo dos resultados
    logger.info("\n" + "=" * 50)
    logger.info("RESUMO DOS RESULTADOS")
    logger.info("=" * 50)
    
    for idx, (key, resultado) in enumerate(resultados.items()):
        sinal = resultado["sinal"]
        validacao_contextual = resultado["validacao_contextual"]
        validacao_risco = resultado["validacao_risco"]
        execucao_ordem = resultado["execucao_ordem"]
        
        status = "❌ REJEITADO"
        if validacao_contextual and validacao_risco and execucao_ordem and execucao_ordem.get("status") in ["SUCCESS", "SIMULADO"]:
            status = "✅ EXECUTADO"
        elif validacao_contextual and validacao_risco:
            status = "⚠️ FALHA NA EXECUÇÃO"
        elif validacao_contextual:
            status = "⚠️ REJEITADO (RISCO)"
        else:
            status = "⚠️ REJEITADO (CONTEXTO)"
        
        logger.info(f"Sinal #{idx+1} ({sinal['ativo']} {sinal['classe']}): {status}")
    
    logger.info("\n" + "=" * 50)
    logger.info("FIM DO TESTE DE FLUXO COMPLETO")
    logger.info("=" * 50)
    
    return resultados

# Função principal assíncrona
async def main():
    """Função principal que executa todos os testes."""
    logger.info("=" * 50)
    logger.info("INICIANDO TESTES DE EXECUÇÃO DE ORDENS KR_KRIPTO_ADVANCED EM MODO REAL")
    logger.info("=" * 50)
    
    # Detectar ambiente
    is_mac_m1 = detectar_mac_m1()
    
    # Carregar configuração
    config = carregar_configuracao()
    
    # Obter credenciais
    api_key, api_secret = obter_credenciais()
    
    # Verificar se as credenciais foram encontradas
    if not api_key or not api_secret:
        logger.critical("❌ CREDENCIAIS DA API BINANCE NÃO ENCONTRADAS. ABORTANDO TESTE.")
        return {"status": "ERROR", "reason": "Credenciais da API Binance não encontradas"}
    
    # Confirmar modo real
    logger.warning("⚠️ ATENÇÃO: TESTE SERÁ EXECUTADO EM MODO REAL!")
    logger.warning("⚠️ ORDENS REAIS SERÃO ENVIADAS PARA A BINANCE!")
    logger.warning(f"⚠️ AMBIENTE: {'TESTNET' if config.get('testnet', True) else 'PRODUÇÃO'}")
    
    # Executar teste de fluxo completo
    resultados = await testar_fluxo_completo(config, api_key, api_secret)
    
    # Salvar resultados em JSON
    try:
        with open('teste_execucao_real_resultados.json', 'w') as f:
            # Converter dados não serializáveis
            resultados_json = json.dumps(resultados, default=lambda o: str(o) if not isinstance(o, (dict, list, str, int, float, bool, type(None))) else o, indent=2)
            f.write(resultados_json)
        logger.info("✅ Resultados dos testes salvos em 'teste_execucao_real_resultados.json'")
    except Exception as e:
        logger.error(f"❌ Erro ao salvar resultados: {e}")
    
    return resultados

if __name__ == "__main__":
    resultados = asyncio.run(main())
