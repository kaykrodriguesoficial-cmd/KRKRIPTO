#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de teste final para validar as correções implementadas no sistema KR_KRIPTO_ADVANCED.
Este script testa a inicialização dos componentes corrigidos e verifica se o sistema
consegue inicializar completamente sem erros.
"""

import os
import sys
import logging
import time
from datetime import datetime
import traceback

# Configurar logging
os.makedirs("logs", exist_ok=True)
log_file = f"logs/teste_final_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(log_file)
    ]
)

logger = logging.getLogger("kr_kripto_teste_final")

# Adicionar diretório atual ao path
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

# Adicionar diretório do projeto ao path
project_dir = os.path.join(current_dir, "kr_kripto", "KR_KRIPTO_ADVANCED_V6")
if os.path.exists(project_dir) and project_dir not in sys.path:
    sys.path.insert(0, project_dir)

# Carregar variáveis de ambiente do arquivo .env
def carregar_env():
    """Carrega variáveis de ambiente do arquivo .env"""
    logger.info("Carregando variáveis de ambiente...")
    
    # Lista de possíveis locais para o arquivo .env
    env_paths = [
        os.path.join(current_dir, ".env"),
        os.path.join(current_dir, "upload", ".env"),
        os.path.join(os.path.expanduser("~"), ".env")
    ]
    
    env_file = None
    for path in env_paths:
        if os.path.exists(path):
            env_file = path
            logger.info(f"Arquivo .env encontrado em: {path}")
            break
    
    if not env_file:
        logger.warning("Arquivo .env não encontrado. Usando variáveis de ambiente existentes.")
        return
    
    # Carregar variáveis do arquivo .env
    with open(env_file, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
                
            key, value = line.split("=", 1)
            os.environ[key] = value
            # Log seguro (não mostra valores completos de chaves secretas)
            if "SECRET" in key or "KEY" in key:
                masked_value = value[:4] + "..." + value[-4:] if len(value) > 8 else "***"
                logger.info(f"Variável {key}={masked_value} carregada")
            else:
                logger.info(f"Variável {key}={value} carregada")

# Função para testar o PrometheusExporter
def testar_prometheus_exporter():
    """Testa a inicialização e funcionamento do PrometheusExporter corrigido"""
    logger.info("=== Testando PrometheusExporter ===")
    
    try:
        # Tentar importar o PrometheusExporter
        from src.infrastructure.prometheus_exporter import PrometheusExporter
        
        # Inicializar o PrometheusExporter
        exporter = PrometheusExporter()
        logger.info("PrometheusExporter inicializado com sucesso")
        
        # Testar criação de métricas
        counter = exporter.counter("kr_test_counter", "Contador de teste")
        gauge = exporter.gauge("kr_test_gauge", "Gauge de teste")
        histogram = exporter.histogram("kr_test_histogram", "Histograma de teste")
        
        # Testar operações nas métricas
        counter.inc()
        gauge.set(42)
        histogram.observe(0.1)
        
        logger.info("Métricas criadas e atualizadas com sucesso")
        
        # Testar criação de uma segunda instância para verificar se não há conflitos
        exporter2 = PrometheusExporter()
        counter2 = exporter2.counter("kr_test_counter", "Contador de teste")
        counter2.inc(2)
        
        logger.info("Segunda instância criada e métricas atualizadas sem conflitos")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao testar PrometheusExporter: {e}")
        logger.debug(traceback.format_exc())
        return False

# Função para testar o NeuralGovernor
def testar_neural_governor():
    """Testa a inicialização e funcionamento do NeuralGovernor corrigido"""
    logger.info("=== Testando NeuralGovernor ===")
    
    try:
        # Tentar importar o NeuralGovernor
        from src.intelligence.governance.neural_governance import NeuralGovernor, ModelPerformanceTracker
        
        # Inicializar o NeuralGovernor apenas com config
        config = {
            "selection_strategy": "best_recent",
            "governance_models": [
                {
                    "id": "model1",
                    "path": "models/model1.h5",
                    "type": "keras",
                    "enabled": True
                }
            ]
        }
        
        governor = NeuralGovernor(config=config)
        logger.info("NeuralGovernor inicializado com sucesso (apenas com config)")
        
        # Inicializar NeuralGovernor com tracker explícito
        tracker = ModelPerformanceTracker(config)
        governor2 = NeuralGovernor(config=config, tracker=tracker)
        logger.info("NeuralGovernor inicializado com sucesso (com tracker explícito)")
        
        # Testar seleção de modelo
        model_id = governor.select_model_id()
        logger.info(f"Modelo selecionado: {model_id}")
        
        # Testar método registrar_predicao do tracker
        tracker.registrar_predicao("model1", 0.75, 1)
        logger.info("Método registrar_predicao executado com sucesso")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao testar NeuralGovernor: {e}")
        logger.debug(traceback.format_exc())
        return False

# Função principal para executar todos os testes
def executar_testes():
    """Executa todos os testes finais"""
    logger.info("=== INICIANDO TESTES FINAIS ===")
    
    # Carregar variáveis de ambiente
    carregar_env()
    
    # Resultados dos testes
    resultados = {}
    
    # Testar PrometheusExporter
    resultados["prometheus_exporter"] = testar_prometheus_exporter()
    
    # Testar NeuralGovernor
    resultados["neural_governor"] = testar_neural_governor()
    
    # Resumo dos resultados
    logger.info("=== RESUMO DOS TESTES FINAIS ===")
    for componente, resultado in resultados.items():
        status = "PASSOU" if resultado else "FALHOU"
        logger.info(f"{componente}: {status}")
    
    # Verificar se todos os testes passaram
    todos_passaram = all(resultados.values())
    if todos_passaram:
        logger.info("✅ TODOS OS TESTES PASSARAM! Os componentes corrigidos estão funcionando corretamente.")
    else:
        logger.error("❌ ALGUNS TESTES FALHARAM. Verifique os logs para mais detalhes.")
    
    logger.info(f"Log completo disponível em: {log_file}")
    logger.info("=== TESTES FINAIS CONCLUÍDOS ===")
    
    return todos_passaram, resultados

# Executar testes se o script for executado diretamente
if __name__ == "__main__":
    sucesso, resultados = executar_testes()
    sys.exit(0 if sucesso else 1)
