#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de teste final para validar a integração completa do sistema KR_KRIPTO_ADVANCED
após as correções implementadas no PrometheusExporter e NeuralGovernor.

Este script testa:
1. Inicialização do PrometheusExporter em diferentes caminhos de importação
2. Criação e atualização de métricas sem conflitos de duplicação
3. Inicialização do NeuralGovernor com diferentes configurações
4. Integração entre os componentes corrigidos

Versão: 2.0.0
Data: 2025-06-03
"""

import os
import sys
import time
import logging
import uuid
import json
from datetime import datetime
from typing import Dict, Any, List, Optional

# Configurar logging
log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, f"teste_final_completo_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("kr_kripto_teste_final")

# Adicionar diretórios ao path para importação
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(current_dir, "src")
kr_kripto_dir = os.path.join(current_dir, "kr_kripto", "KR_KRIPTO_ADVANCED_V6", "src")

sys.path.extend([current_dir, src_dir, kr_kripto_dir])

# Carregar variáveis de ambiente
try:
    from dotenv import load_dotenv
    # Tentar carregar de diferentes locais
    env_paths = [
        os.path.join(current_dir, ".env"),
        os.path.join(current_dir, "upload", ".env"),
        os.path.join(os.path.expanduser("~"), ".env")
    ]
    
    env_loaded = False
    for env_path in env_paths:
        if os.path.exists(env_path):
            load_dotenv(env_path)
            logger.info(f"Variáveis de ambiente carregadas de {env_path}")
            env_loaded = True
            break
    
    if not env_loaded:
        logger.warning("Arquivo .env não encontrado. Usando variáveis de ambiente existentes.")
except ImportError:
    logger.warning("python-dotenv não encontrado. Usando variáveis de ambiente existentes.")

# Resultados dos testes
test_results = {
    "timestamp": datetime.now().isoformat(),
    "resultados": {},
    "todos_passaram": True
}

def test_prometheus_exporter_infrastructure():
    """Testa o PrometheusExporter do caminho infrastructure."""
    logger.info("=== Testando PrometheusExporter (infrastructure) ===")
    try:
        # Tentar importar do caminho infrastructure
        sys.path.insert(0, os.path.join(current_dir, "src"))
        from infrastructure.prometheus_exporter import PrometheusExporter, create_counter, create_gauge
        
        # Criar instância
        exporter = PrometheusExporter()
        logger.info("PrometheusExporter (infrastructure) inicializado com sucesso")
        
        # Criar métricas
        counter = create_counter("test_counter", "Contador de teste")
        gauge = create_gauge("test_gauge", "Gauge de teste")
        
        # Atualizar métricas
        counter.inc()
        gauge.set(42)
        logger.info("Métricas criadas e atualizadas com sucesso")
        
        # Criar segunda instância para testar isolamento
        exporter2 = PrometheusExporter()
        counter2 = exporter2.counter("test_counter", "Contador de teste duplicado")
        counter2.inc(2)
        logger.info("Segunda instância criada e métricas atualizadas sem conflitos")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao testar PrometheusExporter (infrastructure): {e}", exc_info=True)
        return False

def test_prometheus_exporter_monitoring():
    """Testa o PrometheusExporter do caminho monitoring."""
    logger.info("=== Testando PrometheusExporter (monitoring) ===")
    try:
        # Tentar importar do caminho monitoring
        sys.path.insert(0, os.path.join(current_dir, "src"))
        from monitoring.prometheus_exporter import PrometheusExporter, create_counter, create_gauge
        
        # Criar instância
        exporter = PrometheusExporter()
        logger.info("PrometheusExporter (monitoring) inicializado com sucesso")
        
        # Criar métricas
        counter = create_counter("test_counter_mon", "Contador de teste")
        gauge = create_gauge("test_gauge_mon", "Gauge de teste")
        
        # Atualizar métricas
        counter.inc()
        gauge.set(42)
        logger.info("Métricas criadas e atualizadas com sucesso")
        
        # Criar segunda instância para testar isolamento
        exporter2 = PrometheusExporter()
        counter2 = exporter2.counter("test_counter_mon", "Contador de teste duplicado")
        counter2.inc(2)
        logger.info("Segunda instância criada e métricas atualizadas sem conflitos")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao testar PrometheusExporter (monitoring): {e}", exc_info=True)
        return False

def test_neural_governor():
    """Testa o NeuralGovernor."""
    logger.info("=== Testando NeuralGovernor ===")
    try:
        # Tentar importar do caminho correto
        sys.path.insert(0, kr_kripto_dir)
        from intelligence.governance.neural_governance import NeuralGovernor
        
        # Criar instância apenas com config
        config = {"selection_strategy": "best_recent"}
        governor = NeuralGovernor(config)
        logger.info("NeuralGovernor inicializado com sucesso (apenas com config)")
        
        # Criar instância com tracker explícito
        class MockTracker:
            def get_best_model(self):
                return "model1"
            
            def registrar_predicao(self, model_id, prediction, actual):
                return True
            
            def record_prediction(self, model_id, prediction, actual):
                return True
        
        tracker = MockTracker()
        governor2 = NeuralGovernor(config, tracker=tracker)
        logger.info("NeuralGovernor inicializado com sucesso (com tracker explícito)")
        
        # Testar seleção de modelo
        selected_model = governor2.select_model()
        logger.info(f"Modelo selecionado: {selected_model}")
        
        # Testar método registrar_predicao
        result = governor2.registrar_predicao("model1", 0.75, 1)
        logger.info("Método registrar_predicao executado com sucesso")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao testar NeuralGovernor: {e}", exc_info=True)
        return False

def test_integration():
    """Testa a integração entre os componentes corrigidos."""
    logger.info("=== Testando Integração entre Componentes ===")
    try:
        # Importar componentes
        sys.path.insert(0, os.path.join(current_dir, "src"))
        from infrastructure.prometheus_exporter import PrometheusExporter, set_component_operational_status
        
        sys.path.insert(0, kr_kripto_dir)
        from intelligence.governance.neural_governance import NeuralGovernor
        
        # Criar instâncias
        exporter = PrometheusExporter()
        governor = NeuralGovernor({"selection_strategy": "best_recent"})
        
        # Registrar status do NeuralGovernor no PrometheusExporter
        set_component_operational_status("neural_governor", "BTCUSDT", True)
        logger.info("Integração entre PrometheusExporter e NeuralGovernor testada com sucesso")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao testar integração entre componentes: {e}", exc_info=True)
        return False

def run_tests():
    """Executa todos os testes e retorna os resultados."""
    # Testar PrometheusExporter (infrastructure)
    test_results["resultados"]["prometheus_exporter_infrastructure"] = test_prometheus_exporter_infrastructure()
    
    # Testar PrometheusExporter (monitoring)
    test_results["resultados"]["prometheus_exporter_monitoring"] = test_prometheus_exporter_monitoring()
    
    # Testar NeuralGovernor
    test_results["resultados"]["neural_governor"] = test_neural_governor()
    
    # Testar integração
    test_results["resultados"]["integracao"] = test_integration()
    
    # Verificar se todos os testes passaram
    test_results["todos_passaram"] = all(test_results["resultados"].values())
    
    # Salvar resultados em arquivo JSON
    results_file = os.path.join(log_dir, f"resultado_testes_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
    with open(results_file, "w") as f:
        json.dump(test_results, f, indent=2)
    
    return test_results

if __name__ == "__main__":
    logger.info("Iniciando testes finais do sistema KR_KRIPTO_ADVANCED")
    
    # Executar testes
    results = run_tests()
    
    # Exibir resumo
    logger.info("=== RESUMO DOS TESTES FINAIS ===")
    for test_name, result in results["resultados"].items():
        logger.info(f"{test_name}: {'PASSOU' if result else 'FALHOU'}")
    
    if results["todos_passaram"]:
        logger.info("✅ TODOS OS TESTES PASSARAM! Os componentes corrigidos estão funcionando corretamente.")
    else:
        logger.error("❌ ALGUNS TESTES FALHARAM. Verifique os logs para mais detalhes.")
    
    logger.info(f"Logs salvos em: {log_file}")
    logger.info(f"Resultados salvos em: {os.path.join(log_dir, f'resultado_testes_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json')}")
