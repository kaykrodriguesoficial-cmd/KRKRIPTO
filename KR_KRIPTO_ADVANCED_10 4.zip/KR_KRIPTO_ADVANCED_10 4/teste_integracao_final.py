#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Teste de integração final para o sistema KR_KRIPTO_ADVANCED.
Este script testa a integração entre todos os componentes corrigidos.
Versão 2: Corrigida para usar os caminhos corretos dos arquivos.
"""

import os
import sys
import logging
import asyncio
import json
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List

# Configurar logging
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(f"logs/teste_integracao_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    ]
)

logger = logging.getLogger("kr_kripto_teste_integracao")

# Adicionar diretório atual ao path
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

# Carregar variáveis de ambiente do arquivo .env
def carregar_env():
    """Carrega variáveis de ambiente do arquivo .env"""
    logger.info("Carregando variáveis de ambiente...")
    
    # Lista de possíveis locais para o arquivo .env
    env_paths = [
        os.path.join(current_dir, ".env"),
        os.path.join(current_dir, "upload", ".env"),
        os.path.join(os.path.expanduser("~"), ".env")
    ]
    
    env_file = None
    for path in env_paths:
        if os.path.exists(path):
            env_file = path
            logger.info(f"Arquivo .env encontrado em: {path}")
            break
    
    if not env_file:
        logger.warning("Arquivo .env não encontrado. Usando variáveis de ambiente existentes.")
        return
    
    # Carregar variáveis do arquivo .env
    with open(env_file, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
                
            key, value = line.split("=", 1)
            os.environ[key] = value
            # Log seguro (não mostra valores completos de chaves secretas)
            if "SECRET" in key or "KEY" in key:
                masked_value = value[:4] + "..." + value[-4:] if len(value) > 8 else "***"
                logger.info(f"Variável {key}={masked_value} carregada")
            else:
                logger.info(f"Variável {key}={value} carregada")

# Função para testar o OperadorBinance
async def testar_operador_binance():
    """Testa a conexão e funcionalidades do OperadorBinance"""
    logger.info("=== Testando OperadorBinance ===")
    
    try:
        # Importar OperadorBinance
        # Primeiro, verificar se o arquivo existe no diretório atual
        if os.path.exists(os.path.join(current_dir, "upload", "operador.py")):
            sys.path.append(os.path.join(current_dir, "upload"))
            from operador import OperadorBinance
            logger.info("OperadorBinance importado de upload/operador.py")
        elif os.path.exists(os.path.join(current_dir, "operador_corrigido.py")):
            # Importar do arquivo corrigido
            from operador_corrigido import OperadorBinance
            logger.info("OperadorBinance importado de operador_corrigido.py")
        else:
            logger.error("Arquivo operador.py não encontrado")
            return False
        
        # Obter credenciais da API Binance
        api_key = os.environ.get("BINANCE_API_KEY") or os.environ.get("KR_BINANCE_API_KEY")
        api_secret = os.environ.get("BINANCE_API_SECRET") or os.environ.get("KR_BINANCE_API_SECRET")
        
        if not api_key or not api_secret:
            logger.error("Credenciais da API Binance não encontradas nas variáveis de ambiente")
            return False
            
        # Inicializar OperadorBinance
        config = {
            "binance_api_key": api_key,
            "binance_api_secret": api_secret,
            "testnet": False
        }
        
        operador = OperadorBinance(config=config)
        logger.info("OperadorBinance inicializado")
        
        # Inicializar cliente
        inicializado = await operador.inicializar()
        if not inicializado:
            logger.error("Falha ao inicializar cliente Binance")
            return False
            
        logger.info("Cliente Binance inicializado com sucesso")
        
        # Testar obtenção de preço
        simbolo = "BTCUSDT"
        preco = await operador.obter_preco_atual(simbolo)
        if preco is None:
            logger.error(f"Falha ao obter preço atual de {simbolo}")
            return False
            
        logger.info(f"Preço atual de {simbolo}: {preco}")
        
        # Testar obtenção de saldo
        saldo = await operador.obter_saldo("USDT")
        if saldo is not None:
            logger.info(f"Saldo USDT: {saldo}")
        else:
            logger.warning("Não foi possível obter saldo USDT")
        
        # Fechar cliente
        await operador.fechar_cliente()
        logger.info("Cliente Binance fechado com sucesso")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao testar OperadorBinance: {e}", exc_info=True)
        return False

# Função para testar o ExecutorContextual
async def testar_executor_contextual():
    """Testa a integração do ExecutorContextual com o OperadorBinance"""
    logger.info("=== Testando ExecutorContextual ===")
    
    try:
        # Importar ExecutorContextual corrigido
        # Verificar diferentes locais possíveis
        if os.path.exists(os.path.join(current_dir, "executor_contextual_corrigido_v2.py")):
            from executor_contextual_corrigido_v2 import ExecutorContextual
            logger.info("ExecutorContextual importado de executor_contextual_corrigido_v2.py")
        elif os.path.exists(os.path.join(current_dir, "executor_contextual_corrigido.py")):
            from executor_contextual_corrigido import ExecutorContextual
            logger.info("ExecutorContextual importado de executor_contextual_corrigido.py")
        else:
            logger.error("Arquivo executor_contextual_corrigido.py não encontrado")
            return False
        
        # Obter credenciais da API Binance
        api_key = os.environ.get("BINANCE_API_KEY") or os.environ.get("KR_BINANCE_API_KEY")
        api_secret = os.environ.get("BINANCE_API_SECRET") or os.environ.get("KR_BINANCE_API_SECRET")
        
        if not api_key or not api_secret:
            logger.error("Credenciais da API Binance não encontradas nas variáveis de ambiente")
            return False
            
        # Inicializar ExecutorContextual
        config = {
            "api_key": api_key,
            "api_secret": api_secret,
            "testnet": False,
            "max_tentativas": 3,
            "delay_entre_tentativas": 1
        }
        
        executor = ExecutorContextual(config=config)
        logger.info("ExecutorContextual inicializado")
        
        # Inicializar
        inicializado = await executor.inicializar()
        if not inicializado:
            logger.error("Falha ao inicializar ExecutorContextual")
            return False
            
        logger.info("ExecutorContextual inicializado com sucesso")
        
        # Testar obtenção de contexto
        simbolo = "BTCUSDT"
        contexto = await executor.obter_contexto(simbolo)
        if contexto is None:
            logger.error(f"Falha ao obter contexto para {simbolo}")
            return False
            
        logger.info(f"Contexto obtido para {simbolo}: preço atual = {contexto['preco_atual']}")
        
        # Testar validação de sinal
        sinal = {
            "simbolo": simbolo,
            "lado": "BUY",
            "tipo": "LIMIT",
            "quantidade": 0.001,
            "preco": contexto["preco_atual"] * 0.95
        }
        
        valido, motivo = await executor.validar_sinal(sinal)
        logger.info(f"Validação do sinal: {valido}, motivo: {motivo}")
        
        # Fechar executor
        await executor.fechar()
        logger.info("ExecutorContextual fechado com sucesso")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao testar ExecutorContextual: {e}", exc_info=True)
        return False

# Função para testar o ClusterManager
def testar_cluster_manager():
    """Testa a inicialização do ClusterManager corrigido"""
    logger.info("=== Testando ClusterManager ===")
    
    try:
        # Importar ClusterManager corrigido
        # Verificar diferentes locais possíveis
        if os.path.exists(os.path.join(current_dir, "cluster_manager_corrigido.py")):
            from cluster_manager_corrigido import ClusterManager
            logger.info("ClusterManager importado de cluster_manager_corrigido.py")
        else:
            logger.error("Arquivo cluster_manager_corrigido.py não encontrado")
            return False
        
        # Inicializar ClusterManager
        config = {
            "cluster_config": {
                "pub_port": 5555,
                "sub_port": 5556,
                "sync_port": 5557,
                "heartbeat_port": 5558,
                "master_host": "*",
                "worker_master_addr": "localhost",
                "heartbeat_interval_sec": 2,
                "heartbeat_timeout_sec": 6
            }
        }
        
        # Testar inicialização como master
        master = ClusterManager(config=config, node_type="master")
        logger.info("ClusterManager (master) inicializado com sucesso")
        
        # Testar inicialização como worker
        worker = ClusterManager(config=config, node_type="worker")
        logger.info("ClusterManager (worker) inicializado com sucesso")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao testar ClusterManager: {e}", exc_info=True)
        return False

# Função para testar o ModelPerformanceTracker
def testar_model_performance_tracker():
    """Testa a inicialização e métodos do ModelPerformanceTracker corrigido"""
    logger.info("=== Testando ModelPerformanceTracker ===")
    
    try:
        # Importar ModelPerformanceTracker corrigido
        # Verificar diferentes locais possíveis
        if os.path.exists(os.path.join(current_dir, "model_performance_tracker_corrigido.py")):
            from model_performance_tracker_corrigido import ModelPerformanceTracker
            logger.info("ModelPerformanceTracker importado de model_performance_tracker_corrigido.py")
        else:
            logger.error("Arquivo model_performance_tracker_corrigido.py não encontrado")
            return False
        
        # Inicializar ModelPerformanceTracker
        config = {
            "window_size": 50,
            "storage_path": "data/model_performance"
        }
        
        tracker = ModelPerformanceTracker(config=config)
        logger.info("ModelPerformanceTracker inicializado com sucesso")
        
        # Testar registro de modelo
        model_id = "test_model"
        model_object = {"name": "Test Model"}
        tracker.register_model(model_id, model_object)
        logger.info(f"Modelo {model_id} registrado com sucesso")
        
        # Testar registro de predição (método em inglês)
        tracker.record_prediction(model_id, 0.75, 1)
        logger.info("Predição registrada com sucesso (método em inglês)")
        
        # Testar registro de predição (método em português)
        tracker.registrar_predicao(model_id, 0.65, 0)
        logger.info("Predição registrada com sucesso (método em português)")
        
        # Testar obtenção de desempenho
        performance = tracker.get_performance(model_id)
        logger.info(f"Desempenho do modelo {model_id}: {performance}")
        
        # Testar obtenção de melhor modelo
        best_model = tracker.get_best_model(min_samples=1)
        logger.info(f"Melhor modelo: {best_model}")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao testar ModelPerformanceTracker: {e}", exc_info=True)
        return False

# Função para testar o NeuralGovernor
def testar_neural_governor():
    """Testa a inicialização e métodos do NeuralGovernor corrigido"""
    logger.info("=== Testando NeuralGovernor ===")
    
    try:
        # Importar NeuralGovernor corrigido
        # Verificar diferentes locais possíveis
        if os.path.exists(os.path.join(current_dir, "neural_governor_corrigido.py")):
            from neural_governor_corrigido import NeuralGovernor
            # Importar ModelPerformanceTracker para uso com NeuralGovernor
            if os.path.exists(os.path.join(current_dir, "model_performance_tracker_corrigido.py")):
                from model_performance_tracker_corrigido import ModelPerformanceTracker
            else:
                # Criar stub para ModelPerformanceTracker
                class ModelPerformanceTracker:
                    def __init__(self, config=None):
                        self.config = config or {}
                    
                    def registrar_predicao(self, model_id, prediction, actual):
                        return True
                    
                    def get_best_model(self, metric="accuracy", min_samples=10):
                        return "model1"
            
            logger.info("NeuralGovernor importado de neural_governor_corrigido.py")
        else:
            logger.error("Arquivo neural_governor_corrigido.py não encontrado")
            return False
        
        # Inicializar NeuralGovernor apenas com config
        config = {
            "selection_strategy": "best_recent",
            "governance_models": [
                {
                    "id": "model1",
                    "path": "models/model1.h5",
                    "type": "keras",
                    "enabled": True
                }
            ]
        }
        
        governor = NeuralGovernor(config=config)
        logger.info("NeuralGovernor inicializado com sucesso (apenas com config)")
        
        # Inicializar NeuralGovernor com tracker explícito
        tracker = ModelPerformanceTracker(config)
        governor2 = NeuralGovernor(config=config, tracker=tracker)
        logger.info("NeuralGovernor inicializado com sucesso (com tracker explícito)")
        
        # Testar seleção de modelo
        model_id = governor.select_model_id()
        logger.info(f"Modelo selecionado: {model_id}")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao testar NeuralGovernor: {e}", exc_info=True)
        return False

# Função para copiar arquivos corrigidos para o diretório de teste
def copiar_arquivos_corrigidos():
    """Copia os arquivos corrigidos para o diretório de teste"""
    logger.info("=== Copiando arquivos corrigidos para o diretório de teste ===")
    
    try:
        import shutil
        
        # Lista de arquivos a serem copiados
        arquivos = [
            "executor_contextual_corrigido_v2.py",
            "cluster_manager_corrigido.py",
            "model_performance_tracker_corrigido.py",
            "neural_governor_corrigido.py"
        ]
        
        # Diretório de destino (onde o teste está sendo executado)
        destino = os.path.dirname(os.path.abspath(__file__))
        
        # Copiar cada arquivo
        for arquivo in arquivos:
            # Verificar diferentes locais possíveis
            locais = [
                os.path.join(current_dir, arquivo),
                os.path.join(current_dir, "upload", arquivo),
                os.path.join(os.path.expanduser("~"), arquivo)
            ]
            
            for local in locais:
                if os.path.exists(local):
                    shutil.copy2(local, os.path.join(destino, arquivo))
                    logger.info(f"Arquivo {arquivo} copiado de {local} para {destino}")
                    break
            else:
                logger.warning(f"Arquivo {arquivo} não encontrado")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao copiar arquivos corrigidos: {e}", exc_info=True)
        return False

# Função principal para executar todos os testes
async def executar_testes():
    """Executa todos os testes de integração"""
    logger.info("=== INICIANDO TESTES DE INTEGRAÇÃO FINAL ===")
    
    # Carregar variáveis de ambiente
    carregar_env()
    
    # Copiar arquivos corrigidos para o diretório de teste
    copiar_arquivos_corrigidos()
    
    # Resultados dos testes
    resultados = {}
    
    # Testar OperadorBinance
    resultados["operador_binance"] = await testar_operador_binance()
    
    # Testar ExecutorContextual
    resultados["executor_contextual"] = await testar_executor_contextual()
    
    # Testar ClusterManager
    resultados["cluster_manager"] = testar_cluster_manager()
    
    # Testar ModelPerformanceTracker
    resultados["model_performance_tracker"] = testar_model_performance_tracker()
    
    # Testar NeuralGovernor
    resultados["neural_governor"] = testar_neural_governor()
    
    # Resumo dos resultados
    logger.info("=== RESUMO DOS TESTES DE INTEGRAÇÃO ===")
    for componente, resultado in resultados.items():
        status = "PASSOU" if resultado else "FALHOU"
        logger.info(f"{componente}: {status}")
    
    # Verificar se todos os testes passaram
    todos_passaram = all(resultados.values())
    if todos_passaram:
        logger.info("✅ TODOS OS TESTES PASSARAM! O sistema está funcionando corretamente.")
    else:
        logger.error("❌ ALGUNS TESTES FALHARAM. Verifique os logs para mais detalhes.")
    
    # Salvar resultados em arquivo JSON
    resultado_file = f"logs/resultado_testes_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(resultado_file, "w") as f:
        json.dump({
            "timestamp": datetime.now().isoformat(),
            "resultados": resultados,
            "todos_passaram": todos_passaram
        }, f, indent=2)
    
    logger.info(f"Resultados salvos em: {resultado_file}")
    logger.info("=== TESTES DE INTEGRAÇÃO FINAL CONCLUÍDOS ===")
    
    return todos_passaram

# Executar testes se o script for executado diretamente
if __name__ == "__main__":
    asyncio.run(executar_testes())
