#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Suite de Testes - Sistema Multi-Timeframe MASTER
Validação completa do sistema de confluência temporal
"""

import pandas as pd
import numpy as np
import sys
import os
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any
import json

# Adicionar o diretório atual ao path
sys.path.append(os.getcwd())

try:
    from analise_multitimeframe import MultiTimeframeAnalyzer, analisar_multitimeframe_completo
    print("✅ Módulo MultiTimeframeAnalyzer importado com sucesso")
except ImportError as e:
    print(f"❌ Erro ao importar: {e}")
    sys.exit(1)

class TesteSuiteMultiTimeframe:
    """
    Suite completa de testes para sistema multi-timeframe
    """
    
    def __init__(self):
        self.analyzer = MultiTimeframeAnalyzer()
        self.resultados_testes = {}
        self.casos_teste = []
        
    def gerar_dados_teste(self, symbol: str = "BTCUSDT", cenario: str = "normal") -> Dict:
        """
        Gera dados de teste para múltiplos timeframes
        """
        np.random.seed(42)  # Para resultados reproduzíveis
        
        dados_por_tf = {}
        
        # Configurações por cenário
        cenarios = {
            'normal': {'volatilidade': 0.02, 'tendencia': 0.001},
            'alta_volatilidade': {'volatilidade': 0.08, 'tendencia': 0.002},
            'tendencia_forte': {'volatilidade': 0.03, 'tendencia': 0.005},
            'lateral': {'volatilidade': 0.015, 'tendencia': 0.0001},
            'reversao': {'volatilidade': 0.04, 'tendencia': -0.003}
        }
        
        config = cenarios.get(cenario, cenarios['normal'])
        
        for tf in ['15m', '1h', '4h', '1d']:
            # Ajustar número de períodos por timeframe
            n_periodos = {'15m': 200, '1h': 150, '4h': 100, '1d': 60}.get(tf, 100)
            
            # Gerar dados OHLCV
            dados_tf = self._gerar_ohlcv(
                n_periodos=n_periodos,
                preco_base=50000,
                volatilidade=config['volatilidade'],
                tendencia=config['tendencia'],
                timeframe=tf
            )
            
            dados_por_tf[tf] = dados_tf
        
        return dados_por_tf
    
    def _gerar_ohlcv(self, n_periodos: int, preco_base: float, 
                     volatilidade: float, tendencia: float, timeframe: str) -> pd.DataFrame:
        """
        Gera dados OHLCV realistas para um timeframe
        """
        # Ajustar parâmetros por timeframe
        mult_tf = {'15m': 0.5, '1h': 1.0, '4h': 2.0, '1d': 4.0}.get(timeframe, 1.0)
        volatilidade *= mult_tf
        tendencia *= mult_tf
        
        precos_close = []
        volumes = []
        
        for i in range(n_periodos):
            # Tendência com ruído
            trend = tendencia * i
            noise = np.random.normal(0, volatilidade)
            
            if i == 0:
                preco = preco_base
            else:
                preco = precos_close[-1] * (1 + trend + noise)
            
            precos_close.append(preco)
            
            # Volume com variação
            vol_base = np.random.uniform(1000, 5000)
            vol_mult = 1 + abs(noise) * 2  # Mais volume em movimentos grandes
            volumes.append(vol_base * vol_mult)
        
        # Gerar OHLC baseado no close
        opens = [precos_close[0]] + precos_close[:-1]
        highs = [max(o, c) * (1 + np.random.uniform(0, 0.005)) for o, c in zip(opens, precos_close)]
        lows = [min(o, c) * (1 - np.random.uniform(0, 0.005)) for o, c in zip(opens, precos_close)]
        
        return pd.DataFrame({
            'timestamp': range(n_periodos),
            'open': opens,
            'high': highs,
            'low': lows,
            'close': precos_close,
            'volume': volumes
        })
    
    def executar_teste_basico(self) -> bool:
        """
        Teste básico de funcionamento
        """
        print("\n🧪 TESTE 1: FUNCIONAMENTO BÁSICO")
        print("=" * 50)
        
        try:
            # Gerar dados de teste
            dados = self.gerar_dados_teste("BTCUSDT", "normal")
            print(f"✅ Dados gerados para {len(dados)} timeframes")
            
            # Executar análise
            resultado = self.analyzer.analisar_multitimeframe_completo("BTCUSDT", dados)
            print("✅ Análise multi-timeframe executada")
            
            # Verificar estrutura do resultado
            campos_obrigatorios = [
                'symbol', 'analises_por_tf', 'sinais_por_tf', 
                'confluencia', 'sinal_final', 'scoring'
            ]
            
            for campo in campos_obrigatorios:
                if campo not in resultado:
                    print(f"❌ Campo obrigatório ausente: {campo}")
                    return False
            
            print("✅ Estrutura do resultado validada")
            
            # Verificar scoring
            scoring = resultado['scoring']
            if scoring['score_total'] < 0 or scoring['score_total'] > 30:
                print(f"❌ Score inválido: {scoring['score_total']}")
                return False
            
            print(f"✅ Score válido: {scoring['score_total']:.2f}/30")
            print(f"✅ Classificação: {scoring['classificacao']}")
            print(f"✅ Confiança: {scoring['confianca']:.1%}")
            
            self.resultados_testes['basico'] = {
                'status': 'PASSOU',
                'score': scoring['score_total'],
                'classificacao': scoring['classificacao'],
                'confianca': scoring['confianca']
            }
            
            return True
            
        except Exception as e:
            print(f"❌ Erro no teste básico: {e}")
            self.resultados_testes['basico'] = {'status': 'FALHOU', 'erro': str(e)}
            return False
    
    def executar_teste_cenarios(self) -> bool:
        """
        Teste com diferentes cenários de mercado
        """
        print("\n🧪 TESTE 2: CENÁRIOS DE MERCADO")
        print("=" * 50)
        
        cenarios = ['normal', 'alta_volatilidade', 'tendencia_forte', 'lateral', 'reversao']
        resultados_cenarios = {}
        
        try:
            for cenario in cenarios:
                print(f"\n📊 Testando cenário: {cenario.upper()}")
                
                # Gerar dados para o cenário
                dados = self.gerar_dados_teste("BTCUSDT", cenario)
                
                # Executar análise
                resultado = self.analyzer.analisar_multitimeframe_completo("BTCUSDT", dados)
                
                # Extrair métricas
                scoring = resultado['scoring']
                sinal = resultado['sinal_final']
                
                resultados_cenarios[cenario] = {
                    'score': scoring['score_total'],
                    'classificacao': scoring['classificacao'],
                    'confianca': scoring['confianca'],
                    'acao': sinal['acao'],
                    'nivel_confluencia': sinal.get('nivel_confluencia', 'N/A')
                }
                
                print(f"  Score: {scoring['score_total']:.2f}")
                print(f"  Ação: {sinal['acao']}")
                print(f"  Confiança: {scoring['confianca']:.1%}")
            
            # Validar diversidade de resultados
            acoes_unicas = len(set(r['acao'] for r in resultados_cenarios.values()))
            scores_range = max(r['score'] for r in resultados_cenarios.values()) - \
                          min(r['score'] for r in resultados_cenarios.values())
            
            print(f"\n✅ Ações únicas geradas: {acoes_unicas}")
            print(f"✅ Range de scores: {scores_range:.2f}")
            
            if acoes_unicas >= 2 and scores_range >= 5:
                print("✅ Sistema responde adequadamente a diferentes cenários")
                self.resultados_testes['cenarios'] = {
                    'status': 'PASSOU',
                    'resultados': resultados_cenarios
                }
                return True
            else:
                print("⚠️ Sistema pode não estar diferenciando cenários adequadamente")
                self.resultados_testes['cenarios'] = {
                    'status': 'PARCIAL',
                    'resultados': resultados_cenarios
                }
                return True
            
        except Exception as e:
            print(f"❌ Erro no teste de cenários: {e}")
            self.resultados_testes['cenarios'] = {'status': 'FALHOU', 'erro': str(e)}
            return False
    
    def executar_teste_performance(self) -> bool:
        """
        Teste de performance e tempo de execução
        """
        print("\n🧪 TESTE 3: PERFORMANCE")
        print("=" * 50)
        
        try:
            import time
            
            # Gerar dados maiores
            dados = self.gerar_dados_teste("BTCUSDT", "normal")
            
            # Medir tempo de execução
            inicio = time.time()
            
            for i in range(5):  # 5 execuções
                resultado = self.analyzer.analisar_multitimeframe_completo("BTCUSDT", dados)
            
            fim = time.time()
            tempo_total = fim - inicio
            tempo_medio = tempo_total / 5
            
            print(f"✅ 5 execuções completadas")
            print(f"✅ Tempo total: {tempo_total:.3f}s")
            print(f"✅ Tempo médio: {tempo_medio:.3f}s")
            
            # Validar performance
            if tempo_medio < 1.0:  # Menos de 1 segundo por análise
                print("✅ Performance excelente")
                status_perf = 'EXCELENTE'
            elif tempo_medio < 2.0:
                print("✅ Performance boa")
                status_perf = 'BOA'
            else:
                print("⚠️ Performance pode ser melhorada")
                status_perf = 'REGULAR'
            
            self.resultados_testes['performance'] = {
                'status': 'PASSOU',
                'tempo_medio': tempo_medio,
                'classificacao': status_perf
            }
            
            return True
            
        except Exception as e:
            print(f"❌ Erro no teste de performance: {e}")
            self.resultados_testes['performance'] = {'status': 'FALHOU', 'erro': str(e)}
            return False
    
    def executar_teste_confluencia(self) -> bool:
        """
        Teste específico de confluência temporal
        """
        print("\n🧪 TESTE 4: CONFLUÊNCIA TEMPORAL")
        print("=" * 50)
        
        try:
            # Cenário com alta confluência (todos TFs alinhados)
            dados_alinhados = self.gerar_dados_teste("BTCUSDT", "tendencia_forte")
            resultado_alinhado = self.analyzer.analisar_multitimeframe_completo("BTCUSDT", dados_alinhados)
            
            # Cenário com baixa confluência (TFs divergentes)
            dados_divergentes = self.gerar_dados_teste("ETHUSDT", "lateral")
            resultado_divergente = self.analyzer.analisar_multitimeframe_completo("ETHUSDT", dados_divergentes)
            
            # Comparar confluências
            conf_alinhado = resultado_alinhado['confluencia']['alinhamento']
            conf_divergente = resultado_divergente['confluencia']['alinhamento']
            
            print(f"✅ Confluência cenário alinhado: {conf_alinhado:.1%}")
            print(f"✅ Confluência cenário divergente: {conf_divergente:.1%}")
            
            # Validar diferenciação
            if conf_alinhado > conf_divergente:
                print("✅ Sistema detecta diferenças de confluência corretamente")
                
                # Verificar scores
                score_alinhado = resultado_alinhado['scoring']['score_total']
                score_divergente = resultado_divergente['scoring']['score_total']
                
                print(f"✅ Score alinhado: {score_alinhado:.2f}")
                print(f"✅ Score divergente: {score_divergente:.2f}")
                
                self.resultados_testes['confluencia'] = {
                    'status': 'PASSOU',
                    'confluencia_alinhado': conf_alinhado,
                    'confluencia_divergente': conf_divergente,
                    'diferenciacao': 'OK'
                }
                return True
            else:
                print("⚠️ Sistema pode não estar detectando confluência adequadamente")
                self.resultados_testes['confluencia'] = {
                    'status': 'PARCIAL',
                    'confluencia_alinhado': conf_alinhado,
                    'confluencia_divergente': conf_divergente,
                    'diferenciacao': 'LIMITADA'
                }
                return True
            
        except Exception as e:
            print(f"❌ Erro no teste de confluência: {e}")
            self.resultados_testes['confluencia'] = {'status': 'FALHOU', 'erro': str(e)}
            return False
    
    def executar_teste_comparativo(self) -> bool:
        """
        Teste comparativo com sistema single-timeframe
        """
        print("\n🧪 TESTE 5: COMPARATIVO SINGLE vs MULTI-TF")
        print("=" * 50)
        
        try:
            # Dados de teste
            dados = self.gerar_dados_teste("BTCUSDT", "normal")
            
            # Análise multi-timeframe
            resultado_multi = self.analyzer.analisar_multitimeframe_completo("BTCUSDT", dados)
            
            # Análise single-timeframe (apenas 1h)
            from analise_tecnica_basica import AnaliseTecnicaBasica
            analyzer_single = AnaliseTecnicaBasica()
            
            analise_single = analyzer_single.analisar_dados(dados['1h'])
            acao_single, conf_single, motivo_single = analyzer_single.gerar_sinal(analise_single)
            
            # Comparar resultados
            conf_multi = resultado_multi['scoring']['confianca']
            score_multi = resultado_multi['scoring']['score_total']
            acao_multi = resultado_multi['sinal_final']['acao']
            
            print(f"📊 SINGLE-TF:")
            print(f"  Ação: {acao_single}")
            print(f"  Confiança: {conf_single:.1%}")
            
            print(f"📊 MULTI-TF:")
            print(f"  Ação: {acao_multi}")
            print(f"  Confiança: {conf_multi:.1%}")
            print(f"  Score: {score_multi:.2f}/30")
            
            # Validar melhorias
            melhorias = []
            
            if conf_multi > conf_single:
                melhorias.append("Confiança superior")
            
            if len(resultado_multi['timeframes_analisados']) > 1:
                melhorias.append("Múltiplos timeframes")
            
            if 'confluencia' in resultado_multi:
                melhorias.append("Análise de confluência")
            
            print(f"✅ Melhorias detectadas: {', '.join(melhorias)}")
            
            self.resultados_testes['comparativo'] = {
                'status': 'PASSOU',
                'confianca_single': conf_single,
                'confianca_multi': conf_multi,
                'melhorias': melhorias,
                'timeframes_analisados': len(resultado_multi['timeframes_analisados'])
            }
            
            return True
            
        except Exception as e:
            print(f"❌ Erro no teste comparativo: {e}")
            self.resultados_testes['comparativo'] = {'status': 'FALHOU', 'erro': str(e)}
            return False
    
    def gerar_relatorio_final(self) -> Dict:
        """
        Gera relatório final dos testes
        """
        print("\n" + "=" * 60)
        print("📋 RELATÓRIO FINAL DOS TESTES")
        print("=" * 60)
        
        testes_passaram = 0
        total_testes = len(self.resultados_testes)
        
        for nome_teste, resultado in self.resultados_testes.items():
            status = resultado['status']
            if status == 'PASSOU':
                print(f"✅ {nome_teste.upper()}: {status}")
                testes_passaram += 1
            elif status == 'PARCIAL':
                print(f"⚠️ {nome_teste.upper()}: {status}")
                testes_passaram += 0.5
            else:
                print(f"❌ {nome_teste.upper()}: {status}")
        
        taxa_sucesso = (testes_passaram / total_testes) * 100
        
        print(f"\n📊 RESUMO:")
        print(f"  Testes executados: {total_testes}")
        print(f"  Testes aprovados: {testes_passaram}")
        print(f"  Taxa de sucesso: {taxa_sucesso:.1f}%")
        
        if taxa_sucesso >= 90:
            status_geral = "EXCELENTE"
            emoji = "🌟"
        elif taxa_sucesso >= 80:
            status_geral = "MUITO BOM"
            emoji = "🚀"
        elif taxa_sucesso >= 70:
            status_geral = "BOM"
            emoji = "✅"
        else:
            status_geral = "PRECISA MELHORAR"
            emoji = "⚠️"
        
        print(f"\n{emoji} STATUS GERAL: {status_geral}")
        
        return {
            'timestamp': datetime.now().isoformat(),
            'total_testes': total_testes,
            'testes_aprovados': testes_passaram,
            'taxa_sucesso': taxa_sucesso,
            'status_geral': status_geral,
            'detalhes': self.resultados_testes
        }

def main():
    """
    Função principal para executar todos os testes
    """
    print("🚀 INICIANDO SUITE DE TESTES - SISTEMA MULTI-TIMEFRAME")
    print("Validação completa do sistema de confluência temporal")
    print("=" * 60)
    
    # Inicializar suite de testes
    suite = TesteSuiteMultiTimeframe()
    
    # Executar todos os testes
    testes = [
        suite.executar_teste_basico,
        suite.executar_teste_cenarios,
        suite.executar_teste_performance,
        suite.executar_teste_confluencia,
        suite.executar_teste_comparativo
    ]
    
    sucesso_geral = True
    
    for teste in testes:
        resultado = teste()
        if not resultado:
            sucesso_geral = False
    
    # Gerar relatório final
    relatorio = suite.gerar_relatorio_final()
    
    # Salvar relatório
    with open('relatorio_testes_multitf.json', 'w') as f:
        json.dump(relatorio, f, indent=2, default=str)
    
    print(f"\n📄 Relatório salvo em: relatorio_testes_multitf.json")
    
    if sucesso_geral and relatorio['taxa_sucesso'] >= 80:
        print("\n🎉 SISTEMA MULTI-TIMEFRAME VALIDADO COM SUCESSO!")
        print("✅ Pronto para uso em produção")
        return True
    else:
        print("\n⚠️ Sistema precisa de ajustes antes do uso em produção")
        return False

if __name__ == "__main__":
    main()

