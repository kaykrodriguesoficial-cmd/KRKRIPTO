#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Teste Completo da Neural Governance Integration

Este script testa a integração completa do sistema de governança neural
com multi-timeframe e RL, validando seleção automática de modelos.

Autor: Manus AI
Data: 30/08/2025
"""

import sys
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import json
from typing import Dict, List, Tuple, Any

# Importar nossa integração
from neural_governance_integration import (
    NeuralGovernanceIntegration, 
    criar_neural_governance_integration
)

def gerar_dados_simulados_completos(symbols: list, timeframes: list) -> Dict:
    """
    Gera dados simulados completos para múltiplos ativos e timeframes.
    
    Args:
        symbols: Lista de símbolos
        timeframes: Lista de timeframes
        
    Returns:
        Dict: Dados organizados por símbolo e timeframe
    """
    dados_completos = {}
    
    for symbol in symbols:
        dados_completos[symbol] = {}
        
        # Preço base baseado no símbolo
        base_price = 50000.0 if 'BTC' in symbol else 3000.0
        
        for tf in timeframes:
            # Períodos baseados no timeframe
            periods_map = {'15m': 200, '1h': 150, '4h': 100, '1d': 60}
            periods = periods_map.get(tf, 100)
            
            # Gerar dados realistas
            np.random.seed(hash(symbol + tf) % 2**32)  # Seed baseada no símbolo+tf
            
            # Retornos com características diferentes por timeframe
            if tf == '15m':
                volatility = 0.005  # Mais volátil em timeframes menores
            elif tf == '1h':
                volatility = 0.01
            elif tf == '4h':
                volatility = 0.02
            else:  # 1d
                volatility = 0.03
            
            returns = np.random.normal(0.0001, volatility, periods)
            
            # Adicionar tendência sutil
            if 'BTC' in symbol:
                trend = np.linspace(0, 0.05, periods)  # Tendência de alta
            else:
                trend = np.linspace(0, 0.03, periods)  # Tendência menor
            
            returns += trend / periods
            
            # Calcular preços
            prices = [base_price]
            for ret in returns:
                new_price = prices[-1] * (1 + ret)
                prices.append(new_price)
            
            prices = prices[1:]
            
            # Gerar OHLC completo
            data = []
            for i, close in enumerate(prices):
                high = close * (1 + abs(np.random.normal(0, volatility/2)))
                low = close * (1 - abs(np.random.normal(0, volatility/2)))
                open_price = prices[i-1] if i > 0 else close
                volume = np.random.uniform(1000, 10000)
                
                timestamp = datetime.now() - timedelta(hours=periods-i)
                
                data.append({
                    'timestamp': timestamp,
                    'open': open_price,
                    'high': high,
                    'low': low,
                    'close': close,
                    'volume': volume
                })
            
            df = pd.DataFrame(data)
            
            # Adicionar indicadores técnicos
            df['rsi'] = 50 + np.random.normal(0, 15, len(df))
            df['rsi'] = np.clip(df['rsi'], 0, 100)
            
            df['macd'] = np.random.normal(0, 0.1, len(df))
            df['macd_signal'] = df['macd'] * 0.8 + np.random.normal(0, 0.05, len(df))
            df['macd_hist'] = df['macd'] - df['macd_signal']
            
            df['sma_20'] = df['close'].rolling(window=min(20, len(df))).mean().fillna(df['close'])
            df['ema_9'] = df['close'].ewm(span=9).mean()
            
            dados_completos[symbol][tf] = df
    
    return dados_completos

def executar_teste_neural_governance():
    """
    Executa teste completo da Neural Governance Integration.
    """
    print("🧠 INICIANDO TESTE COMPLETO - NEURAL GOVERNANCE INTEGRATION")
    print("=" * 70)
    
    # 1. Configurar sistema
    config = {
        'neural_governor_config': {
            'selection_strategy': 'best_recent',
            'min_score_threshold': 0.3,  # Mais permissivo para teste
            'min_predictions_threshold': 3  # Menos predições para teste
        },
        'rl_config': {
            'ativo': 'BTCUSDT',
            'timeframes': ['15m', '1h', '4h', '1d'],
            'learning_rate': 0.01,
            'epsilon': 0.2
        }
    }
    
    print("🌟 Criando Neural Governance Integration...")
    integration = criar_neural_governance_integration(config)
    print("✅ Sistema de governança neural criado")
    
    # 2. Verificar status inicial
    print("\n📊 Status inicial do sistema:")
    status = integration.get_system_status()
    
    print(f"  🧠 Estratégia: {status['neural_governance']['strategy']}")
    print(f"  📈 Modelos registrados: {status['neural_governance']['registered_models']}")
    print(f"  🎯 Threshold mínimo: {status['neural_governance']['thresholds']['min_score']}")
    
    # 3. Gerar dados para teste
    print("\n📊 Gerando dados simulados...")
    symbols = ['BTCUSDT', 'ETHUSDT']
    timeframes = ['15m', '1h', '4h', '1d']
    
    dados_completos = gerar_dados_simulados_completos(symbols, timeframes)
    
    for symbol in symbols:
        print(f"  ✅ {symbol}: {len(timeframes)} timeframes gerados")
    
    # 4. Executar análises com governança neural
    print("\n🧠 Executando análises com governança neural...")
    
    resultados = []
    
    for i, symbol in enumerate(symbols):
        print(f"\n  🎯 Analisando {symbol}...")
        
        # Dados do símbolo
        dados_por_tf = dados_completos[symbol]
        
        # Contexto de mercado simulado
        market_context = {
            'volatility': 'high' if i == 0 else 'medium',
            'trend': 'bullish' if i == 0 else 'bearish',
            'market_session': 'active'
        }
        
        # Fazer análise com governança neural
        resultado = integration.analyze_and_decide(symbol, dados_por_tf, market_context)
        resultados.append(resultado)
        
        # Exibir resultado
        sinal = resultado.get('sinal_final', {})
        governance = resultado.get('governance', {})
        
        print(f"    🎯 Ação: {sinal.get('acao', 'N/A')}")
        print(f"    📊 Confiança: {sinal.get('confianca', 0):.1%}")
        print(f"    🤖 Modelo usado: {governance.get('selected_model', 'N/A')}")
        print(f"    📈 Score: {resultado.get('scoring', {}).get('score_total', 0):.1f}")
        
        # Simular algumas predições para treinar o sistema
        for j in range(5):
            # Simular resultado real
            actual_result = {
                'profit': np.random.normal(0.01, 0.02)  # Lucro simulado
            }
            
            # Registrar no performance tracker
            model_id = governance.get('selected_model', 'unknown')
            if hasattr(integration.neural_governor.performance_tracker, 'record_prediction'):
                integration.neural_governor.performance_tracker.record_prediction(
                    model_id, sinal, actual_result
                )
    
    # 5. Analisar performance dos modelos
    print("\n📊 ANÁLISE DE PERFORMANCE DOS MODELOS:")
    print("-" * 50)
    
    governance_status = integration.neural_governor.get_governance_status()
    
    print(f"📈 Modelos registrados: {governance_status['registered_models']}")
    print(f"🎯 Estratégia ativa: {governance_status['strategy']}")
    
    # Performance individual dos modelos
    print(f"\n🏆 PERFORMANCE DOS MODELOS:")
    for model_id, perf in governance_status['models_performance'].items():
        if perf.get('predictions', 0) > 0:
            print(f"  🤖 {model_id}:")
            print(f"    📊 Predições: {perf.get('predictions', 0)}")
            print(f"    🎯 Accuracy: {perf.get('accuracy', 0):.1%}")
            print(f"    📈 Confiança média: {perf.get('avg_confidence', 0):.3f}")
            print(f"    💰 Lucro total: {perf.get('total_profit', 0):.4f}")
            print(f"    🏆 Score confiabilidade: {perf.get('reliability_score', 0):.3f}")
    
    # Melhores modelos
    best_models = governance_status.get('best_models', [])
    if best_models:
        print(f"\n🥇 RANKING DOS MELHORES MODELOS:")
        for i, (model_id, score) in enumerate(best_models, 1):
            print(f"  {i}. {model_id}: {score:.3f}")
    
    # 6. Testar seleção de modelos
    print(f"\n🔄 TESTANDO SELEÇÃO DE MODELOS:")
    
    # Teste com diferentes contextos
    contextos_teste = [
        {'volatility': 'low', 'trend': 'neutral'},
        {'volatility': 'high', 'trend': 'bullish'},
        {'volatility': 'medium', 'trend': 'bearish'}
    ]
    
    for i, context in enumerate(contextos_teste, 1):
        model_id, model_instance = integration.neural_governor.select_best_model(context)
        print(f"  {i}. Contexto {context} → Modelo: {model_id}")
    
    # 7. Teste de robustez
    print(f"\n🛡️ TESTE DE ROBUSTEZ:")
    
    try:
        # Teste com dados vazios
        resultado_vazio = integration.analyze_and_decide('TESTUSDT', {})
        print(f"  ✅ Dados vazios: {resultado_vazio['sinal_final']['acao']}")
        
        # Teste com contexto inválido
        resultado_invalido = integration.analyze_and_decide(
            'BTCUSDT', 
            dados_completos['BTCUSDT'], 
            {'invalid': 'context'}
        )
        print(f"  ✅ Contexto inválido: {resultado_invalido['sinal_final']['acao']}")
        
    except Exception as e:
        print(f"  ❌ Erro no teste de robustez: {e}")
    
    # 8. Resumo final
    print(f"\n🎉 TESTE NEURAL GOVERNANCE FINALIZADO!")
    print("=" * 70)
    
    # Estatísticas finais
    total_decisions = len(resultados)
    models_used = set(r.get('governance', {}).get('selected_model') for r in resultados)
    avg_confidence = np.mean([r.get('sinal_final', {}).get('confianca', 0) for r in resultados])
    
    print(f"✅ Decisões tomadas: {total_decisions}")
    print(f"🤖 Modelos utilizados: {len(models_used)} ({', '.join(models_used)})")
    print(f"📊 Confiança média: {avg_confidence:.1%}")
    print(f"🧠 Governança neural: FUNCIONANDO")
    print(f"🔄 Seleção automática: ATIVA")
    print(f"📈 Performance tracking: OPERACIONAL")
    
    return {
        'integration': integration,
        'resultados': resultados,
        'governance_status': governance_status,
        'dados_completos': dados_completos
    }

if __name__ == "__main__":
    try:
        resultado_teste = executar_teste_neural_governance()
        print(f"\n🚀 Teste executado com sucesso!")
        
    except Exception as e:
        print(f"\n❌ Erro durante o teste: {e}")
        import traceback
        traceback.print_exc()

