import asyncio
import sys
import os
import logging

# Configurar logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("teste_operador")

# Adicionar diretório do projeto ao path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Importar OperadorBinance
try:
    from src.infrastructure.operador import OperadorBinance
    logger.info("OperadorBinance importado com sucesso")
except ImportError as e:
    logger.error(f"Erro ao importar OperadorBinance: {e}")
    sys.exit(1)

async def teste_operador():
    try:
        # Inicializar operador
        operador = OperadorBinance(config={})
        logger.info("OperadorBinance inicializado")
        
        # Inicializar cliente
        await operador.inicializar_cliente()
        logger.info("Cliente inicializado com sucesso")
        
        # Testar obtenção de dados
        klines = await operador.obter_klines("BTCUSDT", "1h", limit=10)
        logger.info(f"Obtidas {len(klines)} klines para BTCUSDT")
        
        # Testar obtenção de saldo
        saldo = await operador.obter_saldo()
        logger.info(f"Saldo obtido: {saldo}")
        
        # Testar obtenção de informações do símbolo
        info = await operador.obter_info_simbolo("BTCUSDT")
        logger.info(f"Informações do símbolo obtidas: {info['status']}")
        
        # Fechar cliente
        await operador.fechar_cliente()
        logger.info("Cliente fechado com sucesso")
    except Exception as e:
        logger.error(f"Erro no teste do operador: {e}")

if __name__ == "__main__":
    asyncio.run(teste_operador())

