import asyncio
from binance import AsyncClient

async def teste_ordem():
    try:
        # Inicializar cliente
        client = await AsyncClient.create()
        
        # Testar ordem de teste (não executa realmente)
        test_order = await client.create_test_order(
            symbol='BTCUSDT',
            side='BUY',
            type='MARKET',
            quantity=0.001
        )
        print("Ordem de teste bem-sucedida!")
        print("Seu sistema está configurado corretamente para enviar ordens.")
        
        # Fechar cliente
        await client.close_connection()
    except Exception as e:
        print(f"Erro ao testar ordem: {e}")

if __name__ == "__main__":
    asyncio.run(teste_ordem())


