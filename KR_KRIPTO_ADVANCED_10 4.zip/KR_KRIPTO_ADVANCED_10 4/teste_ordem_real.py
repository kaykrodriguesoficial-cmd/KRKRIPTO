import asyncio
import sys
import os
import logging

# Configurar logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("teste_ordem_real")

# Adicionar diretório do projeto ao path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Importar OperadorBinance
try:
    from src.infrastructure.operador import OperadorBinance
    logger.info("OperadorBinance importado com sucesso")
except ImportError as e:
    logger.error(f"Erro ao importar OperadorBinance: {e}")
    sys.exit(1)

async def teste_ordem_real():
    try:
        # Inicializar operador
        operador = OperadorBinance(config={})
        logger.info("OperadorBinance inicializado")
        
        # Inicializar cliente
        await operador.inicializar_cliente()
        logger.info("Cliente inicializado com sucesso")
        
        # Verificar saldo
        saldo = await operador.obter_saldo()
        logger.info(f"Saldo obtido: {saldo}")
        
        # Verificar permissões da API
        logger.info("Verificando permissões da API...")
        try:
            # Tentar criar uma ordem de teste (não executa realmente)
            resultado_teste = await operador.cliente.create_test_order(
                symbol='BTCUSDT',
                side='BUY',
                type='MARKET',
                quantity=0.001
            )
            logger.info(f"Ordem de teste bem-sucedida: {resultado_teste}")
            logger.info("API tem permissão para enviar ordens!")
        except Exception as e:
            logger.error(f"Erro ao criar ordem de teste: {e}")
            logger.error("API não tem permissão para enviar ordens ou há outro problema.")
        
        # Verificar se a API tem permissão para operações de trading
        try:
            api_permissions = await operador.cliente.get_api_permission()
            logger.info(f"Permissões da API: {api_permissions}")
            
            # Verificar permissões específicas
            if 'enableSpotAndMarginTrading' in api_permissions and api_permissions['enableSpotAndMarginTrading']:
                logger.info("API tem permissão para trading spot!")
            else:
                logger.warning("API NÃO tem permissão para trading spot!")
                
            if 'enableWithdrawals' in api_permissions and api_permissions['enableWithdrawals']:
                logger.info("API tem permissão para saques!")
            else:
                logger.info("API NÃO tem permissão para saques (isso é normal para segurança).")
        except Exception as e:
            logger.error(f"Erro ao verificar permissões da API: {e}")
        
        # Fechar cliente
        await operador.fechar_cliente()
        logger.info("Cliente fechado com sucesso")
    except Exception as e:
        logger.error(f"Erro no teste de ordem real: {e}")

if __name__ == "__main__":
    asyncio.run(teste_ordem_real())

