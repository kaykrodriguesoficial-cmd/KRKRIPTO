import asyncio
import sys
import os
import logging
import json

# Configurar logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("teste_ordem_real")

# Adicionar diretório do projeto ao path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Carregar configuração diretamente
config = {}
try:
    with open('config.json', 'r') as f:
        config = json.load(f)
    logger.info(f"Configuração carregada de config.json: {len(config)} itens")
except Exception as e:
    logger.error(f"Erro ao carregar config.json: {e}")

# Carregar variáveis de ambiente diretamente
api_key = os.environ.get('BINANCE_API_KEY', '')
api_secret = os.environ.get('BINANCE_API_SECRET', '')

if api_key and api_secret:
    logger.info("Credenciais encontradas nas variáveis de ambiente")
    config['api_key'] = api_key
    config['api_secret'] = api_secret
else:
    logger.warning("Credenciais não encontradas nas variáveis de ambiente")

# Importar OperadorBinance
try:
    from src.infrastructure.operador import OperadorBinance
    logger.info("OperadorBinance importado com sucesso")
except ImportError as e:
    logger.error(f"Erro ao importar OperadorBinance: {e}")
    sys.exit(1)

async def teste_ordem_real():
    try:
        # Mostrar configuração (sem mostrar as credenciais completas)
        safe_config = config.copy()
        if 'api_key' in safe_config:
            safe_config['api_key'] = '***' + safe_config['api_key'][-4:] if safe_config['api_key'] else 'Não definida'
        if 'api_secret' in safe_config:
            safe_config['api_secret'] = '***' + safe_config['api_secret'][-4:] if safe_config['api_secret'] else 'Não definida'
        logger.info(f"Configuração: {safe_config}")
        
        # Inicializar operador com configuração explícita
        operador = OperadorBinance(config=config)
        logger.info("OperadorBinance inicializado")
        
        # Inicializar cliente
        await operador.inicializar_cliente()
        logger.info("Cliente inicializado com sucesso")
        
        # Verificar métodos disponíveis
        logger.info(f"Métodos disponíveis: {[m for m in dir(operador) if not m.startswith('_')]}")
        
        # Tentar obter saldo (usando o método correto)
        try:
            if hasattr(operador, 'obter_saldo'):
                saldo = await operador.obter_saldo()
                logger.info(f"Saldo obtido: {saldo}")
            elif hasattr(operador, 'get_account'):
                saldo = await operador.get_account()
                logger.info(f"Saldo obtido via get_account: {saldo}")
            else:
                logger.warning("Método para obter saldo não encontrado")
        except Exception as e:
            logger.error(f"Erro ao obter saldo: {e}")
        
        # Verificar permissões da API
        logger.info("Verificando permissões da API...")
        try:
            # Tentar criar uma ordem de teste (não executa realmente)
            if hasattr(operador.cliente, 'create_test_order'):
                resultado_teste = await operador.cliente.create_test_order(
                    symbol='BTCUSDT',
                    side='BUY',
                    type='MARKET',
                    quantity=0.001
                )
                logger.info(f"Ordem de teste bem-sucedida: {resultado_teste}")
                logger.info("API tem permissão para enviar ordens!")
            else:
                logger.warning("Método create_test_order não encontrado")
        except Exception as e:
            logger.error(f"Erro ao criar ordem de teste: {e}")
        
        # Fechar cliente
        if hasattr(operador, 'fechar_cliente'):
            await operador.fechar_cliente()
            logger.info("Cliente fechado com sucesso")
        
    except Exception as e:
        logger.error(f"Erro no teste de ordem real: {e}")
        logger.error(f"Detalhes: {traceback.format_exc()}")

if __name__ == "__main__":
    import traceback
    asyncio.run(teste_ordem_real())

