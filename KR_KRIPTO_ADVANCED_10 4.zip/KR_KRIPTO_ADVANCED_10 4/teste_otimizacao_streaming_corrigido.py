#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Teste de otimização do streaming da Binance.

Este script testa as otimizações implementadas no módulo binance_stream.py:
1. Priorização de dados de streaming sobre consultas REST
2. Cache agressivo com TTL dinâmico
3. Controle inteligente de intervalos entre chamadas REST
"""

import asyncio
import logging
import sys
import time
import random
from typing import Dict, Any, Optional, List

# Configurar logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                   handlers=[logging.StreamHandler(sys.stdout)])

logger = logging.getLogger("teste_otimizacao")

# Importar o módulo de streaming
try:
    from binance_stream_corrigido import BinanceStreamManager
    logger.info("Módulo binance_stream_corrigido importado com sucesso.")
except ImportError:
    try:
        from src.core.binance_stream import BinanceStreamManager
        logger.info("Módulo binance_stream importado com sucesso.")
    except ImportError:
        logger.error("Não foi possível importar BinanceStreamManager. Verifique o caminho do módulo.")
        sys.exit(1)

# Simulação de chamada REST para testes
async def simular_chamada_rest(symbol: str, intervalo: str = None) -> Dict[str, Any]:
    """Simula uma chamada à API REST da Binance."""
    logger.info(f"Simulando chamada REST para {symbol} {intervalo if intervalo else ''}")
    
    # Simular latência de rede
    await asyncio.sleep(random.uniform(0.5, 1.5))
    
    # 10% de chance de falha
    if random.random() < 0.1:
        logger.warning(f"Simulando falha na chamada REST para {symbol}")
        return None
    
    # Gerar dados simulados
    now = time.time()
    
    if intervalo:  # Kline
        return {
            'open_time': int(now * 1000) - 60000,
            'open': 50000.0 + random.uniform(-1000, 1000),
            'high': 51000.0 + random.uniform(-500, 500),
            'low': 49000.0 + random.uniform(-500, 500),
            'close': 50500.0 + random.uniform(-800, 800),
            'volume': random.uniform(10, 100),
            'close_time': int(now * 1000),
            'is_closed': True,
            'symbol': symbol,
            'interval': intervalo,
            'source': 'rest'
        }
    else:  # Ticker
        return {
            'symbol': symbol,
            'price': 50000.0 + random.uniform(-1000, 1000),
            'price_change': random.uniform(-500, 500),
            'price_change_percent': random.uniform(-5, 5),
            'volume': random.uniform(1000, 10000),
            'source': 'rest'
        }

# Callbacks para testes
async def callback_kline(symbol: str, interval: str, data: Dict[str, Any]):
    """Callback para processar klines."""
    logger.info(f"Callback kline recebido: {symbol} {interval} - close: {data.get('close')}")

async def callback_ticker(symbol: str, interval: str, data: Dict[str, Any]):
    """Callback para processar tickers."""
    logger.info(f"Callback ticker recebido: {symbol} - price: {data.get('price')}")

async def teste_otimizacao():
    """Função principal de teste."""
    logger.info("Iniciando teste de otimização do streaming da Binance")
    
    # Configuração de teste
    config = {
        "testnet": True,
        "execution_mode": "master",
        "websocket": {
            "max_reconnect_attempts": 5,
            "base_reconnect_delay": 1.0,
            "max_reconnect_delay": 30.0,
            "reconnect_jitter": 0.2,
            "connect_timeout": 15.0,
            "message_timeout": 30.0,
            "heartbeat_interval": 20.0
        },
        "data_source_optimization": {
            "prioritize_streaming": True,
            "use_aggressive_cache": True,
            "fallback_to_rest": True,
            "cache_ttl_seconds": {
                "kline_1m": 130,  # 2 minutos + 10s buffer
                "ticker": 10,
                "default": 60
            },
            "min_rest_interval_seconds": {
                "kline": 5,
                "ticker": 2,
                "default": 5
            }
        }
    }
    
    # Contexto global simplificado
    context_global = {
        "dataframes": {},
        "last_kline_time": {},
        "dataframes_lock": asyncio.Lock()
    }
    
    try:
        # Inicializar gerenciador
        manager = BinanceStreamManager(config, context_global)
        
        # Registrar callbacks
        # CORREÇÃO: Usar o formato correto com 3 argumentos (symbol, stream_type, callback)
        manager.registrar_callback("BTCUSDT", "1m", callback_kline)
        manager.registrar_callback("ETHUSDT", "ticker", callback_ticker)
        
        # Iniciar streams
        streams = [
            {"type": "kline", "symbol": "BTCUSDT", "interval": "1m"},
            {"type": "ticker", "symbol": "ETHUSDT"}
        ]
        
        await manager.iniciar_streams(streams)
        logger.info("Streams iniciados com sucesso")
        
        # Aguardar um pouco para receber alguns dados via streaming
        logger.info("Aguardando 5 segundos para receber dados via streaming...")
        await asyncio.sleep(5)
        
        # TESTE 1: Verificar cache de streaming
        logger.info("\n=== TESTE 1: Verificar cache de streaming ===")
        kline_data = await manager.get_optimized_data(
            "BTCUSDT", "kline", "1m", 
            lambda: simular_chamada_rest("BTCUSDT", "1m")
        )
        
        if kline_data:
            logger.info(f"Dados obtidos: {kline_data.get('source', 'streaming')} - close: {kline_data.get('close')}")
        else:
            logger.error("Não foi possível obter dados de kline")
        
        # TESTE 2: Verificar dados não disponíveis no streaming
        logger.info("\n=== TESTE 2: Verificar dados não disponíveis no streaming ===")
        # Tentar obter dados para um símbolo que não está no streaming
        bnb_data = await manager.get_optimized_data(
            "BNBUSDT", "kline", "1m", 
            lambda: simular_chamada_rest("BNBUSDT", "1m")
        )
        
        if bnb_data:
            logger.info(f"Dados obtidos: {bnb_data.get('source', 'desconhecido')} - close: {bnb_data.get('close')}")
        else:
            logger.error("Não foi possível obter dados de BNBUSDT")
        
        # TESTE 3: Verificar rate limit
        logger.info("\n=== TESTE 3: Verificar rate limit ===")
        # Fazer múltiplas chamadas em sequência para o mesmo recurso
        for i in range(3):
            logger.info(f"Chamada {i+1}/3 para BNBUSDT")
            data = await manager.get_optimized_data(
                "BNBUSDT", "kline", "1m", 
                lambda: simular_chamada_rest("BNBUSDT", "1m")
            )
            if data:
                logger.info(f"Dados obtidos: {data.get('source', 'desconhecido')} - close: {data.get('close')}")
            else:
                logger.warning("Chamada bloqueada pelo rate limit ou falhou")
            
            # Pequena pausa entre chamadas
            await asyncio.sleep(1)
        
        # TESTE 4: Forçar uso de REST
        logger.info("\n=== TESTE 4: Forçar uso de REST ===")
        force_rest_data = await manager.get_optimized_data(
            "BTCUSDT", "kline", "1m", 
            lambda: simular_chamada_rest("BTCUSDT", "1m"),
            force_rest=True
        )
        
        if force_rest_data:
            logger.info(f"Dados obtidos: {force_rest_data.get('source', 'desconhecido')} - close: {force_rest_data.get('close')}")
        else:
            logger.error("Não foi possível obter dados via REST forçado")
        
        # TESTE 5: Verificar expiração de cache
        logger.info("\n=== TESTE 5: Verificar expiração de cache ===")
        logger.info("Aguardando 11 segundos para expirar cache de ticker...")
        await asyncio.sleep(11)  # Ticker TTL é 10s
        
        ticker_data = await manager.get_optimized_data(
            "ETHUSDT", "ticker", None, 
            lambda: simular_chamada_rest("ETHUSDT")
        )
        
        if ticker_data:
            logger.info(f"Dados obtidos após expiração: {ticker_data.get('source', 'desconhecido')} - price: {ticker_data.get('price')}")
        else:
            logger.error("Não foi possível obter dados de ticker após expiração")
        
        # Estatísticas finais
        logger.info("\n=== ESTATÍSTICAS FINAIS ===")
        logger.info(f"Tamanho do cache de streaming (kline): {len(manager.kline_cache)}")
        logger.info(f"Tamanho do cache de streaming (ticker): {len(manager.ticker_cache)}")
        logger.info(f"Tamanho do cache agressivo: {len(manager.aggressive_cache)}")
        logger.info(f"Chamadas REST registradas: {len(manager.last_rest_call_times)}")
        
        # Parar streams
        logger.info("\nFinalizando teste...")
        await manager.parar()
        logger.info("Teste concluído com sucesso!")
        
    except Exception as e:
        logger.error(f"Erro durante o teste: {e}", exc_info=True)
        if 'manager' in locals():
            await manager.parar()

if __name__ == "__main__":
    asyncio.run(teste_otimizacao())
