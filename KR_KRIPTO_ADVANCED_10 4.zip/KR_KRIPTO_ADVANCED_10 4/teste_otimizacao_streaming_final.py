#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Teste de Otimização do Streaming da Binance

Este script testa as otimizações implementadas no módulo de streaming da Binance:
1. Priorização de dados de streaming sobre consultas REST
2. Cache agressivo para dados frequentemente acessados
3. Controle de intervalos entre chamadas REST

O teste simula diferentes cenários de acesso a dados e valida o comportamento
do sistema em cada um deles, mostrando as estatísticas de uso de cache e API.
"""

import asyncio
import logging
import sys
import time
import random
from datetime import datetime

# Configurar logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                   handlers=[logging.StreamHandler(sys.stdout)])

logger = logging.getLogger("teste_otimizacao")

# Importar o módulo de streaming otimizado
sys.path.append('/home/ubuntu')
try:
    from src.core.binance_stream import BinanceStreamManager
except ImportError:
    logger.error("Não foi possível importar BinanceStreamManager do arquivo otimizado.")
    sys.exit(1)

# Contador de chamadas REST
rest_calls = {
    "total": 0,
    "blocked": 0,
    "success": 0,
    "by_symbol": {}
}

# Contador de uso de cache
cache_stats = {
    "streaming_hits": 0,
    "aggressive_hits": 0,
    "misses": 0,
    "by_symbol": {}
}

# Mock para operador.obter_klines
async def mock_obter_klines(symbol, interval):
    """Simula uma chamada à API REST para obter klines."""
    rest_calls["total"] += 1
    
    if symbol not in rest_calls["by_symbol"]:
        rest_calls["by_symbol"][symbol] = 0
    rest_calls["by_symbol"][symbol] += 1
    
    # Simular latência da API
    await asyncio.sleep(0.2 + random.random() * 0.3)
    
    # Simular dados de kline
    timestamp = int(time.time() * 1000)
    rest_calls["success"] += 1
    
    logger.info(f"[MOCK REST] Chamada REST para {symbol} {interval} executada com sucesso")
    
    return {
        'open_time': timestamp,
        'open': 100.0 + random.random() * 10,
        'high': 110.0 + random.random() * 10,
        'low': 90.0 + random.random() * 10,
        'close': 105.0 + random.random() * 10,
        'volume': 1000.0 + random.random() * 100,
        'close_time': timestamp + 59999,
        'is_closed': True,
        'symbol': symbol,
        'interval': interval,
        'source': 'rest_api'
    }

# Mock para operador.obter_ticker
async def mock_obter_ticker(symbol):
    """Simula uma chamada à API REST para obter ticker."""
    rest_calls["total"] += 1
    
    if symbol not in rest_calls["by_symbol"]:
        rest_calls["by_symbol"][symbol] = 0
    rest_calls["by_symbol"][symbol] += 1
    
    # Simular latência da API
    await asyncio.sleep(0.1 + random.random() * 0.2)
    
    rest_calls["success"] += 1
    
    logger.info(f"[MOCK REST] Chamada REST para ticker {symbol} executada com sucesso")
    
    return {
        'symbol': symbol,
        'price': 100.0 + random.random() * 10,
        'price_change': random.random() * 2 - 1,
        'price_change_percent': (random.random() * 2 - 1) * 100,
        'volume': 10000.0 + random.random() * 1000,
        'source': 'rest_api'
    }

async def registrar_resultado_cache(symbol, resource_type, result_source):
    """Registra estatísticas de uso de cache."""
    if symbol not in cache_stats["by_symbol"]:
        cache_stats["by_symbol"][symbol] = {
            "streaming_hits": 0,
            "aggressive_hits": 0,
            "misses": 0
        }
    
    if result_source == "streaming":
        cache_stats["streaming_hits"] += 1
        cache_stats["by_symbol"][symbol]["streaming_hits"] += 1
    elif result_source == "aggressive":
        cache_stats["aggressive_hits"] += 1
        cache_stats["by_symbol"][symbol]["aggressive_hits"] += 1
    else:
        cache_stats["misses"] += 1
        cache_stats["by_symbol"][symbol]["misses"] += 1

async def teste_otimizacao():
    """Executa o teste de otimização do streaming."""
    logger.info("Iniciando teste de otimização do streaming da Binance")
    
    # Configuração de teste com otimizações
    config_teste = {
        "testnet": True,
        "execution_mode": "master",
        "websocket": {
            "max_reconnect_attempts": 5,
            "base_reconnect_delay": 1.0,
            "max_reconnect_delay": 30.0,
            "reconnect_jitter": 0.2,
            "connect_timeout": 15.0,
            "message_timeout": 30.0,
            "heartbeat_interval": 20.0
        },
        "data_source_optimization": {
            "prioritize_streaming": True,
            "fallback_to_rest": True,
            "use_aggressive_cache": True,
            "cache_ttl_seconds": {
                "kline_1m": 130,  # 2min + 10s buffer
                "kline_5m": 330,  # 5min + 30s buffer
                "ticker": 10,
                "depth": 5,
                "default": 60
            },
            "min_rest_interval_seconds": {
                "kline": 5,
                "ticker": 2,
                "depth": 2,
                "default": 5
            }
        },
        "dataframe_max_length": 1000
    }
    
    # Contexto global simplificado
    contexto_teste = {
        "dataframes": {},
        "last_kline_time": {},
        "dataframes_lock": asyncio.Lock(),
        "processadores_book": {},
        "memoria_temporal": {},
        "configuracao_global": config_teste,
        "gerenciador_fallback": None,
        "governor": None,
        "tracker": None,
        "context_switcher": None,
        "strategy_config": None,
        "attack_detector": None,
        "news_provider": None,
        "operador": None,
        "analisar_sinal_func": lambda **kwargs: logger.debug(f"[TESTE] analisar_sinal chamado para {kwargs.get('ativo')}")
    }
    
    # Inicializar gerenciador
    manager = BinanceStreamManager(config_teste, contexto_teste)
    
    # Callback para klines
    async def callback_kline(symbol, interval, kline_data):
        logger.info(f"[CALLBACK] Kline recebido para {symbol} {interval}: {kline_data.get('close')}")
        await registrar_resultado_cache(symbol, "kline", "streaming")
    
    # Callback para tickers
    async def callback_ticker(symbol, interval, ticker_data):
        logger.info(f"[CALLBACK] Ticker recebido para {symbol}: {ticker_data.get('price')}")
        await registrar_resultado_cache(symbol, "ticker", "streaming")
    
    # Registrar callbacks
    manager.registrar_callback("BTCUSDT_1m", callback_kline)
    manager.registrar_callback("ETHUSDT_ticker", callback_ticker)
    
    # Definir streams a serem iniciados
    streams_para_iniciar = [
        {'type': 'kline', 'symbol': 'BTCUSDT', 'interval': '1m'},
        {'type': 'ticker', 'symbol': 'ETHUSDT'}
    ]
    
    # Iniciar streams
    await manager.iniciar_streams(streams_para_iniciar)
    logger.info("Streams iniciados. Aguardando 5 segundos para receber dados iniciais...")
    await asyncio.sleep(5)
    
    # TESTE 1: Acesso a dados com streaming ativo
    logger.info("\n=== TESTE 1: Acesso a dados com streaming ativo ===")
    logger.info("Tentando obter dados de BTCUSDT 1m via get_optimized_data...")
    
    # Tentar obter dados de kline (deve vir do streaming)
    kline_data = await manager.get_optimized_data(
        symbol='BTCUSDT',
        resource_type='kline',
        interval='1m',
        rest_call_func=lambda: mock_obter_klines('BTCUSDT', '1m')
    )
    
    if kline_data:
        logger.info(f"Dados de kline obtidos: Close={kline_data.get('close')}")
        if 'received_timestamp' in kline_data:
            age = time.time() - kline_data['received_timestamp']
            logger.info(f"Idade dos dados: {age:.2f}s")
    else:
        logger.warning("Não foi possível obter dados de kline")
    
    # Tentar obter dados de ticker (deve vir do streaming)
    ticker_data = await manager.get_optimized_data(
        symbol='ETHUSDT',
        resource_type='ticker',
        rest_call_func=lambda: mock_obter_ticker('ETHUSDT')
    )
    
    if ticker_data:
        logger.info(f"Dados de ticker obtidos: Price={ticker_data.get('price')}")
        if 'received_timestamp' in ticker_data:
            age = time.time() - ticker_data['received_timestamp']
            logger.info(f"Idade dos dados: {age:.2f}s")
    else:
        logger.warning("Não foi possível obter dados de ticker")
    
    # TESTE 2: Acesso a dados não disponíveis no streaming (deve usar REST)
    logger.info("\n=== TESTE 2: Acesso a dados não disponíveis no streaming ===")
    logger.info("Tentando obter dados de ADAUSDT (não está no streaming)...")
    
    # Tentar obter dados de um símbolo não presente no streaming
    ada_data = await manager.get_optimized_data(
        symbol='ADAUSDT',
        resource_type='kline',
        interval='1m',
        rest_call_func=lambda: mock_obter_klines('ADAUSDT', '1m')
    )
    
    if ada_data:
        logger.info(f"Dados de ADAUSDT obtidos via REST: {ada_data.get('close')}")
        await registrar_resultado_cache('ADAUSDT', 'kline', 'rest')
    else:
        logger.warning("Não foi possível obter dados de ADAUSDT")
    
    # TESTE 3: Múltiplas chamadas em sequência (deve respeitar rate limit)
    logger.info("\n=== TESTE 3: Múltiplas chamadas em sequência (teste de rate limit) ===")
    logger.info("Executando 10 chamadas para XRPUSDT em sequência rápida...")
    
    for i in range(10):
        logger.info(f"Chamada {i+1}/10 para XRPUSDT...")
        xrp_data = await manager.get_optimized_data(
            symbol='XRPUSDT',
            resource_type='kline',
            interval='1m',
            rest_call_func=lambda: mock_obter_klines('XRPUSDT', '1m')
        )
        
        if xrp_data:
            source = "rest" if xrp_data.get('source') == 'rest_api' else "aggressive"
            logger.info(f"Dados de XRPUSDT obtidos via {source}: {xrp_data.get('close')}")
            await registrar_resultado_cache('XRPUSDT', 'kline', source)
        else:
            logger.warning("Não foi possível obter dados de XRPUSDT")
            rest_calls["blocked"] += 1
        
        # Pequena pausa entre chamadas
        await asyncio.sleep(0.5)
    
    # TESTE 4: Forçar uso de REST ignorando cache
    logger.info("\n=== TESTE 4: Forçar uso de REST ignorando cache ===")
    logger.info("Tentando obter dados de BTCUSDT forçando REST...")
    
    btc_force_rest = await manager.get_optimized_data(
        symbol='BTCUSDT',
        resource_type='kline',
        interval='1m',
        rest_call_func=lambda: mock_obter_klines('BTCUSDT', '1m'),
        force_rest=True
    )
    
    if btc_force_rest:
        logger.info(f"Dados de BTCUSDT obtidos forçando REST: {btc_force_rest.get('close')}")
        await registrar_resultado_cache('BTCUSDT', 'kline', 'rest')
    else:
        logger.warning("Não foi possível obter dados de BTCUSDT forçando REST")
    
    # TESTE 5: Esperar expiração do cache e verificar comportamento
    logger.info("\n=== TESTE 5: Teste de expiração de cache ===")
    logger.info("Aguardando 15 segundos para expirar cache de ticker...")
    await asyncio.sleep(15)
    
    # Tentar obter ticker após expiração do cache (TTL = 10s)
    logger.info("Tentando obter ticker de ETHUSDT após expiração do cache...")
    ticker_expired = await manager.get_optimized_data(
        symbol='ETHUSDT',
        resource_type='ticker',
        rest_call_func=lambda: mock_obter_ticker('ETHUSDT')
    )
    
    if ticker_expired:
        source = "rest" if ticker_expired.get('source') == 'rest_api' else "streaming"
        logger.info(f"Dados de ticker obtidos via {source} após expiração: {ticker_expired.get('price')}")
        await registrar_resultado_cache('ETHUSDT', 'ticker', source)
    else:
        logger.warning("Não foi possível obter dados de ticker após expiração")
    
    # Parar streams
    logger.info("\nFinalizando teste. Parando streams...")
    await manager.parar()
    
    # Exibir estatísticas finais
    logger.info("\n=== ESTATÍSTICAS FINAIS ===")
    logger.info(f"Chamadas REST: Total={rest_calls['total']}, Sucesso={rest_calls['success']}, Bloqueadas={rest_calls['blocked']}")
    logger.info(f"Cache: Streaming={cache_stats['streaming_hits']}, Agressivo={cache_stats['aggressive_hits']}, Misses={cache_stats['misses']}")
    
    logger.info("\nEstatísticas por símbolo:")
    all_symbols = set(list(rest_calls.get("by_symbol", {}).keys()) + list(cache_stats.get("by_symbol", {}).keys()))
    
    for symbol in all_symbols:
        rest_count = rest_calls.get("by_symbol", {}).get(symbol, 0)
        cache_symbol_stats = cache_stats.get("by_symbol", {}).get(symbol, {"streaming_hits": 0, "aggressive_hits": 0, "misses": 0})
        
        logger.info(f"{symbol}: REST={rest_count}, Streaming={cache_symbol_stats['streaming_hits']}, "
                   f"Agressivo={cache_symbol_stats['aggressive_hits']}, Misses={cache_symbol_stats['misses']}")
    
    logger.info("\nTeste de otimização concluído!")

if __name__ == "__main__":
    try:
        asyncio.run(teste_otimizacao())
    except KeyboardInterrupt:
        logger.info("Teste interrompido pelo usuário.")
    except Exception as e:
        logger.error(f"Erro durante o teste: {e}", exc_info=True)
