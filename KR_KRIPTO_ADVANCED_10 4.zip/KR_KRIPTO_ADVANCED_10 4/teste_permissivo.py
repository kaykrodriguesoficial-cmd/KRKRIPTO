#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de teste com configuração permissiva para diagnóstico de entradas
"""

import os
import sys
import json
import logging
import asyncio
import time
from datetime import datetime

# Configurar logging
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("teste_permissivo.log"),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger("teste_permissivo")

# Importar o main instrumentado
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import main_instrumentado as main

async def teste_permissivo():
    """Executa o sistema com configuração permissiva para diagnóstico"""
    try:
        # Carregar configuração permissiva
        with open("config_permissivo.json", "r") as f:
            config = json.load(f)
        
        logger.info("Iniciando teste com configuração permissiva")
        logger.info(f"Limiar de compra: {config['limiar_compra']}")
        logger.info(f"Limiar de venda: {config['limiar_venda']}")
        
        # Substituir a configuração no main
        main.config = config
        
        # Inicializar componentes
        success = main.inicializar_componentes(config)
        if not success:
            logger.error("Falha ao inicializar componentes")
            return
        
        # Executar o loop principal por tempo limitado (30 minutos)
        logger.info("Iniciando loop principal com timeout de 30 minutos")
        start_time = time.time()
        max_runtime = 30 * 60  # 30 minutos
        
        while time.time() - start_time < max_runtime:
            # Processar cada ativo e intervalo
            for ativo in config["ativos"]:
                for intervalo in config["intervalos"]:
                    try:
                        # Obter dados históricos
                        if "operador_binance" in main.components:
                            operador = main.components["operador_binance"]
                            klines = await operador.obter_klines(ativo, intervalo, limit=100)
                            
                            if klines is not None and len(klines) > 0:
                                # Converter para DataFrame
                                import pandas as pd
                                df = pd.DataFrame(klines)
                                
                                # Processar dados
                                resultado = main.processar_dados(df, ativo, intervalo)
                                
                                # Verificar se gerou sinal
                                if resultado["status"] == "OK" and resultado["sinal"] != "HOLD":
                                    logger.info(f"SINAL GERADO: {resultado['sinal']} para {ativo} ({intervalo})")
                                    
                                    # Tentar executar operação
                                    op_result = main.executar_operacao(
                                        resultado["sinal"],
                                        ativo,
                                        resultado["ultimo_preco"],
                                        resultado.get("stop_loss"),
                                        resultado.get("take_profit")
                                    )
                                    
                                    logger.info(f"Resultado da operação: {op_result}")
                    except Exception as e:
                        logger.error(f"Erro ao processar {ativo} ({intervalo}): {str(e)}")
            
            # Aguardar antes do próximo ciclo
            await asyncio.sleep(60)
            logger.info(f"Tempo decorrido: {(time.time() - start_time) / 60:.1f} minutos")
        
        logger.info("Teste concluído após 30 minutos")
    except Exception as e:
        logger.error(f"Erro durante o teste: {str(e)}")
    finally:
        # Limpar recursos
        if hasattr(main, "components") and "operador_binance" in main.components:
            operador = main.components["operador_binance"]
            if hasattr(operador, "fechar_cliente"):
                await operador.fechar_cliente()

if __name__ == "__main__":
    asyncio.run(teste_permissivo())
