#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Teste de resiliência para o módulo binance_stream fundido.
Este script testa a capacidade de reconexão, circuit breaker e recuperação de falhas.
"""

import asyncio
import logging
import sys
import time
import random
from datetime import datetime

# Ajuste o caminho de importação conforme necessário
import sys
sys.path.append("/Volumes/Extreme SSD/KR_KRIPTO_ADVANCED")

try:
    from src.core.binance_stream import BinanceStreamManager
except ImportError:
    print("Erro ao importar BinanceStreamManager. Verifique o caminho de importação.")
    sys.exit(1)

# Configurar logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                   handlers=[logging.StreamHandler(sys.stdout)])

logger = logging.getLogger("teste_resiliencia")

# Estatísticas de teste
class TesteStats:
    def __init__(self):
        self.mensagens_recebidas = 0
        self.callbacks_executados = 0
        self.reconexoes_detectadas = 0
        self.falhas_simuladas = 0
        self.inicio_teste = time.time()
    
    def imprimir_resumo(self):
        duracao = time.time() - self.inicio_teste
        logger.info(f"=== RESUMO DO TESTE DE RESILIÊNCIA ===")
        logger.info(f"Duração total: {duracao:.1f} segundos")
        logger.info(f"Mensagens recebidas: {self.mensagens_recebidas}")
        logger.info(f"Callbacks executados: {self.callbacks_executados}")
        logger.info(f"Reconexões detectadas: {self.reconexoes_detectadas}")
        logger.info(f"Falhas simuladas: {self.falhas_simuladas}")
        logger.info(f"Taxa de mensagens: {self.mensagens_recebidas/duracao:.2f} msgs/s")
        logger.info(f"====================================")

# Configuração de teste
config_teste = {
    "testnet": True,  # Usar testnet para não afetar ambiente de produção
    "execution_mode": "master",
    "websocket": {
        "max_reconnect_attempts": 10,
        "base_reconnect_delay": 1.0,
        "max_reconnect_delay": 30.0,
        "reconnect_jitter": 0.2,
        "connect_timeout": 10.0,
        "message_timeout": 20.0,
        "heartbeat_interval": 10.0
    }
}

# Contexto global simplificado
contexto_teste = {
    "dataframes": {},
    "last_kline_time": {},
    "dataframes_lock": asyncio.Lock(),
    "processadores_book": {},
    "memoria_temporal": {},
    "configuracao_global": config_teste,
    "gerenciador_fallback": None,
    "governor": None,
    "tracker": None,
    "context_switcher": None,
    "strategy_config": None,
    "attack_detector": None,
    "news_provider": None,
    "operador": None,
    "analisar_sinal_func": lambda **kwargs: logger.info(f"[TESTE] analisar_sinal chamado para {kwargs.get('ativo')}")
}

# Estatísticas globais
stats = TesteStats()

# Callbacks de teste
async def callback_kline(symbol, interval, data):
    stats.callbacks_executados += 1
    if data.get('is_closed', False):
        logger.info(f"[CALLBACK KLINE] {symbol} {interval} fechado: {data.get('close')}")
    else:
        logger.debug(f"[CALLBACK KLINE] {symbol} {interval} atualização")

async def callback_ticker(symbol, interval, data):
    stats.callbacks_executados += 1
    logger.info(f"[CALLBACK TICKER] {symbol}: Preço={data.get('price')}")

# Simulador de falhas de rede
class SimuladorFalhas:
    def __init__(self, manager):
        self.manager = manager
        self.running = False
        self.task = None
    
    async def iniciar(self, intervalo_min=30, intervalo_max=90):
        """Inicia o simulador de falhas com intervalo aleatório entre falhas"""
        self.running = True
        self.task = asyncio.create_task(self._loop_simulacao(intervalo_min, intervalo_max))
        logger.info(f"Simulador de falhas iniciado (intervalo: {intervalo_min}-{intervalo_max}s)")
    
    async def _loop_simulacao(self, intervalo_min, intervalo_max):
        """Loop principal de simulação de falhas"""
        while self.running:
            # Aguardar intervalo aleatório
            intervalo = random.uniform(intervalo_min, intervalo_max)
            await asyncio.sleep(intervalo)
            if not self.running:
                break
            
            # Simular falha
            await self._simular_falha()
    
    async def _simular_falha(self):
        """Simula uma falha de rede fechando uma conexão WebSocket aleatória"""
        if not self.manager.websockets:
            logger.warning("Sem conexões WebSocket para simular falha")
            return
        
        # Selecionar uma conexão aleatória
        stream_name = random.choice(list(self.manager.websockets.keys()))
        ws = self.manager.websockets.get(stream_name)
        
        if ws and not ws.closed:
            stats.falhas_simuladas += 1
            logger.warning(f"[SIMULAÇÃO] Forçando fechamento da conexão {stream_name}")
            
            # Fechar conexão
            try:
                await ws.close()
                logger.info(f"[SIMULAÇÃO] Conexão {stream_name} fechada com sucesso")
            except Exception as e:
                logger.error(f"[SIMULAÇÃO] Erro ao fechar conexão {stream_name}: {e}")
    
    async def parar(self):
        """Para o simulador de falhas"""
        self.running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
        logger.info("Simulador de falhas parado")

# Monitor de estatísticas
class MonitorEstatisticas:
    def __init__(self, manager):
        self.manager = manager
        self.running = False
        self.task = None
        self.ultima_contagem = {}
    
    async def iniciar(self, intervalo=15):
        """Inicia o monitor de estatísticas"""
        self.running = True
        self.task = asyncio.create_task(self._loop_monitoramento(intervalo))
        logger.info(f"Monitor de estatísticas iniciado (intervalo: {intervalo}s)")
    
    async def _loop_monitoramento(self, intervalo):
        """Loop principal de monitoramento"""
        while self.running:
            await asyncio.sleep(intervalo)
            if not self.running:
                break
            
            await self._coletar_estatisticas()
    
    async def _coletar_estatisticas(self):
        """Coleta e exibe estatísticas de conexão"""
        logger.info("=== ESTATÍSTICAS DE CONEXÃO ===")
        
        for symbol, stats_conn in self.manager.connection_stats.items():
            estat = stats_conn.obter_estatisticas()
            
            # Calcular mensagens desde última verificação
            msgs_total = sum(estat['mensagens_por_tipo'].values())
            msgs_anterior = sum(self.ultima_contagem.get(symbol, {}).values())
            msgs_delta = msgs_total - msgs_anterior
            
            # Atualizar contagem anterior
            self.ultima_contagem[symbol] = estat['mensagens_por_tipo'].copy()
            
            # Registrar estatísticas globais
            stats.mensagens_recebidas = msgs_total
            if estat['reconexoes'] > 0:
                stats.reconexoes_detectadas = estat['reconexoes']
            
            # Exibir estatísticas
            logger.info(f"[{symbol}] Status: {estat['status_conexao']}")
            logger.info(f"[{symbol}] Mensagens: {msgs_total} (+{msgs_delta} novas)")
            logger.info(f"[{symbol}] Tipos: {estat['mensagens_por_tipo']}")
            logger.info(f"[{symbol}] Reconexões: {estat['reconexoes']}")
            logger.info(f"[{symbol}] Tempo conectado: {estat['tempo_total_conectado']:.1f}s")
            logger.info(f"[{symbol}] Circuit breaker: {estat['circuit_breaker_ativo']}")
        
        logger.info("==============================")
    
    async def parar(self):
        """Para o monitor de estatísticas"""
        self.running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
        logger.info("Monitor de estatísticas parado")

async def main():
    logger.info("=== INICIANDO TESTE DE RESILIÊNCIA DO BINANCE STREAM ===")
    logger.info(f"Data/Hora: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info("Configuração: Testnet, 2 streams, simulação de falhas")
    
    # Inicializar gerenciador
    manager = BinanceStreamManager(config_teste, contexto_teste)
    
    # Registrar callbacks
    manager.registrar_callback("BTCUSDT_1m", callback_kline)
    manager.registrar_callback("BTCUSDT_ticker", callback_ticker)
    
    # Definir streams para teste
    streams_teste = [
        {'type': 'kline', 'symbol': 'BTCUSDT', 'interval': '1m'},
        {'type': 'ticker', 'symbol': 'BTCUSDT'}
    ]
    
    # Inicializar monitor e simulador
    monitor = MonitorEstatisticas(manager)
    simulador = SimuladorFalhas(manager)
    
    try:
        # Iniciar streams
        logger.info("Iniciando streams...")
        await manager.iniciar_streams(streams_teste)
        
        # Aguardar conexão inicial
        logger.info("Aguardando conexão inicial (10s)...")
        await asyncio.sleep(10)
        
        # Iniciar monitor de estatísticas
        await monitor.iniciar(intervalo=15)
        
        # Iniciar simulador de falhas após 30s
        logger.info("Aguardando 30s antes de iniciar simulação de falhas...")
        await asyncio.sleep(30)
        await simulador.iniciar(intervalo_min=30, intervalo_max=60)
        
        # Duração total do teste: 5 minutos
        logger.info("Teste em execução por 5 minutos...")
        await asyncio.sleep(300 - 40)  # 5 minutos menos o tempo já aguardado
        
    except KeyboardInterrupt:
        logger.info("Teste interrompido pelo usuário")
    except Exception as e:
        logger.error(f"Erro durante teste: {e}", exc_info=True)
    finally:
        # Parar simulador e monitor
        logger.info("Finalizando teste...")
        await simulador.parar()
        await monitor.parar()
        
        # Parar streams
        await manager.parar()
        
        # Exibir resumo
        stats.imprimir_resumo()
        logger.info("Teste finalizado.")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Teste interrompido pelo usuário")
