#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Teste Completo da Integração RL + Multi-Timeframe

Este script testa a integração completa do sistema de RL com multi-timeframe,
simulando um ambiente de trading real.

Autor: Manus AI
Data: 30/08/2025
"""

import sys
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import json

# Importar nossa integração
from rl_multitimeframe_integration import RLMultiTimeframeAgent, criar_agente_rl_multitimeframe

def gerar_dados_simulados(symbol: str, timeframe: str, periods: int = 100) -> pd.DataFrame:
    """
    Gera dados simulados de mercado para teste.
    
    Args:
        symbol: Símbolo do ativo
        timeframe: Timeframe dos dados
        periods: Número de períodos
        
    Returns:
        pd.DataFrame: Dados simulados
    """
    # Gerar dados realistas
    np.random.seed(42)  # Para reprodutibilidade
    
    # Preço inicial
    initial_price = 50000.0 if 'BTC' in symbol else 3000.0
    
    # Gerar retornos com tendência e volatilidade
    returns = np.random.normal(0.0001, 0.02, periods)  # Retornos diários ~2% vol
    
    # Adicionar tendência sutil
    trend = np.linspace(0, 0.1, periods)  # Tendência de alta de 10%
    returns += trend / periods
    
    # Calcular preços
    prices = [initial_price]
    for ret in returns:
        new_price = prices[-1] * (1 + ret)
        prices.append(new_price)
    
    prices = prices[1:]  # Remover preço inicial duplicado
    
    # Gerar OHLC
    data = []
    for i, close in enumerate(prices):
        # Simular variação intraday
        high = close * (1 + abs(np.random.normal(0, 0.005)))
        low = close * (1 - abs(np.random.normal(0, 0.005)))
        open_price = prices[i-1] if i > 0 else close
        
        # Volume simulado
        volume = np.random.uniform(1000, 10000)
        
        # Timestamp
        timestamp = datetime.now() - timedelta(hours=periods-i)
        
        data.append({
            'timestamp': timestamp,
            'open': open_price,
            'high': high,
            'low': low,
            'close': close,
            'volume': volume
        })
    
    df = pd.DataFrame(data)
    
    # Adicionar indicadores técnicos básicos
    df['rsi'] = 50 + np.random.normal(0, 15, len(df))  # RSI simulado
    df['rsi'] = np.clip(df['rsi'], 0, 100)
    
    df['macd'] = np.random.normal(0, 0.1, len(df))
    df['macd_signal'] = df['macd'] * 0.8 + np.random.normal(0, 0.05, len(df))
    df['macd_hist'] = df['macd'] - df['macd_signal']
    
    # Médias móveis
    df['sma_20'] = df['close'].rolling(window=min(20, len(df))).mean().fillna(df['close'])
    df['ema_9'] = df['close'].ewm(span=9).mean()
    
    return df

def executar_teste_completo():
    """
    Executa teste completo da integração RL + Multi-timeframe.
    """
    print("🚀 INICIANDO TESTE COMPLETO - INTEGRAÇÃO RL + MULTI-TIMEFRAME")
    print("=" * 70)
    
    # 1. Configurar agente
    config = {
        'ativo': 'BTCUSDT',
        'timeframes': ['15m', '1h', '4h', '1d'],
        'learning_rate': 0.01,  # Mais agressivo para teste
        'epsilon': 0.3,         # Mais exploração
        'gamma': 0.95
    }
    
    print("🤖 Criando agente RL multi-timeframe...")
    agente = criar_agente_rl_multitimeframe(config)
    print(f"✅ Agente criado para {agente.ativo}")
    
    # 2. Gerar dados simulados para múltiplos timeframes
    print("\n📊 Gerando dados simulados...")
    dados_por_tf = {}
    
    timeframe_periods = {
        '15m': 200,
        '1h': 150, 
        '4h': 100,
        '1d': 60
    }
    
    for tf in agente.timeframes:
        periods = timeframe_periods.get(tf, 100)
        dados_por_tf[tf] = gerar_dados_simulados('BTCUSDT', tf, periods)
        print(f"  ✅ {tf}: {len(dados_por_tf[tf])} períodos gerados")
    
    # 3. Executar simulação de treinamento
    print("\n🧠 Executando simulação de treinamento...")
    
    # Usar dados de 1h como referência principal para preços
    price_data = dados_por_tf['1h']
    num_steps = min(50, len(price_data) - 1)  # Limitar para teste
    
    resultados = []
    
    for step in range(num_steps):
        print(f"\r  📈 Passo {step+1}/{num_steps}", end="", flush=True)
        
        # Executar passo de treinamento
        resultado = agente.train_step(dados_por_tf, price_data, step)
        resultados.append(resultado)
        
        # Log a cada 10 passos
        if (step + 1) % 10 == 0:
            action_names = ['MANTER', 'COMPRAR', 'VENDER']
            action_name = action_names[resultado['action']]
            print(f"\n    🎯 Passo {step+1}: {action_name} | Reward: {resultado['reward']:.3f} | Epsilon: {resultado['epsilon']:.3f}")
    
    print(f"\n✅ Treinamento concluído: {num_steps} passos")
    
    # 4. Analisar resultados
    print("\n📊 ANÁLISE DOS RESULTADOS:")
    print("-" * 40)
    
    # Métricas do agente
    metrics = agente.get_performance_metrics()
    print(f"📈 Total de trades: {metrics['total_trades']}")
    print(f"✅ Trades bem-sucedidos: {metrics['successful_trades']}")
    print(f"🎯 Taxa de sucesso: {metrics['success_rate']:.1%}")
    print(f"💰 Lucro total: {metrics['total_profit']:.4f}")
    print(f"🏆 Reward médio: {metrics['avg_reward']:.4f}")
    print(f"📊 Score médio: {metrics['avg_score']:.2f}")
    print(f"🧠 Epsilon final: {metrics['epsilon']:.4f}")
    print(f"🗂️ Tamanho Q-table: {metrics['q_table_size']}")
    
    # Análise das ações
    acoes = [r['action'] for r in resultados]
    action_counts = {0: acoes.count(0), 1: acoes.count(1), 2: acoes.count(2)}
    action_names = {0: 'MANTER', 1: 'COMPRAR', 2: 'VENDER'}
    
    print(f"\n🎯 DISTRIBUIÇÃO DE AÇÕES:")
    for action_id, count in action_counts.items():
        percentage = (count / len(acoes)) * 100
        print(f"  {action_names[action_id]}: {count} ({percentage:.1f}%)")
    
    # Análise das recompensas
    rewards = [r['reward'] for r in resultados]
    print(f"\n🏆 ANÁLISE DE RECOMPENSAS:")
    print(f"  Recompensa total: {sum(rewards):.4f}")
    print(f"  Recompensa média: {np.mean(rewards):.4f}")
    print(f"  Recompensa máxima: {max(rewards):.4f}")
    print(f"  Recompensa mínima: {min(rewards):.4f}")
    print(f"  Desvio padrão: {np.std(rewards):.4f}")
    
    # 5. Testar salvamento/carregamento
    print(f"\n💾 Testando salvamento/carregamento...")
    
    model_path = "models/rl_multitf_test.json"
    agente.save_model(model_path)
    
    # Criar novo agente e carregar modelo
    agente_novo = criar_agente_rl_multitimeframe(config)
    sucesso_carregamento = agente_novo.load_model(model_path)
    
    if sucesso_carregamento:
        print("✅ Modelo salvo e carregado com sucesso")
        print(f"📊 Q-table carregada: {len(agente_novo.q_table)} estados")
    else:
        print("❌ Erro no salvamento/carregamento")
    
    # 6. Teste de predição
    print(f"\n🔮 Testando predição com modelo treinado...")
    
    # Usar último estado para predição
    if resultados:
        ultimo_resultado = resultados[-1]
        state_features = np.array(ultimo_resultado['state_features'])
        multitf_result = ultimo_resultado['multitf_result']
        
        # Fazer predição
        acao_predita = agente.choose_action(state_features, multitf_result)
        action_names = ['MANTER', 'COMPRAR', 'VENDER']
        
        print(f"🎯 Ação predita: {action_names[acao_predita]}")
        print(f"📊 Score multi-TF: {multitf_result.get('scoring', {}).get('score_total', 0):.1f}/30")
        print(f"🔄 Confluência: {multitf_result.get('confluencia', {}).get('nivel_otimizado', 'N/A')}")
    
    # 7. Resumo final
    print(f"\n🎉 TESTE COMPLETO FINALIZADO!")
    print("=" * 70)
    print("✅ Integração RL + Multi-timeframe funcionando")
    print("✅ Aprendizado adaptativo ativo")
    print("✅ Confluência temporal integrada")
    print("✅ Sistema pronto para FASE 2")
    
    return {
        'agente': agente,
        'resultados': resultados,
        'metrics': metrics,
        'dados_por_tf': dados_por_tf
    }

if __name__ == "__main__":
    try:
        resultado_teste = executar_teste_completo()
        print(f"\n🚀 Teste executado com sucesso!")
        
    except Exception as e:
        print(f"\n❌ Erro durante o teste: {e}")
        import traceback
        traceback.print_exc()

