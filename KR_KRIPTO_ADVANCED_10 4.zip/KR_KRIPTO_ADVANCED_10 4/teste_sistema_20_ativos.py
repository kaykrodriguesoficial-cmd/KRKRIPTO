#!/usr/bin/env python3
import json
import asyncio

def carregar_config(arquivo):
    with open(arquivo, 'r') as f:
        return json.load(f)

async def main():
    print("🔍 TESTE SISTEMA 20 ATIVOS")
    print("=" * 50)
    
    config = carregar_config('config.json')
    symbols = config.get('symbols', [])
    ativos = config.get('ativos', {})
    
    print(f"✅ Symbols carregados: {len(symbols)}")
    print(f"✅ Ativos carregados: {len(ativos)}")
    print(f"✅ Primeiros 5 symbols: {symbols[:5]}")
    
    if len(symbols) == 20 and len(ativos) == 20:
        print("\n🎉 SUCESSO! Sistema pode processar 20 ativos!")
        return True
    else:
        print("\n❌ FALHA! Problema na configuração!")
        return False

if __name__ == "__main__":
    asyncio.run(main())
