# Salve como teste_stream.py
import asyncio
import logging
import sys
from src.core.binance_stream import BinanceStreamManager

# Configurar logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                   handlers=[logging.StreamHandler(sys.stdout)])

# Configuração de teste
config_teste = {
    "testnet": True,  # Usar testnet para não afetar ambiente de produção
    "execution_mode": "master",
    "websocket": {
        "max_reconnect_attempts": 5,
        "base_reconnect_delay": 1.0,
        "max_reconnect_delay": 30.0,
        "reconnect_jitter": 0.2,
        "connect_timeout": 15.0,
        "message_timeout": 30.0,
        "heartbeat_interval": 20.0
    }
}

# Contexto global simplificado
contexto_teste = {
    "dataframes": {},
    "last_kline_time": {},
    "dataframes_lock": asyncio.Lock(),
    "processadores_book": {},
    "memoria_temporal": {},
    "configuracao_global": config_teste,
    "gerenciador_fallback": None,
    "governor": None,
    "tracker": None,
    "context_switcher": None,
    "strategy_config": None,
    "attack_detector": None,
    "news_provider": None,
    "operador": None,
    "analisar_sinal_func": lambda **kwargs: print(f"[TESTE] analisar_sinal chamado para {kwargs.get('ativo')}")
}

# Callback de teste
async def callback_teste(symbol, interval, data):
    print(f"[CALLBACK] Recebido {symbol} {interval}: {data}")

async def main():
    print("Iniciando teste do BinanceStreamManager...")
    
    # Inicializar gerenciador
    manager = BinanceStreamManager(config_teste, contexto_teste)
    
    # Registrar callback
    manager.registrar_callback("BTCUSDT_1m", callback_teste)
    
    # Definir streams para teste
    streams_teste = [
        {'type': 'kline', 'symbol': 'BTCUSDT', 'interval': '1m'},
        {'type': 'ticker', 'symbol': 'BTCUSDT'}
    ]
    
    try:
        # Iniciar streams
        print("Iniciando streams...")
        await manager.iniciar_streams(streams_teste)
        
        # Manter rodando por 2 minutos
        print("Streams iniciados. Aguardando 2 minutos para receber dados...")
        await asyncio.sleep(120)
        
    except Exception as e:
        print(f"Erro durante teste: {e}")
    finally:
        # Parar streams
        print("Parando streams...")
        await manager.parar()
        print("Teste finalizado.")

if __name__ == "__main__":
    asyncio.run(main())

