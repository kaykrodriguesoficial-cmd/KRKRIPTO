# tests/core/test_data_handler.py
import pytest
import pandas as pd
import os
from unittest.mock import patch, mock_open

# Adjust the path to import from the src directory
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../src')))

from core.data_handler import carregar_dados_historicos

# --- Fixtures ---

@pytest.fixture
def valid_csv_data():
    # Sample data matching expected format after processing in process_csv.py
    return "timestamp,open,high,low,close,volume\n2023-01-01 00:00:00,16500,16550,16450,16520,100\n2023-01-01 01:00:00,16520,16600,16510,16580,120"

@pytest.fixture
def csv_missing_cols_data():
    return "timestamp,open,high,low,volume\n2023-01-01 00:00:00,16500,16550,16450,100"

@pytest.fixture
def csv_bad_timestamp_data():
    return "timestamp,open,high,low,close,volume\nnot-a-date,16500,16550,16450,16520,100"

@pytest.fixture
def empty_csv_data():
    return "timestamp,open,high,low,close,volume\n"

# --- Test Cases ---

def test_carregar_dados_historicos_valid(tmp_path, valid_csv_data):
    """Test loading valid historical data."""
    ativo = "TESTBTC"
    # Criar o arquivo no local e nome esperados pela lógica de fallback da função
    # A função tentará {ativo}_{timeframe}.csv, depois {ativo}.csv
    file_path = tmp_path / f"{ativo}.csv"
    with open(file_path, 'w') as f:
        f.write(valid_csv_data)

    df = carregar_dados_historicos(ativo=ativo, data_dir=str(tmp_path)) 
    
    assert isinstance(df, pd.DataFrame), "df deveria ser um DataFrame"
    assert not df.empty, "df não deveria estar vazio"
    assert len(df) == 2, "df deveria ter 2 linhas"
    assert isinstance(df.index, pd.DatetimeIndex), "Índice do df deveria ser DatetimeIndex"
    assert list(df.columns) == ["Open", "High", "Low", "Close", "Volume"], "Nomes de colunas incorretos"
    assert df.index.name == "Timestamp", "Nome do índice incorreto"

def test_carregar_dados_historicos_non_existent(tmp_path):
    """Test loading non-existent file."""
    ativo = "TESTBTC_NONEXISTENT"
    # Não criar nenhum arquivo para este ativo em tmp_path
    df = carregar_dados_historicos(ativo=ativo, data_dir=str(tmp_path))
    # A função tem uma lógica de fallback para um arquivo de simulação padrão se nada for encontrado.
    # Se esse arquivo de simulação padrão NÃO existir, então retornará None.
    # Vamos assumir por agora que o teste espera None se o arquivo específico não for encontrado
    # e o fallback de simulação não estiver presente no ambiente de teste.
    # Para um teste mais robusto, poderíamos mockar os.path.exists para o arquivo de simulação.
    # Por enquanto, se a lógica de fallback do simulador estiver ativa, este teste pode precisar de ajuste.
    # Verificando a implementação: ele tenta carregar 'src/tests/e2e/data/e2e_volatile_data_synthetic.csv'
    # Se este arquivo existir, o teste falhará. Para garantir que retorne None, precisamos que esse fallback não exista.
    # Ou, se o objetivo é testar que NENHUM arquivo para o ativo é encontrado, o comportamento atual da função é retornar dados de simulação.
    # Para testar o retorno de None, o arquivo de simulação padrão também não deve existir.
    # Vou assumir que o teste original esperava None se o arquivo do ativo não existisse.
    # Para forçar isso, vamos mockar o os.path.exists para o arquivo de simulação.
    with patch('core.data_handler.os.path.exists') as mock_exists:
        # Configurar o mock para retornar False para o arquivo de simulação
        # e True para o diretório (se a função verificar a existência do diretório, o que não parece ser o caso)
        # A chamada original para o arquivo do ativo já terá retornado False.
        def side_effect(path_checked):
            if "e2e_volatile_data_synthetic.csv" in path_checked:
                return False # Simula que o arquivo de fallback não existe
            if path_checked == str(tmp_path / f"{ativo}_1m.csv") or path_checked == str(tmp_path / f"{ativo}.csv") :
                 return False # Arquivos do ativo não existem
            return os.path.exists(path_checked) # Comportamento original para outros caminhos
        mock_exists.side_effect = side_effect
        df = carregar_dados_historicos(ativo=ativo, data_dir=str(tmp_path))
        assert df is None, "df deveria ser None para arquivo inexistente sem fallback de simulação"

def test_carregar_dados_historicos_missing_cols(tmp_path, csv_missing_cols_data):
    """Test loading CSV with missing required columns."""
    ativo = "TESTBTC"
    file_path = tmp_path / f"{ativo}.csv"
    with open(file_path, 'w') as f:
        f.write(csv_missing_cols_data)

    df = carregar_dados_historicos(ativo=ativo, data_dir=str(tmp_path))
    # A função foi ajustada para retornar None se colunas OHLC essenciais estiverem faltando.
    # O teste agora espera explicitamente None neste cenário.
    assert df is None, "df deveria ser None se colunas OHLC essenciais estiverem faltando após o carregamento"

def test_carregar_dados_historicos_bad_timestamp(tmp_path, csv_bad_timestamp_data):
    """Test loading CSV with invalid timestamp format."""
    ativo = "TESTBTC"
    file_path = tmp_path / f"{ativo}.csv"
    with open(file_path, 'w') as f:
        f.write(csv_bad_timestamp_data)

    df = carregar_dados_historicos(ativo=ativo, data_dir=str(tmp_path))
    # A função tenta converter timestamp e loga erro, mas não retorna None explicitamente.
    # Se a conversão do timestamp falhar e resultar em NaT, o índice pode ser problemático.
    # O teste original esperava `assert df is None`.
    # Similar ao caso de colunas faltando, a função deveria ser mais robusta.
    # Vou manter a asserção original e ajustar a função se necessário.
    assert df is None, "df deveria ser None se o timestamp for inválido e não puder ser processado"

def test_carregar_dados_historicos_empty_file(tmp_path, empty_csv_data):
    """Test loading an empty CSV file (only headers)."""
    ativo = "TESTBTC"
    file_path = tmp_path / f"{ativo}.csv"
    with open(file_path, 'w') as f:
        f.write(empty_csv_data)
        
    df = carregar_dados_historicos(ativo=ativo, data_dir=str(tmp_path))
    
    assert isinstance(df, pd.DataFrame), "df deveria ser um DataFrame"
    assert df.empty, "df deveria estar vazio"

@patch("pandas.read_csv", side_effect=PermissionError("Permission denied"))
def test_carregar_dados_historicos_permission_error(mock_read_csv, tmp_path):
    """Test handling PermissionError during file read."""
    ativo = "TESTBTC"
    # A função tentará construir o caminho, mas o mock no read_csv interceptará.
    df = carregar_dados_historicos(ativo=ativo, data_dir=str(tmp_path))
    assert df is None

@patch("pandas.read_csv", side_effect=Exception("Unexpected read error"))
def test_carregar_dados_historicos_other_exception(mock_read_csv, tmp_path):
    """Test handling other unexpected exceptions during loading."""
    ativo = "TESTBTC"
    df = carregar_dados_historicos(ativo=ativo, data_dir=str(tmp_path))
    assert df is None


