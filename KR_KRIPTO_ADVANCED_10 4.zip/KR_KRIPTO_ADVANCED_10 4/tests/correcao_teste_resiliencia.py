#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Correção para o teste de resiliência de rede

Este script corrige a importação ausente de aiohttp no arquivo de teste de resiliência de rede.
"""

import os
import sys
import shutil

def corrigir_teste_resiliencia(arquivo_teste):
    """
    Corrige o arquivo de teste de resiliência de rede adicionando a importação ausente.
    
    Args:
        arquivo_teste: Caminho para o arquivo test_network_resilience_integration.py
    
    Returns:
        bool: True se a correção foi aplicada com sucesso, False caso contrário
    """
    try:
        # Ler o conteúdo do arquivo
        with open(arquivo_teste, 'r') as f:
            conteudo = f.read()
        
        # Verificar se a importação já existe
        if 'import aiohttp' not in conteudo:
            # Adicionar a importação após as importações existentes
            linhas = conteudo.split('\n')
            
            # Encontrar a última linha de importação
            ultima_importacao = 0
            for i, linha in enumerate(linhas):
                if linha.startswith('import ') or linha.startswith('from '):
                    ultima_importacao = i
            
            # Inserir a importação de aiohttp após a última importação
            linhas.insert(ultima_importacao + 1, 'import aiohttp')
            
            # Reconstruir o conteúdo
            conteudo_corrigido = '\n'.join(linhas)
            
            # Salvar o arquivo corrigido
            with open(arquivo_teste, 'w') as f:
                f.write(conteudo_corrigido)
            
            print(f"Correção aplicada com sucesso ao arquivo {arquivo_teste}")
            return True
        else:
            print(f"O arquivo {arquivo_teste} já contém a importação de aiohttp")
            return True
        
    except Exception as e:
        print(f"Erro ao corrigir o arquivo: {str(e)}")
        return False

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python correcao_teste_resiliencia.py <caminho_para_test_network_resilience_integration.py>")
        sys.exit(1)
    
    arquivo_teste = sys.argv[1]
    if not os.path.exists(arquivo_teste):
        print(f"Arquivo {arquivo_teste} não encontrado")
        sys.exit(1)
    
    # Fazer backup do arquivo original
    arquivo_backup = f"{arquivo_teste}.bak"
    try:
        shutil.copy2(arquivo_teste, arquivo_backup)
        print(f"Backup do arquivo original salvo em {arquivo_backup}")
    except Exception as e:
        print(f"Erro ao criar backup: {str(e)}")
        sys.exit(1)
    
    # Aplicar correção
    if corrigir_teste_resiliencia(arquivo_teste):
        print("\nA correção adicionou a importação ausente de 'aiohttp' ao arquivo de teste.")
        print("\nAgora você pode executar o teste de resiliência de rede diretamente:")
        print(f"python {arquivo_teste}")
        sys.exit(0)
    else:
        print("Falha ao aplicar correção")
        sys.exit(1)
