"""Pytest fixtures for managing the E2E test process."""

import pytest
import subprocess
import os
import time
import signal

@pytest.fixture(scope="function")
def run_kripto_process(request):
    """Fixture to start and manage the main.py script as a subprocess."""
    process = None
    log_file_path = "/home/ubuntu/audit_kripto/KR_KRIPTO_ADVANCED_REORGANIZED/logs/e2e_test.log"
    
    # Clean up old log file if it exists
    if os.path.exists(log_file_path):
        os.remove(log_file_path)

    def _starter(config_path, data_path=None, mode="standalone", timeout=30, env_vars=None):
        nonlocal process
        cmd = [
            "python3.11", 
            "main.py", 
            f"--config={config_path}",
            f"--logfile={log_file_path}" # Ensure logs go to a specific file for E2E
        ]
        if mode == "simulate" and data_path:
            cmd.append(f"--simulate={data_path}")
        else:
            cmd.append(f"--mode={mode}") # Default to standalone if not simulate

        print(f"\nStarting process with command: {' '.join(cmd)}")
        # Prepare environment variables for the subprocess
        process_env = os.environ.copy()
        # Force DEBUG logging for E2E tests
        process_env["LOG_LEVEL"] = "DEBUG"
        if env_vars:
            process_env.update(env_vars)

        # Use Popen for non-blocking execution, passing the environment
        process = subprocess.Popen(cmd, cwd="/home/ubuntu/audit_kripto/KR_KRIPTO_ADVANCED_REORGANIZED",
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                                   env=process_env) # Pass the combined environment
        
        # Allow some time for the process to start and potentially fail early
        time.sleep(5)
        
        # Check if process terminated unexpectedly early
        poll_result = process.poll()
        if poll_result is not None:
            stdout, stderr = process.communicate()
            pytest.fail(f"Process terminated unexpectedly with code {poll_result}.\nStdout:\n{stdout}\nStderr:\n{stderr}")
            
        return process # Return the process object for potential interaction

    yield _starter

    # Teardown: Ensure the process is terminated after the test
    if process and process.poll() is None:
        print(f"\nTerminating process {process.pid}...")
        # Send SIGTERM first for graceful shutdown
        process.send_signal(signal.SIGTERM)
        try:
            process.wait(timeout=10) # Wait for graceful shutdown
        except subprocess.TimeoutExpired:
            print(f"Process {process.pid} did not terminate gracefully, sending SIGKILL.")
            process.kill() # Force kill if it doesn't respond
            process.wait()
        print(f"Process {process.pid} terminated.")
        
        # Optional: Print logs after termination for debugging
        # if os.path.exists(log_file_path):
        #     with open(log_file_path, 'r') as f:
        #         print(f"\n--- E2E Log ({log_file_path}) ---")
        #         print(f.read())
        #         print("--- End E2E Log ---")


