#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de correção de importações para resolver o problema de 'modo degradado'
no ambiente Mac M1 para os módulos fallback_v2 e memoria_temporal_v2.

Este script cria links simbólicos e ajusta importações para garantir que
o sistema encontre corretamente os módulos necessários.
"""

import os
import sys
import logging
import platform
import importlib
import shutil
from pathlib import Path

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("kr_kripto_import_fix_mac_m1")

def is_mac_m1():
    """Verifica se o ambiente atual é um Mac M1 (ARM64)."""
    return platform.system() == "Darwin" and ("arm" in platform.machine().lower())

def criar_links_simbolicos():
    """
    Cria links simbólicos para garantir que os módulos v2 sejam encontrados
    corretamente pelo sistema.
    """
    # Obter diretório raiz do projeto
    try:
        # Tentar encontrar o diretório src
        src_dir = None
        for path in sys.path:
            if os.path.isdir(os.path.join(path, 'src')):
                src_dir = os.path.join(path, 'src')
                break
        
        if not src_dir:
            # Tentar encontrar no diretório atual
            current_dir = os.path.abspath(os.path.dirname(__file__))
            if os.path.isdir(os.path.join(current_dir, 'src')):
                src_dir = os.path.join(current_dir, 'src')
            elif os.path.isdir(os.path.join(current_dir, '..', 'src')):
                src_dir = os.path.join(current_dir, '..', 'src')
        
        if not src_dir:
            logger.error("Não foi possível encontrar o diretório 'src'")
            return False
        
        # Verificar e criar links para fallback_v2
        core_dir = os.path.join(src_dir, 'core')
        if not os.path.isdir(core_dir):
            os.makedirs(core_dir, exist_ok=True)
            logger.info(f"Diretório criado: {core_dir}")
        
        # Verificar se os arquivos existem
        fallback_path = os.path.join(core_dir, 'fallback.py')
        fallback_v2_path = os.path.join(core_dir, 'fallback_v2.py')
        memoria_path = os.path.join(core_dir, 'memoria_temporal.py')
        memoria_v2_path = os.path.join(core_dir, 'memoria_temporal_v2.py')
        
        # Criar links se necessário para fallback
        if os.path.exists(fallback_path) and not os.path.exists(fallback_v2_path):
            # Copiar o arquivo em vez de criar link simbólico (mais compatível)
            shutil.copy2(fallback_path, fallback_v2_path)
            logger.info(f"Arquivo copiado: {fallback_path} -> {fallback_v2_path}")
        elif os.path.exists(fallback_v2_path) and not os.path.exists(fallback_path):
            shutil.copy2(fallback_v2_path, fallback_path)
            logger.info(f"Arquivo copiado: {fallback_v2_path} -> {fallback_path}")
        
        # Criar links se necessário para memoria_temporal
        if os.path.exists(memoria_path) and not os.path.exists(memoria_v2_path):
            shutil.copy2(memoria_path, memoria_v2_path)
            logger.info(f"Arquivo copiado: {memoria_path} -> {memoria_v2_path}")
        elif os.path.exists(memoria_v2_path) and not os.path.exists(memoria_path):
            shutil.copy2(memoria_v2_path, memoria_path)
            logger.info(f"Arquivo copiado: {memoria_v2_path} -> {memoria_path}")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao criar links simbólicos: {e}")
        return False

def corrigir_importacoes():
    """
    Corrige as importações para garantir que os módulos sejam encontrados
    corretamente pelo sistema.
    """
    try:
        # Adicionar diretórios ao path
        current_dir = os.path.abspath(os.path.dirname(__file__))
        
        # Tentar encontrar o diretório raiz do projeto
        root_dir = current_dir
        while root_dir and not os.path.isdir(os.path.join(root_dir, 'src')):
            parent = os.path.dirname(root_dir)
            if parent == root_dir:  # Chegou à raiz do sistema
                root_dir = None
                break
            root_dir = parent
        
        if not root_dir:
            # Tentar encontrar no diretório atual
            if os.path.isdir(os.path.join(current_dir, 'src')):
                root_dir = current_dir
        
        if not root_dir:
            logger.error("Não foi possível encontrar o diretório raiz do projeto")
            return False
        
        # Adicionar diretórios ao path
        if root_dir not in sys.path:
            sys.path.insert(0, root_dir)
            logger.info(f"Adicionado ao path: {root_dir}")
        
        # Verificar se os módulos podem ser importados
        try:
            # Tentar importar fallback_v2
            importlib.import_module('src.core.fallback')
            logger.info("Módulo src.core.fallback importado com sucesso")
        except ImportError as e:
            logger.error(f"Módulo crítico src.core.fallback não disponível: {e}")
            
            # Tentar importar fallback como alternativa
            try:
                importlib.import_module('src.core.fallback')
                logger.info("Módulo src.core.fallback importado como alternativa")
            except ImportError as e2:
                logger.error(f"Módulo alternativo src.core.fallback não disponível: {e2}")
        
        try:
            # Tentar importar memoria_temporal
            importlib.import_module('src.core.memoria_temporal')
            logger.info("Módulo src.core.memoria_temporal importado com sucesso")
        except ImportError as e:
            logger.error(f"Módulo crítico src.core.memoria_temporal não disponível: {e}")
            
            # Tentar importar memoria_temporal como alternativa
            try:
                importlib.import_module('src.core.memoria_temporal')
                logger.info("Módulo src.core.memoria_temporal importado como alternativa")
            except ImportError as e2:
                logger.error(f"Módulo alternativo src.core.memoria_temporal não disponível: {e2}")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao corrigir importações: {e}")
        return False

def main():
    """Função principal."""
    logger.info(f"Iniciando correção de importações para Mac M1")
    logger.info(f"Ambiente: {'Mac M1' if is_mac_m1() else 'Outro'}")
    
    # Criar links simbólicos
    if criar_links_simbolicos():
        logger.info("Links simbólicos criados com sucesso")
    else:
        logger.warning("Falha ao criar links simbólicos")
    
    # Corrigir importações
    if corrigir_importacoes():
        logger.info("Importações corrigidas com sucesso")
    else:
        logger.warning("Falha ao corrigir importações")
    
    logger.info("Correção de importações concluída")

if __name__ == "__main__":
    main()
