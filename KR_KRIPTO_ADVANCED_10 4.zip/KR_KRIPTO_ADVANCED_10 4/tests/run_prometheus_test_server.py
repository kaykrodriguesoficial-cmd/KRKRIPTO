# Helper script para executar o servidor Prometheus em um subprocesso isolado
import time
import sys
import os

# Adicionar o diretório RAIZ DO PROJETO ao sys.path para que 'src' seja um pacote de nível superior
PROJECT_ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..")) # /home/ubuntu/kripto_analysis/KR_KRIPTO_ADVANCED_REORGANIZED
sys.path.insert(0, PROJECT_ROOT_DIR)

# Agora podemos importar de src.infrastructure
from src.infrastructure import prometheus_exporter as pe_module

TEST_PORT = 8001 # Deve ser o mesmo que no teste principal

def run_server_and_update_metrics():
    # Atualizar métricas
    pe_module.inc_signals_processed("BTCUSDT", "dummy_regime", "dummy_decision")
    pe_module.inc_signals_processed("BTCUSDT", "dummy_regime", "dummy_decision")
    pe_module.inc_signals_processed("ETHUSDT", "dummy_regime", "dummy_decision")
    pe_module.inc_errors("signal_processor")
    pe_module.inc_errors("binance_stream_connection")
    pe_module.set_active_connection("BTCUSDT", True)
    pe_module.set_active_connection("ETHUSDT", False)
    pe_module.update_last_signal_timestamp("BTCUSDT")

    # Iniciar o servidor de métricas
    pe_module.start_metrics_server(port=TEST_PORT, addr="localhost")

    try:
        while True:
            time.sleep(1) # Manter o processo vivo
    except KeyboardInterrupt:
        print("Helper script encerrado.")

if __name__ == "__main__":
    print(f"Helper: Adicionado ao sys.path: {PROJECT_ROOT_DIR}")
    print(f"Helper: Iniciando servidor de métricas na porta {TEST_PORT} e atualizando métricas...")
    run_server_and_update_metrics()

