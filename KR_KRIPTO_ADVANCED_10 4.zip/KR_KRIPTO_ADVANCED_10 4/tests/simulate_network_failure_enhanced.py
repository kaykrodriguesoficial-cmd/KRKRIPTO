#!/usr/bin/env python3
"""
Script aprimorado para simular falhas de rede durante a conexão com a Binance.
Este script executa o BinanceStreamManager aprimorado diretamente (sem depender do main.py)
e simula uma desconexão modificando temporariamente o arquivo os.path.join(tempfile.gettempdir(), "hosts").

Uso:
    python3 simulate_network_failure_enhanced.py
"""

import subprocess
import time
import os
import signal
import sys
import threading
import tempfile
import shutil
import asyncio
import logging
from logging.handlers import TimedRotatingFileHandler
import json
from pathlib import Path

# Configurações
PROJECT_DIR = os.path.join(tempfile.gettempdir(), "KR_KRIPTO_ADVANCED_COPIA")
ENHANCED_STREAM_PATH = f"{PROJECT_DIR}/src/core/binance_stream_enhanced.py"
LOG_FILE = f"{PROJECT_DIR}/logs/teste_resiliencia_rede_{int(time.time())}.log"
HOSTS_FILE = os.path.join(tempfile.gettempdir(), "hosts")
WAIT_BEFORE_DISCONNECT = 15  # segundos para aguardar antes de simular a desconexão
DISCONNECT_DURATION = 20     # segundos para manter a desconexão
WAIT_AFTER_RECONNECT = 30    # segundos para aguardar após reconexão antes de encerrar

# Domínios da Binance para bloquear
BINANCE_DOMAINS = [
    "binance.com",
    "testnet.binance.vision",
    "data-stream.binance.vision",
    "stream.testnet.binance.vision",
    "api.binance.com",
    "api-testnet.binance.vision"
]

# Configurar logging com rotação
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        TimedRotatingFileHandler(
            filename=LOG_FILE,
            when='midnight',
            interval=1,
            backupCount=30,
            encoding='utf-8'
        ),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("teste_resiliencia_rede")

def backup_hosts_file():
    """Cria um backup do arquivo os.path.join(tempfile.gettempdir(), "hosts")."""
    backup_path = os.path.join(tempfile.gettempdir(), "hosts.backup")
    try:
        shutil.copy(HOSTS_FILE, backup_path)
        logger.info(f"Backup do arquivo hosts criado em {backup_path}")
        return backup_path
    except Exception as e:
        logger.error(f"Erro ao criar backup do arquivo hosts: {e}")
        sys.exit(1)

def restore_hosts_file(backup_path):
    """Restaura o arquivo os.path.join(tempfile.gettempdir(), "hosts") a partir do backup."""
    try:
        shutil.copy(backup_path, HOSTS_FILE)
        logger.info(f"Arquivo hosts restaurado a partir do backup")
    except Exception as e:
        logger.error(f"Erro ao restaurar arquivo hosts: {e}")
        logger.warning(f"ATENÇÃO: Restaure manualmente o arquivo hosts a partir de {backup_path}")

def simulate_network_failure():
    """
    Simula uma falha de rede modificando o arquivo os.path.join(tempfile.gettempdir(), "hosts") para
    redirecionar os domínios da Binance para 127.0.0.1.
    """
    logger.info(f"Simulando falha de rede por {DISCONNECT_DURATION} segundos...")
    
    # Backup do arquivo hosts original
    backup_path = backup_hosts_file()
    
    try:
        # Lê o conteúdo atual do arquivo hosts
        with open(HOSTS_FILE, 'r') as f:
            hosts_content = f.read()
        
        # Adiciona entradas para bloquear os domínios da Binance
        block_entries = "\n# Entradas temporárias para simular falha de rede (teste)\n"
        for domain in BINANCE_DOMAINS:
            block_entries += f"127.0.0.1 {domain}\n"
        
        # Escreve o novo conteúdo no arquivo hosts
        with open(HOSTS_FILE, 'w') as f:
            f.write(hosts_content + block_entries)
        
        logger.info(f"Domínios da Binance redirecionados para 127.0.0.1")
        
        # Tenta limpar o cache DNS para aplicar as alterações imediatamente
        try:
            subprocess.run(["sudo", "systemd-resolve", "--flush-caches"], check=False)
        except:
            logger.warning("Não foi possível limpar o cache DNS com systemd-resolve")
            
            # Tenta alternativas para limpar o cache DNS
            try:
                subprocess.run(["sudo", "service", "nscd", "restart"], check=False)
            except:
                logger.warning("Não foi possível reiniciar o serviço nscd")
                
            try:
                subprocess.run(["sudo", "killall", "-HUP", "mDNSResponder"], check=False)
            except:
                logger.warning("Não foi possível reiniciar o mDNSResponder")
        
        # Aguarda o tempo de desconexão
        logger.info(f"Mantendo falha de rede por {DISCONNECT_DURATION} segundos...")
        time.sleep(DISCONNECT_DURATION)
        
        # Restaura o arquivo hosts original
        restore_hosts_file(backup_path)
        
        # Tenta limpar o cache DNS novamente
        try:
            subprocess.run(["sudo", "systemd-resolve", "--flush-caches"], check=False)
        except:
            logger.warning("Não foi possível limpar o cache DNS após restauração")
        
        logger.info(f"Conexão de rede restaurada")
    
    except Exception as e:
        logger.error(f"Erro durante a simulação de falha de rede: {e}")
        # Garante que o arquivo hosts seja restaurado mesmo em caso de erro
        restore_hosts_file(backup_path)

# Script para testar diretamente o BinanceStreamManager aprimorado - SEM DOCSTRINGS
TEST_SCRIPT = '''
import sys
import os
import asyncio
import logging
from logging.handlers import TimedRotatingFileHandler
import json
import time
from pathlib import Path

# Adicionar o diretório do projeto ao PYTHONPATH
project_dir = Path("{project_dir}")
sys.path.append(str(project_dir))

# Configurar logging com rotação
log_file = project_dir / "logs" / "teste_binance_stream.log"
os.makedirs(os.path.dirname(log_file), exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        TimedRotatingFileHandler(
            filename=str(log_file),
            when='midnight',
            interval=1,
            backupCount=30,
            encoding='utf-8'
        ),
        logging.StreamHandler()
    ]
)

# Importar a versão aprimorada do BinanceStreamManager
from src.core.binance_stream_enhanced import BinanceStreamManager

# Classes Mock para componentes necessários
class MemoriaTemporalMock:
    def __init__(self):
        self.data = {{}}
    
    async def registrar_evento(self, *args, **kwargs):
        logging.debug("Mock: MemoriaTemporal.registrar_evento chamado")
        return True
    
    async def consultar_eventos(self, *args, **kwargs):
        logging.debug("Mock: MemoriaTemporal.consultar_eventos chamado")
        return []

class GerenciadorFallbackMock:
    def __init__(self):
        self.fallback_active = False
    
    def is_fallback_active(self, *args, **kwargs):
        logging.debug("Mock: GerenciadorFallback.is_fallback_active chamado")
        return self.fallback_active
    
    def activate_fallback(self, *args, **kwargs):
        logging.debug("Mock: GerenciadorFallback.activate_fallback chamado")
        self.fallback_active = True
        return True

class GovernorMock:
    def __init__(self):
        pass
    
    async def evaluate_signal(self, *args, **kwargs):
        logging.debug("Mock: Governor.evaluate_signal chamado")
        return True, 1.0

class TrackerMock:
    def __init__(self):
        pass
    
    def track_model_performance(self, *args, **kwargs):
        logging.debug("Mock: Tracker.track_model_performance chamado")
        return True

class ContextSwitcherMock:
    def __init__(self):
        pass
    
    def should_switch_context(self, *args, **kwargs):
        logging.debug("Mock: ContextSwitcher.should_switch_context chamado")
        return False
    
    def get_current_context(self, *args, **kwargs):
        logging.debug("Mock: ContextSwitcher.get_current_context chamado")
        return "default"

class AttackDetectorMock:
    def __init__(self):
        pass
    
    def detect_spoofing(self, *args, **kwargs):
        logging.debug("Mock: AttackDetector.detect_spoofing chamado")
        return False

class BookProcessorMock:
    def __init__(self):
        self.state = None
    
    async def process_book_update(self, *args, **kwargs):
        logging.debug("Mock: BookProcessor.process_book_update chamado")
        return True

# Função mock para analisar_sinal
async def mock_analisar_sinal(**kwargs):
    logging.debug("Mock: analisar_sinal chamado com argumentos: " + str(kwargs.keys()))
    return {{"status": "success", "signal": None}}

# Carrega a configuração do arquivo config.json
async def carregar_configuracao():
    try:
        config_path = project_dir / "config.json"
        with open(config_path, 'r') as f:
            config = json.load(f)
        logging.info(f"Configuração carregada com sucesso: {{config_path}}")
        return config
    except Exception as e:
        logging.error(f"Erro ao carregar configuração: {{e}}")
        return None

# Cria um contexto robusto com mocks para todos os componentes necessários
async def criar_contexto_robusto(config):
    # Criar instâncias de mocks
    memoria_temporal = MemoriaTemporalMock()
    gerenciador_fallback = GerenciadorFallbackMock()
    governor = GovernorMock()
    tracker = TrackerMock()
    context_switcher = ContextSwitcherMock()
    attack_detector = AttackDetectorMock()
    
    # Criar processadores de book para cada asset
    assets = config.get("assets", ["BTCUSDT"])
    processadores_book = {{asset: BookProcessorMock() for asset in assets}}
    
    return {{
        "configuracao_global": config,
        "dataframes": {{}},
        "last_kline_time": {{}},
        "dataframes_lock": asyncio.Lock(),
        "processadores_book": processadores_book,
        "memoria_temporal": memoria_temporal,
        "gerenciador_fallback": gerenciador_fallback,
        "analisar_sinal_func": mock_analisar_sinal,
        "governor": governor,
        "tracker": tracker,
        "context_switcher": context_switcher,
        "strategy_config": config.get("strategy_config", {{}}),
        "attack_detector": attack_detector,
        "agentes_rl": {{}},
        "ambientes_rl": {{}},
        "operador": None,
        "news_provider": None
    }}

# Monitora e registra o status da conexão periodicamente
async def monitorar_status_conexao(stream_manager, duracao_teste):
    inicio = time.time()
    intervalo = 5  # segundos entre verificações
    
    while (time.time() - inicio) < duracao_teste:
        status = stream_manager.get_connection_status()
        logging.info(f"Status atual das conexões: {{json.dumps(status, indent=2)}}")
        
        # Verificar se há conexões ativas
        conexoes_ativas = sum(1 for s in status.values() if s["connected"])
        logging.info(f"Conexões ativas: {{conexoes_ativas}}/{{len(status)}}")
        
        # Calcular tempo restante
        tempo_decorrido = time.time() - inicio
        tempo_restante = duracao_teste - tempo_decorrido
        logging.info(f"Tempo decorrido: {{tempo_decorrido:.1f}}s, Tempo restante: {{tempo_restante:.1f}}s")
        
        await asyncio.sleep(intervalo)

# Função principal do teste
async def main():
    logging.info("Iniciando teste de resiliência a falhas de rede com BinanceStreamManager aprimorado")
    
    # Definir duração do teste (em segundos)
    duracao_teste = {total_duration}  # Duração total do teste
    
    # Carregar configuração
    config = await carregar_configuracao()
    if not config:
        logging.error("Não foi possível carregar a configuração. Encerrando teste.")
        return
    
    # Verificar configuração de testnet
    is_testnet = config.get("testnet", False)
    logging.info(f"Modo Testnet: {{is_testnet}}")
    
    # Verificar assets configurados
    assets = config.get("assets", ["BTCUSDT"])
    logging.info(f"Assets configurados: {{assets}}")
    
    # Criar contexto robusto com mocks
    contexto = await criar_contexto_robusto(config)
    logging.info("Contexto robusto criado para o teste com mocks para todos os componentes necessários")
    
    try:
        # Inicializar BinanceStreamManager aprimorado
        stream_manager = BinanceStreamManager(config={})
        logging.info("BinanceStreamManager aprimorado inicializado")
        
        # Iniciar streams para os assets
        logging.info(f"Iniciando streams para assets: {{assets}}")
        tasks = await stream_manager.start_streams_for_assets(assets)
        
        # Iniciar monitoramento de status
        monitor_task = asyncio.create_task(monitorar_status_conexao(stream_manager, duracao_teste))
        
        # Aguardar pelo tempo definido
        logging.info(f"Teste em execução por {{duracao_teste}} segundos...")
        await asyncio.sleep(duracao_teste)
        
        # Encerrar monitoramento
        monitor_task.cancel()
        try:
            await monitor_task
        except asyncio.CancelledError:
            pass
        
        # Obter status final
        status_final = stream_manager.get_connection_status()
        logging.info(f"Status final das conexões: {{json.dumps(status_final, indent=2)}}")
        
        # Parar streams
        logging.info("Encerrando streams...")
        await stream_manager.stop_streams()
        
        # Verificar resultados
        conexoes_bem_sucedidas = all(s["connected"] for s in status_final.values())
        mensagens_recebidas = all(s["messages_received"] > 0 for s in status_final.values())
        
        if conexoes_bem_sucedidas and mensagens_recebidas:
            logging.info("TESTE CONCLUÍDO COM SUCESSO: Conexão estabelecida e mensagens recebidas para todos os assets.")
        else:
            logging.warning("TESTE CONCLUÍDO COM RESSALVAS: Nem todas as conexões foram bem-sucedidas ou receberam mensagens.")
        
        # Resumo do teste
        logging.info("Resumo do teste:")
        for asset, status in status_final.items():
            logging.info(f"Asset: {{asset}}")
            logging.info(f"  - Conectado: {{status['connected']}}")
            logging.info(f"  - Mensagens recebidas: {{status['messages_received']}}")
            logging.info(f"  - Status de autenticação: {{status['authentication_status']}}")
            logging.info(f"  - Tempo de conexão: {{status['connection_time']:.1f}}s")
            if status['last_message_time'] is not None:
                logging.info(f"  - Tempo desde última mensagem: {{status['last_message_time']:.1f}}s")
            logging.info(f"  - Tentativas de reconexão: {{status['reconnect_attempts']}}")
        
    except Exception as e:
        logging.error(f"Erro durante o teste: {{e}}", exc_info=True)
    finally:
        logging.info("Teste de resiliência a falhas de rede concluído")

if __name__ == "__main__":
    asyncio.run(main())
'''.format(project_dir=PROJECT_DIR, total_duration=WAIT_BEFORE_DISCONNECT + DISCONNECT_DURATION + WAIT_AFTER_RECONNECT)

def create_test_script():
    """Cria o script de teste temporário."""
    script_path = os.path.join(tempfile.gettempdir(), "test_binance_resilience.py")
    with open(script_path, 'w') as f:
        f.write(TEST_SCRIPT)
    logger.info(f"Script de teste criado em {script_path}")
    return script_path

def run_test_script(script_path):
    """Executa o script de teste em um processo separado."""
    logger.info(f"Executando script de teste...")
    
    # Executa o script de teste em um processo separado
    process = subprocess.Popen(
        ["python3.11", script_path],
        cwd=PROJECT_DIR,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        universal_newlines=True
    )
    
    # Captura a saída em tempo real
    for line in process.stdout:
        logger.info(f"[TESTE] {line.strip()}")
    
    return process

def main():
    logger.info("Iniciando teste aprimorado de resiliência a falhas de rede")
    
    # Criar script de teste
    script_path = create_test_script()
    
    # Executar script de teste
    process = run_test_script(script_path)
    
    # Aguardar antes de simular a desconexão
    logger.info(f"Aguardando {WAIT_BEFORE_DISCONNECT} segundos antes de simular falha de rede...")
    time.sleep(WAIT_BEFORE_DISCONNECT)
    
    # Simular a falha de rede
    simulate_network_failure()
    
    # Aguardar após reconexão
    logger.info(f"Aguardando {WAIT_AFTER_RECONNECT} segundos após reconexão...")
    time.sleep(WAIT_AFTER_RECONNECT)
    
    # Verificar se o processo ainda está em execução
    if process.poll() is None:
        logger.info("Processo de teste ainda em execução, aguardando finalização...")
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            logger.warning("Processo de teste não finalizou no tempo esperado, forçando encerramento...")
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                logger.error("Não foi possível encerrar o processo de teste, forçando kill...")
                process.kill()
    
    # Capturar saída de erro
    stderr = process.stderr.read()
    if stderr:
        logger.error(f"Erros durante a execução do teste:\n{stderr}")
    
    # Verificar código de saída
    exit_code = process.returncode
    if exit_code == 0:
        logger.info("Teste concluído com sucesso (código de saída 0)")
    else:
        logger.warning(f"Teste concluído com código de saída não-zero: {exit_code}")
    
    logger.info(f"Teste de resiliência a falhas de rede finalizado. Logs salvos em: {LOG_FILE}")
    logger.info("Para analisar os resultados, verifique o arquivo de log.")

if __name__ == "__main__":
    main()
