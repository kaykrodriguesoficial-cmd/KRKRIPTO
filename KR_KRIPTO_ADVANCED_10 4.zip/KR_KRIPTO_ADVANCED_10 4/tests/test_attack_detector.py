# src/tests/intelligence/test_attack_detector.py

import pytest
import pandas as pd
import time
from collections import deque

# Adjust the import path based on the project structure
from src.intelligence.attack_detector import AttackDetector

# Default config for testing (aligned with config.json keys)
DEFAULT_CONFIG = {
    "volume_spike_window": 5, # Shorter period for easier testing
    "volume_spike_threshold_std": 3.0,
    "spoofing_threshold_ratio": 5.0,
    "spoofing_depth_levels": 3,
    "spoofing_history_size": 10,
    "spoofing_cancel_rate_threshold": 0.7,
    "spoofing_cancel_time_ms": 500
}

@pytest.fixture
def detector():
    """Provides an instance of AttackDetector with default config."""
    return AttackDetector(config={})

# --- Tests for detect_artificial_volume ---

def create_kline_data(volumes, closes, highs=None, lows=None):
    """Helper function to create DataFrame for kline tests."""
    count = len(volumes)
    if highs is None:
        highs = [c + 0.5 for c in closes]
    if lows is None:
        lows = [c - 0.5 for c in closes]
    opens = [c - 0.1 for c in closes] # Simple open values
    # Corrected timestamp generation
    timestamps = pd.to_datetime(range(count), unit='m', origin='2023-01-01') 
    return pd.DataFrame({
        'open': opens,
        'high': highs,
        'low': lows,
        'close': closes,
        'volume': volumes
    }, index=timestamps)

def test_detect_artificial_volume_normal(detector):
    """Test with normal volume fluctuations."""
    volumes = [100, 110, 90, 105, 95, 100] # Last volume is normal
    closes = [10, 10.1, 10, 10.2, 10.1, 10.2]
    df = create_kline_data(volumes, closes)
    assert not detector.detect_artificial_volume(df)

def test_detect_artificial_volume_spike(detector):
    """Test with a significant volume spike."""
    volumes = [100, 110, 90, 105, 95, 500] # Last volume is > 3x average of previous 5
    closes = [10, 10.1, 10, 10.2, 10.1, 10.3] # Price moves a bit
    df = create_kline_data(volumes, closes)
    assert detector.detect_artificial_volume(df)

def test_detect_artificial_volume_insufficient_data(detector):
    """Test with insufficient data."""
    volumes = [100, 110, 90] # Less than period + 1
    closes = [10, 10.1, 10]
    df = create_kline_data(volumes, closes)
    assert not detector.detect_artificial_volume(df)

def test_detect_artificial_volume_zero_avg(detector):
    """Test case where average volume might be zero (edge case)."""
    volumes = [0, 0, 0, 0, 0, 500] # Avg is 0, spike occurs
    closes = [10, 10, 10, 10, 10, 10.1]
    df = create_kline_data(volumes, closes)
    # The current logic handles avg_volume > 0 implicitly in the check
    # If avg_volume is 0, volume_spike will be True if last_kline["volume"] > 0
    assert detector.detect_artificial_volume(df)

# --- Tests for detect_spoofing (Simplified) ---

def create_book_update(bids, asks, timestamp_ms):
    """Helper function to create a book update dictionary."""
    # Corrected dictionary creation
    return {
        'e': 'depthUpdate',
        'E': timestamp_ms,
        's': 'BTCUSDT', # Example symbol
        'U': 1000, # Example first update ID
        'u': 1001, # Example final update ID
        'b': bids,
        'a': asks
    }

def test_detect_spoofing_normal_book(detector):
    """Test with a normal book update after some history."""
    # 1. Initial small updates to build history
    ts0 = int(time.time() * 1000)
    update0_bids = [["10.0", "2"], ["9.9", "3"]]
    update0_asks = [["10.1", "2"], ["10.2", "4"]]
    update0 = create_book_update(update0_bids, update0_asks, ts0)
    detector.detect_spoofing(update0) # Process to build history

    ts1 = ts0 + 50
    update1_bids = [["10.0", "3"], ["9.8", "5"]]
    update1_asks = [["10.1", "3"], ["10.3", "6"]]
    update1 = create_book_update(update1_bids, update1_asks, ts1)
    detector.detect_spoofing(update1) # Process more history

    # 2. The actual 'normal' update to test
    bids = [["10.0", "5"], ["9.9", "8"], ["9.8", "12"]]
    asks = [["10.1", "6"], ["10.2", "7"], ["10.3", "10"]]
    timestamp = ts1 + 50
    update = create_book_update(bids, asks, timestamp)
    # Now, with history, these normal orders should not trigger spoofing
    assert not detector.detect_spoofing(update)

def test_detect_spoofing_large_bid_appears(detector):
    """Test when a large bid order appears."""
    # Avg bid size = (5+8+12)/3 = 8.33. Threshold = 8.33 * 5 = 41.65
    bids = [["10.0", "50"], ["9.9", "8"], ["9.8", "12"]]
    asks = [["10.1", "6"], ["10.2", "7"], ["10.3", "10"]]
    timestamp = int(time.time() * 1000)
    update = create_book_update(bids, asks, timestamp)
    assert detector.detect_spoofing(update)
    # Check if it was added to recent large orders
    assert len(detector.recent_large_orders["bids"]) == 1
    assert detector.recent_large_orders["bids"][0] == (10.0, 50.0, timestamp)

def test_detect_spoofing_large_ask_appears(detector):
    """Test when a large ask order appears."""
    bids = [["10.0", "5"], ["9.9", "8"], ["9.8", "12"]]
    # Avg ask size (other) = (5+6)/2 = 5.5. Threshold = 5.5 * 5 = 27.5
    asks = [["10.1", "40"], ["10.2", "5"], ["10.3", "6"]]
    timestamp = int(time.time() * 1000)
    update = create_book_update(bids, asks, timestamp)
    assert detector.detect_spoofing(update)
    assert len(detector.recent_large_orders["asks"]) == 1
    assert detector.recent_large_orders["asks"][0] == (10.1, 40.0, timestamp)

def test_detect_spoofing_large_order_persists(detector):
    """Test that a persistent large order is not detected repeatedly."""
    bids = [["10.0", "50"], ["9.9", "8"], ["9.8", "12"]]
    asks = [["10.1", "6"], ["10.2", "7"], ["10.3", "10"]]
    timestamp1 = int(time.time() * 1000)
    update1 = create_book_update(bids, asks, timestamp1)
    assert detector.detect_spoofing(update1) # First detection
    assert len(detector.recent_large_orders["bids"]) == 1

    # Second update, same large order
    timestamp2 = timestamp1 + 100
    update2 = create_book_update(bids, asks, timestamp2)
    assert not detector.detect_spoofing(update2) # Should not detect again
    assert len(detector.recent_large_orders["bids"]) == 1 # Still one order tracked

def test_detect_spoofing_order_disappears_within_window(detector):
    """Test that the tracked order is kept if it disappears within the window (simplified check)."""
    bids1 = [["10.0", "50"], ["9.9", "8"], ["9.8", "12"]]
    asks1 = [["10.1", "6"], ["10.2", "7"], ["10.3", "10"]]
    timestamp1 = int(time.time() * 1000)
    update1 = create_book_update(bids1, asks1, timestamp1)
    assert detector.detect_spoofing(update1)
    assert len(detector.recent_large_orders["bids"]) == 1

    # Order disappears quickly
    bids2 = [["9.9", "8"], ["9.8", "12"]]
    asks2 = [["10.1", "6"], ["10.2", "7"], ["10.3", "10"]]
    timestamp2 = timestamp1 + 100 # Within 500ms window
    update2 = create_book_update(bids2, asks2, timestamp2)
    assert not detector.detect_spoofing(update2) # No new large order
    # The check for removal happens *after* processing the update in the current logic
    # So the order should be removed after this call because spoofing was confirmed.
    assert len(detector.recent_large_orders["bids"]) == 0 

def test_detect_spoofing_order_disappears_outside_window(detector):
    """Test that the tracked order is removed if time exceeds the window."""
    bids1 = [["10.0", "50"], ["9.9", "8"], ["9.8", "12"]]
    asks1 = [["10.1", "6"], ["10.2", "7"], ["10.3", "10"]]
    timestamp1 = int(time.time() * 1000)
    update1 = create_book_update(bids1, asks1, timestamp1)
    assert detector.detect_spoofing(update1)
    assert len(detector.recent_large_orders["bids"]) == 1

    # Process another update much later
    bids2 = [["10.0", "5"], ["9.9", "8"], ["9.8", "12"]]
    asks2 = [["10.1", "6"], ["10.2", "7"], ["10.3", "10"]]
    timestamp2 = timestamp1 + 600 # Outside 500ms window
    update2 = create_book_update(bids2, asks2, timestamp2)
    assert not detector.detect_spoofing(update2) # No new large order
    # The check for removal happens in detect_spoofing. After this call, the old order should be gone.
    assert len(detector.recent_large_orders["bids"]) == 0


