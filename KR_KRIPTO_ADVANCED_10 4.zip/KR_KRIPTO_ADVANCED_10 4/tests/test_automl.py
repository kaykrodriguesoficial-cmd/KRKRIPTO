"""
Testes Unitários para AutoML - Testes para o módulo AutoML com AdaptiveEnsemble
==============================================================================

Este módulo implementa testes unitários para o módulo AutoML com AdaptiveEnsemble.

Autor: Manus AI
Data: Maio 2025
Versão: 1.0.0
"""

import os
import sys
import unittest
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

# Adicionar diretório raiz ao path para importações relativas
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Importar módulos a serem testados
from src.intelligence.automl.adaptive_ensemble import AdaptiveEnsemble
from src.intelligence.automl.automl_prototype import AutoMLPrototype

class MockModel:
    """Modelo mock para testes."""
    
    def __init__(self, name="mock_model", prediction_value=0.5, error_rate=0.0):
        self.name = name
        self.prediction_value = prediction_value
        self.error_rate = error_rate
        self.fit_called = False
        self.predict_called = False
        self.evaluate_called = False
        self.save_called = False
        self.load_called = False
    
    def fit(self, X, y):
        self.fit_called = True
        return self
    
    def predict(self, X):
        self.predict_called = True
        if np.random.random() < self.error_rate:
            raise Exception("Erro simulado na predição")
        
        if isinstance(X, np.ndarray):
            return np.ones(X.shape[0]) * self.prediction_value
        else:
            return self.prediction_value
    
    def evaluate(self, X, y):
        self.evaluate_called = True
        return 0.8  # Retorna um score fixo para testes
    
    def save(self, path):
        self.save_called = True
        return True
    
    @classmethod
    def load(cls, path):
        model = cls()
        model.load_called = True
        return model


class TestAdaptiveEnsemble(unittest.TestCase):
    """Testes para a classe AdaptiveEnsemble."""
    
    def setUp(self):
        """Configuração inicial para os testes."""
        # Criar modelos mock
        self.models = {
            "model1": MockModel(name="model1", prediction_value=0.7),
            "model2": MockModel(name="model2", prediction_value=0.3)
        }
        
        # Criar ensemble
        self.ensemble = AdaptiveEnsemble(
            models=self.models,
            window_size=10,
            adaptation_rate=0.1,
            min_weight=0.1,
            default_weight=0.5
        )
    
    def test_init(self):
        """Testa a inicialização do ensemble."""
        self.assertEqual(len(self.ensemble.models), 2)
        self.assertEqual(self.ensemble.window_size, 10)
        self.assertEqual(self.ensemble.adaptation_rate, 0.1)
        self.assertEqual(self.ensemble.min_weight, 0.1)
        
        # Verificar pesos iniciais
        self.assertEqual(len(self.ensemble.weights), 2)
        self.assertEqual(self.ensemble.weights["model1"], 0.5)
        self.assertEqual(self.ensemble.weights["model2"], 0.5)
    
    def test_predict(self):
        """Testa a predição do ensemble."""
        # Criar dados de teste
        X = np.random.random((5, 10))
        
        # Fazer predição
        predictions = self.ensemble.predict(X)
        
        # Verificar resultado
        self.assertEqual(predictions.shape, (5,))
        
        # Verificar se os modelos foram chamados
        self.assertTrue(self.models["model1"].predict_called)
        self.assertTrue(self.models["model2"].predict_called)
        
        # Verificar valor da predição (média ponderada)
        expected = 0.7 * 0.5 + 0.3 * 0.5  # model1 * weight1 + model2 * weight2
        np.testing.assert_allclose(predictions, expected)
    
    def test_update_performance(self):
        """Testa a atualização de performance dos modelos."""
        # Atualizar performance
        self.ensemble.update_performance("model1", 0.9)
        self.ensemble.update_performance("model2", 0.1)
        
        # Verificar se os pesos foram atualizados
        self.assertGreater(self.ensemble.weights["model1"], 0.5)
        self.assertLess(self.ensemble.weights["model2"], 0.5)
    
    def test_save_load(self):
        """Testa o salvamento e carregamento do ensemble."""
        # Criar diretório temporário para testes
        import tempfile
        temp_dir = tempfile.mkdtemp()
        
        # Salvar ensemble
        path = os.path.join(temp_dir, "ensemble.pkl")
        self.ensemble.save(path)
        
        # Carregar ensemble
        loaded_ensemble = AdaptiveEnsemble.load(path)
        
        # Verificar se o carregamento foi bem-sucedido
        self.assertEqual(len(loaded_ensemble.models), 2)
        self.assertEqual(loaded_ensemble.window_size, 10)
        self.assertEqual(loaded_ensemble.adaptation_rate, 0.1)
        self.assertEqual(loaded_ensemble.min_weight, 0.1)
        
        # Limpar
        import shutil
        shutil.rmtree(temp_dir)
    
    def test_error_handling(self):
        """Testa o tratamento de erros do ensemble."""
        # Criar modelos com erro
        models_with_error = {
            "model1": MockModel(name="model1", prediction_value=0.7),
            "model2": MockModel(name="model2", prediction_value=0.3, error_rate=1.0)  # Sempre falha
        }
        
        # Criar ensemble
        ensemble_with_error = AdaptiveEnsemble(
            models=models_with_error,
            window_size=10,
            adaptation_rate=0.1,
            min_weight=0.1,
            default_weight=0.5
        )
        
        # Criar dados de teste
        X = np.random.random((5, 10))
        
        # Fazer predição (deve usar apenas model1)
        predictions = ensemble_with_error.predict(X)
        
        # Verificar resultado
        self.assertEqual(predictions.shape, (5,))
        
        # Verificar se os modelos foram chamados
        self.assertTrue(models_with_error["model1"].predict_called)
        self.assertTrue(models_with_error["model2"].predict_called)
        
        # Verificar valor da predição (apenas model1)
        np.testing.assert_allclose(predictions, 0.7)


class TestAutoMLPrototype(unittest.TestCase):
    """Testes para a classe AutoMLPrototype."""
    
    def setUp(self):
        """Configuração inicial para os testes."""
        # Criar diretório temporário para testes
        import tempfile
        self.temp_dir = tempfile.mkdtemp()
        
        # Criar configuração
        self.config = {
            "n_trials": 5,
            "window_size": 10,
            "adaptation_rate": 0.1,
            "min_weight": 0.1,
            "default_weight": 0.5
        }
        
        # Criar protótipo
        self.automl = AutoMLPrototype(self.config)
        
        # Substituir diretórios
        self.automl.models_dir = os.path.join(self.temp_dir, "modelos")
        self.automl.data_dir = os.path.join(self.temp_dir, "dados")
        os.makedirs(self.automl.models_dir, exist_ok=True)
        os.makedirs(self.automl.data_dir, exist_ok=True)
        
        # Criar dados de teste
        self.create_test_data()
    
    def tearDown(self):
        """Limpeza após os testes."""
        import shutil
        shutil.rmtree(self.temp_dir)
    
    def create_test_data(self):
        """Cria dados de teste para os testes."""
        # Criar dataframe de teste
        dates = pd.date_range(start="2023-01-01", periods=100, freq="H")
        self.df = pd.DataFrame({
            "open": np.random.random(100) * 100,
            "high": np.random.random(100) * 100 + 10,
            "low": np.random.random(100) * 100 - 10,
            "close": np.random.random(100) * 100,
            "volume": np.random.random(100) * 1000,
            "rsi": np.random.random(100) * 100,
            "macd": np.random.random(100) * 10 - 5,
            "macd_signal": np.random.random(100) * 10 - 5,
            "macd_hist": np.random.random(100) * 10 - 5,
            "ema_9": np.random.random(100) * 100,
            "sma_20": np.random.random(100) * 100
        }, index=dates)
        
        # Criar dicionário de dataframes
        self.dataframes = {
            "BTCUSDT_1h": self.df
        }
    
    def test_setup_integration(self):
        """Testa a configuração da integração."""
        # Configurar integração
        result = self.automl.setup_integration(self.dataframes, None)
        
        # Verificar resultado
        self.assertTrue(result)
        self.assertIsNotNone(self.automl.integration)
    
    def test_create_ensemble(self):
        """Testa a criação de um ensemble."""
        # Configurar integração
        self.automl.setup_integration(self.dataframes, None)
        
        # Criar modelos mock
        self.automl.models[("BTCUSDT", "1h", "transformer")] = {
            "model": MockModel(name="transformer", prediction_value=0.7),
            "params": {"n_layers": 2},
            "score": 0.8
        }
        
        self.automl.models[("BTCUSDT", "1h", "lstm")] = {
            "model": MockModel(name="lstm", prediction_value=0.3),
            "params": {"n_layers": 1},
            "score": 0.7
        }
        
        # Criar ensemble
        result = self.automl.create_ensemble("BTCUSDT", "1h")
        
        # Verificar resultado
        self.assertTrue(result)
        self.assertIn(("BTCUSDT", "1h"), self.automl.ensembles)
        
        # Verificar se o ensemble foi salvo
        ensemble_path = os.path.join(self.automl.models_dir, "automl_BTCUSDT_1h_ensemble.pkl")
        self.assertTrue(os.path.exists(ensemble_path))
    
    def test_predict(self):
        """Testa a predição com o protótipo."""
        # Configurar integração
        self.automl.setup_integration(self.dataframes, None)
        
        # Criar modelos mock
        self.automl.models[("BTCUSDT", "1h", "transformer")] = {
            "model": MockModel(name="transformer", prediction_value=0.7),
            "params": {"n_layers": 2},
            "score": 0.8
        }
        
        # Fazer predição
        predictions = self.automl.predict(self.df.iloc[-1:], "BTCUSDT", "1h", use_ensemble=False)
        
        # Verificar resultado
        self.assertEqual(predictions, 0.7)
    
    def test_update_ensemble_performance(self):
        """Testa a atualização de performance do ensemble."""
        # Configurar integração
        self.automl.setup_integration(self.dataframes, None)
        
        # Criar modelos mock
        self.automl.models[("BTCUSDT", "1h", "transformer")] = {
            "model": MockModel(name="transformer", prediction_value=0.7),
            "params": {"n_layers": 2},
            "score": 0.8
        }
        
        self.automl.models[("BTCUSDT", "1h", "lstm")] = {
            "model": MockModel(name="lstm", prediction_value=0.3),
            "params": {"n_layers": 1},
            "score": 0.7
        }
        
        # Criar ensemble
        self.automl.create_ensemble("BTCUSDT", "1h")
        
        # Atualizar performance
        result = self.automl.update_ensemble_performance("BTCUSDT", "1h", "transformer", 0.9)
        
        # Verificar resultado
        self.assertTrue(result)
        
        # Verificar se os pesos foram atualizados
        ensemble = self.automl.ensembles[("BTCUSDT", "1h")]
        self.assertGreater(ensemble.weights["transformer"], 0.5)
        self.assertLess(ensemble.weights["lstm"], 0.5)


if __name__ == "__main__":
    unittest.main()
