"""
Testes unitários para o módulo binance_stream.py (anteriormente binance_stream_resilient.py)
"""

import asyncio
import pytest
import json
import time
import os
import sys
from unittest.mock import MagicMock, patch, AsyncMock
import aiohttp
from aiohttp.test_utils import make_mocked_coro

# Adicionar diretório raiz ao path para importações relativas
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.core.binance_stream import (
    conectar_binance_resiliente,
    processar_mensagem,
    verificar_heartbeat,
    ConnectionStats,
    NetworkFailureType
)

# Fixtures para testes
@pytest.fixture
def mock_context():
    """Cria um contexto mock para testes."""
    return {
        "websocket_connections": {},
        "reconnect_tasks": {},
        "heartbeat_tasks": {},
        "dataframes": {},
        "last_kline_time": {},
        "dataframes_lock": AsyncMock(),
        "processadores_book": {},
        "memoria_temporal": {},
        "configuracao_global": {
            "testnet": True,
            "websocket": {
                "max_reconnect_attempts": 3,
                "base_delay": 0.1,
                "max_delay": 1.0,
                "jitter": 0.1,
                "timeout": 1.0
            }
        },
        "gerenciador_fallback": MagicMock(),
        "analisar_sinal_func": AsyncMock(),
        "governor": MagicMock(),
        "tracker": MagicMock(),
        "context_switcher": MagicMock(),
        "strategy_config": MagicMock(),
        "attack_detector": MagicMock(detect_spoofing=MagicMock(return_value=False))
    }

@pytest.fixture
def mock_zmq_socket():
    """Cria um socket ZMQ mock para testes."""
    socket = AsyncMock()
    socket.send_string = AsyncMock()
    return socket

@pytest.fixture
def mock_ws_message():
    """Cria uma mensagem WebSocket mock para testes."""
    message = MagicMock()
    message.type = aiohttp.WSMsgType.TEXT
    message.data = json.dumps({
        "stream": "btcusdt@kline_1m",
        "data": {
            "e": "kline",
            "k": {
                "t": int(time.time() * 1000),
                "o": "20000",
                "h": "20100",
                "l": "19900",
                "c": "20050",
                "v": "100",
                "x": True
            }
        }
    })
    return message

@pytest.fixture
def mock_ws_depth_message():
    """Cria uma mensagem de profundidade WebSocket mock para testes."""
    message = MagicMock()
    message.type = aiohttp.WSMsgType.TEXT
    message.data = json.dumps({
        "stream": "btcusdt@depth@100ms",
        "data": {
            "e": "depthUpdate",
            "E": int(time.time() * 1000),
            "s": "BTCUSDT",
            "b": [["20000", "1.0"], ["19900", "2.0"]],
            "a": [["20100", "1.0"], ["20200", "2.0"]]
        }
    })
    return message

# Testes para ConnectionStats
class TestConnectionStats:
    def test_init(self):
        """Testa a inicialização da classe ConnectionStats."""
        stats = ConnectionStats("BTCUSDT")
        assert stats.ativo == "BTCUSDT"
        assert stats.mensagens_recebidas["kline"] == 0
        assert stats.ultima_mensagem_timestamp == 0
        assert stats.conexao_estabelecida_timestamp == 0
        assert stats.reconexoes == 0
        assert stats.falhas_consecutivas == 0
        assert stats.max_falhas_consecutivas == 0
        assert stats.tempo_total_conectado == 0
        assert stats.ultima_desconexao_timestamp == 0
        assert stats.circuit_breaker_ativo == False
        assert stats.circuit_breaker_expiracao == 0
        assert stats.falhas_por_tipo == {}

    def test_registrar_conexao(self):
        """Testa o registro de conexão."""
        stats = ConnectionStats("BTCUSDT")
        stats.falhas_consecutivas = 3
        stats.registrar_conexao()
        assert stats.conexao_estabelecida_timestamp > 0
        assert stats.falhas_consecutivas == 0

    def test_registrar_desconexao(self):
        """Testa o registro de desconexão."""
        stats = ConnectionStats("BTCUSDT")
        stats.conexao_estabelecida_timestamp = time.time() - 10
        stats.registrar_desconexao()
        assert stats.ultima_desconexao_timestamp > 0
        assert stats.tempo_total_conectado >= 10

    def test_registrar_mensagem(self):
        """Testa o registro de mensagem."""
        stats = ConnectionStats("BTCUSDT")
        stats.registrar_mensagem("kline")
        assert stats.mensagens_recebidas["kline"] == 1
        assert stats.ultima_mensagem_timestamp > 0

    def test_registrar_falha(self):
        """Testa o registro de falha."""
        stats = ConnectionStats("BTCUSDT")
        stats.registrar_falha("connection_refused")
        assert stats.falhas_consecutivas == 1
        assert stats.max_falhas_consecutivas == 1
        assert stats.falhas_por_tipo["connection_refused"] == 1

    def test_circuit_breaker(self):
        """Testa a ativação e verificação do circuit breaker."""
        stats = ConnectionStats("BTCUSDT")
        stats.ativar_circuit_breaker(1)
        assert stats.circuit_breaker_ativo == True
        assert stats.circuit_breaker_expiracao > time.time()
        assert stats.verificar_circuit_breaker() == True
        time.sleep(1.1)
        assert stats.verificar_circuit_breaker() == False
        assert stats.circuit_breaker_ativo == False

    def test_tempo_desde_ultima_mensagem(self):
        """Testa o cálculo do tempo desde a última mensagem."""
        stats = ConnectionStats("BTCUSDT")
        assert stats.tempo_desde_ultima_mensagem() == float('inf')
        stats.ultima_mensagem_timestamp = time.time() - 5
        assert stats.tempo_desde_ultima_mensagem() >= 5

    def test_obter_estatisticas(self):
        """Testa a obtenção de estatísticas."""
        stats = ConnectionStats("BTCUSDT")
        stats.registrar_mensagem("kline")
        stats.registrar_conexao()
        stats.registrar_falha("connection_refused")
        estatisticas = stats.obter_estatisticas()
        assert estatisticas["ativo"] == "BTCUSDT"
        assert estatisticas["mensagens_por_tipo"]["kline"] == 1
        assert estatisticas["falhas_consecutivas_atuais"] == 1
        assert estatisticas["falhas_por_tipo"]["connection_refused"] == 1

# Testes para processar_mensagem
@pytest.mark.asyncio
async def test_processar_mensagem_kline(mock_context, mock_zmq_socket):
    """Testa o processamento de mensagem kline."""
    ativo = "BTCUSDT"
    msg = {
        "e": "kline",
        "k": {
            "t": int(time.time() * 1000),
            "o": "20000",
            "h": "20100",
            "l": "19900",
            "c": "20050",
            "v": "100",
            "x": True
        }
    }
    
    # Patch para carregar_dados_historicos_async_local
    with patch('src.core.binance_stream.carregar_dados_historicos_async_local', 
               new_callable=AsyncMock) as mock_carregar:
        import pandas as pd
        mock_df = pd.DataFrame({
            'Open': [20000], 'High': [20100], 'Low': [19900], 'Close': [20050], 'Volume': [100]
        }, index=pd.to_datetime([int(time.time() * 1000)], unit='ms'))
        mock_carregar.return_value = mock_df
        
        await processar_mensagem(ativo, msg, mock_context, "master", mock_zmq_socket)
        
        # Verificar se o DataFrame foi atualizado
        assert ativo in mock_context["dataframes"]
        assert mock_context["analisar_sinal_func"].called

@pytest.mark.asyncio
async def test_processar_mensagem_depth(mock_context, mock_zmq_socket):
    """Testa o processamento de mensagem de profundidade."""
    ativo = "BTCUSDT"
    msg = {
        "e": "depthUpdate",
        "E": int(time.time() * 1000),
        "s": "BTCUSDT",
        "b": [["20000", "1.0"], ["19900", "2.0"]],
        "a": [["20100", "1.0"], ["20200", "2.0"]]
    }
    
    # Adicionar processador de book mock
    mock_context["processadores_book"][ativo] = AsyncMock()
    
    await processar_mensagem(ativo, msg, mock_context, "worker", mock_zmq_socket)
    
    # Verificar se o processador de book foi chamado
    assert mock_context["processadores_book"][ativo].process_book_update.called
    # Verificar se o socket ZMQ foi chamado no modo worker
    assert mock_zmq_socket.send_string.called

@pytest.mark.asyncio
async def test_processar_mensagem_missing_context(mock_context, mock_zmq_socket):
    """Testa o processamento de mensagem com contexto incompleto."""
    ativo = "BTCUSDT"
    msg = {
        "e": "kline",
        "k": {
            "t": int(time.time() * 1000),
            "o": "20000",
            "h": "20100",
            "l": "19900",
            "c": "20050",
            "v": "100",
            "x": True
        }
    }
    
    # Remover chave necessária do contexto
    del mock_context["analisar_sinal_func"]
    
    await processar_mensagem(ativo, msg, mock_context, "master", mock_zmq_socket)
    
    # Verificar que não houve erro, mas o processamento foi interrompido
    assert ativo not in mock_context.get("dataframes", {})

# Testes para verificar_heartbeat
@pytest.mark.asyncio
async def test_verificar_heartbeat(mock_context):
    """Testa a verificação de heartbeat."""
    ativo = "BTCUSDT"
    
    # Configurar mock para asyncio.sleep para não esperar realmente
    with patch('asyncio.sleep', new_callable=AsyncMock) as mock_sleep:
        # Configurar para retornar após primeira chamada
        mock_sleep.side_effect = [None, asyncio.CancelledError()]
        
        # Adicionar conexão mock
        mock_context["websocket_connections"][ativo] = AsyncMock()
        mock_context["websocket_connections"][ativo].close = AsyncMock()
        
        try:
            await verificar_heartbeat(ativo, mock_context["websocket_connections"], mock_context["reconnect_tasks"])
        except asyncio.CancelledError:
            pass
        
        # Verificar que sleep foi chamado
        assert mock_sleep.called

# Testes para conectar_binance_resiliente
@pytest.mark.asyncio
async def test_conectar_binance_resiliente_e2e_load(mock_context, mock_zmq_socket):
    """Testa a conexão com modo E2E LOAD."""
    ativo = "BTCUSDT"
    
    # Configurar ambiente para simulação E2E
    os.environ["E2E_MOCK_WS_MODE"] = "LOAD"
    
    # Patch para asyncio.sleep para não esperar realmente
    with patch('asyncio.sleep', new_callable=AsyncMock) as mock_sleep:
        # Configurar para retornar None indefinidamente, exceto na 6ª chamada que lança CancelledError
        def sleep_side_effect(*args, **kwargs):
            mock_sleep.call_count = getattr(mock_sleep, 'call_count', 0) + 1
            if mock_sleep.call_count >= 6:
                raise asyncio.CancelledError()
            return None
            
        mock_sleep.side_effect = sleep_side_effect
        
        try:
            await conectar_binance_resiliente(ativo, mock_context, "master", mock_zmq_socket)
        except asyncio.CancelledError:
            pass
        
        # Verificar que sleep foi chamado
        assert mock_sleep.called
    
    # Limpar ambiente
    os.environ.pop("E2E_MOCK_WS_MODE", None)

@pytest.mark.asyncio
async def test_conectar_binance_resiliente_e2e_failure(mock_context, mock_zmq_socket):
    """Testa a conexão com modo E2E FAILURE."""
    ativo = "BTCUSDT"
    
    # Configurar ambiente para simulação E2E
    os.environ["E2E_MOCK_WS_MODE"] = "FAILURE"
    
    # Patch para asyncio.sleep para não esperar realmente
    with patch('asyncio.sleep', new_callable=AsyncMock) as mock_sleep:
        # Configurar para retornar None indefinidamente, exceto na 6ª chamada que lança CancelledError
        def sleep_side_effect(*args, **kwargs):
            mock_sleep.call_count = getattr(mock_sleep, 'call_count', 0) + 1
            if mock_sleep.call_count >= 6:
                raise asyncio.CancelledError()
            return None
            
        mock_sleep.side_effect = sleep_side_effect
        
        # Patch para NetworkResilience.execute_with_retry
        with patch('src.core.network_resilience.NetworkResilience.execute_with_retry', 
                  new_callable=AsyncMock) as mock_retry:
            mock_retry.side_effect = asyncio.CancelledError()
            
            try:
                await conectar_binance_resiliente(ativo, mock_context, "master", mock_zmq_socket)
            except asyncio.CancelledError:
                pass
            
            # Verificar que retry foi chamado
            assert mock_retry.called
    
    # Limpar ambiente
    os.environ.pop("E2E_MOCK_WS_MODE", None)

@pytest.mark.asyncio
async def test_conectar_binance_resiliente_real(mock_context, mock_zmq_socket, mock_ws_message, mock_ws_depth_message):
    """Testa a conexão real com WebSocket."""
    ativo = "BTCUSDT"
    
    # Patch para aiohttp.ClientSession
    with patch('aiohttp.ClientSession') as mock_session:
        # Configurar session mock
        session_instance = AsyncMock()
        mock_session.return_value.__aenter__.return_value = session_instance
        
        # Configurar ws_connect mock
        ws_instance = AsyncMock()
        session_instance.ws_connect.return_value.__aenter__.return_value = ws_instance
        
        # Configurar ws para retornar mensagens e depois fechar
        ws_instance.__aiter__.return_value = [mock_ws_message, mock_ws_depth_message]
        
        # Patch para NetworkResilience.execute_with_retry para chamar diretamente a função
        with patch('src.core.network_resilience.NetworkResilience.execute_with_retry', 
                  new_callable=AsyncMock) as mock_retry:
            # Fazer com que execute_with_retry chame a função diretamente
            async def execute_side_effect(operation, operation_name, context):
                return await operation()
            mock_retry.side_effect = execute_side_effect
            
            # Patch para asyncio.sleep para não esperar realmente
            with patch('asyncio.sleep', new_callable=AsyncMock) as mock_sleep:
                # Configurar para retornar após algumas chamadas
                mock_sleep.side_effect = [None, asyncio.CancelledError()]
                
                try:
                    await conectar_binance_resiliente(ativo, mock_context, "master", mock_zmq_socket)
                except asyncio.CancelledError:
                    pass
                
                # Verificar que session.ws_connect foi chamado com a URL correta
                assert session_instance.ws_connect.called
                # Verificar que a URL contém testnet (conforme configuração)
                call_args = session_instance.ws_connect.call_args[0][0]
                assert "testnet" in call_args

if __name__ == "__main__":
    pytest.main(["-xvs", __file__])
