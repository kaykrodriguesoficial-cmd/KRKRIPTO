# Tests for src/strategies/validators/book_imbalance.py

import pytest
from unittest.mock import MagicMock

# Adjust import path based on the project structure
from src.strategies.validators.book_imbalance import validar_book_institucional

# Mock BookState for testing
@pytest.fixture
def mock_book_state():
    """Provides a mock BookState object."""
    state = MagicMock()
    # Set default attributes that might be accessed
    state.imbalance = 0.0
    state.liquidez_total_bids = 1000000.0
    state.liquidez_total_asks = 1000000.0
    state.preco_medio_ponderado_bids = 50000.0
    state.preco_medio_ponderado_asks = 50001.0
    state.maior_bid_qty = 10.0
    state.maior_ask_qty = 10.0
    state.profundidade_media_bids = 5.0
    state.profundidade_media_asks = 5.0
    state.spread = 1.0
    state.volume_negociado_recente = 50.0
    state.agressoes_recentes = {"compras": 25.0, "vendas": 25.0}
    return state

def test_validar_book_institucional_compra_sem_imbalance(mock_book_state):
    """Test validation for BUY signal with no significant imbalance."""
    mock_book_state.imbalance = 0.0 # Neutral imbalance
    # --- CORRECTION: Pass tipo_sinal --- 
    is_valid = validar_book_institucional(mock_book_state, tipo_sinal="compra")
    # --- END CORRECTION ---
    # Expect validation to pass if no strong counter-signal from imbalance
    assert is_valid is True

def test_validar_book_institucional_venda_sem_imbalance(mock_book_state):
    """Test validation for SELL signal with no significant imbalance."""
    mock_book_state.imbalance = 0.0 # Neutral imbalance
    # --- CORRECTION: Pass tipo_sinal --- 
    is_valid = validar_book_institucional(mock_book_state, tipo_sinal="venda")
    # --- END CORRECTION ---
    # Expect validation to pass
    assert is_valid is True

def test_validar_book_institucional_compra_com_imbalance_compra(mock_book_state):
    """Test validation for BUY signal with positive (buy-side) imbalance."""
    mock_book_state.imbalance = 0.7 # Strong buy-side imbalance
    # --- CORRECTION: Pass tipo_sinal --- 
    is_valid = validar_book_institucional(mock_book_state, tipo_sinal="compra")
    # --- END CORRECTION ---
    # Expect validation to pass (imbalance confirms signal)
    assert is_valid is True

def test_validar_book_institucional_venda_com_imbalance_venda(mock_book_state):
    """Test validation for SELL signal with negative (sell-side) imbalance."""
    mock_book_state.imbalance = -0.7 # Strong sell-side imbalance
    # --- CORRECTION: Pass tipo_sinal --- 
    is_valid = validar_book_institucional(mock_book_state, tipo_sinal="venda")
    # --- END CORRECTION ---
    # Expect validation to pass (imbalance confirms signal)
    assert is_valid is True

def test_validar_book_institucional_compra_com_imbalance_venda(mock_book_state):
    """Test validation for BUY signal with negative (sell-side) imbalance."""
    mock_book_state.imbalance = -0.7 # Strong sell-side imbalance (contradicts BUY)
    # --- CORRECTION: Pass tipo_sinal --- 
    is_valid = validar_book_institucional(mock_book_state, tipo_sinal="compra")
    # --- END CORRECTION ---
    # Expect validation to FAIL (imbalance contradicts signal)
    assert is_valid is False

def test_validar_book_institucional_venda_com_imbalance_compra(mock_book_state):
    """Test validation for SELL signal with positive (buy-side) imbalance."""
    mock_book_state.imbalance = 0.7 # Strong buy-side imbalance (contradicts SELL)
    # --- CORRECTION: Pass tipo_sinal --- 
    is_valid = validar_book_institucional(mock_book_state, tipo_sinal="venda")
    # --- END CORRECTION ---
    # Expect validation to FAIL (imbalance contradicts signal)
    assert is_valid is False

def test_validar_book_institucional_sinal_neutro(mock_book_state):
    """Test validation when the signal is neutral ("nada")."""
    mock_book_state.imbalance = 0.7 # Imbalance doesn't matter for neutral signal
    # --- CORRECTION: Pass tipo_sinal --- 
    is_valid = validar_book_institucional(mock_book_state, tipo_sinal="nada")
    # --- END CORRECTION ---
    # Expect validation to always pass for neutral signals
    assert is_valid is True

# Note: The function currently only checks the 'imbalance' attribute.
# More tests could be added if the function evolves to use other BookState attributes.

