#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Testes unitários para o BookProcessor v2.
"""

import unittest
import sys
import os
import logging
import asyncio
from datetime import datetime
import tempfile
import json

# Configurar logging para testes
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("test_book_processor")

# Adicionar diretório pai ao path para importação
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Importar o módulo a ser testado
try:
    from src.realtime.book_processor_v2 import BookProcessor, BookState
except ImportError:
    logger.error("Não foi possível importar BookProcessor. Verificando caminhos...")
    logger.info(f"Diretório atual: {os.getcwd()}")
    logger.info(f"sys.path: {sys.path}")
    raise

class TestBookState(unittest.TestCase):
    """Testes para a classe BookState."""
    
    def setUp(self):
        """Configuração inicial para cada teste."""
        self.book_state = BookState()
        
        # Adicionar alguns dados de exemplo
        self.book_state.bids = [(100.5, 1.5), (100.2, 2.0), (100.0, 3.0)]
        self.book_state.asks = [(101.0, 1.0), (101.2, 2.5), (101.5, 1.8)]
        self.book_state.last_update_id = 12345
    
    def test_get_best_bid(self):
        """Testa a obtenção do melhor bid."""
        best_bid = self.book_state.get_best_bid()
        self.assertEqual(best_bid, (100.5, 1.5))
        
        # Testar com book vazio
        empty_state = BookState()
        self.assertIsNone(empty_state.get_best_bid())
    
    def test_get_best_ask(self):
        """Testa a obtenção do melhor ask."""
        best_ask = self.book_state.get_best_ask()
        self.assertEqual(best_ask, (101.0, 1.0))
        
        # Testar com book vazio
        empty_state = BookState()
        self.assertIsNone(empty_state.get_best_ask())
    
    def test_get_spread(self):
        """Testa o cálculo do spread."""
        spread = self.book_state.get_spread()
        self.assertEqual(spread, 101.0 - 100.5)
        
        # Testar com book vazio
        empty_state = BookState()
        self.assertEqual(empty_state.get_spread(), 0.0)
    
    def test_get_mid_price(self):
        """Testa o cálculo do preço médio."""
        mid_price = self.book_state.get_mid_price()
        self.assertEqual(mid_price, (101.0 + 100.5) / 2)
        
        # Testar com book vazio
        empty_state = BookState()
        self.assertEqual(empty_state.get_mid_price(), 0.0)
    
    def test_get_book_imbalance(self):
        """Testa o cálculo do desequilíbrio do livro."""
        # Caso padrão
        imbalance = self.book_state.get_book_imbalance()
        
        # Calcular manualmente para comparação
        bid_volume = sum(qty for _, qty in self.book_state.bids[:10])
        ask_volume = sum(qty for _, qty in self.book_state.asks[:10])
        expected_imbalance = (bid_volume - ask_volume) / (bid_volume + ask_volume)
        
        self.assertAlmostEqual(imbalance, expected_imbalance)
        
        # Testar com níveis específicos
        imbalance_2 = self.book_state.get_book_imbalance(levels=2)
        
        # Calcular manualmente para comparação
        bid_volume_2 = sum(qty for _, qty in self.book_state.bids[:2])
        ask_volume_2 = sum(qty for _, qty in self.book_state.asks[:2])
        expected_imbalance_2 = (bid_volume_2 - ask_volume_2) / (bid_volume_2 + ask_volume_2)
        
        self.assertAlmostEqual(imbalance_2, expected_imbalance_2)
        
        # Testar com book vazio
        empty_state = BookState()
        self.assertEqual(empty_state.get_book_imbalance(), 0.0)
    
    def test_to_dict(self):
        """Testa a conversão para dicionário."""
        state_dict = self.book_state.to_dict()
        
        self.assertIn("bids", state_dict)
        self.assertIn("asks", state_dict)
        self.assertIn("last_update_id", state_dict)
        self.assertIn("timestamp", state_dict)
        self.assertIn("spread", state_dict)
        self.assertIn("mid_price", state_dict)
        self.assertIn("imbalance", state_dict)
        
        self.assertEqual(state_dict["last_update_id"], 12345)
        self.assertEqual(state_dict["spread"], 101.0 - 100.5)
        self.assertEqual(state_dict["mid_price"], (101.0 + 100.5) / 2)


class TestBookProcessor(unittest.TestCase):
    """Testes para a classe BookProcessor."""
    
    def setUp(self):
        """Configuração inicial para cada teste."""
        self.config = {
            "ativo": "BTCUSDT",
            "max_levels": 10,
            "max_history": 5,
            "storage_path": tempfile.mkdtemp()  # Usar diretório temporário para testes
        }
        self.processor = BookProcessor(self.config)
    
    def test_initialization(self):
        """Testa a inicialização do processador."""
        self.assertEqual(self.processor.ativo, "BTCUSDT")
        self.assertEqual(self.processor.max_levels, 10)
        self.assertEqual(self.processor.max_history, 5)
        self.assertEqual(self.processor.update_count, 0)
        self.assertIsInstance(self.processor.book_state, BookState)
    
    def test_process_book_update(self):
        """Testa o processamento de atualizações do livro."""
        # Criar uma atualização de exemplo
        update = {
            "u": 12345,  # update ID
            "b": [  # bids (preço, quantidade)
                ["100.50", "1.5"],
                ["100.20", "2.0"],
                ["100.00", "3.0"]
            ],
            "a": [  # asks (preço, quantidade)
                ["101.00", "1.0"],
                ["101.20", "2.5"],
                ["101.50", "1.8"]
            ]
        }
        
        # Processar a atualização
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(self.processor.process_book_update(update))
        
        # Verificar se o estado foi atualizado corretamente
        self.assertEqual(self.processor.book_state.last_update_id, 12345)
        self.assertEqual(len(self.processor.book_state.bids), 3)
        self.assertEqual(len(self.processor.book_state.asks), 3)
        
        # Verificar se os preços foram convertidos para float
        self.assertEqual(self.processor.book_state.bids[0][0], 100.50)
        self.assertEqual(self.processor.book_state.asks[0][0], 101.00)
        
        # Processar uma atualização com ID menor (deve ser ignorada)
        old_update = {
            "u": 12344,
            "b": [["99.00", "1.0"]],
            "a": [["102.00", "1.0"]]
        }
        loop.run_until_complete(self.processor.process_book_update(old_update))
        
        # Verificar que o estado não mudou
        self.assertEqual(self.processor.book_state.last_update_id, 12345)
        self.assertEqual(self.processor.book_state.bids[0][0], 100.50)
        
        # Processar várias atualizações para testar o histórico
        for i in range(20):
            update = {
                "u": 12346 + i,
                "b": [[f"{100.0 + i*0.1}", "1.0"]],
                "a": [[f"{101.0 + i*0.1}", "1.0"]]
            }
            loop.run_until_complete(self.processor.process_book_update(update))
        
        # Verificar se o histórico foi limitado ao tamanho máximo
        self.assertLessEqual(len(self.processor.history), self.processor.max_history)
        
        loop.close()
    
    def test_get_imbalance(self):
        """Testa o cálculo do desequilíbrio."""
        # Configurar um estado de livro de exemplo
        self.processor.book_state.bids = [(100.5, 1.5), (100.2, 2.0), (100.0, 3.0)]
        self.processor.book_state.asks = [(101.0, 1.0), (101.2, 2.5), (101.5, 1.8)]
        
        # Calcular desequilíbrio
        imbalance = self.processor.get_imbalance()
        
        # Calcular manualmente para comparação
        bid_volume = sum(qty for _, qty in self.processor.book_state.bids[:10])
        ask_volume = sum(qty for _, qty in self.processor.book_state.asks[:10])
        expected_imbalance = (bid_volume - ask_volume) / (bid_volume + ask_volume)
        
        self.assertAlmostEqual(imbalance, expected_imbalance)
        
        # Testar com níveis específicos
        imbalance_2 = self.processor.get_imbalance(levels=2)
        
        # Calcular manualmente para comparação
        bid_volume_2 = sum(qty for _, qty in self.processor.book_state.bids[:2])
        ask_volume_2 = sum(qty for _, qty in self.processor.book_state.asks[:2])
        expected_imbalance_2 = (bid_volume_2 - ask_volume_2) / (bid_volume_2 + ask_volume_2)
        
        self.assertAlmostEqual(imbalance_2, expected_imbalance_2)
    
    def test_save_state(self):
        """Testa o salvamento do estado."""
        # Configurar um estado de livro de exemplo
        self.processor.book_state.bids = [(100.5, 1.5), (100.2, 2.0)]
        self.processor.book_state.asks = [(101.0, 1.0), (101.2, 2.5)]
        self.processor.book_state.last_update_id = 12345
        
        # Salvar estado
        filepath = os.path.join(self.config["storage_path"], "test_book_state.json")
        result = self.processor.save_state(filepath)
        
        # Verificar resultado
        self.assertTrue(result)
        self.assertTrue(os.path.exists(filepath))
        
        # Verificar conteúdo do arquivo
        with open(filepath, 'r') as f:
            state = json.load(f)
        
        self.assertEqual(state["ativo"], "BTCUSDT")
        self.assertEqual(state["state"]["last_update_id"], 12345)
        self.assertEqual(len(state["state"]["bids"]), 2)
        self.assertEqual(len(state["state"]["asks"]), 2)
    
    def test_start_streams(self):
        """Testa o início dos streams."""
        # Configurar dados de exemplo
        ativos_config = [
            {"par": "BTCUSDT", "intervalo": "1m"},
            {"par": "ETHUSDT", "intervalo": "1m"}
        ]
        tipos_stream_config = ["kline", "depth"]
        
        # Iniciar streams
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(self.processor.start_streams(ativos_config, tipos_stream_config))
        
        # Verificar resultado
        self.assertTrue(result)
        
        # Testar com configuração sem o ativo do processador
        ativos_config = [
            {"par": "ETHUSDT", "intervalo": "1m"},
            {"par": "SOLUSDT", "intervalo": "1m"}
        ]
        
        result = loop.run_until_complete(self.processor.start_streams(ativos_config, tipos_stream_config))
        
        # Deve retornar True mesmo sem encontrar o ativo
        self.assertTrue(result)
        
        loop.close()


if __name__ == "__main__":
    unittest.main()
