#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Testes unitários para validar as correções implementadas no KR_KRIPTO_ADVANCED.

Este script executa testes para validar:
1. Método obter_klines em OperadorBinance
2. Gerenciador de resiliência com timeout e circuit breaker
3. Mecanismo de rollback com argumento componente
4. Redirecionamentos de módulos e imports
5. Resolução de duplicação de métricas no Prometheus

Versão: 1.0
Data: 2025-05-30
"""

import os
import sys
import time
import unittest
import logging
import threading
from unittest.mock import patch, MagicMock
from datetime import datetime

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("kr_kripto_tests")

# Adicionar diretório raiz ao path
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

# Testes para OperadorBinance
class TestOperadorBinance(unittest.TestCase):
    """Testes para o OperadorBinance."""
    
    def setUp(self):
        """Configuração inicial para os testes."""
        from src.infrastructure.operador import OperadorBinance
        self.operador = OperadorBinance(testnet=True)
    
    def test_obter_klines_method_exists(self):
        """Testa se o método obter_klines existe."""
        self.assertTrue(hasattr(self.operador, 'obter_klines'), 
                        "O método obter_klines não existe no OperadorBinance")
    
    def test_obter_klines_signature(self):
        """Testa a assinatura do método obter_klines."""
        import inspect
        signature = inspect.signature(self.operador.obter_klines)
        parameters = list(signature.parameters.keys())
        
        self.assertIn('ativo', parameters, "Parâmetro 'ativo' não encontrado na assinatura")
        self.assertIn('intervalo', parameters, "Parâmetro 'intervalo' não encontrado na assinatura")
        self.assertIn('limite', parameters, "Parâmetro 'limite' não encontrado na assinatura")
    
    @patch('src.infrastructure.operador.Client')
    def test_obter_klines_functionality(self, mock_client):
        """Testa a funcionalidade do método obter_klines."""
        # Configurar mock
        mock_instance = mock_client.return_value
        mock_instance.get_klines.return_value = [
            [1622505600000, "35000", "36000", "34500", "35500", "100", 1622509200000, "3500000", 1000, "50", "1750000", "0"]
            for _ in range(10)
        ]
        
        # Executar método
        self.operador.sync_client = mock_instance
        result = self.operador.obter_klines("BTCUSDT", "1h", 10)
        
        # Verificar resultado
        self.assertIsNotNone(result, "O método obter_klines retornou None")
        self.assertEqual(len(result), 10, "O número de klines retornado não é o esperado")
        mock_instance.get_klines.assert_called_once_with(symbol="BTCUSDT", interval="1h", limit=10)

# Testes para o gerenciador de resiliência
class TestResilienceManager(unittest.TestCase):
    """Testes para o gerenciador de resiliência."""
    
    def setUp(self):
        """Configuração inicial para os testes."""
        from src.core.resilience_manager import with_timeout, with_circuit_breaker, reset_all_circuit_breakers
        self.with_timeout = with_timeout
        self.with_circuit_breaker = with_circuit_breaker
        self.reset_all_circuit_breakers = reset_all_circuit_breakers
        self.reset_all_circuit_breakers()
    
    def test_timeout_decorator(self):
        """Testa o decorador de timeout."""
        # Função que não excede o timeout
        @self.with_timeout(1)
        def fast_function():
            return "success"
        
        # Função que excede o timeout
        @self.with_timeout(1)
        def slow_function():
            time.sleep(2)
            return "success"
        
        # Testar função rápida
        self.assertEqual(fast_function(), "success", "A função rápida não retornou o resultado esperado")
        
        # Testar função lenta
        from src.core.resilience_manager import TimeoutError
        with self.assertRaises(TimeoutError, msg="A função lenta não lançou TimeoutError"):
            slow_function()
    
    def test_circuit_breaker_decorator(self):
        """Testa o decorador de circuit breaker."""
        # Função que sempre falha
        failure_count = 0
        
        @self.with_circuit_breaker("test_operation", max_failures=3)
        def failing_function():
            nonlocal failure_count
            failure_count += 1
            raise ValueError("Falha simulada")
        
        # Testar circuit breaker
        from src.core.resilience_manager import CircuitBreakerOpenError
        
        # Primeiras 3 chamadas devem lançar ValueError
        for _ in range(3):
            with self.assertRaises(ValueError, msg="A função não lançou ValueError"):
                failing_function()
        
        # Próxima chamada deve lançar CircuitBreakerOpenError
        with self.assertRaises(CircuitBreakerOpenError, msg="O circuit breaker não abriu após 3 falhas"):
            failing_function()
        
        # Verificar contador de falhas
        self.assertEqual(failure_count, 3, "O contador de falhas não é o esperado")

# Testes para o mecanismo de rollback
class TestRollback(unittest.TestCase):
    """Testes para o mecanismo de rollback."""
    
    def setUp(self):
        """Configuração inicial para os testes."""
        from src.infrastructure.rollback import verificar_necessidade_de_rollback, registrar_operacao
        self.verificar_necessidade_de_rollback = verificar_necessidade_de_rollback
        self.registrar_operacao = registrar_operacao
    
    def test_verificar_necessidade_de_rollback_signature(self):
        """Testa a assinatura do método verificar_necessidade_de_rollback."""
        import inspect
        signature = inspect.signature(self.verificar_necessidade_de_rollback)
        parameters = list(signature.parameters.keys())
        
        self.assertIn('componente', parameters, "Parâmetro 'componente' não encontrado na assinatura")
    
    def test_verificar_necessidade_de_rollback_functionality(self):
        """Testa a funcionalidade do método verificar_necessidade_de_rollback."""
        # Registrar operações bem-sucedidas
        for _ in range(5):
            self.registrar_operacao("sistema", True)
        
        # Verificar que não é necessário rollback
        self.assertFalse(self.verificar_necessidade_de_rollback("sistema"), 
                         "Rollback não deveria ser necessário após operações bem-sucedidas")
        
        # Registrar operações com falha
        for _ in range(10):
            self.registrar_operacao("sistema", False)
        
        # Verificar que é necessário rollback
        self.assertTrue(self.verificar_necessidade_de_rollback("sistema"), 
                        "Rollback deveria ser necessário após muitas falhas")

# Testes para redirecionamentos de módulos
class TestModuleRedirects(unittest.TestCase):
    """Testes para redirecionamentos de módulos."""
    
    def test_memoria_temporal_import(self):
        """Testa a importação do MemoriaTemporal."""
        try:
            from src.intelligence.import_fix_memoria_temporal import MemoriaTemporal
            self.assertTrue(True, "MemoriaTemporal importado com sucesso")
        except ImportError:
            self.fail("Falha ao importar MemoriaTemporal")
    
    def test_model_performance_tracker_import(self):
        """Testa a importação do ModelPerformanceTracker."""
        try:
            from src.intelligence.import_fix_model_performance_tracker import ModelPerformanceTracker
            self.assertTrue(True, "ModelPerformanceTracker importado com sucesso")
        except ImportError:
            self.fail("Falha ao importar ModelPerformanceTracker")

# Testes para o PrometheusExporter
class TestPrometheusExporter(unittest.TestCase):
    """Testes para o PrometheusExporter."""
    
    def setUp(self):
        """Configuração inicial para os testes."""
        try:
            import src.infrastructure.prometheus_exporter_v3 as prometheus_exporter
            self.prometheus_exporter = prometheus_exporter
        except ImportError:
            self.skipTest("PrometheusExporter não disponível")
    
    def test_prometheus_exporter_version(self):
        """Testa a versão do PrometheusExporter."""
        self.assertEqual(self.prometheus_exporter.__version__, "3.0.1", 
                         "Versão do PrometheusExporter não é a esperada")
    
    def test_metric_creation(self):
        """Testa a criação de métricas."""
        # Verificar se as métricas são criadas com prefixo único
        metric_name = "TEST_METRIC"
        metric = self.prometheus_exporter._create_metric("counter", metric_name, "Métrica de teste")
        
        self.assertIsNotNone(metric, "A métrica não foi criada")
        
        # Verificar se a métrica está no dicionário de métricas
        unique_name = self.prometheus_exporter._get_unique_name(metric_name)
        self.assertIn(unique_name, self.prometheus_exporter._metrics, 
                      "A métrica não foi armazenada no dicionário")
    
    def test_duplicate_metrics_handling(self):
        """Testa o tratamento de métricas duplicadas."""
        # Criar duas métricas com o mesmo nome
        metric_name = "DUPLICATE_TEST"
        metric1 = self.prometheus_exporter._create_metric("counter", metric_name, "Primeira métrica")
        metric2 = self.prometheus_exporter._create_metric("counter", metric_name, "Segunda métrica")
        
        # Verificar que as métricas são o mesmo objeto
        self.assertIs(metric1, metric2, "As métricas duplicadas não são o mesmo objeto")

# Executar testes
if __name__ == "__main__":
    unittest.main()
