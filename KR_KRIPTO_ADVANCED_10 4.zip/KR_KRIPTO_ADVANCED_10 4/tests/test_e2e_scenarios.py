# src/tests/e2e/test_e2e_scenarios.py

import pytest
import tempfile
import time
import os
import subprocess
import asyncio
import json
# from unittest.mock import patch, AsyncMock # No longer needed for WS mock
import aiohttp # Import aiohttp for exceptions
import errno # For OSError code

# Import the fixture
from tests.e2e.fixtures.process_fixture import run_kripto_process

# Define paths
E2E_CONFIG_PATH = "src/tests/e2e/config/e2e_config.json"
E2E_NORMAL_DATA_PATH = "src/tests/e2e/data/e2e_normal_data.csv"
E2E_LOG_PATH = os.path.join(tempfile.gettempdir(), "e2e_test.log")
os.makedirs(os.path.join(tempfile.gettempdir(), "e2e_test.log"), exist_ok=True)

