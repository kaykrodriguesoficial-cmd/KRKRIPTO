# Tests for src/strategies/fakeout.py

import pandas as pd
import numpy as np
import pytest

# Adjust import path based on the project structure
from src.strategies.fakeout import detectar_fakeout

# Fixture for sample DataFrame with necessary columns for BEARISH fakeout
@pytest.fixture
def df_for_bearish_fakeout():
    """Provides a DataFrame with HIGH, LOW, CLOSE, and RSI_14 (uppercase) containing BEARISH divergence."""
    data = {
        # Contains Bearish divergence: Higher High in price, Lower High in RSI
        'HIGH':  [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 118], # Bearish Fakeout High (120 > 111)
        'LOW':   [90,  91,  92,  93,  94,  95,  96,  97,  98,  99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 108, 107],
        'CLOSE': [95,  96,  97,  98,  99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 112],
        'RSI_14':[30,  35,  40,  45,  50,  55,  60,  65,  70,  75,  80,  78,  75,  70,  65,  60,  55,  50,  45,  40,  35,  40]  # RSI Lower High (35 < 80)
    }
    df = pd.DataFrame(data)
    for col in df.columns:
        df[col] = pd.to_numeric(df[col])
    return df

# --- NEW FIXTURE for BULLISH fakeout --- 
@pytest.fixture
def df_for_bullish_fakeout():
    """Provides a DataFrame with only BULLISH divergence (Lower Low price, Higher Low RSI)."""
    data = {
        # Focus on lows: Lower low in price, higher low in RSI
        # Avoid bearish divergence: No higher high + lower high RSI
        'HIGH':  [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 110, 109, 108, 107, 106, 105, 104, 103, 102, 101], # Price makes lower highs
        'LOW':   [90,  91,  92,  93,  94,  95,  96,  97,  98,  99,  97,  96,  95,  94,  93,  92,  91,  90,  89,  88,  87,  86], # Lower Low (86 vs 87)
        'CLOSE': [95,  96,  97,  98,  99, 100, 101, 102, 103, 104, 100,  99,  98,  97,  96,  95,  94,  93,  92,  91,  90,  89],
        'RSI_14':[30,  35,  40,  45,  50,  55,  60,  65,  70,  65,  40,  38,  36,  34,  32,  30,  28,  26,  24,  22,  25,  27]  # Higher Low (27 vs 22)
    }
    df = pd.DataFrame(data)
    for col in df.columns:
        df[col] = pd.to_numeric(df[col])
    return df
# --- END NEW FIXTURE ---

def test_detectar_fakeout_bullish(df_for_bullish_fakeout): # Use new fixture
    """Test detection of a potential bullish fakeout (divergence)."""
    df = df_for_bullish_fakeout # Use new fixture
    # The function currently only detects the specific bearish divergence.
    # Since this data only has bullish divergence, the function should return False.
    score = detectar_fakeout(df)
    assert isinstance(score, bool)
    assert score is False # Expecting False because function only checks bearish

def test_detectar_fakeout_bearish(df_for_bearish_fakeout): # Use specific bearish fixture
    """Test detection of a potential bearish fakeout (divergence)."""
    df = df_for_bearish_fakeout # Use specific bearish fixture
    # The function's stub logic is designed to detect the bearish divergence in this specific data.
    score = detectar_fakeout(df)
    assert isinstance(score, bool)
    # Based on the data and stub logic, this should trigger the bearish fakeout condition
    assert score is True # Expecting True for bearish fakeout

def test_detectar_fakeout_no_divergence():
    """Test when there is no clear divergence."""
    # Create data without divergence
    data = {
        'HIGH':  [100, 101, 102, 103, 104, 105, 106, 107, 108, 109] * 2,
        'LOW':   [90,  91,  92,  93,  94,  95,  96,  97,  98,  99 ] * 2,
        'CLOSE': [95,  96,  97,  98,  99, 100, 101, 102, 103, 104] * 2,
        'RSI_14':[30,  35,  40,  45,  50,  55,  60,  65,  70,  75 ] * 2
    }
    df = pd.DataFrame(data)
    for col in df.columns:
        df[col] = pd.to_numeric(df[col])

    # Function only detects specific bearish divergence, should be False here
    score = detectar_fakeout(df)
    assert score is False

def test_detectar_fakeout_insufficient_data():
    """Test with data shorter than the lookback period."""
    data = {
        'HIGH': [100, 101], 'LOW': [90, 91], 'CLOSE': [95, 96], 'RSI_14': [50, 55]
    }
    df = pd.DataFrame(data)
    for col in df.columns:
        df[col] = pd.to_numeric(df[col])

    # Expect False if data is too short
    score = detectar_fakeout(df)
    assert score is False

def test_detectar_fakeout_missing_columns():
    """Test when essential columns are missing."""
    data = {"CLOSE": [100, 101, 102] * 10, "RSI_14": [50, 55, 60] * 10} # Missing HIGH, LOW
    df = pd.DataFrame(data)
    for col in df.columns:
        df[col] = pd.to_numeric(df[col])

    # Expect False as the function catches the KeyError and returns False
    score = detectar_fakeout(df)
    assert score is False

