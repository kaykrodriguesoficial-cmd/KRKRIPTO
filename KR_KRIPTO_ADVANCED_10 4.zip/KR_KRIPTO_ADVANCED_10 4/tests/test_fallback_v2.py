#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Testes unitários para o módulo GerenciadorFallback.
"""

import os
import sys
import unittest
import tempfile
import shutil
from datetime import datetime, timedelta

# Adicionar diretório pai ao path para importar o módulo
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Importar o módulo a ser testado
from src.core.fallback import GerenciadorFallback

# Função serializável para uso nos testes
def modelo_predict_func(x):
    return {"prediction": 0.7, "confidence": 0.8}

class TestGerenciadorFallback(unittest.TestCase):
    """Testes para o GerenciadorFallback."""
    
    def setUp(self):
        """Configuração inicial para cada teste."""
        # Criar diretório temporário para testes
        self.temp_dir = tempfile.mkdtemp()
        
        # Configuração de teste
        self.config = {
            "max_falhas": 3,
            "janela_falhas": 60,  # 1 minuto
            "tempo_reset": 120,  # 2 minutos
        }
        
        # Instanciar o gerenciador
        self.gerenciador = GerenciadorFallback(config=self.config)
        
        # Substituir o diretório de fallback pelo temporário
        self.gerenciador.diretorio_fallback = os.path.join(self.temp_dir, ".fallback_cache")
        os.makedirs(self.gerenciador.diretorio_fallback, exist_ok=True)
    
    def tearDown(self):
        """Limpeza após cada teste."""
        # Remover diretório temporário
        shutil.rmtree(self.temp_dir)
    
    def test_inicializacao(self):
        """Testar inicialização do gerenciador."""
        self.assertIsNotNone(self.gerenciador)
        self.assertEqual(self.gerenciador.max_falhas, 3)
        self.assertEqual(self.gerenciador.janela_falhas, 60)
        self.assertEqual(self.gerenciador.tempo_reset, 120)
        self.assertIsInstance(self.gerenciador.modelos_fallback, dict)
        self.assertIn("default", self.gerenciador.modelos_fallback)
    
    def test_registrar_falha(self):
        """Testar registro de falhas."""
        # Registrar uma falha
        resultado = self.gerenciador.registrar_falha("componente_teste", Exception("Erro de teste"))
        self.assertFalse(resultado)  # Não deve ativar circuit breaker com apenas uma falha
        self.assertIn("componente_teste", self.gerenciador.falhas)
        self.assertEqual(len(self.gerenciador.falhas["componente_teste"]), 1)
        
        # Registrar mais falhas até ativar circuit breaker
        self.gerenciador.registrar_falha("componente_teste", Exception("Erro de teste 2"))
        resultado = self.gerenciador.registrar_falha("componente_teste", Exception("Erro de teste 3"))
        self.assertTrue(resultado)  # Deve ativar circuit breaker após 3 falhas
        self.assertIn("componente_teste", self.gerenciador.circuit_breakers)
    
    def test_verificar_circuit_breaker(self):
        """Testar verificação de circuit breaker."""
        # Ativar circuit breaker
        for i in range(3):
            self.gerenciador.registrar_falha("componente_teste", Exception(f"Erro de teste {i+1}"))
        
        # Verificar se está ativo
        self.assertTrue(self.gerenciador.verificar_circuit_breaker("componente_teste"))
        
        # Modificar o tempo de reset para testar reset
        cb_info = self.gerenciador.circuit_breakers["componente_teste"]
        cb_info["reset_em"] = datetime.now() - timedelta(seconds=1)  # Já passou o tempo de reset
        
        # Verificar novamente - deve estar resetado
        self.assertFalse(self.gerenciador.verificar_circuit_breaker("componente_teste"))
        self.assertNotIn("componente_teste", self.gerenciador.circuit_breakers)
    
    def test_obter_status(self):
        """Testar obtenção de status."""
        # Status inicial
        status = self.gerenciador.obter_status()
        self.assertEqual(status["status"], "OK")
        self.assertFalse(status["circuit_breaker"])
        
        # Ativar circuit breaker
        for i in range(3):
            self.gerenciador.registrar_falha("componente_teste", Exception(f"Erro de teste {i+1}"))
        
        # Verificar status atualizado
        status = self.gerenciador.obter_status()
        self.assertEqual(status["status"], "DEGRADED")
        self.assertTrue(status["circuit_breaker"])
        self.assertIn("componente_teste", status["componentes"])
    
    def test_verificar_necessidade_de_rollback(self):
        """Testar verificação de necessidade de rollback."""
        # Sem necessidade de rollback
        metricas = {"erro_critico": False, "falhas_consecutivas": 1, "memoria_percentual": 50, "cpu_percentual": 30}
        self.assertFalse(self.gerenciador.verificar_necessidade_de_rollback(metricas))
        
        # Com erro crítico
        metricas["erro_critico"] = True
        self.assertTrue(self.gerenciador.verificar_necessidade_de_rollback(metricas))
        
        # Com falhas consecutivas
        metricas["erro_critico"] = False
        metricas["falhas_consecutivas"] = 3
        self.assertTrue(self.gerenciador.verificar_necessidade_de_rollback(metricas))
        
        # Com uso crítico de memória
        metricas["falhas_consecutivas"] = 1
        metricas["memoria_percentual"] = 96
        self.assertTrue(self.gerenciador.verificar_necessidade_de_rollback(metricas))
    
    def test_modelos_fallback(self):
        """Testar operações com modelos de fallback."""
        # Obter modelo default
        modelo = self.gerenciador.obter_modelo_fallback()
        self.assertIsNotNone(modelo)
        
        # Criar e salvar novo modelo (usando função global em vez de lambda)
        novo_modelo = {"tipo": "teste", "criado_em": datetime.now(), "predict": modelo_predict_func}
        resultado = self.gerenciador.salvar_modelo_fallback("modelo_teste", novo_modelo)
        self.assertTrue(resultado)
        
        # Obter modelo salvo
        modelo_carregado = self.gerenciador.obter_modelo_fallback("modelo_teste")
        self.assertEqual(modelo_carregado["tipo"], "teste")
        
        # Verificar se o arquivo foi criado
        self.assertTrue(os.path.exists(os.path.join(self.gerenciador.diretorio_fallback, "modelo_teste.pkl")))

if __name__ == "__main__":
    unittest.main()
