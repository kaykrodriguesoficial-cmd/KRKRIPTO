#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Testes unitários para o módulo GerenciadorFallback híbrido.
"""

import os
import sys
import unittest
import tempfile
import shutil
from datetime import datetime, timedelta

# Adicionar diretório pai ao path para importar o módulo
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Importar o módulo de correção de importações
try:
    from src.intelligence.import_fix_v3 import fix_imports
    fix_imports()
except ImportError:
    print("Aviso: Não foi possível carregar o corretor de importações v3.")

# Importar o módulo a ser testado
from src.core.fallback_v2 import GerenciadorFallback

# Função serializável para uso nos testes
def modelo_predict_func(x):
    return {"prediction": 0.7, "confidence": 0.8}

class TestGerenciadorFallbackHibrido(unittest.TestCase):
    """Testes para o GerenciadorFallback híbrido."""
    
    def setUp(self):
        """Configuração inicial para cada teste."""
        # Criar diretório temporário para testes
        self.temp_dir = tempfile.mkdtemp()
        
        # Configuração de teste
        self.config = {
            "max_falhas": 3,
            "janela_falhas": 60,  # 1 minuto
            "tempo_reset": 120,  # 2 minutos
        }
        
        # Instanciar o gerenciador
        self.gerenciador = GerenciadorFallback(config=self.config)
        
        # Substituir o diretório de fallback pelo temporário
        self.gerenciador.diretorio_fallback = os.path.join(self.temp_dir, ".fallback_cache")
        os.makedirs(self.gerenciador.diretorio_fallback, exist_ok=True)
    
    def tearDown(self):
        """Limpeza após cada teste."""
        # Remover diretório temporário
        shutil.rmtree(self.temp_dir)
    
    def test_inicializacao(self):
        """Testar inicialização do gerenciador."""
        self.assertIsNotNone(self.gerenciador)
        self.assertEqual(self.gerenciador.max_falhas, 3)
        self.assertEqual(self.gerenciador.janela_falhas, 60)
        self.assertEqual(self.gerenciador.tempo_reset, 120)
        self.assertIsInstance(self.gerenciador.modelos_fallback, dict)
        self.assertIn("default", self.gerenciador.modelos_fallback)
        # Verificar novos atributos da versão híbrida
        self.assertIsInstance(self.gerenciador.watchdog_tasks, dict)
    
    def test_registrar_falha(self):
        """Testar registro de falhas."""
        # Registrar uma falha
        resultado = self.gerenciador.registrar_falha("componente_teste", Exception("Erro de teste"))
        self.assertFalse(resultado)  # Não deve ativar circuit breaker com apenas uma falha
        self.assertIn("componente_teste", self.gerenciador.falhas)
        self.assertEqual(len(self.gerenciador.falhas["componente_teste"]), 1)
        
        # Registrar mais falhas até ativar circuit breaker
        self.gerenciador.registrar_falha("componente_teste", Exception("Erro de teste 2"))
        resultado = self.gerenciador.registrar_falha("componente_teste", Exception("Erro de teste 3"))
        self.assertTrue(resultado)  # Deve ativar circuit breaker após 3 falhas
        self.assertIn("componente_teste", self.gerenciador.circuit_breakers)
    
    def test_verificar_circuit_breaker(self):
        """Testar verificação de circuit breaker."""
        # Ativar circuit breaker
        for i in range(3):
            self.gerenciador.registrar_falha("componente_teste", Exception(f"Erro de teste {i+1}"))
        
        # Verificar se está ativo
        self.assertTrue(self.gerenciador.verificar_circuit_breaker("componente_teste"))
        
        # Modificar o tempo de reset para testar reset
        cb_info = self.gerenciador.circuit_breakers["componente_teste"]
        cb_info["reset_em"] = datetime.now() - timedelta(seconds=1)  # Já passou o tempo de reset
        
        # Verificar novamente - deve estar resetado
        self.assertFalse(self.gerenciador.verificar_circuit_breaker("componente_teste"))
        self.assertNotIn("componente_teste", self.gerenciador.circuit_breakers)
    
    def test_obter_status(self):
        """Testar obtenção de status."""
        # Status inicial
        status = self.gerenciador.obter_status()
        self.assertEqual(status["status"], "OK")
        self.assertFalse(status["circuit_breaker"])
        
        # Ativar circuit breaker
        for i in range(3):
            self.gerenciador.registrar_falha("componente_teste", Exception(f"Erro de teste {i+1}"))
        
        # Verificar status atualizado
        status = self.gerenciador.obter_status()
        self.assertEqual(status["status"], "DEGRADED")
        self.assertTrue(status["circuit_breaker"])
        self.assertIn("componente_teste", status["componentes"])
        # Verificar novos campos da versão híbrida
        self.assertIn("watchdog_tasks", status)
    
    def test_verificar_necessidade_de_rollback(self):
        """Testar verificação de necessidade de rollback."""
        # Sem necessidade de rollback
        metricas = {"erro_critico": False, "falhas_consecutivas": 1, "memoria_percentual": 50, "cpu_percentual": 30}
        self.assertFalse(self.gerenciador.verificar_necessidade_de_rollback(metricas))
        
        # Com erro crítico
        metricas["erro_critico"] = True
        self.assertTrue(self.gerenciador.verificar_necessidade_de_rollback(metricas))
        
        # Com falhas consecutivas
        metricas["erro_critico"] = False
        metricas["falhas_consecutivas"] = 3
        self.assertTrue(self.gerenciador.verificar_necessidade_de_rollback(metricas))
        
        # Com uso crítico de memória
        metricas["falhas_consecutivas"] = 1
        metricas["memoria_percentual"] = 96
        self.assertTrue(self.gerenciador.verificar_necessidade_de_rollback(metricas))
    
    def test_modelos_fallback(self):
        """Testar operações com modelos de fallback."""
        # Obter modelo default
        modelo = self.gerenciador.obter_modelo_fallback()
        self.assertIsNotNone(modelo)
        
        # Criar e salvar novo modelo (usando função global em vez de lambda)
        novo_modelo = {"tipo": "teste", "criado_em": datetime.now(), "predict": modelo_predict_func}
        resultado = self.gerenciador.salvar_modelo_fallback("modelo_teste", novo_modelo)
        self.assertTrue(resultado)
        
        # Obter modelo salvo
        modelo_carregado = self.gerenciador.obter_modelo_fallback("modelo_teste")
        self.assertEqual(modelo_carregado["tipo"], "teste")
        
        # Verificar se o arquivo foi criado
        self.assertTrue(os.path.exists(os.path.join(self.gerenciador.diretorio_fallback, "modelo_teste.pkl")))
    
    def test_watchdog(self):
        """Testar funcionalidade de watchdog."""
        # Variáveis para teste
        self.watchdog_chamado = False
        self.watchdog_args = None
        self.watchdog_kwargs = None
        
        # Função de callback para o watchdog
        def watchdog_callback(*args, **kwargs):
            self.watchdog_chamado = True
            self.watchdog_args = args
            self.watchdog_kwargs = kwargs
            return "OK"
        
        # Registrar watchdog
        resultado = self.gerenciador.registrar_watchdog(
            "tarefa_teste", 
            1,  # 1 segundo
            watchdog_callback,
            args=["arg1", "arg2"],
            kwargs={"kwarg1": "valor1"}
        )
        self.assertTrue(resultado)
        self.assertIn("tarefa_teste", self.gerenciador.watchdog_tasks)
        
        # Modificar o tempo da última verificação para forçar disparo
        self.gerenciador.watchdog_tasks["tarefa_teste"]["ultima_verificacao"] = datetime.now() - timedelta(seconds=2)
        
        # Verificar watchdogs
        resultados = self.gerenciador.verificar_watchdogs()
        
        # Verificar que o callback foi chamado
        self.assertTrue(self.watchdog_chamado)
        self.assertEqual(self.watchdog_args, ("arg1", "arg2"))
        self.assertEqual(self.watchdog_kwargs, {"kwarg1": "valor1"})
        self.assertIn("tarefa_teste", resultados)
        self.assertEqual(resultados["tarefa_teste"]["status"], "OK")
    
    def test_monitorar_modelo(self):
        """Testar monitoramento de modelo."""
        # Monitorar modelo com métricas boas
        resultado = self.gerenciador.monitorar_modelo(
            "modelo_teste",
            {"acuracia": 0.85, "erro_medio": 0.15}
        )
        self.assertEqual(resultado["status"], "OK")
        self.assertEqual(resultado["alertas_atual"], 0)
        
        # Monitorar modelo com métricas ruins
        resultado = self.gerenciador.monitorar_modelo(
            "modelo_teste",
            {"acuracia": 0.55, "erro_medio": 0.45, "erro_quadratico": 0.35}
        )
        self.assertEqual(resultado["status"], "WARNING")
        # Corrigido: Agora esperamos 2 alertas (erro_medio e erro_quadratico estão acima do limiar)
        self.assertEqual(resultado["alertas_atual"], 2)
        
        # Verificar que o histórico foi registrado
        componente = self.gerenciador.status["componentes"][f"modelo_modelo_teste"]
        self.assertEqual(len(componente["metricas_historicas"]), 2)
    
    def test_circuit_breaker_sincrono(self):
        """Testar decorador de circuit breaker síncrono."""
        # Função para testar
        chamadas = [0]
        erros = [0]
        
        @self.gerenciador.circuit_breaker_sincrono("funcao_teste")
        def funcao_teste(falhar=False):
            chamadas[0] += 1
            if falhar:
                erros[0] += 1
                raise ValueError("Erro de teste")
            return "OK"
        
        # Testar função sem falhas
        resultado = funcao_teste()
        self.assertEqual(resultado, "OK")
        self.assertEqual(chamadas[0], 1)
        self.assertEqual(erros[0], 0)
        
        # Testar função com falhas
        for _ in range(2):
            with self.assertRaises(ValueError):
                funcao_teste(falhar=True)
        
        self.assertEqual(chamadas[0], 3)
        self.assertEqual(erros[0], 2)
        
        # Testar circuit breaker ativado
        with self.assertRaises(ValueError):
            funcao_teste(falhar=True)
        
        # Verificar que o circuit breaker está ativo
        self.assertTrue(self.gerenciador.verificar_circuit_breaker("funcao_teste"))
        
        # Tentar chamar função com circuit breaker ativo
        with self.assertRaises(Exception) as context:
            funcao_teste()
        
        self.assertIn("Circuit breaker ativo", str(context.exception))
        # Corrigido: A chamada acima também incrementa o contador, mesmo que o circuit breaker bloqueie
        self.assertEqual(chamadas[0], 4)

if __name__ == "__main__":
    unittest.main()
