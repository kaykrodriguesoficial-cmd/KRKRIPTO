#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Testes unitários para o módulo fallback_v2.py.
Verifica a funcionalidade do GerenciadorFallback em ambiente Mac M1.
"""

import os
import sys
import unittest
import logging
from datetime import datetime, timedelta
import platform
import tempfile
import json

# Configurar logging para testes
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("test_fallback_v2")

# Adicionar diretório raiz ao path para importações
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Importar o módulo a ser testado
try:
    from src.core.fallback_v2 import GerenciadorFallback, is_mac_m1
except ImportError:
    logger.error("Não foi possível importar GerenciadorFallback de src.core.fallback_v2")
    # Tentar importação alternativa
    try:
        from src.core.fallback import GerenciadorFallback, is_mac_m1
        logger.info("GerenciadorFallback importado de src.core.fallback")
    except ImportError:
        logger.error("Não foi possível importar GerenciadorFallback de src.core.fallback")
        raise

class TestGerenciadorFallback(unittest.TestCase):
    """Testes para o GerenciadorFallback."""
    
    def setUp(self):
        """Configuração inicial para cada teste."""
        # Detectar ambiente
        self.is_mac_m1 = is_mac_m1()
        self.ambiente = "Mac M1" if self.is_mac_m1 else "Outro"
        logger.info(f"Executando testes em ambiente: {self.ambiente}")
        
        # Criar configuração de teste
        self.config = {
            "max_falhas": 2,
            "janela_falhas": 10,
            "tempo_reset": 5
        }
        
        # Criar instância do gerenciador
        self.gerenciador = GerenciadorFallback(config=self.config)
    
    def test_inicializacao(self):
        """Testa a inicialização do gerenciador."""
        self.assertIsNotNone(self.gerenciador)
        self.assertEqual(self.gerenciador.config["max_falhas"], 2)
        self.assertEqual(self.gerenciador.config["janela_falhas"], 10)
        self.assertEqual(self.gerenciador.config["tempo_reset"], 5)
    
    def test_registrar_falha(self):
        """Testa o registro de falhas."""
        # Registrar primeira falha
        resultado = self.gerenciador.registrar_falha("componente_teste", Exception("Erro de teste"))
        self.assertFalse(resultado.get("circuit_breaker", False))
        self.assertEqual(resultado.get("falhas_recentes", 0), 1)
        
        # Registrar segunda falha (deve ativar circuit breaker)
        resultado = self.gerenciador.registrar_falha("componente_teste", Exception("Outro erro"))
        self.assertTrue(resultado.get("circuit_breaker", False))
        self.assertEqual(resultado.get("falhas_recentes", 0), 2)
    
    def test_verificar_circuit_breaker(self):
        """Testa a verificação de circuit breaker."""
        # Inicialmente não deve ter circuit breaker
        self.assertFalse(self.gerenciador.verificar_circuit_breaker("componente_teste"))
        
        # Ativar circuit breaker
        self.gerenciador.registrar_falha("componente_teste", Exception("Erro 1"))
        self.gerenciador.registrar_falha("componente_teste", Exception("Erro 2"))
        
        # Verificar que está ativo
        self.assertTrue(self.gerenciador.verificar_circuit_breaker("componente_teste"))
        
        # Esperar reset
        import time
        time.sleep(self.config["tempo_reset"] + 1)
        
        # Verificar que foi resetado
        self.assertFalse(self.gerenciador.verificar_circuit_breaker("componente_teste"))
    
    def test_obter_modelo_fallback(self):
        """Testa a obtenção do modelo de fallback."""
        modelo = self.gerenciador.obter_modelo_fallback()
        self.assertIsNotNone(modelo)
        self.assertTrue(callable(modelo.get("predict")))
        
        # Testar função de predição
        predicao = modelo["predict"]({"feature1": 1.0})
        self.assertIsNotNone(predicao)
        self.assertIn("prediction", predicao)
    
    def test_monitorar_modelo(self):
        """Testa o monitoramento de modelos."""
        # Métricas boas
        metricas_boas = {"accuracy": 0.9, "erro": 0.1}
        resultado = self.gerenciador.monitorar_modelo("modelo_bom", metricas_boas)
        self.assertEqual(resultado["status"], "OK")
        
        # Métricas ruins
        metricas_ruins = {"accuracy": 0.3, "erro": 0.7}
        resultado = self.gerenciador.monitorar_modelo("modelo_ruim", metricas_ruins)
        self.assertNotEqual(resultado["status"], "OK")
    
    def test_compatibilidade_mac_m1(self):
        """Testa a compatibilidade com Mac M1."""
        # Verificar detecção de ambiente
        ambiente_detectado = is_mac_m1()
        logger.info(f"Ambiente Mac M1 detectado: {ambiente_detectado}")
        
        # Verificar se a função is_mac_m1 está funcionando corretamente
        if platform.system() == "Darwin" and "arm" in platform.machine().lower():
            self.assertTrue(ambiente_detectado)
        
        # Verificar se o gerenciador funciona no ambiente atual
        self.assertIsNotNone(self.gerenciador)
        self.assertIsNotNone(self.gerenciador.obter_modelo_fallback())
    
    def test_circuit_breaker_decorator(self):
        """Testa o decorator de circuit breaker."""
        # Função de teste
        @self.gerenciador.circuit_breaker_sincrono("componente_decorado")
        def funcao_teste():
            return "sucesso"
        
        # Testar função normal
        self.assertEqual(funcao_teste(), "sucesso")
        
        # Ativar circuit breaker
        self.gerenciador.registrar_falha("componente_decorado", Exception("Erro 1"))
        self.gerenciador.registrar_falha("componente_decorado", Exception("Erro 2"))
        
        # Testar função com circuit breaker ativo
        self.assertIsNone(funcao_teste())
    
    def test_obter_status(self):
        """Testa a obtenção do status do gerenciador."""
        status = self.gerenciador.obter_status()
        self.assertIsNotNone(status)
        self.assertIn("status", status)
        self.assertIn("circuit_breaker", status)
        self.assertIn("componentes", status)
    
    def tearDown(self):
        """Limpeza após cada teste."""
        # Nada a limpar por enquanto
        pass

if __name__ == "__main__":
    unittest.main()
