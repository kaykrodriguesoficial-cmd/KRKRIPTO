# Tests for src/strategies/validators/filtros_institucionais.py

import pytest
import pandas as pd
import numpy as np
from unittest.mock import MagicMock, patch
from typing import Dict, List, Optional, Tuple, Union, Any

# Import the actual functions from the module
from src.strategies.validators.filtros_institucionais import (
    validar_filtro_institucional,
    detectar_rejeicao,
    detectar_volume_anormal,
    detectar_fakeout # Note: This might be redundant with src.strategies.fakeout
)

# --- Fixtures ---

@pytest.fixture
def mock_book_state_filtros():
    """Provides a mock BookState object for filtro tests."""
    state = MagicMock()
    # Add attributes potentially used by filters
    state.liquidez_total_bids = 1000000.0
    state.liquidez_total_asks = 1000000.0
    state.maior_bid_qty = 10.0
    state.maior_ask_qty = 10.0
    state.volume_negociado_recente = 50.0
    state.agressoes_recentes = {"compras": 25.0, "vendas": 25.0}
    return state

@pytest.fixture
def create_df(data):
    """Helper fixture to create DataFrame from dictionary."""
    return pd.DataFrame(data)

@pytest.fixture
def mock_df_filtros():
    """Provides a mock DataFrame for filtro tests."""
    # Create a minimal DataFrame with necessary columns for the mocked functions
    # The actual content might not matter much if the underlying functions are mocked
    data = {
        "High": [100, 101, 102],
        "Low": [98, 99, 100],
        "Close": [99, 100, 101],
        "Open": [98.5, 99.5, 100.5],
        "Volume": [1000, 1100, 1050],
        "fakeout": [0, 0, 0]  # Assuming a fakeout column might be checked
    }
    return pd.DataFrame(data)


# --- Tests for Helper Functions ---

# Test detectar_rejeicao
@pytest.mark.parametrize(
    "high, low, close, open, expected_rejection",
    [
        (110, 90, 91, 92, True),  # Long lower wick (rejection of low)
        (110, 90, 108, 107, True), # Long upper wick (rejection of high)
        (105, 95, 104, 96, False), # Normal candle
        (100, 100, 100, 100, False), # Doji (no range)
    ]
)
def test_detectar_rejeicao(high, low, close, open, expected_rejection):
    df = pd.DataFrame({
        "High": [100] * 19 + [high],
        "Low": [100] * 19 + [low],
        "Close": [100] * 19 + [close],
        "Open": [100] * 19 + [open]
    })
    assert detectar_rejeicao(df) == expected_rejection

# Test detectar_volume_anormal
@pytest.mark.parametrize(
    "volumes, expected_anomaly",
    [
        ([100] * 20 + [150], False), # Normal volume
        ([100] * 20 + [350], True),  # Abnormal volume (> 3x mean)
        ([100] * 5, False),         # Insufficient data
    ]
)
def test_detectar_volume_anormal(volumes, expected_anomaly):
    df = pd.DataFrame({"Volume": volumes})
    assert detectar_volume_anormal(df) == expected_anomaly

# Test detectar_fakeout (internal version)
# Note: This logic seems simple (just checks last value). Needs clarification if it"s correct.
@pytest.mark.parametrize(
    "fakeout_col, expected_detection",
    [
        ([0] * 19 + [1], True), # Fakeout detected in last candle
        ([0] * 20, False),      # No fakeout
        ([1] * 19 + [0], False), # Fakeout not in last candle
    ]
)
def test_detectar_fakeout_internal(fakeout_col, expected_detection):
    df = pd.DataFrame({"fakeout": fakeout_col}) # Assuming a column named "fakeout"
    assert detectar_fakeout(df) == expected_detection

def test_detectar_fakeout_internal_no_col():
    df = pd.DataFrame({"Close": [100]*20})
    assert detectar_fakeout(df) is False # Should handle missing column gracefully

# --- Tests for validar_filtro_institucional ---

@patch("src.strategies.validators.filtros_institucionais.detectar_rejeicao")
@patch("src.strategies.validators.filtros_institucionais.detectar_volume_anormal")
@patch("src.strategies.validators.filtros_institucionais.detectar_fakeout")
def test_validar_filtro_pass(mock_detect_fakeout, mock_detect_volume, mock_detect_rejection, mock_df_filtros, mock_book_state_filtros):
    """Test when all internal checks pass."""
    mock_detect_rejection.return_value = False
    mock_detect_volume.return_value = False
    mock_detect_fakeout.return_value = False

    is_valid, reason = validar_filtro_institucional(mock_df_filtros, mock_book_state_filtros)
    assert is_valid is True
    assert reason == "OK"

@patch("src.strategies.validators.filtros_institucionais.detectar_rejeicao", return_value=True)
@patch("src.strategies.validators.filtros_institucionais.detectar_volume_anormal", return_value=False)
@patch("src.strategies.validators.filtros_institucionais.detectar_fakeout", return_value=False)
def test_validar_filtro_fail_rejection(mock_detect_fakeout, mock_detect_volume, mock_detect_rejection, mock_df_filtros, mock_book_state_filtros):
    """Test when rejection is detected."""
    is_valid, reason = validar_filtro_institucional(mock_df_filtros, mock_book_state_filtros)
    assert is_valid is False
    assert "Rejeição detectada" in reason

@patch("src.strategies.validators.filtros_institucionais.detectar_rejeicao", return_value=False)
@patch("src.strategies.validators.filtros_institucionais.detectar_volume_anormal", return_value=True)
@patch("src.strategies.validators.filtros_institucionais.detectar_fakeout", return_value=False)
def test_validar_filtro_fail_volume(mock_detect_fakeout, mock_detect_volume, mock_detect_rejection, mock_df_filtros, mock_book_state_filtros):
    """Test when abnormal volume is detected."""
    is_valid, reason = validar_filtro_institucional(mock_df_filtros, mock_book_state_filtros)
    assert is_valid is False
    assert "Volume anormal" in reason

@patch("src.strategies.validators.filtros_institucionais.detectar_rejeicao", return_value=False)
@patch("src.strategies.validators.filtros_institucionais.detectar_volume_anormal", return_value=False)
@patch("src.strategies.validators.filtros_institucionais.detectar_fakeout", return_value=True)
def test_validar_filtro_fail_fakeout(mock_detect_fakeout, mock_detect_volume, mock_detect_rejection, mock_df_filtros, mock_book_state_filtros):
    """Test when fakeout is detected."""
    is_valid, reason = validar_filtro_institucional(mock_df_filtros, mock_book_state_filtros)
    assert is_valid is False
    assert "Fakeout detectado" in reason

@patch("src.strategies.validators.filtros_institucionais.detectar_rejeicao", side_effect=Exception("Test Error"))
def test_validar_filtro_exception(mock_detect_rejection, mock_df_filtros, mock_book_state_filtros):
    """Test when an exception occurs during validation."""
    is_valid, reason = validar_filtro_institucional(mock_df_filtros, mock_book_state_filtros)
    assert is_valid is False # Should fail validation on error
    assert "Erro" in reason
