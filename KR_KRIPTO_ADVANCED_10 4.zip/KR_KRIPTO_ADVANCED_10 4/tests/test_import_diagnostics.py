# Conteúdo para tests/test_import_diagnostics.py
import pytest
import sys
import os

def test_check_sys_path_and_environment_for_pytest():
    print("\n--- Diagnóstico de Ambiente Pytest ---")
    print(f"sys.executable: {sys.executable}")
    print("sys.path:")
    for p in sys.path:
        print(f"  - {p}")
    print("Variáveis de Ambiente Relevantes:")
    print(f"  PYTHONPATH: {os.environ.get('PYTHONPATH')}")
    print(f"  VIRTUAL_ENV: {os.environ.get('VIRTUAL_ENV')}")
    print("--- Fim do Diagnóstico de Ambiente Pytest ---\n")
    assert True # Teste apenas para imprimir informações

def test_import_aioresponses():
    print("\nTentando importar aioresponses...")
    try:
        import aioresponses
        print("aioresponses importado com sucesso!")
        print(f"Localização de aioresponses: {aioresponses.__file__}")
        assert True
    except ModuleNotFoundError as e:
        print(f"Falha ao importar aioresponses: {e}")
        pytest.fail(f"ModuleNotFoundError para aioresponses: {e}")
    except Exception as e:
        print(f"Outro erro ao importar aioresponses: {e}")
        pytest.fail(f"Erro inesperado ao importar aioresponses: {e}")

def test_import_binance():
    print("\nTentando importar binance...")
    try:
        import binance
        print("binance importado com sucesso!")
        print(f"Localização de binance: {binance.__file__}")
        assert True
    except ModuleNotFoundError as e:
        print(f"Falha ao importar binance: {e}")
        pytest.fail(f"ModuleNotFoundError para binance: {e}")
    except Exception as e:
        print(f"Outro erro ao importar binance: {e}")
        pytest.fail(f"Erro inesperado ao importar binance: {e}")

