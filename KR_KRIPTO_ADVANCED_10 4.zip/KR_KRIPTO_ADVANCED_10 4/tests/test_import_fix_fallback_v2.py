#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Testes unitários para o mecanismo de importação robusto do fallback_v2.
Verifica a compatibilidade com ambientes Mac M1 (ARM64) e x86_64.
"""

import unittest
import sys
import os
import importlib
import logging
from unittest.mock import patch, MagicMock

# Configurar logging para testes
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("test_import_fix_fallback_v2")

# Adicionar diretório raiz ao path para importações
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class TestImportFixFallbackV2(unittest.TestCase):
    """Testes para o mecanismo de importação robusto do fallback_v2."""
    
    def setUp(self):
        """Preparação para cada teste."""
        # Limpar cache de importação para garantir testes isolados
        if "src.intelligence.import_fix_fallback_v2" in sys.modules:
            del sys.modules["src.intelligence.import_fix_fallback_v2"]
        
        # Backup do sys.path original
        self.original_path = sys.path.copy()
    
    def tearDown(self):
        """Limpeza após cada teste."""
        # Restaurar sys.path original
        sys.path = self.original_path
    
    def test_import_success(self):
        """Testa se o módulo pode ser importado sem erros."""
        try:
            from src.intelligence.import_fix_fallback_v2 import GerenciadorFallback, get_fallback_info
            info = get_fallback_info()
            logger.info(f"GerenciadorFallback info: {info}")
            self.assertTrue(True)  # Se chegou aqui, a importação foi bem-sucedida
        except Exception as e:
            self.fail(f"Falha ao importar import_fix_fallback_v2: {e}")
    
    @patch("src.intelligence.import_fix_fallback_v2.is_mac_m1")
    def test_mac_m1_detection(self, mock_is_mac_m1):
        """Testa a detecção de ambiente Mac M1."""
        # Simular ambiente Mac M1
        mock_is_mac_m1.return_value = True
        
        # Reimportar o módulo com o mock ativo
        if "src.intelligence.import_fix_fallback_v2" in sys.modules:
            del sys.modules["src.intelligence.import_fix_fallback_v2"]
        
        from src.intelligence.import_fix_fallback_v2 import get_fallback_info
        info = get_fallback_info()
        
        self.assertTrue(info["is_mac_m1"])
        logger.info(f"Detecção de Mac M1: {info}")
    
    @patch("src.intelligence.import_fix_fallback_v2.is_mac_m1")
    def test_x86_detection(self, mock_is_mac_m1):
        """Testa a detecção de ambiente x86."""
        # Simular ambiente x86
        mock_is_mac_m1.return_value = False
        
        # Reimportar o módulo com o mock ativo
        if "src.intelligence.import_fix_fallback_v2" in sys.modules:
            del sys.modules["src.intelligence.import_fix_fallback_v2"]
        
        from src.intelligence.import_fix_fallback_v2 import get_fallback_info
        info = get_fallback_info()
        
        self.assertFalse(info["is_mac_m1"])
        logger.info(f"Detecção de x86: {info}")
    
    def test_create_instance(self):
        """Testa a criação de uma instância de GerenciadorFallback."""
        from src.intelligence.import_fix_fallback_v2 import create_fallback_manager
        
        # Criar instância com configuração personalizada
        config = {"max_falhas": 5}
        fallback = create_fallback_manager(config)
        
        self.assertIsNotNone(fallback)
        logger.info(f"Instância criada: {fallback}")
    
    def test_global_instance(self):
        """Testa a instância global de fallback_manager."""
        from src.intelligence.import_fix_fallback_v2 import fallback_manager
        
        self.assertIsNotNone(fallback_manager)
        logger.info(f"Instância global: {fallback_manager}")
    
    def test_basic_functionality(self):
        """Testa funcionalidades básicas do GerenciadorFallback."""
        from src.intelligence.import_fix_fallback_v2 import GerenciadorFallback
        
        fallback = GerenciadorFallback()
        
        # Registrar falha
        fallback.registrar_falha("test_component", Exception("Teste"), {"detail": "test"})
        
        # Verificar circuit breaker
        cb_status = fallback.verificar_circuit_breaker("test_component")
        
        # Obter status
        status = fallback.obter_status()
        self.assertIsNotNone(status)
        
        # Verificar recursos do sistema
        try:
            recursos = fallback.verificar_recursos_sistema()
            logger.info(f"Recursos do sistema: {recursos}")
        except Exception as e:
            logger.warning(f"Não foi possível verificar recursos: {e}")
        
        logger.info(f"Funcionalidades básicas testadas: {status}")
    
    @patch("importlib.util.spec_from_file_location")
    @patch("importlib.util.module_from_spec")
    @patch("os.path.exists")
    def test_fallback_to_stub(self, mock_exists, mock_module_from_spec, mock_spec_from_file_location):
        """Testa o fallback para stub quando nenhuma implementação real está disponível."""
        # Simular que nenhum arquivo existe
        mock_exists.return_value = False
        
        # Simular falha na importação
        mock_spec = MagicMock()
        mock_spec_from_file_location.return_value = mock_spec
        mock_spec.loader.exec_module.side_effect = ImportError("Simulação de falha na importação")
        
        # Reimportar o módulo com os mocks ativos
        if "src.intelligence.import_fix_fallback_v2" in sys.modules:
            del sys.modules["src.intelligence.import_fix_fallback_v2"]
        
        # Patch para evitar importações reais
        with patch.dict(sys.modules, {
            'src.core.fallback_v2': None,
            'src.core.fallback': None,
            'src.infrastructure.fallback_v2': None,
            'src.infrastructure.fallback': None,
            'core.fallback_v2': None,
            'core.fallback': None,
            'infrastructure.fallback_v2': None,
            'infrastructure.fallback': None
        }):
            with patch("importlib.import_module", side_effect=ImportError("Simulação de falha na importação")):
                from src.intelligence.import_fix_fallback_v2 import get_fallback_info, GerenciadorFallback
                
                info = get_fallback_info()
                
                # Testar se o stub funciona
                fallback = GerenciadorFallback()
                status = fallback.obter_status()
                
                logger.info(f"Fallback para stub verificado: {info}")

if __name__ == "__main__":
    unittest.main()
