#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Testes unitários para o mecanismo de importação robusto do MemoriaTemporal.
Verifica a compatibilidade com ambientes Mac M1 (ARM64) e x86_64.
"""

import unittest
import sys
import os
import importlib
import logging
from unittest.mock import patch, MagicMock

# Configurar logging para testes
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("test_import_fix_memoria_temporal")

# Adicionar diretório raiz ao path para importações
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class TestImportFixMemoriaTemporal(unittest.TestCase):
    """Testes para o mecanismo de importação robusto do MemoriaTemporal."""
    
    def setUp(self):
        """Preparação para cada teste."""
        # Limpar cache de importação para garantir testes isolados
        if "src.intelligence.import_fix_memoria_temporal" in sys.modules:
            del sys.modules["src.intelligence.import_fix_memoria_temporal"]
        
        # Backup do sys.path original
        self.original_path = sys.path.copy()
    
    def tearDown(self):
        """Limpeza após cada teste."""
        # Restaurar sys.path original
        sys.path = self.original_path
    
    def test_import_success(self):
        """Testa se o módulo pode ser importado sem erros."""
        try:
            from src.intelligence.import_fix_memoria_temporal import MemoriaTemporal, get_memoria_temporal_info
            info = get_memoria_temporal_info()
            logger.info(f"MemoriaTemporal info: {info}")
            self.assertTrue(True)  # Se chegou aqui, a importação foi bem-sucedida
        except Exception as e:
            self.fail(f"Falha ao importar import_fix_memoria_temporal: {e}")
    
    @patch("src.intelligence.import_fix_memoria_temporal.is_mac_m1")
    def test_mac_m1_detection(self, mock_is_mac_m1):
        """Testa a detecção de ambiente Mac M1."""
        # Simular ambiente Mac M1
        mock_is_mac_m1.return_value = True
        
        # Reimportar o módulo com o mock ativo
        if "src.intelligence.import_fix_memoria_temporal" in sys.modules:
            del sys.modules["src.intelligence.import_fix_memoria_temporal"]
        
        from src.intelligence.import_fix_memoria_temporal import get_memoria_temporal_info
        info = get_memoria_temporal_info()
        
        self.assertTrue(info["is_mac_m1"])
        logger.info(f"Detecção de Mac M1: {info}")
    
    @patch("src.intelligence.import_fix_memoria_temporal.is_mac_m1")
    def test_x86_detection(self, mock_is_mac_m1):
        """Testa a detecção de ambiente x86."""
        # Simular ambiente x86
        mock_is_mac_m1.return_value = False
        
        # Reimportar o módulo com o mock ativo
        if "src.intelligence.import_fix_memoria_temporal" in sys.modules:
            del sys.modules["src.intelligence.import_fix_memoria_temporal"]
        
        from src.intelligence.import_fix_memoria_temporal import get_memoria_temporal_info
        info = get_memoria_temporal_info()
        
        self.assertFalse(info["is_mac_m1"])
        logger.info(f"Detecção de x86: {info}")
    
    def test_create_instance(self):
        """Testa a criação de uma instância de MemoriaTemporal."""
        from src.intelligence.import_fix_memoria_temporal import create_memoria_temporal
        
        # Criar instância com configuração personalizada
        config = {"diretorio_base": "test_data"}
        memoria = create_memoria_temporal(config)
        
        self.assertIsNotNone(memoria)
        logger.info(f"Instância criada: {memoria}")
    
    def test_global_instance(self):
        """Testa a instância global de memoria_temporal."""
        from src.intelligence.import_fix_memoria_temporal import memoria_temporal
        
        self.assertIsNotNone(memoria_temporal)
        logger.info(f"Instância global: {memoria_temporal}")
    
    def test_procedural_interface(self):
        """Testa a interface procedural para compatibilidade com código legado."""
        from src.intelligence.import_fix_memoria_temporal import (
            inicializar_memoria,
            resetar_memoria,
            atualizar_memoria,
            ajustar_por_memoria
        )
        
        # Verificar se as funções existem
        self.assertTrue(callable(inicializar_memoria))
        self.assertTrue(callable(resetar_memoria))
        self.assertTrue(callable(atualizar_memoria))
        self.assertTrue(callable(ajustar_por_memoria))
        
        logger.info("Interface procedural verificada com sucesso")
    
    @patch("importlib.util.spec_from_file_location")
    @patch("importlib.util.module_from_spec")
    @patch("os.path.exists")
    def test_fallback_to_stub(self, mock_exists, mock_module_from_spec, mock_spec_from_file_location):
        """Testa o fallback para stub quando nenhuma implementação real está disponível."""
        # Simular que nenhum arquivo existe
        mock_exists.return_value = False
        
        # Simular falha na importação
        mock_spec = MagicMock()
        mock_spec_from_file_location.return_value = mock_spec
        mock_spec.loader.exec_module.side_effect = ImportError("Simulação de falha na importação")
        
        # Reimportar o módulo com os mocks ativos
        if "src.intelligence.import_fix_memoria_temporal" in sys.modules:
            del sys.modules["src.intelligence.import_fix_memoria_temporal"]
        
        # Patch para evitar importações reais
        with patch.dict(sys.modules, {
            'src.core.memoria_temporal_v2': None,
            'core.memoria_temporal_v2': None,
            'src.core.memoria_temporal': None,
            'core.memoria_temporal': None
        }):
            with patch("importlib.import_module", side_effect=ImportError("Simulação de falha na importação")):
                from src.intelligence.import_fix_memoria_temporal import get_memoria_temporal_info, MemoriaTemporal
                
                info = get_memoria_temporal_info()
                self.assertEqual(info["version"], "stub")
                
                # Testar se o stub funciona
                memoria = MemoriaTemporal()
                self.assertEqual(memoria.ajustar_por_memoria("BTC", "12:00", 10), 10)
                
                logger.info(f"Fallback para stub verificado: {info}")

if __name__ == "__main__":
    unittest.main()
