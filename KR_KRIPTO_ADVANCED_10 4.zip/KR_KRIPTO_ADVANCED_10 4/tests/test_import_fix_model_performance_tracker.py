#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Testes unitários para o mecanismo de importação robusto do ModelPerformanceTracker.
Verifica a compatibilidade com ambientes Mac M1 (ARM64) e x86_64.
"""

import unittest
import sys
import os
import importlib
import logging
from unittest.mock import patch, MagicMock

# Configurar logging para testes
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("test_import_fix_model_performance_tracker")

# Adicionar diretório raiz ao path para importações
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class TestImportFixModelPerformanceTracker(unittest.TestCase):
    """Testes para o mecanismo de importação robusto do ModelPerformanceTracker."""
    
    def setUp(self):
        """Preparação para cada teste."""
        # Limpar cache de importação para garantir testes isolados
        if "src.intelligence.import_fix_model_performance_tracker" in sys.modules:
            del sys.modules["src.intelligence.import_fix_model_performance_tracker"]
        
        # Backup do sys.path original
        self.original_path = sys.path.copy()
    
    def tearDown(self):
        """Limpeza após cada teste."""
        # Restaurar sys.path original
        sys.path = self.original_path
    
    def test_import_success(self):
        """Testa se o módulo pode ser importado sem erros."""
        try:
            from src.intelligence.import_fix_model_performance_tracker import ModelPerformanceTracker, get_model_tracker_info
            info = get_model_tracker_info()
            logger.info(f"ModelPerformanceTracker info: {info}")
            self.assertTrue(True)  # Se chegou aqui, a importação foi bem-sucedida
        except Exception as e:
            self.fail(f"Falha ao importar import_fix_model_performance_tracker: {e}")
    
    @patch("src.intelligence.import_fix_model_performance_tracker.is_mac_m1")
    def test_mac_m1_detection(self, mock_is_mac_m1):
        """Testa a detecção de ambiente Mac M1."""
        # Simular ambiente Mac M1
        mock_is_mac_m1.return_value = True
        
        # Reimportar o módulo com o mock ativo
        if "src.intelligence.import_fix_model_performance_tracker" in sys.modules:
            del sys.modules["src.intelligence.import_fix_model_performance_tracker"]
        
        from src.intelligence.import_fix_model_performance_tracker import get_model_tracker_info
        info = get_model_tracker_info()
        
        self.assertTrue(info["is_mac_m1"])
        logger.info(f"Detecção de Mac M1: {info}")
    
    @patch("src.intelligence.import_fix_model_performance_tracker.is_mac_m1")
    def test_x86_detection(self, mock_is_mac_m1):
        """Testa a detecção de ambiente x86."""
        # Simular ambiente x86
        mock_is_mac_m1.return_value = False
        
        # Reimportar o módulo com o mock ativo
        if "src.intelligence.import_fix_model_performance_tracker" in sys.modules:
            del sys.modules["src.intelligence.import_fix_model_performance_tracker"]
        
        from src.intelligence.import_fix_model_performance_tracker import get_model_tracker_info
        info = get_model_tracker_info()
        
        self.assertFalse(info["is_mac_m1"])
        logger.info(f"Detecção de x86: {info}")
    
    def test_create_instance(self):
        """Testa a criação de uma instância de ModelPerformanceTracker."""
        from src.intelligence.import_fix_model_performance_tracker import create_model_tracker
        
        # Criar instância com configuração personalizada
        config = {"window_size": 200}
        tracker = create_model_tracker(config)
        
        self.assertIsNotNone(tracker)
        logger.info(f"Instância criada: {tracker}")
    
    def test_global_instance(self):
        """Testa a instância global de model_tracker."""
        from src.intelligence.import_fix_model_performance_tracker import model_tracker
        
        self.assertIsNotNone(model_tracker)
        logger.info(f"Instância global: {model_tracker}")
    
    def test_basic_functionality(self):
        """Testa funcionalidades básicas do ModelPerformanceTracker."""
        from src.intelligence.import_fix_model_performance_tracker import ModelPerformanceTracker
        
        tracker = ModelPerformanceTracker()
        
        # Registrar modelo
        tracker.register_model("model1", {"type": "test_model"})
        
        # Registrar predição
        tracker.record_prediction("model1", 0.8)
        
        # Atualizar desempenho
        tracker.update_performance("model1", 1.0)
        
        # Obter desempenho
        performance = tracker.get_performance("model1")
        self.assertIsNotNone(performance)
        
        # Obter melhor modelo
        best_model = tracker.get_best_model()
        
        logger.info(f"Funcionalidades básicas testadas: {performance}")
    
    @patch("importlib.util.spec_from_file_location")
    @patch("importlib.util.module_from_spec")
    @patch("os.path.exists")
    def test_fallback_to_stub(self, mock_exists, mock_module_from_spec, mock_spec_from_file_location):
        """Testa o fallback para stub quando nenhuma implementação real está disponível."""
        # Simular que nenhum arquivo existe
        mock_exists.return_value = False
        
        # Simular falha na importação
        mock_spec = MagicMock()
        mock_spec_from_file_location.return_value = mock_spec
        mock_spec.loader.exec_module.side_effect = ImportError("Simulação de falha na importação")
        
        # Reimportar o módulo com os mocks ativos
        if "src.intelligence.import_fix_model_performance_tracker" in sys.modules:
            del sys.modules["src.intelligence.import_fix_model_performance_tracker"]
        
        # Patch para evitar importações reais
        with patch.dict(sys.modules, {
            'src.intelligence.model_performance_tracker_v4': None,
            'src.intelligence.model_performance_tracker_v3': None,
            'src.intelligence.model_performance_tracker': None,
            'src.intelligence.model_performance_tracker_stub': None,
            'intelligence.model_performance_tracker_v4': None,
            'intelligence.model_performance_tracker_v3': None,
            'intelligence.model_performance_tracker': None,
            'intelligence.model_performance_tracker_stub': None
        }):
            with patch("importlib.import_module", side_effect=ImportError("Simulação de falha na importação")):
                from src.intelligence.import_fix_model_performance_tracker import get_model_tracker_info, ModelPerformanceTracker
                
                info = get_model_tracker_info()
                
                # Testar se o stub funciona
                tracker = ModelPerformanceTracker()
                best_model = tracker.get_best_model()
                
                logger.info(f"Fallback para stub verificado: {info}")

if __name__ == "__main__":
    unittest.main()
