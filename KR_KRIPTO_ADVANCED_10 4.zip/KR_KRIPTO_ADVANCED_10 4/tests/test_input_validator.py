# src/tests/unit/strategies/validators/test_input_validator.py

import pytest
import pandas as pd
import numpy as np
from src.strategies.validators.input_validator import validar_entrada_sinal

# Fixture para criar um DataFrame de exemplo
@pytest.fixture
def sample_dataframe():
    data = {
        "Timestamp": pd.to_datetime(["2023-01-01 00:00:00", "2023-01-01 00:01:00", "2023-01-01 00:02:00"] * 10), # Mais dados para cálculo de indicadores
        "Open": np.random.rand(30) * 100 + 20000,
        "High": np.random.rand(30) * 100 + 20100,
        "Low": np.random.rand(30) * 50 + 19950,
        "Close": np.random.rand(30) * 100 + 20000,
        "Volume": np.random.rand(30) * 10 + 1
    }
    df = pd.DataFrame(data)
    # Garantir que High >= Low, Open, Close e Low <= High, Open, Close
    df["High"] = df[["High", "Open", "Close"]].max(axis=1)
    df["Low"] = df[["Low", "Open", "Close"]].min(axis=1)
    return df

# Teste com DataFrame válido
def test_valid_dataframe(sample_dataframe):
    status, df_validated = validar_entrada_sinal(sample_dataframe, ativo="BTCUSDT") # Ajustado para tupla
    assert status is True
    assert df_validated is not None
    assert isinstance(df_validated, pd.DataFrame)
    # Verificar nomes minúsculos
    expected_cols_lower = ["open", "high", "low", "close", "volume"]
    assert all(col in df_validated.columns for col in expected_cols_lower)
    # Verificar indicadores (nomes podem variar ligeiramente com pandas-ta)
    assert any("atr" in col.lower() for col in df_validated.columns)
    assert any("adx" in col.lower() for col in df_validated.columns)
    assert any("bbl" in col.lower() for col in df_validated.columns) # Verifica uma das bandas
    assert any("rsi" in col.lower() for col in df_validated.columns)
    assert len(df_validated) == len(sample_dataframe)

# Teste com DataFrame None
def test_none_dataframe():
    status, df_validated = validar_entrada_sinal(None, ativo="BTCUSDT") # Ajustado para tupla
    assert status is False
    assert df_validated is None

# Teste com DataFrame vazio
def test_empty_dataframe():
    df_empty = pd.DataFrame()
    status, df_validated = validar_entrada_sinal(df_empty, ativo="BTCUSDT") # Ajustado para tupla
    assert status is False
    assert df_validated is None

# Teste com colunas OHLCV ausentes
def test_missing_ohlcv_columns(sample_dataframe):
    df_missing = sample_dataframe.drop(columns=["High"])
    status, df_validated = validar_entrada_sinal(df_missing, ativo="BTCUSDT") # Ajustado para tupla
    assert status is False
    assert df_validated is None

# Teste com colunas OHLCV com nomes diferentes
def test_different_case_columns():
    data = {
        "timestamp": pd.to_datetime(["2023-01-01 00:00:00"] * 30),
        "oPen": np.random.rand(30) * 100 + 20000,
        "HIGH": np.random.rand(30) * 100 + 20100,
        "low": np.random.rand(30) * 50 + 19950,
        "clOse": np.random.rand(30) * 100 + 20000,
        "VOLUME": np.random.rand(30) * 10 + 1
    }
    df = pd.DataFrame(data)
    df["HIGH"] = df[["HIGH", "oPen", "clOse"]].max(axis=1)
    df["low"] = df[["low", "oPen", "clOse"]].min(axis=1)
    
    status, df_validated = validar_entrada_sinal(df, ativo="BTCUSDT") # Ajustado para tupla
    assert status is True
    assert df_validated is not None
    expected_cols_lower = ["open", "high", "low", "close", "volume"]
    assert all(col in df_validated.columns for col in expected_cols_lower)
    assert any("atr" in col.lower() for col in df_validated.columns)
    assert any("adx" in col.lower() for col in df_validated.columns)
    assert any("rsi" in col.lower() for col in df_validated.columns)

# Teste com dados insuficientes para indicadores
def test_insufficient_data():
    data = {
        "Open": [20000, 20010],
        "High": [20050, 20060],
        "Low": [19990, 20000],
        "Close": [20020, 20030],
        "Volume": [10, 12]
    }
    df_short = pd.DataFrame(data)
    status, df_validated = validar_entrada_sinal(df_short, ativo="BTCUSDT") # Ajustado para tupla
    # A função deve retornar True, mas com indicadores NaN
    assert status is True 
    assert df_validated is not None
    # Verificar se as colunas base existem
    expected_cols_lower = ["open", "high", "low", "close", "volume"]
    assert all(col in df_validated.columns for col in expected_cols_lower)
    # Verificar se as colunas de indicadores foram adicionadas (mesmo que com NaN)
    assert any("atr" in col.lower() for col in df_validated.columns)
    assert any("adx" in col.lower() for col in df_validated.columns)
    assert any("bbl" in col.lower() for col in df_validated.columns)
    assert any("rsi" in col.lower() for col in df_validated.columns)
    # Verificar se os valores dos indicadores são NaN (ou quase todos)
    # CORRIGIDO MANUALMENTE REAL: Usar aspas simples (') em vez de aspas escapadas (\')
    assert df_validated[df_validated.filter(like='ATR').columns].isnull().all().all()
    assert df_validated[df_validated.filter(like='ADX').columns].isnull().all().all()
    assert df_validated[df_validated.filter(like='RSI').columns].isnull().all().all()


