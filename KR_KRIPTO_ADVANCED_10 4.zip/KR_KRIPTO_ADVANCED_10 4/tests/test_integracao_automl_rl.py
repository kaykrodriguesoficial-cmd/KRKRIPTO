"""
Testes de Integração - Testes para a integração entre AutoML e RL
=================================================================

Este módulo implementa testes de integração para validar a integração
entre os módulos AutoML e Reinforcement Learning.

Autor: Manus AI
Data: Maio 2025
Versão: 1.0.0
"""

import os
import sys
import unittest
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

# Adicionar diretório raiz ao path para importações relativas
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Definir mocks antes de importar os módulos reais
class MockAgenteRL:
    """Agente RL mock para testes."""
    
    def __init__(self, config=None):
        self.config = config or {}
        self.ativo = self.config.get('ativo', 'BTCUSDT')
        self.modelo_path = self.config.get('modelo_path', '')
        self.treinar_called = False
        self.prever_acao_called = False
        self.salvar_called = False
        self.carregar_called = False
        self.atualizar_called = False
    
    def treinar(self, ambiente, total_timesteps):
        self.treinar_called = True
        return {
            'retorno_total': 0.1,
            'sharpe': 0.5,
            'max_drawdown': 0.2,
            'num_operacoes': 10
        }
    
    def prever_acao(self, estado):
        self.prever_acao_called = True
        # Retornar ação aleatória (0: HOLD, 1: BUY, 2: SELL)
        return np.random.randint(0, 3)
    
    def salvar(self, path):
        self.salvar_called = True
        # Simular salvamento
        with open(path, 'w') as f:
            f.write('mock_model')
        return True
    
    def carregar(self, path):
        self.carregar_called = True
        return True
    
    def atualizar(self, estado, acao, recompensa, proximo_estado):
        self.atualizar_called = True
        return True
    
    def avaliar(self, ambiente, num_episodios):
        return {
            'retorno_total': 0.1,
            'sharpe': 0.5,
            'max_drawdown': 0.2,
            'num_operacoes': 10
        }

# Aplicar monkey patch antes de importar os módulos reais
import src.intelligence.reinforcement.agente_rl_avancado
src.intelligence.reinforcement.agente_rl_avancado.AgenteDQN = MockAgenteRL
src.intelligence.reinforcement.agente_rl_avancado.AgentePPO = MockAgenteRL
src.intelligence.reinforcement.agente_rl_avancado.RealAgenteRL = MockAgenteRL

# Importar módulos a serem testados
from src.intelligence.integracao_automl_rl import IntegracaoAutoMLRL
from src.intelligence.automl.adaptive_ensemble import AdaptiveEnsemble
from src.intelligence.automl.automl_prototype import AutoMLPrototype
from src.intelligence.reinforcement.ambiente_rl_avancado import AmbienteRLAvancado, RealAmbienteRL

# Importar mocks dos testes unitários
from tests.test_reinforcement_learning import MockOperador, MockMemoriaTemporal

class TestIntegracaoAutoMLRL(unittest.TestCase):
    """Testes para a classe IntegracaoAutoMLRL."""
    
    def setUp(self):
        """Configuração inicial para os testes."""
        # Criar diretório temporário para testes
        import tempfile
        self.temp_dir = tempfile.mkdtemp()
        
        # Criar mocks
        self.operador = MockOperador(posicao=0.0, saldo=1000.0, preco=50000.0)
        self.memoria_temporal = MockMemoriaTemporal()
        
        # Criar dataframe de teste
        dates = pd.date_range(start="2023-01-01", periods=100, freq="H")
        self.df = pd.DataFrame({
            "open": np.random.random(100) * 100,
            "high": np.random.random(100) * 100 + 10,
            "low": np.random.random(100) * 100 - 10,
            "close": np.random.random(100) * 100,
            "volume": np.random.random(100) * 1000,
            "rsi": np.random.random(100) * 100,
            "macd": np.random.random(100) * 10 - 5,
            "macd_signal": np.random.random(100) * 10 - 5,
            "macd_hist": np.random.random(100) * 10 - 5,
            "ema_9": np.random.random(100) * 100,
            "sma_20": np.random.random(100) * 100
        }, index=dates)
        
        # Criar dicionário de dataframes
        self.dataframes = {
            "BTCUSDT_1h": self.df
        }
        
        # Adicionar dataframes ao mock da memória temporal
        self.memoria_temporal.dataframes = self.dataframes
        
        # Criar configuração
        self.config = {
            "operador": self.operador,
            "memoria_temporal": self.memoria_temporal,
            "capital_inicial": 1000.0,
            "custo_transacao": 0.001,
            "automl": {
                "n_trials": 5,
                "window_size": 10,
                "adaptation_rate": 0.1,
                "min_weight": 0.1,
                "default_weight": 0.5
            }
        }
        
        # Criar integração
        self.integracao = IntegracaoAutoMLRL(self.config)
        
        # Substituir diretórios
        self.integracao.models_dir = os.path.join(self.temp_dir, "modelos")
        self.integracao.data_dir = os.path.join(self.temp_dir, "dados")
        os.makedirs(self.integracao.models_dir, exist_ok=True)
        os.makedirs(self.integracao.data_dir, exist_ok=True)
        
        # Configurar integração
        self.integracao.setup(self.dataframes)
    
    def tearDown(self):
        """Limpeza após os testes."""
        import shutil
        shutil.rmtree(self.temp_dir)
    
    def test_setup(self):
        """Testa a configuração da integração."""
        # Verificar se o AutoML foi configurado
        self.assertIsNotNone(self.integracao.automl)
        self.assertIsNotNone(self.integracao.automl.integration)
    
    def test_criar_ambiente_rl(self):
        """Testa a criação de um ambiente RL."""
        # Criar ambiente RL
        ambiente = self.integracao.criar_ambiente_rl("BTCUSDT", "1h")
        
        # Verificar resultado
        self.assertIsNotNone(ambiente)
        self.assertIsInstance(ambiente, AmbienteRLAvancado)
        self.assertEqual(ambiente.ativo, "BTCUSDT")
        self.assertEqual(ambiente.capital_inicial, 1000.0)
        self.assertEqual(ambiente.custo_transacao, 0.001)
        
        # Verificar se o ambiente foi armazenado
        self.assertIn(("BTCUSDT", "1h"), self.integracao.ambiente_rl)
        self.assertEqual(self.integracao.ambiente_rl[("BTCUSDT", "1h")], ambiente)
    
    def test_criar_agente_rl(self):
        """Testa a criação de um agente RL."""
        # Criar agente RL
        agente = self.integracao.criar_agente_rl("BTCUSDT", "1h", "dqn")
        
        # Verificar resultado
        self.assertIsNotNone(agente)
        self.assertIsInstance(agente, MockAgenteRL)
        self.assertEqual(agente.ativo, "BTCUSDT")
        
        # Verificar se o agente foi armazenado
        self.assertIn(("BTCUSDT", "1h"), self.integracao.agente_rl)
        self.assertEqual(self.integracao.agente_rl[("BTCUSDT", "1h")], agente)
    
    def test_treinar_agente_rl(self):
        """Testa o treinamento de um agente RL."""
        # Criar ambiente e agente RL
        self.integracao.criar_ambiente_rl("BTCUSDT", "1h")
        self.integracao.criar_agente_rl("BTCUSDT", "1h", "dqn")
        
        # Treinar agente
        metricas = self.integracao.treinar_agente_rl("BTCUSDT", "1h", 10000)
        
        # Verificar resultado
        self.assertIsNotNone(metricas)
        self.assertIn("retorno_total", metricas)
        self.assertIn("sharpe", metricas)
        self.assertIn("max_drawdown", metricas)
        self.assertIn("num_operacoes", metricas)
        
        # Verificar se o agente foi treinado
        agente = self.integracao.agente_rl[("BTCUSDT", "1h")]
        self.assertTrue(agente.treinar_called)
        self.assertTrue(agente.salvar_called)
        
        # Verificar se o modelo foi salvo
        modelo_path = os.path.join(self.integracao.models_dir, "rl_BTCUSDT_1h.zip")
        self.assertTrue(os.path.exists(modelo_path))
    
    def test_otimizar_hiperparametros_rl(self):
        """Testa a otimização de hiperparâmetros do agente RL."""
        # Criar ambiente RL
        self.integracao.criar_ambiente_rl("BTCUSDT", "1h")
        
        # Otimizar hiperparâmetros
        best_params = self.integracao.otimizar_hiperparametros_rl("BTCUSDT", "1h", 5)
        
        # Verificar resultado
        self.assertIsNotNone(best_params)
        
        # Verificar se o agente foi criado e armazenado
        self.assertIn(("BTCUSDT", "1h"), self.integracao.agente_rl)
        agente = self.integracao.agente_rl[("BTCUSDT", "1h")]
        self.assertIsNotNone(agente)
        
        # Verificar se o modelo foi salvo
        modelo_path = os.path.join(self.integracao.models_dir, "rl_BTCUSDT_1h_optimized.zip")
        self.assertTrue(os.path.exists(modelo_path))
    
    def test_criar_ambiente_real(self):
        """Testa a criação de um ambiente RL real."""
        # Criar ambiente real
        ambiente_real = self.integracao.criar_ambiente_real("BTCUSDT", "1h")
        
        # Verificar resultado
        self.assertIsNotNone(ambiente_real)
        self.assertIsInstance(ambiente_real, RealAmbienteRL)
        self.assertEqual(ambiente_real.ativo, "BTCUSDT")
        self.assertEqual(ambiente_real.timeframe, "1h")
        self.assertEqual(ambiente_real.operador, self.operador)
        self.assertEqual(ambiente_real.memoria_temporal, self.memoria_temporal)
        
        # Verificar se o ambiente foi armazenado
        self.assertIn(("BTCUSDT", "1h", "real"), self.integracao.ambiente_rl)
        self.assertEqual(self.integracao.ambiente_rl[("BTCUSDT", "1h", "real")], ambiente_real)
    
    def test_criar_agente_real(self):
        """Testa a criação de um agente RL real."""
        # Criar modelo mock
        modelo_path = os.path.join(self.integracao.models_dir, "rl_BTCUSDT_1h.zip")
        with open(modelo_path, 'w') as f:
            f.write('mock_model')
        
        # Criar agente real
        agente_real = self.integracao.criar_agente_real("BTCUSDT", "1h", modelo_path)
        
        # Verificar resultado
        self.assertIsNotNone(agente_real)
        self.assertIsInstance(agente_real, MockAgenteRL)
        self.assertEqual(agente_real.ativo, "BTCUSDT")
        self.assertTrue(agente_real.carregar_called)
        
        # Verificar se o agente foi armazenado
        self.assertIn(("BTCUSDT", "1h", "real"), self.integracao.agente_rl)
        self.assertEqual(self.integracao.agente_rl[("BTCUSDT", "1h", "real")], agente_real)
    
    def test_executar_ciclo_rl(self):
        """Testa a execução de um ciclo completo de RL em ambiente real."""
        # Criar ambiente e agente reais
        self.integracao.criar_ambiente_real("BTCUSDT", "1h")
        
        # Criar modelo mock
        modelo_path = os.path.join(self.integracao.models_dir, "rl_BTCUSDT_1h.zip")
        with open(modelo_path, 'w') as f:
            f.write('mock_model')
        
        self.integracao.criar_agente_real("BTCUSDT", "1h", modelo_path)
        
        # Executar ciclo RL
        resultado = self.integracao.executar_ciclo_rl("BTCUSDT", "1h")
        
        # Verificar resultado
        self.assertIsNotNone(resultado)
        self.assertIn("acao", resultado)
        self.assertIn("recompensa", resultado)
        self.assertIn("info", resultado)
        
        # Verificar se o agente foi atualizado
        agente_real = self.integracao.agente_rl[("BTCUSDT", "1h", "real")]
        self.assertTrue(agente_real.prever_acao_called)
        self.assertTrue(agente_real.atualizar_called)
    
    def test_prever_com_automl_rl(self):
        """Testa a previsão combinada de AutoML e RL."""
        # Criar ambiente e agente RL
        self.integracao.criar_ambiente_rl("BTCUSDT", "1h")
        self.integracao.criar_agente_rl("BTCUSDT", "1h", "dqn")
        
        # Criar modelos mock para o AutoML
        self.integracao.automl.models[("BTCUSDT", "1h", "transformer")] = {
            "model": MockModel(name="transformer", prediction_value=0.7),
            "params": {"n_layers": 2},
            "score": 0.8
        }
        
        # Fazer previsão combinada
        previsoes = self.integracao.prever_com_automl_rl("BTCUSDT", "1h", self.df.iloc[-1:])
        
        # Verificar resultado
        self.assertIsNotNone(previsoes)
        self.assertIn("automl", previsoes)
        self.assertIn("rl", previsoes)
        self.assertIn("combinada", previsoes)
        
        # Verificar se os modelos foram chamados
        agente = self.integracao.agente_rl[("BTCUSDT", "1h")]
        self.assertTrue(agente.prever_acao_called)
    
    def test_get_status(self):
        """Testa a obtenção do status da integração."""
        # Criar ambiente e agente RL
        self.integracao.criar_ambiente_rl("BTCUSDT", "1h")
        self.integracao.criar_agente_rl("BTCUSDT", "1h", "dqn")
        
        # Criar modelos mock para o AutoML
        self.integracao.automl.models[("BTCUSDT", "1h", "transformer")] = {
            "model": MockModel(name="transformer", prediction_value=0.7),
            "params": {"n_layers": 2},
            "score": 0.8
        }
        
        # Obter status
        status = self.integracao.get_status()
        
        # Verificar resultado
        self.assertIsNotNone(status)
        self.assertIn("automl", status)
        self.assertIn("rl", status)
        self.assertIn("disponivel", status["automl"])
        self.assertTrue(status["automl"]["disponivel"])
        self.assertIn("ambientes", status["rl"])
        self.assertIn("agentes", status["rl"])
        self.assertIn(("BTCUSDT", "1h", "simulacao"), status["rl"]["ambientes"])
        self.assertIn(("BTCUSDT", "1h", "simulacao"), status["rl"]["agentes"])


# Mock para testes
class MockModel:
    """Modelo mock para testes."""
    
    def __init__(self, name="mock_model", prediction_value=0.5, error_rate=0.0):
        self.name = name
        self.prediction_value = prediction_value
        self.error_rate = error_rate
        self.fit_called = False
        self.predict_called = False
        self.evaluate_called = False
        self.save_called = False
        self.load_called = False
    
    def fit(self, X, y):
        self.fit_called = True
        return self
    
    def predict(self, X):
        self.predict_called = True
        if np.random.random() < self.error_rate:
            raise Exception("Erro simulado na predição")
        
        if isinstance(X, np.ndarray):
            return np.ones(X.shape[0]) * self.prediction_value
        else:
            return self.prediction_value
    
    def evaluate(self, X, y):
        self.evaluate_called = True
        return 0.8  # Retorna um score fixo para testes
    
    def save(self, path):
        self.save_called = True
        return True
    
    @classmethod
    def load(cls, path):
        model = cls()
        model.load_called = True
        return model


if __name__ == "__main__":
    unittest.main()
