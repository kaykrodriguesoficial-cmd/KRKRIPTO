#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Testes de integração para os módulos críticos do projeto KR_KRIPTO_ADVANCED.
Valida a integração entre GerenciadorFallback, MemoriaTemporal e o sistema principal.
"""

import os
import sys
import unittest
import tempfile
import shutil
from datetime import datetime

# Adicionar diretório pai ao path para importar os módulos
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Importar os módulos a serem testados
from src.core.fallback import GerenciadorFallback
from src.core.memoria_temporal import MemoriaTemporal
from src.intelligence.import_fix_v2 import fix_imports

class TestIntegracaoModulos(unittest.TestCase):
    """Testes de integração para os módulos críticos."""
    
    def setUp(self):
        """Configuração inicial para cada teste."""
        # Criar diretório temporário para testes
        self.temp_dir = tempfile.mkdtemp()
        
        # Aplicar correções de importação
        fix_imports()
        
        # Configurações de teste
        self.config_fallback = {
            "max_falhas": 3,
            "janela_falhas": 60,
            "tempo_reset": 120,
        }
        
        self.config_memoria = {
            "diretorio_base": self.temp_dir,
            "arquivo_memoria": "memoria_teste.csv",
            "arquivo_log": "memoria_teste.log"
        }
        
        # Instanciar os módulos
        self.gerenciador_fallback = GerenciadorFallback(config=self.config_fallback)
        self.memoria_temporal = MemoriaTemporal(config=self.config_memoria)
    
    def tearDown(self):
        """Limpeza após cada teste."""
        # Remover diretório temporário
        shutil.rmtree(self.temp_dir)
    
    def test_integracao_basica(self):
        """Testar integração básica entre os módulos."""
        # Verificar que os módulos foram inicializados corretamente
        self.assertIsNotNone(self.gerenciador_fallback)
        self.assertIsNotNone(self.memoria_temporal)
        
        # Verificar que o GerenciadorFallback está operacional
        status = self.gerenciador_fallback.obter_status()
        self.assertEqual(status["status"], "OK")
        
        # Verificar que a MemoriaTemporal está operacional
        df = self.memoria_temporal.obter_memoria()
        self.assertIsNotNone(df)
    
    def test_fluxo_integrado(self):
        """Testar fluxo integrado entre os módulos."""
        # Simular um fluxo de operação integrado
        
        # 1. Registrar dados na memória temporal
        self.memoria_temporal.atualizar_memoria("BTC", "12:00", 0.75, True)
        
        # 2. Obter estatísticas da memória
        stats = self.memoria_temporal.obter_estatisticas("BTC")
        self.assertEqual(stats["total_registros"], 1)
        
        # 3. Usar estatísticas para ajustar score
        score_ajustado = self.memoria_temporal.ajustar_por_memoria("BTC", "12:00", 0.6)
        self.assertEqual(score_ajustado, 0.6 + 3)  # Bonificação por alta taxa de acerto
        
        # 4. Simular falha e verificar circuit breaker
        self.gerenciador_fallback.registrar_falha("processamento_score", Exception("Erro de teste"))
        self.assertFalse(self.gerenciador_fallback.verificar_circuit_breaker("processamento_score"))
        
        # 5. Simular múltiplas falhas para ativar circuit breaker
        self.gerenciador_fallback.registrar_falha("processamento_score", Exception("Erro de teste"))
        self.gerenciador_fallback.registrar_falha("processamento_score", Exception("Erro de teste"))
        self.assertTrue(self.gerenciador_fallback.verificar_circuit_breaker("processamento_score"))
        
        # 6. Verificar status degradado
        status = self.gerenciador_fallback.obter_status()
        self.assertEqual(status["status"], "DEGRADED")
    
    def test_compatibilidade_ambiente(self):
        """Testar compatibilidade com diferentes ambientes."""
        import platform
        
        # Detectar ambiente
        is_mac = platform.system() == "Darwin"
        is_arm = "arm" in platform.machine().lower()
        is_mac_m1 = is_mac and is_arm
        
        # Registrar informações do ambiente
        print(f"Sistema: {platform.system()}")
        print(f"Arquitetura: {platform.machine()}")
        print(f"Processador: {platform.processor()}")
        print(f"Mac M1 detectado: {is_mac_m1}")
        
        # Verificar que os módulos funcionam no ambiente atual
        self.assertIsNotNone(self.gerenciador_fallback)
        self.assertIsNotNone(self.memoria_temporal)
        
        # Testar operações básicas em cada módulo
        self.gerenciador_fallback.registrar_falha("teste_ambiente", Exception("Teste de ambiente"))
        self.memoria_temporal.atualizar_memoria("TESTE", "00:00", 0.5, True)
        
        # Se os testes chegaram até aqui sem erros, os módulos são compatíveis com o ambiente

if __name__ == "__main__":
    unittest.main()
