# /home/ubuntu/kripto_analysis/KR_KRIPTO_ADVANCED_REORGANIZED/tests/test_integration_data.py

import pandas as pd
import time

# --- Dados para Teste de Volume Spike ---

def create_volume_spike_df(window=5, spike_multiplier=5.0):
    """Cria um DataFrame com um pico de volume no último candle."""
    base_volume = 100
    normal_volumes = [base_volume + i * 10 for i in range(window)] # Volumes normais
    spike_volume = (sum(normal_volumes) / window) * spike_multiplier # Volume do spike
    volumes = normal_volumes + [spike_volume]
    
    count = len(volumes)
    closes = [10 + i * 0.1 for i in range(count)]
    highs = [c + 0.5 for c in closes]
    lows = [c - 0.5 for c in closes]
    opens = [c - 0.1 for c in closes]
    # --- CORRECTION: Change datetime unit from 'min' to 'm' --- 
    timestamps = pd.to_datetime(range(count), unit='m', origin='2023-01-01')
    # --- END CORRECTION ---
    # --- CORRECTION: Use capitalized column names ---
    df = pd.DataFrame({
        'Open': opens,
        'High': highs,
        'Low': lows,
        'Close': closes,
        'Volume': volumes
    }, index=timestamps)
    # --- END CORRECTION ---
    return df

# --- Dados para Teste de Spoofing ---

def create_spoofing_sequence(cancel_time_ms=200, spoof_qty=100.0, normal_qty=10.0, price="25000"):
    """Cria uma sequência de updates de book para simular spoofing."""
    ts = int(time.time() * 1000)
    
    # 1. Update normal inicial (para ter histórico)
    update1 = {"E": ts, "b": [[price, str(normal_qty)]], "a": [[str(float(price)+1), str(normal_qty)]]}
    
    # 2. Aparece ordem grande
    ts += 100
    update2 = {"E": ts, "b": [[price, str(spoof_qty)]], "a": [[str(float(price)+1), str(normal_qty)]]}
    
    # 3. Ordem grande desaparece rapidamente
    ts += cancel_time_ms # Dentro da janela de cancelamento
    update3 = {"E": ts, "b": [["24999", str(normal_qty)]], "a": [[str(float(price)+1), str(normal_qty)]]}
    
    return [update1, update2, update3]

# --- DataFrame Pós-Spoofing ---

def create_post_spoofing_df(num_candles=50):
    """Cria um DataFrame simples para usar após a confirmação de spoofing."""
    volumes = [100] * num_candles
    closes = [25000 + i * 0.1 for i in range(num_candles)]
    highs = [c + 0.5 for c in closes]
    lows = [c - 0.5 for c in closes]
    opens = [c - 0.1 for c in closes]
    # --- CORRECTION: Change datetime unit from 'min' to 'm' --- 
    timestamps = pd.to_datetime(range(num_candles), unit='m', origin='2023-01-02')
    # --- END CORRECTION ---
    
    # --- CORRECTION: Use capitalized column names ---
    df = pd.DataFrame({
        'Open': opens,
        'High': highs,
        'Low': lows,
        'Close': closes,
        'Volume': volumes
    }, index=timestamps)
    # --- END CORRECTION ---
    return df

# Exemplo de como usar (pode ser comentado ou removido)
if __name__ == "__main__":
    df_volume_spike = create_volume_spike_df()
    print("--- DataFrame Volume Spike ---")
    print(df_volume_spike)
    print("\n")

    spoofing_updates = create_spoofing_sequence()
    print("--- Sequência Spoofing Updates ---")
    for i, update in enumerate(spoofing_updates):
        print(f"Update {i+1}: {update}")
    print("\n")

    df_post_spoofing = create_post_spoofing_df()
    print("--- DataFrame Pós-Spoofing ---")
    print(df_post_spoofing.head())

