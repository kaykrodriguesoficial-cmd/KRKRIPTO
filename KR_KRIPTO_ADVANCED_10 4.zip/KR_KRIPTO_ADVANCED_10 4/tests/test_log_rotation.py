
import logging
from logging.handlers import TimedRotatingFileHandler
import time
import os
import tempfile


# Função auxiliar para criar e obter diretório de logs temporário
def get_temp_log_dir():
    temp_log_dir = os.path.join(tempfile.gettempdir(), 'kr_kripto_test_logs')
    os.makedirs(temp_log_dir, exist_ok=True)
    return temp_log_dir

log_file = os.path.join(get_temp_log_dir(), 'test_rotation_1747386998.log')
os.makedirs(os.path.dirname(log_file), exist_ok=True)

logger = logging.getLogger('test_rotation')
logger.setLevel(logging.INFO)

# Configurar handler com rotação a cada segundo para teste
handler = TimedRotatingFileHandler(
    filename=log_file,
    when='S',  # Segundos, para teste rápido
    interval=1,
    backupCount=5,
    encoding='utf-8'
)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

# Gerar logs por alguns segundos
for i in range(10):
    logger.info(f"Mensagem de teste {i+1}")
    time.sleep(1.1)  # Ligeiramente mais que 1 segundo para garantir rotação
    
print("Teste de rotação concluído")
    