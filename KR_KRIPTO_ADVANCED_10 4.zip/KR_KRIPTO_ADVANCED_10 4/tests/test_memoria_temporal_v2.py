#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Testes unitários para o módulo MemoriaTemporal.
"""

import os
import sys
import unittest
import tempfile
import shutil
import pandas as pd
from datetime import datetime

# Adicionar diretório pai ao path para importar o módulo
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Importar o módulo a ser testado
from src.core.memoria_temporal import MemoriaTemporal

class TestMemoriaTemporal(unittest.TestCase):
    """Testes para a MemoriaTemporal."""
    
    def setUp(self):
        """Configuração inicial para cada teste."""
        # Criar diretório temporário para testes
        self.temp_dir = tempfile.mkdtemp()
        
        # Configuração de teste
        self.config = {
            "diretorio_base": self.temp_dir,
            "arquivo_memoria": "memoria_teste.csv",
            "arquivo_log": "memoria_teste.log"
        }
        
        # Instanciar a memória temporal
        self.memoria = MemoriaTemporal(config=self.config)
    
    def tearDown(self):
        """Limpeza após cada teste."""
        # Remover diretório temporário
        shutil.rmtree(self.temp_dir)
    
    def test_inicializacao(self):
        """Testar inicialização da memória temporal."""
        self.assertIsNotNone(self.memoria)
        self.assertEqual(self.memoria.caminho_memoria, os.path.join(self.temp_dir, "memoria_teste.csv"))
        self.assertEqual(self.memoria.caminho_log, os.path.join(self.temp_dir, "logs", "memoria_teste.log"))
        self.assertTrue(os.path.exists(self.memoria.caminho_memoria))
    
    def test_resetar_memoria(self):
        """Testar reset da memória."""
        # Adicionar alguns dados
        self.memoria.atualizar_memoria("BTC", "12:00", 0.75, True)
        self.memoria.atualizar_memoria("ETH", "13:00", 0.65, False)
        
        # Verificar que os dados foram adicionados
        df = self.memoria.obter_memoria()
        self.assertEqual(len(df), 2)
        
        # Resetar memória para um ativo específico
        resultado = self.memoria.resetar_memoria("BTC")
        self.assertTrue(resultado)
        
        # Verificar que apenas o ativo especificado foi resetado
        df = self.memoria.obter_memoria()
        self.assertEqual(len(df), 1)
        self.assertEqual(df.iloc[0]["ativo"], "ETH")
        
        # Resetar toda a memória
        resultado = self.memoria.resetar_memoria()
        self.assertTrue(resultado)
        
        # Verificar que toda a memória foi resetada
        df = self.memoria.obter_memoria()
        self.assertEqual(len(df), 0)
    
    def test_atualizar_memoria(self):
        """Testar atualização da memória."""
        # Adicionar um novo registro
        resultado = self.memoria.atualizar_memoria("BTC", "12:00", 0.75, True)
        self.assertTrue(resultado)
        
        # Verificar que o registro foi adicionado
        df = self.memoria.obter_memoria()
        self.assertEqual(len(df), 1)
        self.assertEqual(df.iloc[0]["ativo"], "BTC")
        self.assertEqual(df.iloc[0]["hora"], "12:00")
        self.assertEqual(df.iloc[0]["score_medio"], 0.75)
        self.assertEqual(df.iloc[0]["acertos"], 1)
        self.assertEqual(df.iloc[0]["erros"], 0)
        self.assertEqual(df.iloc[0]["taxa_acerto"], 1.0)
        
        # Atualizar o mesmo registro
        resultado = self.memoria.atualizar_memoria("BTC", "12:00", 0.85, False)
        self.assertTrue(resultado)
        
        # Verificar que o registro foi atualizado
        df = self.memoria.obter_memoria()
        self.assertEqual(len(df), 1)
        self.assertEqual(df.iloc[0]["score_medio"], 0.8)  # Média de 0.75 e 0.85
        self.assertEqual(df.iloc[0]["acertos"], 1)
        self.assertEqual(df.iloc[0]["erros"], 1)
        self.assertEqual(df.iloc[0]["taxa_acerto"], 0.5)  # 1 acerto em 2 tentativas
    
    def test_ajustar_por_memoria(self):
        """Testar ajuste de score por memória."""
        # Adicionar registro com baixa taxa de acerto
        self.memoria.atualizar_memoria("BTC", "12:00", 0.3, False)
        self.memoria.atualizar_memoria("BTC", "12:00", 0.3, False)
        self.memoria.atualizar_memoria("BTC", "12:00", 0.3, False)
        self.memoria.atualizar_memoria("BTC", "12:00", 0.3, True)
        
        # Verificar penalização para hora com baixa taxa de acerto
        score_ajustado = self.memoria.ajustar_por_memoria("BTC", "12:00", 0.6)
        self.assertEqual(score_ajustado, 0.6 - 5)  # Penalização de 5 pontos
        
        # Adicionar registro com alta taxa de acerto
        self.memoria.atualizar_memoria("ETH", "13:00", 0.7, True)
        self.memoria.atualizar_memoria("ETH", "13:00", 0.7, True)
        self.memoria.atualizar_memoria("ETH", "13:00", 0.7, True)
        
        # Verificar bonificação para hora com alta taxa de acerto
        score_ajustado = self.memoria.ajustar_por_memoria("ETH", "13:00", 0.6)
        self.assertEqual(score_ajustado, 0.6 + 3)  # Bonificação de 3 pontos
        
        # Verificar que não há ajuste para hora sem histórico
        score_ajustado = self.memoria.ajustar_por_memoria("LTC", "14:00", 0.6)
        self.assertEqual(score_ajustado, 0.6)  # Sem ajuste
    
    def test_obter_memoria(self):
        """Testar obtenção da memória."""
        # Adicionar alguns dados
        self.memoria.atualizar_memoria("BTC", "12:00", 0.75, True)
        self.memoria.atualizar_memoria("ETH", "13:00", 0.65, False)
        
        # Obter toda a memória
        df = self.memoria.obter_memoria()
        self.assertEqual(len(df), 2)
        
        # Obter memória filtrada por ativo
        df = self.memoria.obter_memoria("BTC")
        self.assertEqual(len(df), 1)
        self.assertEqual(df.iloc[0]["ativo"], "BTC")
    
    def test_obter_estatisticas(self):
        """Testar obtenção de estatísticas."""
        # Adicionar alguns dados
        self.memoria.atualizar_memoria("BTC", "12:00", 0.75, True)
        self.memoria.atualizar_memoria("BTC", "13:00", 0.65, False)
        self.memoria.atualizar_memoria("ETH", "12:00", 0.85, True)
        
        # Obter estatísticas globais
        stats = self.memoria.obter_estatisticas()
        self.assertEqual(stats["total_registros"], 3)
        self.assertEqual(stats["total_acertos"], 2)
        self.assertEqual(stats["total_erros"], 1)
        
        # Obter estatísticas por ativo
        stats = self.memoria.obter_estatisticas("BTC")
        self.assertEqual(stats["total_registros"], 2)
        self.assertEqual(stats["total_acertos"], 1)
        self.assertEqual(stats["total_erros"], 1)
    
    def test_exportar_importar_memoria(self):
        """Testar exportação e importação da memória."""
        # Adicionar alguns dados
        self.memoria.atualizar_memoria("BTC", "12:00", 0.75, True)
        self.memoria.atualizar_memoria("ETH", "13:00", 0.65, False)
        
        # Exportar memória
        caminho_export = self.memoria.exportar_memoria(formato="csv")
        self.assertTrue(os.path.exists(caminho_export))
        
        # Resetar memória
        self.memoria.resetar_memoria()
        df = self.memoria.obter_memoria()
        self.assertEqual(len(df), 0)
        
        # Importar memória
        resultado = self.memoria.importar_memoria(caminho_export)
        self.assertTrue(resultado)
        
        # Verificar que os dados foram importados
        df = self.memoria.obter_memoria()
        self.assertEqual(len(df), 2)
        self.assertIn("BTC", df["ativo"].values)
        self.assertIn("ETH", df["ativo"].values)

if __name__ == "__main__":
    unittest.main()
