#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Testes unitários para o módulo memoria_temporal_v2.py.
Verifica a funcionalidade da MemoriaTemporal em ambiente Mac M1.
"""

import os
import sys
import unittest
import logging
import tempfile
import pandas as pd
from datetime import datetime
import platform
import shutil

# Configurar logging para testes
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("test_memoria_temporal_v2")

# Adicionar diretório raiz ao path para importações
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Importar o módulo a ser testado
try:
    from src.core.memoria_temporal import MemoriaTemporal
except ImportError:
    logger.error("Não foi possível importar MemoriaTemporal de src.core.memoria_temporal_v2")
    # Tentar importação alternativa
    try:
        from src.core.memoria_temporal import MemoriaTemporal
        logger.info("MemoriaTemporal importado de src.core.memoria_temporal")
    except ImportError:
        logger.error("Não foi possível importar MemoriaTemporal de src.core.memoria_temporal")
        raise

# Verificar se estamos em um Mac M1
def is_mac_m1():
    """Verifica se o ambiente atual é um Mac M1 (ARM64)."""
    return platform.system() == "Darwin" and ("arm" in platform.machine().lower())

class TestMemoriaTemporal(unittest.TestCase):
    """Testes para a MemoriaTemporal."""
    
    def setUp(self):
        """Configuração inicial para cada teste."""
        # Detectar ambiente
        self.is_mac_m1 = is_mac_m1()
        self.ambiente = "Mac M1" if self.is_mac_m1 else "Outro"
        logger.info(f"Executando testes em ambiente: {self.ambiente}")
        
        # Criar diretório temporário para testes
        self.temp_dir = tempfile.mkdtemp()
        
        # Criar configuração de teste
        self.config = {
            "diretorio_base": self.temp_dir,
            "arquivo_memoria": "memoria_teste.csv",
            "arquivo_log": "memoria_teste.log"
        }
        
        # Criar instância da memória temporal
        self.memoria = MemoriaTemporal(config=self.config)
    
    def test_inicializacao(self):
        """Testa a inicialização da memória temporal."""
        self.assertIsNotNone(self.memoria)
        self.assertEqual(self.memoria.diretorio_base, self.temp_dir)
        self.assertTrue(os.path.exists(self.memoria.caminho_memoria))
    
    def test_resetar_memoria(self):
        """Testa o reset da memória."""
        # Adicionar alguns dados
        self.memoria.atualizar_memoria("BTCUSDT", "12:00", 75.0, True)
        self.memoria.atualizar_memoria("ETHUSDT", "13:00", 65.0, False)
        
        # Verificar que os dados foram adicionados
        df = self.memoria.obter_memoria()
        self.assertEqual(len(df), 2)
        
        # Resetar memória para um ativo específico
        resultado = self.memoria.resetar_memoria("BTCUSDT")
        self.assertTrue(resultado)
        
        # Verificar que apenas o ativo especificado foi resetado
        df = self.memoria.obter_memoria()
        self.assertEqual(len(df), 1)
        self.assertEqual(df.iloc[0]["ativo"], "ETHUSDT")
        
        # Resetar toda a memória
        resultado = self.memoria.resetar_memoria()
        self.assertTrue(resultado)
        
        # Verificar que toda a memória foi resetada
        df = self.memoria.obter_memoria()
        self.assertEqual(len(df), 0)
    
    def test_atualizar_memoria(self):
        """Testa a atualização da memória."""
        # Adicionar um novo registro
        resultado = self.memoria.atualizar_memoria("BTCUSDT", "14:00", 80.0, True)
        self.assertTrue(resultado)
        
        # Verificar que o registro foi adicionado
        df = self.memoria.obter_memoria()
        self.assertEqual(len(df), 1)
        self.assertEqual(df.iloc[0]["ativo"], "BTCUSDT")
        self.assertEqual(df.iloc[0]["hora"], "14:00")
        self.assertEqual(df.iloc[0]["score_medio"], 80.0)
        self.assertEqual(df.iloc[0]["acertos"], 1)
        self.assertEqual(df.iloc[0]["erros"], 0)
        
        # Atualizar o mesmo registro
        resultado = self.memoria.atualizar_memoria("BTCUSDT", "14:00", 70.0, False)
        self.assertTrue(resultado)
        
        # Verificar que o registro foi atualizado
        df = self.memoria.obter_memoria()
        self.assertEqual(len(df), 1)
        self.assertEqual(df.iloc[0]["score_medio"], 75.0)  # Média de 80 e 70
        self.assertEqual(df.iloc[0]["acertos"], 1)
        self.assertEqual(df.iloc[0]["erros"], 1)
        self.assertEqual(df.iloc[0]["taxa_acerto"], 0.5)  # 1 acerto em 2 tentativas
    
    def test_ajustar_por_memoria(self):
        """Testa o ajuste de score por memória."""
        # Adicionar registros com diferentes taxas de acerto
        # Hora com alta taxa de acerto
        for _ in range(8):
            self.memoria.atualizar_memoria("BTCUSDT", "15:00", 80.0, True)
        for _ in range(2):
            self.memoria.atualizar_memoria("BTCUSDT", "15:00", 80.0, False)
        
        # Hora com baixa taxa de acerto
        for _ in range(2):
            self.memoria.atualizar_memoria("BTCUSDT", "16:00", 60.0, True)
        for _ in range(8):
            self.memoria.atualizar_memoria("BTCUSDT", "16:00", 60.0, False)
        
        # Testar ajuste para hora com alta taxa de acerto
        score_ajustado = self.memoria.ajustar_por_memoria("BTCUSDT", "15:00", 75.0)
        self.assertGreater(score_ajustado, 75.0)  # Deve ser bonificado
        
        # Testar ajuste para hora com baixa taxa de acerto
        score_ajustado = self.memoria.ajustar_por_memoria("BTCUSDT", "16:00", 75.0)
        self.assertLess(score_ajustado, 75.0)  # Deve ser penalizado
        
        # Testar ajuste para hora sem histórico
        score_ajustado = self.memoria.ajustar_por_memoria("BTCUSDT", "17:00", 75.0)
        self.assertEqual(score_ajustado, 75.0)  # Deve permanecer inalterado
    
    def test_obter_memoria(self):
        """Testa a obtenção da memória."""
        # Adicionar registros para diferentes ativos
        self.memoria.atualizar_memoria("BTCUSDT", "18:00", 85.0, True)
        self.memoria.atualizar_memoria("ETHUSDT", "18:00", 75.0, False)
        
        # Obter toda a memória
        df = self.memoria.obter_memoria()
        self.assertEqual(len(df), 2)
        
        # Obter memória para um ativo específico
        df = self.memoria.obter_memoria("BTCUSDT")
        self.assertEqual(len(df), 1)
        self.assertEqual(df.iloc[0]["ativo"], "BTCUSDT")
    
    def test_obter_estatisticas(self):
        """Testa a obtenção de estatísticas."""
        # Adicionar registros para diferentes ativos
        self.memoria.atualizar_memoria("BTCUSDT", "19:00", 90.0, True)
        self.memoria.atualizar_memoria("BTCUSDT", "20:00", 80.0, False)
        
        # Obter estatísticas
        estatisticas = self.memoria.obter_estatisticas("BTCUSDT")
        self.assertEqual(estatisticas["total_registros"], 2)
        self.assertEqual(estatisticas["total_acertos"], 1)
        self.assertEqual(estatisticas["total_erros"], 1)
        self.assertAlmostEqual(estatisticas["taxa_acerto_media"], 0.5)
        self.assertAlmostEqual(estatisticas["score_medio"], 85.0)
    
    def test_exportar_importar_memoria(self):
        """Testa a exportação e importação da memória."""
        # Adicionar alguns dados
        self.memoria.atualizar_memoria("BTCUSDT", "21:00", 95.0, True)
        self.memoria.atualizar_memoria("ETHUSDT", "21:00", 85.0, False)
        
        # Exportar memória
        caminho_exportado = self.memoria.exportar_memoria(formato="csv")
        self.assertTrue(os.path.exists(caminho_exportado))
        
        # Resetar memória
        self.memoria.resetar_memoria()
        df = self.memoria.obter_memoria()
        self.assertEqual(len(df), 0)
        
        # Importar memória
        resultado = self.memoria.importar_memoria(caminho_exportado)
        self.assertTrue(resultado)
        
        # Verificar que os dados foram importados
        df = self.memoria.obter_memoria()
        self.assertEqual(len(df), 2)
    
    def test_compatibilidade_mac_m1(self):
        """Testa a compatibilidade com Mac M1."""
        # Verificar detecção de ambiente
        ambiente_detectado = is_mac_m1()
        logger.info(f"Ambiente Mac M1 detectado: {ambiente_detectado}")
        
        # Verificar se a função is_mac_m1 está funcionando corretamente
        if platform.system() == "Darwin" and "arm" in platform.machine().lower():
            self.assertTrue(ambiente_detectado)
        
        # Verificar se a memória temporal funciona no ambiente atual
        self.assertIsNotNone(self.memoria)
        
        # Testar operações básicas
        self.memoria.atualizar_memoria("BTCUSDT", "22:00", 100.0, True)
        df = self.memoria.obter_memoria()
        self.assertEqual(len(df), 1)
    
    def tearDown(self):
        """Limpeza após cada teste."""
        # Remover diretório temporário
        shutil.rmtree(self.temp_dir)

if __name__ == "__main__":
    unittest.main()
