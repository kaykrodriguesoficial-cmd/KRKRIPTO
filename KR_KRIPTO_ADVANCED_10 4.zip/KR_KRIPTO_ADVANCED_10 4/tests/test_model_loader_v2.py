#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Testes unitários para o ModelLoader v2.
"""

import unittest
import sys
import os
import logging
import tempfile
import json

# Configurar logging para testes
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("test_model_loader")

# Adicionar diretório pai ao path para importação
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Importar o módulo a ser testado
try:
    from src.intelligence.model_loader_v2 import ModelLoader, ModelLoaderStub
except ImportError:
    logger.error("Não foi possível importar ModelLoader. Verificando caminhos...")
    logger.info(f"Diretório atual: {os.getcwd()}")
    logger.info(f"sys.path: {sys.path}")
    raise

class TestModelLoader(unittest.TestCase):
    """Testes para o ModelLoader."""
    
    def setUp(self):
        """Configuração inicial para cada teste."""
        self.config = {
            "default_model_path": tempfile.mkdtemp()  # Usar diretório temporário para testes
        }
        self.loader = ModelLoader(self.config)
        
        # Criar um modelo dummy para testes
        self.dummy_model_path = os.path.join(self.config["default_model_path"], "dummy_model.json")
        with open(self.dummy_model_path, 'w') as f:
            json.dump({"model_type": "dummy", "version": "1.0"}, f)
    
    def test_initialization(self):
        """Testa a inicialização do carregador."""
        self.assertEqual(self.loader.default_model_path, self.config["default_model_path"])
        self.assertEqual(len(self.loader.models), 0)
        self.assertEqual(len(self.loader.model_types), 0)
        self.assertEqual(len(self.loader.model_paths), 0)
    
    def test_check_dependencies(self):
        """Testa a verificação de dependências."""
        self.loader._check_dependencies()
        
        # Verificar se os atributos de disponibilidade foram definidos
        self.assertIn("has_keras", dir(self.loader))
        self.assertIn("has_sklearn", dir(self.loader))
        self.assertIn("has_torch", dir(self.loader))
    
    def test_load_model_nonexistent(self):
        """Testa o carregamento de um modelo inexistente."""
        result = self.loader.load_model("nonexistent", "/path/to/nonexistent/model.h5", "keras")
        self.assertFalse(result)
    
    def test_load_models_config(self):
        """Testa o carregamento de modelos a partir de configuração."""
        # Criar configuração de teste
        models_config = [
            {
                "id": "model1",
                "path": self.dummy_model_path,
                "type": "sklearn",
                "enabled": True
            },
            {
                "id": "model2",
                "path": "/path/to/nonexistent/model.h5",
                "type": "keras",
                "enabled": True
            },
            {
                "id": "model3",
                "path": "/path/to/disabled/model.pt",
                "type": "pytorch",
                "enabled": False
            }
        ]
        
        # Carregar modelos
        results = self.loader.load_models(models_config)
        
        # Verificar resultados
        self.assertIn("model1", results)
        self.assertIn("model2", results)
        self.assertIn("model3", results)
        
        # model1 pode falhar se sklearn não estiver disponível
        # model2 deve falhar porque o arquivo não existe
        self.assertFalse(results["model2"])
        # model3 deve falhar porque está desabilitado
        self.assertFalse(results["model3"])
    
    def test_get_model(self):
        """Testa a obtenção de um modelo carregado."""
        # Adicionar um modelo manualmente para teste
        dummy_model = {"type": "dummy"}
        self.loader.models["dummy"] = dummy_model
        self.loader.model_types["dummy"] = "json"
        self.loader.model_paths["dummy"] = self.dummy_model_path
        
        # Obter o modelo
        model = self.loader.get_model("dummy")
        self.assertEqual(model, dummy_model)
        
        # Tentar obter um modelo inexistente
        model = self.loader.get_model("nonexistent")
        self.assertIsNone(model)
    
    def test_predict(self):
        """Testa a realização de predições."""
        # Adicionar um modelo com método predict para teste
        class DummyModel:
            def predict(self, X):
                return [0.5] * len(X)
        
        dummy_model = DummyModel()
        self.loader.models["dummy"] = dummy_model
        self.loader.model_types["dummy"] = "sklearn"
        self.loader.model_paths["dummy"] = self.dummy_model_path
        
        # Realizar predição
        prediction = self.loader.predict("dummy", [1, 2, 3])
        self.assertEqual(prediction, [0.5, 0.5, 0.5])
        
        # Tentar predição com modelo inexistente
        prediction = self.loader.predict("nonexistent", [1, 2, 3])
        self.assertIsNone(prediction)
    
    def test_get_model_info(self):
        """Testa a obtenção de informações sobre um modelo."""
        # Adicionar um modelo manualmente para teste
        dummy_model = {"type": "dummy"}
        self.loader.models["dummy"] = dummy_model
        self.loader.model_types["dummy"] = "json"
        self.loader.model_paths["dummy"] = self.dummy_model_path
        
        # Obter informações
        info = self.loader.get_model_info("dummy")
        
        self.assertEqual(info["id"], "dummy")
        self.assertEqual(info["type"], "json")
        self.assertEqual(info["path"], self.dummy_model_path)
        self.assertTrue(info["loaded"])
        
        # Tentar obter informações de um modelo inexistente
        info = self.loader.get_model_info("nonexistent")
        self.assertIn("error", info)
    
    def test_get_all_models_info(self):
        """Testa a obtenção de informações sobre todos os modelos."""
        # Adicionar alguns modelos manualmente para teste
        self.loader.models["dummy1"] = {"type": "dummy1"}
        self.loader.model_types["dummy1"] = "json"
        self.loader.model_paths["dummy1"] = self.dummy_model_path
        
        self.loader.models["dummy2"] = {"type": "dummy2"}
        self.loader.model_types["dummy2"] = "json"
        self.loader.model_paths["dummy2"] = self.dummy_model_path
        
        # Obter informações de todos os modelos
        all_info = self.loader.get_all_models_info()
        
        self.assertEqual(len(all_info), 2)
        self.assertIn("dummy1", all_info)
        self.assertIn("dummy2", all_info)
        self.assertEqual(all_info["dummy1"]["type"], "json")
        self.assertEqual(all_info["dummy2"]["type"], "json")
    
    def test_unload_model(self):
        """Testa o descarregamento de um modelo."""
        # Adicionar um modelo manualmente para teste
        self.loader.models["dummy"] = {"type": "dummy"}
        self.loader.model_types["dummy"] = "json"
        self.loader.model_paths["dummy"] = self.dummy_model_path
        
        # Verificar que o modelo está carregado
        self.assertIn("dummy", self.loader.models)
        
        # Descarregar o modelo
        result = self.loader.unload_model("dummy")
        self.assertTrue(result)
        
        # Verificar que o modelo foi descarregado
        self.assertNotIn("dummy", self.loader.models)
        self.assertNotIn("dummy", self.loader.model_types)
        self.assertNotIn("dummy", self.loader.model_paths)
        
        # Tentar descarregar um modelo inexistente
        result = self.loader.unload_model("nonexistent")
        self.assertFalse(result)
    
    def test_unload_all_models(self):
        """Testa o descarregamento de todos os modelos."""
        # Adicionar alguns modelos manualmente para teste
        self.loader.models["dummy1"] = {"type": "dummy1"}
        self.loader.model_types["dummy1"] = "json"
        self.loader.model_paths["dummy1"] = self.dummy_model_path
        
        self.loader.models["dummy2"] = {"type": "dummy2"}
        self.loader.model_types["dummy2"] = "json"
        self.loader.model_paths["dummy2"] = self.dummy_model_path
        
        # Verificar que os modelos estão carregados
        self.assertEqual(len(self.loader.models), 2)
        
        # Descarregar todos os modelos
        result = self.loader.unload_all_models()
        self.assertTrue(result)
        
        # Verificar que todos os modelos foram descarregados
        self.assertEqual(len(self.loader.models), 0)
        self.assertEqual(len(self.loader.model_types), 0)
        self.assertEqual(len(self.loader.model_paths), 0)


class TestModelLoaderStub(unittest.TestCase):
    """Testes para o ModelLoaderStub."""
    
    def setUp(self):
        """Configuração inicial para cada teste."""
        self.config = {
            "default_model_path": tempfile.mkdtemp()  # Usar diretório temporário para testes
        }
        self.loader_stub = ModelLoaderStub(self.config)
    
    def test_initialization(self):
        """Testa a inicialização do stub."""
        # Verificar que o stub herda de ModelLoader
        self.assertIsInstance(self.loader_stub, ModelLoader)
        
        # Verificar que o modelo dummy foi criado
        self.assertIn("dummy_model", self.loader_stub.models)
    
    def test_dummy_model(self):
        """Testa o modelo dummy criado pelo stub."""
        # Obter o modelo dummy
        dummy_model = self.loader_stub.get_model("dummy_model")
        self.assertIsNotNone(dummy_model)
        
        # Verificar que o modelo tem um método predict
        self.assertTrue(hasattr(dummy_model, "predict") or callable(getattr(dummy_model, "predict", None)))


if __name__ == "__main__":
    unittest.main()
