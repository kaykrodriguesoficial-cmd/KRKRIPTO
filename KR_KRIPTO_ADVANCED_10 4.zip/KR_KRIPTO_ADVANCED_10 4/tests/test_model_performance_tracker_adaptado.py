#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Testes unitários adaptados para o ModelPerformanceTracker.

Este módulo contém testes para validar todas as funcionalidades do
ModelPerformanceTracker, adaptados para a estrutura atual da implementação.

Autor: Manus
Data: 27/05/2025
Versão: 3.1
"""

import os
import sys
import unittest
import logging
import platform
from datetime import datetime
from unittest.mock import MagicMock

# Configurar logging para testes
logging.basicConfig(level=logging.ERROR)

# Adicionar diretório raiz ao path para importações
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Tentar importar o corretor de importações
try:
    from src.intelligence.import_fix import fix_imports
    fix_imports()
except ImportError:
    print("Aviso: Não foi possível carregar o corretor de importações.")

# Importar o ModelPerformanceTracker e a função is_mac_m1
try:
    from src.intelligence.model_performance_tracker import ModelPerformanceTracker, is_mac_m1
except ImportError as e:
    print(f"Erro ao importar ModelPerformanceTracker: {e}")
    sys.exit(1)

class TestModelPerformanceTrackerAdaptado(unittest.TestCase):
    """Testes adaptados para o ModelPerformanceTracker."""
    
    def setUp(self):
        """Configuração inicial para cada teste."""
        # Configuração de teste
        self.test_config = {
            "window_size": 10,
            "min_samples": 5,
            "save_history": False
        }
        
        # Criar instância do tracker
        self.tracker = ModelPerformanceTracker(config=self.test_config)
        
        # Criar modelo mock para testes
        self.mock_model = MagicMock()
        self.mock_model.predict = MagicMock(return_value=[1])
        
        # Registrar modelo mock
        self.tracker.register_model("test_model", self.mock_model)
        
        # Imprimir informações do ambiente para debug
        print(f"Executando testes em: {platform.system()} {platform.machine()}")
        print(f"Mac M1 detectado: {is_mac_m1()}")
    
    def test_initialization(self):
        """Testa a inicialização do tracker."""
        # Verificar se o tracker foi inicializado corretamente
        self.assertIsInstance(self.tracker, ModelPerformanceTracker)
        self.assertEqual(self.tracker.window_size, 10)
        self.assertIn("test_model", self.tracker.models)
        
        # Verificar se o ambiente foi detectado corretamente
        self.assertIn("mac_m1", self.tracker.environment)
        self.assertEqual(self.tracker.environment["mac_m1"], is_mac_m1())
    
    def test_register_model(self):
        """Testa o registro de modelos."""
        # Registrar novo modelo
        result = self.tracker.register_model("new_model", MagicMock())
        
        # Verificar resultado
        self.assertTrue(result)
        self.assertIn("new_model", self.tracker.models)
        self.assertIn("new_model", self.tracker.performance_history)
        self.assertIn("new_model", self.tracker.metrics_cache)
    
    def test_record_prediction(self):
        """Testa o registro de predições."""
        # Limpar dados anteriores
        self.tracker.performance_history["test_model"] = []
        
        # Registrar predição
        result = self.tracker.record_prediction("test_model", 1)
        
        # Verificar resultado
        self.assertTrue(result)
        self.assertEqual(len(self.tracker.performance_history["test_model"]), 1)
        self.assertEqual(self.tracker.performance_history["test_model"][0]["prediction"], 1)
        
        # Registrar predição com valor real
        result = self.tracker.record_prediction("test_model", 0, actual=1)
        
        # Verificar resultado
        self.assertTrue(result)
        self.assertEqual(len(self.tracker.performance_history["test_model"]), 2)
        
        # Testar modelo inexistente
        result = self.tracker.record_prediction("nonexistent_model", 1)
        self.assertFalse(result)
    
    def test_update_performance(self):
        """Testa a atualização de desempenho."""
        # Limpar dados anteriores
        self.tracker.performance_history["test_model"] = []
        
        # Registrar predições sem valores reais
        for i in range(5):
            self.tracker.record_prediction("test_model", i % 2)
        
        # Atualizar desempenho
        result = self.tracker.update_performance("test_model", 1)
        
        # Verificar resultado
        self.assertTrue(result)
        
        # Verificar que pelo menos um registro tem valor real
        has_actual = False
        for record in self.tracker.performance_history["test_model"]:
            if record["actual"] is not None:
                has_actual = True
                break
        self.assertTrue(has_actual)
        
        # Testar modelo inexistente
        result = self.tracker.update_performance("nonexistent_model", 1)
        self.assertFalse(result)
    
    def test_get_performance(self):
        """Testa a obtenção de desempenho."""
        # Limpar dados anteriores
        self.tracker.performance_history["test_model"] = []
        
        # Registrar predições com valores reais
        for i in range(5):
            self.tracker.record_prediction("test_model", i % 2, actual=i % 2)
        
        # Obter desempenho
        performance = self.tracker.get_performance("test_model")
        
        # Verificar resultado
        self.assertIsNotNone(performance)
        self.assertIn("sample_count", performance)
        
        # Testar modelo inexistente
        performance = self.tracker.get_performance("nonexistent_model")
        self.assertIsNone(performance)
    
    def test_get_best_model(self):
        """Testa a seleção do melhor modelo."""
        # Registrar segundo modelo
        self.tracker.register_model("better_model", MagicMock())
        
        # Forçar métricas para teste determinístico
        self.tracker.metrics_cache["test_model"] = {
            "accuracy": 0.6,
            "precision": 0.6,
            "recall": 0.6,
            "f1_score": 0.6,
            "sample_count": 10  # Garantir que atende ao min_samples
        }
        
        self.tracker.metrics_cache["better_model"] = {
            "accuracy": 0.8,
            "precision": 0.8,
            "recall": 0.8,
            "f1_score": 0.8,
            "sample_count": 10  # Garantir que atende ao min_samples
        }
        
        # Obter melhor modelo
        best_model = self.tracker.get_best_model(metric="accuracy", min_samples=10)
        
        # Verificar resultado
        self.assertEqual(best_model, "better_model")
        
        # Testar com min_samples maior
        best_model = self.tracker.get_best_model(min_samples=20)
        self.assertIsNone(best_model)
    
    def test_get_all_models_performance(self):
        """Testa a obtenção de desempenho de todos os modelos."""
        # Registrar segundo modelo
        self.tracker.register_model("second_model", MagicMock())
        
        # Limpar dados anteriores
        self.tracker.performance_history["test_model"] = []
        
        # Registrar predições com valores reais
        for i in range(5):
            self.tracker.record_prediction("test_model", i % 2, actual=i % 2)
        
        # Obter desempenho de todos os modelos
        all_performance = self.tracker.get_all_models_performance()
        
        # Verificar resultado
        self.assertIsInstance(all_performance, dict)
        self.assertIn("test_model", all_performance)
        self.assertIn("second_model", all_performance)
    
    def test_reset(self):
        """Testa o reset do tracker."""
        # Limpar dados anteriores
        self.tracker.performance_history["test_model"] = []
        
        # Registrar predições com valores reais
        for i in range(5):
            self.tracker.record_prediction("test_model", i % 2, actual=i % 2)
        
        # Verificar que temos dados
        self.assertGreater(len(self.tracker.performance_history["test_model"]), 0)
        
        # Reset
        result = self.tracker.reset()
        
        # Verificar resultado
        self.assertTrue(result)
        self.assertEqual(len(self.tracker.performance_history["test_model"]), 0)
    
    def test_mac_m1_detection(self):
        """Testa a detecção de ambiente Mac M1."""
        # Verificar se a função is_mac_m1 está disponível
        self.assertIsNotNone(is_mac_m1)
        
        # Verificar se o resultado é um booleano
        self.assertIsInstance(is_mac_m1(), bool)
        
        # Verificar se o ambiente foi detectado corretamente no tracker
        self.assertIn("mac_m1", self.tracker.environment)
        self.assertEqual(self.tracker.environment["mac_m1"], is_mac_m1())
        
        # Verificar se a detecção é consistente com o sistema atual
        if platform.system() == "Darwin" and "arm" in platform.machine().lower():
            self.assertTrue(is_mac_m1())
        
        print(f"Ambiente: {self.tracker.environment}")

if __name__ == '__main__':
    unittest.main()
