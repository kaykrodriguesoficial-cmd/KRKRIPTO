"""
Testes de integração para validar a resiliência de rede em ambiente controlado.
Este script simula falhas de rede e valida o comportamento de reconexão.
"""

import asyncio
import os
import sys
import time
import logging
import json
import aiohttp
from datetime import datetime
from logging.handlers import TimedRotatingFileHandler


# Adicionar diretório raiz ao path para importações relativas
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Configurar logging
log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'logs')
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, 'network_resilience_integration_test.log')

# Configurar logger com rotação diária
logger = logging.getLogger("network_resilience_test")
if not logger.handlers:
    handler = TimedRotatingFileHandler(
        filename=log_file,
        when='midnight',
        interval=1,
        backupCount=30,
        encoding='utf-8'
    )
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    
    # Adicionar handler para console também
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    logger.setLevel(logging.INFO)

# Importar módulos necessários
try:
    from src.core.binance_stream_resilient import conectar_binance_resiliente, ConnectionStats
    from src.core.network_resilience import NetworkResilience, NetworkFailureType
except ImportError as e:
    logger.error(f"Erro ao importar módulos: {e}")
    raise ImportError(f"Erro ao importar módulos: {e}")

class NetworkResilienceIntegrationTest:
    """Classe para testes de integração de resiliência de rede."""
    
    def __init__(self):
        """Inicializa o teste de integração."""
        self.test_results = {
            "start_time": datetime.now().isoformat(),
            "tests": [],
            "overall_status": "pending"
        }
        self.context = {
            "websocket_connections": {},
            "reconnect_tasks": {},
            "heartbeat_tasks": {},
            "dataframes": {},
            "last_kline_time": {},
            "dataframes_lock": asyncio.Lock(),
            "processadores_book": {},
            "memoria_temporal": {},
            "configuracao_global": {
                "testnet": True,
                "websocket": {
                    "max_reconnect_attempts": 5,
                    "base_delay": 1.0,
                    "max_delay": 10.0,
                    "jitter": 0.1,
                    "timeout": 5.0
                }
            },
            "gerenciador_fallback": None,
            "analisar_sinal_func": self.mock_analisar_sinal,
            "governor": None,
            "tracker": None,
            "context_switcher": None,
            "strategy_config": None,
            "attack_detector": None
        }
    
    async def mock_analisar_sinal(self, **kwargs):
        """Mock para a função analisar_sinal."""
        logger.info(f"Mock analisar_sinal chamado com ativo={kwargs.get('ativo')}")
        await asyncio.sleep(0.1)
        return {"status": "success", "signal": None}
    
    async def test_normal_connection(self):
        """Testa conexão normal sem falhas."""
        test_name = "test_normal_connection"
        logger.info(f"Iniciando teste: {test_name}")
        
        try:
            # Configurar ambiente para simulação E2E LOAD
            os.environ["E2E_MOCK_WS_MODE"] = "LOAD"
            
            # Iniciar conexão em background
            ativo = "BTCUSDT"
            task = asyncio.create_task(
                conectar_binance_resiliente(ativo, self.context, "master")
            )
            
            # Aguardar um tempo para processamento
            await asyncio.sleep(3)
            
            # Verificar estatísticas
            if ativo in self.context["dataframes"]:
                df_size = len(self.context["dataframes"][ativo])
                logger.info(f"DataFrame para {ativo} tem {df_size} candles")
                
                self.test_results["tests"].append({
                    "name": test_name,
                    "status": "success",
                    "details": f"Conexão normal estabelecida, DataFrame tem {df_size} candles"
                })
            else:
                logger.warning(f"DataFrame para {ativo} não foi criado")
                self.test_results["tests"].append({
                    "name": test_name,
                    "status": "warning",
                    "details": "DataFrame não foi criado, possível falha na conexão"
                })
            
            # Cancelar tarefa
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            
        except Exception as e:
            logger.error(f"Erro no teste {test_name}: {e}", exc_info=True)
            self.test_results["tests"].append({
                "name": test_name,
                "status": "error",
                "details": str(e)
            })
        finally:
            # Limpar ambiente
            os.environ.pop("E2E_MOCK_WS_MODE", None)
            logger.info(f"Teste finalizado: {test_name}")
    
    async def test_connection_failure(self):
        """Testa comportamento durante falha de conexão."""
        test_name = "test_connection_failure"
        logger.info(f"Iniciando teste: {test_name}")
        
        try:
            # Configurar ambiente para simulação E2E FAILURE
            os.environ["E2E_MOCK_WS_MODE"] = "FAILURE"
            
            # Iniciar conexão em background
            ativo = "BTCUSDT"
            task = asyncio.create_task(
                conectar_binance_resiliente(ativo, self.context, "master")
            )
            
            # Aguardar um tempo para processamento
            await asyncio.sleep(5)
            
            # Verificar tentativas de reconexão
            from src.core.binance_stream_resilient import connection_stats
            
            if ativo in connection_stats:
                reconexoes = connection_stats[ativo].reconexoes
                falhas = connection_stats[ativo].falhas_consecutivas
                logger.info(f"Estatísticas para {ativo}: reconexões={reconexoes}, falhas={falhas}")
                
                if reconexoes > 0:
                    self.test_results["tests"].append({
                        "name": test_name,
                        "status": "success",
                        "details": f"Reconexão ativada após falha: {reconexoes} tentativas, {falhas} falhas consecutivas"
                    })
                else:
                    logger.warning(f"Nenhuma reconexão detectada para {ativo}")
                    self.test_results["tests"].append({
                        "name": test_name,
                        "status": "warning",
                        "details": "Nenhuma reconexão detectada, possível falha no mecanismo"
                    })
            else:
                logger.warning(f"Estatísticas para {ativo} não foram criadas")
                self.test_results["tests"].append({
                    "name": test_name,
                    "status": "warning",
                    "details": "Estatísticas não foram criadas, possível falha no mecanismo"
                })
            
            # Cancelar tarefa
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            
        except Exception as e:
            logger.error(f"Erro no teste {test_name}: {e}", exc_info=True)
            self.test_results["tests"].append({
                "name": test_name,
                "status": "error",
                "details": str(e)
            })
        finally:
            # Limpar ambiente
            os.environ.pop("E2E_MOCK_WS_MODE", None)
            logger.info(f"Teste finalizado: {test_name}")
    
    async def test_circuit_breaker(self):
        """Testa ativação do circuit breaker após múltiplas falhas."""
        test_name = "test_circuit_breaker"
        logger.info(f"Iniciando teste: {test_name}")
        
        try:
            # Criar instância de ConnectionStats
            ativo = "ETHUSDT"
            from src.core.binance_stream_resilient import connection_stats
            
            if ativo not in connection_stats:
                connection_stats[ativo] = ConnectionStats(config={})
            
            # Simular múltiplas falhas para ativar circuit breaker
            for _ in range(5):
                connection_stats[ativo].registrar_falha(NetworkFailureType.CONNECTION_REFUSED)
            
            # Verificar se circuit breaker foi ativado
            if connection_stats[ativo].circuit_breaker_ativo:
                logger.info(f"Circuit breaker ativado para {ativo} após {connection_stats[ativo].falhas_consecutivas} falhas")
                self.test_results["tests"].append({
                    "name": test_name,
                    "status": "success",
                    "details": f"Circuit breaker ativado após {connection_stats[ativo].falhas_consecutivas} falhas"
                })
            else:
                logger.warning(f"Circuit breaker não foi ativado para {ativo}")
                self.test_results["tests"].append({
                    "name": test_name,
                    "status": "warning",
                    "details": "Circuit breaker não foi ativado, possível falha no mecanismo"
                })
            
            # Verificar expiração do circuit breaker
            await asyncio.sleep(1)
            if not connection_stats[ativo].verificar_circuit_breaker():
                logger.info(f"Circuit breaker expirou para {ativo}")
                self.test_results["tests"].append({
                    "name": test_name + "_expiration",
                    "status": "success",
                    "details": "Circuit breaker expirou corretamente"
                })
            else:
                logger.warning(f"Circuit breaker não expirou para {ativo}")
                self.test_results["tests"].append({
                    "name": test_name + "_expiration",
                    "status": "warning",
                    "details": "Circuit breaker não expirou, possível falha no mecanismo"
                })
            
        except Exception as e:
            logger.error(f"Erro no teste {test_name}: {e}", exc_info=True)
            self.test_results["tests"].append({
                "name": test_name,
                "status": "error",
                "details": str(e)
            })
        finally:
            logger.info(f"Teste finalizado: {test_name}")
    
    async def test_network_resilience_retry(self):
        """Testa o mecanismo de retry do NetworkResilience."""
        test_name = "test_network_resilience_retry"
        logger.info(f"Iniciando teste: {test_name}")
        
        try:
            # Criar instância de NetworkResilience
            resilience = NetworkResilience(
                max_retries=3,
                base_delay=0.1,
                max_delay=1.0,
                jitter=0.1,
                timeout=1.0
            )
            
            # Contador para tentativas
            attempt_count = 0
            
            # Função que falha nas primeiras tentativas
            async def operation_with_failures():
                nonlocal attempt_count
                attempt_count += 1
                
                if attempt_count < 3:
                    logger.info(f"Simulando falha na tentativa {attempt_count}")
                    raise aiohttp.ClientConnectorError(None, OSError("Conexão recusada"))
                
                logger.info(f"Sucesso na tentativa {attempt_count}")
                return "success"
            
            # Executar operação com retry
            result = await resilience.execute_with_retry(
                operation=operation_with_failures,
                operation_name="test_operation"
            )
            
            if result == "success" and attempt_count == 3:
                logger.info(f"Retry funcionou corretamente: sucesso após {attempt_count} tentativas")
                self.test_results["tests"].append({
                    "name": test_name,
                    "status": "success",
                    "details": f"Retry funcionou corretamente: sucesso após {attempt_count} tentativas"
                })
            else:
                logger.warning(f"Retry não funcionou como esperado: result={result}, attempts={attempt_count}")
                self.test_results["tests"].append({
                    "name": test_name,
                    "status": "warning",
                    "details": f"Retry não funcionou como esperado: result={result}, attempts={attempt_count}"
                })
            
        except Exception as e:
            logger.error(f"Erro no teste {test_name}: {e}", exc_info=True)
            self.test_results["tests"].append({
                "name": test_name,
                "status": "error",
                "details": str(e)
            })
        finally:
            logger.info(f"Teste finalizado: {test_name}")
    
    async def run_all_tests(self):
        """Executa todos os testes de integração."""
        logger.info("Iniciando bateria de testes de integração")
        
        start_time = time.time()
        
        try:
            # Executar testes
            await self.test_normal_connection()
            await self.test_connection_failure()
            await self.test_circuit_breaker()
            await self.test_network_resilience_retry()
            
            # Calcular resultado geral
            success_count = sum(1 for test in self.test_results["tests"] if test["status"] == "success")
            warning_count = sum(1 for test in self.test_results["tests"] if test["status"] == "warning")
            error_count = sum(1 for test in self.test_results["tests"] if test["status"] == "error")
            
            if error_count > 0:
                self.test_results["overall_status"] = "error"
            elif warning_count > 0:
                self.test_results["overall_status"] = "warning"
            else:
                self.test_results["overall_status"] = "success"
            
            self.test_results["end_time"] = datetime.now().isoformat()
            self.test_results["duration_seconds"] = time.time() - start_time
            self.test_results["summary"] = {
                "total": len(self.test_results["tests"]),
                "success": success_count,
                "warning": warning_count,
                "error": error_count
            }
            
            # Salvar resultados
            results_file = os.path.join(log_dir, 'network_resilience_test_results.json')
            with open(results_file, 'w') as f:
                json.dump(self.test_results, f, indent=2)
            
            logger.info(f"Testes concluídos. Resultados salvos em {results_file}")
            logger.info(f"Resumo: {success_count} sucessos, {warning_count} avisos, {error_count} erros")
            
            return self.test_results
            
        except Exception as e:
            logger.error(f"Erro ao executar testes: {e}", exc_info=True)
            self.test_results["overall_status"] = "error"
            self.test_results["error"] = str(e)
            return self.test_results

async def main():
    """Função principal para execução dos testes."""
    test_runner = NetworkResilienceIntegrationTest()
    results = await test_runner.run_all_tests()
    
    # Exibir resumo
    print("\n" + "="*50)
    print(f"RESUMO DOS TESTES DE INTEGRAÇÃO DE RESILIÊNCIA DE REDE")
    print("="*50)
    print(f"Status geral: {results['overall_status'].upper()}")
    print(f"Total de testes: {results['summary']['total']}")
    print(f"Sucessos: {results['summary']['success']}")
    print(f"Avisos: {results['summary']['warning']}")
    print(f"Erros: {results['summary']['error']}")
    print(f"Duração: {results['duration_seconds']:.2f} segundos")
    print("="*50)
    
    # Exibir detalhes de cada teste
    print("\nDETALHES DOS TESTES:")
    for i, test in enumerate(results['tests']):
        print(f"{i+1}. {test['name']}: {test['status'].upper()}")
        print(f"   {test['details']}")
    
    print("\n" + "="*50)
    
    # Retornar código de saída baseado no resultado
    if results['overall_status'] == 'error':
        return 1
    return 0

if __name__ == "__main__":
    asyncio.run(main())
