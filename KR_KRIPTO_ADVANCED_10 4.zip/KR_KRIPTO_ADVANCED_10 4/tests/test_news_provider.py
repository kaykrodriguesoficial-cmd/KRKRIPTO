# src/tests/data_providers/test_news_provider.py

import pytest
import asyncio
from aioresponses import aioresponses
import logging

# Import the class to be tested
from src.data_providers.news_provider import NewsProvider

# Mock API token (replace with a real one if needed for specific tests, but usually mocked)
TEST_API_TOKEN = "mock_api_token"

@pytest.fixture
def news_provider():
    """Fixture to create a NewsProvider instance for testing."""
    test_config = {"cryptopanic_api_token": TEST_API_TOKEN}
    return NewsProvider(config=test_config)

@pytest.mark.asyncio
async def test_get_recent_news_score_positive(news_provider, caplog):
    """Test getting a positive news score based on mock API data."""
    asset_symbol = "BTC"
    mock_url = f"https://cryptopanic.com/api/v1/posts/?auth_token={TEST_API_TOKEN}&currencies={asset_symbol}&kind=news&public=true"
    
    mock_response = {
        "count": 2,
        "results": [
            {
                "kind": "news",
                "domain": "cointelegraph.com",
                "title": "Bitcoin price surges past $70,000",
                "published_at": "2024-05-01T12:00:00Z",
                "slug": "bitcoin-price-surges-past-70000",
                "currencies": [{"code": "BTC", "title": "Bitcoin", "slug": "bitcoin"}],
                "id": 12345,
                "url": "https://cointelegraph.com/news/bitcoin-price-surges-past-70000",
                "created_at": "2024-05-01T12:01:00Z",
                "votes": {"negative": 10, "positive": 100, "important": 5, "saved": 2, "comments": 15}
            },
            {
                "kind": "news",
                "domain": "coindesk.com",
                "title": "Institutional adoption drives Bitcoin higher",
                "published_at": "2024-05-01T11:00:00Z",
                "slug": "institutional-adoption-drives-bitcoin-higher",
                "currencies": [{"code": "BTC", "title": "Bitcoin", "slug": "bitcoin"}],
                "id": 12346,
                "url": "https://coindesk.com/news/institutional-adoption-drives-bitcoin-higher",
                "created_at": "2024-05-01T11:01:00Z",
                "votes": {"negative": 5, "positive": 80, "important": 10, "saved": 1, "comments": 8}
            }
        ]
    }

    with aioresponses() as m:
        caplog.set_level(logging.INFO) # Set log level for this test
        m.get(mock_url, payload=mock_response, status=200)
        score = await news_provider.get_recent_news_score(asset_symbol)

    # Expected score calculation: (100 + 80) / (100 + 80 + 10 + 5) = 180 / 195 = ~0.923
    # Scaled to 0-1 range: (0.923 * 2) - 1 = ~0.846. Let's use approx
    assert score == pytest.approx(0.846, abs=0.01)
    assert f"[NewsProvider] Score calculado para {asset_symbol}" in caplog.text # Check log message

@pytest.mark.asyncio
async def test_get_recent_news_score_negative(news_provider):
    """Test getting a negative news score based on mock API data."""
    asset_symbol = "ETH"
    mock_url = f"https://cryptopanic.com/api/v1/posts/?auth_token={TEST_API_TOKEN}&currencies={asset_symbol}&kind=news&public=true"
    
    mock_response = {
        "count": 1,
        "results": [
            {
                "kind": "news",
                "title": "Ethereum faces regulatory hurdles",
                "currencies": [{"code": "ETH", "title": "Ethereum"}],
                "votes": {"negative": 90, "positive": 10, "important": 20}
            }
        ]
    }

    with aioresponses() as m:
        m.get(mock_url, payload=mock_response, status=200)
        score = await news_provider.get_recent_news_score(asset_symbol)

    # Expected score: 10 / (10 + 90) = 0.1. Scaled: (0.1 * 2) - 1 = -0.8
    assert score == pytest.approx(-0.8, abs=0.01)

@pytest.mark.asyncio
async def test_get_recent_news_score_neutral_no_votes(news_provider):
    """Test getting a neutral score when there are no votes."""
    asset_symbol = "ADA"
    mock_url = f"https://cryptopanic.com/api/v1/posts/?auth_token={TEST_API_TOKEN}&currencies={asset_symbol}&kind=news&public=true"
    
    mock_response = {
        "count": 1,
        "results": [
            {
                "kind": "news",
                "title": "Cardano update released",
                "currencies": [{"code": "ADA", "title": "Cardano"}],
                "votes": {"negative": 0, "positive": 0, "important": 0}
            }
        ]
    }

    with aioresponses() as m:
        m.get(mock_url, payload=mock_response, status=200)
        score = await news_provider.get_recent_news_score(asset_symbol)

    # Expected score: Neutral (0.5) when no votes
    assert score == 0.5

@pytest.mark.asyncio
async def test_get_recent_news_score_no_news(news_provider):
    """Test getting a neutral score when there are no news results."""
    asset_symbol = "XRP"
    mock_url = f"https://cryptopanic.com/api/v1/posts/?auth_token={TEST_API_TOKEN}&currencies={asset_symbol}&kind=news&public=true"
    
    mock_response = {"count": 0, "results": []}

    with aioresponses() as m:
        m.get(mock_url, payload=mock_response, status=200)
        score = await news_provider.get_recent_news_score(asset_symbol)

    # Expected score: Neutral (0.5) when no news
    assert score == 0.5

@pytest.mark.asyncio
async def test_get_recent_news_score_api_error(news_provider, caplog):
    """Test handling of API errors (e.g., 401 Unauthorized)."""
    asset_symbol = "LTC"
    mock_url = f"https://cryptopanic.com/api/v1/posts/?auth_token={TEST_API_TOKEN}&currencies={asset_symbol}&kind=news&public=true"

    with aioresponses() as m:
        m.get(mock_url, status=401, body="Unauthorized")
        score = await news_provider.get_recent_news_score(asset_symbol)

    # Expected score: Neutral (0.5) on error
    assert score == 0.5
    assert f"Erro ao buscar notícias para {asset_symbol}: Status 401" in caplog.text

@pytest.mark.asyncio
async def test_get_recent_news_score_network_error(news_provider, caplog):
    """Test handling of network errors during the request."""
    asset_symbol = "DOGE"
    mock_url = f"https://cryptopanic.com/api/v1/posts/?auth_token={TEST_API_TOKEN}&currencies={asset_symbol}&kind=news&public=true"

    with aioresponses() as m:
        # Simulate a network error by raising an exception
        m.get(mock_url, exception=asyncio.TimeoutError("Request timed out"))
        score = await news_provider.get_recent_news_score(asset_symbol)

    # Expected score: Neutral (0.5) on error
    assert score == 0.5
    assert f"Timeout ao buscar notícias da API CryptoPanic para {asset_symbol}" in caplog.text

@pytest.mark.asyncio
async def test_news_provider_close_session(news_provider):
    """Test that the close_session method closes the aiohttp session."""
    # Ensure session is created
    _ = await news_provider._get_session() # Use await here
    assert news_provider._session is not None
    assert not news_provider._session.closed
    
    await news_provider.close_session()
    
    assert news_provider._session is None or news_provider._session.closed

# Add more tests as needed, e.g., for different API parameters, edge cases, etc.


