import pytest
import requests
import time
import subprocess
import sys
import os
import logging

# Adicionar o diretório raiz do projeto ao sys.path para o subprocesso também
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
HELPER_SCRIPT_PATH = os.path.join(PROJECT_ROOT, "tests", "run_prometheus_test_server.py")

TEST_PORT = 8001 # Deve ser o mesmo que no helper script
METRICS_URL = f"http://localhost:{TEST_PORT}/metrics"

@pytest.fixture(scope="function") # Alterado para function scope para garantir isolamento total
def prometheus_subprocess_server():
    """Inicia o servidor Prometheus e atualiza métricas em um subprocesso isolado."""
    process = None
    try:
        # Iniciar o helper script em um novo processo
        # Usar sys.executable para garantir que estamos usando o mesmo interpretador Python
        logging.info(f"SUBPROCESS_TEST: Iniciando helper script: {HELPER_SCRIPT_PATH}")
        process = subprocess.Popen([sys.executable, HELPER_SCRIPT_PATH],
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   env={**os.environ, "PYTHONPATH": PROJECT_ROOT + os.pathsep + os.environ.get("PYTHONPATH", "")})
        
        # Aguardar um pouco para o servidor no subprocesso iniciar e as métricas serem atualizadas
        # É crucial que o helper script imprima algo no stdout quando estiver pronto, ou ter um health check.
        # Por agora, vamos usar um sleep e verificar a saída do helper.
        time.sleep(3) # Aumentar um pouco para dar tempo ao subprocesso

        # Verificar se o subprocesso iniciou corretamente (opcional, mas bom para debug)
        helper_stdout_initial = ""
        helper_stderr_initial = ""
        try:
            helper_stdout_initial, helper_stderr_initial = process.communicate(timeout=1) # Não bloquear indefinidamente
        except subprocess.TimeoutExpired:
            logging.info("SUBPROCESS_TEST: Helper script stdout/stderr (timeout comunicate inicial):")
            # Se timeout, o processo ainda está rodando, o que é esperado.
            pass # Não é um erro se o processo ainda estiver rodando

        if process.poll() is not None: # Se o processo terminou
            stdout_output = helper_stdout_initial.decode() if helper_stdout_initial else "(no stdout)"
            stderr_output = helper_stderr_initial.decode() if helper_stderr_initial else "(no stderr)"
            pytest.fail(f"SUBPROCESS_TEST: Helper script {HELPER_SCRIPT_PATH} terminou inesperadamente.\nExit code: {process.returncode}\nSTDOUT:\n{stdout_output}\nSTDERR:\n{stderr_output}")
        
        logging.info("SUBPROCESS_TEST: Servidor Prometheus (no subprocesso) deve estar rodando.")
        yield METRICS_URL # O teste usará esta URL
        
    finally:
        if process:
            logging.info("SUBPROCESS_TEST: Encerrando o subprocesso do servidor Prometheus...")
            process.terminate() # Tenta terminar graciosamente
            try:
                stdout, stderr = process.communicate(timeout=5) # Espera um pouco para terminar
                logging.info(f"SUBPROCESS_TEST: Helper script STDOUT ao terminar:\n{stdout.decode() if stdout else ''}")
                logging.info(f"SUBPROCESS_TEST: Helper script STDERR ao terminar:\n{stderr.decode() if stderr else ''}")
            except subprocess.TimeoutExpired:
                logging.warning("SUBPROCESS_TEST: Timeout ao esperar o helper script terminar, forçando kill.")
                process.kill() # Força o encerramento se não terminar
                stdout, stderr = process.communicate()
                logging.info(f"SUBPROCESS_TEST: Helper script STDOUT após kill:\n{stdout.decode() if stdout else ''}")
                logging.info(f"SUBPROCESS_TEST: Helper script STDERR após kill:\n{stderr.decode() if stderr else ''}")
            logging.info("SUBPROCESS_TEST: Subprocesso do servidor Prometheus encerrado.")


def test_prometheus_metrics_export_subprocess(prometheus_subprocess_server):
    """Testa se as métricas são corretamente atualizadas e exportadas via HTTP por um servidor em subprocesso."""
    metrics_url_from_fixture = prometheus_subprocess_server # A fixture agora retorna a URL

    # Aguardar um momento extra para garantir que todas as atualizações de métricas no subprocesso ocorreram
    time.sleep(1) 

    logging.info(f"TEST_SUBPROCESS: Tentando buscar métricas de {metrics_url_from_fixture}")
    try:
        response = requests.get(metrics_url_from_fixture, timeout=15) # Timeout maior para o primeiro request
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        pytest.fail(f"Falha ao buscar métricas de {metrics_url_from_fixture}: {e}")
    
    metrics_text = response.text
    # print(f"\n--- METRICS RESPONSE (SUBPROCESS) ---\n{metrics_text}\n--- END METRICS RESPONSE ---")
    logging.info(f"TEST_SUBPROCESS: Métricas recebidas:\n{metrics_text}")

    # Verificar as métricas esperadas (devem corresponder ao que o helper script configura)
    assert 'kr_signals_processed_total{asset="BTCUSDT",final_decision="dummy_decision",regime="dummy_regime"} 2.0' in metrics_text
    assert 'kr_signals_processed_total{asset="ETHUSDT",final_decision="dummy_decision",regime="dummy_regime"} 1.0' in metrics_text
    assert 'kr_errors_total{asset="N/A",component="signal_processor"} 1.0' in metrics_text
    assert 'kr_errors_total{asset="N/A",component="binance_stream_connection"} 1.0' in metrics_text
    assert 'kr_binance_connection_status{connection_type="websocket"} 0.0' in metrics_text # ETHUSDT foi False
    assert 'kr_last_signal_timestamp_seconds{asset="BTCUSDT"}' in metrics_text

