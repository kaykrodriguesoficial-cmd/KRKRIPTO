#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Testes unitários para o PrometheusExporter v2.
Compatível com Mac M1 (ARM64).
"""

import unittest
import sys
import os
import logging
import platform
from unittest.mock import patch, MagicMock

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("test_prometheus_exporter_v2")

# Verificar se estamos em um Mac M1
def is_mac_m1():
    """Verifica se o ambiente atual é um Mac M1 (ARM64)."""
    return platform.system() == "Darwin" and ("arm" in platform.machine().lower())

# Adicionar diretório raiz ao path
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

# Importar o módulo a ser testado
try:
    from src.infrastructure.prometheus_exporter_v2 import (
        Counter, Gauge, Histogram, 
        _register_metric, _get_metric,
        inc_signals_processed, inc_errors,
        set_active_connection, update_last_signal_timestamp,
        start_metrics_server, is_operational, is_mac_m1_environment
    )
    MODULE_AVAILABLE = True
except ImportError as e:
    logger.error(f"Erro ao importar PrometheusExporter v2: {e}")
    MODULE_AVAILABLE = False

@unittest.skipIf(not MODULE_AVAILABLE, "PrometheusExporter v2 não disponível")
class TestPrometheusExporterV2(unittest.TestCase):
    """Testes para o PrometheusExporter v2."""

    def setUp(self):
        """Configuração inicial para os testes."""
        logger.info(f"Executando testes em ambiente: {'Mac M1' if is_mac_m1() else 'Outro'}")
        
    def test_mac_m1_detection(self):
        """Testa a detecção de ambiente Mac M1."""
        logger.info(f"Ambiente Mac M1 detectado: {is_mac_m1_environment()}")
        # Não testamos o valor específico, apenas se a função executa sem erros
        self.assertIsNotNone(is_mac_m1_environment())

    def test_register_metric(self):
        """Testa o registro de métricas."""
        # Testar registro de Counter
        counter = _register_metric(
            Counter, 
            "test_counter", 
            "Test counter documentation", 
            labels=["label1", "label2"]
        )
        self.assertIsNotNone(counter)
        
        # Testar registro de Gauge
        gauge = _register_metric(
            Gauge, 
            "test_gauge", 
            "Test gauge documentation", 
            labels=["label1"]
        )
        self.assertIsNotNone(gauge)
        
        # Testar registro de Histogram
        histogram = _register_metric(
            Histogram, 
            "test_histogram", 
            "Test histogram documentation", 
            labels=["label1"], 
            buckets=[0.1, 0.5, 1.0]
        )
        self.assertIsNotNone(histogram)

    def test_get_metric(self):
        """Testa a obtenção de métricas."""
        # Registrar uma métrica para teste
        _register_metric(
            Counter, 
            "test_get_metric", 
            "Test get_metric documentation"
        )
        
        # Obter a métrica
        metric = _get_metric("TEST_GET_METRIC")
        self.assertIsNotNone(metric)
        
        # Testar obtenção de métrica inexistente (deve criar um stub)
        nonexistent_metric = _get_metric("NONEXISTENT_METRIC")
        self.assertIsNotNone(nonexistent_metric)

    def test_inc_signals_processed(self):
        """Testa o incremento de sinais processados."""
        # Patch para evitar efeitos colaterais
        with patch('src.infrastructure.prometheus_exporter_v2._get_metric') as mock_get_metric:
            mock_metric = MagicMock()
            mock_labels = MagicMock()
            mock_metric.labels.return_value = mock_labels
            mock_get_metric.return_value = mock_metric
            
            # Chamar a função
            inc_signals_processed("BTC", "bull", "buy")
            
            # Verificar se a função foi chamada corretamente
            mock_get_metric.assert_called_once_with("SIGNALS_PROCESSED_TOTAL")
            mock_metric.labels.assert_called_once_with(asset="BTC", regime="bull", final_decision="buy")
            mock_labels.inc.assert_called_once()

    def test_inc_errors(self):
        """Testa o incremento de erros."""
        # Patch para evitar efeitos colaterais
        with patch('src.infrastructure.prometheus_exporter_v2._get_metric') as mock_get_metric:
            mock_metric = MagicMock()
            mock_labels = MagicMock()
            mock_metric.labels.return_value = mock_labels
            mock_get_metric.return_value = mock_metric
            
            # Chamar a função
            inc_errors("test_component", "BTC")
            
            # Verificar se a função foi chamada corretamente
            mock_get_metric.assert_called_once_with("ERRORS_TOTAL")
            mock_metric.labels.assert_called_once_with(component="test_component", asset="BTC")
            mock_labels.inc.assert_called_once()

    def test_set_active_connection(self):
        """Testa a definição de conexão ativa."""
        # Patch para evitar efeitos colaterais
        with patch('src.infrastructure.prometheus_exporter_v2.set_binance_connection_status') as mock_set_status:
            # Chamar a função
            set_active_connection("BTC", True)
            
            # Verificar se a função foi chamada corretamente
            mock_set_status.assert_called_once_with("websocket", True)

    def test_update_last_signal_timestamp(self):
        """Testa a atualização do timestamp do último sinal."""
        # Patch para evitar efeitos colaterais
        with patch('src.infrastructure.prometheus_exporter_v2._get_metric') as mock_get_metric:
            mock_metric = MagicMock()
            mock_labels = MagicMock()
            mock_metric.labels.return_value = mock_labels
            mock_get_metric.return_value = mock_metric
            
            # Chamar a função
            update_last_signal_timestamp("BTC")
            
            # Verificar se a função foi chamada corretamente
            mock_get_metric.assert_called_once_with("LAST_SIGNAL_TIMESTAMP")
            mock_metric.labels.assert_called_once_with(asset="BTC")
            mock_labels.set_to_current_time.assert_called_once()

    def test_start_metrics_server(self):
        """Testa o início do servidor de métricas."""
        # Patch para evitar efeitos colaterais
        with patch('src.infrastructure.prometheus_exporter_v2.start_http_server') as mock_start_server:
            # Chamar a função
            result = start_metrics_server(8000)
            
            # Verificar se a função foi chamada corretamente
            if MODULE_AVAILABLE:
                mock_start_server.assert_called_once_with(8000, addr='0.0.0.0')
                self.assertTrue(result)

    def test_is_operational(self):
        """Testa a verificação de operacionalidade."""
        # Chamar a função
        result = is_operational()
        
        # Verificar se o resultado é um booleano
        self.assertIsInstance(result, bool)

if __name__ == '__main__':
    unittest.main()
