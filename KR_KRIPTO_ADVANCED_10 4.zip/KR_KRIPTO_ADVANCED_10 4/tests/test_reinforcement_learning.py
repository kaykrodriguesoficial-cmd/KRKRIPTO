"""
Testes Unitários para Reinforcement Learning - Testes para o módulo RL avançado
==============================================================================

Este módulo implementa testes unitários para o módulo de Reinforcement Learning avançado.

Autor: Manus AI
Data: Maio 2025
Versão: 1.0.0
"""

import os
import sys
import unittest
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

# Adicionar diretório raiz ao path para importações relativas
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Importar módulos a serem testados
from src.intelligence.reinforcement.ambiente_rl_avancado import AmbienteRLAvancado, RealAmbienteRL

# MODIFICADO: Importar OperadorBinance em vez de Operador
from src.infrastructure.operador import OperadorBinance

class MockOperador:
    """Operador mock para testes."""
    
    def __init__(self, posicao=0.0, saldo=1000.0, preco=50000.0):
        self.posicao = posicao
        self.saldo = saldo
        self.preco = preco
        self.ordens = []
    
    def obter_posicao(self, ativo):
        return self.posicao
    
    def obter_saldo_disponivel(self, moeda):
        return self.saldo
    
    def obter_ticker(self, ativo):
        return {"price": str(self.preco)}
    
    def criar_ordem_mercado(self, ativo, lado, quantidade):
        ordem = {
            "ativo": ativo,
            "lado": lado,
            "quantidade": quantidade,
            "preco": self.preco,
            "timestamp": datetime.now().isoformat()
        }
        self.ordens.append(ordem)
        
        # Atualizar posição e saldo
        if lado == "BUY":
            self.posicao += quantidade
            self.saldo -= quantidade * self.preco
        elif lado == "SELL":
            self.saldo += quantidade * self.preco
            self.posicao -= quantidade
        
        return ordem
    
    def obter_klines(self, ativo, intervalo, limite=100):
        # Gerar dados aleatórios para klines
        klines = []
        timestamp = int(datetime.now().timestamp() * 1000)
        for i in range(limite):
            kline = [
                timestamp - (limite - i) * 60000,  # Open time
                str(self.preco - 100 + np.random.random() * 200),  # Open
                str(self.preco - 50 + np.random.random() * 300),   # High
                str(self.preco - 150 + np.random.random() * 200),  # Low
                str(self.preco - 100 + np.random.random() * 200),  # Close
                str(np.random.random() * 10),  # Volume
                timestamp - (limite - i - 1) * 60000,  # Close time
                str(np.random.random() * 1000000),  # Quote asset volume
                100,  # Number of trades
                str(np.random.random() * 5),  # Taker buy base asset volume
                str(np.random.random() * 500000),  # Taker buy quote asset volume
                "0"  # Ignore
            ]
            klines.append(kline)
        
        return klines


class MockMemoriaTemporal:
    """Memória temporal mock para testes."""
    
    def __init__(self, dataframes=None):
        self.dataframes = dataframes or {}
    
    def obter_dataframe(self, ativo, timeframe):
        key = f"{ativo}_{timeframe}"
        if key in self.dataframes:
            return self.dataframes[key]
        
        # Criar dataframe aleatório se não existir
        dates = pd.date_range(start="2023-01-01", periods=100, freq="H")
        df = pd.DataFrame({
            "open": np.random.random(100) * 100,
            "high": np.random.random(100) * 100 + 10,
            "low": np.random.random(100) * 100 - 10,
            "close": np.random.random(100) * 100,
            "volume": np.random.random(100) * 1000,
            "rsi": np.random.random(100) * 100,
            "macd": np.random.random(100) * 10 - 5,
            "macd_signal": np.random.random(100) * 10 - 5,
            "macd_hist": np.random.random(100) * 10 - 5,
            "ema_9": np.random.random(100) * 100,
            "sma_20": np.random.random(100) * 100
        }, index=dates)
        
        self.dataframes[key] = df
        return df


class TestAmbienteRLAvancado(unittest.TestCase):
    """Testes para a classe AmbienteRLAvancado."""
    
    def setUp(self):
        """Configuração inicial para os testes."""
        # Criar dataframe de teste
        dates = pd.date_range(start="2023-01-01", periods=100, freq="H")
        self.df = pd.DataFrame({
            "open": np.random.random(100) * 100,
            "high": np.random.random(100) * 100 + 10,
            "low": np.random.random(100) * 100 - 10,
            "close": np.random.random(100) * 100,
            "volume": np.random.random(100) * 1000,
            "rsi": np.random.random(100) * 100,
            "macd": np.random.random(100) * 10 - 5,
            "macd_signal": np.random.random(100) * 10 - 5,
            "macd_hist": np.random.random(100) * 10 - 5,
            "ema_9": np.random.random(100) * 100,
            "sma_20": np.random.random(100) * 100
        }, index=dates)
        
        # Criar configuração
        self.config = {
            "ativo": "BTCUSDT",
            "df_historico": self.df,
            "indice_inicio": 0,
            "indice_fim": 99,
            "capital_inicial": 1000.0,
            "custo_transacao": 0.001,
            "indicadores": ["rsi", "macd", "macd_signal", "macd_hist", "ema_9", "sma_20"]
        }
        
        # Criar ambiente
        self.ambiente = AmbienteRLAvancado(self.config)
    
    def test_init(self):
        """Testa a inicialização do ambiente."""
        self.assertEqual(self.ambiente.ativo, "BTCUSDT")
        self.assertEqual(self.ambiente.capital_inicial, 1000.0)
        self.assertEqual(self.ambiente.custo_transacao, 0.001)
        self.assertEqual(self.ambiente.indice_inicio, 0)
        self.assertEqual(self.ambiente.indice_fim, 99)
        self.assertEqual(len(self.ambiente.indicadores), 6)
    
    def test_reset(self):
        """Testa o reset do ambiente."""
        # Reset do ambiente
        estado = self.ambiente.reset()
        
        # Verificar estado inicial
        self.assertEqual(self.ambiente.indice_atual, 0)
        self.assertEqual(self.ambiente.capital_atual, 1000.0)
        self.assertEqual(self.ambiente.posicao_atual, 0.0)
        self.assertEqual(self.ambiente.valor_portfolio, 1000.0)
        self.assertEqual(len(self.ambiente.historico_acoes), 0)
        self.assertEqual(len(self.ambiente.historico_recompensas), 0)
        self.assertEqual(len(self.ambiente.historico_portfolio), 1)
        self.assertFalse(self.ambiente.done)
        
        # Verificar estado retornado
        self.assertIsInstance(estado, dict)
        self.assertIn("rsi", estado)
        self.assertIn("macd", estado)
        self.assertIn("posicao_atual", estado)
        self.assertIn("capital_normalizado", estado)
        self.assertIn("portfolio_normalizado", estado)
    
    def test_step_hold(self):
        """Testa o step com ação HOLD."""
        # Reset do ambiente
        self.ambiente.reset()
        
        # Executar ação HOLD
        proximo_estado, recompensa, done, info = self.ambiente.step(0)
        
        # Verificar resultado
        self.assertEqual(self.ambiente.indice_atual, 1)
        self.assertEqual(self.ambiente.capital_atual, 1000.0)
        self.assertEqual(self.ambiente.posicao_atual, 0.0)
        self.assertEqual(len(self.ambiente.historico_acoes), 1)
        self.assertEqual(self.ambiente.historico_acoes[0], 0)
        self.assertEqual(len(self.ambiente.historico_recompensas), 1)
        self.assertEqual(len(self.ambiente.historico_portfolio), 2)
        self.assertFalse(done)
        
        # Verificar estado retornado
        self.assertIsInstance(proximo_estado, dict)
        self.assertIn("rsi", proximo_estado)
        self.assertIn("macd", proximo_estado)
        self.assertIn("posicao_atual", proximo_estado)
    
    def test_step_buy(self):
        """Testa o step com ação BUY."""
        # Reset do ambiente
        self.ambiente.reset()
        
        # Executar ação BUY
        proximo_estado, recompensa, done, info = self.ambiente.step(1)
        
        # Verificar resultado
        self.assertEqual(self.ambiente.indice_atual, 1)
        self.assertEqual(self.ambiente.capital_atual, 0.0)
        self.assertGreater(self.ambiente.posicao_atual, 0.0)
        self.assertEqual(len(self.ambiente.historico_acoes), 1)
        self.assertEqual(self.ambiente.historico_acoes[0], 1)
        self.assertEqual(len(self.ambiente.historico_recompensas), 1)
        self.assertEqual(len(self.ambiente.historico_portfolio), 2)
        self.assertFalse(done)
    
    def test_step_sell(self):
        """Testa o step com ação SELL após BUY."""
        # Reset do ambiente
        self.ambiente.reset()
        
        # Executar ação BUY
        self.ambiente.step(1)
        
        # Executar ação SELL
        proximo_estado, recompensa, done, info = self.ambiente.step(2)
        
        # Verificar resultado
        self.assertEqual(self.ambiente.indice_atual, 2)
        self.assertGreater(self.ambiente.capital_atual, 0.0)
        self.assertEqual(self.ambiente.posicao_atual, 0.0)
        self.assertEqual(len(self.ambiente.historico_acoes), 2)
        self.assertEqual(self.ambiente.historico_acoes[0], 1)
        self.assertEqual(self.ambiente.historico_acoes[1], 2)
        self.assertEqual(len(self.ambiente.historico_recompensas), 2)
        self.assertEqual(len(self.ambiente.historico_portfolio), 3)
        self.assertFalse(done)
    
    def test_episode_completion(self):
        """Testa a conclusão de um episódio completo."""
        # Reset do ambiente
        self.ambiente.reset()
        
        # Executar ações até o fim do episódio
        done = False
        num_steps = 0
        while not done and num_steps < 200:  # Limite para evitar loop infinito
            _, _, done, _ = self.ambiente.step(np.random.randint(0, 3))  # Ação aleatória
            num_steps += 1
        
        # Verificar resultado
        self.assertTrue(done)
        self.assertEqual(self.ambiente.indice_atual, 100)  # indice_fim + 1
        self.assertEqual(len(self.ambiente.historico_acoes), 100)
        self.assertEqual(len(self.ambiente.historico_recompensas), 100)
        self.assertEqual(len(self.ambiente.historico_portfolio), 101)  # +1 do estado inicial
    
    def test_get_performance_metrics(self):
        """Testa o cálculo de métricas de performance."""
        # Reset do ambiente
        self.ambiente.reset()
        
        # Executar algumas ações
        self.ambiente.step(1)  # BUY
        self.ambiente.step(0)  # HOLD
        self.ambiente.step(2)  # SELL
        
        # Obter métricas
        metricas = self.ambiente.get_performance_metrics()
        
        # Verificar resultado
        self.assertIn("retorno_total", metricas)
        self.assertIn("retorno_anualizado", metricas)
        self.assertIn("volatilidade", metricas)
        self.assertIn("sharpe", metricas)
        self.assertIn("max_drawdown", metricas)
        self.assertIn("num_operacoes", metricas)
        self.assertIn("acoes", metricas)
        self.assertEqual(metricas["acoes"]["buy"], 1)
        self.assertEqual(metricas["acoes"]["hold"], 1)
        self.assertEqual(metricas["acoes"]["sell"], 1)


class TestRealAmbienteRL(unittest.TestCase):
    """Testes para a classe RealAmbienteRL."""
    
    def setUp(self):
        """Configuração inicial para os testes."""
        # Criar mocks
        self.operador = MockOperador(posicao=0.0, saldo=1000.0, preco=50000.0)
        self.memoria_temporal = MockMemoriaTemporal()
        
        # Criar configuração
        self.config = {
            "ativo": "BTCUSDT",
            "timeframe": "1h",
            "operador": self.operador,
            "memoria_temporal": self.memoria_temporal,
            "indicadores": ["rsi", "macd", "macd_signal", "macd_hist", "ema_9", "sma_20"]
        }
        
        # Criar ambiente real
        self.ambiente_real = RealAmbienteRL(self.config)
    
    def test_init(self):
        """Testa a inicialização do ambiente real."""
        self.assertEqual(self.ambiente_real.ativo, "BTCUSDT")
        self.assertEqual(self.ambiente_real.timeframe, "1h")
        self.assertEqual(self.ambiente_real.operador, self.operador)
        self.assertEqual(self.ambiente_real.memoria_temporal, self.memoria_temporal)
        self.assertEqual(len(self.ambiente_real.indicadores), 6)
        self.assertEqual(len(self.ambiente_real.historico_acoes), 0)
        self.assertEqual(len(self.ambiente_real.historico_recompensas), 0)
    
    def test_obter_estado(self):
        """Testa a obtenção do estado atual."""
        # Obter estado
        estado = self.ambiente_real.obter_estado()
        
        # Verificar resultado
        self.assertIsInstance(estado, dict)
        self.assertIn("rsi", estado)
        self.assertIn("macd", estado)
        self.assertIn("posicao_atual", estado)
        self.assertIn("preco_atual", estado)
    
    def test_executar_acao_hold(self):
        """Testa a execução da ação HOLD."""
        # Executar ação HOLD
        proximo_estado, recompensa, info = self.ambiente_real.executar_acao(0)
        
        # Verificar resultado
        self.assertEqual(self.ambiente_real.ultima_acao, 0)
        self.assertEqual(len(self.ambiente_real.historico_acoes), 1)
        self.assertEqual(self.ambiente_real.historico_acoes[0], 0)
        self.assertEqual(len(self.ambiente_real.historico_recompensas), 1)
        self.assertEqual(len(self.operador.ordens), 0)  # Não deve criar ordens
        
        # Verificar estado retornado
        self.assertIsInstance(proximo_estado, dict)
        self.assertIn("rsi", proximo_estado)
        self.assertIn("macd", proximo_estado)
        self.assertIn("posicao_atual", proximo_estado)
    
    def test_executar_acao_buy(self):
        """Testa a execução da ação BUY."""
        # Executar ação BUY
        proximo_estado, recompensa, info = self.ambiente_real.executar_acao(1)
        
        # Verificar resultado
        self.assertEqual(self.ambiente_real.ultima_acao, 1)
        self.assertEqual(len(self.ambiente_real.historico_acoes), 1)
        self.assertEqual(self.ambiente_real.historico_acoes[0], 1)
        self.assertEqual(len(self.ambiente_real.historico_recompensas), 1)
        self.assertEqual(len(self.operador.ordens), 1)  # Deve criar uma ordem
        self.assertEqual(self.operador.ordens[0]["lado"], "BUY")
        self.assertGreater(self.operador.posicao, 0.0)
        self.assertLess(self.operador.saldo, 1000.0)
    
    def test_executar_acao_sell(self):
        """Testa a execução da ação SELL após BUY."""
        # Executar ação BUY
        self.ambiente_real.executar_acao(1)
        
        # Executar ação SELL
        proximo_estado, recompensa, info = self.ambiente_real.executar_acao(2)
        
        # Verificar resultado
        self.assertEqual(self.ambiente_real.ultima_acao, 2)
        self.assertEqual(len(self.ambiente_real.historico_acoes), 2)
        self.assertEqual(self.ambiente_real.historico_acoes[0], 1)
        self.assertEqual(self.ambiente_real.historico_acoes[1], 2)
        self.assertEqual(len(self.ambiente_real.historico_recompensas), 2)
        self.assertEqual(len(self.operador.ordens), 2)  # Deve criar duas ordens
        self.assertEqual(self.operador.ordens[0]["lado"], "BUY")
        self.assertEqual(self.operador.ordens[1]["lado"], "SELL")
        self.assertEqual(self.operador.posicao, 0.0)
        self.assertGreater(self.operador.saldo, 0.0)
    
    def test_get_performance_metrics(self):
        """Testa o cálculo de métricas de performance."""
        # Executar algumas ações
        self.ambiente_real.executar_acao(1)  # BUY
        self.ambiente_real.executar_acao(0)  # HOLD
        self.ambiente_real.executar_acao(2)  # SELL
        
        # Obter métricas
        metricas = self.ambiente_real.get_performance_metrics()
        
        # Verificar resultado
        self.assertIn("retorno_total", metricas)
        self.assertIn("retorno_anualizado", metricas)
        self.assertIn("volatilidade", metricas)
        self.assertIn("sharpe", metricas)
        self.assertIn("max_drawdown", metricas)
        self.assertIn("num_operacoes", metricas)
        self.assertIn("acoes", metricas)
        self.assertEqual(metricas["acoes"]["buy"], 1)
        self.assertEqual(metricas["acoes"]["hold"], 1)
        self.assertEqual(metricas["acoes"]["sell"], 1)
