# tests/unit/strategies/test_risk_manager.py

import pytest
import pandas as pd
import numpy as np
import logging
from unittest.mock import patch

# Import the module to be tested
from src.strategies.risk_manager import aplicar_risco, calcular_volatilidade

# Try to import MarketRegime, use stub if fails
try:
    from src.intelligence.context_switcher import MarketRegime
except ImportError:
    # This stub is likely outdated and might cause issues if the import fails.
    # It's better to ensure the main enum is importable.
    logging.error("Failed to import MarketRegime from src.intelligence.context_switcher. Tests might fail.")
    # Raise an error or define a minimal stub if absolutely necessary for basic tests
    from enum import Enum
    class MarketRegime(config={}):
        INDEFINIDO = "INDEFINIDO"
        # Add other values only if essential for basic test structure and import fails
        TENDENCIA_FORTE_ALTA = "TENDENCIA_FORTE_ALTA"
        TENDENCIA_FORTE_BAIXA = "TENDENCIA_FORTE_BAIXA"
        ALTA_VOLATILIDADE = "ALTA_VOLATILIDADE"
        BAIXA_VOLATILIDADE = "BAIXA_VOLATILIDADE"

# --- Fixtures ---
@pytest.fixture
def sample_dataframe():
    """Creates a sample DataFrame for testing."""
    dates = pd.date_range(end="2023-01-31", periods=100, freq="1h")
    # Simulate different volatility levels
    price_low_vol = 100 * (1 + np.random.normal(0, 0.005, 100).cumsum())
    price_high_vol = 100 * (1 + np.random.normal(0, 0.03, 100).cumsum())
    df = pd.DataFrame({
        "Close_low": price_low_vol,
        "Close_high": price_high_vol,
    }, index=dates)
    # Use a single Close column for the main tests
    df["Close"] = df["Close_low"]
    return df

@pytest.fixture
def high_vol_dataframe():
    """Creates a sample DataFrame with high volatility."""
    dates = pd.date_range(end="2023-01-31", periods=100, freq="1h")
    price_high_vol = 100 * (1 + np.random.normal(0, 0.05, 100).cumsum()) # Higher vol
    df = pd.DataFrame({"Close": price_high_vol}, index=dates)
    return df

# --- Test calcular_volatilidade ---

def test_calcular_volatilidade_sufficient_data(sample_dataframe):
    vol = calcular_volatilidade(sample_dataframe, window=20)
    assert isinstance(vol, float)
    assert vol >= 0

def test_calcular_volatilidade_insufficient_data():
    dates = pd.date_range(end="2023-01-31", periods=10, freq="1h")
    price = 100 * (1 + np.random.normal(0, 0.01, 10).cumsum())
    df_short = pd.DataFrame({"Close": price}, index=dates)
    vol = calcular_volatilidade(df_short, window=20)
    assert vol == 0.0

def test_calcular_volatilidade_with_nan():
    dates = pd.date_range(end="2023-01-31", periods=30, freq="1h")
    price = 100 * (1 + np.random.normal(0, 0.01, 30).cumsum())
    df_nan = pd.DataFrame({"Close": price}, index=dates)
    df_nan.loc[df_nan.index[5], "Close"] = np.nan # Introduce NaN
    # Should handle NaN gracefully (e.g., ignore or return 0)
    # The current implementation might raise an error or return NaN depending on pandas version
    # For simplicity, let's assume it should return 0 or a valid float
    try:
        vol = calcular_volatilidade(df_nan, window=20)
        assert isinstance(vol, float)
        # Depending on how NaNs propagate, vol might be NaN or 0. Accept either for now.
        # assert vol == 0.0 or np.isnan(vol)
    except Exception as e:
        pytest.fail(f"calcular_volatilidade raised an exception with NaN: {e}")

# --- Test aplicar_risco ---

@pytest.mark.parametrize("regime, expected_factor", [
    (MarketRegime.TENDENCIA_FORTE_ALTA, 1.0), # No adjustment expected
    (MarketRegime.TENDENCIA_FORTE_BAIXA, 1.0), # No adjustment expected
    (MarketRegime.BAIXA_VOLATILIDADE, 1.0), # No adjustment expected
    (MarketRegime.ALTA_VOLATILIDADE, 0.90), # Adjustment expected
    (MarketRegime.INDEFINIDO, 0.90),      # Adjustment expected
])
def test_aplicar_risco_regime_adjustment(sample_dataframe, regime, expected_factor):
    """Tests risk adjustment based solely on market regime (low volatility)."""
    initial_score = 0.8
    config = {"risk_volatility_threshold": 1.0} # Ensure volatility threshold is high
    
    # Mock calcular_volatilidade to return low volatility
    with patch("src.strategies.risk_manager.calcular_volatilidade", return_value=0.1):
        adjusted_score = aplicar_risco(initial_score, sample_dataframe, regime, config)
        
    assert adjusted_score == pytest.approx(initial_score * expected_factor, abs=1e-6)
    assert 0.0 <= adjusted_score <= 1.0

def test_aplicar_risco_volatility_adjustment(sample_dataframe):
    """Tests risk adjustment based solely on high volatility (neutral regime)."""
    initial_score = 0.8
    regime = MarketRegime.TENDENCIA_FORTE_ALTA # Neutral regime
    config = {
        "risk_volatility_threshold": 0.3, 
        "risk_volatility_factor": 0.85
    }
    
    # Mock calcular_volatilidade to return high volatility
    with patch("src.strategies.risk_manager.calcular_volatilidade", return_value=0.5):
        adjusted_score = aplicar_risco(initial_score, sample_dataframe, regime, config)
        
    assert adjusted_score == pytest.approx(initial_score * 0.85, abs=1e-6)
    assert 0.0 <= adjusted_score <= 1.0

def test_aplicar_risco_volatility_no_adjustment_below_threshold(sample_dataframe):
    """Tests no volatility adjustment when below threshold."""
    initial_score = 0.8
    regime = MarketRegime.TENDENCIA_FORTE_ALTA # Neutral regime
    config = {"risk_volatility_threshold": 0.5}
    
    # Mock calcular_volatilidade to return low volatility
    with patch("src.strategies.risk_manager.calcular_volatilidade", return_value=0.3):
        adjusted_score = aplicar_risco(initial_score, sample_dataframe, regime, config)
        
    assert adjusted_score == pytest.approx(initial_score, abs=1e-6)

def test_aplicar_risco_combined_adjustment(sample_dataframe):
    """Tests combined risk adjustment for uncertain regime and high volatility."""
    initial_score = 0.8
    regime = MarketRegime.INDEFINIDO # Uncertain regime
    config = {
        "risk_volatility_threshold": 0.3,
        "risk_uncertain_factor": 0.90,
        "risk_volatility_factor": 0.85
    }
    expected_score = initial_score * 0.90 * 0.85 # Apply both factors
    
    # Mock calcular_volatilidade to return high volatility
    with patch("src.strategies.risk_manager.calcular_volatilidade", return_value=0.5):
        adjusted_score = aplicar_risco(initial_score, sample_dataframe, regime, config)
        
    assert adjusted_score == pytest.approx(expected_score, abs=1e-6)
    assert 0.0 <= adjusted_score <= 1.0

def test_aplicar_risco_score_limits(sample_dataframe):
    """Tests that the adjusted score stays within [0, 1]."""
    regime = MarketRegime.INDEFINIDO
    config = {
        "risk_volatility_threshold": 0.1,
        "risk_uncertain_factor": 0.1, # Extreme factors
        "risk_volatility_factor": 0.1
    }
    
    with patch("src.strategies.risk_manager.calcular_volatilidade", return_value=0.5):
        # Test lower bound
        adjusted_score_low = aplicar_risco(0.05, sample_dataframe, regime, config)
        assert adjusted_score_low == pytest.approx(0.0, abs=1e-3)
        
        # Test upper bound (factors shouldn't increase score, but check anyway)
        adjusted_score_high = aplicar_risco(1.5, sample_dataframe, regime, config) # Input > 1
        assert adjusted_score_high <= 1.0 # Should be capped at 1 or lower due to factors

        # Test with factors > 1 (should still cap at 1)
        config_inv = {"risk_uncertain_factor": 1.5, "risk_volatility_factor": 1.5}
        adjusted_score_inv = aplicar_risco(0.8, sample_dataframe, MarketRegime.TENDENCIA_FORTE_ALTA, config_inv)
        assert adjusted_score_inv == pytest.approx(0.8, abs=1e-6) # Factors > 1 shouldn't increase score

def test_aplicar_risco_no_config(sample_dataframe):
    """Tests that the function runs with default config if none provided."""
    initial_score = 0.8
    regime = MarketRegime.INDEFINIDO # Should trigger default uncertain factor
    
    # Mock calcular_volatilidade to return high volatility (to trigger default vol factor)
    with patch("src.strategies.risk_manager.calcular_volatilidade", return_value=0.7): # Default threshold is 0.6
        try:
            adjusted_score = aplicar_risco(initial_score, sample_dataframe, regime)
            # Check that it ran and applied some reduction based on defaults
            assert adjusted_score < initial_score 
            assert 0.0 <= adjusted_score <= 1.0
        except Exception as e:
            pytest.fail(f"aplicar_risco failed with default config: {e}")


