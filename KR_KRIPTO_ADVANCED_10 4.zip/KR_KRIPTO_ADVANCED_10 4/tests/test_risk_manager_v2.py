#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Testes unitários para o RiskManager v2 no Mac M1.

Este módulo implementa testes abrangentes para validar a funcionalidade
do RiskManager v2 no ambiente Mac M1 (ARM64).
"""

import unittest
import pandas as pd
import numpy as np
import platform
import sys
import os
import logging
from datetime import datetime

# Configuração de logging para testes
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("test_risk_manager")

# Adiciona o diretório raiz ao path para importações
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Importa o RiskManager
try:
    from src.risk_management.risk_manager import RiskManager, is_mac_m1, calcular_volatilidade, aplicar_risco, calcular_sl_tp_dinamico
except ImportError:
    try:
        # Tentativa alternativa para Mac M1
        from risk_management.risk_manager import RiskManager, is_mac_m1, calcular_volatilidade, aplicar_risco, calcular_sl_tp_dinamico
    except ImportError:
        logger.error("Erro ao importar RiskManager. Verifique se o módulo está instalado corretamente.")
        raise

class TestRiskManagerV2(unittest.TestCase):
    """Testes unitários para o RiskManager v2."""
    
    def setUp(self):
        """Configuração inicial para os testes."""
        # Imprime informações do ambiente
        print(f"Executando testes em: {platform.system()} {platform.machine()}")
        print(f"Mac M1 detectado: {is_mac_m1()}")
        
        # Configuração padrão para testes
        self.config = {
            "risk_volatility_factor": 0.85,
            "risk_uncertain_factor": 0.90,
            "risk_volatility_threshold": 0.6,
            "risk_atr_period": 14,
            "risk_sl_multiplier": 1.5,
            "risk_reward_ratio": 2.0
        }
        
        # Cria uma instância do RiskManager
        self.risk_manager = RiskManager(self.config)
        
        # Cria dados de teste
        self.create_test_data()
        
        # Define regime de mercado para testes
        class TestRegime:
            TENDENCIA_ALTA = 1
            TENDENCIA_BAIXA = 2
            LATERAL_ALTA_VOL = 3
            LATERAL_BAIXA_VOL = 4
            INDEFINIDO = 5
            name = "TESTE"
        
        self.regime = TestRegime
        self.regime_alta_vol = TestRegime.LATERAL_ALTA_VOL
        self.regime_tendencia = TestRegime.TENDENCIA_ALTA
    
    def create_test_data(self):
        """Cria dados de teste para os testes unitários."""
        # DataFrame para testes de volatilidade
        dates = pd.date_range(end="2023-01-31", periods=100, freq="1h")
        price = 100 * (1 + np.random.normal(0, 0.02, 100).cumsum())
        self.df_volatilidade = pd.DataFrame({"Close": price}, index=dates)
        
        # DataFrame para testes de SL/TP
        data = {
            'High': np.random.uniform(101, 105, 100),
            'Low': np.random.uniform(95, 99, 100),
            'Close': np.random.uniform(99, 101, 100)
        }
        # Garante que Low <= Close <= High
        data['Low'] = np.minimum(data['Low'], data['Close'])
        data['High'] = np.maximum(data['High'], data['Close'])
        self.df_sl_tp = pd.DataFrame(data, index=pd.date_range(end="2023-01-31", periods=100, freq="1h"))
    
    def test_mac_m1_detection(self):
        """Testa a detecção de ambiente Mac M1."""
        # Verifica se a função is_mac_m1 está disponível
        self.assertTrue(callable(is_mac_m1), "A função is_mac_m1 deve ser callable")
        
        # Verifica se o resultado é um booleano
        result = is_mac_m1()
        self.assertIsInstance(result, bool, "is_mac_m1 deve retornar um booleano")
        
        # Verifica se a detecção corresponde ao ambiente real
        expected = platform.system() == "Darwin" and platform.machine() == "arm64"
        self.assertEqual(result, expected, "A detecção de Mac M1 deve corresponder ao ambiente real")
        
        # Verifica se o RiskManager tem a informação de ambiente
        self.assertTrue(hasattr(self.risk_manager, "is_mac_m1"), "RiskManager deve ter o atributo is_mac_m1")
        self.assertEqual(self.risk_manager.is_mac_m1, expected, "RiskManager.is_mac_m1 deve corresponder ao ambiente real")
    
    def test_environment_info(self):
        """Testa a coleta de informações do ambiente."""
        # Verifica se o RiskManager tem as informações de ambiente
        self.assertTrue(hasattr(self.risk_manager, "environment_info"), "RiskManager deve ter o atributo environment_info")
        
        # Verifica se as informações de ambiente estão completas
        env_info = self.risk_manager.environment_info
        self.assertIsInstance(env_info, dict, "environment_info deve ser um dicionário")
        
        # Verifica se todas as chaves esperadas estão presentes
        expected_keys = ['system', 'release', 'machine', 'processor', 'python', 'mac_m1']
        for key in expected_keys:
            self.assertIn(key, env_info, f"environment_info deve conter a chave '{key}'")
        
        # Imprime as informações do ambiente para referência
        print(f"Ambiente: {env_info}")
    
    def test_initialization(self):
        """Testa a inicialização do RiskManager."""
        # Verifica se o RiskManager foi inicializado corretamente
        self.assertIsInstance(self.risk_manager, RiskManager, "risk_manager deve ser uma instância de RiskManager")
        
        # Verifica se os parâmetros de configuração foram aplicados corretamente
        self.assertEqual(self.risk_manager.fator_volatilidade_alta, self.config["risk_volatility_factor"])
        self.assertEqual(self.risk_manager.fator_regime_incerto, self.config["risk_uncertain_factor"])
        self.assertEqual(self.risk_manager.limite_volatilidade, self.config["risk_volatility_threshold"])
        self.assertEqual(self.risk_manager.atr_period, self.config["risk_atr_period"])
        self.assertEqual(self.risk_manager.sl_multiplier, self.config["risk_sl_multiplier"])
        self.assertEqual(self.risk_manager.risk_reward_ratio, self.config["risk_reward_ratio"])
    
    def test_calcular_volatilidade(self):
        """Testa o cálculo de volatilidade."""
        # Testa o método da classe
        volatilidade = self.risk_manager.calcular_volatilidade(self.df_volatilidade)
        self.assertIsInstance(volatilidade, float, "volatilidade deve ser um float")
        self.assertGreaterEqual(volatilidade, 0.0, "volatilidade deve ser não-negativa")
        
        # Testa a função procedural
        volatilidade_proc = calcular_volatilidade(self.df_volatilidade)
        self.assertIsInstance(volatilidade_proc, float, "volatilidade_proc deve ser um float")
        self.assertGreaterEqual(volatilidade_proc, 0.0, "volatilidade_proc deve ser não-negativa")
        
        # Verifica se os resultados são consistentes
        self.assertAlmostEqual(volatilidade, volatilidade_proc, places=5, msg="Os resultados do método e da função devem ser consistentes")
        
        # Testa com janela personalizada
        volatilidade_30 = self.risk_manager.calcular_volatilidade(self.df_volatilidade, window=30)
        self.assertIsInstance(volatilidade_30, float, "volatilidade_30 deve ser um float")
        
        # Testa com dados inválidos
        volatilidade_none = self.risk_manager.calcular_volatilidade(None)
        self.assertEqual(volatilidade_none, 0.0, "volatilidade_none deve ser 0.0")
        
        volatilidade_empty = self.risk_manager.calcular_volatilidade(pd.DataFrame())
        self.assertEqual(volatilidade_empty, 0.0, "volatilidade_empty deve ser 0.0")
        
        # Testa com DataFrame sem coluna 'Close'
        df_sem_close = pd.DataFrame({"Outra": [1, 2, 3]})
        volatilidade_sem_close = self.risk_manager.calcular_volatilidade(df_sem_close)
        self.assertEqual(volatilidade_sem_close, 0.0, "volatilidade_sem_close deve ser 0.0")
    
    def test_aplicar_risco(self):
        """Testa a aplicação de risco ao score."""
        # Testa o método da classe com regime de alta volatilidade
        score_original = 0.85
        score_ajustado = self.risk_manager.aplicar_risco(score_original, self.df_volatilidade, self.regime_alta_vol)
        self.assertIsInstance(score_ajustado, float, "score_ajustado deve ser um float")
        self.assertLessEqual(score_ajustado, score_original, "score_ajustado deve ser menor ou igual ao original")
        self.assertGreaterEqual(score_ajustado, 0.0, "score_ajustado deve ser não-negativo")
        self.assertLessEqual(score_ajustado, 1.0, "score_ajustado deve ser menor ou igual a 1.0")
        
        # Testa a função procedural
        score_ajustado_proc = aplicar_risco(score_original, self.df_volatilidade, self.regime_alta_vol)
        self.assertIsInstance(score_ajustado_proc, float, "score_ajustado_proc deve ser um float")
        self.assertAlmostEqual(score_ajustado, score_ajustado_proc, places=5, msg="Os resultados do método e da função devem ser consistentes")
        
        # Testa com regime de tendência (sem ajuste)
        score_tendencia = self.risk_manager.aplicar_risco(score_original, self.df_volatilidade, self.regime_tendencia)
        self.assertIsInstance(score_tendencia, float, "score_tendencia deve ser um float")
        
        # Testa com configuração personalizada
        config_personalizado = self.config.copy()
        config_personalizado["risk_volatility_threshold"] = 0.0  # Garante que a volatilidade seja considerada alta
        score_ajustado_config = aplicar_risco(score_original, self.df_volatilidade, self.regime_tendencia, config_personalizado)
        self.assertIsInstance(score_ajustado_config, float, "score_ajustado_config deve ser um float")
        
        # Testa com score inválido
        score_invalido = self.risk_manager.aplicar_risco("invalido", self.df_volatilidade, self.regime_tendencia)
        self.assertIsInstance(score_invalido, float, "score_invalido deve ser convertido para float")
        self.assertGreaterEqual(score_invalido, 0.0, "score_invalido deve ser não-negativo")
        self.assertLessEqual(score_invalido, 1.0, "score_invalido deve ser menor ou igual a 1.0")
    
    def test_calcular_sl_tp_dinamico(self):
        """Testa o cálculo de Stop Loss e Take Profit dinâmicos."""
        # Testa o método da classe para operação de compra
        entry_price_buy = 100.50
        side_buy = 'BUY'
        sl_buy, tp_buy = self.risk_manager.calcular_sl_tp_dinamico(self.df_sl_tp, entry_price_buy, side_buy)
        
        self.assertIsInstance(sl_buy, float, "sl_buy deve ser um float")
        self.assertIsInstance(tp_buy, float, "tp_buy deve ser um float")
        self.assertLess(sl_buy, entry_price_buy, "sl_buy deve ser menor que entry_price_buy")
        self.assertGreater(tp_buy, entry_price_buy, "tp_buy deve ser maior que entry_price_buy")
        
        # Testa a função procedural
        sl_buy_proc, tp_buy_proc = calcular_sl_tp_dinamico(self.df_sl_tp, entry_price_buy, side_buy)
        self.assertIsInstance(sl_buy_proc, float, "sl_buy_proc deve ser um float")
        self.assertIsInstance(tp_buy_proc, float, "tp_buy_proc deve ser um float")
        self.assertAlmostEqual(sl_buy, sl_buy_proc, places=5, msg="Os resultados do método e da função devem ser consistentes")
        self.assertAlmostEqual(tp_buy, tp_buy_proc, places=5, msg="Os resultados do método e da função devem ser consistentes")
        
        # Testa para operação de venda
        entry_price_sell = 100.50
        side_sell = 'SELL'
        sl_sell, tp_sell = self.risk_manager.calcular_sl_tp_dinamico(self.df_sl_tp, entry_price_sell, side_sell)
        
        self.assertIsInstance(sl_sell, float, "sl_sell deve ser um float")
        self.assertIsInstance(tp_sell, float, "tp_sell deve ser um float")
        self.assertGreater(sl_sell, entry_price_sell, "sl_sell deve ser maior que entry_price_sell")
        self.assertLess(tp_sell, entry_price_sell, "tp_sell deve ser menor que entry_price_sell")
        
        # Testa com configuração personalizada
        config_personalizado = self.config.copy()
        config_personalizado["risk_sl_multiplier"] = 2.0
        config_personalizado["risk_tp_multiplier"] = 3.0
        
        sl_custom, tp_custom = calcular_sl_tp_dinamico(self.df_sl_tp, entry_price_buy, side_buy, config_personalizado)
        self.assertIsInstance(sl_custom, float, "sl_custom deve ser um float")
        self.assertIsInstance(tp_custom, float, "tp_custom deve ser um float")
        
        # Testa com dados inválidos
        sl_none, tp_none = self.risk_manager.calcular_sl_tp_dinamico(None, entry_price_buy, side_buy)
        self.assertIsNone(sl_none, "sl_none deve ser None")
        self.assertIsNone(tp_none, "tp_none deve ser None")
        
        sl_empty, tp_empty = self.risk_manager.calcular_sl_tp_dinamico(pd.DataFrame(), entry_price_buy, side_buy)
        self.assertIsNone(sl_empty, "sl_empty deve ser None")
        self.assertIsNone(tp_empty, "tp_empty deve ser None")
        
        # Testa com preço de entrada inválido
        sl_preco_invalido, tp_preco_invalido = self.risk_manager.calcular_sl_tp_dinamico(self.df_sl_tp, -1.0, side_buy)
        self.assertIsNone(sl_preco_invalido, "sl_preco_invalido deve ser None")
        self.assertIsNone(tp_preco_invalido, "tp_preco_invalido deve ser None")
        
        # Testa com lado inválido
        sl_lado_invalido, tp_lado_invalido = self.risk_manager.calcular_sl_tp_dinamico(self.df_sl_tp, entry_price_buy, "INVALID")
        self.assertIsNone(sl_lado_invalido, "sl_lado_invalido deve ser None")
        self.assertIsNone(tp_lado_invalido, "tp_lado_invalido deve ser None")
    
    def test_procedural_interface(self):
        """Testa a interface procedural do RiskManager."""
        # Testa a função calcular_volatilidade
        volatilidade = calcular_volatilidade(self.df_volatilidade)
        self.assertIsInstance(volatilidade, float, "volatilidade deve ser um float")
        
        # Testa a função aplicar_risco
        score_original = 0.85
        score_ajustado = aplicar_risco(score_original, self.df_volatilidade, self.regime_alta_vol)
        self.assertIsInstance(score_ajustado, float, "score_ajustado deve ser um float")
        
        # Testa a função calcular_sl_tp_dinamico
        entry_price = 100.50
        side = 'BUY'
        sl, tp = calcular_sl_tp_dinamico(self.df_sl_tp, entry_price, side)
        self.assertIsInstance(sl, float, "sl deve ser um float")
        self.assertIsInstance(tp, float, "tp deve ser um float")
        
        # Testa com configuração personalizada
        config_personalizado = self.config.copy()
        score_ajustado_config = aplicar_risco(score_original, self.df_volatilidade, self.regime_alta_vol, config_personalizado)
        self.assertIsInstance(score_ajustado_config, float, "score_ajustado_config deve ser um float")
        
        sl_config, tp_config = calcular_sl_tp_dinamico(self.df_sl_tp, entry_price, side, config_personalizado)
        self.assertIsInstance(sl_config, float, "sl_config deve ser um float")
        self.assertIsInstance(tp_config, float, "tp_config deve ser um float")
    
    def test_robustness(self):
        """Testa a robustez do RiskManager em condições adversas."""
        # Testa com DataFrame vazio
        df_vazio = pd.DataFrame()
        volatilidade_vazio = self.risk_manager.calcular_volatilidade(df_vazio)
        self.assertEqual(volatilidade_vazio, 0.0, "volatilidade_vazio deve ser 0.0")
        
        score_vazio = self.risk_manager.aplicar_risco(0.5, df_vazio, self.regime_tendencia)
        self.assertIsInstance(score_vazio, float, "score_vazio deve ser um float")
        
        sl_vazio, tp_vazio = self.risk_manager.calcular_sl_tp_dinamico(df_vazio, 100.0, 'BUY')
        self.assertIsNone(sl_vazio, "sl_vazio deve ser None")
        self.assertIsNone(tp_vazio, "tp_vazio deve ser None")
        
        # Testa com valores extremos
        score_extremo = self.risk_manager.aplicar_risco(1000.0, self.df_volatilidade, self.regime_alta_vol)
        self.assertLessEqual(score_extremo, 1.0, "score_extremo deve ser limitado a 1.0")
        
        score_negativo = self.risk_manager.aplicar_risco(-1000.0, self.df_volatilidade, self.regime_alta_vol)
        self.assertGreaterEqual(score_negativo, 0.0, "score_negativo deve ser limitado a 0.0")
        
        # Testa com tipos de dados inválidos
        score_str = self.risk_manager.aplicar_risco("0.5", self.df_volatilidade, self.regime_tendencia)
        self.assertIsInstance(score_str, float, "score_str deve ser convertido para float")
        
        # Testa com regime None
        score_regime_none = self.risk_manager.aplicar_risco(0.5, self.df_volatilidade, None)
        self.assertIsInstance(score_regime_none, float, "score_regime_none deve ser um float")

if __name__ == "__main__":
    unittest.main()
