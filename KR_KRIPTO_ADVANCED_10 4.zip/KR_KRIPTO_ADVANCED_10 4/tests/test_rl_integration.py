# src/tests/intelligence/rl/test_rl_integration.py

import pytest
import pandas as pd
import numpy as np
import os
import sys
import asyncio
from unittest.mock import patch, MagicMock

# Adicionar o diretório raiz do projeto ao sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))

# Importar as classes a serem testadas
from src.intelligence.rl.agente_rl import AgenteRL
from src.intelligence.rl.ambiente_rl import AmbienteRL

# --- Fixtures ---

@pytest.fixture
def sample_dataframe():
    """Cria um DataFrame de exemplo para os testes (com colunas minúsculas)."""
    data = {
        'open': [100, 101, 102, 101, 103, 104, 105, 104, 106, 107],
        'high': [101, 102, 103, 102, 104, 105, 106, 105, 107, 108],
        'low': [99, 100, 101, 100, 102, 103, 104, 103, 105, 106],
        'close': [101, 102, 101, 102, 104, 105, 104, 105, 107, 106],
        'volume': [1000, 1100, 1200, 1050, 1300, 1400, 1350, 1250, 1500, 1450],
        # Adicionar colunas de indicadores usadas no estado (ex: rsi, macd_hist) - minúsculo
        'rsi': [50, 55, 52, 54, 60, 65, 62, 64, 70, 68],
        'macd_hist': [0.1, 0.2, 0.15, 0.18, 0.25, 0.3, 0.28, 0.29, 0.35, 0.32]
    }
    return pd.DataFrame(data)

@pytest.fixture
def ambiente(sample_dataframe):
    """Cria uma instância do AmbienteRL para os testes."""
    # Passar o dataframe já com colunas minúsculas
    return AmbienteRL(config={'ativo': "TESTUSDT", 'df_inicial': sample_dataframe, 'capital_inicial': 1000.0, 'custo_transacao': 0.001})

@pytest.fixture
def agente(tmp_path):
    """Cria uma instância do AgenteRL para os testes, usando um path temporário para a Q-table."""
    q_table_file = tmp_path / "q_table_test.pkl"
    return AgenteRL(ativo="TESTUSDT", q_table_path=str(q_table_file))

# --- Testes ---

def test_ambiente_inicializacao(ambiente, sample_dataframe):
    """Testa a inicialização correta do AmbienteRL."""
    assert ambiente.ativo == "TESTUSDT"
    assert ambiente.capital_inicial == 1000.0
    assert ambiente.custo_transacao == 0.001
    assert ambiente.indice_atual == len(sample_dataframe) - 1
    assert ambiente.capital_atual == 1000.0
    assert ambiente.posicao_atual == 0
    assert ambiente.valor_portfolio == 1000.0

def test_ambiente_obter_estado(ambiente, sample_dataframe):
    """Testa a obtenção do estado atual do ambiente."""
    estado = ambiente.obter_estado()
    assert isinstance(estado, dict)
    assert "rsi" in estado
    # assert "macd_hist" in estado # MACD não é mais usado no estado base
    assert "posicao_atual" in estado
    # Verificar valores do último candle (usando colunas minúsculas)
    assert estado["rsi"] == sample_dataframe["rsi"].iloc[-1]
    # assert estado["macd_hist"] == sample_dataframe["macd_hist"].iloc[-1]
    assert estado["posicao_atual"] == 0 # Inicialmente neutro

def test_agente_inicializacao(agente):
    """Testa a inicialização correta do AgenteRL."""
    assert agente.ativo == "TESTUSDT"
    assert agente.lr == 0.1
    assert agente.gamma == 0.95
    assert agente.epsilon >= agente.epsilon_min
    assert isinstance(agente.q_table, dict) # Na verdade é defaultdict, mas dict é superclasse

def test_agente_discretizar_estado(agente):
    """Testa a função de discretização de estado do agente."""
    # Testar diferentes valores de RSI e MACD
    estado_continuo_1 = {"rsi": 15, "macd_hist": -0.1}
    estado_discreto_1 = agente._discretizar_estado(estado_continuo_1)
    assert isinstance(estado_discreto_1, tuple)
    # assert estado_discreto_1 == (0, 0) # RSI < 20, MACD < -0.001 -> Ajustado para apenas RSI
    assert estado_discreto_1 == (0,) # Apenas RSI < 20

    estado_continuo_2 = {"rsi": 75, "macd_hist": 0.0}
    estado_discreto_2 = agente._discretizar_estado(estado_continuo_2)
    # assert estado_discreto_2 == (3, 1) # 60 <= RSI < 80, MACD ~= 0 -> Ajustado para apenas RSI
    assert estado_discreto_2 == (3,) # Apenas 60 <= RSI < 80

    estado_continuo_3 = {"rsi": 90, "macd_hist": 0.5}
    estado_discreto_3 = agente._discretizar_estado(estado_continuo_3)
    # assert estado_discreto_3 == (4, 2) # RSI >= 80, MACD > 0.001 -> Ajustado para apenas RSI
    assert estado_discreto_3 == (4,) # Apenas RSI >= 80

def test_agente_escolher_acao_exploracao(agente):
    """Testa a escolha de ação em modo de exploração (epsilon alto)."""
    agente.epsilon = 1.0 # Forçar exploração
    estado = {"rsi": 50, "posicao_atual": 0} # Estado simplificado
    with patch("random.choice") as mock_random_choice:
        mock_random_choice.return_value = 1 # Simular escolha de BUY
        acao = agente.escolher_acao(estado)
        mock_random_choice.assert_called_once_with(agente.acoes)
        assert acao == 1

def test_agente_escolher_acao_exploitacao(agente):
    """Testa a escolha de ação em modo de explotação (epsilon baixo)."""
    agente.epsilon = 0.0 # Forçar explotação
    estado = {"rsi": 30, "posicao_atual": 0} # Estado simplificado
    estado_discreto = agente._discretizar_estado(estado)
    # Definir valores Q manualmente para este estado
    agente.q_table[estado_discreto] = np.array([0.1, 0.5, 0.2]) # Melhor ação é BUY (índice 1)
    acao = agente.escolher_acao(estado)
    assert acao == 1

def test_ambiente_step_buy(ambiente):
    """Testa a execução de uma ação de COMPRA no ambiente."""
    preco_atual = ambiente.df["close"].iloc[-1] # Usar minúsculo
    capital_antes = ambiente.capital_atual
    posicao_antes = ambiente.posicao_atual

    proximo_estado, recompensa, finalizado = ambiente.step(1) # Ação BUY

    assert ambiente.capital_atual == 0
    assert ambiente.posicao_atual > posicao_antes
    # Verificar cálculo da posição com custo de transação
    qtd_esperada = capital_antes / preco_atual * (1 - ambiente.custo_transacao)
    assert np.isclose(ambiente.posicao_atual, qtd_esperada)
    assert ambiente.ultima_acao == 1
    assert isinstance(proximo_estado, dict)
    assert isinstance(recompensa, float)
    assert not finalizado

def test_ambiente_step_sell(ambiente):
    """Testa a execução de uma ação de VENDA no ambiente (após uma compra)."""
    # Primeiro, fazer uma compra para ter posição
    ambiente.step(1)
    posicao_antes_venda = ambiente.posicao_atual
    capital_antes_venda = ambiente.capital_atual
    preco_atual = ambiente.df["close"].iloc[-1] # Usar minúsculo

    proximo_estado, recompensa, finalizado = ambiente.step(2) # Ação SELL

    assert ambiente.posicao_atual == 0
    # assert ambiente.capital_atual > capital_antes_venda # Pode ser igual se preço não mudar
    # Verificar cálculo do capital com custo de transação
    valor_esperado = posicao_antes_venda * preco_atual * (1 - ambiente.custo_transacao)
    assert np.isclose(ambiente.capital_atual, valor_esperado)
    assert ambiente.ultima_acao == 2
    assert isinstance(proximo_estado, dict)
    assert isinstance(recompensa, float)
    assert not finalizado

def test_ambiente_step_hold(ambiente):
    """Testa a execução de uma ação HOLD no ambiente."""
    capital_antes = ambiente.capital_atual
    posicao_antes = ambiente.posicao_atual
    portfolio_antes = ambiente.valor_portfolio

    proximo_estado, recompensa, finalizado = ambiente.step(0) # Ação HOLD

    assert ambiente.capital_atual == capital_antes
    assert ambiente.posicao_atual == posicao_antes
    assert ambiente.valor_portfolio == portfolio_antes # Valor não deve mudar só com HOLD
    assert ambiente.ultima_acao == 0
    assert isinstance(proximo_estado, dict)
    # Recompensa por HOLD pode ser zero ou ter outra lógica
    # assert recompensa == 0.0
    assert not finalizado

def test_agente_aprender(agente):
    """Testa a função de aprendizado do agente (atualização da Q-table)."""
    estado = {"rsi": 65, "posicao_atual": 0} # Estado simplificado
    proximo_estado = {"rsi": 70, "posicao_atual": 1} # Estado simplificado
    acao = 1 # BUY
    recompensa = 0.05

    estado_discreto = agente._discretizar_estado(estado)
    proximo_estado_discreto = agente._discretizar_estado(proximo_estado)

    # Valor Q inicial (deve ser 0)
    q_antes = agente.q_table[estado_discreto][acao]
    assert q_antes == 0.0

    # Definir Q-value para o próximo estado para teste
    agente.q_table[proximo_estado_discreto] = np.array([0.1, 0.2, 0.15])
    q_futuro_max = 0.2

    # Capturar o Q-value *atual* para (estado_discreto, acao) APÓS a modificação acima,
    # pois estado_discreto e proximo_estado_discreto podem ser iguais.
    q_atual_real = agente.q_table[estado_discreto][acao]

    agente.aprender(estado, acao, recompensa, proximo_estado)

    # Verificar se o valor Q foi atualizado
    q_depois = agente.q_table[estado_discreto][acao]
    # Calcular o esperado usando o q_atual_real como ponto de partida
    q_esperado = q_atual_real + agente.lr * (recompensa + agente.gamma * q_futuro_max - q_atual_real)
    assert np.isclose(q_depois, q_esperado)

    # Verificar se epsilon decaiu
    assert agente.epsilon < 1.0

def test_agente_salvar_carregar_q_table(agente, tmp_path):
    """Testa o salvamento e carregamento da Q-table."""
    estado = {"rsi": 45, "posicao_atual": 0} # Estado simplificado
    estado_discreto = agente._discretizar_estado(estado)
    agente.q_table[estado_discreto] = np.array([0.8, 0.1, 0.1]) # Definir um valor

    # Salvar
    agente.salvar_q_table()
    q_table_path = agente.q_table_path
    assert os.path.exists(q_table_path)

    # Criar novo agente para carregar
    agente_novo = AgenteRL(config={'ativo': "TESTUSDT", 'q_table_path': q_table_path})

    # Verificar se o valor carregado está correto
    assert estado_discreto in agente_novo.q_table
    assert np.allclose(agente_novo.q_table[estado_discreto], np.array([0.8, 0.1, 0.1]))

# Teste de integração simples do ciclo RL
@pytest.mark.asyncio
async def test_ciclo_rl_integracao(agente, ambiente):
    """Testa um ciclo completo: estado -> ação -> step -> aprender."""
    # 1. Obter estado inicial
    estado_inicial = ambiente.obter_estado()
    assert estado_inicial is not None

    # 2. Agente escolhe ação
    # Forçar explotação para previsibilidade no teste
    agente.epsilon = 0.0
    estado_discreto_inicial = agente._discretizar_estado(estado_inicial)
    agente.q_table[estado_discreto_inicial] = np.array([0.1, 0.5, 0.2]) # Forçar BUY
    acao_escolhida = agente.escolher_acao(estado_inicial)
    assert acao_escolhida == 1 # BUY

    # 3. Ambiente executa ação (step)
    proximo_estado, recompensa, _ = ambiente.step(acao_escolhida)
    assert proximo_estado is not None
    assert isinstance(recompensa, float)

    # 4. Agente aprende
    q_antes = agente.q_table[estado_discreto_inicial][acao_escolhida]
    agente.aprender(estado_inicial, acao_escolhida, recompensa, proximo_estado)
    q_depois = agente.q_table[estado_discreto_inicial][acao_escolhida]

    # Verificar se Q-value mudou (a menos que recompensa + gamma*q_futuro == q_atual)
    # É difícil prever o valor exato sem saber o q_futuro_max, mas deve ser diferente de 0
    # assert not np.isclose(q_depois, q_antes) # Pode ser próximo se recompensa for pequena
    assert q_depois != 0.0 # Pelo menos foi atualizado


