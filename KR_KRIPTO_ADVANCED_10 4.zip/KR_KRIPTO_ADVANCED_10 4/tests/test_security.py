# Tests for src/infrastructure/security.py

import pytest
import os
import hashlib
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa

# Adjust the path to import from the src directory
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from src.infrastructure.security import verificar_assinatura, validar_modelo_sha256

# --- Fixtures for Test Setup ---

@pytest.fixture(scope="module")
def dummy_files(tmp_path_factory):
    """Creates dummy model, hash, key, and signature files for testing."""
    base_path = tmp_path_factory.mktemp("security_test_files")
    model_path = base_path / "dummy_model.h5"
    key_path = base_path / "dummy_public.pem"
    sig_path = base_path / "dummy_model.sig"
    
    # 1. Create dummy model content
    model_content = b"This is a dummy model file content."
    model_path.write_bytes(model_content)
    correct_sha256 = hashlib.sha256(model_content).hexdigest()
    incorrect_sha256 = "a" * 64

    # 2. Generate RSA key pair for signature
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    public_key = private_key.public_key()

    # 3. Save public key
    pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    key_path.write_bytes(pem)

    # 4. Create signature for the model content
    signature = private_key.sign(
        model_content,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )
    sig_path.write_bytes(signature)
    
    # Create a corrupted signature file
    corrupted_sig_path = base_path / "corrupted_model.sig"
    corrupted_sig_path.write_bytes(b"invalid signature data")

    return {
        "model": str(model_path),
        "key": str(key_path),
        "sig": str(sig_path),
        "corrupted_sig": str(corrupted_sig_path),
        "correct_sha256": correct_sha256,
        "incorrect_sha256": incorrect_sha256,
        "non_existent": str(base_path / "non_existent_file")
    }

# --- Tests for validar_modelo_sha256 ---

def test_validar_modelo_sha256_valid(dummy_files):
    """Test SHA256 validation with a correct hash."""
    assert validar_modelo_sha256(dummy_files["model"], dummy_files["correct_sha256"]) == True

def test_validar_modelo_sha256_invalid(dummy_files):
    """Test SHA256 validation with an incorrect hash."""
    assert validar_modelo_sha256(dummy_files["model"], dummy_files["incorrect_sha256"]) == False

def test_validar_modelo_sha256_file_not_found(dummy_files):
    """Test SHA256 validation when the model file does not exist."""
    assert validar_modelo_sha256(dummy_files["non_existent"], dummy_files["correct_sha256"]) == False

# --- Tests for verificar_assinatura ---

def test_verificar_assinatura_valid(dummy_files):
    """Test signature verification with a valid signature."""
    assert verificar_assinatura(dummy_files["model"], dummy_files["sig"], dummy_files["key"]) == True

def test_verificar_assinatura_invalid_signature(dummy_files):
    """Test signature verification with an invalid signature file."""
    assert verificar_assinatura(dummy_files["model"], dummy_files["corrupted_sig"], dummy_files["key"]) == False

def test_verificar_assinatura_model_not_found(dummy_files):
    """Test signature verification when the model file does not exist."""
    assert verificar_assinatura(dummy_files["non_existent"], dummy_files["sig"], dummy_files["key"]) == False

def test_verificar_assinatura_sig_not_found(dummy_files):
    """Test signature verification when the signature file does not exist."""
    assert verificar_assinatura(dummy_files["model"], dummy_files["non_existent"], dummy_files["key"]) == False

def test_verificar_assinatura_key_not_found(dummy_files):
    """Test signature verification when the public key file does not exist."""
    assert verificar_assinatura(dummy_files["model"], dummy_files["sig"], dummy_files["non_existent"]) == False

# TODO: Add tests for edge cases, different hash algorithms if applicable, etc.

