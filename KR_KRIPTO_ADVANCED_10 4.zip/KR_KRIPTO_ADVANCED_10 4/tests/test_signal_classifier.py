# Tests for src/strategies/signal_classifier.py

import pandas as pd
import numpy as np
import pytest
import asyncio # Adicionado
from unittest.mock import MagicMock, AsyncMock # Adicionado

# Adjust import path based on the project structure
from src.strategies.signal_classifier import prever_classe_corrigido_v12 as prever_classe
from src.infrastructure.fallback import GerenciadorFallback # Adicionado
from src.intelligence.governance.neural_governance import NeuralGovernor, ModelPerformanceTracker # Adicionado

# Fixture for sample DataFrame with RSI
@pytest.fixture
def df_with_rsi():
    """Provides a DataFrame with an RSI column for testing."""
    data = {
        # Other columns might be needed if the function evolves, but RSI is key
        # Let's simulate different RSI scenarios
        # Scenario 1: Oversold (RSI < 30)
        # Scenario 2: Overbought (RSI > 70)
        # Scenario 3: Neutral (30 <= RSI <= 70)
        # Scenario 4: Edge cases (NaN, exactly 30, exactly 70)
        # Scenario 5: Missing RSI column (tested separately)
        'RSI': [25.0, 80.0, 50.0, np.nan, 30.0, 70.0, 45.0],
        'Close': [100, 101, 102, 103, 104, 105, 106] # Adicionada coluna Close para evitar erros de ausência
    }
    df = pd.DataFrame(data)
    return df

@pytest.fixture
def mock_fallback_manager(config={}):
    return MagicMock(spec=GerenciadorFallback)

@pytest.fixture
def mock_governor():
    governor = MagicMock(spec=NeuralGovernor)
    governor.get_selected_model_id = MagicMock(return_value="test_model_id")
    # Mock predict como AsyncMock, pois é chamado com await
    governor.predict = AsyncMock(return_value=0.7) # Exemplo de retorno: probabilidade
    return governor

@pytest.fixture
def mock_tracker():
    return MagicMock(spec=ModelPerformanceTracker)

@pytest.mark.asyncio
async def test_prever_classe_compra(df_with_rsi, mock_fallback_manager, mock_governor, mock_tracker):
    """Test prediction when RSI indicates oversold (potential buy)."""
    # Teste com governor desativado para focar na lógica de fallback/placeholder
    classe, prob = await prever_classe(
        ativo="TESTBTC", 
        df=df_with_rsi, 
        indice_atual=0, 
        fallback_manager=mock_fallback_manager, 
        governor=mock_governor, 
        tracker=mock_tracker, 
        news_score=0.5, 
        governor_active=False
    )
    # A lógica atual de fallback retorna "nada", 0.5
    assert classe == "nada"
    assert prob == 0.5

@pytest.mark.asyncio
async def test_prever_classe_venda(df_with_rsi, mock_fallback_manager, mock_governor, mock_tracker):
    """Test prediction when RSI indicates overbought (potential sell)."""
    classe, prob = await prever_classe(
        ativo="TESTBTC", 
        df=df_with_rsi, 
        indice_atual=1, 
        fallback_manager=mock_fallback_manager, 
        governor=mock_governor, 
        tracker=mock_tracker, 
        news_score=0.5, 
        governor_active=False
    )
    assert classe == "nada"
    assert prob == 0.5

@pytest.mark.asyncio
async def test_prever_classe_nada(df_with_rsi, mock_fallback_manager, mock_governor, mock_tracker):
    """Test prediction when RSI is neutral."""
    classe, prob = await prever_classe(
        ativo="TESTBTC", 
        df=df_with_rsi, 
        indice_atual=2, 
        fallback_manager=mock_fallback_manager, 
        governor=mock_governor, 
        tracker=mock_tracker, 
        news_score=0.5, 
        governor_active=False
    )
    assert classe == "nada"
    assert prob == 0.5

@pytest.mark.asyncio
async def test_prever_classe_rsi_nan(df_with_rsi, mock_fallback_manager, mock_governor, mock_tracker):
    """Test prediction when RSI is NaN."""
    classe, prob = await prever_classe(
        ativo="TESTBTC", 
        df=df_with_rsi, 
        indice_atual=3, 
        fallback_manager=mock_fallback_manager, 
        governor=mock_governor, 
        tracker=mock_tracker, 
        news_score=0.5, 
        governor_active=False
    )
    assert classe == "nada"
    assert prob == 0.5

@pytest.mark.asyncio
async def test_prever_classe_rsi_edge_cases(df_with_rsi, mock_fallback_manager, mock_governor, mock_tracker):
    """Test prediction at the exact boundaries of RSI thresholds."""
    # RSI = 30
    classe_30, prob_30 = await prever_classe(
        ativo="TESTBTC", 
        df=df_with_rsi, 
        indice_atual=4, 
        fallback_manager=mock_fallback_manager, 
        governor=mock_governor, 
        tracker=mock_tracker, 
        news_score=0.5, 
        governor_active=False
    )
    assert classe_30 == "nada"
    assert prob_30 == 0.5
    
    # RSI = 70
    classe_70, prob_70 = await prever_classe(
        ativo="TESTBTC", 
        df=df_with_rsi, 
        indice_atual=5, 
        fallback_manager=mock_fallback_manager, 
        governor=mock_governor, 
        tracker=mock_tracker, 
        news_score=0.5, 
        governor_active=False
    )
    assert classe_70 == "nada"
    assert prob_70 == 0.5

@pytest.mark.asyncio
async def test_prever_classe_missing_rsi_column(mock_fallback_manager, mock_governor, mock_tracker):
    """Test prediction when the RSI column is missing."""
    df_no_rsi = pd.DataFrame({"Close": [100, 101, 102]})
    classe, prob = await prever_classe(
        ativo="TESTBTC", 
        df=df_no_rsi, 
        indice_atual=0, 
        fallback_manager=mock_fallback_manager, 
        governor=mock_governor, 
        tracker=mock_tracker, 
        news_score=0.5, 
        governor_active=False
    )
    assert classe == "nada"
    assert prob == 0.5

@pytest.mark.asyncio
async def test_prever_classe_with_governor_active(df_with_rsi, mock_fallback_manager, mock_governor, mock_tracker):
    """Test prediction when governor is active and returns a prediction."""
    # Configure o mock do governor para retornar uma probabilidade que resulte em "COMPRA"
    mock_governor.predict = AsyncMock(return_value=0.8) # Probabilidade alta -> COMPRA
    
    classe, prob = await prever_classe(
        ativo="TESTBTC", 
        df=df_with_rsi, 
        indice_atual=0, 
        fallback_manager=mock_fallback_manager, 
        governor=mock_governor, 
        tracker=mock_tracker, 
        news_score=0.5, 
        governor_active=True
    )
    assert classe == "COMPRA" # Esperado com base na lógica do governor em prever_classe
    assert prob == 0.8
    mock_governor.get_selected_model_id.assert_called_once()
    mock_governor.predict.assert_called_once_with(df=df_with_rsi, asset_name="TESTBTC", news_score=0.5)

@pytest.mark.asyncio
async def test_prever_classe_with_governor_predict_none(df_with_rsi, mock_fallback_manager, mock_governor, mock_tracker):
    """Test prediction when governor is active but its predict method returns None."""
    mock_governor.predict = AsyncMock(return_value=None)
    
    classe, prob = await prever_classe(
        ativo="TESTBTC", 
        df=df_with_rsi, 
        indice_atual=0, 
        fallback_manager=mock_fallback_manager, 
        governor=mock_governor, 
        tracker=mock_tracker, 
        news_score=0.5, 
        governor_active=True
    )
    # Espera-se fallback para "nada", 0.5
    assert classe == "nada"
    assert prob == 0.5

@pytest.mark.asyncio
async def test_prever_classe_with_governor_exception(df_with_rsi, mock_fallback_manager, mock_governor, mock_tracker):
    """Test prediction when governor is active but its predict method raises an exception."""
    mock_governor.predict = AsyncMock(side_effect=Exception("Governor Error"))
    
    classe, prob = await prever_classe(
        ativo="TESTBTC", 
        df=df_with_rsi, 
        indice_atual=0, 
        fallback_manager=mock_fallback_manager, 
        governor=mock_governor, 
        tracker=mock_tracker, 
        news_score=0.5, 
        governor_active=True
    )
    # Espera-se fallback para "nada", 0.5
    assert classe == "nada"
    assert prob == 0.5

# Note: The original function prever_classe_corrigido_v12 has a placeholder logic
# for RSI-based classification when governor is not active. The current tests reflect
# that this placeholder logic always returns "nada", 0.5.
# If the RSI logic were to be implemented, these tests would need to be updated.

