# /home/ubuntu/kripto_analysis/KR_KRIPTO_ADVANCED_REORGANIZED/tests/test_signal_processor_integration.py

import pytest
import asyncio
import pandas as pd
import logging

# Import components from the project
from src.core.signal_processor import analisar_sinal
from src.intelligence.attack_detector import AttackDetector
from src.infrastructure.memory import MemoriaTemporal
from src.realtime.book_processor import BookProcessor
from src.infrastructure.fallback import GerenciadorFallback
# Import stubs or mocks if needed for other dependencies like RL, Governance, etc.

# Import test data generation functions
from tests.test_integration_data import create_volume_spike_df, create_spoofing_sequence, create_post_spoofing_df

# Basic config for testing
TEST_CONFIG = {
    "attack_detector": {
        "volume_spike_window": 5,
        "volume_spike_threshold_std": 3.0,
        "spoofing_threshold_ratio": 5.0,
        "spoofing_depth_levels": 3,
        "spoofing_history_size": 10,
        "spoofing_cancel_time_ms": 500,
        "spoofing_min_absolute_qty": 1.0
    },
    "limiar_compra": 0.65,
    "limiar_venda": 0.35,
    # Add other necessary config keys if analisar_sinal depends on them
}

# Fixtures
@pytest.fixture
def attack_detector():
    return AttackDetector(TEST_CONFIG.get("attack_detector"))

@pytest.fixture
def memoria_temporal():
    # --- CORRECTION: Remove config argument as __init__ takes no args --- 
    # Simple stub or mock if state is not critical for these tests
    return MemoriaTemporal(config={})
    # --- END CORRECTION ---

@pytest.fixture
def book_processor():
    # Simple stub
    return BookProcessor(config={'ativo': "TESTBTC"})

@pytest.fixture
def fallback_manager(config={}):
    # Simple stub or mock
    class MockFallbackManager:
        def get_active_model(self, *args, **kwargs):
            return None # Or a mock model if needed
        def get_model_and_scaler_paths(self, *args, **kwargs):
            return ("mock_model_path.h5", "mock_scaler_path.pkl") # Correção adicionada
    return MockFallbackManager()

# Test for Volume Spike Detection Integration
@pytest.mark.asyncio
async def test_analisar_sinal_discards_on_volume_spike(
    attack_detector, memoria_temporal, book_processor, fallback_manager, caplog
):
    """Verify that analisar_sinal discards the signal when volume spike is detected."""
    # --- CORRECTION: Configure caplog for the specific logger --- 
    caplog.set_level(logging.WARNING, logger="kr_kripto_processor")
    # --- END CORRECTION ---
    ativo = "TESTBTC"
    df_spike = create_volume_spike_df(window=5, spike_multiplier=5.0)
    
    # Mock other dependencies as needed (RL, Governance, ContextSwitcher, etc.)
    processadores_book = {ativo: book_processor}
    agentes_rl = {}
    ambientes_rl = {}
    
    # Call analisar_sinal
    # analisar_sinal doesn't return a specific value on discard, it just returns early.
    # We check if the warning log for discarding was generated.
    await analisar_sinal(
        ativo=ativo,
        df_original=df_spike,
        memoria_temporal=memoria_temporal,
        processadores_book=processadores_book,
        agentes_rl=agentes_rl,
        ambientes_rl=ambientes_rl,
        config=TEST_CONFIG,
        fallback_manager=fallback_manager,
        attack_detector=attack_detector
        # Pass other mocked dependencies here if needed
    )
    
    # Check if the specific warning message was logged
    assert any(
        f"[{ativo}] Sinal descartado devido a possível volume artificial detectado." in record.message
        for record in caplog.records
        # Ensure we are checking records from the correct logger
        if record.name == "kr_kripto_processor" and record.levelno == logging.WARNING
    ), "Warning log for discarding signal due to volume spike not found."

# Test for Spoofing Detection Integration
@pytest.mark.asyncio
async def test_analisar_sinal_discards_on_spoofing(
    attack_detector, memoria_temporal, book_processor, fallback_manager, caplog
):
    """Verify that analisar_sinal discards the signal when spoofing is confirmed."""
    # --- CORRECTION: Configure caplog for the specific logger --- 
    caplog.set_level(logging.WARNING, logger="kr_kripto_processor")
    # --- END CORRECTION ---
    ativo = "TESTBTC"
    
    # 1. Simulate the spoofing sequence to set the detector's internal flag
    spoofing_updates = create_spoofing_sequence(cancel_time_ms=200) # Ensure cancellation is fast
    for update in spoofing_updates:
        # We call detect_spoofing mainly for its side effect of setting the flag
        attack_detector.detect_spoofing(update)
        # Optional: Add a small delay if needed, though likely not necessary here
        # await asyncio.sleep(0.01)
        
    # At this point, the last update should have triggered the confirmation
    # and set _spoofing_confirmed_recently to True inside the detector.
    
    # 2. Create subsequent kline data for analisar_sinal
    df_post_spoofing = create_post_spoofing_df()
    
    # 3. Mock other dependencies
    processadores_book = {ativo: book_processor}
    agentes_rl = {}
    ambientes_rl = {}
    
    # 4. Call analisar_sinal - it should now check the flag and discard
    await analisar_sinal(
        ativo=ativo,
        df_original=df_post_spoofing, # Use the data *after* spoofing was confirmed
        memoria_temporal=memoria_temporal,
        processadores_book=processadores_book,
        agentes_rl=agentes_rl,
        ambientes_rl=ambientes_rl,
        config=TEST_CONFIG,
        fallback_manager=fallback_manager,
        attack_detector=attack_detector
    )
    
    # 5. Check if the specific warning message was logged
    assert any(
        f"[{ativo}] Sinal descartado devido a spoofing confirmado recentemente." in record.message
        for record in caplog.records
        # Ensure we are checking records from the correct logger
        if record.name == "kr_kripto_processor" and record.levelno == logging.WARNING
    ), "Warning log for discarding signal due to spoofing not found."

