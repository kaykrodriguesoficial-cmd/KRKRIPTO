# Arquivo de teste temporário para inspecionar o nome do mock
import pytest
from unittest.mock import patch, AsyncMock
import asyncio

# Este import é necessário para que o patch funcione corretamente no target
# mesmo que não seja usado diretamente no teste mínimo.
from src.core import signal_processor

@pytest.mark.asyncio
@patch("src.core.signal_processor.enviar_telegram", new_callable=AsyncMock)
async def test_inspect_mock_name(mock_generated_name_for_enviar_telegram):
    print(f"Nome do mock recebido pela função de teste: {mock_generated_name_for_enviar_telegram}")
    # Tentar imprimir o nome do mock, se disponível como atributo
    try:
        print(f"mock_generated_name_for_enviar_telegram.__name__: {mock_generated_name_for_enviar_telegram.__name__}")
    except AttributeError:
        print("mock_generated_name_for_enviar_telegram não possui atributo __name__.")
    assert True # Teste mínimo para garantir a execução

