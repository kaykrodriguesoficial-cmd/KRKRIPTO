#!/usr/bin/env python3
"""
Script para testar a conexão aprimorada com a API da Binance.
Este script executa o sistema KR_KRIPTO_ADVANCED_COPIA com a versão aprimorada
do BinanceStreamManager por um período estendido para validar a conexão contínua.

Uso:
    python3 teste_conexao_binance_aprimorado.py
"""

import sys
import tempfile
import os
import asyncio
import logging
from logging.handlers import TimedRotatingFileHandler
import json
import time
import datetime
from pathlib import Path

# Adicionar o diretório do projeto ao PYTHONPATH
project_dir = Path(os.path.join(tempfile.gettempdir(), "KR_KRIPTO_ADVANCED_COPIA"))
sys.path.append(str(project_dir))

# Configurar logging com rotação
log_file = f"{project_dir}/logs/teste_conexao_binance_{int(time.time())}.log"
os.makedirs(os.path.dirname(log_file), exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        TimedRotatingFileHandler(
            filename=log_file,
            when='midnight',
            interval=1,
            backupCount=30,
            encoding='utf-8'
        ),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("teste_conexao_binance")

# Importar a versão aprimorada do BinanceStreamManager
try:
    from src.core.binance_stream_enhanced import BinanceStreamManager
    logger.info("Versão aprimorada do BinanceStreamManager importada com sucesso.")
except ImportError as e:
    logger.error(f"Erro ao importar BinanceStreamManager aprimorado: {e}")
    sys.exit(1)

# Classes Mock para componentes necessários
class MemoriaTemporalMock:
    def __init__(self):
        self.data = {}
    
    async def registrar_evento(self, *args, **kwargs):
        logger.debug("Mock: MemoriaTemporal.registrar_evento chamado")
        return True
    
    async def consultar_eventos(self, *args, **kwargs):
        logger.debug("Mock: MemoriaTemporal.consultar_eventos chamado")
        return []

class GerenciadorFallbackMock:
    def __init__(self):
        self.fallback_active = False
    
    def is_fallback_active(self, *args, **kwargs):
        logger.debug("Mock: GerenciadorFallback.is_fallback_active chamado")
        return self.fallback_active
    
    def activate_fallback(self, *args, **kwargs):
        logger.debug("Mock: GerenciadorFallback.activate_fallback chamado")
        self.fallback_active = True
        return True

class GovernorMock:
    def __init__(self):
        pass
    
    async def evaluate_signal(self, *args, **kwargs):
        logger.debug("Mock: Governor.evaluate_signal chamado")
        return True, 1.0

class TrackerMock:
    def __init__(self):
        pass
    
    def track_model_performance(self, *args, **kwargs):
        logger.debug("Mock: Tracker.track_model_performance chamado")
        return True

class ContextSwitcherMock:
    def __init__(self):
        pass
    
    def should_switch_context(self, *args, **kwargs):
        logger.debug("Mock: ContextSwitcher.should_switch_context chamado")
        return False
    
    def get_current_context(self, *args, **kwargs):
        logger.debug("Mock: ContextSwitcher.get_current_context chamado")
        return "default"

class AttackDetectorMock:
    def __init__(self):
        pass
    
    def detect_spoofing(self, *args, **kwargs):
        logger.debug("Mock: AttackDetector.detect_spoofing chamado")
        return False

class BookProcessorMock:
    def __init__(self):
        self.state = None
    
    async def process_book_update(self, *args, **kwargs):
        logger.debug("Mock: BookProcessor.process_book_update chamado")
        return True

async def mock_analisar_sinal(**kwargs):
    """Função mock para analisar_sinal."""
    logger.debug("Mock: analisar_sinal chamado com argumentos: " + str(kwargs.keys()))
    return {"status": "success", "signal": None}

async def carregar_configuracao():
    """Carrega a configuração do arquivo config.json."""
    try:
        config_path = project_dir / "config.json"
        with open(config_path, 'r') as f:
            config = json.load(f)
        logger.info(f"Configuração carregada com sucesso: {config_path}")
        return config
    except Exception as e:
        logger.error(f"Erro ao carregar configuração: {e}")
        return None

async def criar_contexto_robusto(config):
    """Cria um contexto robusto com mocks para todos os componentes necessários."""
    # Criar instâncias de mocks
    memoria_temporal = MemoriaTemporalMock()
    gerenciador_fallback = GerenciadorFallbackMock()
    governor = GovernorMock()
    tracker = TrackerMock()
    context_switcher = ContextSwitcherMock()
    attack_detector = AttackDetectorMock()
    
    # Criar processadores de book para cada asset
    assets = config.get("assets", ["BTCUSDT"])
    processadores_book = {asset: BookProcessorMock() for asset in assets}
    
    return {
        "configuracao_global": config,
        "dataframes": {},
        "last_kline_time": {},
        "dataframes_lock": asyncio.Lock(),
        "processadores_book": processadores_book,
        "memoria_temporal": memoria_temporal,
        "gerenciador_fallback": gerenciador_fallback,
        "analisar_sinal_func": mock_analisar_sinal,
        "governor": governor,
        "tracker": tracker,
        "context_switcher": context_switcher,
        "strategy_config": config.get("strategy_config", {}),
        "attack_detector": attack_detector,
        "agentes_rl": {},
        "ambientes_rl": {},
        "operador": None,
        "news_provider": None
    }

async def monitorar_status_conexao(stream_manager, duracao_teste):
    """Monitora e registra o status da conexão periodicamente."""
    inicio = time.time()
    intervalo = 10  # segundos entre verificações
    
    while (time.time() - inicio) < duracao_teste:
        status = stream_manager.get_connection_status()
        logger.info(f"Status atual das conexões: {json.dumps(status, indent=2)}")
        
        # Verificar se há conexões ativas
        conexoes_ativas = sum(1 for s in status.values() if s["connected"])
        logger.info(f"Conexões ativas: {conexoes_ativas}/{len(status)}")
        
        # Calcular tempo restante
        tempo_decorrido = time.time() - inicio
        tempo_restante = duracao_teste - tempo_decorrido
        logger.info(f"Tempo decorrido: {tempo_decorrido:.1f}s, Tempo restante: {tempo_restante:.1f}s")
        
        await asyncio.sleep(intervalo)

async def main():
    """Função principal do teste."""
    logger.info("Iniciando teste de conexão aprimorada com a API da Binance")
    
    # Definir duração do teste (em segundos)
    duracao_teste = 120  # 2 minutos
    
    # Carregar configuração
    config = await carregar_configuracao()
    if not config:
        logger.error("Não foi possível carregar a configuração. Encerrando teste.")
        return
    
    # Verificar configuração de testnet
    is_testnet = config.get("testnet", False)
    logger.info(f"Modo Testnet: {is_testnet}")
    
    # Verificar assets configurados
    assets = config.get("assets", ["BTCUSDT"])
    logger.info(f"Assets configurados: {assets}")
    
    # Criar contexto robusto com mocks
    contexto = await criar_contexto_robusto(config)
    logger.info("Contexto robusto criado para o teste com mocks para todos os componentes necessários")
    
    try:
        # Inicializar BinanceStreamManager aprimorado
        stream_manager = BinanceStreamManager(config={})
        logger.info("BinanceStreamManager aprimorado inicializado")
        
        # Iniciar streams para os assets
        logger.info(f"Iniciando streams para assets: {assets}")
        tasks = await stream_manager.start_streams_for_assets(assets)
        
        # Iniciar monitoramento de status
        monitor_task = asyncio.create_task(monitorar_status_conexao(stream_manager, duracao_teste))
        
        # Aguardar pelo tempo definido
        logger.info(f"Teste em execução por {duracao_teste} segundos...")
        await asyncio.sleep(duracao_teste)
        
        # Encerrar monitoramento
        monitor_task.cancel()
        try:
            await monitor_task
        except asyncio.CancelledError:
            pass
        
        # Obter status final
        status_final = stream_manager.get_connection_status()
        logger.info(f"Status final das conexões: {json.dumps(status_final, indent=2)}")
        
        # Parar streams
        logger.info("Encerrando streams...")
        await stream_manager.stop_streams()
        
        # Verificar resultados
        conexoes_bem_sucedidas = all(s["connected"] for s in status_final.values())
        mensagens_recebidas = all(s["messages_received"] > 0 for s in status_final.values())
        
        if conexoes_bem_sucedidas and mensagens_recebidas:
            logger.info("TESTE CONCLUÍDO COM SUCESSO: Conexão estabelecida e mensagens recebidas para todos os assets.")
        else:
            logger.warning("TESTE CONCLUÍDO COM RESSALVAS: Nem todas as conexões foram bem-sucedidas ou receberam mensagens.")
        
        # Resumo do teste
        logger.info("Resumo do teste:")
        for asset, status in status_final.items():
            logger.info(f"Asset: {asset}")
            logger.info(f"  - Conectado: {status['connected']}")
            logger.info(f"  - Mensagens recebidas: {status['messages_received']}")
            logger.info(f"  - Status de autenticação: {status['authentication_status']}")
            logger.info(f"  - Tempo de conexão: {status['connection_time']:.1f}s")
            if status['last_message_time'] is not None:
                logger.info(f"  - Tempo desde última mensagem: {status['last_message_time']:.1f}s")
        
    except Exception as e:
        logger.error(f"Erro durante o teste: {e}", exc_info=True)
    finally:
        logger.info("Teste de conexão aprimorada com a API da Binance concluído")

if __name__ == "__main__":
    asyncio.run(main())
