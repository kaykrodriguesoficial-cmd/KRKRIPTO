#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Teste de Desempenho sob Carga para KR_KRIPTO_ADVANCED_COPIA

Este script realiza testes de desempenho sob diferentes níveis de carga para validar
a estabilidade, responsividade e eficiência do sistema KR_KRIPTO_ADVANCED_COPIA.

Autor: Manus
Data: 16/05/2025
"""

import os
import sys
import time
import json
import logging
import asyncio
import argparse
import psutil
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
import matplotlib.pyplot as plt
from logging.handlers import TimedRotatingFileHandler

# Adicionar diretório raiz ao path para importações relativas
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '.')))

# Configurar logging
log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logs')
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, 'teste_desempenho_carga.log')

# Configurar logger com rotação diária
logger = logging.getLogger("teste_desempenho")
if not logger.handlers:
    handler = TimedRotatingFileHandler(
        filename=log_file,
        when='midnight',
        interval=1,
        backupCount=30,
        encoding='utf-8'
    )
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    
    # Adicionar handler para console também
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    logger.setLevel(logging.INFO)

class TesteDesempenhoCarga:
    """Classe para testes de desempenho sob carga."""
    
    def __init__(self, config: dict):
        """Inicializa o teste de desempenho."""
        self.config = config or self._carregar_config_padrao()
        self.resultados = {
            "inicio": datetime.now().isoformat(),
            "testes": [],
            "status_geral": "pendente",
            "metricas_sistema": {
                "cpu": [],
                "memoria": [],
                "disco": [],
                "rede": []
            }
        }
        
        # Criar diretório para gráficos
        self.graficos_dir = os.path.join(log_dir, 'graficos')
        os.makedirs(self.graficos_dir, exist_ok=True)
        
        logger.info(f"Teste de Desempenho sob Carga inicializado com configuração: {json.dumps(self.config, indent=2)}")
    
    def _carregar_config_padrao(self):
        """Carrega configuração padrão para o teste."""
        return {
            "niveis_carga": [
                {"nome": "leve", "threads": 2, "duracao_segundos": 30, "intervalo_ms": 500},
                {"nome": "medio", "threads": 5, "duracao_segundos": 30, "intervalo_ms": 200},
                {"nome": "pesado", "threads": 10, "duracao_segundos": 30, "intervalo_ms": 100}
            ],
            "ativos": ["BTCUSDT", "ETHUSDT", "BNBUSDT", "ADAUSDT", "XRPUSDT"],
            "metricas": {
                "latencia": True,
                "throughput": True,
                "uso_recursos": True,
                "estabilidade": True
            },
            "limites": {
                "cpu_max": 80,  # porcentagem
                "memoria_max": 70,  # porcentagem
                "latencia_max_ms": 500,
                "erros_max": 5
            }
        }
    
    def _gerar_dados_simulados(self, ativo, tamanho=100):
        """Gera dados simulados para teste."""
        logger.info(f"Gerando dados simulados para {ativo}, tamanho={tamanho}")
        
        # Data inicial (30 dias atrás)
        data_inicial = datetime.now() - timedelta(days=30)
        
        # Gerar timestamps
        timestamps = [data_inicial + timedelta(minutes=i*15) for i in range(tamanho)]
        
        # Gerar preços com tendência e volatilidade aleatória
        preco_base = {
            "BTCUSDT": 50000,
            "ETHUSDT": 3000,
            "BNBUSDT": 500,
            "ADAUSDT": 1.5,
            "XRPUSDT": 0.8
        }.get(ativo, 100)
        
        # Adicionar tendência e volatilidade
        np.random.seed(int(time.time()) % 10000)
        tendencia = np.random.choice([-1, 1]) * np.random.uniform(0.0001, 0.001)
        volatilidade = np.random.uniform(0.005, 0.02)
        
        precos = []
        preco_atual = preco_base
        for _ in range(tamanho):
            # Aplicar tendência e volatilidade
            mudanca_percentual = tendencia + np.random.normal(0, volatilidade)
            preco_atual *= (1 + mudanca_percentual)
            precos.append(preco_atual)
        
        # Gerar volumes
        volumes = np.random.uniform(preco_base * 10, preco_base * 1000, tamanho)
        
        # Criar DataFrame
        df = pd.DataFrame({
            'timestamp': timestamps,
            'open': precos,
            'high': [p * (1 + np.random.uniform(0, 0.01)) for p in precos],
            'low': [p * (1 - np.random.uniform(0, 0.01)) for p in precos],
            'close': [p * (1 + np.random.uniform(-0.005, 0.005)) for p in precos],
            'volume': volumes
        })
        
        return df
    
    def _monitorar_recursos(self, intervalo=1.0, evento_parada=None):
        """Monitora recursos do sistema em thread separada."""
        logger.info(f"Iniciando monitoramento de recursos com intervalo={intervalo}s")
        
        while not evento_parada.is_set():
            # Coletar métricas
            cpu_percent = psutil.cpu_percent(interval=None)
            memoria_percent = psutil.virtual_memory().percent
            disco_percent = psutil.disk_usage('/').percent
            
            # Coletar estatísticas de rede (bytes enviados/recebidos)
            rede_stats = psutil.net_io_counters()
            
            # Armazenar métricas
            timestamp = datetime.now().isoformat()
            self.resultados["metricas_sistema"]["cpu"].append((timestamp, cpu_percent))
            self.resultados["metricas_sistema"]["memoria"].append((timestamp, memoria_percent))
            self.resultados["metricas_sistema"]["disco"].append((timestamp, disco_percent))
            self.resultados["metricas_sistema"]["rede"].append((timestamp, {
                "bytes_enviados": rede_stats.bytes_sent,
                "bytes_recebidos": rede_stats.bytes_recv
            }))
            
            # Verificar limites
            if cpu_percent > self.config["limites"]["cpu_max"]:
                logger.warning(f"Uso de CPU acima do limite: {cpu_percent}% > {self.config['limites']['cpu_max']}%")
            
            if memoria_percent > self.config["limites"]["memoria_max"]:
                logger.warning(f"Uso de memória acima do limite: {memoria_percent}% > {self.config['limites']['memoria_max']}%")
            
            # Aguardar próximo intervalo
            time.sleep(intervalo)
    
    async def _simular_processamento(self, ativo, nivel_carga):
        """Simula o processamento de dados para um ativo específico."""
        try:
            # Gerar dados simulados
            df = self._gerar_dados_simulados(ativo, tamanho=100)
            
            # Simular processamento com diferentes cargas
            inicio = time.time()
            
            # Aplicar indicadores técnicos (simulação de carga de processamento)
            # SMA - Simple Moving Average
            janela = 20
            df['sma'] = df['close'].rolling(window=janela).mean()
            
            # EMA - Exponential Moving Average
            df['ema'] = df['close'].ewm(span=janela, adjust=False).mean()
            
            # Bollinger Bands
            df['std'] = df['close'].rolling(window=janela).std()
            df['upper_band'] = df['sma'] + (df['std'] * 2)
            df['lower_band'] = df['sma'] - (df['std'] * 2)
            
            # RSI - Relative Strength Index
            delta = df['close'].diff()
            ganhos = delta.copy()
            perdas = delta.copy()
            ganhos[ganhos < 0] = 0
            perdas[perdas > 0] = 0
            avg_ganho = ganhos.rolling(window=14).mean()
            avg_perda = abs(perdas.rolling(window=14).mean())
            rs = avg_ganho / avg_perda
            df['rsi'] = 100 - (100 / (1 + rs))
            
            # MACD - Moving Average Convergence Divergence
            df['ema12'] = df['close'].ewm(span=12, adjust=False).mean()
            df['ema26'] = df['close'].ewm(span=26, adjust=False).mean()
            df['macd'] = df['ema12'] - df['ema26']
            df['signal'] = df['macd'].ewm(span=9, adjust=False).mean()
            
            # Simular atraso baseado no nível de carga
            await asyncio.sleep(nivel_carga["intervalo_ms"] / 1000.0)
            
            # Calcular tempo de processamento
            tempo_processamento = time.time() - inicio
            
            return {
                "ativo": ativo,
                "tempo_processamento": tempo_processamento,
                "registros_processados": len(df),
                "indicadores_calculados": 7,  # SMA, EMA, Bollinger (3), RSI, MACD (2)
                "status": "sucesso"
            }
            
        except Exception as e:
            logger.error(f"Erro ao processar {ativo}: {str(e)}", exc_info=True)
            return {
                "ativo": ativo,
                "tempo_processamento": 0,
                "registros_processados": 0,
                "indicadores_calculados": 0,
                "status": "erro",
                "erro": str(e)
            }
    
    async def _executar_nivel_carga(self, nivel_carga):
        """Executa teste para um nível de carga específico."""
        logger.info(f"Iniciando teste com nível de carga: {nivel_carga['nome']}")
        logger.info(f"Configuração: threads={nivel_carga['threads']}, "
                   f"duração={nivel_carga['duracao_segundos']}s, "
                   f"intervalo={nivel_carga['intervalo_ms']}ms")
        
        inicio_teste = time.time()
        resultados_nivel = {
            "nivel": nivel_carga['nome'],
            "config": nivel_carga,
            "inicio": datetime.now().isoformat(),
            "resultados_ativos": [],
            "metricas": {
                "tempo_total": 0,
                "tempo_medio_processamento": 0,
                "throughput": 0,
                "total_processado": 0,
                "erros": 0
            }
        }
        
        # Iniciar evento de parada para monitoramento
        evento_parada = asyncio.Event()
        
        # Iniciar thread de monitoramento
        with ThreadPoolExecutor(max_workers=1) as executor:
            future_monitor = executor.submit(
                self._monitorar_recursos, 
                intervalo=1.0, 
                evento_parada=evento_parada
            )
            
            # Executar tarefas de processamento
            tarefas = []
            total_iteracoes = int(nivel_carga['duracao_segundos'] * 1000 / nivel_carga['intervalo_ms'])
            
            for _ in range(total_iteracoes):
                for _ in range(nivel_carga['threads']):
                    # Selecionar ativo aleatório
                    ativo = np.random.choice(self.config['ativos'])
                    # Criar tarefa de processamento
                    tarefa = asyncio.create_task(self._simular_processamento(ativo, nivel_carga))
                    tarefas.append(tarefa)
                
                # Aguardar intervalo entre lotes
                await asyncio.sleep(nivel_carga['intervalo_ms'] / 1000.0)
            
            # Aguardar conclusão de todas as tarefas
            resultados_tarefas = await asyncio.gather(*tarefas, return_exceptions=True)
            
            # Parar monitoramento
            evento_parada.set()
            future_monitor.result()  # Aguardar conclusão do monitoramento
        
        # Processar resultados
        tempo_total = time.time() - inicio_teste
        sucessos = [r for r in resultados_tarefas if isinstance(r, dict) and r.get('status') == 'sucesso']
        erros = [r for r in resultados_tarefas if isinstance(r, Exception) or 
                (isinstance(r, dict) and r.get('status') != 'sucesso')]
        
        # Calcular métricas
        if sucessos:
            tempo_medio = sum(r['tempo_processamento'] for r in sucessos) / len(sucessos)
            total_processado = sum(r['registros_processados'] for r in sucessos)
            throughput = total_processado / tempo_total if tempo_total > 0 else 0
        else:
            tempo_medio = 0
            total_processado = 0
            throughput = 0
        
        # Atualizar resultados
        resultados_nivel['metricas']['tempo_total'] = tempo_total
        resultados_nivel['metricas']['tempo_medio_processamento'] = tempo_medio
        resultados_nivel['metricas']['throughput'] = throughput
        resultados_nivel['metricas']['total_processado'] = total_processado
        resultados_nivel['metricas']['erros'] = len(erros)
        resultados_nivel['resultados_ativos'] = sucessos
        resultados_nivel['fim'] = datetime.now().isoformat()
        
        # Verificar limites
        status = "sucesso"
        if tempo_medio * 1000 > self.config['limites']['latencia_max_ms']:
            logger.warning(f"Latência média acima do limite: {tempo_medio*1000:.2f}ms > {self.config['limites']['latencia_max_ms']}ms")
            status = "alerta"
        
        if len(erros) > self.config['limites']['erros_max']:
            logger.error(f"Número de erros acima do limite: {len(erros)} > {self.config['limites']['erros_max']}")
            status = "falha"
        
        resultados_nivel['status'] = status
        
        # Adicionar aos resultados gerais
        self.resultados['testes'].append(resultados_nivel)
        
        logger.info(f"Teste de nível {nivel_carga['nome']} concluído com status: {status}")
        logger.info(f"Métricas: tempo_total={tempo_total:.2f}s, "
                   f"tempo_medio={tempo_medio*1000:.2f}ms, "
                   f"throughput={throughput:.2f} reg/s, "
                   f"total_processado={total_processado}, "
                   f"erros={len(erros)}")
        
        return resultados_nivel
    
    async def executar_todos_testes(self):
        """Executa todos os testes de carga configurados."""
        logger.info("Iniciando bateria de testes de desempenho sob carga")
        
        inicio_geral = time.time()
        
        try:
            # Executar testes para cada nível de carga
            for nivel_carga in self.config['niveis_carga']:
                await self._executar_nivel_carga(nivel_carga)
            
            # Calcular resultado geral
            sucessos = sum(1 for teste in self.resultados['testes'] if teste['status'] == 'sucesso')
            alertas = sum(1 for teste in self.resultados['testes'] if teste['status'] == 'alerta')
            falhas = sum(1 for teste in self.resultados['testes'] if teste['status'] == 'falha')
            
            if falhas > 0:
                self.resultados['status_geral'] = 'falha'
            elif alertas > 0:
                self.resultados['status_geral'] = 'alerta'
            else:
                self.resultados['status_geral'] = 'sucesso'
            
            self.resultados['fim'] = datetime.now().isoformat()
            self.resultados['duracao_segundos'] = time.time() - inicio_geral
            self.resultados['resumo'] = {
                'total': len(self.resultados['testes']),
                'sucesso': sucessos,
                'alerta': alertas,
                'falha': falhas
            }
            
            # Gerar gráficos
            self._gerar_graficos()
            
            # Salvar resultados
            self._salvar_resultados()
            
            logger.info(f"Testes concluídos. Status geral: {self.resultados['status_geral']}")
            logger.info(f"Resumo: {sucessos} sucessos, {alertas} alertas, {falhas} falhas")
            
            return self.resultados
            
        except Exception as e:
            logger.error(f"Erro ao executar testes: {str(e)}", exc_info=True)
            self.resultados['status_geral'] = 'erro'
            self.resultados['erro'] = str(e)
            return self.resultados
    
    def _gerar_graficos(self):
        """Gera gráficos com os resultados dos testes."""
        logger.info("Gerando gráficos de resultados")
        
        try:
            # 1. Gráfico de uso de CPU
            plt.figure(figsize=(10, 6))
            timestamps = [datetime.fromisoformat(t) for t, _ in self.resultados['metricas_sistema']['cpu']]
            valores = [v for _, v in self.resultados['metricas_sistema']['cpu']]
            plt.plot(timestamps, valores, 'b-', label='CPU (%)')
            plt.axhline(y=self.config['limites']['cpu_max'], color='r', linestyle='--', label=f"Limite ({self.config['limites']['cpu_max']}%)")
            plt.title('Uso de CPU Durante Teste de Carga')
            plt.xlabel('Tempo')
            plt.ylabel('Uso de CPU (%)')
            plt.legend()
            plt.grid(True)
            plt.tight_layout()
            caminho_grafico = os.path.join(self.graficos_dir, 'cpu_usage.png')
            plt.savefig(caminho_grafico)
            plt.close()
            
            # 2. Gráfico de uso de memória
            plt.figure(figsize=(10, 6))
            timestamps = [datetime.fromisoformat(t) for t, _ in self.resultados['metricas_sistema']['memoria']]
            valores = [v for _, v in self.resultados['metricas_sistema']['memoria']]
            plt.plot(timestamps, valores, 'g-', label='Memória (%)')
            plt.axhline(y=self.config['limites']['memoria_max'], color='r', linestyle='--', label=f"Limite ({self.config['limites']['memoria_max']}%)")
            plt.title('Uso de Memória Durante Teste de Carga')
            plt.xlabel('Tempo')
            plt.ylabel('Uso de Memória (%)')
            plt.legend()
            plt.grid(True)
            plt.tight_layout()
            caminho_grafico = os.path.join(self.graficos_dir, 'memory_usage.png')
            plt.savefig(caminho_grafico)
            plt.close()
            
            # 3. Gráfico de latência por nível de carga
            plt.figure(figsize=(10, 6))
            niveis = [teste['nivel'] for teste in self.resultados['testes']]
            latencias = [teste['metricas']['tempo_medio_processamento'] * 1000 for teste in self.resultados['testes']]
            plt.bar(niveis, latencias, color='orange')
            plt.axhline(y=self.config['limites']['latencia_max_ms'], color='r', linestyle='--', label=f"Limite ({self.config['limites']['latencia_max_ms']}ms)")
            plt.title('Latência Média por Nível de Carga')
            plt.xlabel('Nível de Carga')
            plt.ylabel('Latência (ms)')
            plt.legend()
            plt.grid(True, axis='y')
            plt.tight_layout()
            caminho_grafico = os.path.join(self.graficos_dir, 'latency_by_load.png')
            plt.savefig(caminho_grafico)
            plt.close()
            
            # 4. Gráfico de throughput por nível de carga
            plt.figure(figsize=(10, 6))
            niveis = [teste['nivel'] for teste in self.resultados['testes']]
            throughputs = [teste['metricas']['throughput'] for teste in self.resultados['testes']]
            plt.bar(niveis, throughputs, color='purple')
            plt.title('Throughput por Nível de Carga')
            plt.xlabel('Nível de Carga')
            plt.ylabel('Throughput (registros/s)')
            plt.grid(True, axis='y')
            plt.tight_layout()
            caminho_grafico = os.path.join(self.graficos_dir, 'throughput_by_load.png')
            plt.savefig(caminho_grafico)
            plt.close()
            
            logger.info(f"Gráficos gerados com sucesso no diretório: {self.graficos_dir}")
            
        except Exception as e:
            logger.error(f"Erro ao gerar gráficos: {str(e)}", exc_info=True)
    
    def _salvar_resultados(self):
        """Salva os resultados em arquivo JSON."""
        try:
            # Salvar resultados detalhados
            resultados_file = os.path.join(log_dir, 'teste_desempenho_resultados.json')
            with open(resultados_file, 'w') as f:
                json.dump(self.resultados, f, indent=2)
            
            # Salvar resumo em formato mais legível
            resumo = {
                'status_geral': self.resultados['status_geral'],
                'inicio': self.resultados['inicio'],
                'fim': self.resultados['fim'],
                'duracao_segundos': self.resultados['duracao_segundos'],
                'resumo': self.resultados['resumo'],
                'testes': []
            }
            
            for teste in self.resultados['testes']:
                resumo['testes'].append({
                    'nivel': teste['nivel'],
                    'status': teste['status'],
                    'tempo_medio_ms': teste['metricas']['tempo_medio_processamento'] * 1000,
                    'throughput': teste['metricas']['throughput'],
                    'erros': teste['metricas']['erros']
                })
            
            resumo_file = os.path.join(log_dir, 'teste_desempenho_resumo.json')
            with open(resumo_file, 'w') as f:
                json.dump(resumo, f, indent=2)
            
            logger.info(f"Resultados salvos em {resultados_file}")
            logger.info(f"Resumo salvo em {resumo_file}")
            
            return resultados_file, resumo_file
            
        except Exception as e:
            logger.error(f"Erro ao salvar resultados: {str(e)}", exc_info=True)
            return None, None
    
    def gerar_relatorio_html(self):
        """Gera relatório HTML com os resultados dos testes."""
        try:
            logger.info("Gerando relatório HTML")
            
            # Caminho para o relatório
            relatorio_file = os.path.join(log_dir, 'relatorio_desempenho.html')
            
            # Gerar conteúdo HTML
            html_content = f"""
            <!DOCTYPE html>
            <html lang="pt-BR">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Relatório de Desempenho sob Carga - KR_KRIPTO_ADVANCED_COPIA</title>
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 0; padding: 20px; color: #333; }}
                    h1, h2, h3 {{ color: #2c3e50; }}
                    .container {{ max-width: 1200px; margin: 0 auto; }}
                    .header {{ background-color: #34495e; color: white; padding: 20px; margin-bottom: 20px; }}
                    .summary {{ display: flex; justify-content: space-between; margin-bottom: 20px; }}
                    .summary-box {{ background-color: #f8f9fa; border-radius: 5px; padding: 15px; width: 30%; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
                    .success {{ background-color: #d4edda; color: #155724; }}
                    .warning {{ background-color: #fff3cd; color: #856404; }}
                    .danger {{ background-color: #f8d7da; color: #721c24; }}
                    table {{ width: 100%; border-collapse: collapse; margin-bottom: 20px; }}
                    th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }}
                    th {{ background-color: #f2f2f2; }}
                    tr:hover {{ background-color: #f5f5f5; }}
                    .graph-container {{ display: flex; flex-wrap: wrap; justify-content: space-between; margin-bottom: 20px; }}
                    .graph {{ width: 48%; margin-bottom: 20px; }}
                    .graph img {{ width: 100%; border: 1px solid #ddd; border-radius: 5px; }}
                    .footer {{ background-color: #f8f9fa; padding: 15px; text-align: center; margin-top: 30px; font-size: 0.9em; color: #6c757d; }}
                    @media (max-width: 768px) {{
                        .summary {{ flex-direction: column; }}
                        .summary-box {{ width: 100%; margin-bottom: 10px; }}
                        .graph {{ width: 100%; }}
                    }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>Relatório de Desempenho sob Carga</h1>
                        <h2>KR_KRIPTO_ADVANCED_COPIA</h2>
                        <p>Gerado em: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}</p>
                    </div>
                    
                    <h2>Resumo</h2>
                    <div class="summary">
                        <div class="summary-box {self.resultados['status_geral']}">
                            <h3>Status Geral</h3>
                            <p><strong>{self.resultados['status_geral'].upper()}</strong></p>
                        </div>
                        <div class="summary-box">
                            <h3>Duração</h3>
                            <p><strong>{self.resultados['duracao_segundos']:.2f} segundos</strong></p>
                        </div>
                        <div class="summary-box">
                            <h3>Testes</h3>
                            <p>Total: <strong>{self.resultados['resumo']['total']}</strong></p>
                            <p>Sucesso: <strong>{self.resultados['resumo']['sucesso']}</strong></p>
                            <p>Alerta: <strong>{self.resultados['resumo']['alerta']}</strong></p>
                            <p>Falha: <strong>{self.resultados['resumo']['falha']}</strong></p>
                        </div>
                    </div>
                    
                    <h2>Resultados por Nível de Carga</h2>
                    <table>
                        <tr>
                            <th>Nível</th>
                            <th>Status</th>
                            <th>Threads</th>
                            <th>Intervalo (ms)</th>
                            <th>Latência Média (ms)</th>
                            <th>Throughput (reg/s)</th>
                            <th>Erros</th>
                        </tr>
            """
            
            # Adicionar linhas da tabela para cada teste
            for teste in self.resultados['testes']:
                status_class = "success" if teste['status'] == 'sucesso' else "warning" if teste['status'] == 'alerta' else "danger"
                html_content += f"""
                        <tr class="{status_class}">
                            <td>{teste['nivel']}</td>
                            <td>{teste['status'].upper()}</td>
                            <td>{teste['config']['threads']}</td>
                            <td>{teste['config']['intervalo_ms']}</td>
                            <td>{teste['metricas']['tempo_medio_processamento'] * 1000:.2f}</td>
                            <td>{teste['metricas']['throughput']:.2f}</td>
                            <td>{teste['metricas']['erros']}</td>
                        </tr>
                """
            
            # Adicionar gráficos
            html_content += """
                    </table>
                    
                    <h2>Gráficos</h2>
                    <div class="graph-container">
                        <div class="graph">
                            <h3>Uso de CPU</h3>
                            <img src="graficos/cpu_usage.png" alt="Gráfico de Uso de CPU">
                        </div>
                        <div class="graph">
                            <h3>Uso de Memória</h3>
                            <img src="graficos/memory_usage.png" alt="Gráfico de Uso de Memória">
                        </div>
                        <div class="graph">
                            <h3>Latência por Nível de Carga</h3>
                            <img src="graficos/latency_by_load.png" alt="Gráfico de Latência por Nível de Carga">
                        </div>
                        <div class="graph">
                            <h3>Throughput por Nível de Carga</h3>
                            <img src="graficos/throughput_by_load.png" alt="Gráfico de Throughput por Nível de Carga">
                        </div>
                    </div>
                    
                    <h2>Conclusão</h2>
            """
            
            # Adicionar conclusão baseada nos resultados
            if self.resultados['status_geral'] == 'sucesso':
                html_content += """
                    <p>O sistema KR_KRIPTO_ADVANCED_COPIA demonstrou excelente desempenho sob todos os níveis de carga testados. 
                    Todos os indicadores de performance estão dentro dos limites aceitáveis, e o sistema manteve-se estável 
                    mesmo sob carga pesada. Recomenda-se prosseguir com os próximos testes do Guia de Testes Abrangente.</p>
                """
            elif self.resultados['status_geral'] == 'alerta':
                html_content += """
                    <p>O sistema KR_KRIPTO_ADVANCED_COPIA apresentou desempenho satisfatório, porém com alguns alertas 
                    que merecem atenção. A latência média ou uso de recursos aproximou-se dos limites estabelecidos 
                    em alguns cenários de carga. Recomenda-se revisar os componentes críticos antes de prosseguir 
                    para ambientes de produção com alto volume de dados.</p>
                """
            else:
                html_content += """
                    <p>O sistema KR_KRIPTO_ADVANCED_COPIA apresentou problemas de desempenho significativos sob carga. 
                    Foram identificadas falhas que precisam ser corrigidas antes de prosseguir com os próximos testes. 
                    Recomenda-se revisar os componentes críticos, otimizar o código e implementar melhorias de performance 
                    nos pontos identificados nos gráficos e tabelas deste relatório.</p>
                """
            
            # Finalizar HTML
            html_content += """
                    <div class="footer">
                        <p>Teste de Desempenho sob Carga - KR_KRIPTO_ADVANCED_COPIA</p>
                        <p>Gerado automaticamente pelo script teste_desempenho_carga.py</p>
                    </div>
                </div>
            </body>
            </html>
            """
            
            # Salvar arquivo HTML
            with open(relatorio_file, 'w') as f:
                f.write(html_content)
            
            logger.info(f"Relatório HTML gerado com sucesso: {relatorio_file}")
            return relatorio_file
            
        except Exception as e:
            logger.error(f"Erro ao gerar relatório HTML: {str(e)}", exc_info=True)
            return None

async def main():
    """Função principal para execução dos testes."""
    parser = argparse.ArgumentParser(description='Teste de Desempenho sob Carga para KR_KRIPTO_ADVANCED_COPIA')
    parser.add_argument('--config', type=str, help='Caminho para arquivo de configuração JSON')
    parser.add_argument('--output', type=str, help='Diretório para salvar resultados')
    args = parser.parse_args()
    
    # Carregar configuração personalizada se fornecida
    config = None
    if args.config:
        try:
            with open(args.config, 'r') as f:
                config = json.load(f)
            logger.info(f"Configuração carregada de {args.config}")
        except Exception as e:
            logger.error(f"Erro ao carregar configuração: {str(e)}")
            return
    
    # Iniciar teste
    teste_runner = TesteDesempenhoCarga(config={})
    resultados = await teste_runner.executar_todos_testes()
    
    # Gerar relatório HTML
    relatorio_file = teste_runner.gerar_relatorio_html()
    
    # Exibir resumo
    print("\n" + "="*50)
    print(f"RESUMO DO TESTE DE DESEMPENHO SOB CARGA")
    print("="*50)
    print(f"Status geral: {resultados['status_geral'].upper()}")
    print(f"Total de testes: {resultados['resumo']['total']}")
    print(f"Sucessos: {resultados['resumo']['sucesso']}")
    print(f"Alertas: {resultados['resumo']['alerta']}")
    print(f"Falhas: {resultados['resumo']['falha']}")
    print(f"Duração: {resultados['duracao_segundos']:.2f} segundos")
    print("="*50)
    
    print("\nDETALHES DOS TESTES:")
    for i, teste in enumerate(resultados['testes'], 1):
        print(f"{i}. {teste['nivel']}: {teste['status'].upper()}")
        print(f"   Latência média: {teste['metricas']['tempo_medio_processamento']*1000:.2f} ms")
        print(f"   Throughput: {teste['metricas']['throughput']:.2f} reg/s")
        print(f"   Erros: {teste['metricas']['erros']}")
    
    print("\n" + "="*50)
    print(f"Relatório HTML: {relatorio_file}")
    print(f"Gráficos: {teste_runner.graficos_dir}")
    print("="*50)
    
    return resultados

if __name__ == "__main__":
    asyncio.run(main())
