#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de validação das correções para testes pulados e warnings no KR Kripto Advanced.

Este script executa a validação das correções aplicadas aos testes pulados e warnings,
verificando se todos os testes agora passam corretamente no ambiente Mac M1.
"""

import os
import sys
import subprocess
import json
import datetime

# Diretório de correções
CORRECOES_DIR = "/home/ubuntu/correcoes"
# Diretório do projeto
PROJETO_DIR = "/home/ubuntu/kr_kripto_advanced/KR_KRIPTO_ADVANCED_COPIA"
# Diretório de testes
TESTES_DIR = os.path.join(PROJETO_DIR, "tests")

def criar_diretorio_backup():
    """Cria um diretório de backup para os arquivos originais."""
    backup_dir = os.path.join(PROJETO_DIR, "tests_backup")
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)
    return backup_dir

def backup_arquivos_originais():
    """Faz backup dos arquivos originais que serão substituídos."""
    backup_dir = criar_diretorio_backup()
    arquivos_corrigidos = [f for f in os.listdir(CORRECOES_DIR) if f.endswith(".py")]
    
    for arquivo in arquivos_corrigidos:
        nome_original = arquivo.replace("_corrigido", "")
        caminho_original = os.path.join(TESTES_DIR, nome_original)
        caminho_backup = os.path.join(backup_dir, nome_original)
        
        if os.path.exists(caminho_original):
            with open(caminho_original, 'r') as f_orig:
                conteudo = f_orig.read()
            
            with open(caminho_backup, 'w') as f_backup:
                f_backup.write(conteudo)
            
            print(f"Backup do arquivo {nome_original} criado em {caminho_backup}")

def aplicar_correcoes():
    """Aplica as correções aos arquivos de teste."""
    arquivos_corrigidos = [f for f in os.listdir(CORRECOES_DIR) if f.endswith(".py")]
    
    for arquivo in arquivos_corrigidos:
        nome_original = arquivo.replace("_corrigido", "")
        caminho_corrigido = os.path.join(CORRECOES_DIR, arquivo)
        caminho_destino = os.path.join(TESTES_DIR, nome_original)
        
        with open(caminho_corrigido, 'r') as f_corrigido:
            conteudo = f_corrigido.read()
        
        with open(caminho_destino, 'w') as f_destino:
            f_destino.write(conteudo)
        
        print(f"Correção aplicada: {nome_original}")

def executar_testes():
    """Executa os testes e retorna os resultados."""
    comando = ["pytest", "tests/", "-v", "--asyncio-mode=strict"]
    
    try:
        resultado = subprocess.run(
            comando,
            cwd=PROJETO_DIR,
            capture_output=True,
            text=True,
            check=False
        )
        
        return {
            "comando": " ".join(comando),
            "retorno": resultado.returncode,
            "saida": resultado.stdout,
            "erro": resultado.stderr,
            "timestamp": datetime.datetime.now().isoformat()
        }
    except Exception as e:
        return {
            "comando": " ".join(comando),
            "erro": str(e),
            "timestamp": datetime.datetime.now().isoformat()
        }

def analisar_resultados(resultados):
    """Analisa os resultados dos testes e gera um relatório."""
    saida = resultados.get("saida", "")
    
    # Contagem de testes
    testes_totais = 0
    testes_passados = 0
    testes_falhas = 0
    testes_erros = 0
    testes_pulados = 0
    warnings = 0
    
    # Extrair informações do resumo
    import re
    
    # Padrão para o resumo de testes
    padrao_resumo = r'=+ ([\d]+) passed, ([\d]+) skipped, ([\d]+) failed, ([\d]+) error.+ in ([\d\.]+)s =+'
    match_resumo = re.search(padrao_resumo, saida)
    
    if match_resumo:
        testes_passados = int(match_resumo.group(1))
        testes_pulados = int(match_resumo.group(2))
        testes_falhas = int(match_resumo.group(3))
        testes_erros = int(match_resumo.group(4))
        tempo_execucao = match_resumo.group(5)
        testes_totais = testes_passados + testes_pulados + testes_falhas + testes_erros
    
    # Contar warnings
    padrao_warnings = r'=+ warnings summary =+'
    if re.search(padrao_warnings, saida):
        warnings = len(re.findall(r'Warning:', saida))
    
    # Gerar relatório
    relatorio = {
        "testes_totais": testes_totais,
        "testes_passados": testes_passados,
        "testes_falhas": testes_falhas,
        "testes_erros": testes_erros,
        "testes_pulados": testes_pulados,
        "warnings": warnings,
        "timestamp": datetime.datetime.now().isoformat()
    }
    
    return relatorio

def restaurar_arquivos_originais():
    """Restaura os arquivos originais após os testes."""
    backup_dir = os.path.join(PROJETO_DIR, "tests_backup")
    if not os.path.exists(backup_dir):
        print("Diretório de backup não encontrado.")
        return
    
    arquivos_backup = [f for f in os.listdir(backup_dir) if f.endswith(".py")]
    
    for arquivo in arquivos_backup:
        caminho_backup = os.path.join(backup_dir, arquivo)
        caminho_destino = os.path.join(TESTES_DIR, arquivo)
        
        with open(caminho_backup, 'r') as f_backup:
            conteudo = f_backup.read()
        
        with open(caminho_destino, 'w') as f_destino:
            f_destino.write(conteudo)
        
        print(f"Arquivo original restaurado: {arquivo}")

def salvar_resultados(resultados, relatorio):
    """Salva os resultados e o relatório em arquivos JSON."""
    with open(os.path.join(CORRECOES_DIR, "resultados_testes.json"), 'w') as f:
        json.dump(resultados, f, indent=2)
    
    with open(os.path.join(CORRECOES_DIR, "relatorio_validacao.json"), 'w') as f:
        json.dump(relatorio, f, indent=2)
    
    # Gerar relatório em formato legível
    with open(os.path.join(CORRECOES_DIR, "relatorio_validacao.txt"), 'w') as f:
        f.write("RELATÓRIO DE VALIDAÇÃO DAS CORREÇÕES\n")
        f.write("===================================\n\n")
        f.write(f"Data e hora: {relatorio['timestamp']}\n\n")
        f.write(f"Total de testes: {relatorio['testes_totais']}\n")
        f.write(f"Testes passados: {relatorio['testes_passados']}\n")
        f.write(f"Testes pulados: {relatorio['testes_pulados']}\n")
        f.write(f"Testes com falhas: {relatorio['testes_falhas']}\n")
        f.write(f"Testes com erros: {relatorio['testes_erros']}\n")
        f.write(f"Warnings: {relatorio['warnings']}\n\n")
        
        # Análise de sucesso
        if relatorio['testes_pulados'] == 0 and relatorio['testes_falhas'] == 0 and relatorio['testes_erros'] == 0:
            f.write("RESULTADO: SUCESSO\n")
            f.write("Todas as correções foram aplicadas com sucesso e todos os testes passaram.\n")
        else:
            f.write("RESULTADO: PARCIAL\n")
            f.write("Algumas correções podem precisar de ajustes adicionais.\n")
        
        if relatorio['warnings'] > 0:
            f.write("\nALERTA: Ainda existem warnings que podem precisar de atenção.\n")

def main():
    """Função principal que executa a validação das correções."""
    print("Iniciando validação das correções...")
    
    # Fazer backup dos arquivos originais
    print("\n1. Criando backup dos arquivos originais...")
    backup_arquivos_originais()
    
    try:
        # Aplicar correções
        print("\n2. Aplicando correções...")
        aplicar_correcoes()
        
        # Executar testes
        print("\n3. Executando testes...")
        resultados = executar_testes()
        
        # Analisar resultados
        print("\n4. Analisando resultados...")
        relatorio = analisar_resultados(resultados)
        
        # Salvar resultados
        print("\n5. Salvando resultados...")
        salvar_resultados(resultados, relatorio)
        
        # Exibir resumo
        print("\nRESUMO DA VALIDAÇÃO:")
        print(f"Total de testes: {relatorio['testes_totais']}")
        print(f"Testes passados: {relatorio['testes_passados']}")
        print(f"Testes pulados: {relatorio['testes_pulados']}")
        print(f"Testes com falhas: {relatorio['testes_falhas']}")
        print(f"Testes com erros: {relatorio['testes_erros']}")
        print(f"Warnings: {relatorio['warnings']}")
        
        if relatorio['testes_pulados'] == 0 and relatorio['testes_falhas'] == 0 and relatorio['testes_erros'] == 0:
            print("\nSUCESSO: Todas as correções foram aplicadas com sucesso!")
        else:
            print("\nPARCIAL: Algumas correções podem precisar de ajustes adicionais.")
    
    finally:
        # Restaurar arquivos originais
        print("\n6. Restaurando arquivos originais...")
        restaurar_arquivos_originais()
    
    print("\nValidação concluída!")

if __name__ == "__main__":
    main()
