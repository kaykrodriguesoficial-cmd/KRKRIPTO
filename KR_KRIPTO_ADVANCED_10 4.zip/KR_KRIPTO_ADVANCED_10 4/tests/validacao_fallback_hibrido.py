#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de validação para o GerenciadorFallback híbrido em diferentes ambientes.
Este script testa a integração do GerenciadorFallback com o sistema principal
e verifica sua compatibilidade tanto em Mac M1 (ARM64) quanto em Linux.
"""

import os
import sys
import platform
import logging
import time
from datetime import datetime

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("validacao_fallback")

# Adicionar diretório pai ao path para importar os módulos
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Importar o módulo de correção de importações
try:
    from src.intelligence.import_fix import fix_imports, is_mac_m1
    resultados_fix = fix_imports()
    logger.info(f"Import fix aplicado: {resultados_fix}")
except ImportError:
    logger.warning("Não foi possível carregar o corretor de importações v3.")
    is_mac_m1 = lambda: platform.system() == "Darwin" and ("arm" in platform.machine().lower())

# Tentar importar o GerenciadorFallback
try:
    from src.core.fallback import GerenciadorFallback
    logger.info("GerenciadorFallback híbrido importado com sucesso")
    fallback_disponivel = True
except ImportError as e:
    logger.error(f"Erro ao importar GerenciadorFallback híbrido: {e}")
    fallback_disponivel = False

def verificar_ambiente():
    """Verifica o ambiente de execução."""
    info = {
        "sistema": platform.system(),
        "release": platform.release(),
        "versao": platform.version(),
        "arquitetura": platform.machine(),
        "processador": platform.processor(),
        "python": platform.python_version(),
        "mac_m1": is_mac_m1()
    }
    
    logger.info(f"Ambiente de execução: {info}")
    return info

def testar_fallback_basico():
    """Testa funcionalidades básicas do GerenciadorFallback."""
    if not fallback_disponivel:
        logger.error("GerenciadorFallback não disponível para teste")
        return False
    
    try:
        # Inicializar o gerenciador
        gerenciador = GerenciadorFallback()
        logger.info("GerenciadorFallback inicializado com sucesso")
        
        # Testar registro de falhas
        gerenciador.registrar_falha("componente_teste", Exception("Erro de teste"))
        logger.info("Registro de falha realizado com sucesso")
        
        # Testar obtenção de status
        status = gerenciador.obter_status()
        logger.info(f"Status obtido: {status}")
        
        # Testar modelo de fallback
        modelo = gerenciador.obter_modelo_fallback()
        predicao = modelo["predict"]({"feature1": 1.0, "feature2": 2.0})
        logger.info(f"Predição do modelo de fallback: {predicao}")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao testar GerenciadorFallback: {e}")
        return False

def testar_integracao_sistema():
    """Testa a integração do GerenciadorFallback com o sistema principal."""
    if not fallback_disponivel:
        logger.error("GerenciadorFallback não disponível para teste de integração")
        return False
    
    try:
        # Simular componentes do sistema
        class OperadorBinanceMock:
            def obter_saldo(self):
                return {"USDT": 1000.0, "BTC": 0.1}
        
        operador = OperadorBinanceMock()
        
        # Inicializar o gerenciador com configuração e operador
        config = {
            "max_falhas": 5,
            "janela_falhas": 300,
            "tempo_reset": 600
        }
        gerenciador = GerenciadorFallback(config=config, operador_binance=operador)
        logger.info("GerenciadorFallback inicializado com configuração e operador")
        
        # Testar circuit breaker
        @gerenciador.circuit_breaker_sincrono("operacao_critica")
        def operacao_critica(falhar=False):
            if falhar:
                raise ValueError("Falha simulada")
            return "Operação bem-sucedida"
        
        # Executar operação sem falha
        resultado = operacao_critica()
        logger.info(f"Operação crítica executada: {resultado}")
        
        # Simular monitoramento de modelo
        resultado_monitoramento = gerenciador.monitorar_modelo(
            "modelo_principal",
            {"acuracia": 0.82, "erro_medio": 0.18}
        )
        logger.info(f"Monitoramento de modelo: {resultado_monitoramento}")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao testar integração do GerenciadorFallback: {e}")
        return False

def testar_compatibilidade_mac_m1():
    """Testa a compatibilidade específica com Mac M1."""
    if not is_mac_m1():
        logger.info("Não é um ambiente Mac M1, pulando testes específicos")
        return None
    
    if not fallback_disponivel:
        logger.error("GerenciadorFallback não disponível para teste de compatibilidade Mac M1")
        return False
    
    try:
        logger.info("Executando testes específicos para Mac M1")
        
        # Inicializar o gerenciador
        gerenciador = GerenciadorFallback()
        
        # Verificar recursos do sistema (específico para Mac M1)
        recursos = gerenciador.verificar_recursos_sistema()
        logger.info(f"Recursos do sistema Mac M1: {recursos}")
        
        # Testar watchdog (específico para Mac M1)
        def callback_watchdog():
            logger.info("Callback de watchdog executado em Mac M1")
            return True
        
        gerenciador.registrar_watchdog("tarefa_mac_m1", 10, callback_watchdog)
        logger.info("Watchdog registrado com sucesso em Mac M1")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao testar compatibilidade Mac M1: {e}")
        return False

def executar_validacao_completa():
    """Executa a validação completa do GerenciadorFallback."""
    resultados = {
        "timestamp": datetime.now().isoformat(),
        "ambiente": verificar_ambiente(),
        "fallback_disponivel": fallback_disponivel
    }
    
    # Executar testes
    resultados["teste_basico"] = testar_fallback_basico()
    resultados["teste_integracao"] = testar_integracao_sistema()
    resultados["teste_mac_m1"] = testar_compatibilidade_mac_m1()
    
    # Resumo
    testes_ok = sum(1 for k, v in resultados.items() if k.startswith("teste_") and v is True)
    testes_total = sum(1 for k in resultados.keys() if k.startswith("teste_") and resultados[k] is not None)
    resultados["resumo"] = f"{testes_ok}/{testes_total} testes bem-sucedidos"
    
    logger.info(f"Validação completa: {resultados['resumo']}")
    return resultados

if __name__ == "__main__":
    logger.info("Iniciando validação do GerenciadorFallback híbrido")
    resultados = executar_validacao_completa()
    
    # Exibir resultados
    print("\n" + "="*50)
    print("RESULTADOS DA VALIDAÇÃO DO GERENCIADOR FALLBACK HÍBRIDO")
    print("="*50)
    
    # Ambiente
    print(f"\nAmbiente: {resultados['ambiente']['sistema']} {resultados['ambiente']['arquitetura']}")
    print(f"Mac M1: {'Sim' if resultados['ambiente']['mac_m1'] else 'Não'}")
    print(f"Python: {resultados['ambiente']['python']}")
    
    # Disponibilidade
    print(f"\nGerenciadorFallback disponível: {'Sim' if resultados['fallback_disponivel'] else 'Não'}")
    
    # Resultados dos testes
    print("\nResultados dos testes:")
    print(f"- Teste básico: {'PASSOU' if resultados['teste_basico'] else 'FALHOU'}")
    print(f"- Teste de integração: {'PASSOU' if resultados['teste_integracao'] else 'FALHOU'}")
    
    if resultados['teste_mac_m1'] is not None:
        print(f"- Teste Mac M1: {'PASSOU' if resultados['teste_mac_m1'] else 'FALHOU'}")
    else:
        print("- Teste Mac M1: NÃO APLICÁVEL")
    
    # Resumo
    print(f"\nResumo: {resultados['resumo']}")
    print("="*50)
