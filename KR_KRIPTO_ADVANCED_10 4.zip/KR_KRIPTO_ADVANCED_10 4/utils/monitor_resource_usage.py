#!/usr/bin/env python3
"""
Script para monitoramento de consumo de recursos (CPU, memória) durante execução do KR_KRIPTO_ADVANCED_COPIA.

Este script:
1. Inicia o sistema KR_KRIPTO_ADVANCED_COPIA em modo de simulação
2. Monitora o consumo de CPU e memória em intervalos regulares
3. Gera gráficos e relatórios de uso de recursos
4. Detecta possíveis vazamentos de memória ou picos de CPU

Uso:
    python3 monitor_resource_usage.py --duration 600 --interval 5 --output resource_report.json

Argumentos:
    --duration: Duração do teste em segundos (padrão: 600)
    --interval: Intervalo entre medições em segundos (padrão: 5)
    --output: Arquivo de saída para os resultados (padrão: resource_usage_TIMESTAMP.json)
    --detailed: Ativa o modo detalhado com mais métricas (padrão: False)
    --plot: Gera gráficos de uso de recursos (padrão: True)
"""

import os
import sys
import time
import json
import argparse
import subprocess
import signal
import psutil
import datetime
import threading
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path

# Configurações globais
MAIN_PY_PATH = "/home/ubuntu/KR_KRIPTO_ADVANCED_COPIA_PROJECT/KR_KRIPTO_ADVANCED_COPIA/main.py"
DATA_FILE_PATH = "/home/ubuntu/KR_KRIPTO_ADVANCED_COPIA_PROJECT/KR_KRIPTO_ADVANCED_COPIA/data/BTCUSDT_1m.csv"
OUTPUT_DIR = "/home/ubuntu"
TIMESTAMP = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

class ResourceMonitor:
    """Classe para monitorar o consumo de recursos de um processo."""
    
    def __init__(self, config: dict):
        """
        Inicializa o monitor de recursos.
        
        Args:
            process: Objeto de processo psutil
            interval: Intervalo entre medições em segundos
            detailed: Se True, coleta métricas detalhadas
        """
        self.process = process
        self.interval = interval
        self.detailed = detailed
        self.running = False
        self.metrics = {
            'timestamp': [],
            'cpu_percent': [],
            'memory_percent': [],
            'memory_mb': [],
            'threads': [],
            'io_read_mb': [],
            'io_write_mb': [],
            'children_count': []
        }
        
        if detailed:
            self.metrics.update({
                'ctx_switches': [],
                'open_files': [],
                'connections': []
            })
    
    def start(self):
        """Inicia o monitoramento em uma thread separada."""
        self.running = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop)
        self.monitor_thread.daemon = True
        self.monitor_thread.start()
        print(f"🔍 Monitoramento iniciado para PID {self.process.pid} com intervalo de {self.interval}s")
    
    def stop(self):
        """Para o monitoramento."""
        self.running = False
        if hasattr(self, 'monitor_thread'):
            self.monitor_thread.join(timeout=2)
        print(f"✓ Monitoramento finalizado após {len(self.metrics['timestamp'])} medições")
    
    def _monitor_loop(self):
        """Loop principal de monitoramento."""
        start_time = time.time()
        last_io_counters = self.process.io_counters() if hasattr(self.process, 'io_counters') else None
        
        while self.running:
            try:
                # Atualiza as informações do processo
                self.process.cpu_percent(interval=0.1)  # Warm-up
                
                # Coleta métricas básicas
                cpu_percent = self.process.cpu_percent(interval=0.5)
                memory_info = self.process.memory_info()
                memory_percent = self.process.memory_percent()
                memory_mb = memory_info.rss / (1024 * 1024)  # Converter para MB
                threads_count = len(self.process.threads())
                children_count = len(self.process.children(recursive=True))
                
                # Coleta métricas de I/O
                io_counters = self.process.io_counters() if hasattr(self.process, 'io_counters') else None
                io_read_mb = 0
                io_write_mb = 0
                
                if io_counters and last_io_counters:
                    io_read_mb = (io_counters.read_bytes - last_io_counters.read_bytes) / (1024 * 1024)
                    io_write_mb = (io_counters.write_bytes - last_io_counters.write_bytes) / (1024 * 1024)
                    last_io_counters = io_counters
                
                # Registra as métricas básicas
                current_time = time.time() - start_time
                self.metrics['timestamp'].append(current_time)
                self.metrics['cpu_percent'].append(cpu_percent)
                self.metrics['memory_percent'].append(memory_percent)
                self.metrics['memory_mb'].append(memory_mb)
                self.metrics['threads'].append(threads_count)
                self.metrics['io_read_mb'].append(io_read_mb)
                self.metrics['io_write_mb'].append(io_write_mb)
                self.metrics['children_count'].append(children_count)
                
                # Coleta métricas detalhadas se solicitado
                if self.detailed:
                    ctx_switches = sum(self.process.num_ctx_switches())
                    open_files = len(self.process.open_files())
                    connections = len(self.process.connections())
                    
                    self.metrics['ctx_switches'].append(ctx_switches)
                    self.metrics['open_files'].append(open_files)
                    self.metrics['connections'].append(connections)
                
                # Exibe progresso
                if len(self.metrics['timestamp']) % 10 == 0:
                    print(f"📊 {len(self.metrics['timestamp'])} medições coletadas | "
                          f"CPU: {cpu_percent:.1f}% | Memória: {memory_mb:.1f}MB ({memory_percent:.1f}%) | "
                          f"Threads: {threads_count}")
                
                # Aguarda até o próximo intervalo
                time.sleep(self.interval)
                
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                print("⚠️ Processo não está mais disponível ou acessível")
                self.running = False
                break
            except Exception as e:
                print(f"⚠️ Erro durante monitoramento: {e}")
                continue
    
    def get_metrics(self):
        """Retorna as métricas coletadas."""
        return self.metrics
    
    def generate_report(self):
        """Gera um relatório com estatísticas das métricas coletadas."""
        if not self.metrics['timestamp']:
            return {"error": "Nenhuma métrica coletada"}
        
        report = {
            "duration_seconds": max(self.metrics['timestamp']),
            "measurements_count": len(self.metrics['timestamp']),
            "interval_seconds": self.interval,
            "stats": {}
        }
        
        # Calcula estatísticas para cada métrica
        for key in self.metrics:
            if key == 'timestamp':
                continue
                
            values = self.metrics[key]
            if not values:
                continue
                
            report["stats"][key] = {
                "min": min(values),
                "max": max(values),
                "avg": sum(values) / len(values),
                "median": sorted(values)[len(values) // 2],
                "std_dev": np.std(values),
                "last": values[-1]
            }
            
            # Detecta tendências
            if len(values) > 10:
                first_half = values[:len(values)//2]
                second_half = values[len(values)//2:]
                first_half_avg = sum(first_half) / len(first_half)
                second_half_avg = sum(second_half) / len(second_half)
                
                if key == 'memory_mb':
                    # Detecta possível vazamento de memória
                    if second_half_avg > first_half_avg * 1.2:  # 20% de aumento
                        report["stats"][key]["trend"] = "INCREASING"
                        report["stats"][key]["possible_leak"] = True
                    elif second_half_avg < first_half_avg * 0.8:  # 20% de diminuição
                        report["stats"][key]["trend"] = "DECREASING"
                        report["stats"][key]["possible_leak"] = False
                    else:
                        report["stats"][key]["trend"] = "STABLE"
                        report["stats"][key]["possible_leak"] = False
                else:
                    # Tendência geral para outras métricas
                    if second_half_avg > first_half_avg * 1.1:  # 10% de aumento
                        report["stats"][key]["trend"] = "INCREASING"
                    elif second_half_avg < first_half_avg * 0.9:  # 10% de diminuição
                        report["stats"][key]["trend"] = "DECREASING"
                    else:
                        report["stats"][key]["trend"] = "STABLE"
        
        # Adiciona análise geral
        report["analysis"] = {
            "cpu_stability": "STABLE" if report["stats"]["cpu_percent"]["std_dev"] < 10 else "UNSTABLE",
            "memory_stability": "STABLE" if report["stats"]["memory_mb"]["std_dev"] < (report["stats"]["memory_mb"]["avg"] * 0.1) else "UNSTABLE",
            "possible_memory_leak": report["stats"]["memory_mb"].get("possible_leak", False),
            "high_cpu_usage": report["stats"]["cpu_percent"]["avg"] > 50,
            "high_memory_usage": report["stats"]["memory_percent"]["avg"] > 50
        }
        
        return report
    
    def plot_metrics(self, output_prefix):
        """Gera gráficos para as métricas coletadas."""
        if not self.metrics['timestamp']:
            print("⚠️ Nenhuma métrica para plotar")
            return
        
        # Configurações de estilo
        plt.style.use('ggplot')
        
        # Gráfico de CPU
        plt.figure(figsize=(12, 6))
        plt.plot(self.metrics['timestamp'], self.metrics['cpu_percent'], 'b-', linewidth=2)
        plt.title('Uso de CPU ao Longo do Tempo', fontsize=14)
        plt.xlabel('Tempo (segundos)', fontsize=12)
        plt.ylabel('CPU (%)', fontsize=12)
        plt.grid(True)
        plt.tight_layout()
        cpu_plot_path = f"{output_prefix}_cpu.png"
        plt.savefig(cpu_plot_path)
        plt.close()
        
        # Gráfico de Memória
        plt.figure(figsize=(12, 6))
        plt.plot(self.metrics['timestamp'], self.metrics['memory_mb'], 'r-', linewidth=2)
        plt.title('Uso de Memória ao Longo do Tempo', fontsize=14)
        plt.xlabel('Tempo (segundos)', fontsize=12)
        plt.ylabel('Memória (MB)', fontsize=12)
        plt.grid(True)
        plt.tight_layout()
        memory_plot_path = f"{output_prefix}_memory.png"
        plt.savefig(memory_plot_path)
        plt.close()
        
        # Gráfico combinado
        fig, ax1 = plt.subplots(figsize=(12, 6))
        
        color = 'tab:blue'
        ax1.set_xlabel('Tempo (segundos)', fontsize=12)
        ax1.set_ylabel('CPU (%)', color=color, fontsize=12)
        ax1.plot(self.metrics['timestamp'], self.metrics['cpu_percent'], color=color, linewidth=2)
        ax1.tick_params(axis='y', labelcolor=color)
        
        ax2 = ax1.twinx()
        color = 'tab:red'
        ax2.set_ylabel('Memória (MB)', color=color, fontsize=12)
        ax2.plot(self.metrics['timestamp'], self.metrics['memory_mb'], color=color, linewidth=2)
        ax2.tick_params(axis='y', labelcolor=color)
        
        plt.title('CPU e Memória ao Longo do Tempo', fontsize=14)
        fig.tight_layout()
        combined_plot_path = f"{output_prefix}_combined.png"
        plt.savefig(combined_plot_path)
        plt.close()
        
        # Gráfico de threads e processos filhos
        plt.figure(figsize=(12, 6))
        plt.plot(self.metrics['timestamp'], self.metrics['threads'], 'g-', label='Threads', linewidth=2)
        plt.plot(self.metrics['timestamp'], self.metrics['children_count'], 'm-', label='Processos Filhos', linewidth=2)
        plt.title('Threads e Processos Filhos ao Longo do Tempo', fontsize=14)
        plt.xlabel('Tempo (segundos)', fontsize=12)
        plt.ylabel('Contagem', fontsize=12)
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        threads_plot_path = f"{output_prefix}_threads.png"
        plt.savefig(threads_plot_path)
        plt.close()
        
        # Gráfico de I/O se disponível
        if any(self.metrics['io_read_mb']) or any(self.metrics['io_write_mb']):
            plt.figure(figsize=(12, 6))
            plt.plot(self.metrics['timestamp'], self.metrics['io_read_mb'], 'c-', label='Leitura (MB)', linewidth=2)
            plt.plot(self.metrics['timestamp'], self.metrics['io_write_mb'], 'y-', label='Escrita (MB)', linewidth=2)
            plt.title('Operações de I/O ao Longo do Tempo', fontsize=14)
            plt.xlabel('Tempo (segundos)', fontsize=12)
            plt.ylabel('MB por intervalo', fontsize=12)
            plt.legend()
            plt.grid(True)
            plt.tight_layout()
            io_plot_path = f"{output_prefix}_io.png"
            plt.savefig(io_plot_path)
            plt.close()
        
        # Gráficos detalhados se disponíveis
        if self.detailed and self.metrics.get('ctx_switches'):
            plt.figure(figsize=(12, 6))
            plt.plot(self.metrics['timestamp'], self.metrics['ctx_switches'], 'k-', linewidth=2)
            plt.title('Trocas de Contexto ao Longo do Tempo', fontsize=14)
            plt.xlabel('Tempo (segundos)', fontsize=12)
            plt.ylabel('Contagem', fontsize=12)
            plt.grid(True)
            plt.tight_layout()
            ctx_plot_path = f"{output_prefix}_ctx_switches.png"
            plt.savefig(ctx_plot_path)
            plt.close()
            
            plt.figure(figsize=(12, 6))
            plt.plot(self.metrics['timestamp'], self.metrics['open_files'], 'tab:orange', linewidth=2, label='Arquivos Abertos')
            plt.plot(self.metrics['timestamp'], self.metrics['connections'], 'tab:purple', linewidth=2, label='Conexões')
            plt.title('Arquivos e Conexões ao Longo do Tempo', fontsize=14)
            plt.xlabel('Tempo (segundos)', fontsize=12)
            plt.ylabel('Contagem', fontsize=12)
            plt.legend()
            plt.grid(True)
            plt.tight_layout()
            files_plot_path = f"{output_prefix}_files_connections.png"
            plt.savefig(files_plot_path)
            plt.close()
        
        print(f"✓ Gráficos salvos em:")
        print(f"  - {cpu_plot_path}")
        print(f"  - {memory_plot_path}")
        print(f"  - {combined_plot_path}")
        print(f"  - {threads_plot_path}")
        
        return {
            "cpu_plot": cpu_plot_path,
            "memory_plot": memory_plot_path,
            "combined_plot": combined_plot_path,
            "threads_plot": threads_plot_path,
            "io_plot": io_plot_path if any(self.metrics['io_read_mb']) or any(self.metrics['io_write_mb']) else None,
            "ctx_plot": ctx_plot_path if self.detailed and self.metrics.get('ctx_switches') else None,
            "files_connections_plot": files_plot_path if self.detailed and self.metrics.get('ctx_switches') else None
        }

def run_main_process(duration, simulation_file, output_file):
    """
    Executa o processo main.py em modo de simulação.
    
    Args:
        duration: Duração máxima em segundos
        simulation_file: Arquivo de dados para simulação
        output_file: Arquivo para salvar resultados da simulação
    
    Returns:
        Objeto de processo psutil
    """
    cmd = [
        "python3.11",
        MAIN_PY_PATH,
        "--simulate", simulation_file,
        "--simulation_output", output_file
    ]
    
    print(f"🚀 Iniciando processo: {' '.join(cmd)}")
    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        universal_newlines=True,
        bufsize=1
    )
    
    # Aguarda um pouco para garantir que o processo iniciou
    time.sleep(2)
    
    if process.poll() is not None:
        print(f"⚠️ Processo encerrou prematuramente com código {process.returncode}")
        stdout, stderr = process.communicate()
        print(f"STDOUT: {stdout}")
        print(f"STDERR: {stderr}")
        return None
    
    # Converte para objeto psutil
    return psutil.Process(process.pid)

def main():
    """Função principal."""
    parser = argparse.ArgumentParser(description='Monitoramento de recursos do KR_KRIPTO_ADVANCED_COPIA')
    parser.add_argument('--duration', type=int, default=600, help='Duração do teste em segundos')
    parser.add_argument('--interval', type=int, default=5, help='Intervalo entre medições em segundos')
    parser.add_argument('--output', type=str, default=f"resource_usage_{TIMESTAMP}.json", 
                        help='Arquivo de saída para os resultados')
    parser.add_argument('--detailed', action='store_true', help='Ativa o modo detalhado com mais métricas')
    parser.add_argument('--no-plot', dest='plot', action='store_false', help='Desativa a geração de gráficos')
    parser.set_defaults(plot=True)
    
    args = parser.parse_args()
    
    # Verifica se o arquivo main.py existe
    if not os.path.exists(MAIN_PY_PATH):
        print(f"❌ Arquivo main.py não encontrado em {MAIN_PY_PATH}")
        return 1
    
    # Verifica se o arquivo de dados existe
    if not os.path.exists(DATA_FILE_PATH):
        print(f"❌ Arquivo de dados não encontrado em {DATA_FILE_PATH}")
        return 1
    
    # Prepara caminhos de saída
    output_path = os.path.join(OUTPUT_DIR, args.output)
    simulation_output = os.path.join(OUTPUT_DIR, f"simulation_output_{TIMESTAMP}.json")
    plots_prefix = os.path.join(OUTPUT_DIR, f"resource_usage_{TIMESTAMP}")
    
    print(f"================================================================================")
    print(f"TESTE 11: CONSUMO DE RECURSOS (CPU, MEMÓRIA)")
    print(f"================================================================================")
    print(f"Duração: {args.duration} segundos")
    print(f"Intervalo: {args.interval} segundos")
    print(f"Modo detalhado: {'Ativado' if args.detailed else 'Desativado'}")
    print(f"Geração de gráficos: {'Ativada' if args.plot else 'Desativada'}")
    print(f"Arquivo de saída: {output_path}")
    print(f"--------------------------------------------------------------------------------")
    
    try:
        # Inicia o processo main.py
        process = run_main_process(args.duration, DATA_FILE_PATH, simulation_output)
        if not process:
            print("❌ Falha ao iniciar o processo main.py")
            return 1
        
        # Inicia o monitoramento
        monitor = ResourceMonitor(config={'interval': args.interval, 'detailed': args.detailed})
        monitor.start()
        
        # Aguarda pelo tempo especificado
        print(f"⏱️ Monitorando por {args.duration} segundos...")
        start_time = time.time()
        try:
            while time.time() - start_time < args.duration:
                if process.is_running():
                    time.sleep(1)
                else:
                    print(f"⚠️ Processo encerrou prematuramente após {time.time() - start_time:.1f} segundos")
                    break
        except KeyboardInterrupt:
            print("\n⚠️ Monitoramento interrompido pelo usuário")
        
        # Para o monitoramento
        monitor.stop()
        
        # Tenta encerrar o processo graciosamente
        if process.is_running():
            print(f"🛑 Encerrando processo {process.pid}...")
            process.terminate()
            try:
                process.wait(timeout=5)
            except psutil.TimeoutExpired:
                print(f"⚠️ Processo não encerrou após 5 segundos, forçando...")
                process.kill()
        
        # Gera relatório
        report = monitor.generate_report()
        report["process_info"] = {
            "command": "python3.11 " + MAIN_PY_PATH,
            "pid": process.pid,
            "start_time": start_time,
            "end_time": time.time(),
            "actual_duration": time.time() - start_time
        }
        
        # Salva relatório
        with open(output_path, 'w') as f:
            json.dump(report, f, indent=2)
        print(f"✓ Relatório salvo em {output_path}")
        
        # Gera gráficos
        if args.plot:
            plot_paths = monitor.plot_metrics(plots_prefix)
            report["plots"] = plot_paths
            
            # Atualiza o relatório com os caminhos dos gráficos
            with open(output_path, 'w') as f:
                json.dump(report, f, indent=2)
        
        # Exibe resumo
        print(f"\n================================================================================")
        print(f"RESUMO DO TESTE DE CONSUMO DE RECURSOS")
        print(f"================================================================================")
        print(f"Duração real: {report['process_info']['actual_duration']:.1f} segundos")
        print(f"Medições: {report['measurements_count']}")
        print(f"CPU média: {report['stats']['cpu_percent']['avg']:.2f}% (min: {report['stats']['cpu_percent']['min']:.2f}%, max: {report['stats']['cpu_percent']['max']:.2f}%)")
        print(f"Memória média: {report['stats']['memory_mb']['avg']:.2f} MB (min: {report['stats']['memory_mb']['min']:.2f} MB, max: {report['stats']['memory_mb']['max']:.2f} MB)")
        print(f"Estabilidade CPU: {report['analysis']['cpu_stability']}")
        print(f"Estabilidade Memória: {report['analysis']['memory_stability']}")
        print(f"Possível vazamento de memória: {'SIM' if report['analysis']['possible_memory_leak'] else 'NÃO'}")
        print(f"--------------------------------------------------------------------------------")
        
        # Retorna o caminho do relatório para uso externo
        return output_path
        
    except Exception as e:
        print(f"❌ Erro durante execução: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
