#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validacao_correcoes_runtime_completo.py

Script completo para validar as correções de runtime do KR Kripto Advanced no ambiente Mac M1.
Este script copia os arquivos necessários para o diretório correto e executa os testes
em um ambiente que simula a estrutura real do projeto.

Autor: Manus
Data: 20/05/2025
"""

import os
import sys
import json
import logging
import platform
import subprocess
import time
import shutil
from pathlib import Path

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - VALIDACAO - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger("validacao_correcoes")

# Detecção de ambiente Mac M1
IS_MAC_M1 = False
if platform.system() == "Darwin" and ("arm" in platform.machine().lower() or "M1" in platform.processor()):
    IS_MAC_M1 = True
    logger.info(f"Ambiente Mac M1 detectado: {platform.machine()} / {platform.processor()}")
else:
    logger.info(f"Ambiente não-Mac M1 detectado: {platform.system()} / {platform.machine()} / {platform.processor()}")

def verificar_arquivos_corrigidos():
    """Verifica se os arquivos corrigidos existem."""
    arquivos_necessarios = [
        "main_corrigido.py",
        "validation_script_module_status_corrigido.py"
    ]
    
    for arquivo in arquivos_necessarios:
        if not os.path.exists(arquivo):
            logger.error(f"Arquivo {arquivo} não encontrado.")
            return False
    
    logger.info("Todos os arquivos corrigidos encontrados.")
    return True

def preparar_ambiente_teste():
    """Prepara um ambiente de teste com a estrutura correta."""
    logger.info("Preparando ambiente de teste...")
    
    # Criar diretório de teste
    diretorio_teste = "/home/ubuntu/kr_kripto_test"
    os.makedirs(diretorio_teste, exist_ok=True)
    
    # Criar estrutura de diretórios
    os.makedirs(f"{diretorio_teste}/src/core", exist_ok=True)
    os.makedirs(f"{diretorio_teste}/src/intelligence", exist_ok=True)
    os.makedirs(f"{diretorio_teste}/src/infrastructure", exist_ok=True)
    os.makedirs(f"{diretorio_teste}/src/data_providers", exist_ok=True)
    os.makedirs(f"{diretorio_teste}/src/config", exist_ok=True)
    os.makedirs(f"{diretorio_teste}/logs", exist_ok=True)
    os.makedirs(f"{diretorio_teste}/data", exist_ok=True)
    os.makedirs(f"{diretorio_teste}/models", exist_ok=True)
    
    # Copiar main.py corrigido
    shutil.copy("/home/ubuntu/main_corrigido.py", f"{diretorio_teste}/main.py")
    
    # Criar arquivos stub para simular a estrutura real
    criar_arquivo_stub(f"{diretorio_teste}/src/config/logging_config.py", """
def setup_logging():
    pass
""")
    
    criar_arquivo_stub(f"{diretorio_teste}/src/core/config_loader.py", """
def carregar_config(path):
    import json
    try:
        with open(path, 'r') as f:
            return json.load(f)
    except Exception as e:
        print(f"Erro ao carregar configuração: {str(e)}")
        return {}

def obter_config_segura(config, chave, padrao=None):
    return config.get(chave, padrao)
""")
    
    criar_arquivo_stub(f"{diretorio_teste}/src/core/model_integrity.py", """
def verificar_integridade_modelo(path):
    return True
""")
    
    criar_arquivo_stub(f"{diretorio_teste}/src/core/env_loader.py", """
def obter_credencial(nome, padrao=None):
    if nome == "binance_api_key":
        return "dummy_api_key"
    elif nome == "binance_api_secret":
        return "dummy_api_secret"
    elif nome == "testnet":
        return "true"
    return padrao
""")
    
    criar_arquivo_stub(f"{diretorio_teste}/src/infrastructure/security.py", """
def verificar_assinatura(data):
    return True
""")
    
    # Criar arquivo de configuração
    config = {
        "components_activation": {
            "operador_binance_active": True,
            "fallback_active": True,
            "memoria_temporal_active": True,
            "attack_detector_active": True,
            "model_performance_tracker_active": True,
            "neural_governor_active": True,
            "institutional_validator_active": True,
            "news_provider_active": True
        },
        "api_key": "dummy_api_key_for_validation",
        "api_secret": "dummy_api_secret_for_validation",
        "testnet": True,
        "log_level": "INFO",
        "model_path": "models/dummy_model.h5"
    }
    
    with open(f"{diretorio_teste}/config.json", "w") as f:
        json.dump(config, f, indent=4)
    
    # Criar dummy model
    with open(f"{diretorio_teste}/models/dummy_model.h5", "w") as f:
        f.write("dummy model content")
    
    logger.info(f"Ambiente de teste preparado em {diretorio_teste}")
    return diretorio_teste

def criar_arquivo_stub(caminho, conteudo):
    """Cria um arquivo stub com o conteúdo especificado."""
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    with open(caminho, "w") as f:
        f.write(conteudo)

def executar_main_corrigido(diretorio_teste):
    """Executa o main.py corrigido no ambiente de teste."""
    logger.info("Executando main.py corrigido no ambiente de teste...")
    
    try:
        resultado = subprocess.run(
            [sys.executable, "main.py", "--config", "config.json", "--debug"],
            capture_output=True,
            text=True,
            timeout=10,
            cwd=diretorio_teste
        )
        
        logger.info(f"Código de saída: {resultado.returncode}")
        
        if resultado.stdout:
            logger.info(f"Saída padrão:\n{resultado.stdout}")
        
        if resultado.stderr:
            logger.warning(f"Saída de erro:\n{resultado.stderr}")
        
        # Verificar se não há mensagens de modo degradado
        modo_degradado = False
        if "modo degradado" in resultado.stdout.lower() or "usando stub" in resultado.stdout.lower():
            logger.warning("Possível modo degradado detectado na saída.")
            modo_degradado = True
        
        return resultado.returncode == 0 and not modo_degradado
    except subprocess.TimeoutExpired:
        logger.info("Timeout ao executar o main.py (comportamento esperado para execução contínua).")
        return True
    except Exception as e:
        logger.error(f"Erro ao executar o main.py: {str(e)}")
        return False

def validar_correcoes():
    """Função principal para validar as correções."""
    logger.info("=== INICIANDO VALIDAÇÃO DAS CORREÇÕES DE RUNTIME ===")
    
    # Verificar arquivos corrigidos
    if not verificar_arquivos_corrigidos():
        logger.error("Falha na verificação dos arquivos corrigidos.")
        return False
    
    # Preparar ambiente de teste
    diretorio_teste = preparar_ambiente_teste()
    
    # Executar main.py corrigido no ambiente de teste
    if not executar_main_corrigido(diretorio_teste):
        logger.error("Falha na execução do main.py corrigido no ambiente de teste.")
        return False
    
    logger.info("=== VALIDAÇÃO DAS CORREÇÕES DE RUNTIME CONCLUÍDA COM SUCESSO ===")
    return True

if __name__ == "__main__":
    if validar_correcoes():
        logger.info("✅ TODAS AS CORREÇÕES FORAM VALIDADAS COM SUCESSO!")
        sys.exit(0)
    else:
        logger.error("❌ FALHA NA VALIDAÇÃO DAS CORREÇÕES!")
        sys.exit(1)
