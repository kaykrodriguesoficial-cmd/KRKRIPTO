#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para validação de ausência de regressão após implementação das melhorias
de alta prioridade no sistema KR_KRIPTO_ADVANCED_COPIA.

Este script verifica:
1. Integridade dos arquivos críticos
2. Funcionamento dos componentes principais
3. Ausência de impactos colaterais nas melhorias implementadas

Autor: Manus AI
Data: 16 de maio de 2025
"""

import os
import sys
import json
import logging
import hashlib
import time
import asyncio
import subprocess
from datetime import datetime
from logging.handlers import TimedRotatingFileHandler

# Configurar logging
log_dir = 'logs'
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, 'validacao_regressao.log')

# Configurar logger com rotação diária
logger = logging.getLogger("validacao_regressao")
handler = TimedRotatingFileHandler(
    filename=log_file,
    when='midnight',
    interval=1,
    backupCount=30,
    encoding='utf-8'
)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

# Adicionar handler para console também
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)

logger.setLevel(logging.INFO)

# Definir arquivos críticos para verificação
ARQUIVOS_CRITICOS = [
    "main.py",
    "config.json",
    "src/core/binance_stream.py",
    "src/core/binance_stream_resilient.py",
    "src/core/network_resilience.py",
    "src/intelligence/simulator.py",
    "backup.sh",
    "corrigir_permissoes.py"
]

# Definir componentes principais para verificação
COMPONENTES_PRINCIPAIS = [
    "src/core/binance_stream_resilient.py",
    "src/core/network_resilience.py",
    "src/intelligence/simulator.py"
]

def calcular_hash_arquivo(arquivo):
    """Calcula o hash SHA-256 de um arquivo."""
    try:
        with open(arquivo, 'rb') as f:
            return hashlib.sha256(f.read()).hexdigest()
    except Exception as e:
        logger.error(f"Erro ao calcular hash do arquivo {arquivo}: {e}")
        return None

def verificar_integridade_arquivos():
    """Verifica a integridade dos arquivos críticos."""
    logger.info("Verificando integridade dos arquivos críticos...")
    
    resultados = []
    
    for arquivo in ARQUIVOS_CRITICOS:
        caminho_completo = os.path.join(os.getcwd(), arquivo)
        
        if not os.path.exists(caminho_completo):
            logger.warning(f"Arquivo crítico não encontrado: {caminho_completo}")
            resultados.append({
                "arquivo": arquivo,
                "status": "não encontrado",
                "hash": None
            })
            continue
        
        hash_arquivo = calcular_hash_arquivo(caminho_completo)
        
        if hash_arquivo:
            logger.info(f"Arquivo {arquivo} verificado com sucesso. Hash: {hash_arquivo[:8]}...")
            resultados.append({
                "arquivo": arquivo,
                "status": "verificado",
                "hash": hash_arquivo,
                "tamanho": os.path.getsize(caminho_completo)
            })
        else:
            logger.error(f"Falha ao verificar arquivo: {arquivo}")
            resultados.append({
                "arquivo": arquivo,
                "status": "erro",
                "hash": None
            })
    
    return resultados

def verificar_permissoes_arquivos():
    """Verifica as permissões dos arquivos críticos."""
    logger.info("Verificando permissões dos arquivos críticos...")
    
    resultados = []
    
    for arquivo in ARQUIVOS_CRITICOS:
        caminho_completo = os.path.join(os.getcwd(), arquivo)
        
        if not os.path.exists(caminho_completo):
            logger.warning(f"Arquivo crítico não encontrado: {caminho_completo}")
            resultados.append({
                "arquivo": arquivo,
                "status": "não encontrado",
                "permissao": None
            })
            continue
        
        try:
            stat_info = os.stat(caminho_completo)
            permissao = stat_info.st_mode & 0o777  # Extrair apenas os bits de permissão
            permissao_octal = oct(permissao)[2:]
            
            # Verificar se as permissões estão de acordo com as recomendações
            if arquivo == "config.json" and permissao != 0o600:
                logger.warning(f"Arquivo {arquivo} com permissão inadequada: {permissao_octal} (recomendado: 600)")
                status = "inadequado"
            elif arquivo.endswith(".py") and permissao != 0o755 and permissao != 0o644:
                logger.warning(f"Arquivo {arquivo} com permissão inadequada: {permissao_octal} (recomendado: 755 ou 644)")
                status = "inadequado"
            elif arquivo.endswith(".sh") and permissao != 0o755:
                logger.warning(f"Arquivo {arquivo} com permissão inadequada: {permissao_octal} (recomendado: 755)")
                status = "inadequado"
            else:
                logger.info(f"Arquivo {arquivo} com permissão adequada: {permissao_octal}")
                status = "adequado"
            
            resultados.append({
                "arquivo": arquivo,
                "status": status,
                "permissao": permissao_octal
            })
        except Exception as e:
            logger.error(f"Erro ao verificar permissões do arquivo {arquivo}: {e}")
            resultados.append({
                "arquivo": arquivo,
                "status": "erro",
                "permissao": None
            })
    
    return resultados

def verificar_sintaxe_python():
    """Verifica a sintaxe dos arquivos Python críticos."""
    logger.info("Verificando sintaxe dos arquivos Python críticos...")
    
    resultados = []
    
    for arquivo in COMPONENTES_PRINCIPAIS:
        caminho_completo = os.path.join(os.getcwd(), arquivo)
        
        if not os.path.exists(caminho_completo):
            logger.warning(f"Arquivo crítico não encontrado: {caminho_completo}")
            resultados.append({
                "arquivo": arquivo,
                "status": "não encontrado"
            })
            continue
        
        try:
            # Usar o compilador Python para verificar a sintaxe
            subprocess.run(
                ["python", "-m", "py_compile", caminho_completo],
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            logger.info(f"Arquivo {arquivo} com sintaxe Python válida.")
            resultados.append({
                "arquivo": arquivo,
                "status": "válido"
            })
        except subprocess.CalledProcessError as e:
            logger.error(f"Erro de sintaxe no arquivo {arquivo}: {e.stderr.decode() if e.stderr else str(e)}")
            resultados.append({
                "arquivo": arquivo,
                "status": "inválido",
                "erro": e.stderr.decode() if e.stderr else str(e)
            })
        except Exception as e:
            logger.error(f"Erro ao verificar sintaxe do arquivo {arquivo}: {e}")
            resultados.append({
                "arquivo": arquivo,
                "status": "erro",
                "erro": str(e)
            })
    
    return resultados

def verificar_configuracao():
    """Verifica a configuração do sistema."""
    logger.info("Verificando configuração do sistema...")
    
    try:
        with open("config.json", "r") as f:
            config = json.load(f)
        
        # Verificar chaves críticas
        chaves_criticas = [
            "binance_api_key",
            "binance_api_secret",
            "testnet",
            "components_activation"
        ]
        
        chaves_faltantes = [chave for chave in chaves_criticas if chave not in config]
        
        if chaves_faltantes:
            logger.warning(f"Chaves críticas faltando na configuração: {chaves_faltantes}")
            return {
                "status": "incompleto",
                "chaves_faltantes": chaves_faltantes
            }
        
        # Verificar chave fallback_active
        if "components_activation" in config and "fallback_active" in config["components_activation"]:
            logger.info("Chave 'fallback_active' encontrada na configuração.")
        else:
            logger.warning("Chave 'fallback_active' não encontrada na configuração.")
            return {
                "status": "incompleto",
                "problema": "Chave 'fallback_active' não encontrada"
            }
        
        logger.info("Configuração verificada com sucesso.")
        return {
            "status": "válido",
            "testnet": config.get("testnet", False),
            "components_activation": config.get("components_activation", {})
        }
    except Exception as e:
        logger.error(f"Erro ao verificar configuração: {e}")
        return {
            "status": "erro",
            "erro": str(e)
        }

def verificar_script_backup():
    """Verifica o script de backup."""
    logger.info("Verificando script de backup...")
    
    caminho_backup = os.path.join(os.getcwd(), "backup.sh")
    
    if not os.path.exists(caminho_backup):
        logger.warning("Script de backup não encontrado.")
        return {
            "status": "não encontrado"
        }
    
    try:
        # Verificar permissões
        stat_info = os.stat(caminho_backup)
        permissao = stat_info.st_mode & 0o777
        permissao_octal = oct(permissao)[2:]
        
        if permissao != 0o755:
            logger.warning(f"Script de backup com permissão inadequada: {permissao_octal} (recomendado: 755)")
            status_permissao = "inadequado"
        else:
            logger.info(f"Script de backup com permissão adequada: {permissao_octal}")
            status_permissao = "adequado"
        
        # Verificar conteúdo
        with open(caminho_backup, "r") as f:
            conteudo = f.read()
        
        # Verificar funções críticas
        funcoes_criticas = [
            "create_backup",
            "calculate_hash",
            "rotate_backups",
            "test_restore",
            "generate_report"
        ]
        
        funcoes_faltantes = []
        for funcao in funcoes_criticas:
            if funcao not in conteudo:
                funcoes_faltantes.append(funcao)
        
        if funcoes_faltantes:
            logger.warning(f"Funções críticas faltando no script de backup: {funcoes_faltantes}")
            status_conteudo = "incompleto"
        else:
            logger.info("Todas as funções críticas encontradas no script de backup.")
            status_conteudo = "completo"
        
        return {
            "status": "verificado",
            "permissao": {
                "valor": permissao_octal,
                "status": status_permissao
            },
            "conteudo": {
                "status": status_conteudo,
                "funcoes_faltantes": funcoes_faltantes
            }
        }
    except Exception as e:
        logger.error(f"Erro ao verificar script de backup: {e}")
        return {
            "status": "erro",
            "erro": str(e)
        }

def verificar_script_permissoes():
    """Verifica o script de correção de permissões."""
    logger.info("Verificando script de correção de permissões...")
    
    caminho_script = os.path.join(os.getcwd(), "corrigir_permissoes.py")
    
    if not os.path.exists(caminho_script):
        logger.warning("Script de correção de permissões não encontrado.")
        return {
            "status": "não encontrado"
        }
    
    try:
        # Verificar permissões
        stat_info = os.stat(caminho_script)
        permissao = stat_info.st_mode & 0o777
        permissao_octal = oct(permissao)[2:]
        
        if permissao != 0o755 and permissao != 0o644:
            logger.warning(f"Script de correção de permissões com permissão inadequada: {permissao_octal} (recomendado: 755 ou 644)")
            status_permissao = "inadequado"
        else:
            logger.info(f"Script de correção de permissões com permissão adequada: {permissao_octal}")
            status_permissao = "adequado"
        
        # Verificar conteúdo
        with open(caminho_script, "r") as f:
            conteudo = f.read()
        
        # Verificar funções críticas
        funcoes_criticas = [
            "verificar_permissao",
            "corrigir_permissao",
            "gerar_relatorio"
        ]
        
        funcoes_faltantes = []
        for funcao in funcoes_criticas:
            if funcao not in conteudo:
                funcoes_faltantes.append(funcao)
        
        if funcoes_faltantes:
            logger.warning(f"Funções críticas faltando no script de correção de permissões: {funcoes_faltantes}")
            status_conteudo = "incompleto"
        else:
            logger.info("Todas as funções críticas encontradas no script de correção de permissões.")
            status_conteudo = "completo"
        
        return {
            "status": "verificado",
            "permissao": {
                "valor": permissao_octal,
                "status": status_permissao
            },
            "conteudo": {
                "status": status_conteudo,
                "funcoes_faltantes": funcoes_faltantes
            }
        }
    except Exception as e:
        logger.error(f"Erro ao verificar script de correção de permissões: {e}")
        return {
            "status": "erro",
            "erro": str(e)
        }

def verificar_modulo_resiliencia():
    """Verifica o módulo de resiliência de rede."""
    logger.info("Verificando módulo de resiliência de rede...")
    
    caminho_modulo = os.path.join(os.getcwd(), "src/core/network_resilience.py")
    
    if not os.path.exists(caminho_modulo):
        logger.warning("Módulo de resiliência de rede não encontrado.")
        return {
            "status": "não encontrado"
        }
    
    try:
        # Verificar conteúdo
        with open(caminho_modulo, "r") as f:
            conteudo = f.read()
        
        # Verificar classes e funções críticas
        elementos_criticos = [
            "NetworkResilience",
            "NetworkStatus",
            "NetworkFailureType",
            "calculate_delay",
            "classify_error",
            "execute_with_retry"
        ]
        
        elementos_faltantes = []
        for elemento in elementos_criticos:
            if elemento not in conteudo:
                elementos_faltantes.append(elemento)
        
        if elementos_faltantes:
            logger.warning(f"Elementos críticos faltando no módulo de resiliência: {elementos_faltantes}")
            status_conteudo = "incompleto"
        else:
            logger.info("Todos os elementos críticos encontrados no módulo de resiliência.")
            status_conteudo = "completo"
        
        # Verificar implementação de backoff exponencial
        if "backoff exponencial" in conteudo.lower() or "exponential backoff" in conteudo.lower():
            logger.info("Implementação de backoff exponencial encontrada.")
            backoff_status = "implementado"
        else:
            logger.warning("Implementação de backoff exponencial não encontrada.")
            backoff_status = "não implementado"
        
        # Verificar implementação de circuit breaker
        if "circuit breaker" in conteudo.lower() or "circuit_breaker" in conteudo.lower():
            logger.info("Implementação de circuit breaker encontrada.")
            circuit_breaker_status = "implementado"
        else:
            logger.warning("Implementação de circuit breaker não encontrada.")
            circuit_breaker_status = "não implementado"
        
        return {
            "status": "verificado",
            "conteudo": {
                "status": status_conteudo,
                "elementos_faltantes": elementos_faltantes
            },
            "backoff_exponencial": backoff_status,
            "circuit_breaker": circuit_breaker_status
        }
    except Exception as e:
        logger.error(f"Erro ao verificar módulo de resiliência: {e}")
        return {
            "status": "erro",
            "erro": str(e)
        }

def verificar_modulo_binance_resilient():
    """Verifica o módulo de conexão resiliente com a Binance."""
    logger.info("Verificando módulo de conexão resiliente com a Binance...")
    
    caminho_modulo = os.path.join(os.getcwd(), "src/core/binance_stream_resilient.py")
    
    if not os.path.exists(caminho_modulo):
        logger.warning("Módulo de conexão resiliente com a Binance não encontrado.")
        return {
            "status": "não encontrado"
        }
    
    try:
        # Verificar conteúdo
        with open(caminho_modulo, "r") as f:
            conteudo = f.read()
        
        # Verificar classes e funções críticas
        elementos_criticos = [
            "ConnectionStats",
            "conectar_binance_resiliente",
            "verificar_heartbeat",
            "processar_mensagem"
        ]
        
        elementos_faltantes = []
        for elemento in elementos_criticos:
            if elemento not in conteudo:
                elementos_faltantes.append(elemento)
        
        if elementos_faltantes:
            logger.warning(f"Elementos críticos faltando no módulo de conexão resiliente: {elementos_faltantes}")
            status_conteudo = "incompleto"
        else:
            logger.info("Todos os elementos críticos encontrados no módulo de conexão resiliente.")
            status_conteudo = "completo"
        
        # Verificar integração com NetworkResilience
        if "NetworkResilience" in conteudo:
            logger.info("Integração com NetworkResilience encontrada.")
            integracao_status = "implementado"
        else:
            logger.warning("Integração com NetworkResilience não encontrada.")
            integracao_status = "não implementado"
        
        # Verificar implementação de logs detalhados
        if "TimedRotatingFileHandler" in conteudo:
            logger.info("Implementação de logs com rotação encontrada.")
            logs_status = "implementado"
        else:
            logger.warning("Implementação de logs com rotação não encontrada.")
            logs_status = "não implementado"
        
        return {
            "status": "verificado",
            "conteudo": {
                "status": status_conteudo,
                "elementos_faltantes": elementos_faltantes
            },
            "integracao_network_resilience": integracao_status,
            "logs_rotacao": logs_status
        }
    except Exception as e:
        logger.error(f"Erro ao verificar módulo de conexão resiliente: {e}")
        return {
            "status": "erro",
            "erro": str(e)
        }

def gerar_relatorio(resultados):
    """Gera um relatório detalhado da validação."""
    logger.info("Gerando relatório de validação...")
    
    # Calcular estatísticas
    total_arquivos = len(resultados["integridade_arquivos"])
    arquivos_ok = sum(1 for r in resultados["integridade_arquivos"] if r["status"] == "verificado")
    
    total_permissoes = len(resultados["permissoes_arquivos"])
    permissoes_ok = sum(1 for r in resultados["permissoes_arquivos"] if r["status"] == "adequado")
    
    total_sintaxe = len(resultados["sintaxe_python"])
    sintaxe_ok = sum(1 for r in resultados["sintaxe_python"] if r["status"] == "válido")
    
    # Determinar status geral
    if (resultados["configuracao"]["status"] == "válido" and
        resultados["script_backup"]["status"] == "verificado" and
        resultados["script_permissoes"]["status"] == "verificado" and
        resultados["modulo_resiliencia"]["status"] == "verificado" and
        resultados["modulo_binance_resilient"]["status"] == "verificado" and
        arquivos_ok == total_arquivos and
        permissoes_ok == total_permissoes and
        sintaxe_ok == total_sintaxe):
        status_geral = "APROVADO"
    else:
        status_geral = "ATENÇÃO"
    
    # Criar relatório
    relatorio = {
        "timestamp": datetime.now().isoformat(),
        "status_geral": status_geral,
        "estatisticas": {
            "arquivos": {
                "total": total_arquivos,
                "verificados": arquivos_ok,
                "percentual": round(arquivos_ok / total_arquivos * 100, 2) if total_arquivos > 0 else 0
            },
            "permissoes": {
                "total": total_permissoes,
                "adequadas": permissoes_ok,
                "percentual": round(permissoes_ok / total_permissoes * 100, 2) if total_permissoes > 0 else 0
            },
            "sintaxe": {
                "total": total_sintaxe,
                "validas": sintaxe_ok,
                "percentual": round(sintaxe_ok / total_sintaxe * 100, 2) if total_sintaxe > 0 else 0
            }
        },
        "resultados_detalhados": resultados
    }
    
    # Salvar relatório em JSON
    relatorio_file = os.path.join(log_dir, f"validacao_regressao_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
    with open(relatorio_file, 'w') as f:
        json.dump(relatorio, f, indent=2)
    
    logger.info(f"Relatório salvo em {relatorio_file}")
    
    # Exibir resumo
    logger.info("\n" + "="*50)
    logger.info(f"RESUMO DA VALIDAÇÃO DE REGRESSÃO")
    logger.info("="*50)
    logger.info(f"Status geral: {status_geral}")
    logger.info(f"Arquivos: {arquivos_ok}/{total_arquivos} ({round(arquivos_ok / total_arquivos * 100, 2)}%)")
    logger.info(f"Permissões: {permissoes_ok}/{total_permissoes} ({round(permissoes_ok / total_permissoes * 100, 2)}%)")
    logger.info(f"Sintaxe Python: {sintaxe_ok}/{total_sintaxe} ({round(sintaxe_ok / total_sintaxe * 100, 2)}%)")
    logger.info(f"Configuração: {resultados['configuracao']['status']}")
    logger.info(f"Script de backup: {resultados['script_backup']['status']}")
    logger.info(f"Script de permissões: {resultados['script_permissoes']['status']}")
    logger.info(f"Módulo de resiliência: {resultados['modulo_resiliencia']['status']}")
    logger.info(f"Módulo de conexão resiliente: {resultados['modulo_binance_resilient']['status']}")
    logger.info("="*50)
    
    return relatorio, relatorio_file

def main():
    """Função principal para validação de regressão."""
    logger.info("Iniciando validação de regressão...")
    
    # Verificar diretório atual
    logger.info(f"Diretório atual: {os.getcwd()}")
    
    # Executar verificações
    resultados = {
        "integridade_arquivos": verificar_integridade_arquivos(),
        "permissoes_arquivos": verificar_permissoes_arquivos(),
        "sintaxe_python": verificar_sintaxe_python(),
        "configuracao": verificar_configuracao(),
        "script_backup": verificar_script_backup(),
        "script_permissoes": verificar_script_permissoes(),
        "modulo_resiliencia": verificar_modulo_resiliencia(),
        "modulo_binance_resilient": verificar_modulo_binance_resilient()
    }
    
    # Gerar relatório
    relatorio, relatorio_file = gerar_relatorio(resultados)
    
    return relatorio, relatorio_file

if __name__ == "__main__":
    main()
