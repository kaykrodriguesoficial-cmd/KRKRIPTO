#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script para validar a integração do main_corrigido_mac_m1.py com os módulos do sistema.
Este script executa todos os testes automatizados e valida os módulos afetados
para garantir ausência de regressão.
"""

import os
import sys
import json
import time
import logging
import subprocess
import platform
import importlib.util
from pathlib import Path

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("validacao_integracao")

def verificar_ambiente_mac_m1():
    """Verifica se o ambiente atual é um Mac M1."""
    is_mac_m1 = False
    try:
        if platform.system() == "Darwin" and ("arm" in platform.machine().lower() or "M1" in platform.processor()):
            is_mac_m1 = True
            logger.info(f"Ambiente Mac M1 detectado: {platform.machine()} / {platform.processor()}")
        else:
            logger.info(f"Ambiente não é Mac M1: {platform.system()} / {platform.machine()}")
    except Exception as e:
        logger.error(f"Erro ao detectar ambiente: {str(e)}")
    
    return is_mac_m1

def verificar_dependencias():
    """Verifica se todas as dependências necessárias estão instaladas."""
    dependencias = [
        "pandas",
        "numpy",
        "pytest",
        "aiohttp",
        "tensorflow",
        "keras"
    ]
    
    dependencias_faltantes = []
    
    for dep in dependencias:
        try:
            importlib.import_module(dep)
            logger.info(f"Dependência {dep} encontrada")
        except ImportError:
            logger.warning(f"Dependência {dep} não encontrada")
            dependencias_faltantes.append(dep)
    
    if dependencias_faltantes:
        logger.warning(f"Dependências faltantes: {', '.join(dependencias_faltantes)}")
        return False
    
    logger.info("Todas as dependências necessárias estão instaladas")
    return True

def executar_validation_script_module_status():
    """Executa o script validation_script_module_status.py e verifica o resultado."""
    script_path = "validation_script_module_status.py"
    
    # Verificar se o arquivo existe
    if not os.path.exists(script_path):
        logger.error(f"Arquivo {script_path} não encontrado")
        return False
    
    # Executar o script
    logger.info(f"Executando {script_path}...")
    
    try:
        # Executar com timeout de 60 segundos
        process = subprocess.Popen(
            [sys.executable, script_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        stdout, stderr = process.communicate(timeout=60)
        
        # Verificar se houve erro
        if process.returncode != 0:
            logger.error(f"Erro ao executar {script_path}: código de retorno {process.returncode}")
            logger.error(f"Saída de erro: {stderr}")
            return False
        
        logger.info(f"Execução de {script_path} bem-sucedida")
        return True
        
    except subprocess.TimeoutExpired:
        # Matar o processo se exceder o timeout
        process.kill()
        logger.warning(f"Timeout ao executar {script_path}")
        return False
        
    except Exception as e:
        logger.error(f"Erro ao executar {script_path}: {str(e)}")
        return False

def executar_pytest():
    """Executa os testes com pytest e verifica o resultado."""
    # Verificar se o diretório de testes existe
    tests_dir = "tests"
    if not os.path.exists(tests_dir) or not os.path.isdir(tests_dir):
        logger.error(f"Diretório {tests_dir} não encontrado")
        return False
    
    # Executar pytest
    logger.info(f"Executando pytest {tests_dir}...")
    
    try:
        # Executar com timeout de 120 segundos
        process = subprocess.Popen(
            [sys.executable, "-m", "pytest", tests_dir, "-v"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        stdout, stderr = process.communicate(timeout=120)
        
        # Verificar se houve erro
        if process.returncode != 0:
            logger.error(f"Erro ao executar pytest: código de retorno {process.returncode}")
            logger.error(f"Saída de erro: {stderr}")
            
            # Verificar se há testes pulados
            if "SKIPPED" in stdout:
                logger.warning("Alguns testes foram pulados")
                
            return False
        
        logger.info("Execução de pytest bem-sucedida")
        return True
        
    except subprocess.TimeoutExpired:
        # Matar o processo se exceder o timeout
        process.kill()
        logger.warning("Timeout ao executar pytest")
        return False
        
    except Exception as e:
        logger.error(f"Erro ao executar pytest: {str(e)}")
        return False

def verificar_integracao_config_loader():
    """Verifica a integração com o módulo config_loader."""
    try:
        # Importar o módulo
        sys.path.append(os.getcwd())
        from src.core.config_loader import carregar_config, obter_config_segura
        
        # Testar a função carregar_config
        config_path = "config.json"
        if not os.path.exists(config_path):
            logger.error(f"Arquivo {config_path} não encontrado")
            return False
        
        config = carregar_config(config_path)
        if not config:
            logger.error("Falha ao carregar a configuração")
            return False
        
        # Testar a função obter_config_segura
        config_segura = obter_config_segura(config)
        if not config_segura:
            logger.error("Falha ao obter configuração segura")
            return False
        
        logger.info("Integração com config_loader verificada com sucesso")
        return True
        
    except Exception as e:
        logger.error(f"Erro ao verificar integração com config_loader: {str(e)}")
        return False

def verificar_integracao_main_corrigido():
    """Verifica a integração do main_corrigido_mac_m1.py com os módulos do sistema."""
    try:
        # Importar o módulo
        main_path = "main_corrigido_mac_m1.py"
        if not os.path.exists(main_path):
            logger.error(f"Arquivo {main_path} não encontrado")
            return False
        
        # Carregar o módulo sem executá-lo
        spec = importlib.util.spec_from_file_location("main_module", main_path)
        main_module = importlib.util.module_from_spec(spec)
        
        # Verificar se as funções principais estão presentes
        funcoes_principais = [
            "inicializar_componentes",
            "finalizar_componentes",
            "processar_dados",
            "executar_simulacao",
            "executar_producao",
            "main_async",
            "main"
        ]
        
        for funcao in funcoes_principais:
            if not hasattr(main_module, funcao):
                logger.error(f"Função {funcao} não encontrada no módulo main_corrigido_mac_m1.py")
                return False
        
        logger.info("Todas as funções principais estão presentes no main_corrigido_mac_m1.py")
        return True
        
    except Exception as e:
        logger.error(f"Erro ao verificar integração do main_corrigido_mac_m1.py: {str(e)}")
        return False

def verificar_tamanho_arquivo():
    """Verifica se o tamanho do arquivo main_corrigido_mac_m1.py é compatível com o original."""
    try:
        # Verificar tamanho do arquivo original
        original_path = "upload/main.py"
        if not os.path.exists(original_path):
            logger.warning(f"Arquivo original {original_path} não encontrado")
            return True  # Não é crítico
        
        # Verificar tamanho do arquivo corrigido
        corrigido_path = "main_corrigido_mac_m1.py"
        if not os.path.exists(corrigido_path):
            logger.error(f"Arquivo corrigido {corrigido_path} não encontrado")
            return False
        
        # Obter tamanho dos arquivos
        tamanho_original = os.path.getsize(original_path)
        tamanho_corrigido = os.path.getsize(corrigido_path)
        
        # Calcular diferença percentual
        diferenca_percentual = abs(tamanho_original - tamanho_corrigido) / tamanho_original * 100
        
        logger.info(f"Tamanho do arquivo original: {tamanho_original} bytes")
        logger.info(f"Tamanho do arquivo corrigido: {tamanho_corrigido} bytes")
        logger.info(f"Diferença percentual: {diferenca_percentual:.2f}%")
        
        # Verificar se a diferença é aceitável (menos de 10%)
        if diferenca_percentual > 10:
            logger.warning(f"Diferença de tamanho significativa: {diferenca_percentual:.2f}%")
            return False
        
        logger.info("Tamanho do arquivo corrigido é compatível com o original")
        return True
        
    except Exception as e:
        logger.error(f"Erro ao verificar tamanho do arquivo: {str(e)}")
        return False

def gerar_relatorio_validacao():
    """Gera um relatório de validação com os resultados dos testes."""
    relatorio_path = "relatorio_validacao_main_corrigido.md"
    
    try:
        # Criar relatório
        with open(relatorio_path, 'w') as f:
            f.write("# Relatório de Validação do main_corrigido_mac_m1.py\n\n")
            f.write(f"Data: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            # Informações do ambiente
            f.write("## Informações do Ambiente\n\n")
            f.write(f"- Sistema Operacional: {platform.system()} {platform.release()}\n")
            f.write(f"- Arquitetura: {platform.machine()}\n")
            f.write(f"- Processador: {platform.processor()}\n")
            f.write(f"- Python: {platform.python_version()}\n\n")
            
            # Resultados dos testes
            f.write("## Resultados dos Testes\n\n")
            
            # Verificar ambiente Mac M1
            is_mac_m1 = verificar_ambiente_mac_m1()
            f.write(f"- Ambiente Mac M1: {'Sim' if is_mac_m1 else 'Não'}\n")
            
            # Verificar dependências
            dependencias_ok = verificar_dependencias()
            f.write(f"- Dependências: {'OK' if dependencias_ok else 'Faltando algumas dependências'}\n")
            
            # Verificar tamanho do arquivo
            tamanho_ok = verificar_tamanho_arquivo()
            f.write(f"- Tamanho do arquivo: {'Compatível' if tamanho_ok else 'Diferença significativa'}\n")
            
            # Verificar integração com config_loader
            config_loader_ok = verificar_integracao_config_loader()
            f.write(f"- Integração com config_loader: {'OK' if config_loader_ok else 'Falha'}\n")
            
            # Verificar integração do main_corrigido
            main_corrigido_ok = verificar_integracao_main_corrigido()
            f.write(f"- Integração do main_corrigido_mac_m1.py: {'OK' if main_corrigido_ok else 'Falha'}\n")
            
            # Executar validation_script_module_status
            validation_script_ok = executar_validation_script_module_status()
            f.write(f"- Execução de validation_script_module_status.py: {'OK' if validation_script_ok else 'Falha'}\n")
            
            # Executar pytest
            pytest_ok = executar_pytest()
            f.write(f"- Execução de pytest: {'OK' if pytest_ok else 'Falha'}\n\n")
            
            # Conclusão
            todos_ok = (
                dependencias_ok and
                tamanho_ok and
                config_loader_ok and
                main_corrigido_ok and
                validation_script_ok and
                pytest_ok
            )
            
            f.write("## Conclusão\n\n")
            if todos_ok:
                f.write("✅ **Todos os testes foram executados com sucesso!**\n\n")
                f.write("O arquivo main_corrigido_mac_m1.py está pronto para uso em ambiente Mac M1.\n")
            else:
                f.write("❌ **Alguns testes falharam.**\n\n")
                f.write("O arquivo main_corrigido_mac_m1.py pode precisar de ajustes adicionais.\n")
            
            # Recomendações
            f.write("\n## Recomendações\n\n")
            if not is_mac_m1:
                f.write("- Executar os testes em um ambiente Mac M1 real para validação completa.\n")
            if not dependencias_ok:
                f.write("- Instalar todas as dependências necessárias.\n")
            if not tamanho_ok:
                f.write("- Verificar se todas as funcionalidades do arquivo original foram preservadas.\n")
            if not config_loader_ok:
                f.write("- Verificar a integração com o módulo config_loader.\n")
            if not main_corrigido_ok:
                f.write("- Verificar se todas as funções principais estão presentes no main_corrigido_mac_m1.py.\n")
            if not validation_script_ok:
                f.write("- Verificar a execução do script validation_script_module_status.py.\n")
            if not pytest_ok:
                f.write("- Verificar a execução dos testes com pytest.\n")
        
        logger.info(f"Relatório de validação gerado: {relatorio_path}")
        return True
        
    except Exception as e:
        logger.error(f"Erro ao gerar relatório de validação: {str(e)}")
        return False

def main():
    """Função principal."""
    logger.info("Iniciando validação de integração do main_corrigido_mac_m1.py")
    
    # Verificar ambiente
    is_mac_m1 = verificar_ambiente_mac_m1()
    if not is_mac_m1:
        logger.warning("Este script está sendo executado em um ambiente que não é Mac M1")
        logger.warning("A validação continuará, mas os resultados podem não ser representativos")
    
    # Verificar dependências
    verificar_dependencias()
    
    # Verificar tamanho do arquivo
    verificar_tamanho_arquivo()
    
    # Verificar integração com config_loader
    verificar_integracao_config_loader()
    
    # Verificar integração do main_corrigido
    verificar_integracao_main_corrigido()
    
    # Executar validation_script_module_status
    executar_validation_script_module_status()
    
    # Executar pytest
    executar_pytest()
    
    # Gerar relatório de validação
    gerar_relatorio_validacao()
    
    logger.info("Validação de integração concluída!")
    return 0

if __name__ == "__main__":
    sys.exit(main())
