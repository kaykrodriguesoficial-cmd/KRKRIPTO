#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script para validar a execução do main_corrigido_mac_m1.py no ambiente Mac M1.
Este script verifica se o arquivo corrigido executa sem erros e se o problema
do registro de histórico foi resolvido.
"""

import os
import sys
import json
import time
import logging
import subprocess
import platform

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("validacao_main")

def verificar_ambiente_mac_m1():
    """Verifica se o ambiente atual é um Mac M1."""
    is_mac_m1 = False
    try:
        if platform.system() == "Darwin" and ("arm" in platform.machine().lower() or "M1" in platform.processor()):
            is_mac_m1 = True
            logger.info(f"Ambiente Mac M1 detectado: {platform.machine()} / {platform.processor()}")
        else:
            logger.info(f"Ambiente não é Mac M1: {platform.system()} / {platform.machine()}")
    except Exception as e:
        logger.error(f"Erro ao detectar ambiente: {str(e)}")
    
    return is_mac_m1

def verificar_arquivo_config():
    """Verifica se o arquivo config.json existe e é válido."""
    config_path = "config.json"
    
    if not os.path.exists(config_path):
        logger.warning(f"Arquivo de configuração não encontrado: {config_path}")
        logger.info("Criando arquivo de configuração padrão...")
        
        # Criar configuração padrão
        config = {
            "version": "3.5.0",
            "environment": "production",
            "mode": "production",
            "log_level": "INFO",
            "components_activation": {
                "fallback_active": True,
                "memoria_temporal_active": True,
                "attack_detector_active": True,
                "model_performance_tracker_active": True,
                "neural_governor_active": True,
                "institutional_validator_active": True
            },
            "paths": {
                "models": "models/",
                "data": "data/",
                "logs": "logs/"
            },
            "verificar_assinatura": False,
            "verificar_integridade_modelos": False,
            "model_paths": {
                "neural_governor": "models/neural_governor/",
                "pattern_detector": "models/pattern_detector/"
            },
            "neural_governor_config": {
                "confidence_threshold": 0.75,
                "max_models": 5
            },
            "attack_detector_config": {
                "sensitivity": "medium"
            },
            "model_performance_tracker_config": {
                "degradation_threshold": 0.15,
                "history_size": 100
            },
            "institutional_validator_config": {
                "min_confidence": 0.8
            },
            "dashboard": {
                "enabled": False,
                "host": "0.0.0.0",
                "port": 8050,
                "debug": False
            }
        }
        
        # Salvar configuração
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
        
        logger.info(f"Arquivo de configuração criado: {config_path}")
        return True
    
    # Verificar se o arquivo é um JSON válido
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
        logger.info(f"Arquivo de configuração válido: {config_path}")
        return True
    except json.JSONDecodeError as e:
        logger.error(f"Arquivo de configuração inválido: {str(e)}")
        return False
    except Exception as e:
        logger.error(f"Erro ao verificar arquivo de configuração: {str(e)}")
        return False

def verificar_startup_times():
    """Verifica se o arquivo startup_times.json existe e é válido."""
    startup_times_path = "startup_times.json"
    
    if os.path.exists(startup_times_path):
        try:
            with open(startup_times_path, 'r') as f:
                startup_times = json.load(f)
            
            # Verificar se é uma lista
            if not isinstance(startup_times, list):
                logger.warning(f"Arquivo {startup_times_path} não contém uma lista. Removendo...")
                os.remove(startup_times_path)
                return False
            
            logger.info(f"Arquivo {startup_times_path} válido com {len(startup_times)} registros")
            return True
        except Exception as e:
            logger.warning(f"Erro ao verificar {startup_times_path}: {str(e)}. Removendo...")
            os.remove(startup_times_path)
            return False
    
    logger.info(f"Arquivo {startup_times_path} não existe")
    return False

def executar_main_corrigido():
    """Executa o main_corrigido_mac_m1.py e verifica se ocorre algum erro."""
    # Verificar se o arquivo existe
    main_path = "main_corrigido_mac_m1.py"
    if not os.path.exists(main_path):
        logger.error(f"Arquivo {main_path} não encontrado")
        return False
    
    # Tornar o arquivo executável
    try:
        os.chmod(main_path, 0o755)
    except Exception as e:
        logger.warning(f"Não foi possível tornar o arquivo executável: {str(e)}")
    
    # Executar o arquivo com timeout
    logger.info(f"Executando {main_path}...")
    
    try:
        # Executar com timeout de 30 segundos
        process = subprocess.Popen(
            [sys.executable, main_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        # Aguardar 30 segundos
        try:
            stdout, stderr = process.communicate(timeout=30)
            
            # Verificar se houve erro
            if process.returncode != 0:
                logger.error(f"Erro ao executar {main_path}: código de retorno {process.returncode}")
                logger.error(f"Saída de erro: {stderr}")
                return False
            
            # Verificar se houve erro de append
            if "Erro ao salvar tempo de inicialização: 'dict' object has no attribute 'append'" in stderr:
                logger.error("Erro de append detectado na saída de erro")
                return False
            
            if "Erro ao salvar tempo de inicialização: 'dict' object has no attribute 'append'" in stdout:
                logger.error("Erro de append detectado na saída padrão")
                return False
            
            logger.info(f"Execução de {main_path} bem-sucedida")
            return True
            
        except subprocess.TimeoutExpired:
            # Matar o processo se exceder o timeout
            process.kill()
            logger.warning(f"Timeout ao executar {main_path}")
            return False
            
    except Exception as e:
        logger.error(f"Erro ao executar {main_path}: {str(e)}")
        return False

def verificar_registro_historico():
    """Verifica se o registro de histórico foi criado corretamente."""
    startup_times_path = "startup_times.json"
    
    if not os.path.exists(startup_times_path):
        logger.error(f"Arquivo {startup_times_path} não foi criado")
        return False
    
    try:
        with open(startup_times_path, 'r') as f:
            startup_times = json.load(f)
        
        # Verificar se é uma lista
        if not isinstance(startup_times, list):
            logger.error(f"Arquivo {startup_times_path} não contém uma lista")
            return False
        
        # Verificar se há pelo menos um registro
        if len(startup_times) == 0:
            logger.error(f"Arquivo {startup_times_path} não contém registros")
            return False
        
        # Verificar se o último registro tem os campos esperados
        ultimo_registro = startup_times[-1]
        campos_esperados = ["timestamp", "duration_seconds", "components"]
        
        for campo in campos_esperados:
            if campo not in ultimo_registro:
                logger.error(f"Campo '{campo}' não encontrado no último registro")
                return False
        
        logger.info(f"Registro de histórico válido com {len(startup_times)} registros")
        return True
        
    except Exception as e:
        logger.error(f"Erro ao verificar registro de histórico: {str(e)}")
        return False

def main():
    """Função principal."""
    logger.info("Iniciando validação do main_corrigido_mac_m1.py")
    
    # Verificar ambiente
    is_mac_m1 = verificar_ambiente_mac_m1()
    if not is_mac_m1:
        logger.warning("Este script está sendo executado em um ambiente que não é Mac M1")
        logger.warning("A validação continuará, mas os resultados podem não ser representativos")
    
    # Verificar arquivo de configuração
    if not verificar_arquivo_config():
        logger.error("Falha na verificação do arquivo de configuração")
        return 1
    
    # Verificar arquivo de startup_times antes da execução
    verificar_startup_times()
    
    # Executar main corrigido
    if not executar_main_corrigido():
        logger.error("Falha na execução do main_corrigido_mac_m1.py")
        return 1
    
    # Verificar registro de histórico após a execução
    if not verificar_registro_historico():
        logger.error("Falha na verificação do registro de histórico")
        return 1
    
    logger.info("Validação concluída com sucesso!")
    return 0

if __name__ == "__main__":
    sys.exit(main())
