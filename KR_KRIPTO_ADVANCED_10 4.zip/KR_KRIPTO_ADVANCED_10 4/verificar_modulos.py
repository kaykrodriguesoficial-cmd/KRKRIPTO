#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import importlib
import logging
import platform

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("verificador_modulos")

# Adicionar o diretório atual ao sys.path
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

# Verificar ambiente
is_mac_m1 = False
if platform.system() == "Darwin" and ("arm" in platform.machine().lower() or "M1" in platform.processor()):
    is_mac_m1 = True
    logger.info(f"Ambiente Mac M1 detectado: {platform.machine()} / {platform.processor()}")
else:
    logger.info(f"Ambiente não-Mac M1 detectado: {platform.system()} / {platform.machine()}")

# Lista de módulos para verificar
modulos = [
    "src.intelligence.attack_detector.AttackDetector",
    "src.intelligence.governance.neural_governance.NeuralGovernor",
    "src.intelligence.institutional_patterns.InstitutionalPatternDetector",
    "src.intelligence.cluster_manager.ClusterManager",
    "src.core.book_imbalance.BookProcessor",
    "src.intelligence.reinforcement.ambiente.AmbienteRL",
    "src.intelligence.reinforcement.agente.AgenteRL"
]

# Verificar cada módulo
for modulo_path in modulos:
    logger.info(f"Verificando módulo: {modulo_path}")
    
    # Separar caminho do módulo e classe
    module_parts = modulo_path.split(".")
    class_name = module_parts[-1]
    module_path = ".".join(module_parts[:-1])
    
    try:
        # Tentar importar o módulo
        module = importlib.import_module(module_path)
        
        # Verificar se a classe existe
        if hasattr(module, class_name):
            logger.info(f"✅ Módulo {modulo_path} disponível")
            
            # Verificar se é possível instanciar
            try:
                class_obj = getattr(module, class_name)
                instance = class_obj()
                logger.info(f"✅ Classe {class_name} pode ser instanciada")
            except Exception as e:
                logger.warning(f"⚠️ Classe {class_name} não pode ser instanciada: {str(e)}")
        else:
            logger.warning(f"⚠️ Classe {class_name} não encontrada no módulo {module_path}")
    
    except ImportError as e:
        logger.error(f"❌ Módulo {module_path} não pode ser importado: {str(e)}")
    
    except Exception as e:
        logger.error(f"❌ Erro ao verificar módulo {modulo_path}: {str(e)}")

logger.info("Verificação de módulos concluída")
