"""
Módulo: book_feedback.py
Objetivo: Ajustar o score da IA dinamicamente com base no desequilíbrio do order book.
"""

def ajustar_score_por_book(score_ia: float, desequilibrio: float, sensibilidade: float = 0.15) -> float:
    """
    score_ia: Score original da IA (0.0 a 1.0)
    desequilibrio: Valor entre -1.0 (venda extrema) a +1.0 (compra extrema)
    sensibilidade: Quanto o desequilíbrio pode afetar o score (0.0 a 1.0)

    Retorna o score ajustado dinamicamente.
    """
    ajuste = desequilibrio * sensibilidade
    score_ajustado = score_ia + ajuste
    return round(max(0.0, min(1.0, score_ajustado)), 4)
