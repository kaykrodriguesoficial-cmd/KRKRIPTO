"""
Processador de Book em Tempo Real para KR_KRIPTO_FULL
Implementa análise tick-by-tick do livro de ofertas para detecção de padrões institucionais.

Versão: 1.0
Data: Abril 2025
"""

import numpy as np
import pandas as pd
from datetime import datetime
import asyncio
import logging
from typing import Dict, List, Any, Optional, Tuple, Set
from collections import deque
import json

# Configuração de logging
logger = logging.getLogger("kr_kripto.book_processor")

class BookState:
    """
    Representa o estado atual do livro de ofertas.
    """
    def __init__(self):
        self.bids: Dict[float, float] = {}  # preço -> quantidade
        self.asks: Dict[float, float] = {}  # preço -> quantidade
        self.timestamp: int = 0
        self.imbalance: float = 0.0  # Desequilíbrio normalizado (-1 a 1)
        self.institutional_patterns: Dict[str, Any] = {
            'paredes': {'significativo': False, 'nivel': 0.0, 'tamanho': 0.0, 'direcao': 0},
            'iceberg': {'significativo': False, 'nivel': 0.0, 'tamanho': 0.0, 'direcao': 0},
            'absorção': {'significativo': False, 'nivel': 0.0, 'tamanho': 0.0, 'direcao': 0},
            'spoofing': {'significativo': False, 'nivel': 0.0, 'tamanho': 0.0, 'direcao': 0},
            'significativo': False
        }
        self.last_update: datetime = datetime.now()
        self.spread: float = 0.0
        self.mid_price: float = 0.0
        self.volume_profile: Dict[float, float] = {}  # preço -> volume acumulado
        self.historical_imbalances: deque = deque(maxlen=100)  # Últimos 100 desequilíbrios

    def to_dict(self) -> Dict[str, Any]:
        """Converte o estado para um dicionário."""
        return {
            'timestamp': self.timestamp,
            'imbalance': self.imbalance,
            'institutional_patterns': self.institutional_patterns,
            'spread': self.spread,
            'mid_price': self.mid_price,
            'last_update': self.last_update.isoformat()
        }

class InstitutionalPatternDetector:
    """
    Detector de padrões institucionais no livro de ofertas.
    """
    def __init__(self, config: dict):
        self.symbol = symbol
        self.historical_states: deque = deque(maxlen=1000)  # Últimos 1000 estados
        self.wall_threshold = 2.0  # Multiplicador para detectar paredes
        self.iceberg_threshold = 0.5  # Limiar para detectar icebergs
        self.absorption_threshold = 0.7  # Limiar para detectar absorção
        self.spoofing_threshold = 0.8  # Limiar para detectar spoofing
        self.significance_threshold = 0.6  # Limiar para considerar um padrão significativo

    def detect_walls(self, bids: Dict[float, float], asks: Dict[float, float]) -> Dict[str, Any]:
        """
        Detecta paredes de ordens (grandes ordens em níveis específicos).
        """
        result = {'significativo': False, 'nivel': 0.0, 'tamanho': 0.0, 'direcao': 0}
        
        if not bids or not asks:
            return result
        
        # Calcular tamanho médio das ordens
        bid_sizes = list(bids.values())
        ask_sizes = list(asks.values())
        
        avg_bid_size = np.mean(bid_sizes) if bid_sizes else 0
        avg_ask_size = np.mean(ask_sizes) if ask_sizes else 0
        
        # Encontrar ordens grandes (paredes)
        max_bid_size = max(bid_sizes) if bid_sizes else 0
        max_ask_size = max(ask_sizes) if ask_sizes else 0
        
        max_bid_price = None
        max_ask_price = None
        
        if max_bid_size > avg_bid_size * self.wall_threshold:
            max_bid_price = [price for price, size in bids.items() if size == max_bid_size][0]
        
        if max_ask_size > avg_ask_size * self.wall_threshold:
            max_ask_price = [price for price, size in asks.items() if size == max_ask_size][0]
        
        # Determinar qual parede é mais significativa
        if max_bid_price and max_ask_price:
            if max_bid_size / avg_bid_size > max_ask_size / avg_ask_size:
                result = {
                    'significativo': True,
                    'nivel': float(max_bid_price),
                    'tamanho': float(max_bid_size),
                    'direcao': 1  # Parede de compra (suporte)
                }
            else:
                result = {
                    'significativo': True,
                    'nivel': float(max_ask_price),
                    'tamanho': float(max_ask_size),
                    'direcao': -1  # Parede de venda (resistência)
                }
        elif max_bid_price:
            result = {
                'significativo': True,
                'nivel': float(max_bid_price),
                'tamanho': float(max_bid_size),
                'direcao': 1  # Parede de compra (suporte)
            }
        elif max_ask_price:
            result = {
                'significativo': True,
                'nivel': float(max_ask_price),
                'tamanho': float(max_ask_size),
                'direcao': -1  # Parede de venda (resistência)
            }
        
        # Verificar se a parede é realmente significativa
        if result['significativo']:
            if result['direcao'] == 1:
                significance = result['tamanho'] / (avg_bid_size * self.wall_threshold)
            else:
                significance = result['tamanho'] / (avg_ask_size * self.wall_threshold)
            
            result['significativo'] = significance > self.significance_threshold
        
        return result

    def detect_icebergs(self, bids: Dict[float, float], asks: Dict[float, float], historical_states: deque) -> Dict[str, Any]:
        """
        Detecta ordens iceberg (grandes ordens escondidas que aparecem gradualmente).
        """
        result = {'significativo': False, 'nivel': 0.0, 'tamanho': 0.0, 'direcao': 0}
        
        if len(historical_states) < 10:
            return result
        
        # Analisar mudanças rápidas em níveis específicos
        bid_changes = {}
        ask_changes = {}
        
        # Obter estados recentes
        recent_states = list(historical_states)[-10:]
        
        # Analisar mudanças em cada nível de preço
        for i in range(1, len(recent_states)):
            prev_state = recent_states[i-1]
            curr_state = recent_states[i]
            
            # Analisar bids
            for price in set(list(prev_state.bids.keys()) + list(curr_state.bids.keys())):
                prev_qty = prev_state.bids.get(price, 0)
                curr_qty = curr_state.bids.get(price, 0)
                
                if curr_qty > prev_qty and price in prev_state.bids:
                    # Aumento de quantidade em nível existente
                    if price not in bid_changes:
                        bid_changes[price] = []
                    bid_changes[price].append(curr_qty - prev_qty)
            
            # Analisar asks
            for price in set(list(prev_state.asks.keys()) + list(curr_state.asks.keys())):
                prev_qty = prev_state.asks.get(price, 0)
                curr_qty = curr_state.asks.get(price, 0)
                
                if curr_qty > prev_qty and price in prev_state.asks:
                    # Aumento de quantidade em nível existente
                    if price not in ask_changes:
                        ask_changes[price] = []
                    ask_changes[price].append(curr_qty - prev_qty)
        
        # Identificar níveis com múltiplos aumentos (potenciais icebergs)
        iceberg_bids = {}
        iceberg_asks = {}
        
        for price, changes in bid_changes.items():
            if len(changes) >= 3:  # Pelo menos 3 aumentos
                iceberg_bids[price] = sum(changes)
        
        for price, changes in ask_changes.items():
            if len(changes) >= 3:  # Pelo menos 3 aumentos
                iceberg_asks[price] = sum(changes)
        
        # Determinar o iceberg mais significativo
        max_bid_iceberg = max(iceberg_bids.values()) if iceberg_bids else 0
        max_ask_iceberg = max(iceberg_asks.values()) if iceberg_asks else 0
        
        if max_bid_iceberg > 0 and max_bid_iceberg > max_ask_iceberg:
            max_bid_price = [price for price, size in iceberg_bids.items() if size == max_bid_iceberg][0]
            result = {
                'significativo': True,
                'nivel': float(max_bid_price),
                'tamanho': float(max_bid_iceberg),
                'direcao': 1  # Iceberg de compra
            }
        elif max_ask_iceberg > 0:
            max_ask_price = [price for price, size in iceberg_asks.items() if size == max_ask_iceberg][0]
            result = {
                'significativo': True,
                'nivel': float(max_ask_price),
                'tamanho': float(max_ask_iceberg),
                'direcao': -1  # Iceberg de venda
            }
        
        # Verificar se o iceberg é realmente significativo
        if result['significativo']:
            # Comparar com o volume médio do livro
            avg_volume = np.mean([sum(bids.values()), sum(asks.values())])
            significance = result['tamanho'] / avg_volume if avg_volume > 0 else 0
            
            result['significativo'] = significance > self.iceberg_threshold
        
        return result

    def detect_absorption(self, bids: Dict[float, float], asks: Dict[float, float], historical_states: deque) -> Dict[str, Any]:
        """
        Detecta absorção de ordens (grandes ordens sendo consumidas rapidamente).
        """
        result = {'significativo': False, 'nivel': 0.0, 'tamanho': 0.0, 'direcao': 0}
        
        if len(historical_states) < 5:
            return result
        
        # Obter estados recentes
        recent_states = list(historical_states)[-5:]
        
        # Analisar desaparecimento rápido de grandes ordens
        bid_disappearances = {}
        ask_disappearances = {}
        
        for i in range(1, len(recent_states)):
            prev_state = recent_states[i-1]
            curr_state = recent_states[i]
            
            # Analisar bids
            for price, qty in prev_state.bids.items():
                curr_qty = curr_state.bids.get(price, 0)
                if curr_qty < qty:
                    # Diminuição de quantidade
                    if price not in bid_disappearances:
                        bid_disappearances[price] = 0
                    bid_disappearances[price] += (qty - curr_qty)
            
            # Analisar asks
            for price, qty in prev_state.asks.items():
                curr_qty = curr_state.asks.get(price, 0)
                if curr_qty < qty:
                    # Diminuição de quantidade
                    if price not in ask_disappearances:
                        ask_disappearances[price] = 0
                    ask_disappearances[price] += (qty - curr_qty)
        
        # Determinar a absorção mais significativa
        max_bid_absorption = max(bid_disappearances.values()) if bid_disappearances else 0
        max_ask_absorption = max(ask_disappearances.values()) if ask_disappearances else 0
        
        if max_bid_absorption > 0 and max_bid_absorption > max_ask_absorption:
            max_bid_price = [price for price, size in bid_disappearances.items() if size == max_bid_absorption][0]
            result = {
                'significativo': True,
                'nivel': float(max_bid_price),
                'tamanho': float(max_bid_absorption),
                'direcao': -1  # Absorção de compra (pressão de venda)
            }
        elif max_ask_absorption > 0:
            max_ask_price = [price for price, size in ask_disappearances.items() if size == max_ask_absorption][0]
            result = {
                'significativo': True,
                'nivel': float(max_ask_price),
                'tamanho': float(max_ask_absorption),
                'direcao': 1  # Absorção de venda (pressão de compra)
            }
        
        # Verificar se a absorção é realmente significativa
        if result['significativo']:
            # Comparar com o volume médio do livro
            avg_volume = np.mean([sum(bids.values()), sum(asks.values())])
            significance = result['tamanho'] / avg_volume if avg_volume > 0 else 0
            
            result['significativo'] = significance > self.absorption_threshold
        
        return result

    def detect_spoofing(self, bids: Dict[float, float], asks: Dict[float, float], historical_states: deque) -> Dict[str, Any]:
        """
        Detecta spoofing (grandes ordens que aparecem e desaparecem rapidamente).
        """
        result = {'significativo': False, 'nivel': 0.0, 'tamanho': 0.0, 'direcao': 0}
        
        if len(historical_states) < 10:
            return result
        
        # Obter estados recentes
        recent_states = list(historical_states)[-10:]
        
        # Analisar aparecimento e desaparecimento rápido de grandes ordens
        bid_spoofing = {}
        ask_spoofing = {}
        
        for i in range(2, len(recent_states)):
            prev_prev_state = recent_states[i-2]
            prev_state = recent_states[i-1]
            curr_state = recent_states[i]
            
            # Analisar bids
            for price, qty in prev_state.bids.items():
                prev_prev_qty = prev_prev_state.bids.get(price, 0)
                curr_qty = curr_state.bids.get(price, 0)
                
                # Ordem que apareceu e depois desapareceu rapidamente
                if prev_prev_qty < qty and curr_qty < qty:
                    if price not in bid_spoofing:
                        bid_spoofing[price] = 0
                    bid_spoofing[price] = max(bid_spoofing[price], qty)
            
            # Analisar asks
            for price, qty in prev_state.asks.items():
                prev_prev_qty = prev_prev_state.asks.get(price, 0)
                curr_qty = curr_state.asks.get(price, 0)
                
                # Ordem que apareceu e depois desapareceu rapidamente
                if prev_prev_qty < qty and curr_qty < qty:
                    if price not in ask_spoofing:
                        ask_spoofing[price] = 0
                    ask_spoofing[price] = max(ask_spoofing[price], qty)
        
        # Determinar o spoofing mais significativo
        max_bid_spoofing = max(bid_spoofing.values()) if bid_spoofing else 0
        max_ask_spoofing = max(ask_spoofing.values()) if ask_spoofing else 0
        
        if max_bid_spoofing > 0 and max_bid_spoofing > max_ask_spoofing:
            max_bid_price = [price for price, size in bid_spoofing.items() if size == max_bid_spoofing][0]
            result = {
                'significativo': True,
                'nivel': float(max_bid_price),
                'tamanho': float(max_bid_spoofing),
                'direcao': 1  # Spoofing de compra (falsa pressão de compra)
            }
        elif max_ask_spoofing > 0:
            max_ask_price = [price for price, size in ask_spoofing.items() if size == max_ask_spoofing][0]
            result = {
                'significativo': True,
                'nivel': float(max_ask_price),
                'tamanho': float(max_ask_spoofing),
                'direcao': -1  # Spoofing de venda (falsa pressão de venda)
            }
        
        # Verificar se o spoofing é realmente significativo
        if result['significativo']:
            # Comparar com o volume médio do livro
            avg_volume = np.mean([sum(bids.values()), sum(asks.values())])
            significance = result['tamanho'] / avg_volume if avg_volume > 0 else 0
            
            result['significativo'] = significance > self.spoofing_threshold
        
        return result

    def detect_patterns(self, state: BookState) -> Dict[str, Any]:
        """
        Detecta todos os padrões institucionais no estado atual do livro.
        """
        # Adicionar estad
(Content truncated due to size limit. Use line ranges to read in chunks)