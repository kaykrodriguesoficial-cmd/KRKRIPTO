# src/core/data_handler.py

import pandas as pd
import os
import logging
import traceback # Import traceback for detailed error logging

logger = logging.getLogger("kr_kripto_data")

DEFAULT_DATA_DIR = "data"

def carregar_dados_historicos(ativo: str, timeframe: str = '1m', data_dir: str = DEFAULT_DATA_DIR):
    """Carrega dados históricos de um arquivo CSV, garantindo colunas OHLC capitalizadas.

    Args:
        ativo: O símbolo do ativo (ex: BTCUSDT).
        timeframe: O timeframe dos dados (ex: 1m).
        data_dir: O diretório onde os arquivos de dados estão localizados.

    Returns:
        Um DataFrame do pandas com os dados históricos (com colunas OHLC capitalizadas)
        ou None se o arquivo não for encontrado ou ocorrer um erro crítico.
    """
    file_path = os.path.join(data_dir, f"{ativo}_{timeframe}.csv")
    logger.info(f"[{ativo}] Attempting to load historical data from: {file_path}")

    if not os.path.exists(file_path):
        logger.warning(f"[{ativo}] Historical data file not found: {file_path}")
        alt_file_path = os.path.join(data_dir, f"{ativo}.csv")
        if os.path.exists(alt_file_path):
            logger.info(f"[{ativo}] Found alternative file: {alt_file_path}")
            file_path = alt_file_path
        else:
            sim_file_path = os.path.join(os.path.dirname(__file__), "..", "tests", "e2e", "data", "e2e_volatile_data_synthetic.csv")
            if os.path.exists(sim_file_path):
                 logger.warning(f"[{ativo}] Specific historical data not found. Loading default simulation data: {sim_file_path}")
                 file_path = sim_file_path
            else:
                logger.error(f"[{ativo}] No historical or simulation data file found at expected paths: {file_path}, {alt_file_path}, {sim_file_path}")
                return None

    try:
        df = pd.read_csv(file_path)

        rename_map = {
            'timestamp': 'Timestamp',
            'open': 'Open',
            'high': 'High',
            'low': 'Low',
            'close': 'Close',
            'volume': 'Volume'
        }
        actual_rename_map = {}
        if not df.empty or (df.empty and df.columns.size > 0):
            current_columns = list(df.columns) # Salva as colunas antes da tentativa de renomeação
            for lower_col, proper_col in rename_map.items():
                for df_col in current_columns: # Itera sobre as colunas originais
                    if df_col.lower() == lower_col:
                        actual_rename_map[df_col] = proper_col
                        break
            if actual_rename_map:
                df.rename(columns=actual_rename_map, inplace=True)
                logger.info(f"[{ativo}] Renamed columns: {actual_rename_map} to {list(df.columns)}")
            else:
                logger.warning(f"[{ativo}] No standard columns found for renaming based on map: {list(df.columns)}")
        
        if df.empty and df.columns.size > 0:
            logger.warning(f"[{ativo}] CSV file {file_path} contains only headers. Returning empty DataFrame.")
            if 'Timestamp' in df.columns:
                try:
                    df['Timestamp'] = pd.to_datetime(df['Timestamp'])
                    df.set_index('Timestamp', inplace=True)
                    if df.index.tz is None:
                         df = df.tz_localize('UTC')
                except Exception as e_idx:
                    logger.warning(f"[{ativo}] Could not set DatetimeIndex on empty DataFrame with headers: {e_idx}")
            return df

        # Depuração explícita para colunas faltantes
        required_ohlc_cols = ['Open', 'High', 'Low', 'Close']
        logger.info(f"DEBUG [{ativo}]: df.columns before checking missing: {list(df.columns)}")
        
        actual_df_cols = list(df.columns)
        missing_cols_found = []
        for req_col in required_ohlc_cols:
            if req_col not in actual_df_cols:
                missing_cols_found.append(req_col)
        
        logger.info(f"DEBUG [{ativo}]: Required OHLC: {required_ohlc_cols}")
        logger.info(f"DEBUG [{ativo}]: Actual DF cols after rename: {actual_df_cols}")
        logger.info(f"DEBUG [{ativo}]: Missing OHLC found: {missing_cols_found}")

        if missing_cols_found:
            logger.error(f"[{ativo}] Missing required OHLC columns: {missing_cols_found}. Cannot proceed.")
            return None

        if 'Timestamp' in df.columns:
            try:
                if df['Timestamp'].dtype == 'object': 
                    try:
                        df['Timestamp'] = pd.to_numeric(df['Timestamp'])
                    except ValueError:
                        logger.warning(f"[{ativo}] Non-numeric values found in Timestamp column during initial to_numeric conversion. Will attempt direct to_datetime conversion which handles coercion.")
                        # A conversão para numérico falhou, provavelmente porque a coluna já é uma string de data/hora
                        # ou contém valores não numéricos que não são timestamps.
                        # O bloco pd.to_datetime abaixo tentará a conversão direta.
                
                if pd.api.types.is_numeric_dtype(df['Timestamp']):
                     df['Timestamp'] = pd.to_datetime(df['Timestamp'], unit='ms', errors='coerce')
                else:
                     # Se não for numérico após a tentativa de conversão (ou se a conversão numérica foi pulada/falhou),
                     # tenta converter diretamente para datetime.
                     df['Timestamp'] = pd.to_datetime(df['Timestamp'], errors='coerce')
                
                if df['Timestamp'].isnull().any():
                    logger.error(f"[{ativo}] Invalid Timestamp values found after conversion (contains NaT). Check data format.")
                    return None 
                
                df.set_index('Timestamp', inplace=True)
                if df.index.tz is None:
                    df = df.tz_localize('UTC')
                logger.info(f"[{ativo}] Set 'Timestamp' as DatetimeIndex.")
            except Exception as ts_err:
                 logger.error(f"[{ativo}] Error converting 'Timestamp' column: {ts_err}. Check data format.")
                 return None 
        elif isinstance(df.index, pd.DatetimeIndex):
            logger.info(f"[{ativo}] Using existing DatetimeIndex.")
            if df.index.tz is None:
                df = df.tz_localize('UTC')
        else: 
            logger.error(f"[{ativo}] No 'Timestamp' column found and index is not DatetimeIndex. Cannot proceed.")
            return None

        logger.info(f"[{ativo}] Successfully loaded and processed data from {file_path}. Shape: {df.shape}")
        return df

    except pd.errors.EmptyDataError:
        logger.warning(f"[{ativo}] CSV file {file_path} is completely empty (EmptyDataError). Returning empty DataFrame.")
        return pd.DataFrame() 
    except FileNotFoundError:
        logger.error(f"[{ativo}] FileNotFoundError should have been caught by os.path.exists: {file_path}")
        return None
    except Exception as e:
        logger.error(f"[{ativo}] General error reading or processing data file {file_path}: {e}")
        logger.error(traceback.format_exc())
        return None

