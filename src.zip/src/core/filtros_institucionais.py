#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
filtros_institucionais.py

Módulo para validação de filtros institucionais no sistema KR_KRIPTO_ADVANCED.
Versão corrigida para compatibilidade com Python 3.9.
"""

import pandas as pd
import numpy as np
import logging
from typing import Dict, List, Optional, Tuple, Union, Any

logger = logging.getLogger("kr_kripto_filtros")

# Constantes para filtros institucionais
VOLUME_THRESHOLD = 1.5  # Multiplicador para volume médio
REJEICAO_MIN_PIPS = 10  # Mínimo de pips para considerar rejeição
FAKEOUT_MIN_PIPS = 5    # Mínimo de pips para considerar fakeout

# Pesos padrão para os diferentes tipos de filtros
DEFAULT_PESOS = {
    "rejeicao": 1.0,
    "volume": 1.0,
    "fakeout": 1.0
}

def detectar_rejeicao(df: pd.DataFrame, ativo: str) -> bool:
    """
    Detecta padrões de rejeição institucional no dataframe.
    
    Args:
        df: DataFrame com dados OHLCV
        ativo: Símbolo do ativo analisado
        
    Returns:
        bool: True se detectou rejeição, False caso contrário
    """
    if df.empty or len(df) < 3:
        logger.warning(f"Dados insuficientes para detectar rejeição em {ativo}")
        return False
    
    try:
        # Lógica de detecção de rejeição
        high_max = df['high'].max()
        close_last = df['close'].iloc[-1]
        open_last = df['open'].iloc[-1]
        
        # Verificar se houve rejeição significativa
        rejeicao_pips = abs(high_max - close_last) * 10000  # Convertendo para pips
        
        if rejeicao_pips > REJEICAO_MIN_PIPS and close_last < open_last:
            logger.info(f"Rejeição detectada em {ativo}: {rejeicao_pips:.2f} pips")
            return True
            
        return False
    except Exception as e:
        logger.error(f"Erro ao detectar rejeição em {ativo}: {str(e)}")
        return False

def detectar_volume_anormal(df: pd.DataFrame, ativo: str) -> bool:
    """
    Detecta volume anormalmente alto no dataframe.
    
    Args:
        df: DataFrame com dados OHLCV
        ativo: Símbolo do ativo analisado
        
    Returns:
        bool: True se detectou volume anormal, False caso contrário
    """
    if df.empty or len(df) < 5:
        logger.warning(f"Dados insuficientes para detectar volume anormal em {ativo}")
        return False
    
    try:
        # Calcular volume médio das últimas 5 barras excluindo a atual
        volume_medio = df['volume'].iloc[-6:-1].mean()
        volume_atual = df['volume'].iloc[-1]
        
        # Verificar se volume atual é significativamente maior que a média
        if volume_atual > volume_medio * VOLUME_THRESHOLD:
            logger.info(f"Volume anormal detectado em {ativo}: {volume_atual:.2f} vs média {volume_medio:.2f}")
            return True
            
        return False
    except Exception as e:
        logger.error(f"Erro ao detectar volume anormal em {ativo}: {str(e)}")
        return False

def detectar_fakeout(df: pd.DataFrame, ativo: str) -> bool:
    """
    Detecta padrões de fakeout institucional no dataframe.
    
    Args:
        df: DataFrame com dados OHLCV
        ativo: Símbolo do ativo analisado
        
    Returns:
        bool: True se detectou fakeout, False caso contrário
    """
    if df.empty or len(df) < 3:
        logger.warning(f"Dados insuficientes para detectar fakeout em {ativo}")
        return False
    
    try:
        # Lógica de detecção de fakeout
        high_anterior = df['high'].iloc[-2]
        low_anterior = df['low'].iloc[-2]
        high_atual = df['high'].iloc[-1]
        low_atual = df['low'].iloc[-1]
        close_atual = df['close'].iloc[-1]
        
        # Verificar se houve fakeout de alta
        fakeout_alta = high_atual > high_anterior and close_atual < low_anterior
        
        # Verificar se houve fakeout de baixa
        fakeout_baixa = low_atual < low_anterior and close_atual > high_anterior
        
        # Calcular tamanho do fakeout em pips
        fakeout_pips = 0
        if fakeout_alta:
            fakeout_pips = abs(high_atual - close_atual) * 10000
        elif fakeout_baixa:
            fakeout_pips = abs(close_atual - low_atual) * 10000
        
        if fakeout_pips > FAKEOUT_MIN_PIPS:
            logger.info(f"Fakeout detectado em {ativo}: {fakeout_pips:.2f} pips")
            return True
            
        return False
    except Exception as e:
        logger.error(f"Erro ao detectar fakeout em {ativo}: {str(e)}")
        return False

def validar_filtro_institucional(df: pd.DataFrame, ativo: str, pesos: Optional[Dict[str, float]] = None) -> Tuple[bool, str]:
    """
    Valida se o ativo passa pelos filtros institucionais.
    
    Args:
        df: DataFrame com dados OHLCV
        ativo: Símbolo do ativo analisado
        pesos: Dicionário com pesos para cada tipo de filtro (rejeicao, volume, fakeout)
        
    Returns:
        Tuple[bool, str]: (Passou no filtro, Mensagem de resultado)
    """
    if pesos is None:
        pesos = DEFAULT_PESOS
    
    try:
        # Detectar os diferentes padrões institucionais
        tem_rejeicao = detectar_rejeicao(df, ativo)
        tem_volume_anormal = detectar_volume_anormal(df, ativo)
        tem_fakeout = detectar_fakeout(df, ativo)
        
        # Calcular pontuação ponderada
        pontuacao = 0
        if tem_rejeicao:
            pontuacao += pesos.get("rejeicao", DEFAULT_PESOS["rejeicao"])
        if tem_volume_anormal:
            pontuacao += pesos.get("volume", DEFAULT_PESOS["volume"])
        if tem_fakeout:
            pontuacao += pesos.get("fakeout", DEFAULT_PESOS["fakeout"])
        
        # Determinar resultado com base na pontuação
        passou_filtro = pontuacao >= 2.0
        
        # Gerar mensagem de resultado
        componentes = []
        if tem_rejeicao:
            componentes.append("rejeição")
        if tem_volume_anormal:
            componentes.append("volume anormal")
        if tem_fakeout:
            componentes.append("fakeout")
            
        if componentes:
            mensagem = f"Filtro institucional para {ativo}: {', '.join(componentes)}. Pontuação: {pontuacao:.1f}"
        else:
            mensagem = f"Nenhum padrão institucional detectado em {ativo}. Pontuação: {pontuacao:.1f}"
        
        logger.info(mensagem)
        return passou_filtro, mensagem
        
    except Exception as e:
        logger.error(f"Erro ao validar filtro institucional para {ativo}: {str(e)}")
        return False, f"Erro ao validar filtro institucional: {str(e)}"

# Funções auxiliares para análise institucional

def calcular_niveis_institucionais(df: pd.DataFrame, janela: int = 20) -> List[float]:
    """
    Calcula níveis de interesse institucional com base no histórico de preços.
    
    Args:
        df: DataFrame com dados OHLCV
        janela: Tamanho da janela para análise
        
    Returns:
        List[float]: Lista de níveis de interesse institucional
    """
    if df.empty or len(df) < janela:
        return []
    
    try:
        # Identificar níveis de suporte e resistência
        niveis = []
        
        # Usar máximos e mínimos locais
        for i in range(janela, len(df) - janela):
            # Verificar se é um máximo local
            if df['high'].iloc[i] == df['high'].iloc[i-janela:i+janela+1].max():
                niveis.append(df['high'].iloc[i])
            
            # Verificar se é um mínimo local
            if df['low'].iloc[i] == df['low'].iloc[i-janela:i+janela+1].min():
                niveis.append(df['low'].iloc[i])
        
        # Agrupar níveis próximos
        if niveis:
            niveis = np.array(niveis)
            niveis.sort()
            
            # Agrupar níveis que estão a menos de 0.1% de distância
            agrupados = [niveis[0]]
            for nivel in niveis[1:]:
                if (nivel - agrupados[-1]) / agrupados[-1] > 0.001:
                    agrupados.append(nivel)
            
            return agrupados
        
        return []
    except Exception as e:
        logger.error(f"Erro ao calcular níveis institucionais: {str(e)}")
        return []

def analisar_acumulacao_distribuicao(df: pd.DataFrame) -> Dict[str, Any]:
    """
    Analisa padrões de acumulação e distribuição institucional.
    
    Args:
        df: DataFrame com dados OHLCV
        
    Returns:
        Dict[str, Any]: Resultados da análise
    """
    if df.empty or len(df) < 10:
        return {"tipo": "indeterminado", "confianca": 0, "detalhes": "Dados insuficientes"}
    
    try:
        # Calcular indicador de acumulação/distribuição
        df = df.copy()
        df['mf_multiplier'] = ((df['close'] - df['low']) - (df['high'] - df['close'])) / (df['high'] - df['low'])
        df['mf_multiplier'].replace([np.inf, -np.inf], 0, inplace=True)
        df['mf_volume'] = df['mf_multiplier'] * df['volume']
        df['ad_line'] = df['mf_volume'].cumsum()
        
        # Analisar tendência recente
        ad_trend = df['ad_line'].iloc[-5:].diff().mean()
        price_trend = df['close'].iloc[-5:].diff().mean()
        
        # Detectar divergências
        divergencia = (ad_trend > 0 and price_trend < 0) or (ad_trend < 0 and price_trend > 0)
        
        # Determinar tipo de padrão
        if ad_trend > 0 and price_trend <= 0:
            tipo = "acumulacao"
            confianca = min(abs(ad_trend) / df['ad_line'].std() * 100, 100)
        elif ad_trend < 0 and price_trend >= 0:
            tipo = "distribuicao"
            confianca = min(abs(ad_trend) / df['ad_line'].std() * 100, 100)
        elif ad_trend > 0 and price_trend > 0:
            tipo = "confirmacao_alta"
            confianca = min(abs(ad_trend) / df['ad_line'].std() * 50, 100)
        elif ad_trend < 0 and price_trend < 0:
            tipo = "confirmacao_baixa"
            confianca = min(abs(ad_trend) / df['ad_line'].std() * 50, 100)
        else:
            tipo = "indeterminado"
            confianca = 0
        
        return {
            "tipo": tipo,
            "confianca": round(confianca, 1),
            "divergencia": divergencia,
            "ad_trend": ad_trend,
            "price_trend": price_trend
        }
    except Exception as e:
        logger.error(f"Erro ao analisar acumulação/distribuição: {str(e)}")
        return {"tipo": "erro", "confianca": 0, "detalhes": str(e)}
