#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Módulo MemoriaTemporal para o projeto KR_KRIPTO_ADVANCED.
Implementação compatível com Mac M1 (ARM64) e ambientes Linux.

Este módulo fornece funcionalidades para armazenamento e análise
de eventos temporais, permitindo identificação de padrões e
ajuste de estratégias com base em comportamentos históricos.
"""

import os
import pandas as pd
import logging
from datetime import datetime
from typing import Dict, Any, Optional, List, Union

# Configuração de logging
logger = logging.getLogger("kr_kripto_memoria_temporal")

class MemoriaTemporal:
    """
    Gerenciador de memória temporal para o sistema KR_KRIPTO_ADVANCED.
    
    Fornece funcionalidades para:
    - Armazenamento de eventos temporais
    - Análise de padrões temporais
    - Persistência de dados históricos
    - Ajuste de estratégias com base em comportamentos passados
    """
    
    def __init__(self, config=None):
        """
        Inicializa a MemoriaTemporal.
        
        Args:
            config: Configuração opcional com parâmetros para o gerenciador
        """
        self.config = config or {}
        
        # Configurações de caminhos
        self.diretorio_base = self.config.get("diretorio_base", "data")
        self.caminho_memoria = os.path.join(self.diretorio_base, self.config.get("arquivo_memoria", "memoria_tatica.csv"))
        self.caminho_log = os.path.join(self.diretorio_base, "logs", self.config.get("arquivo_log", "memoria_tatica.log"))
        
        # Criar diretórios se não existirem
        os.makedirs(os.path.dirname(self.caminho_log), exist_ok=True)
        os.makedirs(os.path.dirname(self.caminho_memoria), exist_ok=True)
        
        # Inicializar memória
        self._inicializar_memoria()
        
        logger.info("MemoriaTemporal inicializada com sucesso")
    
    def _inicializar_memoria(self) -> None:
        """
        Inicializa o arquivo de memória se não existir.
        """
        if not os.path.exists(self.caminho_memoria):
            colunas = ["ativo", "hora", "score_medio", "acertos", "erros", "taxa_acerto", "timestamp"]
            pd.DataFrame(columns=colunas).to_csv(self.caminho_memoria, index=False)
            logger.info(f"Arquivo de memória criado em {self.caminho_memoria}")
    
    def resetar_memoria(self, ativo: Optional[str] = None) -> bool:
        """
        Reseta a memória tática para um ativo específico ou globalmente.
        
        Args:
            ativo: Nome do ativo para resetar. Se None, reseta toda a memória.
            
        Returns:
            True se a operação foi bem-sucedida, False caso contrário
        """
        try:
            self._inicializar_memoria()
            df = pd.read_csv(self.caminho_memoria)
            
            if ativo:
                df = df[df["ativo"] != ativo]
                self._registrar_log(ativo, "Memória tática resetada para esse ativo")
            else:
                df = df[0:0]  # Esvaziar o DataFrame
                self._registrar_log("GLOBAL", "Memória tática global resetada")
            
            df.to_csv(self.caminho_memoria, index=False)
            return True
        except Exception as e:
            logger.error(f"Erro ao resetar memória: {e}")
            return False
    
    def atualizar_memoria(self, ativo: str, hora: str, score: float, acertou: bool) -> bool:
        """
        Atualiza a memória tática com um novo evento.
        
        Args:
            ativo: Nome do ativo
            hora: Hora do evento (formato string)
            score: Pontuação do evento
            acertou: Se a previsão foi correta
            
        Returns:
            True se a operação foi bem-sucedida, False caso contrário
        """
        try:
            self._inicializar_memoria()
            df = pd.read_csv(self.caminho_memoria)
            cond = (df['ativo'] == ativo) & (df['hora'] == hora)
            
            timestamp = datetime.now()
            
            if not any(cond):
                # Criar nova entrada
                nova_linha = pd.DataFrame([{
                    "ativo": ativo,
                    "hora": hora,
                    "score_medio": score,
                    "acertos": int(acertou),
                    "erros": int(not acertou),
                    "taxa_acerto": int(acertou),
                    "timestamp": timestamp.isoformat()
                }])
                df = pd.concat([df, nova_linha], ignore_index=True)
            else:
                # Atualizar entrada existente
                i = df[cond].index[0]
                acertos = df.at[i, 'acertos'] + int(acertou)
                erros = df.at[i, 'erros'] + int(not acertou)
                total = acertos + erros
                df.at[i, 'acertos'] = acertos
                df.at[i, 'erros'] = erros
                df.at[i, 'score_medio'] = (df.at[i, 'score_medio'] + score) / 2
                df.at[i, 'taxa_acerto'] = acertos / total if total > 0 else 0.0
                df.at[i, 'timestamp'] = timestamp.isoformat()
            
            # Salvar DataFrame atualizado
            df.to_csv(self.caminho_memoria, index=False)
            
            # Registrar no log
            self._registrar_log(
                ativo, 
                f"Memória tática atualizada | Hora={hora} | Score={score:.2f} | Acerto={acertou}"
            )
            
            return True
        except Exception as e:
            logger.error(f"Erro em atualizar_memoria: {e}")
            return False
    
    def ajustar_por_memoria(self, ativo: str, hora: str, score: float) -> float:
        """
        Ajusta um score com base no histórico da memória tática.
        
        Args:
            ativo: Nome do ativo
            hora: Hora do evento
            score: Score original
            
        Returns:
            Score ajustado com base no histórico
        """
        try:
            self._inicializar_memoria()
            df = pd.read_csv(self.caminho_memoria)
            cond = (df['ativo'] == ativo) & (df['hora'] == hora)
            
            if any(cond):
                linha = df[cond].iloc[0]
                
                # Ajustar score com base na taxa de acerto histórica
                if linha['taxa_acerto'] < 0.3 and linha['score_medio'] < score:
                    # Penalizar score para horas com baixa taxa de acerto
                    score_ajustado = score - 5
                    self._registrar_log(
                        ativo, 
                        f"Score penalizado por baixa performance tática ({linha['taxa_acerto']:.2f})"
                    )
                    return score_ajustado
                elif linha['taxa_acerto'] > 0.7:
                    # Bonificar score para horas com alta taxa de acerto
                    score_ajustado = score + 3
                    self._registrar_log(
                        ativo, 
                        f"Score bonificado por hora forte ({linha['taxa_acerto']:.2f})"
                    )
                    return score_ajustado
            
            # Se não houver ajuste, retornar o score original
            return score
        except Exception as e:
            logger.error(f"Erro em ajustar_por_memoria: {e}")
            return score  # Em caso de erro, retornar o score original
    
    def obter_memoria(self, ativo: Optional[str] = None) -> pd.DataFrame:
        """
        Obtém os dados da memória tática.
        
        Args:
            ativo: Nome do ativo para filtrar. Se None, retorna todos os dados.
            
        Returns:
            DataFrame com os dados da memória
        """
        try:
            self._inicializar_memoria()
            df = pd.read_csv(self.caminho_memoria)
            
            if ativo:
                return df[df['ativo'] == ativo]
            return df
        except Exception as e:
            logger.error(f"Erro ao obter memória: {e}")
            return pd.DataFrame()  # Retornar DataFrame vazio em caso de erro
    
    def obter_estatisticas(self, ativo: Optional[str] = None) -> Dict[str, Any]:
        """
        Obtém estatísticas da memória tática.
        
        Args:
            ativo: Nome do ativo para filtrar. Se None, calcula para todos os ativos.
            
        Returns:
            Dicionário com estatísticas
        """
        try:
            df = self.obter_memoria(ativo)
            
            if df.empty:
                return {
                    "total_registros": 0,
                    "taxa_acerto_media": 0.0,
                    "score_medio": 0.0
                }
            
            return {
                "total_registros": len(df),
                "taxa_acerto_media": df['taxa_acerto'].mean(),
                "score_medio": df['score_medio'].mean(),
                "total_acertos": df['acertos'].sum(),
                "total_erros": df['erros'].sum(),
                "horas_mais_acertos": df.sort_values('taxa_acerto', ascending=False).head(3)[['hora', 'taxa_acerto']].to_dict('records'),
                "horas_mais_erros": df.sort_values('taxa_acerto').head(3)[['hora', 'taxa_acerto']].to_dict('records')
            }
        except Exception as e:
            logger.error(f"Erro ao obter estatísticas: {e}")
            return {"erro": str(e)}
    
    def registrar_evento(self, tipo=None, tipo_evento=None, dados=None, ativo=None, **kwargs) -> bool:
        """
        Registra um evento na memória temporal para análise posterior.
        
        Args:
            tipo: Tipo do evento (compatibilidade com chamadas antigas)
            tipo_evento: Tipo do evento (ex: 'sinal', 'ordem', 'alerta')
            dados: Dicionário com dados do evento
            ativo: Nome do ativo relacionado ao evento (opcional)
            **kwargs: Argumentos adicionais para flexibilidade de interface
            
        Returns:
            True se o evento foi registrado com sucesso, False caso contrário
        """
        try:
            # Normalizar argumentos para compatibilidade com diferentes chamadas
            evento_tipo = tipo or tipo_evento or kwargs.get('event_type', 'desconhecido')
            evento_dados = dados or kwargs.get('data', kwargs)
            evento_ativo = ativo or kwargs.get('symbol', kwargs.get('ativo', 'SISTEMA'))
            
            # Registrar o evento no log
            mensagem = f"Evento {evento_tipo}: {evento_dados}"
            self._registrar_log(evento_ativo, mensagem)
            
            # Aqui poderia ser implementada lógica adicional para armazenar
            # o evento em uma estrutura de dados específica para análise posterior
            
            logger.info(f"Evento {evento_tipo} registrado com sucesso para {evento_ativo}")
            return True
        except Exception as e:
            logger.error(f"Erro ao registrar evento: {e}")
            return False
    
    def _registrar_log(self, ativo: str, mensagem: str, nivel: str = "INFO") -> None:
        """
        Registra uma mensagem no log da memória tática.
        
        Args:
            ativo: Nome do ativo
            mensagem: Mensagem a ser registrada
            nivel: Nível do log (INFO, WARNING, ERROR)
        """
        try:
            timestamp = datetime.now().isoformat()
            
            # Registrar no arquivo de log
            with open(self.caminho_log, "a") as f:
                f.write(f"{timestamp},{nivel},{ativo},{mensagem}\n")
            
            # Registrar também no logger do sistema
            if nivel == "ERROR":
                logger.error(f"[{ativo}] {mensagem}")
            elif nivel == "WARNING":
                logger.warning(f"[{ativo}] {mensagem}")
            else:
                logger.info(f"[{ativo}] {mensagem}")
        except Exception as e:
            logger.error(f"Erro ao registrar log: {e}")
    
    def exportar_memoria(self, formato: str = "csv", caminho: Optional[str] = None) -> str:
        """
        Exporta os dados da memória tática para um arquivo.
        
        Args:
            formato: Formato de exportação ('csv' ou 'json')
            caminho: Caminho para salvar o arquivo. Se None, usa um caminho padrão.
            
        Returns:
            Caminho do arquivo exportado
        """
        try:
            df = self.obter_memoria()
            
            if caminho is None:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                caminho = os.path.join(self.diretorio_base, f"memoria_tatica_export_{timestamp}.{formato}")
            
            if formato.lower() == "json":
                df.to_json(caminho, orient="records")
            else:
                df.to_csv(caminho, index=False)
            
            logger.info(f"Memória exportada para {caminho}")
            return caminho
        except Exception as e:
            logger.error(f"Erro ao exportar memória: {e}")
            return ""
    
    def importar_memoria(self, caminho: str, substituir: bool = False) -> bool:
        """
        Importa dados para a memória tática a partir de um arquivo.
        
        Args:
            caminho: Caminho do arquivo a ser importado
            substituir: Se True, substitui os dados existentes. Se False, faz merge.
            
        Returns:
            True se a operação foi bem-sucedida, False caso contrário
        """
        try:
            if not os.path.exists(caminho):
                logger.error(f"Arquivo não encontrado: {caminho}")
                return False
            
            # Determinar formato com base na extensão
            formato = os.path.splitext(caminho)[1].lower()
            
            if formato == ".json":
                df_import = pd.read_json(caminho)
            elif formato == ".csv":
                df_import = pd.read_csv(caminho)
            else:
                logger.error(f"Formato não suportado: {formato}")
                return False
            
            # Verificar colunas necessárias
            colunas_necessarias = ["ativo", "hora", "score_medio", "acertos", "erros", "taxa_acerto"]
            if not all(col in df_import.columns for col in colunas_necessarias):
                logger.error(f"Arquivo não contém todas as colunas necessárias: {colunas_necessarias}")
                return False
            
            # Adicionar timestamp se não existir
            if "timestamp" not in df_import.columns:
                df_import["timestamp"] = datetime.now().isoformat()
            
            # Importar dados
            if substituir:
                df_import.to_csv(self.caminho_memoria, index=False)
                self._registrar_log("GLOBAL", f"Memória substituída por importação de {caminho}")
            else:
                df_atual = self.obter_memoria()
                df_merged = pd.concat([df_atual, df_import], ignore_index=True).drop_duplicates(subset=["ativo", "hora"])
                df_merged.to_csv(self.caminho_memoria, index=False)
                self._registrar_log("GLOBAL", f"Memória atualizada por importação de {caminho}")
            
            return True
        except Exception as e:
            logger.error(f"Erro ao importar memória: {e}")
            return False
