# src/core/network_resilience.py
"""
Módulo para aprimorar a resiliência de rede do sistema KR_KRIPTO_ADVANCED_COPIA.
Implementa estratégias avançadas de reconexão, backoff exponencial e detecção de falhas.
"""

import asyncio
import logging
from logging.handlers import TimedRotatingFileHandler
import time
import random
import os
import sys
from typing import Dict, Any, Callable, Coroutine, Optional, List, Tuple
import aiohttp
import socket
import traceback

# Configurar logging com rotação
log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'logs')
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, 'network_resilience.log')

# Configurar logger com rotação diária
logger = logging.getLogger("network_resilience")
if not logger.handlers:
    handler = TimedRotatingFileHandler(
        filename=log_file,
        when='midnight',
        interval=1,
        backupCount=30,
        encoding='utf-8'
    )
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    
    # Adicionar handler para console também
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    logger.setLevel(logging.INFO)
    logger.info("Logger configurado com rotação diária para network_resilience")

# Constantes para estratégia de reconexão
DEFAULT_MAX_RETRIES = 10
DEFAULT_BASE_DELAY = 2.0
DEFAULT_MAX_DELAY = 300.0  # 5 minutos
DEFAULT_JITTER = 0.1  # 10% de variação aleatória
DEFAULT_TIMEOUT = 30.0  # Timeout padrão para conexões

# Tipos de falhas de rede para classificação
class NetworkFailureType:
    """Enumeração de tipos de falhas de rede para classificação e tratamento específico."""
    UNKNOWN = "unknown"
    CONNECTION_REFUSED = "connection_refused"
    TIMEOUT = "timeout"
    DNS_FAILURE = "dns_failure"
    RESET = "connection_reset"
    SSL_ERROR = "ssl_error"
    PROXY_ERROR = "proxy_error"
    SERVER_ERROR = "server_error"
    CLIENT_ERROR = "client_error"
    RATE_LIMIT = "rate_limit"
    AUTHENTICATION = "authentication_error"

class NetworkStatus:
    """Classe para rastrear o status da rede e métricas de conexão."""
    
    def __init__(self):
        self.last_successful_connection = 0.0
        self.last_failure = 0.0
        self.failure_count = 0
        self.success_count = 0
        self.current_status = "unknown"
        self.failure_types = {}
        self.response_times = []
        self.max_response_times = 100  # Manter apenas as últimas N medições
    
    def record_success(self, response_time: float = None):
        """Registra uma conexão bem-sucedida."""
        self.last_successful_connection = time.time()
        self.success_count += 1
        self.current_status = "connected"
        
        if response_time is not None:
            self.response_times.append(response_time)
            if len(self.response_times) > self.max_response_times:
                self.response_times.pop(0)
    
    def record_failure(self, failure_type: str = NetworkFailureType.UNKNOWN):
        """Registra uma falha de conexão."""
        self.last_failure = time.time()
        self.failure_count += 1
        self.current_status = "disconnected"
        
        if failure_type not in self.failure_types:
            self.failure_types[failure_type] = 0
        self.failure_types[failure_type] += 1
    
    def get_average_response_time(self) -> float:
        """Retorna o tempo médio de resposta das últimas conexões."""
        if not self.response_times:
            return 0.0
        return sum(self.response_times) / len(self.response_times)
    
    def get_failure_rate(self) -> float:
        """Retorna a taxa de falha (falhas / total de tentativas)."""
        total = self.success_count + self.failure_count
        if total == 0:
            return 0.0
        return self.failure_count / total
    
    def get_most_common_failure(self) -> Tuple[str, int]:
        """Retorna o tipo de falha mais comum e sua contagem."""
        if not self.failure_types:
            return (NetworkFailureType.UNKNOWN, 0)
        
        most_common = max(self.failure_types.items(), key=lambda x: x[1])
        return most_common
    
    def reset_counters(self):
        """Reinicia os contadores de sucesso e falha."""
        self.failure_count = 0
        self.success_count = 0
        self.failure_types = {}
        self.response_times = []
    
    def get_status_report(self) -> Dict[str, Any]:
        """Retorna um relatório completo do status da rede."""
        now = time.time()
        
        return {
            "current_status": self.current_status,
            "success_count": self.success_count,
            "failure_count": self.failure_count,
            "failure_rate": self.get_failure_rate(),
            "time_since_last_success": now - self.last_successful_connection if self.last_successful_connection > 0 else None,
            "time_since_last_failure": now - self.last_failure if self.last_failure > 0 else None,
            "average_response_time": self.get_average_response_time(),
            "most_common_failure": self.get_most_common_failure(),
            "failure_types": self.failure_types
        }

class NetworkResilience:
    """
    Classe principal para gerenciar a resiliência de rede.
    Implementa estratégias de reconexão, backoff exponencial e detecção de falhas.
    """
    
    def __init__(self, 
                 max_retries: int = DEFAULT_MAX_RETRIES,
                 base_delay: float = DEFAULT_BASE_DELAY,
                 max_delay: float = DEFAULT_MAX_DELAY,
                 jitter: float = DEFAULT_JITTER,
                 timeout: float = DEFAULT_TIMEOUT):
        """
        Inicializa o gerenciador de resiliência de rede.
        
        Args:
            max_retries: Número máximo de tentativas de reconexão
            base_delay: Atraso base para backoff exponencial (segundos)
            max_delay: Atraso máximo entre tentativas (segundos)
            jitter: Fator de variação aleatória para evitar tempestade de reconexões
            timeout: Timeout padrão para conexões (segundos)
        """
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.jitter = jitter
        self.timeout = timeout
        
        self.network_status = NetworkStatus()
        self.active_connections = {}
        self.connection_attempts = {}
        
        logger.info(f"NetworkResilience inicializado com max_retries={max_retries}, "
                   f"base_delay={base_delay}s, max_delay={max_delay}s, jitter={jitter}, timeout={timeout}s")
    
    def classify_error(self, error: Exception) -> str:
        """
        Classifica o tipo de erro de rede para tratamento específico.
        
        Args:
            error: Exceção capturada durante a tentativa de conexão
            
        Returns:
            str: Tipo de falha classificado
        """
        error_str = str(error).lower()
        error_type = type(error).__name__
        
        if isinstance(error, aiohttp.ClientConnectorError):
            if "connection refused" in error_str:
                return NetworkFailureType.CONNECTION_REFUSED
            elif "dns" in error_str or "name resolution" in error_str:
                return NetworkFailureType.DNS_FAILURE
            
        if isinstance(error, asyncio.TimeoutError) or isinstance(error, aiohttp.ClientTimeout):
            return NetworkFailureType.TIMEOUT
            
        if isinstance(error, aiohttp.ClientOSError):
            if "reset by peer" in error_str:
                return NetworkFailureType.RESET
                
        if "ssl" in error_str or "certificate" in error_str:
            return NetworkFailureType.SSL_ERROR
            
        if "proxy" in error_str:
            return NetworkFailureType.PROXY_ERROR
            
        if isinstance(error, aiohttp.ClientResponseError):
            status = getattr(error, "status", 0)
            if 400 <= status < 500:
                if status == 429:
                    return NetworkFailureType.RATE_LIMIT
                elif status == 401 or status == 403:
                    return NetworkFailureType.AUTHENTICATION
                return NetworkFailureType.CLIENT_ERROR
            elif 500 <= status < 600:
                return NetworkFailureType.SERVER_ERROR
                
        return NetworkFailureType.UNKNOWN
    
    def calculate_delay(self, attempt: int) -> float:
        """
        Calcula o atraso para a próxima tentativa usando backoff exponencial com jitter.
        
        Args:
            attempt: Número da tentativa atual (começando em 1)
            
        Returns:
            float: Atraso em segundos para a próxima tentativa
        """
        # Backoff exponencial: base_delay * 2^(attempt-1)
        delay = min(self.base_delay * (2 ** (attempt - 1)), self.max_delay)
        
        # Adicionar jitter para evitar tempestade de reconexões
        jitter_amount = delay * self.jitter
        delay = delay + random.uniform(-jitter_amount, jitter_amount)
        
        return max(delay, 0.1)  # Garantir pelo menos 100ms de atraso
    
    def adjust_strategy_for_failure(self, failure_type: str) -> Dict[str, Any]:
        """
        Ajusta a estratégia de reconexão com base no tipo de falha.
        
        Args:
            failure_type: Tipo de falha classificado
            
        Returns:
            Dict[str, Any]: Parâmetros ajustados para a próxima tentativa
        """
        # Estratégias específicas para diferentes tipos de falha
        if failure_type == NetworkFailureType.RATE_LIMIT:
            # Para rate limit, aumentar significativamente o atraso
            return {
                "base_delay": self.base_delay * 5,
                "max_retries": self.max_retries,
                "timeout": self.timeout
            }
        elif failure_type == NetworkFailureType.TIMEOUT:
            # Para timeouts, aumentar o timeout gradualmente
            return {
                "base_delay": self.base_delay,
                "max_retries": self.max_retries,
                "timeout": min(self.timeout * 1.5, 120.0)  # Aumentar timeout, max 2 minutos
            }
        elif failure_type == NetworkFailureType.SERVER_ERROR:
            # Para erros de servidor, esperar mais tempo
            return {
                "base_delay": self.base_delay * 2,
                "max_retries": self.max_retries,
                "timeout": self.timeout
            }
        elif failure_type == NetworkFailureType.DNS_FAILURE:
            # Para falhas de DNS, esperar mais entre tentativas
            return {
                "base_delay": self.base_delay * 3,
                "max_retries": self.max_retries,
                "timeout": self.timeout
            }
        
        # Estratégia padrão para outros tipos de falha
        return {
            "base_delay": self.base_delay,
            "max_retries": self.max_retries,
            "timeout": self.timeout
        }
    
    async def execute_with_retry(self, 
                                 operation: Callable[[], Coroutine],
                                 operation_name: str = "unknown_operation",
                                 context: Dict[str, Any] = None) -> Any:
        """
        Executa uma operação com retry automático em caso de falha.
        
        Args:
            operation: Função assíncrona a ser executada
            operation_name: Nome da operação para logging
            context: Contexto adicional para logging e tratamento de erros
            
        Returns:
            Any: Resultado da operação se bem-sucedida
            
        Raises:
            Exception: Se todas as tentativas falharem
        """
        if context is None:
            context = {}
            
        attempt = 0
        last_error = None
        adjusted_params = {
            "base_delay": self.base_delay,
            "max_retries": self.max_retries,
            "timeout": self.timeout
        }
        
        while attempt < adjusted_params["max_retries"]:
            attempt += 1
            
            try:
                logger.info(f"[{operation_name}] Tentativa {attempt}/{adjusted_params['max_retries']}")
                start_time = time.time()
                
                # Executar a operação
                result = await operation()
                
                # Registrar sucesso
                elapsed = time.time() - start_time
                self.network_status.record_success(elapsed)
                logger.info(f"[{operation_name}] Operação bem-sucedida em {elapsed:.2f}s após {attempt} tentativa(s)")
                
                return result
                
            except Exception as e:
                # Registrar falha
                failure_type = self.classify_error(e)
                self.network_status.record_failure(failure_type)
                
                last_error = e
                elapsed = time.time() - start_time
                
                logger.warning(f"[{operation_name}] Falha na tentativa {attempt}: {str(e)} "
                              f"(tipo: {failure_type}, tempo: {elapsed:.2f}s)")
                
                # Ajustar estratégia com base no tipo de falha
                adjusted_params = self.adjust_strategy_for_failure(failure_type)
                
                # Verificar se atingimos o número máximo de tentativas
                if attempt >= adjusted_params["max_retries"]:
                    logger.error(f"[{operation_name}] Número máximo de tentativas ({adjusted_params['max_retries']}) "
                                f"excedido. Última falha: {str(e)}")
                    break
                
                # Calcular atraso para próxima tentativa
                delay = self.calculate_delay(attempt)
                
                logger.info(f"[{operation_name}] Aguardando {delay:.2f}s antes da próxima tentativa...")
                await asyncio.sleep(delay)
        
        # Se chegamos aqui, todas as tentativas falharam
        if last_error:
            logger.error(f"[{operation_name}] Todas as {attempt} tentativas falharam. "
                        f"Último erro: {str(last_error)}")
            raise last_error
        else:
            # Caso improvável, mas para segurança
            generic_error = Exception(f"Todas as {attempt} tentativas falharam sem erro específico")
            logger.error(f"[{operation_name}] {str(generic_error)}")
            raise generic_error
    
    async def create_resilient_session(self, session_name: str = "default") -> aiohttp.ClientSession:
        """
        Cria uma sessão HTTP resiliente com configurações otimizadas.
        
        Args:
            session_name: Nome da sessão para rastreamento
            
        Returns:
            aiohttp.ClientSession: Sessão HTTP configurada
        """
        # Configurar timeout
        timeout = aiohttp.ClientTimeout(
            total=self.timeout,
            connect=min(self.timeout / 3, 10),  # Timeout de conexão menor
            sock_connect=min(self.timeout / 3, 10),  # Timeout de socket menor
            sock_read=self.timeout  # Timeout de leitura igual ao total
        )
        
        # Configurar opções de TCP para melhor resiliência
        tcp_connector = aiohttp.TCPConnector(
            limit=100,  # Limite de conexões simultâneas
            ttl_dns_cache=300,  # Cache de DNS por 5 minutos
            enable_cleanup_closed=True,  # Limpar conexões fechadas
            force_close=False,  # Permitir keep-alive
            ssl=False  # Desabilitar SSL para WebSockets da Binance (eles usam wss://)
        )
        
        # Criar sessão
        session = aiohttp.ClientSession(
            timeout=timeout,
            connector=tcp_connector,
            headers={
                "User-Agent": "KR_KRIPTO_ADVANCED_COPIA/1.0",
                "Accept": "application/json"
            }
        )
        
        # Registrar sessão
        self.active_connections[session_name] = session
        logger.info(f"Sessão HTTP resiliente '{session_name}' criada com timeout={self.timeout}s")
        
        return session
    
    async def close_all_sessions(self):
        """Fecha todas as sessões HTTP ativas."""
        for name, session in list(self.active_connections.items()):
            try:
                await session.close()
                logger.info(f"Sessão HTTP '{name}' fechada com sucesso")
            except Exception as e:
                logger.error(f"Erro ao fechar sessão HTTP '{name}': {str(e)}")
        
        self.active_connections.clear()
    
    def get_network_status_report(self) -> Dict[str, Any]:
        """Retorna um relatório detalhado do status da rede."""
        return self.network_status.get_status_report()
    
    async def check_connectivity(self, url: str = "https://api.binance.com/api/v3/ping") -> bool:
        """
        Verifica a conectividade com um endpoint específico.
        
        Args:
            url: URL para verificar conectividade
            
        Returns:
            bool: True se conectividade OK, False caso contrário
        """
        try:
            # Criar uma sessão temporária para o teste
            async with aiohttp.ClientSession() as session:
                start_time = time.time()
                async with session.get(url, timeout=5) as response:
                    elapsed = time.time() - start_time
                    
                    if response.status < 400:
                        self.network_status.record_success(elapsed)
                        logger.info(f"Conectividade OK com {url} em {elapsed:.2f}s (status: {response.status})")
                        return True
                    else:
                        failure_type = (
                            NetworkFailureType.SERVER_ERROR if response.status >= 500 
                            else NetworkFailureType.CLIENT_ERROR
                        )
                        self.network_status.record_failure(failure_type)
                        logger.warning(f"Falha de conectividade com {url}: status {response.status}")
                        return False
                        
        except Exception as e:
            failure_type = self.classify_error(e)
            self.network_status.record_failure(failure_type)
            logger.error(f"Erro ao verificar conectividade com {url}: {str(e)} (tipo: {failure_type})")
            return False

# Exemplo de uso
async def exemplo_uso():
    # Criar gerenciador de resiliência
    resilience = NetworkResilience(
        max_retries=5,
        base_delay=1.0,
        max_delay=30.0,
        jitter=0.1,
        timeout=10.0
    )
    
    # Verificar conectividade
    is_connected = await resilience.check_connectivity()
    print(f"Conectividade: {'OK' if is_connected else 'Falha'}")
    
    # Exemplo de operação com retry
    async def fetch_data():
        # Simular falha aleatória
        if random.random() < 0.7:
            raise aiohttp.ClientConnectorError(
                connection_key=None,
                os_error=OSError("Connection refused")
            )
        return {"data": "exemplo"}
    
    try:
        result = await resilience.execute_with_retry(
            fetch_data,
            operation_name="fetch_example_data"
        )
        print(f"Resultado: {result}")
    except Exception as e:
        print(f"Falha final: {e}")
    
    # Obter relatório de status
    status_report = resilience.get_network_status_report()
    print(f"Relatório de status: {status_report}")
    
    # Fechar sessões
    await resilience.close_all_sessions()

if __name__ == "__main__":
    # Executar exemplo
    asyncio.run(exemplo_uso())
