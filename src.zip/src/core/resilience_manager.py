#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gerenciador de resiliência para operações de longa duração e propensas a falhas.

Este módulo fornece funcionalidades para:
1. Executar operações com timeout
2. Implementar circuit breaker para evitar tentativas repetidas de operações que estão falhando
3. Fornecer fallbacks para operações críticas

Versão: 1.0
Data: 2025-05-30
"""

import threading
import time
import logging
import functools
from typing import Any, Callable, Dict, Optional, TypeVar, cast
from datetime import datetime, timedelta

logger = logging.getLogger("kr_kripto_resilience")

# Configuração global de timeout
DEFAULT_TIMEOUT = 30  # segundos
_market_data_timeout = DEFAULT_TIMEOUT

# Estado do circuit breaker
_circuit_breakers: Dict[str, Dict[str, Any]] = {}

def set_market_data_timeout(seconds: int) -> None:
    """
    Define o timeout global para operações de dados de mercado.
    
    Args:
        seconds: Timeout em segundos
    """
    global _market_data_timeout
    _market_data_timeout = seconds
    logger.info(f"Timeout para dados de mercado definido como {seconds} segundos")

def get_market_data_timeout() -> int:
    """
    Obtém o timeout atual para operações de dados de mercado.
    
    Returns:
        Timeout em segundos
    """
    return _market_data_timeout

class TimeoutError(Exception):
    """Exceção lançada quando uma operação excede o timeout."""
    pass

class CircuitBreakerOpenError(Exception):
    """Exceção lançada quando o circuit breaker está aberto."""
    pass

T = TypeVar('T')

def with_timeout(timeout: Optional[int] = None) -> Callable:
    """
    Decorador para executar funções com timeout.
    
    Args:
        timeout: Timeout em segundos. Se None, usa o timeout global.
        
    Returns:
        Decorador configurado com o timeout especificado
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> T:
            actual_timeout = timeout if timeout is not None else _market_data_timeout
            result = [None]
            exception = [None]
            completed = [False]
            
            def target() -> None:
                try:
                    result[0] = func(*args, **kwargs)
                except Exception as e:
                    exception[0] = e
                finally:
                    completed[0] = True
            
            thread = threading.Thread(target=target)
            thread.daemon = True
            thread.start()
            
            thread.join(actual_timeout)
            
            if not completed[0]:
                error_msg = f"Operação excedeu o timeout de {actual_timeout} segundos"
                logger.error(error_msg)
                raise TimeoutError(error_msg)
            
            if exception[0]:
                raise exception[0]
            
            return cast(T, result[0])
        
        return wrapper
    
    return decorator

def with_circuit_breaker(operation_name: str, max_failures: int = 3, reset_timeout: int = 300) -> Callable:
    """
    Decorador para implementar circuit breaker em funções.
    
    Args:
        operation_name: Nome da operação para identificação no circuit breaker
        max_failures: Número máximo de falhas antes de abrir o circuit breaker
        reset_timeout: Tempo em segundos para resetar o circuit breaker
        
    Returns:
        Decorador configurado com o circuit breaker
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> T:
            # Inicializar estado do circuit breaker se não existir
            if operation_name not in _circuit_breakers:
                _circuit_breakers[operation_name] = {
                    'failures': 0,
                    'last_failure': None,
                    'state': 'closed'  # closed, open, half-open
                }
            
            cb = _circuit_breakers[operation_name]
            
            # Verificar se o circuit breaker está aberto
            if cb['state'] == 'open':
                # Verificar se é hora de resetar para half-open
                if cb['last_failure'] and datetime.now() - cb['last_failure'] > timedelta(seconds=reset_timeout):
                    logger.info(f"Circuit breaker para {operation_name} alterado para half-open após {reset_timeout} segundos")
                    cb['state'] = 'half-open'
                else:
                    logger.warning(f"Circuit breaker para {operation_name} está aberto. Operação bloqueada.")
                    raise CircuitBreakerOpenError(f"Circuit breaker para {operation_name} está aberto")
            
            try:
                result = func(*args, **kwargs)
                
                # Sucesso em half-open fecha o circuit breaker
                if cb['state'] == 'half-open':
                    logger.info(f"Circuit breaker para {operation_name} fechado após sucesso em half-open")
                    cb['state'] = 'closed'
                    cb['failures'] = 0
                
                return result
            
            except Exception as e:
                # Incrementar contador de falhas
                cb['failures'] += 1
                cb['last_failure'] = datetime.now()
                
                # Verificar se deve abrir o circuit breaker
                if cb['failures'] >= max_failures:
                    if cb['state'] != 'open':
                        logger.critical(f"Circuit breaker para {operation_name} aberto após {cb['failures']} falhas")
                        cb['state'] = 'open'
                
                logger.error(f"Falha em {operation_name} ({cb['failures']}): {e}")
                raise
        
        return wrapper
    
    return decorator

def get_circuit_breaker_status() -> Dict[str, Dict[str, Any]]:
    """
    Obtém o status atual de todos os circuit breakers.
    
    Returns:
        Dicionário com o status de cada circuit breaker
    """
    return {name: {
        'state': cb['state'],
        'failures': cb['failures'],
        'last_failure': cb['last_failure'].isoformat() if cb['last_failure'] else None
    } for name, cb in _circuit_breakers.items()}

def reset_circuit_breaker(operation_name: str) -> bool:
    """
    Reseta um circuit breaker específico para o estado fechado.
    
    Args:
        operation_name: Nome da operação do circuit breaker
        
    Returns:
        True se o reset foi bem-sucedido, False caso contrário
    """
    if operation_name in _circuit_breakers:
        _circuit_breakers[operation_name] = {
            'failures': 0,
            'last_failure': None,
            'state': 'closed'
        }
        logger.info(f"Circuit breaker para {operation_name} resetado")
        return True
    else:
        logger.warning(f"Circuit breaker para {operation_name} não encontrado")
        return False

def reset_all_circuit_breakers() -> None:
    """
    Reseta todos os circuit breakers para o estado fechado.
    """
    global _circuit_breakers
    _circuit_breakers = {}
    logger.info("Todos os circuit breakers foram resetados")

# Exemplo de uso:
# @with_circuit_breaker("obter_dados_mercado", max_failures=5, reset_timeout=60)
# @with_timeout(30)
# def obter_dados_mercado(operador, ativo, intervalo, limite=500):
#     """
#     Obtém dados de mercado com timeout e circuit breaker.
#     """
#     return operador.obter_klines(ativo, intervalo, limite)
