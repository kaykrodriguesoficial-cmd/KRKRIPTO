# src/core/utils.py

def calcular_porta_zmq(base_port: int, instance_id: int) -> int:
    """Calcula a porta ZMQ para uma instância específica (placeholder)."""
    # Implementação placeholder simples
    return base_port + instance_id

