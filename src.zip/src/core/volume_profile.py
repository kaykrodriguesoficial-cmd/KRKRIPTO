""" Volume Profile Validator """

