# src/dashboard/app.py

import asyncio
from flask import Flask, render_template, jsonify
import logging
import os
from threading import Thread
from typing import Optional # Adicionado Optional

# Import necessary components (adjust paths as needed)
# Assuming MemoriaTemporal and GerenciadorFallback are accessible
# We might need to pass instances or use a shared context
try:
    from src.infrastructure.memory import MemoriaTemporal
    from src.infrastructure.fallback import GerenciadorFallback
    INFRA_AVAILABLE = True
except ImportError:
    INFRA_AVAILABLE = False
    # Define stubs if not available
    class MemoriaTemporal:
        def __init__(self, config: dict): self.dados={}
        def obter(self, key): return self.dados.get(key)
        def obter_todos(self): return self.dados.copy()
    class GerenciadorFallback:
        def __init__(self, config: dict): self._status = {}
        def get_status(self): return self._status.copy()

logger = logging.getLogger("kr_kripto_dashboard")

# --- Flask App Setup ---
# Use absolute path for templates relative to this file's location
template_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'templates'))
app = Flask(__name__, template_folder=template_dir)

# --- Global State (Placeholder - Should be passed properly) ---
# These should ideally be passed during initialization or accessed via a shared context
memoria_temporal_global: Optional[MemoriaTemporal] = None # Alterado para Optional e None
fallback_manager_global: Optional[GerenciadorFallback] = None # Alterado para Optional e None

def set_dashboard_context(memoria: MemoriaTemporal, fallback: GerenciadorFallback):
    """Sets the global context for the dashboard app."""
    global memoria_temporal_global, fallback_manager_global
    memoria_temporal_global = memoria
    fallback_manager_global = fallback
    logger.info("Dashboard context updated.")

# --- Routes ---
@app.route('/')
def index():
    """Renders the main dashboard page."""
    return render_template('index.html', title='KR Kripto Dashboard')

@app.route('/api/status')
def api_status():
    """Provides live status data as JSON."""
    # Fetch data from shared state (MemoriaTemporal, FallbackManager)
    status_data = {
        "timestamp": asyncio.get_event_loop().time(), # Or use datetime.now()
        "ativos": [], # Placeholder - Need to get active assets
        "conexao_binance": "Desconhecido", # Placeholder
        "ultimo_sinal": memoria_temporal_global.obter("ultimo_sinal_processado") if memoria_temporal_global else None, # Example key
        "fallback_status": fallback_manager_global.get_status() if fallback_manager_global else {},
        "alertas_criticos": (memoria_temporal_global.obter("alertas_criticos") or []) if memoria_temporal_global else [], # Example key
        "spoofing_heatmap": {} # Placeholder
    }

    # Example: Get connection status from fallback manager if available
    # This depends on how fallback manager stores status
    if fallback_manager_global:
        fb_status = fallback_manager_global.get_status()
        ws_connected = True
        active_assets = set()
        for key, task_info in fb_status.items():
            if key.startswith("websocket_"):
                asset = key.split("_", 1)[1]
                active_assets.add(asset)
                if task_info.get("status") != "running":
                    ws_connected = False
        
        status_data["ativos"] = list(active_assets)
        status_data["conexao_binance"] = "Conectado" if ws_connected else "Desconectado"
    else:
        status_data["ativos"] = []
        status_data["conexao_binance"] = "Fallback Manager não inicializado"


    # TODO: Implement heatmap data retrieval
    # status_data["spoofing_heatmap"] = get_spoofing_data()

    return jsonify(status_data)

# --- Async Runner --- 
# Function to run Flask app in a separate thread
def run_flask_app(host='0.0.0.0', port=5000):
    """Runs the Flask app."""
    logger.info(f"Starting Flask dashboard server on http://{host}:{port}")
    try:
        # Use 'run_simple' for production-like environments or when debugging is off
        # from werkzeug.serving import run_simple
        # run_simple(host, port, app, use_reloader=False, use_debugger=False)
        app.run(host=host, port=port, debug=False) # debug=True enables auto-reloading
    except Exception as e:
        logger.critical(f"Failed to start Flask server: {e}", exc_info=True)

async def rodar_dashboard_async(memoria: MemoriaTemporal, fallback: GerenciadorFallback, host='0.0.0.0', port=5000):
    """Runs the Flask dashboard in a separate thread managed by asyncio."""
    set_dashboard_context(memoria, fallback) # Pass the shared state
    loop = asyncio.get_event_loop()
    # Run Flask app in a separate thread so it doesn't block the main asyncio loop
    flask_thread = Thread(target=run_flask_app, args=(host, port), daemon=True)
    flask_thread.start()
    logger.info("Flask dashboard thread started.")
    # Keep the async function alive (optional, depends on how main loop manages tasks)
    # while flask_thread.is_alive():
    #     await asyncio.sleep(1)

# Example for direct execution (for testing)
if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    # Create dummy context for testing
    # Note: GerenciadorFallback would need proper config and operador_binance for real init
    class DummyOperador:
        pass
    dummy_memoria = MemoriaTemporal(config={})
    # For testing, we might still use the stub if real GerenciadorFallback is complex to init here
    if INFRA_AVAILABLE:
         # This will still fail if GerenciadorFallback needs more than just config and operador_binance
         # For a simple test, it's better to ensure GerenciadorFallback can be instantiated with minimal args or use a more complete stub.
        try:
            dummy_fallback = GerenciadorFallback(config={}, operador_binance=DummyOperador(config={})) 
        except TypeError:
            logger.warning("Could not init Real GerenciadorFallback for test, using stub.")
            class GerenciadorFallbackTestStub:
                def __init__(self, config: dict): self._status = {}
                def get_status(self): return self._status.copy()
            dummy_fallback = GerenciadorFallbackTestStub(config={})
    else:
        dummy_fallback = GerenciadorFallback(config={}) # Uses the stub defined at the top of the file

    dummy_memoria.adicionar("ultimo_sinal_processado", {"ativo": "BTCUSDT", "score": 0.7, "timestamp": asyncio.get_event_loop().time()})
    dummy_memoria.adicionar("alertas_criticos", ["Alerta de teste 1", "Alerta de teste 2"])
    if hasattr(dummy_fallback, '_status'): # Check if it's the stub or our test stub
        dummy_fallback._status = {"websocket_BTCUSDT": {"status": "running"}, "websocket_ETHUSDT": {"status": "failed"}}
    
    # Run Flask directly (blocks)
    # set_dashboard_context(dummy_memoria, dummy_fallback)
    # run_flask_app(port=5001)

    # Or run using the async wrapper (more realistic)
    async def main_test():
        await rodar_dashboard_async(dummy_memoria, dummy_fallback, port=5001)
        # Keep main alive while thread runs
        while True:
            await asyncio.sleep(3600)
    
    try:
        asyncio.run(main_test())
    except KeyboardInterrupt:
        logger.info("Dashboard test server stopped.")

