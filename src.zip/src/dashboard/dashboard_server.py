"""
Dashboard de Observabilidade para KR_KRIPTO_FULL
Implementa um servidor web para monitoramento em tempo real do sistema.

Versão: 1.0
Data: Abril 2025
"""

import asyncio
import logging
import os
import json
import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Set
import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
import psutil

# Configuração de logging
logger = logging.getLogger("kr_kripto.dashboard")

# Modelos de dados
class Signal(BaseModel):
    timestamp: str
    ativo: str
    classe: str
    score: float
    probabilidade: float

class Performance(BaseModel):
    sinais_total: int
    sinais_corretos: int
    lucro_total: float
    historico: List[Dict[str, Any]]

class SystemMetrics(BaseModel):
    latencia_media: float
    cpu_uso: float
    memoria_uso: float
    uptime: float

class DashboardData(BaseModel):
    sinais: List[Dict[str, Any]]
    performance: Dict[str, Any]
    metricas: Dict[str, Any]
    ativos: Dict[str, Any]

# Classe para gerenciar conexões WebSocket
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def broadcast(self, message: Dict[str, Any]):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Erro ao enviar mensagem para WebSocket: {e}", exc_info=True)

# Função para iniciar o servidor do dashboard
async def start_dashboard_server(dashboard_data: Dict[str, Any]):
    # Criar diretório para arquivos estáticos
    os.makedirs("dashboard/static", exist_ok=True)
    
    # Criar arquivo HTML para o dashboard
    create_dashboard_html()
    
    # Criar aplicação FastAPI
    app = FastAPI(title="KR_KRIPTO Dashboard")
    
    # Configurar CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Configurar arquivos estáticos
    app.mount("/static", StaticFiles(directory="dashboard/static"), name="static")
    
    # Inicializar gerenciador de conexões
    manager = ConnectionManager()
    
    # Rota principal
    @app.get("/", response_class=HTMLResponse)
    async def get_dashboard():
        with open("dashboard/static/index.html", "r") as f:
            return f.read()
    
    # API para obter estado atual
    @app.get("/api/estado")
    async def obter_estado():
        return dashboard_data
    
    # API para obter histórico de sinais
    @app.get("/api/sinais")
    async def obter_sinais(limite: int = 100):
        return {"sinais": dashboard_data["sinais"][-limite:]}
    
    # API para obter métricas de performance
    @app.get("/api/performance/{ativo}")
    async def obter_performance(ativo: str):
        if ativo in dashboard_data["performance"]:
            return {"performance": dashboard_data["performance"][ativo]}
        return {"error": "Ativo não encontrado"}
    
    # API para obter métricas do sistema
    @app.get("/api/metricas")
    async def obter_metricas():
        return {"metricas": dashboard_data["metricas"]}
    
    # API para obter informações de um ativo específico
    @app.get("/api/ativo/{ativo}")
    async def obter_ativo(ativo: str):
        if ativo in dashboard_data["ativos"]:
            return {"ativo": dashboard_data["ativos"][ativo]}
        return {"error": "Ativo não encontrado"}
    
    # WebSocket para atualizações em tempo real
    @app.websocket("/ws")
    async def websocket_endpoint(websocket: WebSocket):
        await manager.connect(websocket)
        
        # Enviar estado inicial
        await websocket.send_json(dashboard_data)
        
        # Manter conexão e enviar atualizações
        try:
            while True:
                # Aguardar 1 segundo entre atualizações
                await asyncio.sleep(1)
                
                # Enviar estado atualizado
                await websocket.send_json({
                    "tipo": "atualizacao",
                    "timestamp": datetime.now().isoformat(),
                    "estado": dashboard_data
                })
        except WebSocketDisconnect:
            manager.disconnect(websocket)
        except Exception as e:
            logger.error(f"Erro no WebSocket: {e}", exc_info=True)
            manager.disconnect(websocket)
    
    # Tarefa para atualizar métricas do sistema
    async def atualizar_metricas():
        while True:
            try:
                # Atualizar métricas
                dashboard_data["metricas"].update({
                    "cpu_uso": psutil.cpu_percent(),
                    "memoria_uso": psutil.virtual_memory().percent,
                    "uptime": time.time() - dashboard_data["metricas"]["uptime"]
                })
                
                # Broadcast para todos os clientes conectados
                await manager.broadcast({
                    "tipo": "metricas",
                    "timestamp": datetime.now().isoformat(),
                    "metricas": dashboard_data["metricas"]
                })
                
                await asyncio.sleep(5)  # Atualizar a cada 5 segundos
            except Exception as e:
                logger.error(f"Erro ao atualizar métricas: {e}", exc_info=True)
                await asyncio.sleep(10)  # Esperar mais tempo em caso de erro
    
    # Iniciar tarefa de atualização de métricas
    asyncio.create_task(atualizar_metricas())
    
    # Iniciar servidor
    config = uvicorn.Config(app, host="0.0.0.0", port=8050, log_level="info")
    server = uvicorn.Server(config)
    await server.serve()

def create_dashboard_html():
    """
    Cria o arquivo HTML para o dashboard.
    """
    html_content = """
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KR_KRIPTO Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: #212529;
        }
        .navbar {
            background-color: #343a40;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            transition: transform 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card-header {
            border-radius: 10px 10px 0 0;
            font-weight: bold;
        }
        .metric-value {
            font-size: 24px;
            font-weight: bold;
        }
        .metric-label {
            font-size: 14px;
            color: #6c757d;
        }
        .table-container {
            max-height: 300px;
            overflow-y: auto;
        }
        .status-indicator {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 5px;
        }
        .status-online {
            background-color: #28a745;
        }
        .status-warning {
            background-color: #ffc107;
        }
        .status-error {
            background-color: #dc3545;
        }
        .chart-container {
            position: relative;
            height: 250px;
            width: 100%;
        }
        .signal-buy {
            color: #28a745;
        }
        .signal-sell {
            color: #dc3545;
        }
        .signal-neutral {
            color: #6c757d;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">KR_KRIPTO Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" href="#overview">Visão Geral</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#signals">Sinais</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#performance">Performance</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#book">Livro de Ofertas</a>
                    </li>
                </ul>
            </div>
            <div class="d-flex">
                <span class="navbar-text me-3">
                    <span class="status-indicator status-online" id="connection-status"></span>
                    <span id="connection-text">Conectado</span>
                </span>
                <span class="navbar-text" id="last-update">Última atualização: --:--:--</span>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-4">
        <!-- Visão Geral -->
        <section id="overview" class="mb-5">
            <h2 class="mb-4">Visão Geral do Sistema</h2>
            <div class="row">
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-header bg-primary text-white">CPU</div>
                        <div class="card-body text-center">
                            <div class="metric-value" id="cpu-usage">0%</div>
                            <div class="metric-label">Utilização</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-header bg-success text-white">Memória</div>
                        <div class="card-body text-center">
                            <div class="metric-value" id="memory-usage">0%</div>
                            <div class="metric-label">Utilização</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-header bg-info text-white">Latência</div>
                        <div class="card-body text-center">
                            <div class="metric-value" id="latency">0 ms</div>
                            <div class="metric-label">Média</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-header bg-secondary text-white">Uptime</div>
                        <div class="card-body text-center">
                            <div class="metric-value" id="uptime">00:00:00</div>
                            <div class="metric-label">Tempo de Execução</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-dark text-white">Ativos Monitorados</div>
                        <div class="card-body">
                            <div class="table-container">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Ativo</th>
                                            <th>Último Sinal</th>
                                            <th>Score</th>
                                            <th>Regime</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody id="assets-table">
                                        <!-- Preenchido via JavaScript -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-dark text-white">Sinais Recentes</div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="signals-chart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Sinais -->
        <section id="signals" class="mb-5">
            <h2 class="mb-4">Histórico de Sinais</h2>
            <div class="card">
                <div class="card-header bg-dark text-white">
                    Últimos Sinais Emitidos
                </div>
                <div class="card-body">
                    <div class="table-container">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Timestamp</th>
                                    <th>Ativo</th>
                                    <th>Classe</th>
                                    <th>Score</th>
                                    <th>Probabilidade</th>
                                </tr>
                            </thead>
                            <tbody id="signals-table">
                                <!-- Preenchido via JavaScript -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>

        <!-- Performance -->
        <section id="performance" class="mb-5">
            <h2 class="mb-4">Performance do Sistema</h2>
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-dark text-white">
                            Performance por Ativo
                            <select class="form-select form-select-sm float-end" style="width: auto;" id="asset-selector">
                                <!-- Preenchido via JavaScript -->
                            </select>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="performance-chart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-dark text-white">Métricas de Performance</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card mb-3">
                                        <div class="card-body text-center">
                                            <div class="metric-value" id="total-signals">0</div>
                                            <div class="metric-label">Total de Sinais</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="card mb-3">
                                        <div class="card-body text-center">
                                            <div class="metric-value" id="correct-signals">0%</div>
                                            <div class="metric-label">Taxa de Acerto</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="card mb-3">
                                        <div class="card-body text-center">
                                            <div class="metric-value" id="total-profit">$0.00</div>
                                            <div class="metric-label">Lucro Total</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="card mb-3">
                                        <div class="card-body text-center">
                                            <div class="metric-value" id="avg-profit">$0.00</div>
                                            <div class="metric-label">Lucro Médio por Sinal</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Livro de Ofertas -->
        <section id="book" class="mb-5">
            <h2 class="mb-4">Análise do Livro de Ofertas</h2>
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-dark text-white">
                            Desequilíbrio do Livro
                            <select class="form-select form-select-sm float-end" style="width: auto;" id="book-asset-selector">
                                <!-- Preenchido via JavaScript -->
                            </select>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="imbalance-chart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-dark text-white">Padrões Institucionais</div>
                        <div class="card-body">
                            <div class="table-container">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Timestamp</th>
                                            <th>Ativo</th>
                                            <th>Padrão</th>
                                            <th>Direção</th>
                                            <th>Magnitude</th>
                                        </tr>
                                    </thead>
                                    <tbody id="patterns-table">
                                        <!-- Preenchido via JavaScript -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Estado global
        let dashboardData = {
            sinais: [],
            performance: {},
            metricas: {
                latencia_media: 0,
                cpu_uso: 0,
                memoria_uso: 0,
                uptime: 0
            },
            ativos: {}
        };

        // Gráficos
        let signalsChart;
        let performanceChart;
        let imbalanceChart;

        // Padrões institucionais recentes
        let institutionalPatterns = [];

        // WebSocket
        let ws;
        let reconnectAttempts = 0;
        const maxReconnectAttempts = 5;

        // Inicializar dashboard
        document.addEventListener('DOMContentLoaded', function() {
            initCharts();
            connectWebSocket();
            
            // Atualizar a cada segundo
            setInterval(updateDashboard, 1000);
        });

        // Inicializar gráficos
        function initCharts() {
            // Gráfico de sinais
            const signalsCtx = document.getElementById('signals-chart').getContext('2d');
            signalsChart = new Chart(signalsCtx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Score dos Sinais',
                        data: [],
                        borderColor: 'rgba(75, 192, 192, 1)',
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            // Gráfico de performance
            const performanceCtx = document.getElementById('performance-chart').getContext('2d');
            performanceChart = new Chart(performanceCtx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Lucro Acumulado',
                        data: [],
                        borderColor: 'rgba(54, 162, 235, 1)',
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            // Gráfico de desequilíbrio
            const imbalanceCtx = document.getElementById('imbalance-chart').getContext('2d');
            imbalanceChart = new Chart(imbalanceCtx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Desequilíbrio do Livro',
                        data: [],
                        borderColor: 'rgba(255, 99, 132, 1)',
                        backgroundColor: 'rgba(255, 99, 132, 0.2)',
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            min: -1,
                            max: 1
                        }
                    }
                }
            });
        }

        // Conectar ao WebSocket
        function connectWebSocket() {
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const wsUrl = `${protocol}//${window.location.host}/ws`;
            
            ws = new WebSocket(wsUrl);
            
            ws.onopen = function() {
                console.log('WebSocket conectado');
                document.getElementById('connection-status').className = 'status-indicator status-online';
                document.getElementById('connection-text').textContent = 'Conectado';
                reconnectAttempts = 0;
            };
            
            ws.onmessage = function(event) {
                const data = JSON.parse(event.data);
                
                if (data.tipo === 'atualizacao') {
                    dashboardData = data.estado;
                    document.getElementById('last-update').textContent = `Última atualização: ${new Date().toLocaleTimeString()}`;
                } else if (data.tipo === 'metricas') {
                    dashboardData.metricas = data.metricas;
                } else {
                    dashboardData = data;
                }
            };
            
            ws.onclose = function() {
                document.getElementById('connection-status').className = 'status-indicator status-error';
                document.getElementById('connection-text').textContent = 'Desconectado';
                
                // Tentar reconectar
                if (reconnectAttempts < maxReconnectAttempts) {
                    reconnectAttempts++;
                    console.log(`Tentando reconectar (${reconnectAttempts}/${maxReconnectAttempts})...`);
                    setTimeout(connectWebSocket, 3000);
                }
            };
            
            ws.onerror = function(error) {
                console.error('Erro no WebSocket:', error);
                document.getElementById('connection-status').className = 'status-indicator status-error';
                document.getElementById('connection-text').textContent = 'Erro';
            };
        }

        // Atualizar dashboard
        function updateDashboard() {
            updateMetrics();
            updateAssets();
            updateSignals();
            updatePerformance();
            updateBookAnalysis();
        }

        // Atualizar métricas
        function updateMetrics() {
            document.getElementById('cpu-usage').textContent = `${dashboardData.metricas.cpu_uso.toFixed(1)}%`;
            document.getElementById('memory-usage').textContent = `${dashboardData.metricas.memoria_uso.toFixed(1)}%`;
            document.getElementById('latency').textContent = `${dashboardData.metricas.latencia_media.toFixed(2)} ms`;
            
            // Formatar uptime
            const uptime = dashboardData.metricas.uptime;
            const hours = Math.floor(uptime / 3600);
            const minutes = Math.floor((uptime % 3600) / 60);
            const seconds = Math.floor(uptime % 60);
            document.getElementById('uptime').textContent = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        }

        // Atualizar ativos
        function updateAssets() {
            const assetsTable = document.getElementById('assets-table');
            assetsTable.innerHTML = '';
            
            const assetSelector = document.getElementById('asset-selector');
            const bookAssetSelector = document.getElementById('book-asset-selector');
            
            // Limpar seletores
            assetSelector.innerHTML = '';
            bookAssetSelector.innerHTML = '';
            
            for (const [ativo, data] of Object.entries(dashboardData.ativos)) {
                // Adicionar à tabela
                const row = document.createElement('tr');
                
                const lastSignal = data.ultimo_sinal || { classe: 'N/A', score: 0, probabilidade: 0 };
                const signalClass = lastSignal.classe === 'compra' ? 'signal-buy' : 
                                   lastSignal.classe === 'venda' ? 'signal-sell' : 'signal-neutral';
                
                row.innerHTML = `
                    <td>${ativo}</td>
                    <td class="${signalClass}">${lastSignal.classe || 'N/A'}</td>
                    <td>${lastSignal.score ? lastSignal.score.toFixed(2) : 'N/A'}</td>
                    <td>${data.regime || 'normal'}</td>
                    <td><span class="status-indicator status-online"></span> Ativo</td>
                `;
                
                assetsTable.appendChild(row);
                
                // Adicionar aos seletores
                const option1 = document.createElement('option');
                option1.value = ativo;
                option1.textContent = ativo;
                assetSelector.appendChild(option1);
                
                const option2 = document.createElement('option');
                option2.value = ativo;
                option2.textContent = ativo;
                bookAssetSelector.appendChild(option2);
            }
            
            // Selecionar primeiro ativo se não houver seleção
            if (assetSelector.value === '' && assetSelector.options.length > 0) {
                assetSelector.value = assetSelector.options[0].value;
            }
            
            if (bookAssetSelector.value === '' && bookAssetSelector.options.length > 0) {
                bookAssetSelector.value = bookAssetSelector.options[0].value;
            }
        }

        // Atualizar sinais
        function updateSignals() {
            const signalsTable = document.getElementById('signals-table');
            signalsTable.innerHTML = '';
            
            // Limitar a 20 sinais mais recentes
            const recentSignals = dashboardData.sinais.slice(-20).reverse();
            
            for(config={}) {
                const row = document.createElement('tr');
                
                const signalClass = signal.classe === 'compra' ? 'signal-buy' : 
                                   signal.classe === 'venda' ? 'signal-sell' : 'signal-neutral';
                
                const date = new Date(signal.timestamp);
                
                row.innerHTML = `
                    <td>${date.toLocaleString()}</td>
                    <td>${signal.ativo}</td>
                    <td class="${signalClass}">${signal.classe}</td>
                    <td>${signal.score.toFixed(2)}</td>
                    <td>${(signal.probabilidade * 100).toFixed(1)}%</td>
                `;
                
                signalsTable.appendChild(row);
            }
            
            // Atualizar gráfico de sinais
            if (signalsChart && recentSignals.length > 0) {
                signalsChart.data.labels = recentSignals.map(s => new Date(s.timestamp).toLocaleTimeString());
                signalsChart.data.datasets[0].data = recentSignals.map(s => s.score);
                signalsChart.update();
            }
        }

        // Atualizar performance
        function updatePerformance() {
            const selectedAsset = document.getElementById('asset-selector').value;
            
            if (!selectedAsset || !dashboardData.performance[selectedAsset]) {
                return;
            }
            
            const performance = dashboardData.performance[selectedAsset];
            
            // Atualizar métricas
            document.getElementById('total-signals').textContent = performance.sinais_total || 0;
            
            const correctRate = performance.sinais_total > 0 ? 
                (performance.sinais_corretos / performance.sinais_total) * 100 : 0;
            document.getElementById('correct-signals').textContent = `${correctRate.toFixed(1)}%`;
            
            document.getElementById('total-profit').textContent = `$${performance.lucro_total.toFixed(2)}`;
            
            const avgProfit = performance.sinais_total > 0 ? 
                performance.lucro_total / performance.sinais_total : 0;
            document.getElementById('avg-profit').textContent = `$${avgProfit.toFixed(2)}`;
            
            // Atualizar gráfico de performance
            if (performanceChart && performance.historico && performance.historico.length > 0) {
                const historico = performance.historico.slice(-20);  // Últimos 20 pontos
                
                performanceChart.data.labels = historico.map(h => new Date(h.timestamp).toLocaleTimeString());
                
                // Calcular lucro acumulado
                let acumulado = 0;
                performanceChart.data.datasets[0].data = historico.map(h => {
                    acumulado += h.lucro;
                    return acumulado;
                });
                
                performanceChart.update();
            }
        }

        // Atualizar análise do livro
        function updateBookAnalysis() {
            const selectedAsset = document.getElementById('book-asset-selector').value;
            
            if (!selectedAsset || !dashboardData.ativos[selectedAsset]) {
                return;
            }
            
            const ativoData = dashboardData.ativos[selectedAsset];
            
            // Atualizar gráfico de desequilíbrio
            if (imbalanceChart) {
                // Simular dados de desequilíbrio (em uma implementação real, estes viriam do backend)
                const now = new Date();
                const labels = [];
                const data = [];
                
                for(config={'i': 19; i >= 0; i--}) {
                    const time = new Date(now - i * 1000);
                    labels.push(time.toLocaleTimeString());
                    
                    // Usar desequilíbrio real se disponível, ou simular
                    if (ativoData.desequilibrio_book !== undefined) {
                        // Adicionar um pouco de variação para visualização
                        const variation = (Math.random() - 0.5) * 0.1;
                        data.push(ativoData.desequilibrio_book + variation);
                    } else {
                        data.push((Math.random() * 2 - 1) * 0.5);  // Valor entre -0.5 e 0.5
                    }
                }
                
                imbalanceChart.data.labels = labels;
                imbalanceChart.data.datasets[0].data = data;
                imbalanceChart.update();
            }
            
            // Atualizar tabela de padrões institucionais
            const patternsTable = document.getElementById('patterns-table');
            
            // Verificar se há novos padrões institucionais
            if (ativoData.padroes_institucionais && ativoData.padroes_institucionais.significativo) {
                const now = new Date();
                
                // Adicionar novo padrão
                institutionalPatterns.unshift({
                    timestamp: now,
                    ativo: selectedAsset,
                    padrao: getPadraoNome(ativoData.padroes_institucionais),
                    direcao: getPadraoDirecao(ativoData.padroes_institucionais),
                    magnitude: getPadraoMagnitude(ativoData.padroes_institucionais)
                });
                
                // Limitar a 20 padrões
                if (institutionalPatterns.length > 20) {
                    institutionalPatterns.pop();
                }
            }
            
            // Atualizar tabela
            patternsTable.innerHTML = '';
            
            for(config={}) {
                const row = document.createElement('tr');
                
                const direcaoClass = pattern.direcao > 0 ? 'signal-buy' : 
                                    pattern.direcao < 0 ? 'signal-sell' : 'signal-neutral';
                
                row.innerHTML = `
                    <td>${pattern.timestamp.toLocaleString()}</td>
                    <td>${pattern.ativo}</td>
                    <td>${pattern.padrao}</td>
                    <td class="${direcaoClass}">${pattern.direcao > 0 ? 'Compra' : pattern.direcao < 0 ? 'Venda' : 'Neutro'}</td>
                    <td>${pattern.magnitude.toFixed(2)}</td>
                `;
                
                patternsTable.appendChild(row);
            }
        }

        // Funções auxiliares para padrões institucionais
        function getPadraoNome(padroes) {
            if (padroes.paredes && padroes.paredes.significativo) return 'Parede';
            if (padroes.iceberg && padroes.iceberg.significativo) return 'Iceberg';
            if (padroes.absorção && padroes.absorção.significativo) return 'Absorção';
            if (padroes.spoofing && padroes.spoofing.significativo) return 'Spoofing';
            if (padroes.layering && padroes.layering.significativo) return 'Layering';
            if (padroes.momentum_ignition && padroes.momentum_ignition.significativo) return 'Ignição de Momentum';
            return 'Desconhecido';
        }

        function getPadraoDirecao(padroes) {
            if (padroes.paredes && padroes.paredes.significativo) return padroes.paredes.direcao;
            if (padroes.iceberg && padroes.iceberg.significativo) return padroes.iceberg.direcao;
            if (padroes.absorção && padroes.absorção.significativo) return padroes.absorção.direcao;
            if (padroes.spoofing && padroes.spoofing.significativo) return padroes.spoofing.direcao;
            if (padroes.layering && padroes.layering.significativo) return padroes.layering.direcao;
            if (padroes.momentum_ignition && padroes.momentum_ignition.significativo) return padroes.momentum_ignition.direcao_final;
            return 0;
        }

        function getPadraoMagnitude(padroes) {
            if (padroes.paredes && padroes.paredes.significativo) return padroes.paredes.tamanho;
            if (padroes.iceberg && padroes.iceberg.significativo) return padroes.iceberg.tamanho;
            if (padroes.absorção && padroes.absorção.significativo) return padroes.absorção.tamanho;
            if (padroes.spoofing && padroes.spoofing.significativo) return padroes.spoofing.tamanho;
            if (padroes.layering && padroes.layering.significativo) return padroes.layering.tamanho_total;
            if (padroes.momentum_ignition && padroes.momentum_ignition.significativo) return padroes.momentum_ignition.magnitude;
            return 0;
        }

        // Event listeners para seletores
        document.getElementById('asset-selector').addEventListener('change', updatePerformance);
        document.getElementById('book-asset-selector').addEventListener('change', updateBookAnalysis);
    </script>
</body>
</html>
    """
    
    # Criar diretório se não existir
    os.makedirs("dashboard/static", exist_ok=True)
    
    # Escrever arquivo HTML
    with open("dashboard/static/index.html", "w") as f:
        f.write(html_content)
    
    logger.info("Arquivo HTML do dashboard criado com sucesso")
