# src/infrastructure/circuitbreaker.py
import logging
from typing import Dict, Any

logger = logging.getLogger("kr_kripto_circuitbreaker")

class CircuitBreakerManager:
    """Gerencia circuit breakers para diferentes serviços (stub)."""
    def __init__(self, config: dict):
        self.config = config
        logger.info("CircuitBreakerManager(config={}) inicializado.")

    def check(self, service_name: str) -> bool:
        logger.debug(f"CircuitBreaker check (stub) para {service_name}. Retornando True (permitido)." )
        # Placeholder: Always allow requests in stub
        return True

    def record_failure(self, service_name: str):
        logger.debug(f"CircuitBreaker record_failure (stub) para {service_name}.")
        # Placeholder: Does nothing in stub
        pass

    def record_success(self, service_name: str):
        logger.debug(f"CircuitBreaker record_success (stub) para {service_name}.")
        # Placeholder: Does nothing in stub
        pass

