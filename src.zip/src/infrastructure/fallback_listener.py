# src/infrastructure/fallback_listener.py

import os
import asyncio
import logging
import json
from datetime import datetime
from typing import Optional

import pybreaker
import aiobreaker

# Configuração de logging
logger = logging.getLogger("kr_kripto_fallback_listener") # Nome do logger específico para o listener
logger.propagate = True

# Tentativa de importar notifier e prometheus_exporter (copiado de fallback.py, pode ser otimizado depois)
try:
    from src.infrastructure.notifier import enviar_telegram
    NOTIFIER_AVAILABLE = True
except ImportError:
    NOTIFIER_AVAILABLE = False
    async def enviar_telegram(*args, **kwargs):  # Stub function
        logger.error("ERROR: Notifier module (enviar_telegram) not available in listener.")
        if args:
            logger.info(f"[TELEGRAM STUB LISTENER] {args[0]}")

try:
    from src.monitoring.prometheus_exporter import fallback_metric as FALLBACK_ACTIVATIONS_TOTAL
    PROMETHEUS_AVAILABLE = True
    logger.info("Prometheus exporter and fallback_metric (FALLBACK_ACTIVATIONS_TOTAL) loaded in listener.")
except ImportError:
    PROMETHEUS_AVAILABLE = False
    class MockCounter:
        def __init__(self, config: dict):
            self._name = config.get('name', 'unnamed_counter')
            logger.warning(f"MockCounter {self._name} initialized in listener.")
        def inc(self, *args, **kwargs):
            logger.warning(f"MockCounter {self._name} .inc() called in listener with args: {args}, kwargs: {kwargs}")
            pass
    FALLBACK_ACTIVATIONS_TOTAL = MockCounter(config={'name': "fallback_activations_total_listener_stub"})
    logger.warning("WARNING: Prometheus exporter or FALLBACK_ACTIVATIONS_TOTAL not available in listener. Using stub.")

class FallbackListener:
    def __init__(self, config: dict, loop=None):
        super().__init__()
        self.loop = loop or asyncio.get_event_loop()
        self._custom_status_file_path = None

    @property
    def status_file_path(self):
        if hasattr(self, "_custom_status_file_path") and self._custom_status_file_path:
            return self._custom_status_file_path
        else:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            return os.path.join(base_dir, "logs", "fallback_status.json")

    @status_file_path.setter
    def status_file_path(self, value):
        self._custom_status_file_path = value

    def before_call(self, cb, func, *args, **kwargs):
        pass # logger.debug(f"LISTENER_DEBUG: Before call for breaker {cb.name if hasattr(cb, 'name') else 'Unnamed'}")

    def state_change(self, cb, old_state, new_state):
        breaker_name = cb.name if hasattr(cb, "name") else "UnnamedBreaker"
        old_state_name = str(old_state.name if hasattr(old_state, "name") else old_state).upper()
        new_state_name = str(new_state.name if hasattr(new_state, "name") else new_state).upper()
        
        logger.info(f"LISTENER_INFO: State change for breaker {breaker_name}. Old: {old_state_name}, New: {new_state_name}. Status file: {self.status_file_path}")

        actual_new_state_str = new_state_name

        # Determine expected state strings based on breaker type
        if isinstance(cb, aiobreaker.CircuitBreaker):
            # Para aiobreaker, os estados são enums, então comparamos seus nomes
            expected_open_state = aiobreaker.CircuitBreakerState.OPEN.name
            expected_half_open_state = aiobreaker.CircuitBreakerState.HALF_OPEN.name
            expected_closed_state = aiobreaker.CircuitBreakerState.CLOSED.name
        else: # Assumindo pybreaker ou similar que tem .upper() em STATE_X
            expected_open_state = pybreaker.STATE_OPEN.upper()
            expected_half_open_state = pybreaker.STATE_HALF_OPEN.upper()
            expected_closed_state = pybreaker.STATE_CLOSED.upper()

        if actual_new_state_str == expected_open_state:
            log_message = f"Circuit breaker {breaker_name} opened due to repeated failures."
            logger.critical(log_message)
            if self.loop and not self.loop.is_closed():
                self.loop.create_task(self._handle_breaker_open(breaker_name, log_message))
        elif actual_new_state_str == expected_half_open_state:
            log_message = f"Circuit breaker {breaker_name} HALF-OPEN after timeout."
            logger.info(log_message)
            if self.loop and not self.loop.is_closed():
                self.loop.create_task(self._handle_breaker_half_open(breaker_name, log_message))
        elif actual_new_state_str == expected_closed_state:
            log_message = f"Circuit breaker {breaker_name} is now CLOSED after successful operation."
            logger.info(log_message)
            if self.loop and not self.loop.is_closed():
                self.loop.create_task(self._handle_breaker_close(breaker_name, log_message))

    def failure(self, cb, exc):
        breaker_name = cb.name if hasattr(cb, "name") and cb.name else "UnnamedBreakerInListener"
        fail_counter_val = "N/A"
        if hasattr(cb, "fail_counter"): # pybreaker
            fail_counter_val = cb.fail_counter
        elif hasattr(cb, "_fail_counter"): # aiobreaker (internal)
            fail_counter_val = cb._fail_counter
        logger.warning(f"LISTENER_FAILURE: Failure for breaker {breaker_name}. Exception: {type(exc).__name__}({exc}). Fail_counter: {fail_counter_val}")

    def success(self, cb):
        breaker_name = cb.name if hasattr(cb, "name") and cb.name else "UnnamedBreakerInListener"
        logger.info(f"LISTENER_SUCCESS: Success for breaker {breaker_name}.")

    async def _update_status_file(self, breaker_name: str, state: str, additional_info: Optional[str] = None):
        try:
            status_file = self.status_file_path
            os.makedirs(os.path.dirname(status_file), exist_ok=True)
            timestamp = datetime.now().isoformat()
            
            status_key_generic = f"breaker_{breaker_name}_last_event"
            status_data_update = {
                status_key_generic: {"timestamp": timestamp, "state": state.upper(), "info": additional_info or "N/A"}
            }
            if state.upper() == "OPEN":
                status_data_update["last_breaker_open"] = {"name": breaker_name, "state": "OPEN", "timestamp": timestamp, "info": additional_info}
            elif state.upper() == "CLOSED":
                 status_data_update["last_breaker_closed"] = {"name": breaker_name, "state": "CLOSED", "timestamp": timestamp, "info": additional_info}
            elif state.upper() == "HALF-OPEN":
                 status_data_update["last_breaker_half_open"] = {"name": breaker_name, "state": "HALF-OPEN", "timestamp": timestamp, "info": additional_info}

            current_status = {}
            if os.path.exists(status_file):
                try:
                    with open(status_file, "r") as f_read:
                        current_status = json.load(f_read)
                except json.JSONDecodeError:
                    logger.warning(f"Could not decode existing status file {status_file}. Overwriting specific keys.")
            
            current_status.update(status_data_update)
            current_status["overall_last_event"] = {"breaker": breaker_name, "state": state.upper(), "timestamp": timestamp, "info": additional_info or "N/A"}

            with open(status_file, "w") as f_write:
                json.dump(current_status, f_write, indent=4)
            logger.info(f"Status file {status_file} updated for breaker {breaker_name} state {state.upper()}.")
        except Exception as status_e:
            logger.error(f"Failed to update status file for breaker {breaker_name} state {state.upper()}: {status_e}", exc_info=True)

    async def _handle_breaker_open(self, breaker_name: str, log_message: str):
        logger.info(f"LISTENER_ASYNC_HANDLE: _handle_breaker_open for {breaker_name}")
        if PROMETHEUS_AVAILABLE:
            try:
                FALLBACK_ACTIVATIONS_TOTAL.inc()
                logger.info(f"Prometheus metric FALLBACK_ACTIVATIONS_TOTAL incremented for breaker {breaker_name}.")
            except Exception as prom_e:
                logger.error(f"Failed to increment Prometheus metric FALLBACK_ACTIVATIONS_TOTAL for {breaker_name}: {prom_e}", exc_info=True)
        else:
            logger.warning(f"Prometheus exporter not available, skipping metric FALLBACK_ACTIVATIONS_TOTAL increment for {breaker_name}.")
        if NOTIFIER_AVAILABLE:
            await enviar_telegram(f"🚨 ALERTA CRÍTICO: Circuit Breaker {breaker_name} ATIVADO! {log_message}")
        await self._update_status_file(breaker_name, "OPEN", log_message)

    async def _handle_breaker_half_open(self, breaker_name: str, log_message: str):
        logger.info(f"LISTENER_ASYNC_HANDLE: _handle_breaker_half_open for {breaker_name}")
        if NOTIFIER_AVAILABLE:
            await enviar_telegram(f"Circuit breaker {breaker_name} HALF-OPEN after timeout.")
        await self._update_status_file(breaker_name, "HALF-OPEN", log_message)

    async def _handle_breaker_close(self, breaker_name: str, log_message: str):
        logger.info(f"LISTENER_ASYNC_HANDLE: _handle_breaker_close for {breaker_name}")
        if NOTIFIER_AVAILABLE:
            await enviar_telegram(f"Circuit breaker {breaker_name} is now CLOSED after successful operation.")
        await self._update_status_file(breaker_name, "CLOSED", log_message)

