
from datetime import datetime

def log_erro(mensagem):
    try:
        with open("log_erros.txt", "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now()}] {mensagem}\n")
    except:
        print("Erro ao registrar log.")
