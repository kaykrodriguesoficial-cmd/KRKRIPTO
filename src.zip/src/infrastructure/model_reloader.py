# src/infrastructure/model_reloader.py

import asyncio
import logging
import os
import time
from typing import Optional, Callable, Any

# Assuming model loading function exists (e.g., from neural_governance or a dedicated loader)
# from ..intelligence.governance.neural_governance import ModelLoader # Example import

logger = logging.getLogger("kr_kripto_reloader")

class ModelReloader:
    """Monitors for model updates and reloads them in the background."""

    def __init__(
        self,
        model_path: str,
        trigger_file_path: str,
        load_model_func: Callable[[str], Any], # Function to load the model
        check_interval_sec: int = 60
    ):
        """Initializes the ModelReloader.

        Args:
            model_path: Path to the current model file.
            trigger_file_path: Path to a file whose modification triggers a reload attempt.
            load_model_func: A callable function that takes the model path and returns the loaded model.
            check_interval_sec: How often to check the trigger file (in seconds).
        """
        self.model_path = model_path
        self.trigger_file_path = trigger_file_path
        self.load_model_func = load_model_func
        self.check_interval_sec = check_interval_sec

        self.current_model: Any = None
        self.new_model: Optional[Any] = None
        self.last_trigger_mtime: Optional[float] = None
        self._reload_task: Optional[asyncio.Task] = None
        self._monitor_task: Optional[asyncio.Task] = None
        self._lock = asyncio.Lock()

        logger.info(f"ModelReloader initialized for model: {model_path}, trigger: {trigger_file_path}")

    async def start(self):
        """Starts the monitoring process."""
        logger.info("Starting ModelReloader monitoring...")
        # Initial load
        try:
            self.current_model = self.load_model_func(self.model_path)
            logger.info(f"Initial model loaded successfully from {self.model_path}")
        except Exception as e:
            logger.error(f"Failed to load initial model from {self.model_path}: {e}", exc_info=True)
            # Decide if we should proceed without a model or raise an error
            # For now, we proceed, but get_model will return None

        # Get initial modification time of trigger file
        try:
            if os.path.exists(self.trigger_file_path):
                self.last_trigger_mtime = os.path.getmtime(self.trigger_file_path)
                logger.info(f"Initial trigger file mtime: {self.last_trigger_mtime}")
            else:
                logger.warning(f"Trigger file {self.trigger_file_path} does not exist. Reload will not be triggered until it appears.")
        except Exception as e:
            logger.error(f"Error getting initial mtime for trigger file {self.trigger_file_path}: {e}")

        # Start monitoring task
        self._monitor_task = asyncio.create_task(self._monitor_trigger())
        logger.info("ModelReloader monitoring task started.")

    async def stop(self):
        """Stops the monitoring process."""
        logger.info("Stopping ModelReloader...")
        if self._monitor_task and not self._monitor_task.done():
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass # Expected
        if self._reload_task and not self._reload_task.done():
            self._reload_task.cancel()
            try:
                await self._reload_task
            except asyncio.CancelledError:
                pass # Expected
        logger.info("ModelReloader stopped.")

    async def _monitor_trigger(self):
        """Periodically checks the trigger file for modifications."""
        while True:
            await asyncio.sleep(self.check_interval_sec)
            try:
                if not os.path.exists(self.trigger_file_path):
                    # If trigger file disappears, reset mtime so it triggers on reappearance
                    if self.last_trigger_mtime is not None:
                         logger.warning(f"Trigger file {self.trigger_file_path} disappeared.")
                         self.last_trigger_mtime = None
                    continue

                current_mtime = os.path.getmtime(self.trigger_file_path)

                if self.last_trigger_mtime is None:
                    # Trigger file just appeared
                    logger.info(f"Trigger file {self.trigger_file_path} appeared. Triggering reload.")
                    self.last_trigger_mtime = current_mtime
                    self._start_reload()
                elif current_mtime > self.last_trigger_mtime:
                    logger.info(f"Trigger file {self.trigger_file_path} modified. Triggering reload.")
                    self.last_trigger_mtime = current_mtime
                    self._start_reload()
                # else: No change detected

            except Exception as e:
                logger.error(f"Error checking trigger file {self.trigger_file_path}: {e}", exc_info=True)

    def _start_reload(self):
        """Starts the background model reloading task if not already running."""
        if self._reload_task and not self._reload_task.done():
            logger.warning("Reload task already in progress. Ignoring new trigger.")
            return

        logger.info("Starting background model reload...")
        self._reload_task = asyncio.create_task(self._reload_model_background())

    async def _reload_model_background(self):
        """Loads the new model in the background."""
        try:
            # Assume the new model path is the same as the original for now
            # In a real scenario, this might involve finding the latest model file
            new_model_instance = self.load_model_func(self.model_path)
            logger.info(f"New model loaded successfully in background from {self.model_path}")
            async with self._lock:
                self.new_model = new_model_instance
        except Exception as e:
            logger.error(f"Failed to reload model in background from {self.model_path}: {e}", exc_info=True)
            # Keep the old model, clear the new_model flag if set
            async with self._lock:
                self.new_model = None # Indicate failure

    async def swap_model_if_available(self) -> bool:
        """Swaps the current model with the newly loaded one if available.

        Returns:
            True if a swap occurred, False otherwise.
        """
        swapped = False
        async with self._lock:
            if self.new_model is not None:
                logger.info("Swapping to newly reloaded model.")
                self.current_model = self.new_model
                self.new_model = None # Clear the flag
                swapped = True
        return swapped

    async def get_model(self) -> Any:
        """Returns the currently active model."""
        # Check for and perform swap before returning the model
        await self.swap_model_if_available()
        async with self._lock:
            return self.current_model

# Example Usage (Conceptual - requires a real load_model_func)

# Dummy load function for testing
def dummy_load_model(path):
    print(f"--- DUMMY LOAD: Loading model from {path} at {time.time()} ---")
    # Simulate loading time
    time.sleep(2)
    # Return a simple object representing the model (e.g., its load time)
    return {"path": path, "load_time": time.time()}

async def main_reloader_test():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    MODEL_FILE = "/home/ubuntu/dummy_model.h5"
    TRIGGER_FILE = "/home/ubuntu/reload_trigger.txt"

    # Create dummy files
    with open(MODEL_FILE, "w") as f:
        f.write("initial model data")
    with open(TRIGGER_FILE, "w") as f:
        f.write("initial trigger")

    reloader = ModelReloader(
        model_path=MODEL_FILE,
        trigger_file_path=TRIGGER_FILE,
        load_model_func=dummy_load_model,
        check_interval_sec=5 # Check every 5 seconds for testing
    )

    await reloader.start()

    # Simulate getting the model periodically
    for i in range(6):
        print(f"[{i*5}s] Getting model...")
        model = await reloader.get_model()
        print(f"[{i*5}s] Current model: {model}")

        # Simulate modifying the trigger file after 12 seconds
        if i == 2:
            print("--- SIMULATING TRIGGER FILE MODIFICATION ---")
            await asyncio.sleep(2) # Ensure modification time is distinct
            with open(TRIGGER_FILE, "w") as f:
                f.write(f"modified at {time.time()}")

        await asyncio.sleep(5)

    await reloader.stop()

    # Clean up dummy files
    os.remove(MODEL_FILE)
    os.remove(TRIGGER_FILE)

if __name__ == "__main__" and "test_reloader" in os.environ:
    # Run test only if specifically requested
    asyncio.run(main_reloader_test())

