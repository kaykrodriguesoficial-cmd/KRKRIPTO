import subprocess
from multiprocessing import Process
import time

def rodar_ativo(ativo):
    print(f"🚀 Iniciando processo para {ativo}")
    subprocess.call(["python3", "stream_binance.py", ativo])

def executar_multiplos_ativos(ativos=None):
    if ativos is None:
        ativos = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT"]

    processos = []
    for ativo in ativos:
        p = Process(target=rodar_ativo, args=(ativo,))
        p.start()
        processos.append(p)
        time.sleep(1)  # Evita sobrecarga inicial

    for p in processos:
        p.join()