#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Módulo de notificação para o sistema KR_KRIPTO_ADVANCED.

Este módulo fornece funções para enviar notificações via Telegram e outros canais.
"""

# Adicionando função log_erro que está sendo importada por outros módulos
def log_erro(mensagem: str, erro: Exception = None, traceback_completo: bool = True) -> None:
    """
    Registra um erro no log e opcionalmente envia notificação.
    
    Args:
        mensagem: Descrição do erro
        erro: Objeto de exceção (opcional)
        traceback_completo: Se deve incluir o traceback completo
        
    Returns:
        None
    """
    error_msg = mensagem
    if erro:
        error_msg += f": {str(erro)}"
    
    if traceback_completo and erro:
        error_msg += f"\n{traceback.format_exc()}"
        
    logger.error(error_msg)
    return None

import os
import sys
import json
import logging
import traceback
from typing import Dict, Any, Optional, List, Union

logger = logging.getLogger("kr_kripto_notifier")

# Verificar se as dependências estão disponíveis
try:
    import aiohttp
    AIOHTTP_AVAILABLE = True
except ImportError:
    logger.warning("aiohttp não está disponível. Notificações via HTTP serão simuladas.")
    AIOHTTP_AVAILABLE = False

# Configurações
TELEGRAM_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")
TELEGRAM_API_URL = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"

async def enviar_telegram(mensagem: str, chat_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Envia uma mensagem para um chat do Telegram.
    
    Args:
        mensagem: Texto da mensagem a ser enviada
        chat_id: ID do chat para enviar a mensagem. Se não fornecido, usa o valor padrão.
        
    Returns:
        Dicionário com o resultado da operação
    """
    if not chat_id:
        chat_id = TELEGRAM_CHAT_ID
        
    if not TELEGRAM_TOKEN or not chat_id:
        logger.warning("Token do Telegram ou Chat ID não configurados. Mensagem não enviada.")
        return {"success": False, "error": "Configuração incompleta", "message": mensagem}
        
    try:
        if AIOHTTP_AVAILABLE:
            async with aiohttp.ClientSession() as session:
                payload = {
                    "chat_id": chat_id,
                    "text": mensagem,
                    "parse_mode": "HTML"
                }
                
                logger.debug(f"Enviando mensagem para Telegram: {mensagem[:50]}...")
                
                async with session.post(TELEGRAM_API_URL, json=payload) as response:
                    if response.status == 200:
                        result = await response.json()
                        logger.info(f"Mensagem enviada com sucesso para o Telegram.")
                        return {"success": True, "response": result}
                    else:
                        error_text = await response.text()
                        logger.error(f"Erro ao enviar mensagem para Telegram: {response.status} - {error_text}")
                        return {"success": False, "error": f"HTTP {response.status}", "details": error_text}
        else:
            # Simulação quando aiohttp não está disponível
            logger.info(f"[SIMULAÇÃO] Mensagem enviada para Telegram: {mensagem}")
            return {"success": True, "simulated": True, "message": mensagem}
            
    except Exception as e:
        logger.error(f"Exceção ao enviar mensagem para Telegram: {str(e)}")
        logger.debug(f"Detalhes: {traceback.format_exc()}")
        return {"success": False, "error": str(e), "message": mensagem}

async def enviar_email(destinatario: str, assunto: str, corpo: str) -> Dict[str, Any]:
    """
    Envia um email.
    
    Args:
        destinatario: Endereço de email do destinatário
        assunto: Assunto do email
        corpo: Corpo do email
        
    Returns:
        Dicionário com o resultado da operação
    """
    # Stub para simulação
    logger.info(f"[SIMULAÇÃO] Email enviado para {destinatario}: {assunto}")
    return {"success": True, "simulated": True, "to": destinatario, "subject": assunto}

async def enviar_sms(numero: str, mensagem: str) -> Dict[str, Any]:
    """
    Envia um SMS.
    
    Args:
        numero: Número de telefone do destinatário
        mensagem: Texto da mensagem
        
    Returns:
        Dicionário com o resultado da operação
    """
    # Stub para simulação
    logger.info(f"[SIMULAÇÃO] SMS enviado para {numero}: {mensagem[:20]}...")
    return {"success": True, "simulated": True, "to": numero, "message": mensagem}

async def enviar_webhook(url: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Envia dados para um webhook.
    
    Args:
        url: URL do webhook
        payload: Dados a serem enviados
        
    Returns:
        Dicionário com o resultado da operação
    """
    try:
        if AIOHTTP_AVAILABLE:
            async with aiohttp.ClientSession() as session:
                logger.debug(f"Enviando webhook para {url}")
                
                async with session.post(url, json=payload) as response:
                    if response.status in (200, 201, 202, 204):
                        result = await response.json()
                        logger.info(f"Webhook enviado com sucesso para {url}")
                        return {"success": True, "response": result}
                    else:
                        error_text = await response.text()
                        logger.error(f"Erro ao enviar webhook: {response.status} - {error_text}")
                        return {"success": False, "error": f"HTTP {response.status}", "details": error_text}
        else:
            # Simulação quando aiohttp não está disponível
            logger.info(f"[SIMULAÇÃO] Webhook enviado para {url}: {json.dumps(payload)[:50]}...")
            return {"success": True, "simulated": True, "url": url, "payload": payload}
            
    except Exception as e:
        logger.error(f"Exceção ao enviar webhook: {str(e)}")
        logger.debug(f"Detalhes: {traceback.format_exc()}")
        return {"success": False, "error": str(e), "url": url}
