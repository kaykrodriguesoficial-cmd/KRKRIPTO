# -*- coding: utf-8 -*-
"""Módulo para gerenciar e exportar métricas Prometheus."""

import logging
import asyncio # Added for async alert
import time

# Importar prometheus_client com tratamento de erro robusto
try:
    from prometheus_client import Counter, Gauge, Histogram, start_http_server, REGISTRY
    PROMETHEUS_AVAILABLE = True
except ImportError as e:
    logging.critical(f"Falha ao importar biblioteca prometheus_client: {e}. Execute 'pip install prometheus_client' para resolver.")
    PROMETHEUS_AVAILABLE = False
    # Definir classes stub para métricas
    class MetricStub:
        def __init__(self, *args, **kwargs):
            pass
        def labels(self, **kwargs):
            return self
        def inc(self, *args, **kwargs):
            pass
        def set(self, *args, **kwargs):
            pass
        def observe(self, *args, **kwargs):
            pass
        def set_to_current_time(self, *args, **kwargs):
            pass
    
    class Counter(MetricStub): pass
    class Gauge(MetricStub): pass
    class Histogram(MetricStub): pass
    
    # Definir função stub para start_http_server
    def start_http_server(*args, **kwargs):
        logging.error("Não é possível iniciar servidor HTTP: biblioteca prometheus_client não está disponível.")
    
    # Definir REGISTRY stub
    class RegistryStub:
        def register(self, *args, **kwargs):
            pass
    REGISTRY = RegistryStub()

logger = logging.getLogger(__name__)

# Tentativa de importar notifier (ajustar caminhos se necessário)
try:
    from infrastructure.notifier import enviar_telegram
    NOTIFIER_AVAILABLE = True
except ImportError:
    NOTIFIER_AVAILABLE = False
    async def enviar_telegram(*args, **kwargs): # Stub function
        logger.error("Notifier module (enviar_telegram) not available.")

# --- Métricas Definidas ---
# Use try-except pass to avoid errors during tests when metrics are re-registered

def _register_metric(metric_class, name, documentation, labels=None, **extra_kwargs):
    """Helper para registrar métricas evitando ValueError se já existir."""
    if not PROMETHEUS_AVAILABLE:
        logger.warning(f"Não é possível registrar métrica {name}: biblioteca prometheus_client não está disponível.")
        # Criar e armazenar um stub para a métrica
        metric_stub = metric_class()
        globals()[name.upper()] = metric_stub
        return metric_stub
        
    try:
        kwargs = {"registry": REGISTRY}
        if labels:
            kwargs["labelnames"] = labels
        # Adicionar quaisquer outros kwargs passados (ex: buckets para Histogram)
        kwargs.update(extra_kwargs)
        metric = metric_class(name, documentation, **kwargs)
        globals()[name.upper()] = metric # Store metric in globals for easy access
        logger.debug(f"Métrica 	{name}	 registrada.")
        return metric
    except ValueError:
        logger.debug(f"Métrica 	{name}	 já registrada. Pulando.")
        # Return existing metric from registry if needed, or None/existing global
        return globals().get(name.upper())
    except Exception as e:
        logger.error(f"Erro inesperado ao registrar métrica {name}: {e}", exc_info=True)
        # Criar e armazenar um stub para a métrica em caso de erro
        metric_stub = metric_class()
        globals()[name.upper()] = metric_stub
        return metric_stub

# Métricas existentes
SIGNALS_PROCESSED_TOTAL = _register_metric(Counter, 
    "kr_signals_processed_total", 
    "Número total de sinais processados pelo signal_processor", 
    labels=["asset", "regime", "final_decision"] # Added regime and final_decision
)
ERRORS_TOTAL = _register_metric(Counter, 
    "kr_errors_total", 
    "Número total de erros encontrados em diferentes componentes", 
    labels=["component", "asset"] # Added asset
)
ACTIVE_CONNECTIONS = _register_metric(Gauge, 
    "kr_active_connections", 
    "Número atual de conexões WebSocket ativas com a Binance", 
    labels=["asset"]
)
LAST_SIGNAL_TIMESTAMP = _register_metric(Gauge, 
    "kr_last_signal_timestamp_seconds", 
    "Timestamp da última mensagem de sinal recebida", 
    labels=["asset"]
)

# Métricas Detalhadas (incluindo as do passo 004)
SIGNAL_PROCESSING_LATENCY = _register_metric(Histogram, # Renomeado de kripto_signal_latency_seconds para consistência
    "kr_signal_processing_latency_seconds", 
    "Latência do processamento de sinais na função analisar_sinal", 
    labels=["asset", "regime"], 
    # Buckets: 10ms, 50ms, 100ms, 250ms, 500ms, 1s, 2.5s, 5s, 10s
    buckets=[0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10]
)
AI_RESPONSE_TIME = _register_metric(Gauge, # Nova métrica: kripto_ai_response_time_seconds
    "kr_ai_response_time_seconds", 
    "Tempo de resposta do modelo de IA", 
    labels=["asset", "model_type"] # e.g., model_type="transformer", "lstm"
)
BINANCE_CONNECTION_STATUS = _register_metric(Gauge, # Nova métrica: kripto_binance_status
    "kr_binance_connection_status", 
    "Status da conexão com a API/Stream da Binance (1: online, 0: offline)", 
    labels=["connection_type"] # e.g., connection_type="websocket", "rest_api"
)
CIRCUIT_BREAKER_STATE = _register_metric(Gauge, 
    "kr_circuit_breaker_state", 
    "Estado atual do circuit breaker principal (0: closed, 1: open, 0.5: half-open)",
    labels=["breaker_name"]
)
CIRCUIT_BREAKER_FAILURES_TOTAL = _register_metric(Counter, 
    "kr_circuit_breaker_failures_total", 
    "Número total de falhas registradas pelo circuit breaker",
    labels=["breaker_name"]
)
CIRCUIT_BREAKER_SUCCESSES_TOTAL = _register_metric(Counter, 
    "kr_circuit_breaker_successes_total", 
    "Número total de sucessos registrados pelo circuit breaker",
    labels=["breaker_name"]
)
FALLBACK_ACTIVATIONS_TOTAL = _register_metric(Counter, # Métrica adicionada no fallback.py, registrada aqui para centralizar
    "kr_fallback_activations_total",
    "Número total de vezes que um circuit breaker foi ativado (estado OPEN)"
    # Sem labels aqui, pois o listener do fallback.py chama inc() diretamente
)
FALLBACK_MODEL_USED_TOTAL = _register_metric(Counter, 
    "kr_fallback_model_used_total", 
    "Número de vezes que o modelo fallback foi utilizado",
    labels=["asset", "reason"]
)
REGIME_IDENTIFIED_TOTAL = _register_metric(Counter, 
    "kr_regime_identified_total", 
    "Contagem de regimes de mercado identificados",
    labels=["asset", "regime"]
)
VALIDATOR_RESULTS_TOTAL = _register_metric(Counter, 
    "kr_validator_results_total", 
    "Resultado das validações executadas",
    labels=["asset", "validator_name", "result"] # result: "passed" or "failed"
)
GOVERNANCE_PREDICTION = _register_metric(Gauge, 
    "kr_governance_prediction_score", 
    "Score de predição da Governança Neural",
    labels=["asset", "model_id"]
)
NEWS_SCORE = _register_metric(Gauge, 
    "kr_news_provider_score", 
    "Score de sentimento das notícias recentes",
    labels=["asset"]
)
RL_ACTION_CHOSEN = _register_metric(Counter, 
    "kr_rl_action_chosen_total", 
    "Contagem de ações escolhidas pelo agente RL",
    labels=["asset", "action"] # action: 0 (HOLD), 1 (BUY), 2 (SELL)
)
# Nova métrica para status operacional dos componentes (Ponto 5 do plano de robustez)
COMPONENT_OPERATIONAL_STATUS = _register_metric(Gauge,
    "kr_component_operational_status",
    "Status operacional de componentes críticos (1: Real/Ativo, 0: Stub/Degradado/Inativo)",
    labels=["component_name", "asset"] # Asset pode ser "global" para componentes não específicos de ativo
)

# --- Funções de Atualização ---

def _get_metric(metric_name):
    """Helper para obter a métrica global com segurança."""
    metric = globals().get(metric_name.upper())
    if metric is None:
        logger.warning(f"Métrica {metric_name.upper()} não inicializada corretamente ou não encontrada.")
        # Criar um stub para a métrica se não existir
        if metric_name.upper().endswith('_TOTAL'):
            metric = Counter()
        elif metric_name.upper().startswith('LAST_') or metric_name.upper().endswith('_STATUS'):
            metric = Gauge()
        elif metric_name.upper().endswith('_LATENCY_SECONDS'):
            metric = Histogram()
        else:
            metric = Gauge()  # Default to Gauge for unknown metrics
        globals()[metric_name.upper()] = metric
    return metric

def inc_signals_processed(asset: str, regime: str, final_decision: str):
    """Incrementa o contador de sinais processados."""
    metric = _get_metric("SIGNALS_PROCESSED_TOTAL")
    if metric: metric.labels(asset=asset, regime=regime, final_decision=final_decision).inc()

def inc_errors(component: str, asset: str = "N/A"):
    """Incrementa o contador de erros."""
    metric = _get_metric("ERRORS_TOTAL")
    if metric: metric.labels(component=component, asset=asset).inc()

def set_active_connection(asset: str, status: bool):
    """Define o status da conexão WebSocket ativa."""
    # Deprecated in favor of set_binance_connection_status
    # metric = _get_metric("ACTIVE_CONNECTIONS")
    # if metric: metric.labels(asset=asset).set(1 if status else 0)
    set_binance_connection_status("websocket", status)

def set_binance_connection_status(connection_type: str, status: bool):
    """Define o status da conexão com a Binance (WebSocket ou REST API)."""
    metric = _get_metric("BINANCE_CONNECTION_STATUS")
    if metric: metric.labels(connection_type=connection_type).set(1 if status else 0)

def update_last_signal_timestamp(asset: str):
    """Atualiza o timestamp do último sinal recebido."""
    metric = _get_metric("LAST_SIGNAL_TIMESTAMP")
    if metric: metric.labels(asset=asset).set_to_current_time()

def observe_signal_processing_latency(asset: str, regime: str, duration: float):
    """Observa a latência do processamento de sinais."""
    metric = _get_metric("SIGNAL_PROCESSING_LATENCY")
    if metric: metric.labels(asset=asset, regime=regime).observe(duration)

def set_ai_response_time(asset: str, model_type: str, duration: float):
    """Define o tempo de resposta da IA."""
    metric = _get_metric("AI_RESPONSE_TIME")
    if metric: metric.labels(asset=asset, model_type=model_type).set(duration)

def update_circuit_breaker_state(breaker_name: str, state: str):
    """Atualiza o estado do circuit breaker."""
    metric = _get_metric("CIRCUIT_BREAKER_STATE")
    state_map = {"closed": 0, "open": 1, "half-open": 0.5}
    if metric: metric.labels(breaker_name=breaker_name).set(state_map.get(state.lower(), -1)) # Use lower() for safety

def inc_circuit_breaker_failures(breaker_name: str):
    """Incrementa falhas do circuit breaker."""
    metric = _get_metric("CIRCUIT_BREAKER_FAILURES_TOTAL")
    if metric: metric.labels(breaker_name=breaker_name).inc()

def inc_circuit_breaker_successes(breaker_name: str):
    """Incrementa sucessos do circuit breaker."""
    metric = _get_metric("CIRCUIT_BREAKER_SUCCESSES_TOTAL")
    if metric: metric.labels(breaker_name=breaker_name).inc()

# A métrica FALLBACK_ACTIVATIONS_TOTAL é incrementada diretamente no fallback.py
fallback_metric = _get_metric("FALLBACK_ACTIVATIONS_TOTAL") # Get the metric object for fallback.py

def inc_fallback_model_used(asset: str, reason: str):
    """Incrementa uso do modelo fallback."""
    metric = _get_metric("FALLBACK_MODEL_USED_TOTAL")
    if metric: metric.labels(asset=asset, reason=reason).inc()

def inc_regime_identified(asset: str, regime: str):
    """Incrementa contagem de regime identificado."""
    metric = _get_metric("REGIME_IDENTIFIED_TOTAL")
    if metric: metric.labels(asset=asset, regime=regime).inc()

def inc_validator_result(asset: str, validator_name: str, passed: bool):
    """Incrementa resultado de validador."""
    metric = _get_metric("VALIDATOR_RESULTS_TOTAL")
    result_label = "passed" if passed else "failed"
    if metric: metric.labels(asset=asset, validator_name=validator_name, result=result_label).inc()

def set_governance_prediction(asset: str, model_id: str, score: float):
    """Define o score de predição da governança."""
    metric = _get_metric("GOVERNANCE_PREDICTION")
    if metric: metric.labels(asset=asset, model_id=model_id).set(score)

def set_news_score(asset: str, score: float):
    """Define o score de notícias."""
    metric = _get_metric("NEWS_SCORE")
    if metric: metric.labels(asset=asset).set(score)

def inc_rl_action_chosen(asset: str, action: int):
    """Incrementa a contagem da ação RL escolhida."""
    metric = _get_metric("RL_ACTION_CHOSEN")
    action_map = {0: "hold", 1: "buy", 2: "sell"}
    action_label = action_map.get(action, "unknown")
    if metric: metric.labels(asset=asset, action=action_label).inc()

def set_component_operational_status(component_name: str, status: bool, asset: str = "global"):
    """Define o status operacional de um componente (1: Real/Ativo, 0: Stub/Degradado/Inativo)."""
    metric = _get_metric("COMPONENT_OPERATIONAL_STATUS")
    if metric: metric.labels(component_name=component_name, asset=asset).set(1 if status else 0)

# --- Função para Iniciar o Servidor HTTP ---

_server_started_flag = False

def start_metrics_server(port: int = 8000, addr: str = '0.0.0.0'):
    """Inicia o servidor HTTP para expor as métricas Prometheus."""
    if not PROMETHEUS_AVAILABLE:
        logger.error("Não é possível iniciar servidor de métricas: biblioteca prometheus_client não está disponível.")
        logger.error("Execute 'pip install prometheus_client' para habilitar métricas Prometheus.")
        return False
        
    global _server_started_flag
    try:
        if not _server_started_flag:
            start_http_server(port, addr=addr)
            _server_started_flag = True
            logger.info(f"Servidor de métricas Prometheus iniciado em http://{addr}:{port}")
            return True
        else:
             logger.info(f"Servidor de métricas Prometheus já iniciado.")
             return True
    except OSError as e:
        # Check if the error is 'Address already in use'
        if e.errno == 98: # errno.EADDRINUSE
             logger.warning(f"Servidor de métricas Prometheus na porta {port} já está em uso ou iniciado.")
             # Ensure the flag is set if the server is already running
             _server_started_flag = True
             return True
        else:
            logger.critical(f"Erro OSError CRÍTICO ao iniciar o servidor de métricas Prometheus na porta {port}: {e}")
            inc_errors("prometheus_exporter_startup")
            # --- Alerta Bloqueante --- 
            if NOTIFIER_AVAILABLE:
                try:
                    # Run alert in background to avoid blocking startup further
                    asyncio.create_task(enviar_telegram(f"🚨 ALERTA CRÍTICO: Falha ao iniciar Prometheus Exporter na porta {port}! Erro: {e}"))
                    logger.info("Tentativa de envio de alerta Telegram sobre falha do Prometheus Exporter.")
                except Exception as tg_e:
                    logger.error(f"Falha ao enviar alerta Telegram sobre falha do Prometheus Exporter: {tg_e}", exc_info=True)
            # -------------------------
            return False
    except Exception as e:
        logger.critical(f"Erro inesperado CRÍTICO ao iniciar o servidor de métricas Prometheus: {e}")
        inc_errors("prometheus_exporter_startup")
        # --- Alerta Bloqueante --- 
        if NOTIFIER_AVAILABLE:
            try:
                # Run alert in background
                asyncio.create_task(enviar_telegram(f"🚨 ALERTA CRÍTICO: Falha inesperada ao iniciar Prometheus Exporter! Erro: {e}"))
                logger.info("Tentativa de envio de alerta Telegram sobre falha do Prometheus Exporter.")
            except Exception as tg_e:
                logger.error(f"Falha ao enviar alerta Telegram sobre falha do Prometheus Exporter: {tg_e}", exc_info=True)
        # -------------------------
        return False

# Verificar se o PrometheusExporter está disponível
def is_operational():
    """Verifica se o PrometheusExporter está operacional."""
    return PROMETHEUS_AVAILABLE

if __name__ == '__main__':
    # Exemplo de uso e teste
    logging.basicConfig(level=logging.INFO)
    loop = asyncio.get_event_loop()
    start_metrics_server(8001) # Use a different port for direct testing

    # Simula algumas atualizações
    inc_signals_processed('BTCUSDT', 'TENDENCIA_ALTA', 'comprar')
    inc_signals_processed('ETHUSDT', 'LATERAL_BAIXA_VOL', 'manter')
    inc_errors('signal_processor', 'BTCUSDT')
    # set_active_connection('BTCUSDT', True) # Deprecated
    set_binance_connection_status('websocket', True)
    set_binance_connection_status('rest_api', True)
    update_last_signal_timestamp('BTCUSDT')
    observe_signal_processing_latency('BTCUSDT', 'TENDENCIA_ALTA', 0.15)
    set_ai_response_time('BTCUSDT', 'transformer', 0.08)
    update_circuit_breaker_state('websocket', 'closed')
    inc_circuit_breaker_failures('websocket')
    inc_fallback_model_used('BTCUSDT', 'primary_model_error')
    inc_regime_identified('BTCUSDT', 'TENDENCIA_ALTA')
    inc_validator_result('BTCUSDT', 'zonas_rejeicao', True)
    inc_validator_result('BTCUSDT', 'volume_profile', False)
    set_governance_prediction('BTCUSDT', 'model_v3', 0.75)
    set_news_score('BTCUSDT', 0.65)
    inc_rl_action_chosen('BTCUSDT', 1)
    set_binance_connection_status('websocket', False)

    logger.info("Métricas atualizadas. Servidor rodando em http://0.0.0.0:8001")
    # Mantém o script rodando para permitir o scraping
    try:
        # loop.run_forever() # run_forever is not ideal here, use sleep
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("Servidor de métricas encerrado.")
    finally:
        # Cleanup loop if needed, though not strictly necessary for this example
        pass
