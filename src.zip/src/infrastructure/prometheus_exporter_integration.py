#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de integração para o PrometheusExporter v2.

Este script cria links simbólicos e ajusta importações para garantir que
o sistema utilize a versão v2 do PrometheusExporter, compatível com Mac M1.
"""

import os
import sys
import logging
import platform
import importlib
import shutil
from pathlib import Path

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("prometheus_exporter_integration")

def is_mac_m1():
    """Verifica se o ambiente atual é um Mac M1 (ARM64)."""
    return platform.system() == "Darwin" and ("arm" in platform.machine().lower())

def criar_links_simbolicos():
    """
    Cria links simbólicos para garantir que o PrometheusExporter v2 seja encontrado
    corretamente pelo sistema.
    """
    # Obter diretório raiz do projeto
    try:
        # Tentar encontrar o diretório src
        src_dir = None
        for path in sys.path:
            if os.path.isdir(os.path.join(path, 'src')):
                src_dir = os.path.join(path, 'src')
                break
        
        if not src_dir:
            # Tentar encontrar no diretório atual
            current_dir = os.path.abspath(os.path.dirname(__file__))
            if os.path.isdir(os.path.join(current_dir, 'src')):
                src_dir = os.path.join(current_dir, 'src')
            elif os.path.isdir(os.path.join(current_dir, '..', 'src')):
                src_dir = os.path.join(current_dir, '..', 'src')
        
        if not src_dir:
            logger.error("Não foi possível encontrar o diretório 'src'")
            return False
        
        # Verificar e criar links para prometheus_exporter
        infrastructure_dir = os.path.join(src_dir, 'infrastructure')
        if not os.path.isdir(infrastructure_dir):
            os.makedirs(infrastructure_dir, exist_ok=True)
            logger.info(f"Diretório criado: {infrastructure_dir}")
        
        # Verificar se os arquivos existem
        prometheus_path = os.path.join(infrastructure_dir, 'prometheus_exporter.py')
        prometheus_v2_path = os.path.join(infrastructure_dir, 'prometheus_exporter_v2.py')
        
        # Criar backup do arquivo original
        if os.path.exists(prometheus_path):
            backup_path = os.path.join(infrastructure_dir, 'prometheus_exporter_backup.py')
            shutil.copy2(prometheus_path, backup_path)
            logger.info(f"Backup criado: {prometheus_path} -> {backup_path}")
        
        # Copiar o arquivo v2 para o arquivo principal
        if os.path.exists(prometheus_v2_path):
            shutil.copy2(prometheus_v2_path, prometheus_path)
            logger.info(f"Arquivo copiado: {prometheus_v2_path} -> {prometheus_path}")
            return True
        else:
            logger.error(f"Arquivo {prometheus_v2_path} não encontrado")
            return False
    except Exception as e:
        logger.error(f"Erro ao criar links simbólicos: {e}")
        return False

def corrigir_importacoes():
    """
    Corrige as importações para garantir que o PrometheusExporter v2 seja encontrado
    corretamente pelo sistema.
    """
    try:
        # Adicionar diretórios ao path
        current_dir = os.path.abspath(os.path.dirname(__file__))
        
        # Tentar encontrar o diretório raiz do projeto
        root_dir = current_dir
        while root_dir and not os.path.isdir(os.path.join(root_dir, 'src')):
            parent = os.path.dirname(root_dir)
            if parent == root_dir:  # Chegou à raiz do sistema
                root_dir = None
                break
            root_dir = parent
        
        if not root_dir:
            # Tentar encontrar no diretório atual
            if os.path.isdir(os.path.join(current_dir, 'src')):
                root_dir = current_dir
        
        if not root_dir:
            logger.error("Não foi possível encontrar o diretório raiz do projeto")
            return False
        
        # Adicionar diretórios ao path
        if root_dir not in sys.path:
            sys.path.insert(0, root_dir)
            logger.info(f"Adicionado ao path: {root_dir}")
        
        # Verificar se o módulo pode ser importado
        try:
            # Tentar importar prometheus_exporter
            importlib.import_module('src.infrastructure.prometheus_exporter')
            logger.info("Módulo src.infrastructure.prometheus_exporter importado com sucesso")
            return True
        except ImportError as e:
            logger.error(f"Módulo src.infrastructure.prometheus_exporter não disponível: {e}")
            return False
    except Exception as e:
        logger.error(f"Erro ao corrigir importações: {e}")
        return False

def main():
    """Função principal."""
    logger.info(f"Iniciando integração do PrometheusExporter v2 para Mac M1")
    logger.info(f"Ambiente: {'Mac M1' if is_mac_m1() else 'Outro'}")
    
    # Criar links simbólicos
    if criar_links_simbolicos():
        logger.info("Links simbólicos criados com sucesso")
    else:
        logger.warning("Falha ao criar links simbólicos")
    
    # Corrigir importações
    if corrigir_importacoes():
        logger.info("Importações corrigidas com sucesso")
    else:
        logger.warning("Falha ao corrigir importações")
    
    logger.info("Integração do PrometheusExporter v2 concluída")

if __name__ == "__main__":
    main()
