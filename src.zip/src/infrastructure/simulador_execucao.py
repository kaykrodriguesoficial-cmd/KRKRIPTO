# executors/simulador_execucao.py

import random
import time

def simular_execucao(preco_entrada, direcao, delay_ms=300, spread=0.05, volume=1.0):
    """
    Simula se uma operação teria sido executada com sucesso considerando delay, spread e volume.
    
    Args:
        preco_entrada (float): Preço desejado de entrada.
        direcao (str): "compra" ou "venda".
        delay_ms (int): Delay em milissegundos até a execução.
        spread (float): Valor do spread esperado (diferença de bid/ask).
        volume (float): Volume de ordem desejado.

    Returns:
        executado (bool): Se a operação foi executada com sucesso.
        preco_executado (float): Preço simulado de execução.
    """
    time.sleep(delay_ms / 1000.0)

    variacao = random.uniform(-spread, spread)
    if direcao == "compra":
        preco_executado = preco_entrada + variacao
    else:
        preco_executado = preco_entrada - variacao

    chance_execucao = max(0.5, 1.0 - abs(variacao) / spread)

    sucesso = random.random() < chance_execucao

    return sucesso, round(preco_executado, 2)
