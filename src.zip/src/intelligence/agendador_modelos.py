import time
from meta_avaliador_neural import avaliar_modelos

INTERVALO_MINUTOS = 5  # tempo entre avaliações
INTERVALO_SEGUNDOS = INTERVALO_MINUTOS * 60

print("⏱️ Iniciando agendador de avaliação neural...")

while True:
    try:
        print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Avaliando modelos...")
        estado = avaliar_modelos()
        print("Modelos avaliados com sucesso:")
        for modelo, info in estado.items():
            print(f"  - {modelo}: Fitness={info['fitness']}, Ativo={info['ativo']}")
    except Exception as e:
        print(f"❌ Erro na avaliação de modelos: {e}")

    time.sleep(INTERVALO_SEGUNDOS)
