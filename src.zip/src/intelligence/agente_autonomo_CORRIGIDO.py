
import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

from inteligencia.orquestradores.orquestrador_neural import orquestrador_neural, reforcar_ia
from inteligencia.memoria.memoria_performance import atualizar_memoria
from inteligencia.feedback_loop import rodar_feedback_loop
from inteligencia.mutacoes.mutacao_cerebral import tentar_mutacao
from executors.executor_contextual import executar_operacao_contextual
from inteligencia.log_por_ativo import registrar_log

CSV_PATH = "historico_sinais.csv"
fila_resultados_global = {}

def processar_sinal(df, ativo):
    try:
        if df.empty or len(df) < 10:
            registrar_log(ativo, "⚠️ DataFrame vazio ou insuficiente para sinal.", "agente_autonomo", "WARN")
            return {"status": "ignorado", "motivo": "dados insuficientes"}

        preco_entrada = df["close"].iloc[-1]
        timestamp = df.index[-1]
        hora_atual = datetime.now().hour

        try:
            score_final = df["score_final"].iloc[-1]
            fakeout = int(df["fakeout_detectado"].iloc[-1])
            probabilidade = df["probabilidade"].iloc[-1]
            pred_lstm = df["pred_lstm"].iloc[-1]
            direcao = df["direcao_hist"].iloc[-1]
            memoria_score = df["memoria_score"].iloc[-1]
            memoria_lucro = df["memoria_lucro"].iloc[-1]
            capital_disponivel = df["capital_disponivel"].iloc[-1]
            lucro_rolling = df["lucro_ultimos"].iloc[-1]
            prioridade = df["prioridade_ativo"].iloc[-1]
            book_imbalance = df["book_imbalance"].iloc[-1]
            zona_rejeicao = df["zona_rejeicao"].iloc[-1]
            contexto = df["contexto"].iloc[-1]
            score_orderflow = df["score_orderflow"].iloc[-1]
        except Exception as e:
            registrar_log(ativo, f"❌ Erro ao extrair variáveis do DataFrame: {e}", "agente_autonomo", "ERROR")
            return {"status": "erro", "motivo": str(e)}

        vetor_x = {
            "score": score_final,
            "probabilidade": probabilidade,
            "pred_lstm": pred_lstm,
            "direcao_hist": direcao,
            "memoria_score": memoria_score,
            "memoria_lucro": memoria_lucro,
            "capital_disponivel": capital_disponivel,
            "lucro_ultimos": lucro_rolling,
            "prioridade_ativo": prioridade,
            "fakeout_detectado": fakeout,
            "book_imbalance": book_imbalance,
            "zona_rejeicao": zona_rejeicao,
            "contexto": contexto,
            "score_orderflow": score_orderflow,
            "preco_sinal": preco_entrada,
            "timestamp_sinal": datetime.now().timestamp(),
        }

        decisao = orquestrador_neural(vetor_x, ativo)

        if decisao == 1:
            resultado_execucao = executar_operacao_contextual(ativo, score_final)
            registrar_log(ativo, f"🚀 SINAL EXECUTADO com score {score_final} | Execução: {resultado_execucao}", "agente_autonomo")
            fila_resultados_global.setdefault(ativo, []).append({
                "preco": preco_entrada,
                "timestamp": timestamp,
                "vetor_x": vetor_x
            })
        else:
            registrar_log(ativo, f"🛑 SINAL BLOQUEADO | Score: {score_final} | Prob: {probabilidade}", "agente_autonomo")

        # Reforço de IA e mutação após execução
        atualizar_memoria(ativo, hora_atual, score_final, 1 if decisao == 1 else 0)
        reforcar_ia(vetor_x, "compra" if decisao == 1 else "nada")
        rodar_feedback_loop(ativo)
        tentar_mutacao(ativo)

        return {"status": "ok", "decisao": decisao}

    except Exception as e:
        registrar_log(ativo, f"❌ Erro em processar_sinal: {e}", "agente_autonomo", "ERROR")
        return {"status": "erro", "motivo": str(e)}
