
def calcular_pesos_dinamicos(regime, probabilidade, volatilidade=1.0):
    '''
    Define pesos adaptativos para cálculo do score final com base em regime de mercado,
    confiança do modelo e (opcionalmente) volatilidade recente.

    Retorna:
    - peso_score, peso_probabilidade, peso_fakeout
    '''
    # Peso base do score pode aumentar em regimes de tendência
    if regime in ['tendencia_alta', 'tendencia_baixa']:
        peso_score = 1.3
    elif regime == 'consolidacao':
        peso_score = 1.0
    else:
        peso_score = 0.9

    # Peso da probabilidade cresce com confiança
    if probabilidade > 0.85:
        peso_probabilidade = 1.3
    elif probabilidade > 0.65:
        peso_probabilidade = 1.1
    else:
        peso_probabilidade = 0.9

    # Peso de fakeout se adapta à volatilidade
    if volatilidade > 2.0:
        peso_fakeout = 0.7
    elif volatilidade < 1.0:
        peso_fakeout = 1.2
    else:
        peso_fakeout = 1.0

    return peso_score, peso_probabilidade, peso_fakeout
