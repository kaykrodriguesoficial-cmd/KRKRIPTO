# src/intelligence/ajustadores/heuristicas_controller.py
import pandas as pd
import logging

logger = logging.getLogger("kr_kripto_heuristics")

def ajustar_heuristicas(ativo: str, df: pd.DataFrame, indice_atual: int, score: float, classe: str, config_heuristics: dict):
    logger.debug(f"[{ativo}] ajustar_heuristicas (stub) chamado. Retornando score, classe e probabilidade 0.5.")
    # Retorna os valores de entrada para score e classe, e uma probabilidade fixa para o stub
    return score, classe, 0.5

