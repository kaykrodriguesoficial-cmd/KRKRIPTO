
import json
from collections import defaultdict

# Tabela de Q-valores por contexto + modelo
Q_table = defaultdict(lambda: defaultdict(float))
alpha = 0.1  # taxa de aprendizado
gamma = 0.95  # fator de desconto

def contexto_para_chave(contexto):
    """
    Gera uma chave de contexto discretizada.
    """
    regime = contexto.get("regime", "INDEFINIDO")
    score = round(contexto.get("score", 0.5), 1)
    entropia = round(contexto.get("entropia", 0.5), 1)
    return f"{regime}|score:{score}|entropia:{entropia}"

def atualizar_recompensa(contexto, modelo, recompensa):
    """
    Atualiza o Q-valor do modelo no contexto dado com base na recompensa.
    """
    chave = contexto_para_chave(contexto)
    q_atual = Q_table[chave][modelo]
    Q_table[chave][modelo] = q_atual + alpha * (recompensa - q_atual)

def escolher_modelo_otimizado(contexto):
    """
    Retorna o modelo com maior Q-valor para o contexto atual.
    """
    chave = contexto_para_chave(contexto)
    modelos = Q_table[chave]
    if modelos:
        return max(modelos, key=modelos.get)
    return "Regras"  # fallback padrão

def exportar_qtable_json(path):
    """
    Exporta Q-table como JSON.
    """
    with open(path, "w") as f:
        json.dump(Q_table, f, indent=2)

def importar_qtable_json(path):
    """
    Importa Q-table de arquivo JSON.
    """
    global Q_table
    with open(path, "r") as f:
        dados = json.load(f)
    Q_table = defaultdict(lambda: defaultdict(float), {k: defaultdict(float, v) for k, v in dados.items()})
