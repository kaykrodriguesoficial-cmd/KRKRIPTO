
import json
from collections import defaultdict
import os

Q_table = defaultdict(lambda: defaultdict(float))
alpha = 0.1
gamma = 0.95
QTABLE_PATH = "/mnt/data/qtable_tatica_estrategica.json"

def contexto_para_chave(contexto):
    regime = contexto.get("regime", "INDEFINIDO")
    score = round(contexto.get("score", 0.5), 1)
    entropia = round(contexto.get("entropia", 0.5), 1)
    return f"{regime}|score:{score}|entropia:{entropia}"

def salvar_qtable():
    with open(QTABLE_PATH, "w") as f:
        json.dump(Q_table, f, indent=2)

def carregar_qtable():
    global Q_table
    if os.path.exists(QTABLE_PATH):
        with open(QTABLE_PATH, "r") as f:
            dados = json.load(f)
        Q_table = defaultdict(lambda: defaultdict(float), {
            k: defaultdict(float, v) for k, v in dados.items()
        })

def atualizar_recompensa(contexto, modelo, recompensa):
    chave = contexto_para_chave(contexto)
    q_atual = Q_table[chave][modelo]
    Q_table[chave][modelo] = q_atual + alpha * (recompensa - q_atual)
    salvar_qtable()

def escolher_modelo_otimizado(contexto):
    chave = contexto_para_chave(contexto)
    modelos = Q_table[chave]
    if modelos:
        return max(modelos, key=modelos.get)
    return "Regras"

# Auto carregar ao importar
carregar_qtable()
