
import os
import joblib
import numpy as np
import pandas as pd
from datetime import datetime
from sklearn.metrics import accuracy_score
from sklearn.neural_network import MLPClassifier
from inteligencia.log_por_ativo import registrar_log

PASTA_MODELOS = "modelos"
HISTORICO = "historico_sinais.csv"

def avaliar_cerebros():
    try:
        df = pd.read_csv(HISTORICO)
        df = df[df["classe_prevista"].isin(["compra", "venda"])]
        df = df[df["resultado_5_candles"].notnull()]
        df["classe_real"] = df["resultado_5_candles"].apply(lambda x: "compra" if x > 0 else "venda")

        avaliacoes = {}
        for cerebro in ["soberana", "lstm", "heuristica"]:
            col = f"classe_{cerebro}"
            if col in df.columns:
                acc = accuracy_score(df["classe_real"], df[col])
                avaliacoes[cerebro] = round(acc, 4)
                registrar_log("GERAL", f"🎯 IA {cerebro} com acurácia: {acc}", "auto_evolucao")

        return {"status": "ok", "avaliacoes": avaliacoes}

    except Exception as e:
        registrar_log("GERAL", f"❌ Erro ao avaliar cérebros: {e}", "auto_evolucao", "ERROR")
        return {"status": "erro", "motivo": str(e)}

def mutar_modelo(base_path):
    try:
        modelo = joblib.load(base_path)
        if not isinstance(modelo, MLPClassifier):
            registrar_log("GERAL", "❌ Modelo não é MLPClassifier. Mutação abortada.", "auto_evolucao", "ERROR")
            return None

        novo = MLPClassifier(hidden_layer_sizes=(64, 64), max_iter=500)
        novo.coefs_ = [np.copy(w + np.random.normal(0, 0.05, w.shape)) for w in modelo.coefs_]
        novo.intercepts_ = [np.copy(b + np.random.normal(0, 0.05, b.shape)) for b in modelo.intercepts_]

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        nome_novo = os.path.join(PASTA_MODELOS, f"mutacao_{timestamp}.pkl")
        joblib.dump(novo, nome_novo)

        registrar_log("GERAL", f"🧬 Mutação gerada e salva como: {nome_novo}", "auto_evolucao")
        return novo

    except Exception as e:
        registrar_log("GERAL", f"❌ Erro ao mutar modelo: {e}", "auto_evolucao", "ERROR")
        return None
