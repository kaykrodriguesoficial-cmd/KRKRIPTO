def __init__(self, config, dataframes=None):
    self.config = config
    self.dataframes = dataframes or {}
