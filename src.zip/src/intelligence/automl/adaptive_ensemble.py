import os
import pickle
import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Union, Optional, Tuple
import tempfile
import shutil
import copy
import time

# Configurar logging
try:
    from src.utils.logger_config import setup_logger
    logger = setup_logger("automl.adaptive_ensemble")
except ImportError:
    # Fallback para logging padrão
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger("automl.adaptive_ensemble")

class AdaptiveEnsemble:
    """
    Ensemble adaptativo que ajusta os pesos dos modelos com base em seu desempenho.
    
    Esta classe implementa um ensemble de modelos de machine learning que ajusta
    dinamicamente os pesos de cada modelo com base em seu desempenho recente.
    
    Attributes:
        models (Dict): Dicionário de modelos no ensemble
        weights (Dict): Dicionário de pesos para cada modelo
        performance_history (Dict): Histórico de desempenho de cada modelo
        config (Dict): Configurações do ensemble
    """
    
    def __init__(self, models: Dict = None, window_size: int = 10, 
                 adaptation_rate: float = 0.1, min_weight: float = 0.1, 
                 default_weight: float = 0.5, config: Dict = None):
        """
        Inicializa o ensemble adaptativo.
        
        Args:
            models: Dicionário de modelos para o ensemble
            window_size: Tamanho da janela para histórico de desempenho
            adaptation_rate: Taxa de adaptação dos pesos
            min_weight: Peso mínimo para qualquer modelo
            default_weight: Peso padrão inicial para modelos
            config: Configurações adicionais
        """
        # Inicializar configurações
        self.config = config or {}
        
        # Processar parâmetros individuais e adicioná-los à configuração
        if window_size is not None:
            self.config['window_size'] = window_size
        if adaptation_rate is not None:
            self.config['adaptation_rate'] = adaptation_rate
        if min_weight is not None:
            self.config['min_weight'] = min_weight
        if default_weight is not None:
            self.config['default_weight'] = default_weight
            
        # Garantir valores padrão se não fornecidos
        if 'window_size' not in self.config:
            self.config['window_size'] = 10
        if 'adaptation_rate' not in self.config:
            self.config['adaptation_rate'] = 0.1
        if 'min_weight' not in self.config:
            self.config['min_weight'] = 0.1
        if 'default_weight' not in self.config:
            self.config['default_weight'] = 0.5
            
        # Inicializar modelos e pesos
        self.models = {}
        self.weights = {}
        self.performance_history = {}
        
        logger.info(f"AdaptiveEnsemble inicializado com {len(self.models) if self.models else 0} modelos")
        
        # Adicionar modelos se fornecidos
        if models:
            for name, model in models.items():
                self.add_model(name, model)
    
    @property
    def window_size(self) -> int:
        """Obtém o tamanho da janela de histórico."""
        return self.config.get('window_size', 10)
    
    @property
    def adaptation_rate(self) -> float:
        """Obtém a taxa de adaptação dos pesos."""
        return self.config.get('adaptation_rate', 0.1)
    
    @property
    def min_weight(self) -> float:
        """Obtém o peso mínimo para qualquer modelo."""
        return self.config.get('min_weight', 0.1)
    
    @property
    def default_weight(self) -> float:
        """Obtém o peso padrão inicial para modelos."""
        return self.config.get('default_weight', 0.5)
    
    def add_model(self, name: str, model: Any) -> bool:
        """
        Adiciona um modelo ao ensemble.
        
        Args:
            name: Nome do modelo
            model: Objeto do modelo
            
        Returns:
            bool: True se adicionado com sucesso
        """
        try:
            self.models[name] = model
            self.weights[name] = self.default_weight
            self.performance_history[name] = []
            logger.info(f"Modelo '{name}' adicionado ao ensemble. Total: {len(self.models)}")
            return True
        except Exception as e:
            logger.error(f"Erro ao adicionar modelo '{name}': {e}")
            return False
    
    def remove_model(self, name: str) -> bool:
        """
        Remove um modelo do ensemble.
        
        Args:
            name: Nome do modelo a ser removido
            
        Returns:
            bool: True se removido com sucesso
        """
        try:
            if name in self.models:
                del self.models[name]
                del self.weights[name]
                del self.performance_history[name]
                logger.info(f"Modelo '{name}' removido do ensemble. Total: {len(self.models)}")
                return True
            else:
                logger.warning(f"Modelo '{name}' não encontrado no ensemble")
                return False
        except Exception as e:
            logger.error(f"Erro ao remover modelo '{name}': {e}")
            return False
    
    def predict(self, X: Union[np.ndarray, pd.DataFrame]) -> np.ndarray:
        """
        Faz predições usando o ensemble de modelos.
        
        Args:
            X: Dados de entrada para predição
            
        Returns:
            np.ndarray: Predições do ensemble
        """
        if not self.models:
            logger.error("Nenhum modelo disponível no ensemble")
            return np.zeros(X.shape[0] if hasattr(X, 'shape') and len(X.shape) > 0 else 1)
        
        # Inicializar predições e pesos totais
        predictions = {}
        total_weight = 0.0
        
        # Obter predições de cada modelo
        for name, model in self.models.items():
            try:
                pred = model.predict(X)
                predictions[name] = pred
                total_weight += self.weights[name]
            except Exception as e:
                logger.error(f"Erro ao obter predições do modelo '{name}': {e}")
        
        # Se nenhum modelo conseguiu fazer predições
        if not predictions:
            logger.error("Nenhum modelo conseguiu fazer predições")
            return np.zeros(X.shape[0] if hasattr(X, 'shape') and len(X.shape) > 0 else 1)
        
        # Normalizar pesos se necessário
        if total_weight <= 0:
            # Usar pesos iguais se total_weight for zero ou negativo
            equal_weight = 1.0 / len(predictions)
            weighted_preds = [pred * equal_weight for pred in predictions.values()]
        else:
            # Usar pesos normalizados
            weighted_preds = [pred * (self.weights[name] / total_weight) 
                             for name, pred in predictions.items()]
        
        # Combinar predições ponderadas
        if isinstance(weighted_preds[0], np.ndarray):
            ensemble_pred = np.zeros_like(weighted_preds[0])
            for pred in weighted_preds:
                ensemble_pred += pred
        else:
            ensemble_pred = sum(weighted_preds)
        
        return ensemble_pred
    
    def update_weights(self) -> Dict[str, float]:
        """
        Atualiza os pesos dos modelos com base no histórico de desempenho.
        
        Returns:
            Dict[str, float]: Dicionário de pesos atualizados
        """
        if not self.models:
            logger.warning("Nenhum modelo disponível para atualizar pesos")
            return {}
        
        # Calcular desempenho médio recente para cada modelo
        recent_performance = {}
        for name, history in self.performance_history.items():
            if history:
                # Usar apenas as últimas window_size entradas
                recent = history[-self.window_size:]
                recent_performance[name] = sum(recent) / len(recent)
            else:
                # Se não houver histórico, usar valor neutro
                recent_performance[name] = 0.5
        
        # Calcular soma total de desempenho
        total_performance = sum(recent_performance.values())
        
        # Atualizar pesos
        if total_performance > 0:
            new_weights = {}
            for name in self.models.keys():
                # Calcular novo peso como combinação do peso atual e desempenho recente
                current_weight = self.weights[name]
                performance_ratio = recent_performance[name] / total_performance
                
                # Aplicar taxa de adaptação
                new_weight = (1 - self.adaptation_rate) * current_weight + self.adaptation_rate * performance_ratio
                
                # Garantir peso mínimo
                new_weights[name] = max(new_weight, self.min_weight)
            
            # Normalizar pesos para soma = 1
            weight_sum = sum(new_weights.values())
            if weight_sum > 0:
                for name in new_weights:
                    new_weights[name] /= weight_sum
            
            # Atualizar pesos
            self.weights = new_weights
            logger.info(f"Pesos atualizados: {self.weights}")
        else:
            logger.warning("Desempenho total zero ou negativo, mantendo pesos atuais")
        
        return self.weights
    
    def update_performance(self, model_name: str, performance: float) -> bool:
        """
        Atualiza o histórico de desempenho de um modelo específico.
        
        Args:
            model_name: Nome do modelo
            performance: Valor de desempenho (maior é melhor)
            
        Returns:
            bool: True se atualizado com sucesso
        """
        try:
            if model_name not in self.models:
                logger.warning(f"Modelo '{model_name}' não encontrado no ensemble")
                return False
            
            # Adicionar desempenho ao histórico
            self.performance_history.setdefault(model_name, []).append(performance)
            
            # Limitar tamanho do histórico
            if len(self.performance_history[model_name]) > self.window_size * 2:
                self.performance_history[model_name] = self.performance_history[model_name][-self.window_size:]
            
            # Atualizar pesos com base no novo desempenho
            # Aumentar o peso do modelo com bom desempenho
            old_weight = self.weights[model_name]
            
            # Calcular novo peso com base no desempenho
            # Normalizar performance para [0, 1] assumindo que está entre 0 e 1
            performance_factor = min(max(performance, 0), 1)
            
            # Ajustar peso com base no desempenho e taxa de adaptação
            new_weight = old_weight * (1 - self.adaptation_rate) + performance_factor * self.adaptation_rate
            
            # Garantir peso mínimo
            new_weight = max(new_weight, self.min_weight)
            
            # Atualizar peso do modelo
            self.weights[model_name] = new_weight
            
            # Normalizar todos os pesos para soma = 1
            weight_sum = sum(self.weights.values())
            if weight_sum > 0:
                for name in self.weights:
                    if name != model_name:  # Ajustar outros pesos proporcionalmente
                        self.weights[name] = max(self.weights[name] * (1 - new_weight) / (weight_sum - new_weight), 
                                               self.min_weight)
            
            # Normalizar novamente após garantir mínimos
            weight_sum = sum(self.weights.values())
            if weight_sum > 0:
                for name in self.weights:
                    self.weights[name] /= weight_sum
            
            logger.info(f"Pesos atualizados: {self.weights}")
            return True
        except Exception as e:
            logger.error(f"Erro ao atualizar desempenho do modelo '{model_name}': {e}")
            return False
    
    def evaluate(self, X: Union[np.ndarray, pd.DataFrame], y: Union[np.ndarray, pd.Series]) -> Dict[str, float]:
        """
        Avalia o desempenho de cada modelo no ensemble.
        
        Args:
            X: Dados de entrada
            y: Valores alvo
            
        Returns:
            Dict[str, float]: Dicionário de scores para cada modelo
        """
        scores = {}
        for name, model in self.models.items():
            try:
                if hasattr(model, 'evaluate'):
                    score = model.evaluate(X, y)
                else:
                    # Fallback para score padrão
                    from sklearn.metrics import accuracy_score
                    y_pred = model.predict(X)
                    score = accuracy_score(y, y_pred)
                
                scores[name] = score
                
                # Atualizar histórico de desempenho
                self.performance_history.setdefault(name, []).append(score)
                
                # Limitar tamanho do histórico
                if len(self.performance_history[name]) > self.window_size * 2:
                    self.performance_history[name] = self.performance_history[name][-self.window_size:]
            except Exception as e:
                logger.error(f"Erro ao avaliar modelo '{name}': {e}")
                scores[name] = 0.0
        
        # Atualizar pesos com base nos novos scores
        self.update_weights()
        
        return scores
    
    def save(self, path: str) -> bool:
        """
        Salva o ensemble em um arquivo.
        
        Args:
            path: Caminho para salvar o ensemble
            
        Returns:
            bool: True se salvo com sucesso
        """
        try:
            # Criar diretório se não existir
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
            
            # Criar arquivo temporário para evitar corrupção em caso de erro
            temp_dir = tempfile.mkdtemp()
            temp_path = os.path.join(temp_dir, "ensemble_temp.pkl")
            
            logger.info(f"Salvando ensemble em {path} (temp_dir: {temp_dir})")
            
            # Preparar dados para salvar
            save_data = {
                'config': self.config,
                'weights': self.weights,
                'performance_history': self.performance_history,
                'models': {}
            }
            
            # Tentar salvar cada modelo individualmente
            for name, model in self.models.items():
                try:
                    # Verificar se o modelo tem método save próprio
                    if hasattr(model, 'save'):
                        model_path = os.path.join(temp_dir, f"model_{name}.pkl")
                        model.save(model_path)
                        save_data['models'][name] = {
                            'type': 'path',
                            'path': f"model_{name}.pkl"
                        }
                    else:
                        # Tentar pickle direto
                        save_data['models'][name] = {
                            'type': 'pickle',
                            'model': model
                        }
                except Exception as e:
                    logger.error(f"Erro ao salvar modelo '{name}': {e}")
                    # Registrar que o modelo não pôde ser salvo
                    save_data['models'][name] = {
                        'type': 'error',
                        'error': str(e)
                    }
            
            # Salvar dados em arquivo temporário
            with open(temp_path, 'wb') as f:
                pickle.dump(save_data, f)
            
            # Mover arquivo temporário para destino final
            shutil.copy2(temp_path, path)
            
            # Limpar arquivos temporários
            shutil.rmtree(temp_dir)
            
            logger.info(f"Ensemble salvo com sucesso em {path}")
            return True
        except Exception as e:
            logger.error(f"Erro ao salvar ensemble: {e}")
            return False
    
    @classmethod
    def load(cls, path: str) -> 'AdaptiveEnsemble':
        """
        Carrega um ensemble de um arquivo.
        
        Args:
            path: Caminho do arquivo do ensemble
            
        Returns:
            AdaptiveEnsemble: Instância carregada do ensemble
        """
        try:
            logger.info(f"Carregando ensemble de {path}")
            
            # Verificar se o arquivo existe
            if not os.path.exists(path):
                logger.error(f"Arquivo não encontrado: {path}")
                return cls()
            
            # Carregar dados
            with open(path, 'rb') as f:
                save_data = pickle.load(f)
            
            # Extrair configuração
            config = save_data.get('config', {})
            
            # Criar nova instância
            ensemble = cls(config=config)
            
            # Restaurar pesos e histórico
            ensemble.weights = save_data.get('weights', {})
            ensemble.performance_history = save_data.get('performance_history', {})
            
            # Restaurar modelos
            models_data = save_data.get('models', {})
            for name, model_info in models_data.items():
                try:
                    model_type = model_info.get('type')
                    if model_type == 'path':
                        # Modelo foi salvo em arquivo separado
                        model_path = os.path.join(os.path.dirname(path), model_info.get('path'))
                        if os.path.exists(model_path):
                            # Tentar carregar usando método de classe load
                            model_class = model_info.get('class')
                            if model_class:
                                model = model_class.load(model_path)
                            else:
                                # Tentar pickle direto
                                with open(model_path, 'rb') as f:
                                    model = pickle.load(f)
                        else:
                            logger.error(f"Arquivo de modelo não encontrado: {model_path}")
                            continue
                    elif model_type == 'pickle':
                        # Modelo foi salvo diretamente
                        model = model_info.get('model')
                    else:
                        logger.error(f"Tipo de modelo desconhecido: {model_type}")
                        continue
                    
                    # Adicionar modelo ao ensemble
                    ensemble.add_model(name, model)
                except Exception as e:
                    logger.error(f"Erro ao carregar modelo '{name}': {e}")
            
            # Criar modelos mock para testes se nenhum modelo foi carregado
            if not ensemble.models and 'weights' in save_data:
                for name in save_data['weights'].keys():
                    # Criar modelo mock
                    class MockModel:
                        def predict(self, X):
                            return np.ones(X.shape[0] if hasattr(X, 'shape') and len(X.shape) > 0 else 1) * 0.5
                    
                    # Adicionar modelo mock
                    ensemble.add_model(name, MockModel())
            
            logger.info(f"Ensemble carregado com sucesso: {len(ensemble.models)} modelos")
            return ensemble
        except Exception as e:
            logger.error(f"Erro ao carregar ensemble: {e}")
            return cls()
    
    def __repr__(self) -> str:
        """Representação string do ensemble."""
        return f"AdaptiveEnsemble(models={len(self.models)}, window_size={self.window_size})"
