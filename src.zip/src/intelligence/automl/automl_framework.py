"""
AutoML Framework - Componentes Principais
=========================================

Este módulo implementa os componentes principais do framework AutoML:
- AutoMLOptimizer: Otimização de hiperparâmetros com Optuna
- ModelDistiller: Destilação de conhecimento para modelos mais leves
- AdaptiveEnsemble: Ensemble adaptativo com pesos dinâmicos

Autor: Manus AI
Data: Abril 2025
Versão: 1.0.0
"""

import os
import json
import logging
import numpy as np
import pandas as pd
import optuna
from datetime import datetime
from typing import Dict, List, Tuple, Callable, Any, Optional, Union

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler('automl.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('automl_framework')

class AutoMLOptimizer:
    """
    Otimizador de hiperparâmetros baseado em Optuna para modelos de IA.
    
    Esta classe implementa um framework para otimização automática de 
    hiperparâmetros de modelos de machine learning usando Optuna.
    
    Attributes:
        model_type (str): Tipo de modelo a ser otimizado
        data_loader (Callable): Função para carregar dados de treinamento e teste
        model_builder (Callable): Função para construir o modelo com parâmetros específicos
        model_evaluator (Callable): Função para avaliar o modelo
        param_space (Dict): Espaço de parâmetros para otimização
        n_trials (int): Número de tentativas para otimização
        study_name (str): Nome do estudo Optuna
        direction (str): Direção da otimização ('minimize' ou 'maximize')
        best_params (Dict): Melhores parâmetros encontrados
        best_model: Melhor modelo treinado
        best_score (float): Melhor pontuação obtida
    """
    
    def __init__(
        self,
        model_type: str,
        data_loader: Callable,
        model_builder: Callable,
        model_evaluator: Callable,
        param_space: Dict,
        n_trials: int = 50,
        study_name: Optional[str] = None,
        direction: str = 'maximize',
        timeout: Optional[int] = None
    ):
        """
        Inicializa o otimizador AutoML.
        
        Args:
            model_type: Tipo de modelo a ser otimizado
            data_loader: Função para carregar dados de treinamento e teste
            model_builder: Função para construir o modelo com parâmetros específicos
            model_evaluator: Função para avaliar o modelo
            param_space: Espaço de parâmetros para otimização
            n_trials: Número de tentativas para otimização
            study_name: Nome do estudo Optuna
            direction: Direção da otimização ('minimize' ou 'maximize')
            timeout: Tempo limite em segundos para otimização
        """
        self.model_type = model_type
        self.data_loader = data_loader
        self.model_builder = model_builder
        self.model_evaluator = model_evaluator
        self.param_space = param_space
        self.n_trials = n_trials
        self.study_name = study_name or f"automl_{model_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.direction = direction
        self.timeout = timeout
        self.best_params = None
        self.best_model = None
        self.best_score = None
        
        # Criar estudo Optuna
        self.study = optuna.create_study(
            study_name=self.study_name,
            direction=self.direction
        )
        
        logger.info(f"Inicializado AutoMLOptimizer para modelo {model_type}")
        logger.info(f"Espaço de parâmetros: {param_space}")
    
    def _suggest_params(self, trial: optuna.Trial) -> Dict:
        """
        Sugere parâmetros para uma tentativa específica.
        
        Args:
            trial: Objeto Trial do Optuna
            
        Returns:
            Dicionário com parâmetros sugeridos
        """
        params = {}
        
        for param_name, param_config in self.param_space.items():
            param_type = param_config.get('type', 'float')
            
            if param_type == 'categorical':
                params[param_name] = trial.suggest_categorical(
                    param_name, 
                    param_config.get('values', [])
                )
            elif param_type == 'float':
                params[param_name] = trial.suggest_float(
                    param_name,
                    param_config.get('low', 0.0),
                    param_config.get('high', 1.0),
                    log=param_config.get('log', False)
                )
            elif param_type == 'int':
                params[param_name] = trial.suggest_int(
                    param_name,
                    param_config.get('low', 1),
                    param_config.get('high', 10),
                    step=param_config.get('step', 1),
                    log=param_config.get('log', False)
                )
        
        return params
    
    def _objective(self, trial: optuna.Trial) -> float:
        """
        Função objetivo para otimização.
        
        Args:
            trial: Objeto Trial do Optuna
            
        Returns:
            Pontuação de avaliação do modelo
        """
        # Sugerir parâmetros
        params = self._suggest_params(trial)
        
        # Carregar dados
        train_data, test_data = self.data_loader()
        
        # Construir modelo
        model = self.model_builder(params)
        
        # Avaliar modelo
        score = self.model_evaluator(model, train_data, test_data, trial=trial)
        
        return score
    
    def optimize(self) -> Dict:
        """
        Executa a otimização de hiperparâmetros.
        
        Returns:
            Dicionário com os melhores parâmetros encontrados
        """
        logger.info(f"Iniciando otimização para {self.model_type} com {self.n_trials} tentativas")
        
        # Executar otimização
        self.study.optimize(
            self._objective, 
            n_trials=self.n_trials,
            timeout=self.timeout
        )
        
        # Armazenar melhores parâmetros
        self.best_params = self.study.best_params
        self.best_score = self.study.best_value
        
        logger.info(f"Otimização concluída. Melhor pontuação: {self.best_score}")
        logger.info(f"Melhores parâmetros: {self.best_params}")
        
        # Treinar modelo final com os melhores parâmetros
        train_data, test_data = self.data_loader()
        self.best_model = self.model_builder(self.best_params)
        final_score = self.model_evaluator(self.best_model, train_data, test_data)
        
        logger.info(f"Modelo final treinado. Pontuação: {final_score}")
        
        return self.best_params
    
    def save_results(self, output_dir: str) -> str:
        """
        Salva os resultados da otimização.
        
        Args:
            output_dir: Diretório para salvar os resultados
            
        Returns:
            Caminho para o arquivo de resultados
        """
        os.makedirs(output_dir, exist_ok=True)
        
        # Salvar parâmetros
        params_file = os.path.join(output_dir, f"{self.model_type}_best_params.json")
        with open(params_file, 'w') as f:
            json.dump(self.best_params, f, indent=2)
        
        # Salvar histórico de tentativas
        trials_file = os.path.join(output_dir, f"{self.model_type}_trials.csv")
        trials_df = self.study.trials_dataframe()
        trials_df.to_csv(trials_file, index=False)
        
        # Salvar gráficos de importância
        try:
            import matplotlib.pyplot as plt
            from optuna.visualization import plot_param_importances, plot_optimization_history
            
            # Importância dos parâmetros
            fig = plot_param_importances(self.study)
            fig.write_image(os.path.join(output_dir, f"{self.model_type}_param_importance.png"))
            
            # Histórico de otimização
            fig = plot_optimization_history(self.study)
            fig.write_image(os.path.join(output_dir, f"{self.model_type}_optimization_history.png"))
        except ImportError:
            logger.warning("Matplotlib ou plotly não disponíveis. Gráficos não serão salvos.")
        
        logger.info(f"Resultados salvos em {output_dir}")
        
        return params_file


class ModelDistiller:
    """
    Implementa técnicas de destilação de conhecimento para criar modelos mais leves.
    
    A destilação de conhecimento é uma técnica onde um modelo menor (aluno) é treinado
    para imitar o comportamento de um modelo maior (professor), resultando em modelos
    mais leves e rápidos com desempenho similar.
    
    Attributes:
        teacher_model: Modelo professor (maior e mais complexo)
        student_builder (Callable): Função para construir o modelo aluno
        data_loader (Callable): Função para carregar dados de treinamento
        loss_fn (Callable): Função de perda para destilação
        temperature (float): Temperatura para suavização de softmax
        alpha (float): Peso para balancear perda de destilação e perda original
        student_model: Modelo aluno treinado
    """
    
    def __init__(
        self,
        teacher_model,
        student_builder: Callable,
        data_loader: Callable,
        loss_fn: Callable,
        temperature: float = 3.0,
        alpha: float = 0.5
    ):
        """
        Inicializa o destilador de modelos.
        
        Args:
            teacher_model: Modelo professor (maior e mais complexo)
            student_builder: Função para construir o modelo aluno
            data_loader: Função para carregar dados de treinamento
            loss_fn: Função de perda para destilação
            temperature: Temperatura para suavização de softmax
            alpha: Peso para balancear perda de destilação e perda original
        """
        self.teacher_model = teacher_model
        self.student_builder = student_builder
        self.data_loader = data_loader
        self.loss_fn = loss_fn
        self.temperature = temperature
        self.alpha = alpha
        self.student_model = None
        
        logger.info("Inicializado ModelDistiller")
        logger.info(f"Temperatura: {temperature}, Alpha: {alpha}")
    
    def distill(self, epochs: int = 50, batch_size: int = 32, **kwargs) -> Any:
        """
        Executa o processo de destilação de conhecimento.
        
        Args:
            epochs: Número de épocas para treinamento
            batch_size: Tamanho do lote para treinamento
            **kwargs: Argumentos adicionais para o treinamento
            
        Returns:
            Modelo aluno treinado
        """
        logger.info(f"Iniciando destilação com {epochs} épocas e batch size {batch_size}")
        
        # Construir modelo aluno
        self.student_model = self.student_builder()
        
        # Carregar dados
        train_data, val_data = self.data_loader()
        
        # Implementação específica para TensorFlow
        try:
            import tensorflow as tf
            
            if isinstance(self.teacher_model, tf.keras.Model) and isinstance(self.student_model, tf.keras.Model):
                return self._distill_tensorflow(train_data, val_data, epochs, batch_size, **kwargs)
        except ImportError:
            pass
        
        # Implementação específica para PyTorch
        try:
            import torch
            
            if isinstance(self.teacher_model, torch.nn.Module) and isinstance(self.student_model, torch.nn.Module):
                return self._distill_pytorch(train_data, val_data, epochs, batch_size, **kwargs)
        except ImportError:
            pass
        
        # Implementação genérica
        return self._distill_generic(train_data, val_data, epochs, batch_size, **kwargs)
    
    def _distill_tensorflow(self, train_data, val_data, epochs, batch_size, **kwargs):
        """
        Implementação de destilação para TensorFlow.
        """
        import tensorflow as tf
        
        # Extrair X e y dos dados
        X_train, y_train = train_data
        X_val, y_val = val_data
        
        # Definir função de treinamento personalizada
        class DistillationModel(tf.keras.Model):
            def __init__(self, student_model, teacher_model, temperature, alpha):
                super(DistillationModel, self).__init__()
                self.student_model = student_model
                self.teacher_model = teacher_model
                self.temperature = temperature
                self.alpha = alpha
            
            def compile(self, optimizer, metrics=None):
                super(DistillationModel, self).compile(optimizer=optimizer, metrics=metrics)
                self.student_model.compile(optimizer=optimizer, metrics=metrics)
            
            def train_step(self, data):
                x, y = data
                
                # Previsões do professor
                teacher_predictions = self.teacher_model(x, training=False)
                
                with tf.GradientTape() as tape:
                    # Previsões do aluno
                    student_predictions = self.student_model(x, training=True)
                    
                    # Calcular perda de destilação
                    distillation_loss = tf.keras.losses.KLDivergence()(
                        tf.nn.softmax(teacher_predictions / self.temperature, axis=1),
                        tf.nn.softmax(student_predictions / self.temperature, axis=1)
                    ) * (self.temperature ** 2)
                    
                    # Calcular perda original
                    student_loss = tf.keras.losses.SparseCategoricalCrossentropy()(y, student_predictions)
                    
                    # Perda total
                    loss = self.alpha * student_loss + (1 - self.alpha) * distillation_loss
                
                # Calcular gradientes e atualizar pesos
                trainable_vars = self.student_model.trainable_variables
                gradients = tape.gradient(loss, trainable_vars)
                self.optimizer.apply_gradients(zip(gradients, trainable_vars))
                
                # Atualizar métricas
                self.compiled_metrics.update_state(y, student_predictions)
                
                # Retornar métricas
                results = {m.name: m.result() for m in self.metrics}
                results.update({
                    "student_loss": student_loss,
                    "distillation_loss": distillation_loss,
                    "loss": loss
                })
                return results
            
            def test_step(self, data):
                x, y = data
                
                # Previsões do aluno
                student_predictions = self.student_model(x, training=False)
                
                # Calcular perda
                student_loss = tf.keras.losses.SparseCategoricalCrossentropy()(y, student_predictions)
                
                # Atualizar métricas
                self.compiled_metrics.update_state(y, student_predictions)
                
                # Retornar métricas
                results = {m.name: m.result() for m in self.metrics}
                results.update({"loss": student_loss})
                return results
            
            def call(self, inputs):
                return self.student_model(inputs)
        
        # Criar modelo de destilação
        distillation_model = DistillationModel(
            student_model=self.student_model,
            teacher_model=self.teacher_model,
            temperature=self.temperature,
            alpha=self.alpha
        )
        
        # Compilar modelo
        optimizer = kwargs.get('optimizer', tf.keras.optimizers.Adam(learning_rate=0.001))
        metrics = kwargs.get('metrics', ['accuracy'])
        distillation_model.compile(optimizer=optimizer, metrics=metrics)
        
        # Treinar modelo
        callbacks = kwargs.get('callbacks', [])
        history = distillation_model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val) if X_val is not None and y_val is not None else None,
            epochs=epochs,
            batch_size=batch_size,
            callbacks=callbacks,
            verbose=kwargs.get('verbose', 1)
        )
        
        logger.info("Destilação TensorFlow concluída")
        return self.student_model
    
    def _distill_pytorch(self, train_data, val_data, epochs, batch_size, **kwargs):
        """
        Implementação de destilação para PyTorch.
        """
        import torch
        import torch.nn as nn
        import torch.optim as optim
        from torch.utils.data import TensorDataset, DataLoader
        
        # Extrair X e y dos dados
        X_train, y_train = train_data
        X_val, y_val = val_data
        
        # Converter para tensores PyTorch
        X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
        y_train_tensor = torch.tensor(y_train, dtype=torch.long)
        
        # Criar dataset e dataloader
        train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        
        # Criar dataloader de validação se disponível
        val_loader = None
        if X_val is not None and y_val is not None:
            X_val_tensor = torch.tensor(X_val, dtype=torch.float32)
            y_val_tensor = torch.tensor(y_val, dtype=torch.long)
            val_dataset = TensorDataset(X_val_tensor, y_val_tensor)
            val_loader = DataLoader(val_dataset, batch_size=batch_size)
        
        # Definir otimizador
        optimizer = kwargs.get('optimizer', optim.Adam(self.student_model.parameters(), lr=0.001))
        
        # Definir função de perda para classificação
        criterion = nn.CrossEntropyLoss()
        
        # Definir função de perda para destilação
        def distillation_loss(student_logits, teacher_logits, temperature):
            soft_targets = nn.functional.softmax(teacher_logits / temperature, dim=1)
            soft_prob = nn.functional.log_softmax(student_logits / temperature, dim=1)
            return nn.functional.kl_div(soft_prob, soft_targets, reduction='batchmean') * (temperature ** 2)
        
        # Treinar modelo
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.teacher_model.to(device)
        self.student_model.to(device)
        
        self.teacher_model.eval()  # Modo de avaliação para o professor
        self.student_model.train()  # Modo de treinamento para o aluno
        
        for epoch in range(epochs):
            running_loss = 0.0
            correct = 0
            total = 0
            
            for inputs, targets in train_loader:
                inputs, targets = inputs.to(device), targets.to(device)
                
                # Zerar gradientes
                optimizer.zero_grad()
                
                # Previsões do professor
                with torch.no_grad():
                    teacher_outputs = self.teacher_model(inputs)
                
                # Previsões do aluno
                student_outputs = self.student_model(inputs)
                
                # Calcular perda de destilação
                dist_loss = distillation_loss(
                    student_outputs, 
                    teacher_outputs, 
                    self.temperature
                )
                
                # Calcular perda original
                student_loss = criterion(student_outputs, targets)
                
                # Perda total
                loss = self.alpha * student_loss + (1 - self.alpha) * dist_loss
                
                # Retropropagação e otimização
                loss.backward()
                optimizer.step()
                
                # Estatísticas
                running_loss += loss.item()
                _, predicted = student_outputs.max(1)
                total += targets.size(0)
                correct += predicted.eq(targets).sum().item()
            
            # Calcular acurácia de treinamento
            train_accuracy = 100.0 * correct / total
            train_loss = running_loss / len(train_loader)
            
            # Validação
            val_accuracy = 0.0
            val_loss = 0.0
            
            if val_loader is not None:
                self.student_model.eval()
                correct = 0
                total = 0
                running_loss = 0.0
                
                with torch.no_grad():
                    for inputs, targets in val_loader:
                        inputs, targets = inputs.to(device), targets.to(device)
                        outputs = self.student_model(inputs)
                        loss = criterion(outputs, targets)
                        
                        running_loss += loss.item()
                        _, predicted = outputs.max(1)
                        total += targets.size(0)
                        correct += predicted.eq(targets).sum().item()
                
                val_accuracy = 100.0 * correct / total
                val_loss = running_loss / len(val_loader)
                self.student_model.train()
            
            # Log de progresso
            if epoch % 10 == 0 or epoch == epochs - 1:
                logger.info(f"Epoch {epoch+1}/{epochs}: "
                           f"Train Loss: {train_loss:.4f}, "
                           f"Train Acc: {train_accuracy:.2f}%, "
                           f"Val Loss: {val_loss:.4f}, "
                           f"Val Acc: {val_accuracy:.2f}%")
        
        logger.info("Destilação PyTorch concluída")
        return self.student_model
    
    def _distill_generic(self, train_data, val_data, epochs, batch_size, **kwargs):
        """
        Implementação genérica de destilação para outros frameworks.
        """
        logger.warning("Usando implementação genérica de destilação. Pode não ser otimizada.")
        
        # Extrair X e y dos dados
        X_train, y_train = train_data
        
        # Obter previsões do professor
        teacher_predictions = self.teacher_model.predict(X_train)
        
        # Treinar modelo aluno com previsões do professor
        history = self.student_model.fit(
            X_train, 
            [y_train, teacher_predictions],  # Múltiplos alvos
            validation_data=val_data,
            epochs=epochs,
            batch_size=batch_size,
            verbose=kwargs.get('verbose', 1)
        )
        
        logger.info("Destilação genérica concluída")
        return self.student_model
    
    def evaluate(self, test_data) -> Dict:
        """
        Avalia o modelo aluno em dados de teste.
        
        Args:
            test_data: Dados de teste (X_test, y_test)
            
        Returns:
            Dicionário com métricas de avaliação
        """
        if self.student_model is None:
            logger.error("Modelo aluno não treinado")
            return {"error": "Modelo não treinado"}
        
        X_test, y_test = test_data
        
        # Avaliar modelo aluno
        student_metrics = self.student_model.evaluate(X_test, y_test, verbose=0)
        
        # Avaliar modelo professor para comparação
        teacher_metrics = self.teacher_model.evaluate(X_test, y_test, verbose=0)
        
        # Comparar tamanhos dos modelos
        try:
            import numpy as np
            student_size = np.sum([np.prod(v.shape) for v in self.student_model.get_weights()])
            teacher_size = np.sum([np.prod(v.shape) for v in self.teacher_model.get_weights()])
            size_reduction = (1 - student_size / teacher_size) * 100
        except:
            student_size = "N/A"
            teacher_size = "N/A"
            size_reduction = "N/A"
        
        # Preparar resultados
        results = {
            "student_metrics": student_metrics,
            "teacher_metrics": teacher_metrics,
            "student_size": student_size,
            "teacher_size": teacher_size,
            "size_reduction_percent": size_reduction
        }
        
        logger.info(f"Avaliação concluída. Redução de tamanho: {size_reduction}%")
        return results
    
    def save(self, output_dir: str) -> Dict[str, str]:
        """
        Salva o modelo aluno e metadados.
        
        Args:
            output_dir: Diretório para salvar o modelo
            
        Returns:
            Dicionário com caminhos dos arquivos salvos
        """
        if self.student_model is None:
            logger.error("Modelo aluno não treinado")
            return {"error": "Modelo não treinado"}
        
        os.makedirs(output_dir, exist_ok=True)
        
        # Salvar modelo aluno
        student_path = os.path.join(output_dir, "student_model.h5")
        self.student_model.save(student_path)
        
        # Salvar metadados
        metadata = {
            "temperature": self.temperature,
            "alpha": self.alpha,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        metadata_path = os.path.join(output_dir, "metadata.json")
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2)
        
        logger.info(f"Modelo aluno salvo em {student_path}")
        
        return {
            "student_model": student_path,
            "metadata": metadata_path
        }
    
    @classmethod
    def load_student(cls, model_path: str):
        """
        Carrega um modelo aluno salvo.
        
        Args:
            model_path: Caminho para o modelo aluno
            
        Returns:
            Modelo aluno carregado
        """
        try:
            # Tentar carregar como modelo TensorFlow
            try:
                import tensorflow as tf
                model = tf.keras.models.load_model(model_path)
                logger.info(f"Modelo aluno TensorFlow carregado de {model_path}")
                return model
            except ImportError:
                pass
            
            # Tentar carregar como modelo PyTorch
            try:
                import torch
                model = torch.load(model_path)
                logger.info(f"Modelo aluno PyTorch carregado de {model_path}")
                return model
            except ImportError:
                pass
            
            # Fallback genérico
            import pickle
            with open(model_path, 'rb') as f:
                model = pickle.load(f)
            
            logger.info(f"Modelo aluno carregado de {model_path}")
            return model
            
        except Exception as e:
            logger.error(f"Erro ao carregar modelo aluno: {e}")
            return None


class AdaptiveEnsemble:
    """
    Implementa um ensemble adaptativo com pesos dinâmicos.
    
    Esta classe combina múltiplos modelos em um ensemble, ajustando
    dinamicamente os pesos com base no desempenho recente de cada modelo.
    
    Attributes:
        models (List): Lista de modelos no ensemble
        weights (np.ndarray): Pesos de cada modelo
        performance_window (int): Tamanho da janela para avaliação de desempenho
        performance_history (List): Histórico de desempenho de cada modelo
        adaptation_rate (float): Taxa de adaptação dos pesos
    """
    
    def __init__(
        self,
        models: List = None,
        initial_weights: List[float] = None,
        performance_window: int = 100,
        adaptation_rate: float = 0.1
    ):
        """
        Inicializa o ensemble adaptativo.
        
        Args:
            models: Lista de modelos para o ensemble
            initial_weights: Pesos iniciais para cada modelo
            performance_window: Tamanho da janela para avaliação de desempenho
            adaptation_rate: Taxa de adaptação dos pesos
        """
        self.models = models or []
        self.performance_window = performance_window
        self.adaptation_rate = adaptation_rate
        
        # Inicializar pesos
        if initial_weights is not None:
            if len(initial_weights) != len(self.models):
                raise ValueError("Número de pesos deve ser igual ao número de modelos")
            
            # Normalizar pesos
            total = sum(initial_weights)
            self.weights = np.array([w / total for w in initial_weights])
        else:
            # Pesos uniformes
            n_models = len(self.models)
            self.weights = np.ones(n_models) / n_models if n_models > 0 else np.array([])
        
        # Inicializar histórico de desempenho
        self.performance_history = [[] for _ in range(len(self.models))]
        
        logger.info(f"Inicializado AdaptiveEnsemble com {len(self.models)} modelos")
        logger.info(f"Pesos iniciais: {self.weights}")
    
    def add_model(self, model, weight: float = 1.0) -> int:
        """
        Adiciona um modelo ao ensemble.
        
        Args:
            model: Modelo a ser adicionado
            weight: Peso inicial do modelo
            
        Returns:
            Índice do modelo adicionado
        """
        self.models.append(model)
        self.performance_history.append([])
        
        # Recalcular pesos
        n_models = len(self.models)
        if n_models == 1:
            self.weights = np.array([1.0])
        else:
            # Ajustar pesos existentes e adicionar novo peso
            self.weights = np.append(self.weights * (1 - weight / n_models), weight / n_models)
            # Normalizar
            self.weights = self.weights / np.sum(self.weights)
        
        logger.info(f"Modelo adicionado ao ensemble. Total: {n_models}")
        logger.info(f"Pesos atualizados: {self.weights}")
        
        return len(self.models) - 1
    
    def remove_model(self, index: int) -> bool:
        """
        Remove um modelo do ensemble.
        
        Args:
            index: Índice do modelo a ser removido
            
        Returns:
            True se o modelo foi removido com sucesso
        """
        if index < 0 or index >= len(self.models):
            logger.error(f"Índice inválido: {index}")
            return False
        
        self.models.pop(index)
        self.performance_history.pop(index)
        
        # Remover peso e renormalizar
        self.weights = np.delete(self.weights, index)
        if len(self.weights) > 0:
            self.weights = self.weights / np.sum(self.weights)
        
        logger.info(f"Modelo {index} removido do ensemble. Total: {len(self.models)}")
        logger.info(f"Pesos atualizados: {self.weights}")
        
        return True
    
    def update_performance(self, model_index: int, performance: float) -> None:
        """
        Atualiza o histórico de desempenho de um modelo.
        
        Args:
            model_index: Índice do modelo
            performance: Valor de desempenho (maior é melhor)
        """
        if model_index < 0 or model_index >= len(self.models):
            logger.error(f"Índice de modelo inválido: {model_index}")
            return
        
        # Adicionar ao histórico
        self.performance_history[model_index].append(performance)
        
        # Manter tamanho da janela
        if len(self.performance_history[model_index]) > self.performance_window:
            self.performance_history[model_index].pop(0)
        
        # Atualizar pesos se todos os modelos tiverem pelo menos uma medição
        if all(len(hist) > 0 for hist in self.performance_history):
            self._update_weights()
    
    def _update_weights(self) -> None:
        """
        Atualiza os pesos dos modelos com base no desempenho recente.
        """
        # Calcular desempenho médio recente
        recent_performance = np.array([
            np.mean(hist) for hist in self.performance_history
        ])
        
        # Normalizar para soma 1
        if np.sum(recent_performance) > 0:
            normalized_performance = recent_performance / np.sum(recent_performance)
        else:
            normalized_performance = np.ones_like(recent_performance) / len(recent_performance)
        
        # Atualizar pesos gradualmente
        self.weights = (1 - self.adaptation_rate) * self.weights + self.adaptation_rate * normalized_performance
        
        # Garantir que a soma seja 1
        self.weights = self.weights / np.sum(self.weights)
        
        logger.debug(f"Pesos atualizados: {self.weights}")
    
    def predict(self, X) -> np.ndarray:
        """
        Faz previsões usando o ensemble ponderado.
        
        Args:
            X: Dados de entrada
            
        Returns:
            Array com previsões do ensemble
        """
        if not self.models:
            logger.error("Nenhum modelo no ensemble")
            return np.array([])
        
        # Obter previsões de cada modelo
        predictions = []
        for i, model in enumerate(self.models):
            try:
                pred = model.predict(X)
                predictions.append(pred)
            except Exception as e:
                logger.error(f"Erro ao obter previsões do modelo {i}: {e}")
                # Usar zeros como fallback
                predictions.append(np.zeros((X.shape[0], pred.shape[1]) if len(pred.shape) > 1 else X.shape[0]))
        
        # Combinar previsões com pesos
        ensemble_pred = np.zeros_like(predictions[0])
        for i, pred in enumerate(predictions):
            ensemble_pred += self.weights[i] * pred
        
        return ensemble_pred
    
    def evaluate(self, X, y) -> Dict:
        """
        Avalia o desempenho do ensemble e de cada modelo individual.
        
        Args:
            X: Dados de entrada
            y: Rótulos verdadeiros
            
        Returns:
            Dicionário com métricas de avaliação
        """
        results = {
            "ensemble": {},
            "individual_models": []
        }
        
        # Avaliar ensemble
        ensemble_pred = self.predict(X)
        
        # Calcular métricas para o ensemble
        try:
            from sklearn.metrics import accuracy_score, mean_squared_error, r2_score
            
            # Classificação
            if len(y.shape) == 1 or y.shape[1] == 1:
                # Converter probabilidades para classes
                if len(ensemble_pred.shape) > 1 and ensemble_pred.shape[1] > 1:
                    ensemble_classes = np.argmax(ensemble_pred, axis=1)
                else:
                    ensemble_classes = (ensemble_pred > 0.5).astype(int)
                
                results["ensemble"]["accuracy"] = accuracy_score(y, ensemble_classes)
            
            # Regressão
            results["ensemble"]["mse"] = mean_squared_error(y, ensemble_pred)
            results["ensemble"]["r2"] = r2_score(y, ensemble_pred)
            
        except ImportError:
            logger.warning("sklearn não disponível. Métricas limitadas.")
            # Métricas básicas
            if len(y.shape) == 1 or y.shape[1] == 1:
                if len(ensemble_pred.shape) > 1 and ensemble_pred.shape[1] > 1:
                    ensemble_classes = np.argmax(ensemble_pred, axis=1)
                else:
                    ensemble_classes = (ensemble_pred > 0.5).astype(int)
                
                results["ensemble"]["accuracy"] = np.mean(ensemble_classes == y)
            
            results["ensemble"]["mse"] = np.mean((ensemble_pred - y) ** 2)
        
        # Avaliar modelos individuais
        for i, model in enumerate(self.models):
            model_results = {"index": i, "weight": self.weights[i]}
            
            try:
                # Obter previsões
                model_pred = model.predict(X)
                
                # Calcular métricas
                try:
                    # Classificação
                    if len(y.shape) == 1 or y.shape[1] == 1:
                        if len(model_pred.shape) > 1 and model_pred.shape[1] > 1:
                            model_classes = np.argmax(model_pred, axis=1)
                        else:
                            model_classes = (model_pred > 0.5).astype(int)
                        
                        model_results["accuracy"] = accuracy_score(y, model_classes)
                    
                    # Regressão
                    model_results["mse"] = mean_squared_error(y, model_pred)
                    model_results["r2"] = r2_score(y, model_pred)
                    
                except ImportError:
                    # Métricas básicas
                    if len(y.shape) == 1 or y.shape[1] == 1:
                        if len(model_pred.shape) > 1 and model_pred.shape[1] > 1:
                            model_classes = np.argmax(model_pred, axis=1)
                        else:
                            model_classes = (model_pred > 0.5).astype(int)
                        
                        model_results["accuracy"] = np.mean(model_classes == y)
                    
                    model_results["mse"] = np.mean((model_pred - y) ** 2)
                
                # Atualizar histórico de desempenho
                if "mse" in model_results:
                    # Para MSE, menor é melhor, então usamos o inverso
                    self.update_performance(i, 1.0 / (model_results["mse"] + 1e-10))
                elif "accuracy" in model_results:
                    # Para acurácia, maior é melhor
                    self.update_performance(i, model_results["accuracy"])
                
            except Exception as e:
                logger.error(f"Erro ao avaliar modelo {i}: {e}")
                model_results["error"] = str(e)
            
            results["individual_models"].append(model_results)
        
        return results
    
    def save(self, output_dir: str) -> Dict[str, str]:
        """
        Salva o ensemble e seus modelos.
        
        Args:
            output_dir: Diretório para salvar
            
        Returns:
            Dicionário com caminhos dos arquivos salvos
        """
        os.makedirs(output_dir, exist_ok=True)
        
        # Salvar metadados do ensemble
        metadata = {
            "n_models": len(self.models),
            "weights": self.weights.tolist(),
            "performance_window": self.performance_window,
            "adaptation_rate": self.adaptation_rate,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        metadata_path = os.path.join(output_dir, "ensemble_metadata.json")
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2)
        
        # Salvar modelos individuais
        model_paths = []
        for i, model in enumerate(self.models):
            try:
                model_dir = os.path.join(output_dir, f"model_{i}")
                os.makedirs(model_dir, exist_ok=True)
                
                # Tentar salvar como modelo TensorFlow
                try:
                    import tensorflow as tf
                    if isinstance(model, tf.keras.Model):
                        model_path = os.path.join(model_dir, "model.h5")
                        model.save(model_path)
                        model_paths.append(model_path)
                        continue
                except ImportError:
                    pass
                
                # Tentar salvar como modelo PyTorch
                try:
                    import torch
                    if isinstance(model, torch.nn.Module):
                        model_path = os.path.join(model_dir, "model.pt")
                        torch.save(model, model_path)
                        model_paths.append(model_path)
                        continue
                except ImportError:
                    pass
                
                # Fallback para pickle
                import pickle
                model_path = os.path.join(model_dir, "model.pkl")
                with open(model_path, 'wb') as f:
                    pickle.dump(model, f)
                
                model_paths.append(model_path)
                
            except Exception as e:
                logger.error(f"Erro ao salvar modelo {i}: {e}")
                model_paths.append(None)
        
        logger.info(f"Ensemble salvo em {output_dir}")
        
        return {
            "metadata": metadata_path,
            "models": model_paths
        }
    
    @classmethod
    def load(cls, input_dir: str) -> 'AdaptiveEnsemble':
        """
        Carrega um ensemble salvo.
        
        Args:
            input_dir: Diretório do ensemble
            
        Returns:
            Instância de AdaptiveEnsemble
        """
        try:
            # Carregar metadados
            metadata_path = os.path.join(input_dir, "ensemble_metadata.json")
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
            
            # Criar instância
            instance = cls(
                models=[],
                performance_window=metadata.get('performance_window', 100),
                adaptation_rate=metadata.get('adaptation_rate', 0.1)
            )
            
            # Definir pesos
            instance.weights = np.array(metadata.get('weights', []))
            
            # Carregar modelos
            n_models = metadata.get('n_models', 0)
            for i in range(n_models):
                model_dir = os.path.join(input_dir, f"model_{i}")
                
                # Tentar carregar como modelo TensorFlow
                try:
                    import tensorflow as tf
                    model_path = os.path.join(model_dir, "model.h5")
                    if os.path.exists(model_path):
                        model = tf.keras.models.load_model(model_path)
                        instance.models.append(model)
                        instance.performance_history.append([])
                        continue
                except ImportError:
                    pass
                
                # Tentar carregar como modelo PyTorch
                try:
                    import torch
                    model_path = os.path.join(model_dir, "model.pt")
                    if os.path.exists(model_path):
                        model = torch.load(model_path)
                        instance.models.append(model)
                        instance.performance_history.append([])
                        continue
                except ImportError:
                    pass
                
                # Fallback para pickle
                try:
                    import pickle
                    model_path = os.path.join(model_dir, "model.pkl")
                    if os.path.exists(model_path):
                        with open(model_path, 'rb') as f:
                            model = pickle.load(f)
                        instance.models.append(model)
                        instance.performance_history.append([])
                        continue
                except:
                    pass
                
                logger.warning(f"Não foi possível carregar o modelo {i}")
            
            logger.info(f"Ensemble carregado de {input_dir} com {len(instance.models)} modelos")
            return instance
            
        except Exception as e:
            logger.error(f"Erro ao carregar ensemble: {e}")
            return None

# Exportar classes
__all__ = ['AutoMLOptimizer', 'ModelDistiller', 'AdaptiveEnsemble']
