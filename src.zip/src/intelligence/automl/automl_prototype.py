#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AutoML Prototype - Protótipo de AutoML para trading algorítmico

Este módulo implementa um protótipo de AutoML para trading algorítmico,
com foco em adaptabilidade e ensemble de modelos.

Autor: Equipe KR_KRIPTO
Data: Maio 2025
Versão: 2.0
"""

import os
import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Any, Optional, Union
from datetime import datetime, timedelta

# Importar módulos internos
try:
    from src.intelligence.automl.adaptive_ensemble import AdaptiveEnsemble
    from src.utils.logger_config import setup_logger
except ImportError:
    # Fallback para logging padrão
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

# Configurar logger
logger = setup_logger("automl_prototype")

class AutoMLPrototype:
    """
    Protótipo de AutoML para trading algorítmico.
    
    Esta classe implementa um protótipo de AutoML para trading algorítmico,
    com foco em adaptabilidade e ensemble de modelos.
    
    Attributes:
        config (Dict): Configurações do AutoML
        models (Dict): Dicionário de modelos treinados
        ensemble (AdaptiveEnsemble): Ensemble adaptativo de modelos
        integration (Dict): Configurações de integração com outros módulos
        operador (Any): Operador para execução de ordens
    """
    
    def __init__(self, config: Dict = None):
        """
        Inicializa o protótipo de AutoML.
        
        Args:
            config: Configurações do AutoML (default: None)
        """
        self.config = config or {}
        self.models = {}
        self.ensemble = None
        self.integration = {}
        self.operador = None
        
        # Configurações específicas
        self.n_trials = self.config.get('n_trials', 5)
        self.window_size = self.config.get('window_size', 10)
        self.adaptation_rate = self.config.get('adaptation_rate', 0.1)
        self.min_weight = self.config.get('min_weight', 0.1)
        self.default_weight = self.config.get('default_weight', 0.5)
        
        logger.info(f"AutoMLPrototype inicializado com configuração: {self.config}")
    
    def setup_integration(self, dataframes: Dict[str, pd.DataFrame]):
        """
        Configura a integração com outros módulos.
        
        Args:
            dataframes: Dicionário de dataframes (chave: 'symbol_timeframe', valor: DataFrame)
        """
        logger.info(f"Configurando integração com {len(dataframes)} dataframes")
        
        # Inicializar ensemble se ainda não foi inicializado
        if self.ensemble is None:
            self.ensemble = AdaptiveEnsemble(
                adaptation_rate=self.adaptation_rate,
                min_weight=self.min_weight,
                default_weight=self.default_weight
            )
            
            # Adicionar modelos base ao ensemble
            self.ensemble.add_model('modelo_base_1', lambda x: 0.5)
            self.ensemble.add_model('modelo_base_2', lambda x: -0.5)
        
        # Armazenar configurações de integração
        self.integration = {
            'dataframes': dataframes,
            'timestamp': datetime.now().isoformat()
        }
    
    def train_models(self, symbol: str, timeframe: str):
        """
        Treina modelos para um par e timeframe específicos.
        
        Args:
            symbol: Símbolo do ativo
            timeframe: Timeframe para análise
            
        Returns:
            Dict: Resultados do treinamento
        """
        key = f"{symbol}_{timeframe}"
        
        # Verificar se temos dados para este par/timeframe
        if not self.integration or 'dataframes' not in self.integration:
            logger.error(f"Integração não configurada para {key}")
            return {'erro': 'Integração não configurada'}
        
        if key not in self.integration['dataframes']:
            logger.error(f"Dados não disponíveis para {key}")
            return {'erro': f'Dados não disponíveis para {key}'}
        
        # Obter dataframe
        df = self.integration['dataframes'][key]
        
        # Preparar dados para treinamento
        X, y = self._prepare_data(df)
        
        if X is None or y is None:
            logger.error(f"Falha ao preparar dados para {key}")
            return {'erro': 'Falha ao preparar dados'}
        
        # Treinar modelos
        results = {}
        
        # Treinar modelo LSTM
        try:
            lstm_model, lstm_params, lstm_score = self._train_lstm(X, y)
            self.models[(symbol, timeframe, 'lstm')] = {
                'model': lstm_model,
                'params': lstm_params,
                'score': lstm_score
            }
            results['lstm'] = {
                'score': lstm_score,
                'params': lstm_params
            }
            logger.info(f"Modelo LSTM treinado para {key} com score {lstm_score:.4f}")
        except Exception as e:
            logger.error(f"Erro ao treinar modelo LSTM para {key}: {e}")
            results['lstm'] = {'erro': str(e)}
        
        # Treinar modelo Transformer
        try:
            transformer_model, transformer_params, transformer_score = self._train_transformer(X, y)
            self.models[(symbol, timeframe, 'transformer')] = {
                'model': transformer_model,
                'params': transformer_params,
                'score': transformer_score
            }
            results['transformer'] = {
                'score': transformer_score,
                'params': transformer_params
            }
            logger.info(f"Modelo Transformer treinado para {key} com score {transformer_score:.4f}")
        except Exception as e:
            logger.error(f"Erro ao treinar modelo Transformer para {key}: {e}")
            results['transformer'] = {'erro': str(e)}
        
        # Treinar modelo XGBoost
        try:
            xgb_model, xgb_params, xgb_score = self._train_xgboost(X, y)
            self.models[(symbol, timeframe, 'xgboost')] = {
                'model': xgb_model,
                'params': xgb_params,
                'score': xgb_score
            }
            results['xgboost'] = {
                'score': xgb_score,
                'params': xgb_params
            }
            logger.info(f"Modelo XGBoost treinado para {key} com score {xgb_score:.4f}")
        except Exception as e:
            logger.error(f"Erro ao treinar modelo XGBoost para {key}: {e}")
            results['xgboost'] = {'erro': str(e)}
        
        # Atualizar ensemble com os novos modelos
        self._update_ensemble(symbol, timeframe)
        
        return results
    
    def _prepare_data(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """
        Prepara os dados para treinamento.
        
        Args:
            df: DataFrame com dados históricos
            
        Returns:
            Tuple: (X, y) - Dados de entrada e saída para treinamento
        """
        try:
            # Verificar se o DataFrame tem dados suficientes
            if df is None or len(df) < self.window_size + 1:
                logger.error(f"DataFrame insuficiente para preparação de dados: {len(df) if df is not None else 0} linhas")
                return None, None
            
            # Selecionar features relevantes
            features = []
            
            # Preços e volume
            if 'close' in df.columns:
                features.append('close')
            if 'open' in df.columns:
                features.append('open')
            if 'high' in df.columns:
                features.append('high')
            if 'low' in df.columns:
                features.append('low')
            if 'volume' in df.columns:
                features.append('volume')
            
            # Indicadores técnicos
            for col in df.columns:
                if col.startswith(('rsi', 'macd', 'ema', 'sma', 'bollinger', 'atr', 'adx')):
                    features.append(col)
            
            # Verificar se temos features suficientes
            if len(features) < 3:
                logger.warning(f"Poucas features disponíveis: {features}")
                # Adicionar colunas dummy se necessário
                if 'close' in df.columns:
                    df['dummy1'] = df['close'].rolling(5).mean()
                    df['dummy2'] = df['close'].rolling(10).mean()
                    features.extend(['dummy1', 'dummy2'])
            
            # Criar janelas deslizantes
            X = []
            y = []
            
            for i in range(len(df) - self.window_size):
                X.append(df[features].iloc[i:i+self.window_size].values)
                # Target: retorno percentual no próximo período
                if 'close' in df.columns:
                    next_return = (df['close'].iloc[i+self.window_size] / df['close'].iloc[i+self.window_size-1]) - 1
                    y.append(next_return)
                else:
                    # Fallback para um valor aleatório
                    y.append(np.random.normal(0, 0.01))
            
            return np.array(X), np.array(y)
            
        except Exception as e:
            logger.error(f"Erro ao preparar dados: {e}")
            return None, None
    
    def _train_lstm(self, X: np.ndarray, y: np.ndarray) -> Tuple[Any, Dict, float]:
        """
        Treina um modelo LSTM.
        
        Args:
            X: Dados de entrada
            y: Dados de saída
            
        Returns:
            Tuple: (modelo, parâmetros, score)
        """
        # Simulação de treinamento para o protótipo
        params = {
            'units': 64,
            'layers': 2,
            'dropout': 0.2,
            'recurrent_dropout': 0.2,
            'optimizer': 'adam',
            'loss': 'mse'
        }
        
        # Modelo mock para o protótipo
        class MockLSTM:
            def __init__(self, params):
                self.params = params
            
            def predict(self, X):
                # Simulação de predição
                return np.random.normal(0, 0.01, size=len(X))
            
            def evaluate(self, X, y):
                # Simulação de avaliação
                return 0.7 + np.random.random() * 0.2
        
        model = MockLSTM(params)
        score = model.evaluate(X, y)
        
        return model, params, score
    
    def _train_transformer(self, X: np.ndarray, y: np.ndarray) -> Tuple[Any, Dict, float]:
        """
        Treina um modelo Transformer.
        
        Args:
            X: Dados de entrada
            y: Dados de saída
            
        Returns:
            Tuple: (modelo, parâmetros, score)
        """
        # Simulação de treinamento para o protótipo
        params = {
            'n_layers': 4,
            'n_heads': 8,
            'd_model': 128,
            'dff': 512,
            'dropout': 0.1,
            'optimizer': 'adam',
            'loss': 'mse'
        }
        
        # Modelo mock para o protótipo
        class MockTransformer:
            def __init__(self, params):
                self.params = params
            
            def predict(self, X):
                # Simulação de predição
                return np.random.normal(0, 0.01, size=len(X))
            
            def evaluate(self, X, y):
                # Simulação de avaliação
                return 0.75 + np.random.random() * 0.2
        
        model = MockTransformer(params)
        score = model.evaluate(X, y)
        
        return model, params, score
    
    def _train_xgboost(self, X: np.ndarray, y: np.ndarray) -> Tuple[Any, Dict, float]:
        """
        Treina um modelo XGBoost.
        
        Args:
            X: Dados de entrada
            y: Dados de saída
            
        Returns:
            Tuple: (modelo, parâmetros, score)
        """
        # Simulação de treinamento para o protótipo
        params = {
            'max_depth': 6,
            'learning_rate': 0.1,
            'n_estimators': 100,
            'subsample': 0.8,
            'colsample_bytree': 0.8,
            'objective': 'reg:squarederror'
        }
        
        # Modelo mock para o protótipo
        class MockXGBoost:
            def __init__(self, params):
                self.params = params
            
            def predict(self, X):
                # Simulação de predição
                if len(X.shape) == 3:
                    # Reshape para 2D se necessário
                    X_2d = X.reshape(X.shape[0], -1)
                else:
                    X_2d = X
                return np.random.normal(0, 0.01, size=len(X_2d))
            
            def evaluate(self, X, y):
                # Simulação de avaliação
                return 0.8 + np.random.random() * 0.15
        
        model = MockXGBoost(params)
        score = model.evaluate(X, y)
        
        return model, params, score
    
    def _update_ensemble(self, symbol: str, timeframe: str):
        """
        Atualiza o ensemble com os modelos treinados.
        
        Args:
            symbol: Símbolo do ativo
            timeframe: Timeframe para análise
        """
        # Verificar se temos modelos para este par/timeframe
        models_for_pair = [(k, v) for k, v in self.models.items() if k[0] == symbol and k[1] == timeframe]
        
        if not models_for_pair:
            logger.warning(f"Nenhum modelo disponível para {symbol}_{timeframe}")
            return
        
        # Atualizar ensemble
        for key, model_info in models_for_pair:
            model_type = key[2]
            model = model_info['model']
            score = model_info['score']
            
            # Criar wrapper para o modelo
            def predict_wrapper(X, model=model):
                try:
                    return model.predict(X)
                except Exception as e:
                    logger.error(f"Erro na predição do modelo {model_type}: {e}")
                    return np.zeros(len(X))
            
            # Adicionar ou atualizar modelo no ensemble
            model_name = f"{symbol}_{timeframe}_{model_type}"
            if model_name in self.ensemble.models:
                self.ensemble.update_weight(model_name, score)
            else:
                self.ensemble.add_model(model_name, predict_wrapper, weight=score)
            
            logger.info(f"Modelo {model_name} adicionado/atualizado no ensemble com peso {score:.4f}")
    
    def predict(self, symbol: str, timeframe: str, data: pd.DataFrame) -> Dict:
        """
        Faz uma previsão para um par e timeframe específicos.
        
        Args:
            symbol: Símbolo do ativo
            timeframe: Timeframe para análise
            data: DataFrame com dados recentes
            
        Returns:
            Dict: Resultado da previsão
        """
        key = f"{symbol}_{timeframe}"
        
        # Verificar se temos modelos para este par/timeframe
        models_for_pair = [(k, v) for k, v in self.models.items() if k[0] == symbol and k[1] == timeframe]
        
        if not models_for_pair:
            logger.warning(f"Nenhum modelo disponível para {key}")
            return {'erro': f'Nenhum modelo disponível para {key}'}
        
        try:
            # Preparar dados para previsão
            X = self._prepare_prediction_data(data)
            
            if X is None:
                logger.error(f"Falha ao preparar dados para previsão de {key}")
                return {'erro': 'Falha ao preparar dados para previsão'}
            
            # Fazer previsões individuais
            predictions = {}
            
            for model_key, model_info in models_for_pair:
                model_type = model_key[2]
                model = model_info['model']
                
                try:
                    pred = model.predict(X)
                    predictions[model_type] = float(pred[0]) if isinstance(pred, np.ndarray) and len(pred) > 0 else float(pred)
                except Exception as e:
                    logger.error(f"Erro na predição do modelo {model_type} para {key}: {e}")
                    predictions[model_type] = {'erro': str(e)}
            
            # Fazer previsão com ensemble
            try:
                ensemble_pred = self.ensemble.predict(X)
                predictions['ensemble'] = float(ensemble_pred[0]) if isinstance(ensemble_pred, np.ndarray) and len(ensemble_pred) > 0 else float(ensemble_pred)
            except Exception as e:
                logger.error(f"Erro na predição do ensemble para {key}: {e}")
                predictions['ensemble'] = {'erro': str(e)}
            
            # Calcular confiança
            confidence = self._calculate_confidence(predictions)
            
            # Preparar resultado
            result = {
                'previsao': predictions.get('ensemble', 0.0),
                'confianca': confidence,
                'modelos': predictions,
                'timestamp': datetime.now().isoformat()
            }
            
            return result
            
        except Exception as e:
            logger.error(f"Erro ao fazer previsão para {key}: {e}")
            return {'erro': str(e)}
    
    def _prepare_prediction_data(self, data: pd.DataFrame) -> np.ndarray:
        """
        Prepara os dados para previsão.
        
        Args:
            data: DataFrame com dados recentes
            
        Returns:
            np.ndarray: Dados preparados para previsão
        """
        try:
            # Verificar se o DataFrame tem dados suficientes
            if data is None or len(data) < self.window_size:
                logger.error(f"DataFrame insuficiente para previsão: {len(data) if data is not None else 0} linhas")
                return None
            
            # Selecionar features relevantes
            features = []
            
            # Preços e volume
            if 'close' in data.columns:
                features.append('close')
            if 'open' in data.columns:
                features.append('open')
            if 'high' in data.columns:
                features.append('high')
            if 'low' in data.columns:
                features.append('low')
            if 'volume' in data.columns:
                features.append('volume')
            
            # Indicadores técnicos
            for col in data.columns:
                if col.startswith(('rsi', 'macd', 'ema', 'sma', 'bollinger', 'atr', 'adx')):
                    features.append(col)
            
            # Verificar se temos features suficientes
            if len(features) < 3:
                logger.warning(f"Poucas features disponíveis para previsão: {features}")
                # Adicionar colunas dummy se necessário
                if 'close' in data.columns:
                    data['dummy1'] = data['close'].rolling(5).mean()
                    data['dummy2'] = data['close'].rolling(10).mean()
                    features.extend(['dummy1', 'dummy2'])
            
            # Usar as últimas window_size linhas
            X = data[features].iloc[-self.window_size:].values.reshape(1, self.window_size, len(features))
            
            return X
            
        except Exception as e:
            logger.error(f"Erro ao preparar dados para previsão: {e}")
            return None
    
    def _calculate_confidence(self, predictions: Dict) -> float:
        """
        Calcula a confiança da previsão.
        
        Args:
            predictions: Dicionário de previsões
            
        Returns:
            float: Confiança da previsão
        """
        # Remover entradas de erro
        valid_predictions = {k: v for k, v in predictions.items() if not isinstance(v, dict)}
        
        if not valid_predictions:
            return 0.0
        
        # Calcular confiança com base na concordância entre modelos
        values = list(valid_predictions.values())
        mean_value = np.mean(values)
        std_value = np.std(values)
        
        # Normalizar confiança para [0, 1]
        if std_value == 0:
            # Todos os modelos concordam perfeitamente
            confidence = 1.0
        else:
            # Quanto menor o desvio padrão, maior a confiança
            confidence = 1.0 / (1.0 + 5.0 * std_value)
        
        return float(confidence)
    
    def optimize_hyperparameters(self, symbol: str, timeframe: str, n_trials: int = None) -> Dict:
        """
        Otimiza os hiperparâmetros dos modelos para um par e timeframe específicos.
        
        Args:
            symbol: Símbolo do ativo
            timeframe: Timeframe para análise
            n_trials: Número de tentativas de otimização (default: None)
            
        Returns:
            Dict: Melhores hiperparâmetros encontrados
        """
        if n_trials is None:
            n_trials = self.n_trials
        
        key = f"{symbol}_{timeframe}"
        
        # Verificar se temos dados para este par/timeframe
        if not self.integration or 'dataframes' not in self.integration:
            logger.error(f"Integração não configurada para {key}")
            return {'erro': 'Integração não configurada'}
        
        if key not in self.integration['dataframes']:
            logger.error(f"Dados não disponíveis para {key}")
            return {'erro': f'Dados não disponíveis para {key}'}
        
        # Obter dataframe
        df = self.integration['dataframes'][key]
        
        # Preparar dados para otimização
        X, y = self._prepare_data(df)
        
        if X is None or y is None:
            logger.error(f"Falha ao preparar dados para otimização de {key}")
            return {'erro': 'Falha ao preparar dados para otimização'}
        
        # Otimizar hiperparâmetros
        results = {}
        
        # Otimizar LSTM
        try:
            lstm_best_params = self._optimize_lstm(X, y, n_trials)
            results['lstm'] = lstm_best_params
            logger.info(f"Hiperparâmetros otimizados para LSTM de {key}: {lstm_best_params}")
        except Exception as e:
            logger.error(f"Erro ao otimizar hiperparâmetros do LSTM para {key}: {e}")
            results['lstm'] = {'erro': str(e)}
        
        # Otimizar Transformer
        try:
            transformer_best_params = self._optimize_transformer(X, y, n_trials)
            results['transformer'] = transformer_best_params
            logger.info(f"Hiperparâmetros otimizados para Transformer de {key}: {transformer_best_params}")
        except Exception as e:
            logger.error(f"Erro ao otimizar hiperparâmetros do Transformer para {key}: {e}")
            results['transformer'] = {'erro': str(e)}
        
        # Otimizar XGBoost
        try:
            xgb_best_params = self._optimize_xgboost(X, y, n_trials)
            results['xgboost'] = xgb_best_params
            logger.info(f"Hiperparâmetros otimizados para XGBoost de {key}: {xgb_best_params}")
        except Exception as e:
            logger.error(f"Erro ao otimizar hiperparâmetros do XGBoost para {key}: {e}")
            results['xgboost'] = {'erro': str(e)}
        
        return results
    
    def _optimize_lstm(self, X: np.ndarray, y: np.ndarray, n_trials: int) -> Dict:
        """
        Otimiza os hiperparâmetros do modelo LSTM.
        
        Args:
            X: Dados de entrada
            y: Dados de saída
            n_trials: Número de tentativas de otimização
            
        Returns:
            Dict: Melhores hiperparâmetros encontrados
        """
        # Simulação de otimização para o protótipo
        best_params = {
            'units': 128,
            'layers': 3,
            'dropout': 0.3,
            'recurrent_dropout': 0.3,
            'optimizer': 'adam',
            'loss': 'mse'
        }
        
        return best_params
    
    def _optimize_transformer(self, X: np.ndarray, y: np.ndarray, n_trials: int) -> Dict:
        """
        Otimiza os hiperparâmetros do modelo Transformer.
        
        Args:
            X: Dados de entrada
            y: Dados de saída
            n_trials: Número de tentativas de otimização
            
        Returns:
            Dict: Melhores hiperparâmetros encontrados
        """
        # Simulação de otimização para o protótipo
        best_params = {
            'n_layers': 6,
            'n_heads': 8,
            'd_model': 256,
            'dff': 1024,
            'dropout': 0.2,
            'optimizer': 'adam',
            'loss': 'mse'
        }
        
        return best_params
    
    def _optimize_xgboost(self, X: np.ndarray, y: np.ndarray, n_trials: int) -> Dict:
        """
        Otimiza os hiperparâmetros do modelo XGBoost.
        
        Args:
            X: Dados de entrada
            y: Dados de saída
            n_trials: Número de tentativas de otimização
            
        Returns:
            Dict: Melhores hiperparâmetros encontrados
        """
        # Simulação de otimização para o protótipo
        best_params = {
            'max_depth': 8,
            'learning_rate': 0.05,
            'n_estimators': 200,
            'subsample': 0.7,
            'colsample_bytree': 0.7,
            'objective': 'reg:squarederror'
        }
        
        return best_params
    
    def save_models(self, directory: str) -> Dict:
        """
        Salva os modelos treinados.
        
        Args:
            directory: Diretório para salvar os modelos
            
        Returns:
            Dict: Resultado da operação
        """
        # Criar diretório se não existir
        os.makedirs(directory, exist_ok=True)
        
        results = {}
        
        # Salvar cada modelo
        for key, model_info in self.models.items():
            symbol, timeframe, model_type = key
            model = model_info['model']
            
            try:
                # Criar nome do arquivo
                filename = f"{symbol}_{timeframe}_{model_type}.model"
                filepath = os.path.join(directory, filename)
                
                # Salvar modelo (simulação para o protótipo)
                with open(filepath, 'w') as f:
                    f.write(f"Model: {model_type}\nSymbol: {symbol}\nTimeframe: {timeframe}\nParams: {model_info['params']}")
                
                results[filename] = 'success'
                logger.info(f"Modelo {filename} salvo com sucesso em {filepath}")
            except Exception as e:
                results[f"{symbol}_{timeframe}_{model_type}"] = {'erro': str(e)}
                logger.error(f"Erro ao salvar modelo {symbol}_{timeframe}_{model_type}: {e}")
        
        # Salvar ensemble
        try:
            # Criar nome do arquivo
            filename = "ensemble.model"
            filepath = os.path.join(directory, filename)
            
            # Salvar ensemble (simulação para o protótipo)
            with open(filepath, 'w') as f:
                f.write(f"Ensemble\nModels: {list(self.ensemble.models.keys())}\nWeights: {self.ensemble.weights}")
            
            results[filename] = 'success'
            logger.info(f"Ensemble salvo com sucesso em {filepath}")
        except Exception as e:
            results['ensemble'] = {'erro': str(e)}
            logger.error(f"Erro ao salvar ensemble: {e}")
        
        return results
    
    def load_models(self, directory: str) -> Dict:
        """
        Carrega os modelos salvos.
        
        Args:
            directory: Diretório com os modelos salvos
            
        Returns:
            Dict: Resultado da operação
        """
        if not os.path.exists(directory):
            logger.error(f"Diretório {directory} não existe")
            return {'erro': f'Diretório {directory} não existe'}
        
        results = {}
        
        # Listar arquivos no diretório
        files = [f for f in os.listdir(directory) if f.endswith('.model')]
        
        # Carregar cada modelo
        for filename in files:
            try:
                # Extrair informações do nome do arquivo
                if filename == "ensemble.model":
                    # Carregar ensemble (simulação para o protótipo)
                    filepath = os.path.join(directory, filename)
                    with open(filepath, 'r') as f:
                        content = f.read()
                    
                    # Inicializar ensemble se ainda não foi inicializado
                    if self.ensemble is None:
                        self.ensemble = AdaptiveEnsemble(
                            adaptation_rate=self.adaptation_rate,
                            min_weight=self.min_weight,
                            default_weight=self.default_weight
                        )
                    
                    results[filename] = 'success'
                    logger.info(f"Ensemble carregado com sucesso de {filepath}")
                else:
                    # Extrair informações do nome do arquivo
                    parts = filename.split('_')
                    if len(parts) >= 3:
                        symbol = parts[0]
                        timeframe = parts[1]
                        model_type = parts[2].split('.')[0]
                        
                        # Carregar modelo (simulação para o protótipo)
                        filepath = os.path.join(directory, filename)
                        with open(filepath, 'r') as f:
                            content = f.read()
                        
                        # Criar modelo mock
                        if model_type == 'lstm':
                            model, params, score = self._train_lstm(None, None)
                        elif model_type == 'transformer':
                            model, params, score = self._train_transformer(None, None)
                        elif model_type == 'xgboost':
                            model, params, score = self._train_xgboost(None, None)
                        else:
                            logger.warning(f"Tipo de modelo desconhecido: {model_type}")
                            continue
                        
                        # Armazenar modelo
                        self.models[(symbol, timeframe, model_type)] = {
                            'model': model,
                            'params': params,
                            'score': score
                        }
                        
                        results[filename] = 'success'
                        logger.info(f"Modelo {filename} carregado com sucesso de {filepath}")
            except Exception as e:
                results[filename] = {'erro': str(e)}
                logger.error(f"Erro ao carregar modelo {filename}: {e}")
        
        return results
    
    def get_status(self) -> Dict:
        """
        Obtém o status atual do AutoML.
        
        Returns:
            Dict: Status atual
        """
        # Contar modelos por tipo
        model_counts = {}
        for key in self.models:
            symbol, timeframe, model_type = key
            if model_type not in model_counts:
                model_counts[model_type] = 0
            model_counts[model_type] += 1
        
        # Preparar status
        status = {
            'modelos': {
                'total': len(self.models),
                'por_tipo': model_counts
            },
            'ensemble': {
                'modelos': len(self.ensemble.models) if self.ensemble else 0,
                'pesos': self.ensemble.weights if self.ensemble else {}
            },
            'integracao': {
                'configurada': bool(self.integration),
                'dataframes': len(self.integration.get('dataframes', {})) if self.integration else 0
            },
            'configuracao': {
                'n_trials': self.n_trials,
                'window_size': self.window_size,
                'adaptation_rate': self.adaptation_rate
            },
            'timestamp': datetime.now().isoformat()
        }
        
        return status
