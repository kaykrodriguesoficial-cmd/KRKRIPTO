# Corrigido para usar a coluna 'RSI' em maiúsculas
import pandas as pd
import logging

logger = logging.getLogger("kr_kripto.classificador")

def prever_classe_corrigido_v12(df: pd.DataFrame):
    """
    Prevê a classe (compra/venda/nada) com base no DataFrame (v12).
    Usa a coluna 'RSI' (MAIÚSCULA).
    """
    try:
        # --- CORREÇÃO v12: Usar coluna 'RSI' MAIÚSCULA --- 
        if 'RSI' not in df.columns:
            logger.warning("Coluna 'RSI' não encontrada no DataFrame para prever_classe. Retornando 'nada'.")
            return "nada", 0.0
            
        rsi = df.iloc[-1]["RSI"]
        # --- FIM CORREÇÃO v12 ---
        
        if pd.isna(rsi):
            logger.warning("Valor RSI é NaN. Retornando 'nada'.")
            return "nada", 0.0
            
        if rsi < 30:
            return "compra", 0.8
        elif rsi > 70:
            return "venda", 0.8
        else:
            return "nada", 0.5
            
    except IndexError:
        logger.error("Erro de índice ao acessar RSI (DataFrame vazio ou índice inválido?). Retornando 'nada'.")
        return "nada", 0.0
    except KeyError:
        logger.error("Erro de chave ao acessar 'RSI' (Coluna realmente existe?). Retornando 'nada'.")
        return "nada", 0.0
    except Exception as e:
        logger.error(f"Erro inesperado ao prever classe v12: {e}")
        return "nada", 0.0

