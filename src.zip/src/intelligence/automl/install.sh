#!/bin/bash
# Script de instalação e configuração do framework AutoML para KR_KRIPTO_FULL
# Autor: Manus AI
# Data: Abril 2025
# Versão: 1.0.0

# Definir diretório base (ajuste conforme necessário)
BASE_DIR="/Volumes/Extreme SSD/KR_KRIPTO_FULL"
cd "$BASE_DIR" || { echo "Erro: Diretório $BASE_DIR não encontrado"; exit 1; }

# Cores para output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Função para exibir mensagens
print_message() {
    echo -e "${GREEN}[AutoML Installer]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[AutoML Installer]${NC} $1"
}

print_error() {
    echo -e "${RED}[AutoML Installer]${NC} $1"
}

# Verificar se estamos em um Mac com Apple Silicon
is_apple_silicon=false
if [[ "$(uname)" == "Darwin" && "$(uname -m)" == "arm64" ]]; then
    is_apple_silicon=true
    print_message "Detectado Mac com Apple Silicon"
fi

# Criar diretórios necessários
print_message "Criando diretórios necessários..."
mkdir -p "$BASE_DIR/dados"
mkdir -p "$BASE_DIR/modelos"
mkdir -p "$BASE_DIR/resultados"
mkdir -p "$BASE_DIR/logs"

# Instalar dependências
print_message "Instalando dependências..."
if [ "$is_apple_silicon" = true ]; then
    print_message "Instalando dependências otimizadas para Apple Silicon..."
    pip3 install --upgrade pip
    pip3 uninstall -y tensorflow
    pip3 install tensorflow-macos
    pip3 install tensorflow-metal
    pip3 install torch torchvision torchaudio
    pip3 install optuna scikit-learn pandas numpy matplotlib seaborn
    pip3 install ta-lib || print_warning "Não foi possível instalar ta-lib. Alguns indicadores técnicos usarão implementações alternativas."
else
    print_message "Instalando dependências padrão..."
    pip3 install --upgrade pip
    pip3 install tensorflow
    pip3 install torch torchvision torchaudio
    pip3 install optuna scikit-learn pandas numpy matplotlib seaborn
    pip3 install ta-lib || print_warning "Não foi possível instalar ta-lib. Alguns indicadores técnicos usarão implementações alternativas."
fi

# Verificar instalação do TensorFlow
print_message "Verificando instalação do TensorFlow..."
python3 -c "import tensorflow as tf; print(f'TensorFlow versão: {tf.__version__}'); print(f'Dispositivos disponíveis: {tf.config.list_physical_devices()}');" || print_error "Erro ao verificar TensorFlow"

# Verificar instalação do PyTorch
print_message "Verificando instalação do PyTorch..."
python3 -c "import torch; print(f'PyTorch versão: {torch.__version__}'); print(f'CUDA disponível: {torch.cuda.is_available()}'); print(f'MPS disponível: {torch.backends.mps.is_available() if hasattr(torch.backends, \"mps\") else False}');" || print_error "Erro ao verificar PyTorch"

# Verificar instalação do Optuna
print_message "Verificando instalação do Optuna..."
python3 -c "import optuna; print(f'Optuna versão: {optuna.__version__}');" || print_error "Erro ao verificar Optuna"

# Configurar variáveis de ambiente para Apple Silicon
if [ "$is_apple_silicon" = true ]; then
    print_message "Configurando variáveis de ambiente para Apple Silicon..."
    echo 'export TF_ENABLE_ONEDNN_OPTS=0' >> ~/.zshrc
    echo 'export PYTORCH_ENABLE_MPS_FALLBACK=1' >> ~/.zshrc
    source ~/.zshrc
fi

# Testar framework AutoML
print_message "Testando framework AutoML..."
python3 -c "
import sys
sys.path.append('$BASE_DIR')
try:
    from inteligencia.automl.automl_framework import AutoMLOptimizer, ModelDistiller, AdaptiveEnsemble
    print('✅ Framework AutoML importado com sucesso')
except ImportError as e:
    print(f'❌ Erro ao importar framework AutoML: {e}')
    sys.exit(1)
"

# Criar arquivo de configuração
print_message "Criando arquivo de configuração..."
cat > "$BASE_DIR/automl_config.json" << EOL
{
    "data_dir": "$BASE_DIR/dados",
    "models_dir": "$BASE_DIR/modelos",
    "results_dir": "$BASE_DIR/resultados",
    "logs_dir": "$BASE_DIR/logs",
    "default_symbol": "BTCUSDT",
    "default_timeframe": "1h",
    "n_trials": $([ "$is_apple_silicon" = true ] && echo "20" || echo "50"),
    "timeout": $([ "$is_apple_silicon" = true ] && echo "3600" || echo "7200"),
    "is_apple_silicon": $([ "$is_apple_silicon" = true ] && echo "true" || echo "false"),
    "use_mps": $([ "$is_apple_silicon" = true ] && echo "true" || echo "false"),
    "timestamp": "$(date +"%Y-%m-%d %H:%M:%S")"
}
EOL

print_message "Instalação concluída com sucesso!"
print_message "Para começar a usar o framework AutoML, execute:"
print_message "python3 -m inteligencia.automl.run_optimization optimize --symbol BTCUSDT --timeframe 1h"
