"""
Modificações no arquivo principal para integração com o framework AutoML
=========================================================

Este módulo modifica o arquivo principal do sistema KR_KRIPTO_FULL para
integrar o framework AutoML, permitindo o uso de modelos otimizados,
destilação de conhecimento e ensemble adaptativo.

Autor: Manus AI
Data: Abril 2025
Versão: 1.0.0
"""

import os
import sys
import json
import logging
from logging.handlers import TimedRotatingFileHandler
from datetime import datetime

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        TimedRotatingFileHandler('automl_integration_main.log', when='midnight', interval=1, backupCount=30),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('automl_integration_main')

# Verificar se estamos em um Mac com Apple Silicon
is_apple_silicon = False
try:
    import platform
    if platform.system() == 'Darwin' and platform.processor() == 'arm':
        is_apple_silicon = True
        logger.info("Detectado Mac com Apple Silicon")
        
        # Configurações específicas para Apple Silicon
        os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
        os.environ['PYTORCH_ENABLE_MPS_FALLBACK'] = '1'
except:
    pass

# Obter caminho do arquivo principal
try:
    main_file = sys.argv[1] if len(sys.argv) > 1 else "stream_binance_v115_corrigido_final_real_consolidado.py"
    
    if not os.path.exists(main_file):
        logger.error(f"Arquivo principal não encontrado: {main_file}")
        logger.error("Especifique o caminho correto como argumento")
        sys.exit(1)
    
    logger.info(f"Modificando arquivo principal: {main_file}")
except Exception as e:
    logger.error(f"Erro ao obter caminho do arquivo principal: {e}")
    sys.exit(1)

# Ler conteúdo do arquivo principal
try:
    with open(main_file, 'r') as f:
        content = f.read()
    
    logger.info(f"Arquivo principal lido com sucesso: {len(content)} bytes")
except Exception as e:
    logger.error(f"Erro ao ler arquivo principal: {e}")
    sys.exit(1)

# Criar backup do arquivo principal
try:
    backup_file = f"{main_file}.bak.{datetime.now().strftime('%Y%m%d%H%M%S')}"
    with open(backup_file, 'w') as f:
        f.write(content)
    
    logger.info(f"Backup do arquivo principal criado: {backup_file}")
except Exception as e:
    logger.error(f"Erro ao criar backup do arquivo principal: {e}")
    sys.exit(1)

# Definir importações do framework AutoML
automl_imports = """
# Importações do framework AutoML
try:
    from inteligencia.automl.automl_framework import AutoMLOptimizer, ModelDistiller, AdaptiveEnsemble
    from inteligencia.automl.kr_kripto_integration import KRKriptoAutoMLIntegration
    from inteligencia.automl.utils import check_apple_silicon, add_technical_indicators, create_sequences, detect_market_regime
    
    # Verificar se estamos em um Mac com Apple Silicon
    is_apple_silicon = check_apple_silicon()
    if is_apple_silicon:
        import os
        os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
        os.environ['PYTORCH_ENABLE_MPS_FALLBACK'] = '1'
        print("Configurações para Apple Silicon aplicadas")
    
    # Flag para indicar que o framework AutoML está disponível
    AUTOML_AVAILABLE = True
    print("Framework AutoML carregado com sucesso")
except ImportError as e:
    print(f"Aviso: Framework AutoML não disponível: {e}")
    print("O sistema funcionará sem as melhorias de AutoML")
    AUTOML_AVAILABLE = False
"""

# Definir inicialização do framework AutoML
automl_init = """
# Inicialização do framework AutoML
if AUTOML_AVAILABLE:
    try:
        # Diretórios para o framework AutoML
        automl_data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'dados')
        automl_models_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'modelos')
        automl_results_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resultados')
        
        # Criar diretórios se não existirem
        os.makedirs(automl_data_dir, exist_ok=True)
        os.makedirs(automl_models_dir, exist_ok=True)
        os.makedirs(automl_results_dir, exist_ok=True)
        
        # Inicializar integração
        automl_integration = KRKriptoAutoMLIntegration(
            data_dir=automl_data_dir,
            models_dir=automl_models_dir,
            results_dir=automl_results_dir
        )
        
        print(f"Integração AutoML inicializada")
        print(f"Diretório de dados: {automl_data_dir}")
        print(f"Diretório de modelos: {automl_models_dir}")
        print(f"Diretório de resultados: {automl_results_dir}")
    except Exception as e:
        print(f"Erro ao inicializar framework AutoML: {e}")
        print("O sistema funcionará sem as melhorias de AutoML")
        AUTOML_AVAILABLE = False
"""

# Definir função para usar ensemble adaptativo
automl_ensemble_function = """
def predict_with_automl_ensemble(market_data, symbol, timeframe):
    """
    Faz previsões usando o ensemble adaptativo do framework AutoML.
    
    Args:
        market_data: DataFrame com dados de mercado
        symbol: Símbolo do ativo
        timeframe: Timeframe dos dados
        
    Returns:
        Dicionário com resultados da previsão ou None se não disponível
    """
    if not AUTOML_AVAILABLE:
        return None
    
    try:
        # Caminho para a configuração do ensemble
        ensemble_config_path = os.path.join(
            automl_models_dir,
            f"ensemble_{symbol}_{timeframe}/ensemble_config.json"
        )
        
        # Verificar se a configuração do ensemble existe
        if not os.path.exists(ensemble_config_path):
            print(f"Configuração do ensemble não encontrada: {ensemble_config_path}")
            print("Execute 'python -m inteligencia.automl.run_optimization ensemble --symbol {symbol} --timeframe {timeframe}' para criar")
            return None
        
        # Fazer previsão com ensemble
        prediction = automl_integration.predict_with_ensemble(
            market_data=market_data,
            ensemble_config_path=ensemble_config_path,
            symbol=symbol,
            timeframe=timeframe
        )
        
        return prediction
    
    except Exception as e:
        print(f"Erro ao fazer previsão com ensemble: {e}")
        return None
"""

# Definir modificação para usar ensemble na tomada de decisão
automl_decision_modification = """
        # Usar ensemble adaptativo do framework AutoML se disponível
        if AUTOML_AVAILABLE:
            try:
                # Detectar regime de mercado
                market_regime = detect_market_regime(df)
                print(f"Regime de mercado detectado: {market_regime}")
                
                # Fazer previsão com ensemble
                ensemble_prediction = predict_with_automl_ensemble(df, symbol, timeframe)
                
                if ensemble_prediction:
                    prediction = ensemble_prediction['prediction']
                    confidence = ensemble_prediction['confidence']
                    weights = ensemble_prediction['weights']
                    
                    print(f"Previsão do ensemble: {prediction:.4f} (confiança: {confidence:.4f})")
                    print(f"Pesos do ensemble: {weights}")
                    
                    # Usar previsão do ensemble para tomada de decisão
                    if prediction > 0.65 and confidence > 0.3:  # Alta confiança em alta
                        print("Sinal de COMPRA do ensemble adaptativo")
                        # Modificar sinal para COMPRA
                        sinal = "COMPRA"
                    elif prediction < 0.35 and confidence > 0.3:  # Alta confiança em baixa
                        print("Sinal de VENDA do ensemble adaptativo")
                        # Modificar sinal para VENDA
                        sinal = "VENDA"
                    else:
                        print("Sem sinal claro do ensemble adaptativo, usando sistema original")
            except Exception as e:
                print(f"Erro ao usar ensemble adaptativo: {e}")
                print("Usando sistema original para tomada de decisão")
"""

# Modificar conteúdo do arquivo principal
try:
    # Adicionar importações do framework AutoML após as importações existentes
    import_end_marker = "import warnings"
    if import_end_marker in content:
        content = content.replace(import_end_marker, import_end_marker + automl_imports)
    else:
        # Se não encontrar o marcador, adicionar após a última importação
        import_lines = [line for line in content.split('\n') if line.strip().startswith('import ') or line.strip().startswith('from ')]
        if import_lines:
            last_import = import_lines[-1]
            content = content.replace(last_import, last_import + '\n' + automl_imports)
        else:
            # Se não encontrar nenhuma importação, adicionar no início do arquivo
            content = automl_imports + '\n' + content
    
    # Adicionar inicialização do framework AutoML após a definição de variáveis globais
    init_marker = "# Inicialização de variáveis globais"
    if init_marker in content:
        content = content.replace(init_marker, init_marker + '\n' + automl_init)
    else:
        # Se não encontrar o marcador, adicionar após a definição da função principal
        main_function_marker = "def main():"
        if main_function_marker in content:
            content = content.replace(main_function_marker, automl_init + '\n\n' + main_function_marker)
        else:
            # Se não encontrar a função principal, adicionar antes da primeira função
            function_lines = [line for line in content.split('\n') if line.strip().startswith('def ')]
            if function_lines:
                first_function = function_lines[0]
                content = content.replace(first_function, automl_init + '\n\n' + first_function)
            else:
                # Se não encontrar nenhuma função, adicionar no final do arquivo
                content += '\n\n' + automl_init
    
    # Adicionar função para usar ensemble adaptativo
    content += '\n\n' + automl_ensemble_function
    
    # Adicionar modificação para usar ensemble na tomada de decisão
    decision_marker = "# Tomada de decisão"
    if decision_marker in content:
        content = content.replace(decision_marker, decision_marker + '\n' + automl_decision_modification)
    else:
        # Se não encontrar o marcador, procurar por padrões comuns de tomada de decisão
        decision_patterns = [
            "if sinal == 'COMPRA':",
            "if sinal == \"COMPRA\":",
            "if resultado_final > 0:",
            "if score > threshold:"
        ]
        
        for pattern in decision_patterns:
            if pattern in content:
                content = content.replace(pattern, automl_decision_modification + '\n\n        ' + pattern)
                break
    
    logger.info("Modificações aplicadas com sucesso")
except Exception as e:
    logger.error(f"Erro ao modificar conteúdo do arquivo principal: {e}")
    sys.exit(1)

# Salvar arquivo modificado
try:
    with open(main_file, 'w') as f:
        f.write(content)
    
    logger.info(f"Arquivo principal modificado e salvo com sucesso: {main_file}")
except Exception as e:
    logger.error(f"Erro ao salvar arquivo principal modificado: {e}")
    sys.exit(1)

logger.info("Integração do framework AutoML concluída com sucesso!")
print(f"Arquivo principal modificado: {main_file}")
print(f"Backup criado: {backup_file}")
print("Integração do framework AutoML concluída com sucesso!")
