# src/intelligence/automl/kr_kripto_integration.py
from src.intelligence.automl.automl_framework import AutoMLOptimizer, ModelDistiller, AdaptiveEnsemble
import os
import sys
import logging
from logging.handlers import TimedRotatingFileHandler
import numpy as np
import pandas as pd
import tensorflow as tf
import torch

# Configurar logging
log_file = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'logs/automl.log')
os.makedirs(os.path.dirname(log_file), exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        TimedRotatingFileHandler(
            filename=log_file,
            when='midnight',
            interval=1,
            backupCount=30,
            encoding='utf-8'
        ),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('automl.kr_kripto_integration')

class KRKriptoAutoMLIntegration:
    """
    Classe para integração do framework AutoML com o sistema KR_KRIPTO_FULL.
    
    Esta classe fornece métodos para integrar os modelos otimizados, destilados
    e ensembles adaptativos com o sistema principal de trading.
    """
    
    def __init__(self, config: dict):
        """
        Inicializa a integração com o sistema KR_KRIPTO_FULL.
        
        Args:
            dataframes (dict): Dicionário de dataframes históricos.
            memoria_temporal (object): Instância da memória temporal (tipo genérico para evitar import circular).
            config (dict, optional): Configurações adicionais para a integração.
        """
        self.dataframes = dataframes
        self.memoria_temporal = memoria_temporal
        self.config = config or {}
        self.models = {}
        self.ensembles = {}
        self.base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        
        # Detectar Apple Silicon
        self.is_apple_silicon = self._detect_apple_silicon()
        if self.is_apple_silicon:
            logger.info("Detectado Apple Silicon. Aplicando configurações otimizadas.")
            self._configure_for_apple_silicon()
    
    def _detect_apple_silicon(self):
        """
        Detecta se o sistema está rodando em Apple Silicon.
        
        Returns:
            bool: True se for Apple Silicon, False caso contrário.
        """
        try:
            import platform
            if platform.system() == 'Darwin':
                # Verificar se é Apple Silicon
                return platform.processor() == 'arm'
            return False
        except:
            return False
    
    def _configure_for_apple_silicon(self):
        """
        Configura o ambiente para otimização em Apple Silicon.
        """
        try:
            # Configurar TensorFlow para usar Metal
            tf.config.experimental.set_visible_devices([], 'GPU')
            
            # Configurar PyTorch para usar MPS
            if hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
                logger.info("MPS disponível. PyTorch usará aceleração Metal.")
            else:
                logger.info("MPS não disponível. PyTorch usará CPU.")
        except Exception as e:
            logger.warning(f"Erro ao configurar para Apple Silicon: {e}")
    
    def load_models(self, symbol, timeframe):
        """
        Carrega modelos otimizados para um par e timeframe específicos.
        
        Args:
            symbol (str): Símbolo do par (ex: BTCUSDT)
            timeframe (str): Timeframe (ex: 1h)
            
        Returns:
            dict: Dicionário com os modelos carregados
        """
        models = {}
        model_types = ['transformer', 'lstm', 'distilled']
        
        for model_type in model_types:
            model_path = os.path.join(
                self.base_dir,
                f'modelos/automl_{symbol}_{timeframe}_{model_type}.pkl'
            )
            
            if os.path.exists(model_path):
                try:
                    if model_type == 'transformer':
                        from src.intelligence.modelos_transformer.transformer_model import TransformerModel
                        models[model_type] = TransformerModel.load(model_path)
                    elif model_type == 'lstm':
                        from src.intelligence.modelos_lstm.lstm_model import LSTMModel
                        models[model_type] = LSTMModel.load(model_path)
                    elif model_type == 'distilled':
                        models[model_type] = ModelDistiller.load_student(model_path)
                    
                    logger.info(f"Modelo {model_type} carregado com sucesso para {symbol} {timeframe}")
                except Exception as e:
                    logger.error(f"Erro ao carregar modelo {model_type}: {e}")
            else:
                logger.warning(f"Modelo {model_type} não encontrado em {model_path}")
        
        self.models[(symbol, timeframe)] = models
        return models
    
    def load_ensemble(self, symbol, timeframe):
        """
        Carrega ensemble adaptativo para um par e timeframe específicos.
        
        Args:
            symbol (str): Símbolo do par (ex: BTCUSDT)
            timeframe (str): Timeframe (ex: 1h)
            
        Returns:
            AdaptiveEnsemble: Ensemble adaptativo carregado
        """
        ensemble_path = os.path.join(
            self.base_dir,
            f'modelos/automl_{symbol}_{timeframe}_ensemble.pkl'
        )
        
        if os.path.exists(ensemble_path):
            try:
                ensemble = AdaptiveEnsemble.load(ensemble_path)
                logger.info(f"Ensemble carregado com sucesso para {symbol} {timeframe}")
                self.ensembles[(symbol, timeframe)] = ensemble
                return ensemble
            except Exception as e:
                logger.error(f"Erro ao carregar ensemble: {e}")
                return None
        else:
            logger.warning(f"Ensemble não encontrado em {ensemble_path}")
            return None
    
    def predict(self, data, symbol, timeframe, use_ensemble=True):
        """
        Faz previsões usando modelos otimizados ou ensemble.
        
        Args:
            data (pd.DataFrame): Dados de mercado
            symbol (str): Símbolo do par (ex: BTCUSDT)
            timeframe (str): Timeframe (ex: 1h)
            use_ensemble (bool): Se True, usa ensemble adaptativo se disponível
            
        Returns:
            np.ndarray: Array com previsões
        """
        # Pré-processar dados
        X = self._preprocess_data(data)
        
        # Tentar usar ensemble
        if use_ensemble:
            if (symbol, timeframe) not in self.ensembles:
                self.load_ensemble(symbol, timeframe)
            
            if (symbol, timeframe) in self.ensembles and self.ensembles[(symbol, timeframe)] is not None:
                return self.ensembles[(symbol, timeframe)].predict(X)
        
        # Fallback para modelos individuais
        if (symbol, timeframe) not in self.models:
            self.load_models(symbol, timeframe)
        
        models = self.models.get((symbol, timeframe), {})
        
        # Prioridade: transformer > distilled > lstm
        for model_type in ['transformer', 'distilled', 'lstm']:
            if model_type in models and models[model_type] is not None:
                return models[model_type].predict(X)
        
        # Se nenhum modelo estiver disponível, retornar zeros
        logger.warning(f"Nenhum modelo disponível para {symbol} {timeframe}. Retornando zeros.")
        return np.zeros(len(X))
    
    def _preprocess_data(self, data):
        """
        Pré-processa dados para previsão.
        
        Args:
            data (pd.DataFrame): Dados de mercado
            
        Returns:
            np.ndarray: Dados pré-processados
        """
        # Implementação simplificada - em um sistema real, isso seria mais complexo
        # e alinhado com o pré-processamento usado durante o treinamento
        features = data[['open', 'high', 'low', 'close', 'volume']].values
        
        # Normalização
        mean = features.mean(axis=0)
        std = features.std(axis=0)
        normalized = (features - mean) / (std + 1e-8)
        
        return normalized
    
    def integrate_with_main_system(self, symbol, timeframe):
        """
        Integra modelos AutoML com o sistema principal.
        
        Args:
            symbol (str): Símbolo do par (ex: BTCUSDT)
            timeframe (str): Timeframe (ex: 1h)
            
        Returns:
            bool: True se a integração foi bem-sucedida, False caso contrário
        """
        try:
            # Carregar ensemble e modelos
            ensemble = self.load_ensemble(symbol, timeframe)
            models = self.load_models(symbol, timeframe)
            
            # Verificar se pelo menos um modelo foi carregado
            if not ensemble and not models:
                logger.error(f"Nenhum modelo ou ensemble disponível para {symbol} {timeframe}")
                return False
            
            logger.info(f"Integração com sistema principal concluída para {symbol} {timeframe}")
            return True
        except Exception as e:
            logger.error(f"Erro durante integração com sistema principal: {e}")
            return False
    
    def get_model_info(self, symbol, timeframe):
        """
        Obtém informações sobre os modelos disponíveis.
        
        Args:
            symbol (str): Símbolo do par (ex: BTCUSDT)
            timeframe (str): Timeframe (ex: 1h)
            
        Returns:
            dict: Informações sobre os modelos
        """
        info = {
            'symbol': symbol,
            'timeframe': timeframe,
            'models': {},
            'ensemble': None
        }
        
        # Verificar modelos
        if (symbol, timeframe) not in self.models:
            self.load_models(symbol, timeframe)
        
        models = self.models.get((symbol, timeframe), {})
        for model_type, model in models.items():
            if model is not None:
                info['models'][model_type] = {
                    'available': True,
                    'path': os.path.join(self.base_dir, f'modelos/automl_{symbol}_{timeframe}_{model_type}.pkl')
                }
            else:
                info['models'][model_type] = {
                    'available': False,
                    'path': None
                }
        
        # Verificar ensemble
        if (symbol, timeframe) not in self.ensembles:
            self.load_ensemble(symbol, timeframe)
        
        ensemble = self.ensembles.get((symbol, timeframe))
        if ensemble is not None:
            info['ensemble'] = {
                'available': True,
                'path': os.path.join(self.base_dir, f'modelos/automl_{symbol}_{timeframe}_ensemble.pkl')
            }
        else:
            info['ensemble'] = {
                'available': False,
                'path': None
            }
        
        return info
