#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para execução de otimização de modelos com AutoML.

Este módulo fornece uma interface de linha de comando para otimizar modelos,
aplicar destilação de conhecimento, criar ensembles adaptativos e fazer previsões.
"""

import os
import sys
import argparse
import logging
from datetime import datetime
import json
import numpy as np
import pandas as pd
import tensorflow as tf
import torch
from logging.handlers import TimedRotatingFileHandler

# Configurar logging
log_file = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'logs/automl.log')
os.makedirs(os.path.dirname(log_file), exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        TimedRotatingFileHandler(
            filename=log_file,
            when='midnight',
            interval=1,
            backupCount=30,
            encoding='utf-8'
        ),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('automl.run_optimization')

# Importar componentes do framework AutoML
try:
    from inteligencia.automl.automl_framework import AutoMLOptimizer, ModelDistiller, AdaptiveEnsemble
    from inteligencia.automl.kr_kripto_integration import KrKriptoIntegration
    from inteligencia.automl.utils import load_data, preprocess_data, evaluate_model
except ImportError as e:
    logger.error(f"Erro ao importar componentes do AutoML: {e}")
    sys.exit(1)

# Definir comandos disponíveis
AVAILABLE_COMMANDS = ['optimize', 'distill', 'ensemble', 'predict']

def optimize(args):
    """
    Otimiza hiperparâmetros para modelos de IA.
    
    Args:
        args: Argumentos da linha de comando
    """
    logger.info(f"Iniciando otimização para {args.symbol} em timeframe {args.timeframe}")
    
    try:
        # Carregar dados
        data = load_data(symbol=args.symbol, timeframe=args.timeframe, 
                         start_date=args.start_date, end_date=args.end_date)
        
        # Pré-processar dados
        X_train, X_val, y_train, y_val = preprocess_data(data)
        
        # Configurar otimizador
        optimizer = AutoMLOptimizer(
            model_type=args.model_type,
            n_trials=args.n_trials,
            timeout=args.timeout,
            metric=args.metric
        )
        
        # Executar otimização
        best_params, best_model = optimizer.optimize(
            X_train, y_train, X_val, y_val,
            batch_size=args.batch_size,
            epochs=args.epochs,
            force_retrain=args.force_retrain
        )
        
        # Salvar resultados
        model_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
            f'modelos/automl_{args.symbol}_{args.timeframe}_{args.model_type}.pkl'
        )
        optimizer.save_model(best_model, model_path)
        
        # Salvar hiperparâmetros
        params_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
            f'modelos/automl_{args.symbol}_{args.timeframe}_{args.model_type}_params.json'
        )
        with open(params_path, 'w') as f:
            json.dump(best_params, f, indent=4)
        
        # Avaliar modelo
        metrics = evaluate_model(best_model, X_val, y_val)
        logger.info(f"Otimização concluída. Métricas: {metrics}")
        logger.info(f"Modelo salvo em: {model_path}")
        logger.info(f"Parâmetros salvos em: {params_path}")
        
    except Exception as e:
        logger.error(f"Erro durante otimização: {e}")
        raise

def distill(args):
    """
    Aplica destilação de conhecimento para criar modelos mais leves.
    
    Args:
        args: Argumentos da linha de comando
    """
    logger.info(f"Iniciando destilação para {args.symbol} em timeframe {args.timeframe}")
    
    try:
        # Carregar dados
        data = load_data(symbol=args.symbol, timeframe=args.timeframe, 
                         start_date=args.start_date, end_date=args.end_date)
        
        # Pré-processar dados
        X_train, X_val, y_train, y_val = preprocess_data(data)
        
        # Carregar modelo professor
        teacher_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
            f'modelos/automl_{args.symbol}_{args.timeframe}_transformer.pkl'
        )
        
        # Configurar destilador
        distiller = ModelDistiller(
            teacher_path=teacher_path,
            temperature=args.temperature,
            alpha=args.alpha
        )
        
        # Executar destilação
        student_model = distiller.distill(
            X_train, y_train, X_val, y_val,
            batch_size=args.batch_size,
            epochs=args.epochs
        )
        
        # Salvar modelo aluno
        student_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
            f'modelos/automl_{args.symbol}_{args.timeframe}_distilled.pkl'
        )
        distiller.save_model(student_model, student_path)
        
        # Avaliar modelo
        metrics = evaluate_model(student_model, X_val, y_val)
        logger.info(f"Destilação concluída. Métricas: {metrics}")
        logger.info(f"Modelo destilado salvo em: {student_path}")
        
    except Exception as e:
        logger.error(f"Erro durante destilação: {e}")
        raise

def ensemble(args):
    """
    Cria um ensemble adaptativo de modelos.
    
    Args:
        args: Argumentos da linha de comando
    """
    logger.info(f"Criando ensemble para {args.symbol} em timeframe {args.timeframe}")
    
    try:
        # Carregar dados
        data = load_data(symbol=args.symbol, timeframe=args.timeframe, 
                         start_date=args.start_date, end_date=args.end_date)
        
        # Pré-processar dados
        X_train, X_val, y_train, y_val = preprocess_data(data)
        
        # Definir caminhos dos modelos
        model_paths = {
            'transformer': os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                f'modelos/automl_{args.symbol}_{args.timeframe}_transformer.pkl'
            ),
            'lstm': os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                f'modelos/automl_{args.symbol}_{args.timeframe}_lstm.pkl'
            ),
            'distilled': os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                f'modelos/automl_{args.symbol}_{args.timeframe}_distilled.pkl'
            )
        }
        
        # Configurar ensemble
        ensemble = AdaptiveEnsemble(
            model_paths=model_paths,
            detection_window=args.detection_window
        )
        
        # Treinar ensemble
        ensemble.train(X_train, y_train, X_val, y_val)
        
        # Salvar ensemble
        ensemble_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
            f'modelos/automl_{args.symbol}_{args.timeframe}_ensemble.pkl'
        )
        ensemble.save(ensemble_path)
        
        # Avaliar ensemble
        metrics = ensemble.evaluate(X_val, y_val)
        logger.info(f"Ensemble criado. Métricas: {metrics}")
        logger.info(f"Ensemble salvo em: {ensemble_path}")
        
    except Exception as e:
        logger.error(f"Erro durante criação do ensemble: {e}")
        raise

def predict(args):
    """
    Faz previsões usando modelos otimizados.
    
    Args:
        args: Argumentos da linha de comando
    """
    logger.info(f"Fazendo previsões para {args.symbol} em timeframe {args.timeframe}")
    
    try:
        # Carregar dados recentes
        data = load_data(symbol=args.symbol, timeframe=args.timeframe, 
                         limit=args.limit)
        
        # Pré-processar dados
        X, _, _, _ = preprocess_data(data, test_only=True)
        
        # Carregar ensemble ou modelo individual
        if args.use_ensemble:
            model_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                f'modelos/automl_{args.symbol}_{args.timeframe}_ensemble.pkl'
            )
            model = AdaptiveEnsemble.load(model_path)
            predictions = model.predict(X)
        else:
            model_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                f'modelos/automl_{args.symbol}_{args.timeframe}_{args.model_type}.pkl'
            )
            # Carregar modelo específico
            if args.model_type == 'transformer':
                from inteligencia.modelos_transformer.transformer_model import TransformerModel
                model = TransformerModel.load(model_path)
            elif args.model_type == 'lstm':
                from inteligencia.modelos_lstm.lstm_model import LSTMModel
                model = LSTMModel.load(model_path)
            elif args.model_type == 'distilled':
                from inteligencia.automl.automl_framework import ModelDistiller
                model = ModelDistiller.load_student(model_path)
            
            predictions = model.predict(X)
        
        # Salvar previsões
        results_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
            f'resultados/previsoes_{args.symbol}_{args.timeframe}.csv'
        )
        
        # Formatar resultados
        results = pd.DataFrame({
            'timestamp': data.index[-len(predictions):],
            'close': data['close'].values[-len(predictions):],
            'prediction': predictions,
            'signal': np.where(predictions > args.threshold, 1, np.where(predictions < -args.threshold, -1, 0))
        })
        
        results.to_csv(results_path, index=False)
        logger.info(f"Previsões concluídas e salvas em: {results_path}")
        
        # Exibir últimas previsões
        print("\nÚltimas previsões:")
        print(results.tail(10))
        
    except Exception as e:
        logger.error(f"Erro durante previsão: {e}")
        raise

def main():
    """
    Função principal para processamento de argumentos da linha de comando.
    """
    parser = argparse.ArgumentParser(description='Ferramenta de otimização AutoML para KR_KRIPTO_FULL')
    subparsers = parser.add_subparsers(dest='command', help='Comando a ser executado')
    
    # Parser para comando 'optimize'
    optimize_parser = subparsers.add_parser('optimize', help='Otimizar hiperparâmetros')
    optimize_parser.add_argument('--symbol', type=str, required=True, help='Símbolo (ex: BTCUSDT)')
    optimize_parser.add_argument('--timeframe', type=str, default='1h', help='Timeframe (ex: 1m, 5m, 15m, 1h, 4h, 1d)')
    optimize_parser.add_argument('--model-type', type=str, default='transformer', choices=['transformer', 'lstm', 'both'], help='Tipo de modelo')
    optimize_parser.add_argument('--n-trials', type=int, default=20, help='Número de tentativas de otimização')
    optimize_parser.add_argument('--timeout', type=int, default=3600, help='Timeout em segundos')
    optimize_parser.add_argument('--batch-size', type=int, default=64, help='Tamanho do batch')
    optimize_parser.add_argument('--epochs', type=int, default=50, help='Número de épocas')
    optimize_parser.add_argument('--metric', type=str, default='sharpe', choices=['accuracy', 'f1', 'sharpe', 'sortino'], help='Métrica para otimização')
    optimize_parser.add_argument('--start-date', type=str, default=None, help='Data inicial (YYYY-MM-DD)')
    optimize_parser.add_argument('--end-date', type=str, default=None, help='Data final (YYYY-MM-DD)')
    optimize_parser.add_argument('--force-retrain', action='store_true', help='Forçar retreinamento mesmo se existir modelo')
    
    # Parser para comando 'distill'
    distill_parser = subparsers.add_parser('distill', help='Aplicar destilação de conhecimento')
    distill_parser.add_argument('--symbol', type=str, required=True, help='Símbolo (ex: BTCUSDT)')
    distill_parser.add_argument('--timeframe', type=str, default='1h', help='Timeframe (ex: 1m, 5m, 15m, 1h, 4h, 1d)')
    distill_parser.add_argument('--temperature', type=float, default=2.0, help='Temperatura para destilação')
    distill_parser.add_argument('--alpha', type=float, default=0.5, help='Peso para balancear perdas')
    distill_parser.add_argument('--batch-size', type=int, default=64, help='Tamanho do batch')
    distill_parser.add_argument('--epochs', type=int, default=30, help='Número de épocas')
    distill_parser.add_argument('--start-date', type=str, default=None, help='Data inicial (YYYY-MM-DD)')
    distill_parser.add_argument('--end-date', type=str, default=None, help='Data final (YYYY-MM-DD)')
    
    # Parser para comando 'ensemble'
    ensemble_parser = subparsers.add_parser('ensemble', help='Criar ensemble adaptativo')
    ensemble_parser.add_argument('--symbol', type=str, required=True, help='Símbolo (ex: BTCUSDT)')
    ensemble_parser.add_argument('--timeframe', type=str, default='1h', help='Timeframe (ex: 1m, 5m, 15m, 1h, 4h, 1d)')
    ensemble_parser.add_argument('--detection-window', type=int, default=20, help='Janela para detecção de regime')
    ensemble_parser.add_argument('--start-date', type=str, default=None, help='Data inicial (YYYY-MM-DD)')
    ensemble_parser.add_argument('--end-date', type=str, default=None, help='Data final (YYYY-MM-DD)')
    
    # Parser para comando 'predict'
    predict_parser = subparsers.add_parser('predict', help='Fazer previsões')
    predict_parser.add_argument('--symbol', type=str, required=True, help='Símbolo (ex: BTCUSDT)')
    predict_parser.add_argument('--timeframe', type=str, default='1h', help='Timeframe (ex: 1m, 5m, 15m, 1h, 4h, 1d)')
    predict_parser.add_argument('--model-type', type=str, default='transformer', choices=['transformer', 'lstm', 'distilled'], help='Tipo de modelo')
    predict_parser.add_argument('--use-ensemble', action='store_true', help='Usar ensemble adaptativo')
    predict_parser.add_argument('--limit', type=int, default=100, help='Número de candles a carregar')
    predict_parser.add_argument('--threshold', type=float, default=0.5, help='Limiar para sinal')
    
    args = parser.parse_args()
    
    # Verificar se o comando é válido
    if args.command not in AVAILABLE_COMMANDS:
        parser.print_help()
        sys.exit(1)
    
    # Criar diretórios necessários
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    os.makedirs(os.path.join(base_dir, 'modelos'), exist_ok=True)
    os.makedirs(os.path.join(base_dir, 'logs'), exist_ok=True)
    os.makedirs(os.path.join(base_dir, 'resultados'), exist_ok=True)
    
    # Executar comando
    try:
        if args.command == 'optimize':
            optimize(args)
        elif args.command == 'distill':
            distill(args)
        elif args.command == 'ensemble':
            ensemble(args)
        elif args.command == 'predict':
            predict(args)
    except Exception as e:
        logger.error(f"Erro ao executar comando {args.command}: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
