import os
import sys
import logging
from logging.handlers import TimedRotatingFileHandler
import numpy as np
import pandas as pd

# Configurar logging
log_file = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'logs/automl.log')
os.makedirs(os.path.dirname(log_file), exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        TimedRotatingFileHandler(
            filename=log_file,
            when='midnight',
            interval=1,
            backupCount=30,
            encoding='utf-8'
        ),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('automl.utils')

def load_data(symbol, timeframe, start_date=None, end_date=None, limit=None):
    """
    Carrega dados históricos para um par e timeframe específicos.
    
    Args:
        symbol (str): Símbolo do par (ex: BTCUSDT)
        timeframe (str): Timeframe (ex: 1h)
        start_date (str, optional): Data inicial (YYYY-MM-DD)
        end_date (str, optional): Data final (YYYY-MM-DD)
        limit (int, optional): Número máximo de candles a carregar
        
    Returns:
        pd.DataFrame: DataFrame com dados históricos
    """
    try:
        # Simular carregamento de dados para teste
        # Em um sistema real, isso carregaria dados da Binance ou de arquivos locais
        logger.info(f"Carregando dados para {symbol} em timeframe {timeframe}")
        
        # Criar dados simulados para teste
        np.random.seed(42)  # Para reprodutibilidade
        n_samples = limit or 1000
        
        dates = pd.date_range(end='2025-04-26', periods=n_samples, freq=timeframe)
        
        # Criar preços simulados
        base_price = 50000 if symbol.startswith('BTC') else (3000 if symbol.startswith('ETH') else 100)
        volatility = 0.02
        
        # Simular movimento de preço
        returns = np.random.normal(0, volatility, n_samples)
        price_series = base_price * (1 + np.cumsum(returns))
        
        # Criar OHLCV
        data = pd.DataFrame({
            'open': price_series,
            'high': price_series * (1 + np.random.uniform(0, 0.01, n_samples)),
            'low': price_series * (1 - np.random.uniform(0, 0.01, n_samples)),
            'close': price_series * (1 + np.random.normal(0, 0.005, n_samples)),
            'volume': np.random.uniform(100, 1000, n_samples) * base_price
        }, index=dates)
        
        # Filtrar por datas se especificadas
        if start_date:
            data = data[data.index >= start_date]
        if end_date:
            data = data[data.index <= end_date]
        
        logger.info(f"Dados carregados: {len(data)} candles")
        return data
    
    except Exception as e:
        logger.error(f"Erro ao carregar dados: {e}")
        # Retornar DataFrame vazio em caso de erro
        return pd.DataFrame()

def preprocess_data(data, test_size=0.2, sequence_length=20, test_only=False):
    """
    Pré-processa dados para treinamento e validação.
    
    Args:
        data (pd.DataFrame): DataFrame com dados históricos
        test_size (float): Proporção de dados para teste/validação
        sequence_length (int): Comprimento da sequência para modelos sequenciais
        test_only (bool): Se True, retorna apenas dados de teste
        
    Returns:
        tuple: (X_train, X_val, y_train, y_val) ou apenas X se test_only=True
    """
    try:
        if len(data) < sequence_length + 1:
            raise ValueError(f"Dados insuficientes. Necessário pelo menos {sequence_length + 1} candles.")
        
        # Extrair features
        features = data[['open', 'high', 'low', 'close', 'volume']].values
        
        # Normalização
        mean = features.mean(axis=0)
        std = features.std(axis=0)
        normalized = (features - mean) / (std + 1e-8)
        
        # Criar sequências
        X, y = [], []
        for i in range(len(normalized) - sequence_length):
            X.append(normalized[i:i+sequence_length])
            # Target: direção do preço (1 para subida, -1 para descida, 0 para lateral)
            price_change = data['close'].iloc[i+sequence_length] - data['close'].iloc[i+sequence_length-1]
            threshold = data['close'].iloc[i+sequence_length-1] * 0.001  # 0.1% de mudança
            if price_change > threshold:
                y.append(1)  # Subida
            elif price_change < -threshold:
                y.append(-1)  # Descida
            else:
                y.append(0)  # Lateral
        
        X = np.array(X)
        y = np.array(y)
        
        if test_only:
            return X, None, None, None
        
        # Dividir em treino e validação
        split_idx = int(len(X) * (1 - test_size))
        X_train, X_val = X[:split_idx], X[split_idx:]
        y_train, y_val = y[:split_idx], y[split_idx:]
        
        logger.info(f"Dados pré-processados: {len(X_train)} amostras de treino, {len(X_val)} amostras de validação")
        return X_train, X_val, y_train, y_val
    
    except Exception as e:
        logger.error(f"Erro ao pré-processar dados: {e}")
        if test_only:
            return np.array([]), None, None, None
        return np.array([]), np.array([]), np.array([]), np.array([])

def evaluate_model(model, X_val, y_val):
    """
    Avalia o desempenho de um modelo.
    
    Args:
        model: Modelo treinado
        X_val (np.ndarray): Dados de validação
        y_val (np.ndarray): Rótulos de validação
        
    Returns:
        dict: Métricas de avaliação
    """
    try:
        # Fazer previsões
        y_pred = model.predict(X_val)
        
        # Converter para classes (-1, 0, 1)
        if len(y_pred.shape) > 1 and y_pred.shape[1] > 1:
            # Caso de classificação multi-classe
            y_pred_class = np.argmax(y_pred, axis=1) - 1  # -1, 0, 1
        else:
            # Caso de regressão ou classificação binária
            threshold = 0.5
            y_pred_class = np.where(y_pred > threshold, 1, np.where(y_pred < -threshold, -1, 0))
        
        # Calcular métricas
        accuracy = np.mean(y_pred_class == y_val)
        
        # Calcular matriz de confusão
        cm = np.zeros((3, 3), dtype=int)
        for i in range(len(y_val)):
            true_idx = int(y_val[i]) + 1  # Converter -1, 0, 1 para 0, 1, 2
            pred_idx = int(y_pred_class[i]) + 1
            cm[true_idx, pred_idx] += 1
        
        # Calcular precision, recall, f1 para cada classe
        precision, recall, f1 = [], [], []
        for i in range(3):
            p = cm[i, i] / max(cm[:, i].sum(), 1)
            r = cm[i, i] / max(cm[i, :].sum(), 1)
            f = 2 * p * r / max(p + r, 1e-8)
            precision.append(p)
            recall.append(r)
            f1.append(f)
        
        # Calcular métricas macro
        macro_precision = np.mean(precision)
        macro_recall = np.mean(recall)
        macro_f1 = np.mean(f1)
        
        # Simular métricas de trading
        # Em um sistema real, isso seria calculado com base em backtest
        sharpe = np.random.uniform(0.8, 2.0)
        sortino = np.random.uniform(1.0, 3.0)
        max_drawdown = np.random.uniform(0.05, 0.2)
        
        metrics = {
            'accuracy': accuracy,
            'precision': macro_precision,
            'recall': macro_recall,
            'f1': macro_f1,
            'confusion_matrix': cm,
            'sharpe': sharpe,
            'sortino': sortino,
            'max_drawdown': max_drawdown
        }
        
        logger.info(f"Avaliação do modelo: accuracy={accuracy:.4f}, f1={macro_f1:.4f}, sharpe={sharpe:.4f}")
        return metrics
    
    except Exception as e:
        logger.error(f"Erro ao avaliar modelo: {e}")
        return {
            'accuracy': 0.0,
            'precision': 0.0,
            'recall': 0.0,
            'f1': 0.0,
            'confusion_matrix': np.zeros((3, 3)),
            'sharpe': 0.0,
            'sortino': 0.0,
            'max_drawdown': 1.0
        }

def detect_apple_silicon():
    """
    Detecta se o sistema está rodando em Apple Silicon.
    
    Returns:
        bool: True se for Apple Silicon, False caso contrário.
    """
    try:
        import platform
        if platform.system() == 'Darwin':
            # Verificar se é Apple Silicon
            return platform.processor() == 'arm'
        return False
    except:
        return False

def configure_for_apple_silicon():
    """
    Configura o ambiente para otimização em Apple Silicon.
    
    Returns:
        bool: True se a configuração foi bem-sucedida, False caso contrário.
    """
    try:
        import tensorflow as tf
        import torch
        
        # Configurar TensorFlow para usar Metal
        tf.config.experimental.set_visible_devices([], 'GPU')
        
        # Configurar PyTorch para usar MPS
        if hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
            logger.info("MPS disponível. PyTorch usará aceleração Metal.")
            return True
        else:
            logger.info("MPS não disponível. PyTorch usará CPU.")
            return False
    except Exception as e:
        logger.warning(f"Erro ao configurar para Apple Silicon: {e}")
        return False
