# src/intelligence/automl/utils/utils.py
import platform
import logging

logger = logging.getLogger(__name__) # Use specific logger

def detect_apple_silicon():
    """
    Detecta se o sistema está rodando em Apple Silicon.
    
    Returns:
        bool: True se for Apple Silicon, False caso contrário.
    """
    try:
        if platform.system() == 'Darwin':
            # Verificar se é Apple Silicon
            is_arm = platform.processor() == 'arm'
            logger.debug(f"Apple Silicon detection: system=Darwin, processor={platform.processor()}, is_arm={is_arm}")
            return is_arm
        logger.debug(f"Apple Silicon detection: system={platform.system()}, not Darwin")
        return False
    except Exception as e:
        logger.error(f"Error during Apple Silicon detection: {e}", exc_info=True)
        return False

