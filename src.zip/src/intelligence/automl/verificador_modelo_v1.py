
import hashlib

def validar_modelo_sha256(path_modelo: str, sha256_esperado: str) -> bool:
    """Valida o hash SHA256 de um arquivo .h5."""
    try:
        with open(path_modelo, 'rb') as f:
            file_hash = hashlib.sha256(f.read()).hexdigest()
        return file_hash == sha256_esperado
    except FileNotFoundError:
        print(f"❌ Arquivo não encontrado: {path_modelo}")
        return False
    except Exception as e:
        print(f"Erro ao validar modelo: {e}")
        return False
