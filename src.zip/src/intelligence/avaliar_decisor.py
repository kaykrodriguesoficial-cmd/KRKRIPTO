# src/intelligence/avaliar_decisor.py
import pandas as pd
import logging

logger = logging.getLogger("kr_kripto_decisor")

def avaliar_decisao_por_similaridade(df: pd.DataFrame, score: float):
    logger.debug(f"avaliar_decisao_por_similaridade (stub) chamado com score {score}.")
    # Retorna uma similaridade placeholder
    return 0.5

