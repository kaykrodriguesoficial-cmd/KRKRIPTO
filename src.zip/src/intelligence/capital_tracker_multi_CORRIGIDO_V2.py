
import os
import json
from datetime import datetime
import pandas as pd
from inteligencia.log_por_ativo import registrar_log

PASTA_CAPITAL = "capital"
PASTA_CURVA = "curva_capital"

os.makedirs(PASTA_CAPITAL, exist_ok=True)
os.makedirs(PASTA_CURVA, exist_ok=True)

def _caminho_arquivo(ativo):
    return os.path.join(PASTA_CAPITAL, f"capital_{ativo}.json")

def _caminho_curva(ativo):
    return os.path.join(PASTA_CURVA, f"{ativo}.csv")

def inicializar_capital(ativo, valor_inicial=10000.0):
    caminho = _caminho_arquivo(ativo)
    if not os.path.exists(caminho):
        with open(caminho, "w") as f:
            json.dump({"capital": valor_inicial}, f)
        registrar_log(ativo, f"💰 Capital inicializado com ${valor_inicial:.2f}", "capital_tracker_multi")

def resetar_capital(ativo, novo_valor=10000.0):
    caminho = _caminho_arquivo(ativo)
    with open(caminho, "w") as f:
        json.dump({"capital": novo_valor}, f)
    registrar_log(ativo, f"🔁 Capital resetado para ${novo_valor:.2f}", "capital_tracker_multi")

def obter_capital(ativo):
    caminho = _caminho_arquivo(ativo)
    if not os.path.exists(caminho):
        inicializar_capital(ativo)
    try:
        with open(caminho, "r") as f:
            return json.load(f)["capital"]
    except Exception as e:
        registrar_log(ativo, f"⚠️ Erro ao ler capital: {e}", "capital_tracker_multi", "ERROR")
        return 10000.0

def atualizar_capital(ativo, lucro_prejuizo):
    capital_atual = obter_capital(ativo)
    novo_capital = capital_atual + lucro_prejuizo
    caminho = _caminho_arquivo(ativo)
    try:
        with open(caminho, "w") as f:
            json.dump({"capital": novo_capital}, f)
        registrar_log(ativo, f"💹 Capital atualizado: {capital_atual:.2f} → {novo_capital:.2f} | PnL={lucro_prejuizo:.2f}", "capital_tracker_multi")

        # Atualizar curva de capital
        df = pd.DataFrame([{
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "capital": novo_capital,
            "lucro_prejuizo": lucro_prejuizo
        }])
        curva_path = _caminho_curva(ativo)
        df.to_csv(curva_path, mode="a", header=not os.path.exists(curva_path), index=False)

    except Exception as e:
        registrar_log(ativo, f"❌ Erro ao atualizar capital: {e}", "capital_tracker_multi", "ERROR")

    return novo_capital
