
def calcular_resultado_real(df, n=5):
    if len(df) < n + 1:
        return 0.0
    preco_entrada = df.iloc[-(n+1)]['close']
    preco_saida = df.iloc[-1]['close']
    return (preco_saida - preco_entrada) / preco_entrada

def executar_ciclo_resultado(df_candles, score_ia_fusao, dados_input):
    from inteligencia.autoavaliador_critico import avaliar_erro_ia

    if score_ia_fusao >= 0.75:
        decisao_final = 'compra'
    elif score_ia_fusao <= 0.25:
        decisao_final = 'venda'
    else:
        decisao_final = 'nada'

    if decisao_final in ['compra', 'venda']:
        print(f"[IA] Decisão tomada: {decisao_final} com score {score_ia_fusao:.2f}")

        resultado_5_candles = calcular_resultado_real(df_candles)

        try:
            dados_input['score_ia_fusao'] = score_ia_fusao
            avaliar_erro_ia(dados_input, resultado_5_candles)
            print(f"[AUTOAVALIADOR] Resultado: {resultado_5_candles:.4f} registrado com sucesso.")
        except Exception as e:
            print(f"[AUTOAVALIADOR] Erro ao registrar crítica: {e}")
