
import requests
from executors.logger import log_erro

TELEGRAM_TOKEN = "YOUR_BOT_TOKEN"
TELEGRAM_CHAT_ID = "YOUR_CHAT_ID"

def enviar_alerta_telegram(mensagem):
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        payload = {
            "chat_id": TELEGRAM_CHAT_ID,
            "text": mensagem,
            "parse_mode": "Markdown"
        }
        response = requests.post(url, data=payload)
        if response.status_code != 200:
            log_erro(f"[TELEGRAM] Falha ao enviar mensagem: {response.text}")
    except Exception as e:
        log_erro(f"[TELEGRAM] Erro de integração: {e}")
