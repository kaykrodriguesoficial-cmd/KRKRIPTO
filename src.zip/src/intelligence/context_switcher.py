import pandas as pd
import numpy as np
import logging
from enum import Enum # Import Enum

logger = logging.getLogger("kr_kripto_context")

# --- Adicionar a definição do Enum MarketRegime --- (Etapa 018)
class MarketRegime(Enum):
    INDEFINIDO = "INDEFINIDO"
    ALTA_VOLATILIDADE = "ALTA_VOLATILIDADE"
    BAIXA_VOLATILIDADE = "BAIXA_VOLATILIDADE"
    BAIXA_VOLATILIDADE_SQUEEZE = "BAIXA_VOLATILIDADE_SQUEEZE"
    TENDENCIA_FORTE = "TENDENCIA_FORTE"
    TENDENCIA_FORTE_ALTA = "TENDENCIA_FORTE_ALTA"
    TENDENCIA_FORTE_BAIXA = "TENDENCIA_FORTE_BAIXA"
    LATERAL_MODERADO = "LATERAL_MODERADO"
    LATERAL_BAIXA_VOL = "LATERAL_BAIXA_VOL"  # Adicionado LATERAL_BAIXA_VOL
# --- Fim da adição ---

class ContextSwitcher:
    def __init__(self, config: dict):
        self.config = config.get("context_switcher_config", {}) # Get the specific sub-config
        logger.info(f"ContextSwitcher config: {self.config}")
        # Define thresholds for different regimes based on config, with defaults
        self.atr_norm_threshold_high = self.config.get("atr_norm_threshold_high", 0.015) # ATR/Close > 1.5%
        self.atr_norm_threshold_low = self.config.get("atr_norm_threshold_low", 0.005)  # ATR/Close <= 0.5% (Adjusted)
        self.adx_threshold_strong = self.config.get("adx_threshold_strong", 25)
        self.adx_threshold_weak = self.config.get("adx_threshold_weak", 20)
        self.bb_squeeze_factor = self.config.get("bb_squeeze_factor", 1.5) # BB Width < ATR * factor

    def identificar_regime(self, df: pd.DataFrame) -> str:
        """Identifica o regime de mercado atual com base em indicadores técnicos e thresholds configuráveis."""
        if df is None or df.empty:
            logger.warning("DataFrame vazio ou None recebido para identificar regime.")
            return MarketRegime.INDEFINIDO.value # Use Enum value

        # Normalize column names to UPPERCASE for consistent access
        df.columns = [str(col).upper() for col in df.columns]

        # --- Verification of required columns ---
        required_cols = ["ATR_14", "ADX_14", "DMP_14", "DMN_14", "BBL_20_2.0", "BBU_20_2.0", "CLOSE"]
        present_cols = [col for col in required_cols if col in df.columns]
        missing_cols = [col for col in required_cols if col not in df.columns]

        if missing_cols:
            logger.warning(f"Colunas necessárias para identificar regime ausentes: {missing_cols}. Colunas presentes: {list(df.columns)}")
            return MarketRegime.INDEFINIDO.value # Use Enum value

        # --- Extract latest values --- (Ensure columns exist before accessing)
        try:
            latest_data = df.iloc[-1]
            atr = latest_data["ATR_14"]
            adx = latest_data["ADX_14"]
            dmp = latest_data["DMP_14"] # DI+
            dmn = latest_data["DMN_14"] # DI-
            bbl = latest_data["BBL_20_2.0"] # Lower Bollinger Band
            bbu = latest_data["BBU_20_2.0"] # Upper Bollinger Band
            close = latest_data["CLOSE"]
        except KeyError as e:
            logger.error(f"Erro ao acessar coluna necessária (mesmo após verificação): {e}. Colunas: {list(df.columns)}")
            return MarketRegime.INDEFINIDO.value # Use Enum value
        except IndexError:
             logger.error("Erro ao acessar a última linha do DataFrame (IndexError).")
             return MarketRegime.INDEFINIDO.value # Use Enum value

        # --- Handle potential NaN or zero values ---
        if pd.isna(atr) or pd.isna(adx) or pd.isna(dmp) or pd.isna(dmn) or pd.isna(bbl) or pd.isna(bbu) or pd.isna(close) or close == 0:
            logger.warning(f"Valores NaN/zero encontrados nos indicadores/close para a última linha: ATR={atr}, ADX={adx}, DMP={dmp}, DMN={dmn}, BBL={bbl}, BBU={bbu}, CLOSE={close}")
            return MarketRegime.INDEFINIDO.value # Use Enum value

        # --- Regime Identification Logic (Refined with Configurable Thresholds) ---
        atr_normalized = atr / close # Normalize ATR by price
        bb_width = bbu - bbl

        volatility_high = atr_normalized > self.atr_norm_threshold_high
        # --- CORRECTION: Use <= for low volatility threshold --- 
        volatility_low = atr_normalized <= self.atr_norm_threshold_low
        # --- END CORRECTION ---
        trend_strong = adx > self.adx_threshold_strong
        trend_weak = adx < self.adx_threshold_weak
        trend_bullish = dmp > dmn
        trend_bearish = dmn > dmp
        in_squeeze = bb_width < (atr * self.bb_squeeze_factor)

        # Prioritize Strong Trend
        if trend_strong:
            if trend_bullish:
                logger.debug(f"Regime: TENDENCIA_FORTE_ALTA (ADX={adx:.2f} > {self.adx_threshold_strong}, DMP > DMN)")
                return MarketRegime.TENDENCIA_FORTE_ALTA.value
            elif trend_bearish:
                logger.debug(f"Regime: TENDENCIA_FORTE_BAIXA (ADX={adx:.2f} > {self.adx_threshold_strong}, DMN > DMP)")
                return MarketRegime.TENDENCIA_FORTE_BAIXA.value
            else:
                # Fallback if DMP == DMN, which is rare
                logger.debug(f"Regime: TENDENCIA_FORTE (ADX={adx:.2f} > {self.adx_threshold_strong}, DMP==DMN)")
                return MarketRegime.TENDENCIA_FORTE.value

        # Check for Squeeze (Low Volatility + Narrow Bands)
        elif volatility_low and in_squeeze:
            logger.debug(f"Regime: BAIXA_VOLATILIDADE_SQUEEZE (ATR_Norm={atr_normalized:.4f} <= {self.atr_norm_threshold_low}, BBW < ATR*{self.bb_squeeze_factor})")
            return MarketRegime.BAIXA_VOLATILIDADE_SQUEEZE.value

        # Check for High Volatility (without strong trend)
        elif volatility_high:
            logger.debug(f"Regime: ALTA_VOLATILIDADE (ATR_Norm={atr_normalized:.4f} > {self.atr_norm_threshold_high}, ADX <= {self.adx_threshold_strong})")
            return MarketRegime.ALTA_VOLATILIDADE.value

        # Check for general Low Volatility (without squeeze or strong trend)
        # This is where LATERAL_BAIXA_VOL might fit, if it's distinct from BAIXA_VOLATILIDADE
        elif volatility_low: # This condition is the same as the one above for BAIXA_VOLATILIDADE
            # Need to differentiate LATERAL_BAIXA_VOL from BAIXA_VOLATILIDADE
            # For now, let's assume if it's low volatility and not squeeze, it's LATERAL_BAIXA_VOL if ADX is also weak
            if trend_weak: # ADX < 20
                 logger.debug(f"Regime: LATERAL_BAIXA_VOL (ATR_Norm={atr_normalized:.4f} <= {self.atr_norm_threshold_low}, ADX < {self.adx_threshold_weak}, Not Squeeze)")
                 return MarketRegime.LATERAL_BAIXA_VOL.value
            else: # Otherwise, it's just general BAIXA_VOLATILIDADE
                 logger.debug(f"Regime: BAIXA_VOLATILIDADE (ATR_Norm={atr_normalized:.4f} <= {self.atr_norm_threshold_low}, Not Squeeze, ADX >= {self.adx_threshold_weak})")
                 return MarketRegime.BAIXA_VOLATILIDADE.value

        # Default to Moderate Lateral if none of the above
        else:
            logger.debug(f"Regime: LATERAL_MODERADO (Default - ATR_Norm={atr_normalized:.4f}, ADX={adx:.2f})")
            return MarketRegime.LATERAL_MODERADO.value

    def obter_configuracao_estrategia(self, regime: str) -> dict:
        """Retorna a configuração da estratégia apropriada para o regime identificado."""
        strategy_configs = self.config.get("strategy_settings", {})
        # Return specific regime config or default if not found
        return strategy_configs.get(regime, strategy_configs.get("DEFAULT", {}))


