
import pandas as pd
import numpy as np
from collections import defaultdict
from inteligencia.log_por_ativo import registrar_log

# Estado interno de contexto
contexto_status = defaultdict(lambda: {"bloqueado": False, "ultimos_scores": [], "motivo": None})

def avaliar_contexto_mercado(ativo, df, parametros=None):
    if df is None or len(df) < 20:
        contexto_status[ativo]["bloqueado"] = True
        contexto_status[ativo]["motivo"] = "dados insuficientes"
        registrar_log(ativo, "⚠️ Contexto bloqueado: dados insuficientes", "contexto_mercado", "WARN")
        return {"bloqueado": True, "motivo": "dados insuficientes"}

    # Parâmetros default
    p = {
        "limite_volatilidade": 0.015,
        "limite_volume": 0.6,
        "rsi_alto": 78,
        "rsi_baixo": 22
    }
    if parametros:
        p.update(parametros)

    ultimos = df.tail(20)
    volume_medio = ultimos["volume"].mean()
    desvio_preco = ultimos["close"].std()
    rsi = ultimos["rsi"].iloc[-1] if "rsi" in df.columns else 50
    preco_medio = ultimos["close"].mean()

    volatilidade_alta = desvio_preco > preco_medio * p["limite_volatilidade"]
    volume_baixo = volume_medio < ultimos["volume"].rolling(20).mean().iloc[-1] * p["limite_volume"]
    rsi_extremo = rsi > p["rsi_alto"] or rsi < p["rsi_baixo"]

    motivo = []
    if volatilidade_alta: motivo.append("volatilidade alta")
    if volume_baixo: motivo.append("volume baixo")
    if rsi_extremo: motivo.append("RSI extremo")

    if motivo:
        contexto_status[ativo]["bloqueado"] = True
        contexto_status[ativo]["motivo"] = ", ".join(motivo)
        registrar_log(ativo, f"🛑 Contexto bloqueado: {contexto_status[ativo]['motivo']}", "contexto_mercado", "WARN")
    else:
        contexto_status[ativo]["bloqueado"] = False
        contexto_status[ativo]["motivo"] = None
        registrar_log(ativo, "✅ Contexto liberado para operação", "contexto_mercado")

    return {
        "bloqueado": contexto_status[ativo]["bloqueado"],
        "motivo": contexto_status[ativo]["motivo"],
        "volatilidade": desvio_preco,
        "volume_medio": volume_medio,
        "rsi": rsi
    }

def pode_operar_por_contexto(ativo):
    return not contexto_status[ativo]["bloqueado"]
