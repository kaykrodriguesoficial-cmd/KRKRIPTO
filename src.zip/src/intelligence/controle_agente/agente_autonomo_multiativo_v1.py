
import pandas as pd
from datetime import datetime
from inteligencia.feedback.feedback_aprendiz_real import atualizar_qtable_com_feedback
from inteligencia.meta.reforco_qtable import QTableReforco
from estrategias.score_engine_v2 import prever_score_final
from strategies.classificador import prever_classe
from strategies.fakeout import detectar_fakeout
from inteligencia.contexto.contexto_mercado import avaliar_contexto_mercado
from inteligencia.ajustadores.calcular_pesos_dinamicos import calcular_pesos_dinamicos
from inteligencia.orquestrador_neural_SUPREMO import orquestrar_decisao
from executors.logger import log_erro

class AgenteAutonomo:
    def __init__(self, config: dict):
        self.ativo = ativo
        self.qtable = QTableReforco()
        self.historico_sinais = []

    def avaliar_contexto(self, df):
        try:
            avaliar_contexto_mercado(self.ativo, df)

            score_raw = df.iloc[-1]['score'] if 'score' in df.columns else 0.0
            classe, probabilidade = prever_classe(df)
            fakeout = detectar_fakeout(df)

            regime = self._detectar_regime_simples(df)
            contexto = self._construir_contexto(df)

            w_score, w_prob, w_fake = calcular_pesos_dinamicos(regime, probabilidade, contexto['volatilidade'])
            score_final = prever_score_final(score_raw, probabilidade, fakeout, w_score, w_prob, w_fake)

            if not (0.1 <= contexto['volatilidade'] <= 5.0):
                return None

            decisao = orquestrar_decisao(self.ativo, df, score_raw, probabilidade, fakeout, contexto, regime)
            if decisao:
                self._registrar_sinal(classe, score_final, probabilidade, regime, contexto["hora"])
                return {
                    "classe": classe,
                    "score": score_final,
                    "probabilidade": probabilidade
                }
            return None
        except Exception as e:
            log_erro(f"[AGENTE {self.ativo}] Erro ao avaliar contexto: {e}")
            return None

    def _registrar_sinal(self, classe, score, prob, regime, hora):
        sinal = {
            "classe": classe,
            "score": score,
            "probabilidade": prob,
            "contexto": {"regime": regime, "hora": hora},
            "timestamp": str(datetime.utcnow())
        }
        self.historico_sinais.append(sinal)
        self.qtable.registrar_recompensa(regime, hora, "auto", prob)

    def _detectar_regime_simples(self, df):
        try:
            vol = df['close'].pct_change().rolling(5).std().iloc[-1]
            if vol > 0.02:
                return "alta"
            elif vol < 0.005:
                return "lateral"
            return "baixa"
        except Exception:
            return "neutro"

    def _construir_contexto(self, df):
        return {
            "volatilidade": df['close'].pct_change().rolling(5).std().iloc[-1],
            "hora": df.index[-1].hour if not df.empty else datetime.utcnow().hour,
            "tendencia": df['close'].rolling(10).mean().iloc[-1] < df['close'].iloc[-1]
        }
