"""
Módulo: risk_manager.py
Responsável por aplicar lógica de governança de risco sobre os sinais antes da execução.
"""

def aplicar_risco(ativo: str, dados_input: dict, capital_atual: float) -> dict:
    # Configurações de risco
    limiar_capital = 100.0  # Exemplo: mínimo necessário
    drawdown_maximo = 0.3   # 30% de perda acumulada

    # Simulações de dados de risco - ajustar com base em histórico real
    drawdown_simulado = dados_input.get("drawdown_atual", 0.0)

    pode_executar = True
    motivo_bloqueio = ""
    score_ajustado = dados_input.get("score_final", 0.0)

    # Bloqueio por capital insuficiente
    if capital_atual < limiar_capital:
        pode_executar = False
        motivo_bloqueio = "capital abaixo do limite mínimo"

    # Redução de score por drawdown excessivo
    if drawdown_simulado > drawdown_maximo:
        score_ajustado *= 0.5
        motivo_bloqueio = "drawdown alto — score reduzido"

    # Atualiza e retorna os dados_input com informações de risco
    dados_input.update({
        "score_ajustado": round(score_ajustado, 4),
        "pode_executar": pode_executar,
        "motivo_bloqueio": motivo_bloqueio if not pode_executar else ""
    })

    return dados_input
