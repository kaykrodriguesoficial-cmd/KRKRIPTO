
from sklearn.cluster import KMeans
import numpy as np
from executors.logger import log_erro

def clusterizar_contexto(df):
    """
    Aplica clusterização KMeans para identificar tipo de regime de mercado (bull, bear, lateral).
    Retorna o rótulo do cluster: 0, 1 ou 2 e sua interpretação.
    """
    try:
        df = df.tail(30).copy()
        if df.shape[0] < 10:
            return "INDEFINIDO"

        features = np.stack([
            df["close"].pct_change().fillna(0).values,
            df["volume"].pct_change().fillna(0).values
        ], axis=1)

        modelo = KMeans(n_clusters=3, random_state=42, n_init=10)
        clusters = modelo.fit_predict(features)

        final_cluster = clusters[-1]
        mapping = {0: "LATERAL", 1: "BULL", 2: "BEAR"}

        return mapping.get(final_cluster, f"CLUSTER_{final_cluster}")
    except Exception as e:
        log_erro(f"[CLUSTERIZAÇÃO] Erro: {e}")
        return "INDEFINIDO"
