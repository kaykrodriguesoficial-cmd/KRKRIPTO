
import pandas as pd

def priorizar_ativos_por_performance(df_historico):
    """
    Recebe DataFrame com colunas: ['ativo', 'roi', 'drawdown', 'risco_implícito']
    Retorna ativos ranqueados com escore ponderado de prioridade.
    """

    if df_historico.empty or not all(c in df_historico.columns for c in ['ativo', 'roi', 'drawdown', 'risco_implícito']):
        return []

    df = df_historico.copy()
    
    # Normalização simples (0-1) invertendo drawdown e risco
    df['roi_n'] = (df['roi'] - df['roi'].min()) / (df['roi'].max() - df['roi'].min() + 1e-9)
    df['drawdown_n'] = 1 - ((df['drawdown'] - df['drawdown'].min()) / (df['drawdown'].max() - df['drawdown'].min() + 1e-9))
    df['risco_n'] = 1 - ((df['risco_implícito'] - df['risco_implícito'].min()) / (df['risco_implícito'].max() - df['risco_implícito'].min() + 1e-9))

    # Escore final ponderado
    df['prioridade'] = (df['roi_n'] * 0.5) + (df['drawdown_n'] * 0.3) + (df['risco_n'] * 0.2)
    df_ordenado = df.sort_values(by='prioridade', ascending=False)

    return df_ordenado[['ativo', 'prioridade']].reset_index(drop=True)
