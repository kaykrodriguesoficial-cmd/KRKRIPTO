
from collections import defaultdict
import json
import os

CAMINHO_LOGS = "dados/logs_decisoes/"
ARQUIVO_ANALISE = "dados/avaliacoes_modelos/relatorio_modelos.json"

def avaliar_performance_por_modelo():
    resultados = defaultdict(lambda: {"total": 0, "acertos": 0, "soma_pnl": 0.0})
    
    for arquivo in os.listdir(CAMINHO_LOGS):
        if not arquivo.endswith(".jsonl"):
            continue
        caminho_arquivo = os.path.join(CAMINHO_LOGS, arquivo)
        with open(caminho_arquivo, "r") as f:
            for linha in f:
                try:
                    dado = json.loads(linha)
                    modelo = dado.get("modelo")
                    pnl = dado.get("pnl")
                    if modelo is not None and pnl is not None:
                        resultados[modelo]["total"] += 1
                        resultados[modelo]["soma_pnl"] += pnl
                        if pnl > 0:
                            resultados[modelo]["acertos"] += 1
                except Exception:
                    continue

    relatorio = {
        modelo: {
            "total": r["total"],
            "acertos": r["acertos"],
            "media_pnl": round(r["soma_pnl"] / max(1, r["total"]), 4),
            "taxa_acerto": round(r["acertos"] / max(1, r["total"]), 4)
        }
        for modelo, r in resultados.items()
    }

    os.makedirs(os.path.dirname(ARQUIVO_ANALISE), exist_ok=True)
    with open(ARQUIVO_ANALISE, "w") as f:
        json.dump(relatorio, f, indent=4)

    print("📊 Avaliação de modelos finalizada.")
    return relatorio
