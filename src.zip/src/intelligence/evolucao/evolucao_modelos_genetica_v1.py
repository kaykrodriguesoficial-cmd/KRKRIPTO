
import random
from executors.logger import log_erro

class EvolucaoGeneticaModelos:
    def __init__(self):
        self.populacao_modelos = {}

    def avaliar_e_evoluir(self, ativo, modelo_atual, historico):
        try:
            if len(historico) < 10:
                return None

            score_medio = sum(s['score'] for s in historico[-10:]) / 10
            prob_media = sum(s['probabilidade'] for s in historico[-10:]) / 10

            if score_medio < 0.6 or prob_media < 0.6:
                novo_modelo = self._mutar_modelo(modelo_atual)
                log_erro(f"[EVOLUÇÃO] 🔁 Modelo de {ativo} mutado por baixa performance.")
                return novo_modelo

            return None
        except Exception as e:
            log_erro(f"[EVOLUÇÃO] Erro ao avaliar mutação: {e}")
            return None

    def _mutar_modelo(self, modelo):
        mutado = modelo.copy()
        mutado['layers'] += random.choice([-1, 1])
        mutado['dropout'] += random.uniform(-0.05, 0.05)
        mutado['optimizer'] = random.choice(['adam', 'sgd', 'rmsprop'])
        return mutado
