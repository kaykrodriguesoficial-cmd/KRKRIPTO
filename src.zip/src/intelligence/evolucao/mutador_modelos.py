
import random
import copy

def mutar_modelo(modelo_base):
    '''
    Gera uma mutação leve e controlada do modelo original.
    Ideal para testes A/B.
    
    Ex: Ajuste leve em parâmetros, threshold ou estrutura interna.

    Retorna:
    - modelo_mutante (deepcopy)
    '''

    modelo_mutado = copy.deepcopy(modelo_base)

    if hasattr(modelo_mutado, 'ajustar_parametros'):
        # Simula mutação com alteração leve e aleatória
        novo_threshold = round(modelo_mutado.threshold * (1 + random.uniform(-0.1, 0.1)), 4)
        modelo_mutado.ajustar_parametros(threshold=novo_threshold)

    # Tag para rastreio
    modelo_mutado.nome += "_mutado"
    return modelo_mutado
