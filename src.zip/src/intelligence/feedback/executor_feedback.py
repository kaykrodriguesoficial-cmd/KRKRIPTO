
import time
from datetime import datetime
from inteligencia.avaliadores.avaliador_modelo import avaliar_performance_por_modelo
from inteligencia.evolucao.mutacao_baseada_em_feedback import mutar_com_base_em_feedback
from inteligencia.meta.reforco_qtable import qtable

def ciclo_feedback_continuo(intervalo_segundos=60):
    '''
    Executa continuamente avaliação de modelos e mutação baseada em feedback
    sem interferir no ciclo principal de execução de sinais.
    '''

    while True:
        try:
            print(f"[{datetime.utcnow()}] 🔄 Ciclo de feedback iniciado.")
            # Avaliação de desempenho
            relatorio = avaliar_performance_por_modelo()

            # Loop por regime/hora para mutar os piores modelos
            for regime in qtable.qtable.keys():
                for hora in qtable.qtable[regime].keys():
                    desempenho = {
                        modelo: relatorio.get(modelo, {}).get("media_pnl", 0.0)
                        for modelo in qtable.qtable[regime][hora].keys()
                    }
                    mutar_com_base_em_feedback(regime, hora, desempenho)

            print(f"[{datetime.utcnow()}] ✅ Ciclo de feedback finalizado. Aguardando próximo...")
        except Exception as e:
            print(f"[{datetime.utcnow()}] ❌ Erro no ciclo de feedback: {e}")

        time.sleep(intervalo_segundos)
