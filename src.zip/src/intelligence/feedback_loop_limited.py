# src/intelligence/feedback_loop_limited.py
import pandas as pd
import logging
from src.infrastructure.memory import MemoriaTemporal # Assuming MemoriaTemporal is defined here or imported

logger = logging.getLogger("kr_kripto_feedback")

def rodar_feedback_condicional(ativo: str, sinal: str, score: float, df: pd.DataFrame, memoria: MemoriaTemporal):
    logger.debug(f"[{ativo}] rodar_feedback_condicional (stub) chamado com sinal {sinal}.")
    # Placeholder function, does nothing
    pass

