
def calcular_peso_de_risco(score_final, probabilidade, regime, volatilidade, historico_modelo=None):
    '''
    Calcula o peso ideal de alocação de capital (0 a 1) para um sinal, baseado em:
    - Score final (qualidade da decisão)
    - Probabilidade (confiança no modelo)
    - Regime de mercado (condição atual)
    - Volatilidade (risco do ativo)
    - Histórico do modelo em contextos similares

    Retorna:
    - peso_risco (float entre 0.0 e 1.0)
    - explicacao (texto interpretável do cálculo)
    '''

    peso = 0.0
    fatores = []

    if score_final > 0.85:
        peso += 0.4
        fatores.append("score alto")
    elif score_final > 0.7:
        peso += 0.3
        fatores.append("score moderado")
    else:
        peso += 0.1
        fatores.append("score baixo")

    if probabilidade > 0.85:
        peso += 0.3
        fatores.append("alta confiança")
    elif probabilidade > 0.65:
        peso += 0.2
        fatores.append("confiança média")
    else:
        peso += 0.1
        fatores.append("baixa confiança")

    if regime in ["tendencia_alta", "tendencia_baixa"]:
        peso += 0.2
        fatores.append("regime favorável")
    else:
        peso -= 0.1
        fatores.append("regime instável")

    if volatilidade > 2.0:
        peso -= 0.2
        fatores.append("alta volatilidade")
    elif volatilidade < 1.0:
        peso += 0.1
        fatores.append("baixa volatilidade")

    if historico_modelo:
        taxa_acerto = historico_modelo.get("taxa_acerto", 0.5)
        if taxa_acerto > 0.7:
            peso += 0.1
            fatores.append("bom histórico")
        elif taxa_acerto < 0.4:
            peso -= 0.1
            fatores.append("histórico ruim")

    peso_final = max(0.0, min(round(peso, 3), 1.0))
    explicacao = ", ".join(fatores)

    return peso_final, explicacao
