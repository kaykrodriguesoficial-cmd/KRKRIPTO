"""
Módulo: governanca_neural_adaptativa.py
Objetivo: Recalibrar os pesos dos cérebros (IA, heurísticas) com base em performance real pós-execução.
"""

import json
import os

ARQUIVO_GOVERNANCA = "governanca_pesos.json"
PESOS_INICIAIS = {
    "ia": 1.0,
    "heuristica": 1.0
}

def carregar_pesos():
    if os.path.exists(ARQUIVO_GOVERNANCA):
        with open(ARQUIVO_GOVERNANCA, "r") as f:
            return json.load(f)
    return PESOS_INICIAIS.copy()

def salvar_pesos(pesos):
    with open(ARQUIVO_GOVERNANCA, "w") as f:
        json.dump(pesos, f, indent=2)

def ajustar_pesos_por_lucro(lucro_real, fonte_vencedora):
    pesos = carregar_pesos()
    
    # Ajuste multiplicativo
    if lucro_real > 0:
        pesos[fonte_vencedora] *= 1.02  # Reforço
    else:
        pesos[fonte_vencedora] *= 0.97  # Penalidade

    # Clamp (limites mínimos e máximos)
    for k in pesos:
        pesos[k] = round(min(max(pesos[k], 0.1), 3.0), 4)

    salvar_pesos(pesos)
    return pesos

def obter_pesos_atuais():
    return carregar_pesos()
