"""
Pacote de governança neural para o sistema KR_KRIPTO_ADVANCED.
"""

# Garantir que o módulo neural_governance seja importável
try:
    from .neural_governance import NeuralGovernor
except ImportError as e:
    import logging
    logging.getLogger("kr_kripto_governance").warning(f"Erro ao importar NeuralGovernor: {e}")
