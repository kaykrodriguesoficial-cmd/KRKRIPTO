"""
Módulo: heuristicas_controller.py
Objetivo: Reduzir dinamicamente o impacto das heurísticas com base na performance da IA.
"""

def ajustar_heuristicas(dados_input: dict, limite_confianca=0.7):
    """
    Reduz o peso de heurísticas conforme o score da IA sobe.

    - Se score IA > limite_confianca (ex: 0.7), heurísticas recebem menor peso
    """
    score_ia = dados_input.get("score_ia", 0.0)
    heuristicas = ["score_rsi", "score_macd", "score_price_action"]

    fator = 1.0
    if score_ia > limite_confianca:
        fator = max(0.2, 1.0 - (score_ia - limite_confianca))  # mínimo 20%

    for heuristica in heuristicas:
        if heuristica in dados_input:
            dados_input[heuristica] *= fator
            dados_input[heuristica] = round(dados_input[heuristica], 4)

    dados_input["peso_heuristica_aplicado"] = round(fator, 4)
    return dados_input
