# -*- coding: utf-8 -*-
"""
Módulo de Governança Neural para o sistema KR_KRIPTO_ADVANCED.

Este módulo implementa a governança de modelos neurais, permitindo
o carregamento, seleção e monitoramento de desempenho de múltiplos modelos.
"""

import os
import logging
import numpy as np
from typing import Dict, Any, Optional, List, Union, Tuple
import traceback

# Configuração de logging
logger = logging.getLogger("kr_kripto_governance")

# Verificar se TensorFlow/Keras está disponível
try:
    import tensorflow as tf
    from tensorflow import keras
    from tensorflow.keras.models import load_model as keras_load_model_function
    KERAS_AVAILABLE = True
    logger.info("TensorFlow/Keras importado com sucesso.")
except ImportError:
    KERAS_AVAILABLE = False
    keras_load_model_function = None
    logger.warning("TensorFlow/Keras não disponível. Funcionalidades dependentes não estarão disponíveis.")

class PredictiveModel:
    """Classe base para modelos preditivos."""
    
    def __init__(self, model_id: str, model_path: str):
        """
        Inicializa um modelo preditivo.
        
        Args:
            model_id: Identificador único do modelo
            model_path: Caminho para o arquivo do modelo
        """
        self.model_id = model_id
        self.model_path = model_path
        self.model = None
        
    def load(self) -> bool:
        """
        Carrega o modelo.
        
        Returns:
            bool: True se o carregamento foi bem-sucedido, False caso contrário
        """
        raise NotImplementedError("Método abstrato, deve ser implementado pelas subclasses")
        
    def predict(self, input_data: np.ndarray) -> Optional[np.ndarray]:
        """
        Realiza uma predição com o modelo.
        
        Args:
            input_data: Dados de entrada para a predição
            
        Returns:
            Resultado da predição ou None se falhar
        """
        raise NotImplementedError("Método abstrato, deve ser implementado pelas subclasses")
        
    def is_loaded(self) -> bool:
        """
        Verifica se o modelo está carregado.
        
        Returns:
            bool: True se o modelo está carregado, False caso contrário
        """
        return self.model is not None

class KerasModelWrapper(PredictiveModel):
    """Wrapper para modelos Keras."""
    
    def __init__(self, model_id=None, model_path=None, config=None):
        """
        Inicializa um wrapper para modelo Keras.
        
        Args:
            model_id: Identificador único do modelo
            model_path: Caminho para o arquivo do modelo (.h5)
            config: Configuração alternativa (para compatibilidade com testes)
        """
        if config is not None:
            # Compatibilidade com testes que usam apenas config
            model_id = config.get('id', 'unknown')
            model_path = config.get('path', 'dummy/path.h5')
        elif hasattr(model_id, 'get') and callable(model_id.get):
            # Compatibilidade com testes que passam config como primeiro parâmetro
            config = model_id
            model_id = config.get('id', 'unknown')
            model_path = config.get('path', 'dummy/path.h5')
            
        super().__init__(model_id, model_path)
        
    def load(self) -> bool:
        """
        Carrega o modelo Keras.
        
        Returns:
            bool: True se o carregamento foi bem-sucedido, False caso contrário
        """
        if not KERAS_AVAILABLE:
            logger.error(f"Tentativa de carregar modelo Keras {self.model_id}, mas TensorFlow/Keras não está disponível")
            return False
            
        if not os.path.exists(self.model_path):
            logger.error(f"Arquivo do modelo {self.model_path} não encontrado")
            return False
            
        try:
            logger.info(f"Carregando modelo Keras {self.model_id} de {self.model_path}")
            self.model = keras_load_model_function(self.model_path, compile=False)
            logger.info(f"Modelo {self.model_id} carregado com sucesso")
            return True
        except Exception as e:
            logger.error(f"Erro ao carregar modelo {self.model_id}: {str(e)}")
            logger.debug(traceback.format_exc())
            self.model = None
            return False
            
    def predict(self, input_data: np.ndarray) -> Optional[np.ndarray]:
        """
        Realiza uma predição com o modelo Keras.
        
        Args:
            input_data: Dados de entrada para a predição
            
        Returns:
            Resultado da predição ou None se falhar
        """
        if not self.is_loaded():
            logger.warning(f"Tentativa de predição com modelo {self.model_id} não carregado")
            return None
            
        try:
            return self.model.predict(input_data)
        except Exception as e:
            logger.error(f"Erro na predição com modelo {self.model_id}: {str(e)}")
            logger.debug(traceback.format_exc())
            return None

class ModelLoader:
    """Carregador de modelos de governança."""
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o carregador de modelos.
        
        Args:
            config: Configuração do sistema
        """
        self.config = config
        
    def load_models(self) -> Dict[str, PredictiveModel]:
        """
        Carrega todos os modelos habilitados na configuração.
        
        Returns:
            Dicionário de modelos carregados com sucesso
        """
        loaded_models = {}
        
        # Obter lista de modelos da configuração
        models_config = self.config.get("governance_models", [])
        if not models_config:
            logger.warning("Nenhum modelo de governança encontrado na configuração")
            return loaded_models
            
        # Carregar cada modelo habilitado
        for model_config in models_config:
            model_id = model_config.get("id")
            model_path = model_config.get("path")
            model_type = model_config.get("type")
            enabled = model_config.get("enabled", False)
            
            if not enabled:
                logger.info(f"Modelo {model_id} desabilitado, pulando")
                continue
                
            if model_type == "keras":
                model = KerasModelWrapper(model_id, model_path)
                model.load()
                
                if model.is_loaded():
                    loaded_models[model_id] = model
                    logger.info(f"Modelo {model_id} carregado e adicionado ao conjunto")
            else:
                logger.warning(f"Tipo de modelo {model_type} não suportado para {model_id}")
                
        logger.info(f"Total de {len(loaded_models)} modelos carregados com sucesso")
        return loaded_models

class ModelPerformanceTracker:
    """Rastreador de desempenho de modelos."""
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o rastreador de desempenho.
        
        Args:
            config: Configuração do sistema
        """
        self.window_size = config.get('window_size', 50)
        self.performance_history: Dict[str, List[Tuple[float, int, float]]] = {}
        self.model_scores: Dict[str, float] = {}
        
    def record_prediction(self, model_id: str, prediction: float, actual: int) -> None:
        """
        Registra uma predição e atualiza o score do modelo.
        
        Args:
            model_id: Identificador do modelo
            prediction: Valor previsto (probabilidade)
            actual: Valor real (0 ou 1)
        """
        # Inicializar histórico para o modelo se não existir
        if model_id not in self.performance_history:
            self.performance_history[model_id] = []
            
        # Calcular score para esta predição (1 se acertou, 0 se errou)
        predicted_class = 1 if prediction >= 0.5 else 0
        score = 1.0 if predicted_class == actual else 0.0
        
        # Adicionar ao histórico
        self.performance_history[model_id].append((prediction, actual, score))
        
        # Limitar o tamanho do histórico à janela configurada
        if len(self.performance_history[model_id]) > self.window_size:
            self.performance_history[model_id].pop(0)
            
        # Recalcular score médio do modelo
        scores = [entry[2] for entry in self.performance_history[model_id]]
        self.model_scores[model_id] = sum(scores) / len(scores) if scores else 0.0
    
    # Alias em português para compatibilidade com o sistema principal
    def registrar_predicao(self, model_id: str, prediction: float, actual: int) -> None:
        """
        Alias em português para record_prediction.
        Registra uma predição e atualiza o score do modelo.
        
        Args:
            model_id: Identificador do modelo
            prediction: Valor previsto (probabilidade)
            actual: Valor real (0 ou 1)
        """
        logger.debug(f"Chamada para registrar_predicao redirecionada para record_prediction")
        return self.record_prediction(model_id, prediction, actual)
        
    def get_best_model(self) -> Optional[str]:
        """
        Retorna o ID do modelo com melhor desempenho.
        
        Returns:
            ID do melhor modelo ou None se não houver modelos
        """
        if not self.model_scores:
            return None
            
        return max(self.model_scores.items(), key=lambda x: x[1])[0]
        
    def get_model_scores(self) -> Dict[str, float]:
        """
        Retorna os scores de todos os modelos.
        
        Returns:
            Dicionário com os scores dos modelos
        """
        return self.model_scores.copy()

class NeuralGovernor:
    """Governador de modelos neurais."""
    
    def __init__(self, config: Dict[str, Any], models: Optional[Dict[str, PredictiveModel]] = None, tracker: Optional[ModelPerformanceTracker] = None):
        """
        Inicializa o governador neural.
        
        Args:
            config: Configuração do sistema
            models: Dicionário de modelos disponíveis (opcional, será carregado do config se não fornecido)
            tracker: Rastreador de desempenho (opcional, será criado se não fornecido)
        """
        self.config = config
        
        # Inicializar tracker se não fornecido
        if tracker is None:
            logger.info("Tracker não fornecido, criando novo ModelPerformanceTracker")
            self.tracker = ModelPerformanceTracker(config)
        else:
            self.tracker = tracker
            
        # Inicializar models se não fornecido
        if models is None:
            logger.info("Models não fornecidos, carregando a partir do config")
            model_loader = ModelLoader(config)
            self.models = model_loader.load_models()
        else:
            self.models = models
            
        self.selection_strategy = config.get("selection_strategy", "best_recent")
        self.selected_model_id: Optional[str] = None
        
        logger.info(f"NeuralGovernor inicializado com {len(self.models)} modelos e estratégia {self.selection_strategy}")
        
    def select_model_id(self) -> Optional[str]:
        """
        Seleciona o modelo a ser usado com base na estratégia configurada.
        
        Returns:
            ID do modelo selecionado ou None se não houver modelos
        """
        if not self.models:
            logger.warning("Nenhum modelo disponível para seleção")
            return None
            
        if self.selection_strategy == "best_recent":
            # Usar o modelo com melhor desempenho recente
            best_model_id = self.tracker.get_best_model()
            
            # Se o tracker não tiver dados suficientes, usar o primeiro modelo disponível
            if best_model_id is None or best_model_id not in self.models:
                best_model_id = next(iter(self.models.keys()))
                
            self.selected_model_id = best_model_id
            logger.info(f"Modelo selecionado: {best_model_id} (estratégia: best_recent)")
            return best_model_id
        else:
            # Estratégia desconhecida, usar o primeiro modelo como fallback
            fallback_model_id = next(iter(self.models.keys()))
            self.selected_model_id = fallback_model_id
            logger.warning(f"Estratégia {self.selection_strategy} desconhecida. Usando {fallback_model_id} como fallback")
            return fallback_model_id
            
    def predict(self, input_data: np.ndarray) -> Optional[np.ndarray]:
        """
        Realiza uma predição usando o modelo selecionado.
        
        Args:
            input_data: Dados de entrada para a predição
            
        Returns:
            Resultado da predição ou None se falhar
        """
        # Selecionar modelo se ainda não foi selecionado
        if self.selected_model_id is None:
            self.select_model_id()
            
        # Verificar se temos um modelo selecionado
        if self.selected_model_id is None:
            logger.error("Nenhum modelo selecionado para predição")
            return None
            
        # Obter o modelo e fazer a predição
        model = self.models.get(self.selected_model_id)
        if model is None:
            logger.error(f"Modelo selecionado {self.selected_model_id} não encontrado")
            return None
            
        return model.predict(input_data)
        
    def get_selected_model_id(self) -> Optional[str]:
        """
        Retorna o ID do modelo atualmente selecionado.
        
        Returns:
            ID do modelo selecionado ou None se nenhum modelo estiver selecionado
        """
        return self.selected_model_id
        
    def process(self, input_data: np.ndarray) -> Optional[np.ndarray]:
        """
        Método de processamento para compatibilidade com o sistema.
        Este método é chamado pelo sistema principal e redireciona para predict().
        
        Args:
            input_data: Dados de entrada para processamento
            
        Returns:
            Resultado do processamento ou None se falhar
        """
        logger.debug(f"Método process() chamado, redirecionando para predict()")
        return self.predict(input_data)
