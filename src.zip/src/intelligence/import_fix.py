#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Módulo de correção de importações para o projeto KR_KRIPTO_ADVANCED.
Versão 3.0 - Compatibilidade total com Mac M1 e Linux.

Este módulo corrige problemas de importação em diferentes ambientes,
especialmente no Mac M1 (ARM64), garantindo que os módulos críticos
sejam encontrados corretamente.
"""

import os
import sys
import platform
import importlib
import logging
from typing import Dict, Any, Optional, List, Tuple

# Configuração de logging
logger = logging.getLogger("kr_kripto_import_fix")

# Mapeamento de módulos
MODULE_MAPPINGS = {
    # Mapeamentos de fallback
    "src.core.fallback_v2.GerenciadorFallback": "src.core.fallback.GerenciadorFallback",
    "src.infrastructure.fallback.GerenciadorFallback": "src.core.fallback.GerenciadorFallback",
    
    # Mapeamentos de memoria temporal
    "src.core.memoria_temporal_v2.MemoriaTemporal": "src.core.memoria_temporal.MemoriaTemporal",
    "src.intelligence.memoria_temporal.MemoriaTemporal": "src.core.memoria_temporal.MemoriaTemporal",
    
    # Mapeamentos de book processor
    "src.core.book_imbalance.BookProcessor": "src.realtime.book_processor.BookProcessor",
    
    # Outros mapeamentos críticos
    "src.intelligence.model_performance_tracker_stub.ModelPerformanceTrackerStub": "src.intelligence.model_performance_tracker.ModelPerformanceTracker"
}

def is_mac_m1() -> bool:
    """
    Verifica se o ambiente atual é um Mac M1 (ARM64).
    
    Returns:
        True se for um Mac M1, False caso contrário
    """
    return (
        platform.system() == "Darwin" and 
        ("arm" in platform.machine().lower() or "M1" in platform.processor())
    )

def fix_imports() -> Dict[str, Any]:
    """
    Aplica correções de importação para garantir compatibilidade
    entre diferentes ambientes.
    
    Returns:
        Dicionário com resultados das correções
    """
    resultados = {
        "ambiente": "Mac M1" if is_mac_m1() else "Outro",
        "arquitetura": platform.machine(),
        "processador": platform.processor(),
        "mapeamentos_aplicados": [],
        "erros": []
    }
    
    # Aplicar mapeamentos de módulos
    for origem, destino in MODULE_MAPPINGS.items():
        try:
            # Verificar se o módulo de destino existe
            modulo_destino = None
            try:
                partes_destino = destino.split(".")
                nome_modulo = ".".join(partes_destino[:-1])
                nome_classe = partes_destino[-1]
                
                # Tentar importar o módulo de destino
                modulo = importlib.import_module(nome_modulo)
                if hasattr(modulo, nome_classe):
                    modulo_destino = getattr(modulo, nome_classe)
            except (ImportError, AttributeError) as e:
                logger.warning(f"Módulo de destino {destino} não encontrado: {e}")
                resultados["erros"].append(f"Módulo de destino {destino} não encontrado: {e}")
                continue
            
            # Se o módulo de destino existe, aplicar o mapeamento
            if modulo_destino:
                partes_origem = origem.split(".")
                nome_modulo_origem = ".".join(partes_origem[:-1])
                nome_classe_origem = partes_origem[-1]
                
                # Verificar se o módulo de origem existe
                try:
                    modulo_origem = importlib.import_module(nome_modulo_origem)
                    # Se o módulo existe mas a classe não, adicionar a classe
                    if not hasattr(modulo_origem, nome_classe_origem):
                        setattr(modulo_origem, nome_classe_origem, modulo_destino)
                        resultados["mapeamentos_aplicados"].append(f"{origem} -> {destino}")
                except ImportError:
                    logger.warning(f"Módulo de origem {nome_modulo_origem} não encontrado")
                    resultados["erros"].append(f"Módulo de origem {nome_modulo_origem} não encontrado")
        except Exception as e:
            erro = f"Erro ao mapear {origem} para {destino}: {e}"
            logger.error(erro)
            resultados["erros"].append(erro)
    
    # Adicionar diretórios ao path se necessário
    diretorio_base = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
    if diretorio_base not in sys.path:
        sys.path.insert(0, diretorio_base)
        resultados["path_adicionado"] = diretorio_base
    
    # Verificar e corrigir módulos críticos
    modulos_criticos = [
        "src.core.fallback",
        "src.core.memoria_temporal",
        "src.realtime.book_processor"
    ]
    
    for modulo in modulos_criticos:
        try:
            importlib.import_module(modulo)
            resultados[f"modulo_{modulo}"] = "OK"
        except ImportError as e:
            erro = f"Módulo crítico {modulo} não disponível: {e}"
            logger.error(erro)
            resultados["erros"].append(erro)
            resultados[f"modulo_{modulo}"] = "ERRO"
    
    return resultados

# Aplicar correções automaticamente ao importar o módulo
if __name__ != "__main__":
    fix_imports()
