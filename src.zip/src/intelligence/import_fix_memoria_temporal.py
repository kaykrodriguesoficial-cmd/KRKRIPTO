#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Módulo de redirecionamento para memoria_temporal.

Este módulo fornece compatibilidade com imports antigos,
redirecionando para a implementação atual em src.core.memoria_temporal_v2.

Versão: 2.0
Data: 2025-05-30
"""

import os
import sys
import logging
import importlib
import platform
import traceback
from typing import Dict, Any, Optional, List, Union

logger = logging.getLogger("kr_kripto_import_fix")

# Verificar se estamos em um Mac M1
def is_mac_m1() -> bool:
    """Verifica se o ambiente atual é um Mac M1 (Apple Silicon)."""
    try:
        if platform.system() == "Darwin" and ("arm" in platform.machine().lower() or "M1" in platform.processor()):
            logger.info(f"Ambiente Mac M1 detectado: {platform.machine()} / {platform.processor()}")
            return True
        return False
    except Exception as e:
        logger.error(f"Erro ao detectar ambiente: {e}")
        return False

# Flags para controle de importação
MEMORIA_TEMPORAL_V2_AVAILABLE = False
MEMORIA_TEMPORAL_IMPORTED = False
IMPORT_PATH_USED = None

# Tentar importar MemoriaTemporal V2 (preferencial)
try:
    # Primeiro tenta importar do caminho correto (core)
    from src.core.memoria_temporal_v2 import MemoriaTemporal
    logger.info("MemoriaTemporal V2 importado com sucesso de src.core.memoria_temporal_v2")
    MEMORIA_TEMPORAL_V2_AVAILABLE = True
    MEMORIA_TEMPORAL_IMPORTED = True
    IMPORT_PATH_USED = "src.core.memoria_temporal_v2"
except ImportError as e:
    logger.debug(f"Falha ao importar de src.core.memoria_temporal_v2: {e}")
    try:
        # Tenta caminho alternativo sem prefixo src
        from core.memoria_temporal_v2 import MemoriaTemporal
        logger.info("MemoriaTemporal V2 importado com sucesso de core.memoria_temporal_v2")
        MEMORIA_TEMPORAL_V2_AVAILABLE = True
        MEMORIA_TEMPORAL_IMPORTED = True
        IMPORT_PATH_USED = "core.memoria_temporal_v2"
    except ImportError as e:
        logger.warning(f"MemoriaTemporal V2 não encontrado: {e}, tentando versão original...")
        
        # Tentar importar MemoriaTemporal original
        try:
            # Primeiro tenta importar do caminho correto (intelligence)
            from src.intelligence.memoria_temporal import MemoriaTemporal
            logger.info("MemoriaTemporal original importado com sucesso de src.intelligence.memoria_temporal")
            MEMORIA_TEMPORAL_IMPORTED = True
            IMPORT_PATH_USED = "src.intelligence.memoria_temporal"
        except ImportError as e:
            logger.debug(f"Falha ao importar de src.intelligence.memoria_temporal: {e}")
            try:
                # Tenta caminho alternativo sem prefixo src
                from intelligence.memoria_temporal import MemoriaTemporal
                logger.info("MemoriaTemporal original importado com sucesso de intelligence.memoria_temporal")
                MEMORIA_TEMPORAL_IMPORTED = True
                IMPORT_PATH_USED = "intelligence.memoria_temporal"
            except ImportError as e:
                logger.debug(f"Falha ao importar de intelligence.memoria_temporal: {e}")
                # Se ainda falhar, tenta importar como módulo
                try:
                    # Adiciona o diretório atual ao path
                    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
                    
                    # Tenta importar de diferentes caminhos
                    possible_paths = [
                        "src.intelligence.memoria_temporal",
                        "intelligence.memoria_temporal",
                        "src.core.memoria_temporal",
                        "core.memoria_temporal"
                    ]
                    
                    memoria_temporal_module = None
                    for path in possible_paths:
                        try:
                            logger.debug(f"Tentando importar de {path}")
                            memoria_temporal_module = importlib.import_module(path)
                            logger.info(f"MemoriaTemporal importado como módulo de {path}")
                            IMPORT_PATH_USED = path
                            break
                        except ImportError as e:
                            logger.debug(f"Falha ao importar de {path}: {e}")
                            continue
                    
                    if memoria_temporal_module:
                        # Verificar se é uma classe ou funções
                        if hasattr(memoria_temporal_module, "MemoriaTemporal"):
                            MemoriaTemporal = memoria_temporal_module.MemoriaTemporal
                            logger.info("Classe MemoriaTemporal encontrada no módulo")
                        else:
                            # Criar uma classe wrapper para as funções
                            class MemoriaTemporal:
                                def __init__(self, config=None):
                                    self.config = config or {}
                                    if hasattr(memoria_temporal_module, "inicializar_memoria"):
                                        memoria_temporal_module.inicializar_memoria()
                                    logger.info("MemoriaTemporal wrapper inicializado")
                                
                                def resetar_memoria(self, ativo=None):
                                    if hasattr(memoria_temporal_module, "resetar_memoria"):
                                        return memoria_temporal_module.resetar_memoria(ativo)
                                    logger.warning("Método resetar_memoria não encontrado no módulo")
                                    return False
                                
                                def atualizar_memoria(self, ativo, hora, score, acertou):
                                    if hasattr(memoria_temporal_module, "atualizar_memoria"):
                                        return memoria_temporal_module.atualizar_memoria(ativo, hora, score, acertou)
                                    logger.warning("Método atualizar_memoria não encontrado no módulo")
                                    return False
                                
                                def ajustar_por_memoria(self, ativo, hora, score):
                                    if hasattr(memoria_temporal_module, "ajustar_por_memoria"):
                                        return memoria_temporal_module.ajustar_por_memoria(ativo, hora, score)
                                    logger.warning("Método ajustar_por_memoria não encontrado no módulo")
                                    return score
                                
                                def obter_memoria(self, ativo=None):
                                    if hasattr(memoria_temporal_module, "obter_memoria"):
                                        return memoria_temporal_module.obter_memoria(ativo)
                                    logger.warning("Método obter_memoria não encontrado no módulo")
                                    import pandas as pd
                                    return pd.DataFrame()
                                
                                def obter_estatisticas(self, ativo=None):
                                    if hasattr(memoria_temporal_module, "obter_estatisticas"):
                                        return memoria_temporal_module.obter_estatisticas(ativo)
                                    logger.warning("Método obter_estatisticas não encontrado no módulo")
                                    return {"erro": "Método não implementado"}
                                
                                def exportar_memoria(self, formato="csv", caminho=None):
                                    if hasattr(memoria_temporal_module, "exportar_memoria"):
                                        return memoria_temporal_module.exportar_memoria(formato, caminho)
                                    logger.warning("Método exportar_memoria não encontrado no módulo")
                                    return ""
                                
                                def importar_memoria(self, caminho, substituir=False):
                                    if hasattr(memoria_temporal_module, "importar_memoria"):
                                        return memoria_temporal_module.importar_memoria(caminho, substituir)
                                    logger.warning("Método importar_memoria não encontrado no módulo")
                                    return False
                            
                            logger.info("Criado wrapper para funções do módulo")
                        
                        logger.info("MemoriaTemporal importado com sucesso após correção de arquivos")
                        MEMORIA_TEMPORAL_IMPORTED = True
                    else:
                        raise ImportError("Nenhum módulo memoria_temporal encontrado em caminhos conhecidos")
                        
                except Exception as e:
                    logger.error(f"Erro ao tentar importar MemoriaTemporal original: {e}")
                    logger.debug(f"Traceback: {traceback.format_exc()}")
                    MEMORIA_TEMPORAL_IMPORTED = False

# Se nenhuma versão foi importada com sucesso, cria um stub
if not MEMORIA_TEMPORAL_IMPORTED:
    logger.critical("Falha ao importar MemoriaTemporal. Usando implementação stub.")
    
    class MemoriaTemporal:
        """Stub para MemoriaTemporal quando nenhuma implementação real está disponível."""
        
        def __init__(self, config=None):
            self.config = config or {}
            logger.warning("STUB: MemoriaTemporal inicializado, mas módulo real não encontrado.")
            self.memoria = {}
        
        def resetar_memoria(self, ativo=None):
            logger.warning("STUB: resetar_memoria chamado, mas módulo real não encontrado.")
            if ativo:
                if ativo in self.memoria:
                    del self.memoria[ativo]
            else:
                self.memoria = {}
            return True
        
        def atualizar_memoria(self, ativo, hora, score, acertou):
            logger.warning("STUB: atualizar_memoria chamado, mas módulo real não encontrado.")
            if ativo not in self.memoria:
                self.memoria[ativo] = []
            self.memoria[ativo].append({
                'hora': hora,
                'score': score,
                'acertou': acertou
            })
            return True
        
        def ajustar_por_memoria(self, ativo, hora, score):
            logger.warning("STUB: ajustar_por_memoria chamado, mas módulo real não encontrado.")
            # Sem ajuste real, apenas retorna o score original
            return score
        
        def obter_memoria(self, ativo=None):
            logger.warning("STUB: obter_memoria chamado, mas módulo real não encontrado.")
            import pandas as pd
            if ativo:
                if ativo in self.memoria:
                    return pd.DataFrame(self.memoria[ativo])
                return pd.DataFrame()
            
            # Combinar todos os ativos
            all_data = []
            for a, dados in self.memoria.items():
                for d in dados:
                    all_data.append({'ativo': a, **d})
            return pd.DataFrame(all_data)
        
        def obter_estatisticas(self, ativo=None):
            logger.warning("STUB: obter_estatisticas chamado, mas módulo real não encontrado.")
            stats = {
                "total_registros": 0,
                "acertos": 0,
                "erros": 0,
                "taxa_acerto": 0.0,
                "score_medio": 0.0,
                "ativos": []
            }
            
            # Calcular estatísticas básicas
            for a, dados in self.memoria.items():
                if ativo and a != ativo:
                    continue
                
                ativo_stats = {
                    "ativo": a,
                    "registros": len(dados),
                    "acertos": sum(1 for d in dados if d.get('acertou', False)),
                    "score_medio": sum(d.get('score', 0) for d in dados) / len(dados) if dados else 0
                }
                
                ativo_stats["erros"] = ativo_stats["registros"] - ativo_stats["acertos"]
                ativo_stats["taxa_acerto"] = ativo_stats["acertos"] / ativo_stats["registros"] if ativo_stats["registros"] > 0 else 0
                
                stats["total_registros"] += ativo_stats["registros"]
                stats["acertos"] += ativo_stats["acertos"]
                stats["erros"] += ativo_stats["erros"]
                stats["ativos"].append(ativo_stats)
            
            if stats["total_registros"] > 0:
                stats["taxa_acerto"] = stats["acertos"] / stats["total_registros"]
                
                # Calcular score médio global
                total_score = 0
                for a, dados in self.memoria.items():
                    if ativo and a != ativo:
                        continue
                    total_score += sum(d.get('score', 0) for d in dados)
                
                stats["score_medio"] = total_score / stats["total_registros"]
            
            return stats
        
        def exportar_memoria(self, formato="csv", caminho=None):
            logger.warning("STUB: exportar_memoria chamado, mas módulo real não encontrado.")
            import pandas as pd
            import json
            import os
            
            df = self.obter_memoria()
            if df.empty:
                return ""
            
            if not caminho:
                caminho = f"memoria_temporal_export.{formato}"
            
            try:
                if formato.lower() == "csv":
                    df.to_csv(caminho, index=False)
                elif formato.lower() == "json":
                    df.to_json(caminho, orient="records")
                elif formato.lower() == "excel":
                    df.to_excel(caminho, index=False)
                else:
                    logger.error(f"Formato não suportado: {formato}")
                    return ""
                
                return os.path.abspath(caminho)
            except Exception as e:
                logger.error(f"Erro ao exportar memória: {e}")
                return ""
        
        def importar_memoria(self, caminho, substituir=False):
            logger.warning("STUB: importar_memoria chamado, mas módulo real não encontrado.")
            import pandas as pd
            import os
            
            if not os.path.exists(caminho):
                logger.error(f"Arquivo não encontrado: {caminho}")
                return False
            
            try:
                # Determinar formato pelo nome do arquivo
                formato = os.path.splitext(caminho)[1].lower()
                
                if formato == ".csv":
                    df = pd.read_csv(caminho)
                elif formato == ".json":
                    df = pd.read_json(caminho)
                elif formato in [".xlsx", ".xls"]:
                    df = pd.read_excel(caminho)
                else:
                    logger.error(f"Formato não suportado: {formato}")
                    return False
                
                if substituir:
                    self.memoria = {}
                
                # Importar dados
                for _, row in df.iterrows():
                    ativo = row.get('ativo')
                    if not ativo:
                        continue
                    
                    if ativo not in self.memoria:
                        self.memoria[ativo] = []
                    
                    self.memoria[ativo].append({
                        'hora': row.get('hora'),
                        'score': row.get('score'),
                        'acertou': row.get('acertou', False)
                    })
                
                return True
            except Exception as e:
                logger.error(f"Erro ao importar memória: {e}")
                return False

# Exportar informações sobre a importação
def get_memoria_temporal_info() -> Dict[str, Any]:
    """Retorna informações sobre a importação do MemoriaTemporal."""
    return {
        "imported": MEMORIA_TEMPORAL_IMPORTED,
        "v2_available": MEMORIA_TEMPORAL_V2_AVAILABLE,
        "is_mac_m1": is_mac_m1(),
        "import_path": IMPORT_PATH_USED,
        "version": "v2" if MEMORIA_TEMPORAL_V2_AVAILABLE else "original" if MEMORIA_TEMPORAL_IMPORTED else "stub",
        "timestamp": import_time
    }

# Função para criar uma instância de MemoriaTemporal
def create_memoria_temporal(config: Optional[Dict[str, Any]] = None) -> MemoriaTemporal:
    """
    Cria uma instância de MemoriaTemporal com a configuração fornecida.
    
    Args:
        config: Configuração opcional para o MemoriaTemporal
        
    Returns:
        Instância de MemoriaTemporal
    """
    logger.info(f"Criando instância de MemoriaTemporal (versão: {get_memoria_temporal_info()['version']})")
    return MemoriaTemporal(config)

# Registrar o tempo de importação
import time
import datetime
import_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')

# Instância global para uso direto
memoria_temporal = create_memoria_temporal()

# Exportar funções da versão original para compatibilidade
def inicializar_memoria():
    return memoria_temporal.resetar_memoria()

def resetar_memoria(ativo=None):
    return memoria_temporal.resetar_memoria(ativo)

def atualizar_memoria(ativo, hora, score, acertou):
    return memoria_temporal.atualizar_memoria(ativo, hora, score, acertou)

def ajustar_por_memoria(ativo, hora, score):
    return memoria_temporal.ajustar_por_memoria(ativo, hora, score)

def obter_memoria(ativo=None):
    if hasattr(memoria_temporal, "obter_memoria"):
        return memoria_temporal.obter_memoria(ativo)
    logger.warning("Função obter_memoria não disponível na instância global")
    import pandas as pd
    return pd.DataFrame()

def obter_estatisticas(ativo=None):
    if hasattr(memoria_temporal, "obter_estatisticas"):
        return memoria_temporal.obter_estatisticas(ativo)
    logger.warning("Função obter_estatisticas não disponível na instância global")
    return {"erro": "Função não disponível"}

def exportar_memoria(formato="csv", caminho=None):
    if hasattr(memoria_temporal, "exportar_memoria"):
        return memoria_temporal.exportar_memoria(formato, caminho)
    logger.warning("Função exportar_memoria não disponível na instância global")
    return ""

def importar_memoria(caminho, substituir=False):
    if hasattr(memoria_temporal, "importar_memoria"):
        return memoria_temporal.importar_memoria(caminho, substituir)
    logger.warning("Função importar_memoria não disponível na instância global")
    return False
