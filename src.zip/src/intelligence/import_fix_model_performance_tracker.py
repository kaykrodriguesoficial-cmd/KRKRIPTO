#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Módulo de redirecionamento para model_performance_tracker.

Este módulo fornece compatibilidade com imports antigos,
redirecionando para a implementação atual em src.intelligence.model_performance_tracker_stub.

Versão: 2.0
Data: 2025-05-30
"""

import os
import sys
import logging
import importlib
import platform
import traceback
from typing import Dict, Any, Optional, List, Union
import importlib.util
from pathlib import Path

logger = logging.getLogger("kr_kripto_import_fix")

# Verificar se estamos em um Mac M1
def is_mac_m1() -> bool:
    """Verifica se o ambiente atual é um Mac M1 (Apple Silicon)."""
    try:
        if platform.system() == "Darwin" and ("arm" in platform.machine().lower() or "M1" in platform.processor()):
            logger.info(f"Ambiente Mac M1 detectado: {platform.machine()} / {platform.processor()}")
            return True
        return False
    except Exception as e:
        logger.error(f"Erro ao detectar ambiente: {e}")
        return False

# Flags para controle de importação
MODEL_TRACKER_IMPORTED = False
MODEL_TRACKER_VERSION = "unknown"
IMPORT_PATH_USED = None

# Tentar importar ModelPerformanceTracker de diferentes locais
try:
    # Primeiro tenta importar do caminho correto (intelligence)
    from src.intelligence.model_performance_tracker import ModelPerformanceTracker
    logger.info("ModelPerformanceTracker importado com sucesso de src.intelligence.model_performance_tracker")
    MODEL_TRACKER_IMPORTED = True
    MODEL_TRACKER_VERSION = "original"
    IMPORT_PATH_USED = "src.intelligence.model_performance_tracker"
except ImportError as e:
    logger.debug(f"Falha ao importar de src.intelligence.model_performance_tracker: {e}")
    try:
        # Tenta caminho alternativo sem prefixo src
        from intelligence.model_performance_tracker import ModelPerformanceTracker
        logger.info("ModelPerformanceTracker importado com sucesso de intelligence.model_performance_tracker")
        MODEL_TRACKER_IMPORTED = True
        MODEL_TRACKER_VERSION = "original"
        IMPORT_PATH_USED = "intelligence.model_performance_tracker"
    except ImportError as e:
        logger.debug(f"Falha ao importar de intelligence.model_performance_tracker: {e}")
        try:
            # Tenta versão stub
            from src.intelligence.model_performance_tracker_stub import ModelPerformanceTracker
            logger.info("ModelPerformanceTracker importado com sucesso de src.intelligence.model_performance_tracker_stub")
            MODEL_TRACKER_IMPORTED = True
            MODEL_TRACKER_VERSION = "stub"
            IMPORT_PATH_USED = "src.intelligence.model_performance_tracker_stub"
        except ImportError as e:
            logger.debug(f"Falha ao importar de src.intelligence.model_performance_tracker_stub: {e}")
            try:
                # Tenta versão stub sem prefixo src
                from intelligence.model_performance_tracker_stub import ModelPerformanceTracker
                logger.info("ModelPerformanceTracker importado com sucesso de intelligence.model_performance_tracker_stub")
                MODEL_TRACKER_IMPORTED = True
                MODEL_TRACKER_VERSION = "stub"
                IMPORT_PATH_USED = "intelligence.model_performance_tracker_stub"
            except ImportError as e:
                logger.debug(f"Falha ao importar de intelligence.model_performance_tracker_stub: {e}")
                # Se ainda falhar, tenta criar um stub dinamicamente
                logger.warning("ModelPerformanceTracker não encontrado, tentando criar stub dinamicamente...")
                
                # Procurar por arquivos model_performance_tracker*.py em diferentes diretórios
                for base_dir in [".", "src", "src/intelligence", "intelligence"]:
                    for suffix in ["", "_stub", "_v2", "_adaptado"]:
                        try:
                            file_path = os.path.join(base_dir, f"model_performance_tracker{suffix}.py")
                            if os.path.exists(file_path):
                                logger.info(f"Encontrado arquivo {file_path}")
                                
                                # Importar usando importlib
                                spec = importlib.util.spec_from_file_location(f"model_performance_tracker{suffix}", file_path)
                                module = importlib.util.module_from_spec(spec)
                                spec.loader.exec_module(module)
                                
                                # Verificar se tem a classe ModelPerformanceTracker
                                if hasattr(module, "ModelPerformanceTracker"):
                                    ModelPerformanceTracker = module.ModelPerformanceTracker
                                    logger.info(f"ModelPerformanceTracker importado com sucesso de {file_path}")
                                    MODEL_TRACKER_IMPORTED = True
                                    MODEL_TRACKER_VERSION = f"file_{suffix}" if suffix else "file"
                                    IMPORT_PATH_USED = file_path
                                    break
                                else:
                                    logger.warning(f"Arquivo {file_path} não contém ModelPerformanceTracker")
                        except Exception as e:
                            logger.debug(f"Erro ao tentar importar de {file_path}: {e}")
                
                # Se ainda não encontrou, tenta criar um stub em arquivo
                if not MODEL_TRACKER_IMPORTED:
                    try:
                        # Criar diretório se não existir
                        stub_dir = os.path.join("src", "intelligence")
                        os.makedirs(stub_dir, exist_ok=True)
                        
                        # Criar arquivo stub
                        stub_file = os.path.join(stub_dir, "model_performance_tracker_stub.py")
                        with open(stub_file, "w") as f:
                            f.write("""#!/usr/bin/env python3
# -*- coding: utf-8 -*-

\"\"\"
Stub para ModelPerformanceTracker quando o original não está disponível.
\"\"\"

import logging
import time
import json
import os
from typing import Dict, Any, Optional, List, Union
from datetime import datetime

logger = logging.getLogger("kr_kripto_model_tracker_stub")

class ModelPerformanceTrackerStub:
    \"\"\"Stub para ModelPerformanceTracker quando o original não está disponível.\"\"\"
    
    def __init__(self, config=None):
        self.config = config or {}
        self.models = {}
        self.performance_history = {}
        logger.warning("ModelPerformanceTrackerStub inicializado")
    
    def register_model(self, model_id, model_object):
        \"\"\"
        Registra um modelo para rastreamento de desempenho.
        
        Args:
            model_id: Identificador único do modelo
            model_object: Objeto do modelo
            
        Returns:
            True se o registro foi bem-sucedido, False caso contrário
        \"\"\"
        logger.warning(f"STUB: register_model chamado para modelo {model_id}")
        self.models[model_id] = model_object
        self.performance_history[model_id] = []
        return True
    
    def record_prediction(self, model_id, prediction, actual=None, timestamp=None):
        \"\"\"
        Registra uma predição para um modelo.
        
        Args:
            model_id: Identificador do modelo
            prediction: Valor predito
            actual: Valor real (opcional)
            timestamp: Timestamp da predição (opcional)
            
        Returns:
            True se o registro foi bem-sucedido, False caso contrário
        \"\"\"
        logger.warning(f"STUB: record_prediction chamado para modelo {model_id}")
        
        if model_id not in self.models:
            logger.error(f"Modelo {model_id} não registrado")
            return False
        
        if timestamp is None:
            timestamp = datetime.now().isoformat()
        
        self.performance_history.setdefault(model_id, []).append({
            "prediction": prediction,
            "actual": actual,
            "timestamp": timestamp
        })
        
        return True
    
    def update_performance(self, model_id, actual_value):
        \"\"\"
        Atualiza o desempenho de um modelo com o valor real.
        
        Args:
            model_id: Identificador do modelo
            actual_value: Valor real
            
        Returns:
            True se a atualização foi bem-sucedida, False caso contrário
        \"\"\"
        logger.warning(f"STUB: update_performance chamado para modelo {model_id}")
        
        if model_id not in self.models:
            logger.error(f"Modelo {model_id} não registrado")
            return False
        
        # Encontrar a última predição sem valor real
        for prediction in reversed(self.performance_history.get(model_id, [])):
            if prediction["actual"] is None:
                prediction["actual"] = actual_value
                break
        
        return True
    
    def get_performance(self, model_id):
        \"\"\"
        Obtém o desempenho de um modelo.
        
        Args:
            model_id: Identificador do modelo
            
        Returns:
            Dicionário com métricas de desempenho
        \"\"\"
        logger.warning(f"STUB: get_performance chamado para modelo {model_id}")
        
        if model_id not in self.models:
            logger.error(f"Modelo {model_id} não registrado")
            return {}
        
        # Retornar métricas simuladas
        return {
            "accuracy": 0.75,
            "precision": 0.8,
            "recall": 0.7,
            "f1_score": 0.75,
            "sample_count": len(self.performance_history.get(model_id, []))
        }
    
    def get_best_model(self, metric="accuracy", min_samples=10):
        \"\"\"
        Obtém o melhor modelo com base em uma métrica.
        
        Args:
            metric: Métrica para comparação
            min_samples: Número mínimo de amostras para considerar o modelo
            
        Returns:
            Identificador do melhor modelo ou None se nenhum modelo atender aos critérios
        \"\"\"
        logger.warning(f"STUB: get_best_model chamado (métrica: {metric})")
        
        best_model = None
        best_value = -float("inf")
        
        for model_id in self.models:
            performance = self.get_performance(model_id)
            if performance.get("sample_count", 0) >= min_samples:
                value = performance.get(metric, 0)
                if value > best_value:
                    best_value = value
                    best_model = model_id
        
        return best_model
    
    def get_all_models_performance(self):
        \"\"\"
        Retorna o desempenho de todos os modelos registrados.
        
        Returns:
            Dicionário com desempenho de todos os modelos
        \"\"\"
        logger.warning("STUB: get_all_models_performance chamado")
        
        result = {}
        for model_id in self.models:
            result[model_id] = self.get_performance(model_id)
        
        return result
    
    def reset(self):
        \"\"\"
        Reinicia o rastreador de desempenho.
        \"\"\"
        logger.warning("STUB: reset chamado no ModelPerformanceTrackerStub")
        self.performance_history = {model_id: [] for model_id in self.models}
        return True
        
    def save_state(self, filepath=None):
        \"\"\"
        Salva o estado atual do rastreador em um arquivo.
        
        Args:
            filepath: Caminho do arquivo para salvar o estado
            
        Returns:
            True se o salvamento foi bem-sucedido, False caso contrário
        \"\"\"
        logger.warning(f"STUB: save_state chamado (filepath: {filepath})")
        
        if not filepath:
            filepath = "model_tracker_state.json"
        
        try:
            # Criar uma versão serializável do estado
            state = {
                "models": list(self.models.keys()),
                "performance_history": self.performance_history
            }
            
            with open(filepath, "w") as f:
                json.dump(state, f, indent=2)
            
            logger.info(f"Estado salvo em {filepath}")
            return True
        except Exception as e:
            logger.error(f"Erro ao salvar estado: {e}")
            return False
    
    def load_state(self, filepath=None):
        \"\"\"
        Carrega o estado do rastreador de um arquivo.
        
        Args:
            filepath: Caminho do arquivo para carregar o estado
            
        Returns:
            True se o carregamento foi bem-sucedido, False caso contrário
        \"\"\"
        logger.warning(f"STUB: load_state chamado (filepath: {filepath})")
        
        if not filepath:
            filepath = "model_tracker_state.json"
        
        if not os.path.exists(filepath):
            logger.error(f"Arquivo {filepath} não encontrado")
            return False
        
        try:
            with open(filepath, "r") as f:
                state = json.load(f)
            
            # Restaurar apenas o histórico de desempenho
            self.performance_history = state.get("performance_history", {})
            
            logger.info(f"Estado carregado de {filepath}")
            return True
        except Exception as e:
            logger.error(f"Erro ao carregar estado: {e}")
            return False
""")
                        logger.info(f"Criado arquivo stub básico em {stub_file}")
                        
                        # Importar usando importlib para evitar problemas de cache
                        spec = importlib.util.spec_from_file_location("model_performance_tracker_stub", stub_file)
                        module = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(module)
                        ModelPerformanceTracker = module.ModelPerformanceTrackerStub
                        
                        logger.info("ModelPerformanceTrackerStub criado e importado com sucesso")
                        MODEL_TRACKER_IMPORTED = True
                        MODEL_TRACKER_VERSION = "stub_created"
                        IMPORT_PATH_USED = stub_file
                    except Exception as e:
                        logger.error(f"Erro ao tentar criar stub: {e}")
                        logger.debug(f"Traceback: {traceback.format_exc()}")

# Se nenhuma versão foi importada com sucesso, cria um stub em memória
if not MODEL_TRACKER_IMPORTED:
    logger.critical("Falha ao importar ModelPerformanceTracker. Usando implementação stub em memória.")
    
    class ModelPerformanceTracker:
        """Stub para ModelPerformanceTracker quando nenhuma implementação real está disponível."""
        
        def __init__(self, config=None):
            self.config = config or {}
            self.models = {}
            self.performance_history = {}
            logger.warning("STUB EM MEMÓRIA: ModelPerformanceTracker inicializado, mas módulo real não encontrado.")
        
        def register_model(self, model_id, model_object):
            logger.warning(f"STUB EM MEMÓRIA: register_model chamado para modelo {model_id}")
            self.models[model_id] = model_object
            self.performance_history[model_id] = []
            return True
        
        def record_prediction(self, model_id, prediction, actual=None, timestamp=None):
            logger.warning(f"STUB EM MEMÓRIA: record_prediction chamado para modelo {model_id}")
            if model_id not in self.models:
                logger.error(f"Modelo {model_id} não registrado")
                return False
                
            if timestamp is None:
                from datetime import datetime
                timestamp = datetime.now().isoformat()
                
            self.performance_history.setdefault(model_id, []).append({
                "prediction": prediction,
                "actual": actual,
                "timestamp": timestamp
            })
            return True
        
        def update_performance(self, model_id, actual_value):
            logger.warning(f"STUB EM MEMÓRIA: update_performance chamado para modelo {model_id}")
            if model_id not in self.models:
                logger.error(f"Modelo {model_id} não registrado")
                return False
                
            # Encontrar a última predição sem valor real
            for prediction in reversed(self.performance_history.get(model_id, [])):
                if prediction["actual"] is None:
                    prediction["actual"] = actual_value
                    break
            return True
        
        def get_performance(self, model_id):
            logger.warning(f"STUB EM MEMÓRIA: get_performance chamado para modelo {model_id}")
            if model_id not in self.models:
                logger.error(f"Modelo {model_id} não registrado")
                return {}
                
            # Calcular métricas básicas se houver dados suficientes
            history = self.performance_history.get(model_id, [])
            if not history:
                return {"accuracy": 0.0, "precision": 0.0, "recall": 0.0, "f1_score": 0.0, "sample_count": 0}
                
            # Filtrar apenas registros com valores reais
            complete_records = [r for r in history if r["actual"] is not None]
            if not complete_records:
                return {"accuracy": 0.0, "precision": 0.0, "recall": 0.0, "f1_score": 0.0, "sample_count": len(history)}
                
            # Simular métricas
            return {"accuracy": 0.75, "precision": 0.8, "recall": 0.7, "f1_score": 0.75, "sample_count": len(complete_records)}
        
        def get_best_model(self, metric="accuracy", min_samples=10):
            logger.warning(f"STUB EM MEMÓRIA: get_best_model chamado (métrica: {metric})")
            best_model = None
            best_value = -float("inf")
            
            for model_id in self.models:
                performance = self.get_performance(model_id)
                if performance.get("sample_count", 0) >= min_samples:
                    value = performance.get(metric, 0)
                    if value > best_value:
                        best_value = value
                        best_model = model_id
            
            return best_model
        
        def get_all_models_performance(self):
            logger.warning("STUB EM MEMÓRIA: get_all_models_performance chamado")
            return {model_id: self.get_performance(model_id) for model_id in self.models}
        
        def reset(self):
            logger.warning("STUB EM MEMÓRIA: reset chamado")
            self.performance_history = {model_id: [] for model_id in self.models}
            return True
        
        def save_state(self, filepath=None):
            logger.warning(f"STUB EM MEMÓRIA: save_state chamado (filepath: {filepath})")
            if not filepath:
                filepath = "model_tracker_state.json"
                
            try:
                import json
                # Criar uma versão serializável do estado
                state = {
                    "models": list(self.models.keys()),
                    "performance_history": self.performance_history
                }
                
                with open(filepath, "w") as f:
                    json.dump(state, f, indent=2)
                
                logger.info(f"Estado salvo em {filepath}")
                return True
            except Exception as e:
                logger.error(f"Erro ao salvar estado: {e}")
                return False
        
        def load_state(self, filepath=None):
            logger.warning(f"STUB EM MEMÓRIA: load_state chamado (filepath: {filepath})")
            if not filepath:
                filepath = "model_tracker_state.json"
                
            if not os.path.exists(filepath):
                logger.error(f"Arquivo {filepath} não encontrado")
                return False
                
            try:
                import json
                with open(filepath, "r") as f:
                    state = json.load(f)
                
                # Restaurar apenas o histórico de desempenho
                self.performance_history = state.get("performance_history", {})
                
                logger.info(f"Estado carregado de {filepath}")
                return True
            except Exception as e:
                logger.error(f"Erro ao carregar estado: {e}")
                return False

# Exportar informações sobre a importação
def get_model_tracker_info() -> Dict[str, Any]:
    """Retorna informações sobre a importação do ModelPerformanceTracker."""
    return {
        "imported": MODEL_TRACKER_IMPORTED,
        "version": MODEL_TRACKER_VERSION,
        "import_path": IMPORT_PATH_USED,
        "is_mac_m1": is_mac_m1(),
        "is_stub": MODEL_TRACKER_VERSION in ["stub", "stub_created", "memory_stub"],
        "timestamp": import_time
    }

# Função para criar uma instância de ModelPerformanceTracker
def create_model_tracker(config: Optional[Dict[str, Any]] = None) -> ModelPerformanceTracker:
    """
    Cria uma instância de ModelPerformanceTracker com a configuração fornecida.
    
    Args:
        config: Configuração opcional para o ModelPerformanceTracker
        
    Returns:
        Instância de ModelPerformanceTracker
    """
    logger.info(f"Criando instância de ModelPerformanceTracker (versão: {get_model_tracker_info()['version']})")
    return ModelPerformanceTracker(config)

# Registrar o tempo de importação
import time
import datetime
import_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')

# Instância global para uso direto
model_tracker = create_model_tracker()
