#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Módulo de correção de importação para PrometheusExporter no projeto KR_KRIPTO_ADVANCED.
Compatível com Mac M1 (ARM64) e ambientes Linux/Windows (x86_64).

Este módulo implementa um mecanismo robusto de importação que:
1. Tenta importar a versão v3 (mais recente e compatível com Mac M1)
2. Se falhar, tenta importar a versão v2
3. Se falhar, tenta importar a versão original
4. Se todas falharem, cria um stub básico para evitar erros de execução

Uso:
    from src.intelligence.import_fix_prometheus_exporter import PrometheusExporter, start_metrics_server
"""

import os
import sys
import logging
import shutil
import importlib.util
import platform
from typing import Dict, Any, Optional, List, Tuple, Callable, Union

# Configuração de logging
logger = logging.getLogger("kr_kripto_import_fix")

# Verificar se estamos em ambiente Mac M1
def is_mac_m1() -> bool:
    """Detecta se o ambiente de execução é um Mac com chip Apple Silicon (M1/M2/M3)."""
    return (
        platform.system() == "Darwin" and 
        platform.machine() == "arm64"
    )

# Variável global para controle de importação
PROMETHEUS_IMPORTED = False
PROMETHEUS_VERSION = None

# Lista de versões para tentar, em ordem de prioridade
versions_to_try = ["_v3", "_v2", ""]

# Lista de caminhos para tentar, em ordem de prioridade
paths_to_try = [
    "src.infrastructure.prometheus_exporter",
    "src.monitoring.prometheus_exporter",
    "infrastructure.prometheus_exporter",
    "monitoring.prometheus_exporter"
]

# Funções e classes que precisamos importar
required_items = [
    "PrometheusExporter", 
    "start_metrics_server",
    "inc_signals_processed",
    "inc_errors",
    "set_active_connection",
    "update_last_signal_timestamp",
    "signal_processing_latency_seconds",
    "fallback_metric",
    "set_binance_connection_status",
    "set_component_operational_status"
]

# Dicionário para armazenar os itens importados
imported_items = {}

# Tentar importar as versões em ordem de prioridade
for version in versions_to_try:
    # Pular iteração se já importou com sucesso
    if PROMETHEUS_IMPORTED:
        break
        
    suffix = version
    
    for base_path in paths_to_try:
        # Pular iteração se já importou com sucesso
        if PROMETHEUS_IMPORTED:
            break
            
        module_path = f"{base_path}{suffix}"
            
        try:
            # Importar usando importlib para evitar problemas de cache
            if importlib.util.find_spec(module_path):
                module = importlib.import_module(module_path)
                
                # Verificar se o módulo tem os itens necessários
                has_required_items = True
                for item in required_items:
                    if not hasattr(module, item) and item != "PrometheusExporter":
                        has_required_items = False
                        logger.warning(f"Módulo {module_path} não tem o item {item}")
                        break
                
                # Se o módulo tem os itens necessários, importá-los
                if has_required_items:
                    for item in required_items:
                        if hasattr(module, item):
                            imported_items[item] = getattr(module, item)
                    
                    # Verificar se o módulo tem a classe PrometheusExporter
                    if hasattr(module, "PrometheusExporter"):
                        PrometheusExporter = module.PrometheusExporter
                    else:
                        # Criar uma classe PrometheusExporter se não existir
                        class PrometheusExporter:
                            """Classe PrometheusExporter para compatibilidade."""
                            
                            def __init__(self, port=8000, addr='0.0.0.0'):
                                self.port = port
                                self.addr = addr
                                self.server_started = False
                                logger.info(f"PrometheusExporter v3.0.0 inicializado. Compatível com Mac M1: {is_mac_m1()}")
                            
                            def start(self):
                                """Inicia o servidor de métricas."""
                                if hasattr(module, "start_metrics_server"):
                                    return module.start_metrics_server(self.port, self.addr)
                                else:
                                    logger.error("Função start_metrics_server não encontrada")
                                    return False
                            
                            def is_operational(self):
                                """Verifica se o PrometheusExporter está operacional."""
                                if hasattr(module, "is_operational"):
                                    return module.is_operational()
                                else:
                                    return True
                    
                    # Exportar as funções e classes importadas
                    for item in required_items:
                        if item in imported_items:
                            globals()[item] = imported_items[item]
                    
                    logger.info(f"PrometheusExporter{suffix} importado com sucesso de {module_path}")
                    PROMETHEUS_IMPORTED = True
                    PROMETHEUS_VERSION = version if version else "original"
                    break
        except ImportError as e:
            logger.warning(f"Não foi possível importar PrometheusExporter de {module_path}: {e}")
        except Exception as e:
            logger.error(f"Erro ao importar PrometheusExporter de {module_path}: {e}")

# Se nenhuma versão foi importada com sucesso, criar um stub
if not PROMETHEUS_IMPORTED:
    logger.critical("Falha ao importar PrometheusExporter. Usando implementação stub em memória.")
    
    # Criar classes stub para métricas
    class MetricStub:
        def __init__(self, *args, **kwargs):
            pass
        def labels(self, **kwargs):
            return self
        def inc(self, *args, **kwargs):
            pass
        def set(self, *args, **kwargs):
            pass
        def observe(self, *args, **kwargs):
            pass
        def set_to_current_time(self, *args, **kwargs):
            pass
    
    class Counter(MetricStub): pass
    class Gauge(MetricStub): pass
    class Histogram(MetricStub): pass
    
    # Criar classe PrometheusExporter stub
    class PrometheusExporter:
        """Stub para PrometheusExporter quando nenhuma implementação real está disponível."""
        
        def __init__(self, port=8000, addr='0.0.0.0'):
            self.port = port
            self.addr = addr
            self.server_started = False
            logger.warning("STUB EM MEMÓRIA: PrometheusExporter inicializado, mas módulo real não encontrado.")
        
        def start(self):
            """Inicia o servidor de métricas."""
            logger.warning("STUB EM MEMÓRIA: start() chamado, mas módulo real não encontrado.")
            return False
        
        def is_operational(self):
            """Verifica se o PrometheusExporter está operacional."""
            return False
    
    # Criar funções stub
    def start_metrics_server(port=8000, addr='0.0.0.0'):
        """Stub para start_metrics_server."""
        logger.warning("STUB EM MEMÓRIA: start_metrics_server() chamado, mas módulo real não encontrado.")
        return False
    
    def inc_signals_processed(asset, regime, final_decision):
        """Stub para inc_signals_processed."""
        pass
    
    def inc_errors(component, asset="N/A"):
        """Stub para inc_errors."""
        pass
    
    def set_active_connection(asset, status):
        """Stub para set_active_connection."""
        pass
    
    def update_last_signal_timestamp(asset):
        """Stub para update_last_signal_timestamp."""
        pass
    
    def signal_processing_latency_seconds(asset, regime, duration):
        """Stub para signal_processing_latency_seconds."""
        pass
    
    # Criar fallback_metric stub
    fallback_metric = MetricStub()
    
    def set_binance_connection_status(connection_type, status):
        """Stub para set_binance_connection_status."""
        pass
    
    def set_component_operational_status(component_name, status, asset="global"):
        """Stub para set_component_operational_status."""
        pass

# Exportar informações sobre a importação
def get_prometheus_info() -> Dict[str, Any]:
    """Retorna informações sobre a importação do PrometheusExporter."""
    return {
        "imported": PROMETHEUS_IMPORTED,
        "version": PROMETHEUS_VERSION,
        "is_mac_m1": is_mac_m1(),
        "is_stub": PROMETHEUS_VERSION is None
    }

# Função para criar uma instância de PrometheusExporter
def create_prometheus_exporter(port: int = 8000, addr: str = '0.0.0.0') -> PrometheusExporter:
    """
    Cria uma instância de PrometheusExporter com a configuração fornecida.
    
    Args:
        port: Porta para o servidor HTTP
        addr: Endereço para o servidor HTTP
        
    Returns:
        Instância de PrometheusExporter
    """
    return PrometheusExporter(port, addr)

# Instância global para uso direto
prometheus_exporter = create_prometheus_exporter()

# Inicializar o servidor de métricas se o módulo for importado diretamente
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    logger.info("Inicializando PrometheusExporter...")
    
    # Criar instância e iniciar servidor
    exporter = create_prometheus_exporter()
    success = exporter.start()
    
    if success:
        logger.info("Servidor de métricas iniciado com sucesso.")
    else:
        logger.error("Falha ao iniciar servidor de métricas.")
