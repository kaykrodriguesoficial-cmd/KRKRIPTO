#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Módulo de Integração Inteligente para KR_KRIPTO_ADVANCED

Este módulo integra todos os componentes de IA avançados:
- ModelLoader (carregamento inteligente de modelos)
- NeuralGovernor (governança neural)
- Reinforcement Learning (agentes DQN/PPO)
- Institutional Patterns (análise em tempo real)

Autor: KR_KRIPTO Team
Data: Agosto 2025
Versão: 1.0.0
"""

import os
import sys
import logging
import asyncio
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Union, Tuple
from datetime import datetime
import traceback

# Configuração de logging
logger = logging.getLogger("kr_kripto_intelligence")

class IntelligenceIntegration:
    """
    Classe principal de integração de todos os componentes de IA avançados.
    
    Esta classe coordena:
    - Carregamento de modelos via ModelLoader
    - Seleção de modelos via NeuralGovernor
    - Agentes de RL para decisões de trading
    - Análise de padrões institucionais
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa a integração inteligente.
        
        Args:
            config: Configuração completa do sistema
        """
        self.config = config
        self.components = {}
        self.is_initialized = False
        
        # Configurações específicas
        self.model_config = config.get("model_paths", {})
        self.governance_config = config.get("governance_config", {})
        self.neural_governor_config = config.get("neural_governor_config", {})
        self.rl_config = config.get("reinforcement_learning_config", {})
        
        logger.info("IntelligenceIntegration inicializada")
    
    async def initialize_components(self) -> bool:
        """
        Inicializa todos os componentes de IA avançados.
        
        Returns:
            bool: True se todos os componentes foram inicializados com sucesso
        """
        try:
            logger.info("Inicializando componentes de IA avançados...")
            
            # 1. Inicializar ModelLoader
            success_model_loader = await self._initialize_model_loader()
            if not success_model_loader:
                logger.warning("ModelLoader não pôde ser inicializado completamente")
            
            # 2. Inicializar NeuralGovernor
            success_neural_governor = await self._initialize_neural_governor()
            if not success_neural_governor:
                logger.warning("NeuralGovernor não pôde ser inicializado completamente")
            
            # 3. Inicializar Reinforcement Learning
            success_rl = await self._initialize_reinforcement_learning()
            if not success_rl:
                logger.warning("Reinforcement Learning não pôde ser inicializado completamente")
            
            # 4. Inicializar Institutional Patterns
            success_institutional = await self._initialize_institutional_patterns()
            if not success_institutional:
                logger.warning("Institutional Patterns não pôde ser inicializado completamente")
            
            # Verificar se pelo menos os componentes críticos foram inicializados
            critical_components = [success_model_loader, success_neural_governor]
            if any(critical_components):
                self.is_initialized = True
                logger.info("Integração inteligente inicializada com sucesso")
                return True
            else:
                logger.error("Falha na inicialização dos componentes críticos")
                return False
                
        except Exception as e:
            logger.error(f"Erro na inicialização dos componentes: {e}")
            logger.error(traceback.format_exc())
            return False
    
    async def _initialize_model_loader(self) -> bool:
        """Inicializa o ModelLoader avançado."""
        try:
            from .model_loader import ModelLoader
            
            model_loader = ModelLoader(self.config)
            self.components['model_loader'] = model_loader
            
            logger.info("ModelLoader avançado inicializado com sucesso")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao inicializar ModelLoader: {e}")
            return False
    
    async def _initialize_neural_governor(self) -> bool:
        """Inicializa o NeuralGovernor avançado."""
        try:
            from .governance.neural_governance import NeuralGovernor
            
            # Passar o model_loader se disponível
            model_loader = self.components.get('model_loader')
            
            neural_governor = NeuralGovernor(
                config=self.neural_governor_config,
                model_loader=model_loader,
                models=self.config.get("governance_models", [])
            )
            
            self.components['neural_governor'] = neural_governor
            
            logger.info("NeuralGovernor avançado inicializado com sucesso")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao inicializar NeuralGovernor: {e}")
            return False
    
    async def _initialize_reinforcement_learning(self) -> bool:
        """Inicializa os componentes de Reinforcement Learning."""
        try:
            from .reinforcement.agente_rl_avancado import AgenteRL, AgenteDQN, AgentePPO
            from .reinforcement.ambiente_rl_avancado import AmbienteRL, AmbienteRLAvancado
            
            # Configuração do ambiente RL
            ambiente_config = {
                'ativos': list(self.config.get('ativos', {}).keys()),
                'capital_inicial': 1000.0,
                'custo_transacao': 0.001,
                'indicadores': ["rsi", "macd", "ema_9", "sma_20"]
            }
            
            # Inicializar ambiente
            ambiente = AmbienteRLAvancado(ambiente_config)
            self.components['ambiente_rl'] = ambiente
            
            # Configuração do agente RL
            agente_config = {
                'algoritmo': 'DQN',  # ou 'PPO'
                'learning_rate': 0.001,
                'epsilon': 0.1,
                'gamma': 0.95,
                'batch_size': 32
            }
            
            # Inicializar agente (DQN por padrão)
            agente = AgenteDQN(agente_config)
            self.components['agente_rl'] = agente
            
            logger.info("Reinforcement Learning inicializado com sucesso")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao inicializar Reinforcement Learning: {e}")
            return False
    
    async def _initialize_institutional_patterns(self) -> bool:
        """Inicializa o detector de padrões institucionais."""
        try:
            from .realtime.institutional_patterns import InstitutionalPatternDetector
            
            # Configuração para cada ativo
            institutional_detectors = {}
            ativos = self.config.get('ativos', {})
            
            for ativo in ativos.keys():
                detector_config = {
                    'wall_threshold': 2.0,
                    'iceberg_threshold': 0.5,
                    'absorption_threshold': 0.7,
                    'spoofing_threshold': 0.8
                }
                
                detector = InstitutionalPatternDetector(ativo, detector_config)
                institutional_detectors[ativo] = detector
            
            self.components['institutional_patterns'] = institutional_detectors
            
            logger.info("Institutional Patterns inicializado com sucesso")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao inicializar Institutional Patterns: {e}")
            return False
    
    async def generate_intelligent_prediction(self, ativo: str, df_klines: pd.DataFrame) -> Dict[str, Any]:
        """
        Gera predição inteligente usando todos os componentes de IA.
        
        Args:
            ativo: Símbolo do ativo (ex: 'BTCUSDT')
            df_klines: DataFrame com dados históricos
            
        Returns:
            Dict com predição, confiança e metadados
        """
        try:
            if not self.is_initialized:
                logger.warning("Componentes não inicializados, usando predição básica")
                return self._generate_basic_prediction(ativo, df_klines)
            
            logger.info(f"Gerando predição inteligente para {ativo}")
            
            # 1. Carregar modelo via ModelLoader
            modelo = None
            if 'model_loader' in self.components:
                modelo = self.components['model_loader'].carregar_modelo(ativo, '1h')
            
            # 2. Seleção de modelo via NeuralGovernor
            if 'neural_governor' in self.components and not modelo:
                modelo = await self._get_best_model_from_governor(ativo, df_klines)
            
            # 3. Análise de padrões institucionais
            institutional_signal = await self._get_institutional_signal(ativo, df_klines)
            
            # 4. Decisão via Reinforcement Learning
            rl_signal = await self._get_rl_signal(ativo, df_klines)
            
            # 5. Combinar sinais
            final_prediction = await self._combine_signals(
                modelo, institutional_signal, rl_signal, df_klines
            )
            
            logger.info(f"Predição inteligente gerada para {ativo}: {final_prediction['predicao']:.4f}")
            return final_prediction
            
        except Exception as e:
            logger.error(f"Erro na predição inteligente para {ativo}: {e}")
            return self._generate_basic_prediction(ativo, df_klines)
    
    async def _get_best_model_from_governor(self, ativo: str, df_klines: pd.DataFrame) -> Any:
        """Obtém o melhor modelo via NeuralGovernor."""
        try:
            neural_governor = self.components.get('neural_governor')
            if neural_governor:
                return neural_governor.selecionar_melhor_modelo(ativo, df_klines)
            return None
        except Exception as e:
            logger.error(f"Erro ao obter modelo do NeuralGovernor: {e}")
            return None
    
    async def _get_institutional_signal(self, ativo: str, df_klines: pd.DataFrame) -> Dict[str, Any]:
        """Obtém sinal dos padrões institucionais."""
        try:
            institutional_detectors = self.components.get('institutional_patterns', {})
            detector = institutional_detectors.get(ativo)
            
            if detector and len(df_klines) > 0:
                # Simular dados de order book (em implementação real, viria da API)
                last_price = df_klines['close'].iloc[-1]
                bids = {last_price * 0.999: 1000, last_price * 0.998: 2000}
                asks = {last_price * 1.001: 1000, last_price * 1.002: 2000}
                
                patterns = detector.detect_all_patterns(bids, asks)
                
                # Converter padrões em sinal
                if patterns.get('walls', {}).get('buy_wall_strength', 0) > 0.7:
                    return {'signal': 'COMPRAR', 'strength': 0.8, 'reason': 'buy_wall_detected'}
                elif patterns.get('walls', {}).get('sell_wall_strength', 0) > 0.7:
                    return {'signal': 'VENDER', 'strength': 0.8, 'reason': 'sell_wall_detected'}
            
            return {'signal': 'NEUTRO', 'strength': 0.5, 'reason': 'no_institutional_pattern'}
            
        except Exception as e:
            logger.error(f"Erro ao obter sinal institucional: {e}")
            return {'signal': 'NEUTRO', 'strength': 0.5, 'reason': 'error'}
    
    async def _get_rl_signal(self, ativo: str, df_klines: pd.DataFrame) -> Dict[str, Any]:
        """Obtém sinal do agente de Reinforcement Learning."""
        try:
            agente_rl = self.components.get('agente_rl')
            ambiente_rl = self.components.get('ambiente_rl')
            
            if agente_rl and ambiente_rl and len(df_klines) > 0:
                # Preparar estado para o agente RL
                estado = self._prepare_rl_state(df_klines)
                
                # Obter ação do agente
                acao = agente_rl.prever_acao(estado)
                
                # Converter ação em sinal
                if acao == 1:  # Comprar
                    return {'signal': 'COMPRAR', 'strength': 0.7, 'reason': 'rl_buy_signal'}
                elif acao == 2:  # Vender
                    return {'signal': 'VENDER', 'strength': 0.7, 'reason': 'rl_sell_signal'}
                else:  # Hold
                    return {'signal': 'MANTER', 'strength': 0.6, 'reason': 'rl_hold_signal'}
            
            return {'signal': 'MANTER', 'strength': 0.5, 'reason': 'no_rl_agent'}
            
        except Exception as e:
            logger.error(f"Erro ao obter sinal RL: {e}")
            return {'signal': 'MANTER', 'strength': 0.5, 'reason': 'error'}
    
    def _prepare_rl_state(self, df_klines: pd.DataFrame) -> np.ndarray:
        """Prepara estado para o agente RL."""
        try:
            # Usar últimas 10 observações
            recent_data = df_klines.tail(10)
            
            # Calcular indicadores básicos
            closes = recent_data['close'].values
            returns = np.diff(closes) / closes[:-1]
            
            # RSI simplificado
            gains = np.where(returns > 0, returns, 0)
            losses = np.where(returns < 0, -returns, 0)
            avg_gain = np.mean(gains) if len(gains) > 0 else 0
            avg_loss = np.mean(losses) if len(losses) > 0 else 0
            rsi = 100 - (100 / (1 + (avg_gain / (avg_loss + 1e-8))))
            
            # Estado: [preço_normalizado, rsi_normalizado, volatilidade]
            price_norm = (closes[-1] - np.mean(closes)) / (np.std(closes) + 1e-8)
            rsi_norm = (rsi - 50) / 50  # Normalizar RSI para [-1, 1]
            volatility = np.std(returns) if len(returns) > 0 else 0
            
            estado = np.array([price_norm, rsi_norm, volatility])
            return estado
            
        except Exception as e:
            logger.error(f"Erro ao preparar estado RL: {e}")
            return np.array([0.0, 0.0, 0.0])
    
    async def _combine_signals(self, modelo: Any, institutional_signal: Dict, 
                             rl_signal: Dict, df_klines: pd.DataFrame) -> Dict[str, Any]:
        """Combina todos os sinais em uma predição final."""
        try:
            # Pesos para cada componente
            weights = {
                'model': 0.4,
                'institutional': 0.3,
                'rl': 0.3
            }
            
            # Predição do modelo (se disponível)
            model_prediction = 0.5  # Neutro por padrão
            model_confidence = 0.5
            
            if modelo:
                try:
                    if callable(modelo):
                        result = modelo(df_klines)
                        model_prediction = result.get('predicao', 0.5)
                        model_confidence = result.get('confianca', 0.5)
                    else:
                        # Modelo real (Keras, sklearn, etc.)
                        # Implementar predição baseada no tipo do modelo
                        model_prediction = 0.5
                        model_confidence = 0.6
                except Exception as e:
                    logger.error(f"Erro na predição do modelo: {e}")
            
            # Converter sinais em valores numéricos
            institutional_value = self._signal_to_value(institutional_signal)
            rl_value = self._signal_to_value(rl_signal)
            
            # Combinar predições
            final_prediction = (
                weights['model'] * model_prediction +
                weights['institutional'] * institutional_value +
                weights['rl'] * rl_value
            )
            
            # Calcular confiança combinada
            final_confidence = (
                weights['model'] * model_confidence +
                weights['institutional'] * institutional_signal.get('strength', 0.5) +
                weights['rl'] * rl_signal.get('strength', 0.5)
            )
            
            # Metadados
            metadata = {
                'model_prediction': model_prediction,
                'institutional_signal': institutional_signal,
                'rl_signal': rl_signal,
                'combination_weights': weights,
                'timestamp': datetime.now().isoformat()
            }
            
            return {
                'predicao': final_prediction,
                'confianca': final_confidence,
                'metadata': metadata
            }
            
        except Exception as e:
            logger.error(f"Erro ao combinar sinais: {e}")
            return self._generate_basic_prediction('', df_klines)
    
    def _signal_to_value(self, signal: Dict[str, Any]) -> float:
        """Converte sinal em valor numérico."""
        signal_type = signal.get('signal', 'NEUTRO')
        strength = signal.get('strength', 0.5)
        
        if signal_type == 'COMPRAR':
            return 0.5 + (strength * 0.5)  # 0.5 a 1.0
        elif signal_type == 'VENDER':
            return 0.5 - (strength * 0.5)  # 0.0 a 0.5
        else:  # MANTER/NEUTRO
            return 0.5
    
    def _generate_basic_prediction(self, ativo: str, df_klines: pd.DataFrame) -> Dict[str, Any]:
        """Gera predição básica quando componentes avançados não estão disponíveis."""
        import random
        
        predicao = random.uniform(0.4, 0.6)
        confianca = random.uniform(0.5, 0.6)
        
        return {
            'predicao': predicao,
            'confianca': confianca,
            'metadata': {
                'method': 'basic_fallback',
                'timestamp': datetime.now().isoformat()
            }
        }
    
    def get_component_status(self) -> Dict[str, bool]:
        """Retorna status de todos os componentes."""
        return {
            'model_loader': 'model_loader' in self.components,
            'neural_governor': 'neural_governor' in self.components,
            'agente_rl': 'agente_rl' in self.components,
            'ambiente_rl': 'ambiente_rl' in self.components,
            'institutional_patterns': 'institutional_patterns' in self.components,
            'is_initialized': self.is_initialized
        }

