
def gerar_justificativa_de_decisao(ativo, modelo, regime, hora, score_final, probabilidade, fakeout, peso_risco):
    '''
    Gera uma justificativa textual para a decisão da IA, baseada em contexto real.
    '''

    qualidade_score = 'alta' if score_final > 0.85 else 'média' if score_final > 0.7 else 'baixa'
    nivel_confianca = 'alta' if probabilidade > 0.85 else 'razoável' if probabilidade > 0.65 else 'baixa'
    risco_fakeout = 'crítica' if fakeout > 0.6 else 'moderada' if fakeout > 0.4 else 'baixa'
    nivel_alocacao = 'agressiva' if peso_risco > 0.75 else 'moderada' if peso_risco > 0.4 else 'cautelosa'

    explicacao = (
        f"🧠 Decisão para {ativo}\n"
        f"Modelo Selecionado: {modelo}\n"
        f"Regime: {regime.upper()} — Hora: {hora}h\n\n"
        f"Score Final: {score_final}\n"
        f"Confiança (probabilidade): {probabilidade}\n"
        f"Fakeout Detectado: {fakeout}\n"
        f"Peso de Risco Aplicado: {peso_risco}\n\n"
        f"Interpretação:\n"
        f"- O modelo {modelo} foi selecionado com base no regime atual ({regime}) e hora estratégica ({hora}h).\n"
        f"- O score final indica {qualidade_score} qualidade do sinal.\n"
        f"- A probabilidade de acerto foi considerada {nivel_confianca}.\n"
        f"- A presença de fakeout foi considerada {risco_fakeout}.\n"
        f"- O capital foi alocado de forma {nivel_alocacao}.\n\n"
        f"Resultado: Decisão tática baseada em múltiplos vetores simultâneos."
    )

    return explicacao
