
def gerar_justificativa_de_decisao(ativo, regime, contexto, score, probabilidade, entropia, classe, decisao):
    fatores = []
    if probabilidade > 0.75:
        fatores.append("alta confiança da IA")
    if entropia < 0.10:
        fatores.append("baixa incerteza")
    if regime == "alta":
        fatores.append("regime de alta volatilidade")
    if contexto.get("institucional"):
        fatores.append("pressão institucional favorável")
    if contexto.get("tendencia"):
        fatores.append("tendência de alta confirmada")
    
    status = "ACEITA" if decisao else "REJEITADA"
    
    explicacao = (
        f"🧠 DECISÃO {status} para {ativo}:
"
        f"• Classe: {classe} | Score: {score:.2f} | Confiança: {probabilidade:.2f} | Entropia: {entropia:.4f}\n"
        f"• Regime: {regime} | Contexto: {contexto.get('hora', '?')}h\n"
        f"• Fatores-chave: {', '.join(fatores) if fatores else 'nenhum fator dominante'}"
    )
    return explicacao
