
import pandas as pd
from collections import defaultdict
from datetime import datetime, timedelta

class HistoricoDeSinais:
    def __init__(self, config: dict):
        self.sinais = defaultdict(list)
        self.janela = timedelta(minutes=janela_validade_minutos)

    def registrar_sinal(self, ativo, timestamp, classe, probabilidade, score, contexto):
        sinal = {
            'timestamp': timestamp,
            'classe': classe,
            'probabilidade': probabilidade,
            'score': score,
            'contexto': contexto,
            'avaliado': False,
            'resultado': None
        }
        self.sinais[ativo].append(sinal)

    def buscar_sinais_para_avaliar(self, ativo, tempo_atual):
        sinais = self.sinais.get(ativo, [])
        pendentes = []
        for sinal in sinais:
            if not sinal['avaliado'] and tempo_atual - sinal['timestamp'] >= self.janela:
                pendentes.append(sinal)
        return pendentes

    def registrar_resultado(self, ativo, timestamp, resultado_callback):
        sinais = self.buscar_sinais_para_avaliar(ativo, timestamp)
        for sinal in sinais:
            resultado = resultado_callback(sinal)
            sinal['resultado'] = resultado
            sinal['avaliado'] = True

    def exportar_para_csv(self, caminho):
        todos = []
        for ativo, sinais in self.sinais.items():
            for s in sinais:
                s_formatado = dict(s)
                s_formatado['ativo'] = ativo
                s_formatado['timestamp'] = s['timestamp'].isoformat()
                todos.append(s_formatado)
        df = pd.DataFrame(todos)
        df.to_csv(caminho, index=False)
