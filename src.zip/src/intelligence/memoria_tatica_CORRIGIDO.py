
import os
import pandas as pd
from inteligencia.log_por_ativo import registrar_log

CAMINHO_MEMORIA = "memoria_tatica.csv"
CAMINHO_LOG = "logs/memoria_tatica.csv"

os.makedirs("logs", exist_ok=True)

def inicializar_memoria():
    if not os.path.exists(CAMINHO_MEMORIA):
        colunas = ["ativo", "hora", "score_medio", "acertos", "erros", "taxa_acerto"]
        pd.DataFrame(columns=colunas).to_csv(CAMINHO_MEMORIA, index=False)

def resetar_memoria(ativo=None):
    inicializar_memoria()
    df = pd.read_csv(CAMINHO_MEMORIA)
    if ativo:
        df = df[df["ativo"] != ativo]
        registrar_log(ativo, "🧹 Memória tática resetada para esse ativo", "memoria_tatica")
    else:
        df = df[0:0]
        registrar_log("GLOBAL", "🧹 Memória tática global resetada", "memoria_tatica")
    df.to_csv(CAMINHO_MEMORIA, index=False)

def atualizar_memoria(ativo, hora, score, acertou):
    try:
        inicializar_memoria()
        df = pd.read_csv(CAMINHO_MEMORIA)
        cond = (df['ativo'] == ativo) & (df['hora'] == hora)

        if not any(cond):
            nova_linha = pd.DataFrame([{
                "ativo": ativo,
                "hora": hora,
                "score_medio": score,
                "acertos": int(acertou),
                "erros": int(not acertou),
                "taxa_acerto": int(acertou)
            }])
            df = pd.concat([df, nova_linha], ignore_index=True)
        else:
            i = df[cond].index[0]
            acertos = df.at[i, 'acertos'] + int(acertou)
            erros = df.at[i, 'erros'] + int(not acertou)
            total = acertos + erros
            df.at[i, 'acertos'] = acertos
            df.at[i, 'erros'] = erros
            df.at[i, 'score_medio'] = (df.at[i, 'score_medio'] + score) / 2
            df.at[i, 'taxa_acerto'] = acertos / total if total > 0 else 0.0

        df.to_csv(CAMINHO_MEMORIA, index=False)

        pd.DataFrame([{
            "timestamp": pd.Timestamp.now(),
            "ativo": ativo,
            "hora": hora,
            "score": score,
            "acerto": acertou
        }]).to_csv(CAMINHO_LOG, mode="a", header=not os.path.exists(CAMINHO_LOG), index=False)

        registrar_log(ativo, f"🧠 Memória tática atualizada | Hora={hora} | Score={score:.2f} | Acerto={acertou}", "memoria_tatica")

    except Exception as e:
        registrar_log(ativo, f"❌ Erro em atualizar_memoria: {e}", "memoria_tatica", "ERROR")

def ajustar_por_memoria(ativo, hora, score):
    try:
        inicializar_memoria()
        df = pd.read_csv(CAMINHO_MEMORIA)
        cond = (df['ativo'] == ativo) & (df['hora'] == hora)
        if any(cond):
            linha = df[cond].iloc[0]
            if linha['taxa_acerto'] < 0.3 and linha['score_medio'] < score:
                score -= 5
                registrar_log(ativo, f"⚠️ Score penalizado por baixa performance tática ({linha['taxa_acerto']:.2f})", "memoria_tatica")
            elif linha['taxa_acerto'] > 0.7:
                score += 3
                registrar_log(ativo, f"✅ Score bonificado por hora forte ({linha['taxa_acerto']:.2f})", "memoria_tatica")
    except Exception as e:
        registrar_log(ativo, f"Erro em ajustar_por_memoria: {e}", "memoria_tatica", "ERROR")
    return score
