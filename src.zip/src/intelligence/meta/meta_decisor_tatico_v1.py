
def escolher_modelo_tatico(contexto):
    """
    Decide qual modelo tático aplicar com base no regime, entropia e score.
    Retorna uma string identificando o modelo ideal para o momento.
    """
    regime = contexto.get("regime", "INDEFINIDO")
    entropia = contexto.get("entropia", 0.5)
    score = contexto.get("score", 0.5)

    # Estratégia condicional por regime
    if regime == "BEAR":
        return "RandomForest"
    elif regime == "LATERAL":
        if entropia < 0.3:
            return "Regras"
        else:
            return "DecisionTree"
    elif regime == "BULL":
        if score > 0.7:
            return "LSTM"
        else:
            return "CatBoost"

    return "Regras"
