
from collections import defaultdict

class QTableReforco:
    def __init__(self):
        # Tabela: regime -> hora -> modelo -> score acumulado
        self.qtable = defaultdict(lambda: defaultdict(lambda: defaultdict(float)))
        self.contagem = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))

    def registrar_recompensa(self, regime, hora, modelo, recompensa):
        self.qtable[regime][hora][modelo] += recompensa
        self.contagem[regime][hora][modelo] += 1

    def obter_modelo_ideal(self, regime, hora):
        modelos = self.qtable.get(regime, {}).get(hora, {})
        if not modelos:
            return None

        # Retorna o modelo com maior média ponderada
        melhores_modelos = {
            m: self.qtable[regime][hora][m] / max(1, self.contagem[regime][hora][m])
            for m in modelos
        }

        return max(melhores_modelos, key=melhores_modelos.get)

    def exportar_qtable(self):
        return dict(self.qtable)
