import pandas as pd
import os
import json
from datetime import datetime
from sklearn.metrics import accuracy_score

LOG_DECISOES = "historico_sinais.csv"
ARQUIVO_ESTADO = "estado_modelos.json"

def calcular_fitness_individual(df, modelo):
    df_modelo = df[df["modelo_usado"] == modelo]
    if len(df_modelo) < 20:
        return 0.0, 0.0, 0.0

    acuracia = accuracy_score(df_modelo["classe_real"], df_modelo["classe_prevista"])
    lucro = df_modelo["lucro"].sum()
    drawdown = (df_modelo["lucro"].cumsum().cummax() - df_modelo["lucro"].cumsum()).max()

    fitness = round((acuracia * 0.6) + (lucro * 0.3) - (drawdown * 0.1), 4)
    return acuracia, lucro, fitness

def avaliar_modelos(df_path=LOG_DECISOES, estado_path=ARQUIVO_ESTADO):
    if not os.path.exists(df_path):
        print("Arquivo de sinais não encontrado.")
        return

    df = pd.read_csv(df_path)
    df = df[df["classe_real"].notna() & df["classe_prevista"].notna()]
    df = df[df["modelo_usado"].notna()]

    modelos = df["modelo_usado"].unique()
    estado_atual = {}

    for modelo in modelos:
        acuracia, lucro, fitness = calcular_fitness_individual(df, modelo)
        estado_atual[modelo] = {
            "acuracia": round(acuracia, 4),
            "lucro_total": round(lucro, 2),
            "fitness": fitness,
            "ativo": fitness >= 0.3
        }

    with open(estado_path, "w") as f:
        json.dump(estado_atual, f, indent=2)

    print(f"[META-IA] Avaliação completa de {len(modelos)} modelos.")
    return estado_atual

def modelo_esta_ativo(modelo_nome, estado_path=ARQUIVO_ESTADO):
    if not os.path.exists(estado_path):
        return True  # por segurança, assume ativo

    with open(estado_path) as f:
        estado = json.load(f)
        if modelo_nome in estado:
            return estado[modelo_nome]["ativo"]
        return True
