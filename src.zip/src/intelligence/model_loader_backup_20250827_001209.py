# -*- coding: utf-8 -*-
"""
Implementação funcional do ModelLoader para substituir o stub.
Este módulo carrega modelos de IA a partir de arquivos e fornece
uma interface consistente para sua utilização.
"""

import logging
import os
import json
from typing import Dict, List, Any, Optional, Union
import importlib
import traceback

logger = logging.getLogger("kr_kripto_model_loader")

class ModelLoader:
    """
    Carregador de modelos de IA.
    Suporta diferentes tipos de modelos (keras, sklearn, pytorch) e
    fornece uma interface consistente para carregamento e utilização.
    """
    
    def __init__(self, config=None, *args, **kwargs):
        """
        Inicializa o ModelLoader.
        
        Args:
            config: Configuração opcional com parâmetros para o carregador
            *args: Argumentos posicionais adicionais (ignorados para compatibilidade)
            **kwargs: Argumentos nomeados adicionais (ignorados para compatibilidade)
        """
        # Ignorar argumentos extras para garantir compatibilidade com chamadas externas
        if args or kwargs:
            logger.debug(f"ModelLoader inicializado com argumentos extras: {len(args)} posicionais, {len(kwargs)} nomeados")
            
        self.config = config or {}
        self.models = {}
        self.model_types = {}
        self.model_paths = {}
        self.default_model_path = self.config.get("default_model_path", "models")
        
        # Verificar se os módulos necessários estão disponíveis
        self._check_dependencies()
        
        logger.info("ModelLoader inicializado")
    
    def _check_dependencies(self):
        """Verifica se as dependências necessárias estão disponíveis."""
        self.has_keras = False
        self.has_sklearn = False
        self.has_torch = False
        
        try:
            import tensorflow as tf
            from tensorflow import keras
            self.has_keras = True
            logger.info("TensorFlow/Keras disponível para carregamento de modelos")
        except ImportError:
            logger.warning("TensorFlow/Keras não disponível. Modelos Keras não poderão ser carregados.")
        
        try:
            import sklearn
            self.has_sklearn = True
            logger.info("scikit-learn disponível para carregamento de modelos")
        except ImportError:
            logger.warning("scikit-learn não disponível. Modelos sklearn não poderão ser carregados.")
        
        try:
            import torch
            self.has_torch = True
            logger.info("PyTorch disponível para carregamento de modelos")
        except ImportError:
            logger.warning("PyTorch não disponível. Modelos PyTorch não poderão ser carregados.")
    
    def load_model(self, model_id: str, model_path: str, model_type: str = "keras") -> bool:
        """
        Carrega um modelo a partir de um arquivo.
        
        Args:
            model_id: Identificador único para o modelo
            model_path: Caminho para o arquivo do modelo
            model_type: Tipo do modelo ('keras', 'sklearn', 'pytorch')
            
        Returns:
            True se o carregamento foi bem-sucedido, False caso contrário
        """
        if model_id in self.models:
            logger.warning(f"Modelo {model_id} já carregado. Substituindo.")
        
        # Verificar se o arquivo existe
        if not os.path.exists(model_path):
            logger.error(f"Arquivo de modelo não encontrado: {model_path}")
            return False
        
        try:
            # Carregar modelo com base no tipo
            if model_type.lower() == "keras":
                if not self.has_keras:
                    logger.error(f"TensorFlow/Keras não disponível para carregar modelo {model_id}")
                    return False
                
                from tensorflow import keras
                model = keras.models.load_model(model_path)
                
            elif model_type.lower() == "sklearn":
                if not self.has_sklearn:
                    logger.error(f"scikit-learn não disponível para carregar modelo {model_id}")
                    return False
                
                import joblib
                model = joblib.load(model_path)
                
            elif model_type.lower() == "pytorch":
                if not self.has_torch:
                    logger.error(f"PyTorch não disponível para carregar modelo {model_id}")
                    return False
                
                import torch
                model = torch.load(model_path)
                
            else:
                logger.error(f"Tipo de modelo não suportado: {model_type}")
                return False
            
            # Armazenar modelo e metadados
            self.models[model_id] = model
            self.model_types[model_id] = model_type.lower()
            self.model_paths[model_id] = model_path
            
            logger.info(f"Modelo {model_id} ({model_type}) carregado com sucesso de {model_path}")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao carregar modelo {model_id} de {model_path}: {e}")
            logger.debug(traceback.format_exc())
            return False
    
    def load_models(self, models_config=None) -> Dict[str, bool]:
        """
        Carrega múltiplos modelos a partir de uma configuração.
        
        Args:
            models_config: Lista de dicionários com configuração dos modelos
                Cada dicionário deve conter 'id', 'path' e 'type'
                Se None, tenta usar a configuração do sistema
                
        Returns:
            Dicionário com status de carregamento para cada modelo
        """
        # Se não foi fornecida configuração, tentar obter da configuração do sistema
        if models_config is None:
            try:
                # Tentar obter configuração do sistema
                import sys
                main_module = sys.modules.get('__main__')
                
                if main_module and hasattr(main_module, 'config'):
                    system_config = getattr(main_module, 'config')
                    if isinstance(system_config, dict) and "governance_models" in system_config:
                        models_config = system_config.get("governance_models", [])
                        logger.info(f"Usando configuração de modelos do sistema: {len(models_config)} modelos encontrados")
                    else:
                        logger.warning("Configuração do sistema não contém governance_models")
                        models_config = []
                else:
                    # Tentar obter de outras fontes comuns
                    try:
                        from src.core.config_loader import get_config
                        system_config = get_config()
                        if isinstance(system_config, dict) and "governance_models" in system_config:
                            models_config = system_config.get("governance_models", [])
                            logger.info(f"Usando configuração de modelos do config_loader: {len(models_config)} modelos encontrados")
                        else:
                            logger.warning("Configuração do config_loader não contém governance_models")
                            models_config = []
                    except:
                        logger.warning("Não foi possível obter configuração de modelos do sistema")
                        models_config = []
            except Exception as e:
                logger.error(f"Erro ao tentar obter configuração de modelos do sistema: {e}")
                models_config = []
        
        # Se ainda não temos configuração, usar lista vazia
        if models_config is None:
            logger.warning("Nenhuma configuração de modelos fornecida ou encontrada")
            models_config = []
        
        results = {}
        
        for model_config in models_config:
            model_id = model_config.get("id")
            model_path = model_config.get("path")
            model_type = model_config.get("type", "keras")
            enabled = model_config.get("enabled", True)
            
            if not model_id or not model_path:
                logger.error(f"Configuração de modelo inválida: {model_config}")
                results[model_id or "unknown"] = False
                continue
            
            if not enabled:
                logger.info(f"Modelo {model_id} desabilitado na configuração. Pulando.")
                results[model_id] = False
                continue
            
            # Carregar modelo
            success = self.load_model(model_id, model_path, model_type)
            results[model_id] = success
        
        # Log resumo
        loaded_count = sum(1 for success in results.values() if success)
        logger.info(f"Carregados {loaded_count}/{len(results)} modelos")
        
        return results
    
    def get_model(self, model_id: str) -> Optional[Any]:
        """
        Obtém um modelo carregado pelo seu ID.
        
        Args:
            model_id: Identificador do modelo
            
        Returns:
            Objeto do modelo ou None se não encontrado
        """
        if model_id not in self.models:
            logger.error(f"Modelo {model_id} não encontrado")
            return None
        
        return self.models[model_id]
        
    def carregar_modelo(self, ativo: str, intervalo: str) -> Optional[Any]:
        """
        Carrega um modelo específico para um ativo e intervalo.
        
        Args:
            ativo: Símbolo do ativo (ex: "BTCUSDT")
            intervalo: Intervalo de tempo (ex: "1h", "4h")
            
        Returns:
            Modelo carregado ou None se não encontrado
        """
        # Construir ID do modelo baseado no ativo e intervalo
        model_id = f"{ativo}_{intervalo}"
        
        # Verificar se o modelo já está carregado
        if model_id in self.models:
            logger.info(f"Modelo para {ativo} ({intervalo}) já carregado, usando cache")
            return self.models[model_id]
        
        # Tentar carregar o modelo
        try:
            # Construir caminho do modelo baseado na convenção
            model_path = os.path.join(self.default_model_path, ativo, f"{intervalo}.h5")
            
            # Verificar se o arquivo existe
            if not os.path.exists(model_path):
                logger.warning(f"Arquivo de modelo não encontrado para {ativo} ({intervalo}): {model_path}")
                return None
            
            # Tentar determinar o tipo do modelo pela extensão
            if model_path.endswith(".h5"):
                model_type = "keras"
            elif model_path.endswith(".pkl") or model_path.endswith(".joblib"):
                model_type = "sklearn"
            elif model_path.endswith(".pt") or model_path.endswith(".pth"):
                model_type = "pytorch"
            else:
                model_type = "keras"  # Padrão
            
            # Carregar o modelo
            success = self.load_model(model_id, model_path, model_type)
            if success:
                return self.models[model_id]
            else:
                return None
                
        except Exception as e:
            logger.error(f"Erro ao carregar modelo para {ativo} ({intervalo}): {e}")
            logger.debug(traceback.format_exc())
            return None
            
    def carregar_modelo_com_fallback(self, ativo: str, intervalo: str) -> Optional[Any]:
        """
        Carrega modelo com fallback para modelo genérico se necessário.
        
        Args:
            ativo: Símbolo do ativo (ex: "BTCUSDT")
            intervalo: Intervalo de tempo (ex: "1h", "4h")
            
        Returns:
            Modelo carregado (específico, genérico, alternativo ou stub)
        """
        logger.critical(f"DIAGNÓSTICO CRÍTICO: Tentando carregar modelo para {ativo} ({intervalo}) com fallback")
        
        try:
            # Tenta carregar o modelo específico primeiro
            logger.info(f"Tentando carregar modelo específico para {ativo} ({intervalo})")
            modelo = self.carregar_modelo(ativo, intervalo)
            if modelo:
                logger.info(f"Modelo específico carregado com sucesso para {ativo} ({intervalo})")
                return modelo
            
            # Tenta carregar modelo genérico para o intervalo
            logger.warning(f"Modelo específico não encontrado para {ativo} ({intervalo}). Tentando modelo genérico.")
            modelo_generico = self.carregar_modelo_generico(intervalo)
            if modelo_generico:
                logger.info(f"Modelo genérico carregado com sucesso para intervalo {intervalo}")
                return modelo_generico
            
            # Tenta carregar qualquer modelo disponível para o ativo
            logger.warning(f"Modelo genérico não encontrado para intervalo {intervalo}. Tentando qualquer modelo para {ativo}.")
            modelo_alternativo = self.carregar_qualquer_modelo_para_ativo(ativo)
            if modelo_alternativo:
                logger.info(f"Modelo alternativo carregado para {ativo}")
                return modelo_alternativo
                
        except Exception as e:
            logger.error(f"Erro ao carregar modelo para {ativo} ({intervalo}): {str(e)}")
            logger.error(traceback.format_exc())
        
        # Retorna modelo stub como último recurso
        logger.warning(f"Usando modelo stub para {ativo} ({intervalo})")
        return self.criar_modelo_stub()
    
    def carregar_modelo_generico(self, intervalo: str) -> Optional[Any]:
        """
        Carrega um modelo genérico para o intervalo especificado.
        
        Args:
            intervalo: Intervalo de tempo (ex: "1h", "4h")
            
        Returns:
            Modelo genérico ou None se não encontrado
        """
        try:
            # Tentar carregar modelo genérico
            logger.info(f"Tentando carregar modelo genérico para intervalo {intervalo}")
            
            # Construir caminho do modelo genérico baseado na convenção
            model_path = os.path.join(self.default_model_path, "generic", f"{intervalo}.h5")
            
            # Verificar se o arquivo existe
            if not os.path.exists(model_path):
                # Tentar caminhos alternativos comuns
                alt_paths = [
                    os.path.join(self.default_model_path, "generic", intervalo, "model.h5"),
                    os.path.join(self.default_model_path, "generic", f"model_{intervalo}.h5"),
                    os.path.join(self.default_model_path, "generic", f"generic_{intervalo}.h5")
                ]
                
                for alt_path in alt_paths:
                    if os.path.exists(alt_path):
                        model_path = alt_path
                        break
                else:
                    logger.warning(f"Nenhum modelo genérico encontrado para intervalo {intervalo}")
                    return None
            
            # Construir ID do modelo genérico
            model_id = f"generic_{intervalo}"
            
            # Tentar determinar o tipo do modelo pela extensão
            if model_path.endswith(".h5"):
                model_type = "keras"
            elif model_path.endswith(".pkl") or model_path.endswith(".joblib"):
                model_type = "sklearn"
            elif model_path.endswith(".pt") or model_path.endswith(".pth"):
                model_type = "pytorch"
            else:
                model_type = "keras"  # Padrão
            
            # Carregar o modelo
            success = self.load_model(model_id, model_path, model_type)
            if success:
                return self.models[model_id]
            else:
                return None
                
        except Exception as e:
            logger.error(f"Erro ao carregar modelo genérico para {intervalo}: {str(e)}")
            logger.error(traceback.format_exc())
            return None
    
    def carregar_qualquer_modelo_para_ativo(self, ativo: str) -> Optional[Any]:
        """
        Carrega qualquer modelo disponível para o ativo.
        
        Args:
            ativo: Símbolo do ativo (ex: "BTCUSDT")
            
        Returns:
            Qualquer modelo disponível para o ativo ou None se não encontrado
        """
        try:
            # Verificar se existe diretório para o ativo
            ativo_dir = os.path.join(self.default_model_path, ativo)
            if not os.path.exists(ativo_dir) or not os.path.isdir(ativo_dir):
                logger.warning(f"Diretório de modelos não encontrado para {ativo}: {ativo_dir}")
                return None
            
            # Listar arquivos no diretório
            arquivos = os.listdir(ativo_dir)
            modelos_candidatos = [f for f in arquivos if f.endswith(('.h5', '.pkl', '.joblib', '.pt', '.pth'))]
            
            if not modelos_candidatos:
                logger.warning(f"Nenhum arquivo de modelo encontrado para {ativo}")
                return None
            
            # Usar o primeiro modelo encontrado
            primeiro_modelo = modelos_candidatos[0]
            model_path = os.path.join(ativo_dir, primeiro_modelo)
            
            # Extrair intervalo do nome do arquivo (se possível)
            intervalo = primeiro_modelo.split('.')[0]
            model_id = f"{ativo}_{intervalo}_alt"
            
            # Tentar determinar o tipo do modelo pela extensão
            if model_path.endswith(".h5"):
                model_type = "keras"
            elif model_path.endswith(".pkl") or model_path.endswith(".joblib"):
                model_type = "sklearn"
            elif model_path.endswith(".pt") or model_path.endswith(".pth"):
                model_type = "pytorch"
            else:
                model_type = "keras"  # Padrão
            
            # Carregar o modelo
            logger.info(f"Tentando carregar modelo alternativo para {ativo}: {model_path}")
            success = self.load_model(model_id, model_path, model_type)
            if success:
                return self.models[model_id]
            else:
                return None
                
        except Exception as e:
            logger.error(f"Erro ao carregar qualquer modelo para {ativo}: {str(e)}")
            logger.error(traceback.format_exc())
            return None
    
    def criar_modelo_stub(self) -> Any:
        """
        Cria um modelo stub que retorna previsões aleatórias.
        
        Returns:
            Função que simula um modelo com previsões aleatórias
        """
        logger.warning("Criando modelo stub para fallback")
        
        # Verificar se já existe um modelo stub
        model_id = "stub_model"
        if model_id in self.models:
            logger.info("Usando modelo stub existente")
            return self.models[model_id]
        
        # Função de previsão aleatória
        def modelo_stub(dados):
            import random
            predicao = random.uniform(0.3, 0.7)  # Valor entre 0.3 e 0.7 para evitar sinais extremos
            confianca = random.uniform(0.5, 0.6)  # Confiança moderada
            return {"predicao": predicao, "confianca": confianca}
        
        # Registrar o modelo stub para reutilização
        self.models[model_id] = modelo_stub
        self.model_types[model_id] = "stub"
        self.model_paths[model_id] = "memory://stub_model"
        
        return modelo_stub
    
    def predict(self, model_id: str, input_data: Any) -> Optional[Any]:
        """
        Realiza uma predição usando o modelo especificado.
        
        Args:
            model_id: Identificador do modelo
            input_data: Dados de entrada para a predição
            
        Returns:
            Resultado da predição ou None em caso de erro
        """
        model = self.get_model(model_id)
        if model is None:
            return None
        
        model_type = self.model_types.get(model_id)
        
        try:
            # Realizar predição com base no tipo do modelo
            if model_type == "keras":
                import numpy as np
                
                # Verificar se os dados de entrada são numpy array
                if not isinstance(input_data, np.ndarray):
                    input_data = np.array(input_data)
                
                # Verificar se precisa adicionar dimensão de batch
                if len(input_data.shape) == 1:
                    input_data = np.expand_dims(input_data, axis=0)
                
                prediction = model.predict(input_data)
                
            elif model_type == "sklearn":
                # scikit-learn geralmente tem métodos predict ou predict_proba
                if hasattr(model, "predict_proba"):
                    prediction = model.predict_proba(input_data)
                else:
                    prediction = model.predict(input_data)
                
            elif model_type == "pytorch":
                import torch
                
                # Verificar se os dados de entrada são tensor
                if not isinstance(input_data, torch.Tensor):
                    input_data = torch.tensor(input_data, dtype=torch.float32)
                
                # Colocar modelo em modo de avaliação
                model.eval()
                
                # Desativar cálculo de gradientes
                with torch.no_grad():
                    prediction = model(input_data)
                
            else:
                logger.error(f"Tipo de modelo não suportado para predição: {model_type}")
                return None
            
            return prediction
            
        except Exception as e:
            logger.error(f"Erro ao realizar predição com modelo {model_id}: {e}")
            logger.debug(traceback.format_exc())
            return None
    
    def get_model_info(self, model_id: str) -> Dict[str, Any]:
        """
        Obtém informações sobre um modelo carregado.
        
        Args:
            model_id: Identificador do modelo
            
        Returns:
            Dicionário com informações do modelo
        """
        if model_id not in self.models:
            return {"error": f"Modelo {model_id} não encontrado"}
        
        model = self.models[model_id]
        model_type = self.model_types.get(model_id)
        model_path = self.model_paths.get(model_id)
        
        info = {
            "id": model_id,
            "type": model_type,
            "path": model_path,
            "loaded": True
        }
        
        # Adicionar informações específicas do tipo de modelo
        if model_type == "keras":
            try:
                info["layers"] = len(model.layers)
                info["input_shape"] = str(model.input_shape)
                info["output_shape"] = str(model.output_shape)
            except:
                pass
        
        return info
    
    def get_all_models_info(self) -> Dict[str, Dict[str, Any]]:
        """
        Obtém informações sobre todos os modelos carregados.
        
        Returns:
            Dicionário com informações de todos os modelos
        """
        return {model_id: self.get_model_info(model_id) for model_id in self.models}
    
    def unload_model(self, model_id: str) -> bool:
        """
        Descarrega um modelo da memória.
        
        Args:
            model_id: Identificador do modelo
            
        Returns:
            True se o modelo foi descarregado com sucesso
        """
        if model_id not in self.models:
            logger.warning(f"Modelo {model_id} não encontrado para descarregar")
            return False
        
        # Remover referências ao modelo
        del self.models[model_id]
        
        if model_id in self.model_types:
            del self.model_types[model_id]
        
        if model_id in self.model_paths:
            del self.model_paths[model_id]
        
        # Forçar coleta de lixo para liberar memória
        import gc
        gc.collect()
        
        logger.info(f"Modelo {model_id} descarregado")
        return True
    
    def unload_all_models(self) -> bool:
        """
        Descarrega todos os modelos da memória.
        
        Returns:
            True se todos os modelos foram descarregados com sucesso
        """
        model_ids = list(self.models.keys())
        
        for model_id in model_ids:
            self.unload_model(model_id)
        
        # Verificar se todos os modelos foram descarregados
        success = len(self.models) == 0
        
        if success:
            logger.info("Todos os modelos descarregados")
        else:
            logger.warning(f"Alguns modelos não foram descarregados: {list(self.models.keys())}")
        
        return success


# Classe de compatibilidade para manter a interface do stub
class ModelLoaderStub(ModelLoader):
    """
    Classe de compatibilidade que herda de ModelLoader.
    Mantém a interface do stub original para compatibilidade com código existente.
    """
    
    def __init__(self, config=None, *args, **kwargs):
        """
        Inicializa o ModelLoaderStub como um ModelLoader real.
        
        Args:
            config: Configuração opcional
            *args: Argumentos posicionais adicionais (ignorados para compatibilidade)
            **kwargs: Argumentos nomeados adicionais (ignorados para compatibilidade)
        """
        # Ignorar argumentos extras e passar apenas config para o construtor pai
        super().__init__(config)
        logger.info("ModelLoaderStub inicializado como implementação real")
        logger.debug(f"Argumentos extras ignorados: {len(args)} posicionais, {len(kwargs)} nomeados")
        
        # Criar modelo dummy para compatibilidade com código que espera um modelo sempre disponível
        self._create_dummy_model()
    
    def _create_dummy_model(self):
        """Cria um modelo dummy para compatibilidade."""
        try:
            # Tentar criar um modelo Keras dummy se disponível
            if self.has_keras:
                from tensorflow import keras
                inputs = keras.Input(shape=(10,))
                outputs = keras.layers.Dense(1, activation='sigmoid')(inputs)
                model = keras.Model(inputs=inputs, outputs=outputs)
                
                self.models["dummy_model"] = model
                self.model_types["dummy_model"] = "keras"
                self.model_paths["dummy_model"] = "memory://dummy_model"
                
                logger.info("Modelo dummy Keras criado para compatibilidade")
                return
            
            # Tentar criar um modelo sklearn dummy se disponível
            if self.has_sklearn:
                from sklearn.linear_model import LogisticRegression
                model = LogisticRegression()
                
                self.models["dummy_model"] = model
                self.model_types["dummy_model"] = "sklearn"
                self.model_paths["dummy_model"] = "memory://dummy_model"
                
                logger.info("Modelo dummy scikit-learn criado para compatibilidade")
                return
            
            # Se nenhum framework estiver disponível, criar um objeto com método predict
            class DummyModel:
                def predict(self, X):
                    import numpy as np
                    return np.array([[0.5]] * len(X))
            
            self.models["dummy_model"] = DummyModel()
            self.model_types["dummy_model"] = "dummy"
            self.model_paths["dummy_model"] = "memory://dummy_model"
            
            logger.info("Modelo dummy genérico criado para compatibilidade")
            
        except Exception as e:
            logger.error(f"Erro ao criar modelo dummy: {e}")
            logger.debug(traceback.format_exc())
