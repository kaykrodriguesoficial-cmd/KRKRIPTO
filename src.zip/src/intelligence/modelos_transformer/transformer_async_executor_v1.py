
import numpy as np
import hashlib
from concurrent.futures import ThreadPoolExecutor
from tensorflow.keras.models import load_model

# Caminho do modelo e hash esperado
MODELO_PATH = 'modelo_transformer_futuro.h5'
HASH_ESPERADO = 'INSIRA_O_HASH_REAL_AQUI'

# Executor global com 1 thread (pode ser expandido se necessário)
executor = ThreadPoolExecutor(max_workers=1)

# Verificação de integridade
def validar_integridade_modelo(path: str, hash_esperado: str) -> bool:
    with open(path, 'rb') as f:
        hash_calculado = hashlib.sha256(f.read()).hexdigest()
    return hash_calculado == hash_esperado

# Função de inferência síncrona (usada internamente pelo executor)
def _executar_inferencia(janela: np.ndarray) -> dict:
    if not validar_integridade_modelo(MODELO_PATH, HASH_ESPERADO):
        raise ValueError('❌ Modelo Transformer corrompido ou inválido.')

    model = load_model(MODELO_PATH)
    dados_exp = np.expand_dims(janela, axis=(0, -1))
    pred = model.predict(dados_exp, verbose=0)

    direcao = 'alta' if np.argmax(pred[0]) == 1 else 'baixa'
    forca = float(pred[1][0])

    return {
        'direcao_prevista': direcao,
        'forca_prevista': round(forca, 3),
        'volatilidade': 'alta' if forca > 0.7 else 'baixa',
        'reversao_prob': forca < 0.3
    }

# Interface externa: agenda a inferência
def agendar_previsao_transformer(janela: np.ndarray):
    return executor.submit(_executar_inferencia, janela)
