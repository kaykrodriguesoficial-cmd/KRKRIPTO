
import numpy as np
import hashlib
from tensorflow.keras.models import load_model

# Caminho absoluto do modelo
MODELO_PATH = 'modelo_transformer_futuro.h5'

# SHA256 esperado do modelo treinado (atualize isso com o valor real)
HASH_ESPERADO = 'INSIRA_O_HASH_REAL_AQUI'

# Validação de integridade
def validar_integridade_modelo(path: str, hash_esperado: str) -> bool:
    with open(path, 'rb') as f:
        hash_calculado = hashlib.sha256(f.read()).hexdigest()
    return hash_calculado == hash_esperado

# Execução de previsão com o Transformer
def obter_previsao_transformer(janela_atual: np.ndarray) -> dict:
    if not validar_integridade_modelo(MODELO_PATH, HASH_ESPERADO):
        raise ValueError('❌ Modelo Transformer corrompido ou adulterado.')

    model = load_model(MODELO_PATH)
    dados_exp = np.expand_dims(janela_atual, axis=(0, -1))
    pred = model.predict(dados_exp, verbose=0)

    direcao = 'alta' if np.argmax(pred[0]) == 1 else 'baixa'
    forca = float(pred[1][0])

    return {
        'direcao_prevista': direcao,
        'forca_prevista': round(forca, 3),
        'volatilidade': 'alta' if forca > 0.7 else 'baixa',
        'reversao_prob': forca < 0.3
    }
