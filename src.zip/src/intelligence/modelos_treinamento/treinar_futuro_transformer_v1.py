
# treinar_futuro_transformer.py
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, LayerNormalization, Dropout
from tensorflow.keras.layers import MultiHeadAttention, GlobalAveragePooling1D, Add
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping

# === 1. Carregar dados ===
df = pd.read_csv('/Volumes/Extreme SSD/KR_KRIPTO_ADVANCED/src/intelligence/modelos_treinamento/dados_treinamento.csv')

# === 2. Preparar dados ===
X = df.drop(columns=['direcao_futura', 'forca_prevista'])
y_direcao = pd.get_dummies(df['direcao_futura'])
y_forca = df['forca_prevista'].values

X_train, X_test, y_dir_train, y_dir_test, y_forca_train, y_forca_test = train_test_split(
    X, y_direcao, y_forca, test_size=0.2, random_state=42
)

# === 3. Construir Transformer simples ===
def build_model(input_shape):
    inp = Input(shape=input_shape)
    x = LayerNormalization()(inp)
    x = MultiHeadAttention(num_heads=4, key_dim=16)(x, x)
    x = Dropout(0.1)(x)
    x = Add()([inp, x])
    x = GlobalAveragePooling1D()(x)

    direcao_out = Dense(2, activation='softmax', name='direcao')(x)
    forca_out = Dense(1, activation='sigmoid', name='forca')(x)

    model = Model(inputs=inp, outputs=[direcao_out, forca_out])
    model.compile(optimizer=Adam(1e-4),
                  loss={'direcao': 'categorical_crossentropy', 'forca': 'mse'},
                  metrics={'direcao': 'accuracy', 'forca': 'mae'})
    return model

# === 4. Treinar modelo ===
model = build_model((X_train.shape[1], 1))
model.summary()

X_train_exp = np.expand_dims(X_train.values, axis=-1)
X_test_exp = np.expand_dims(X_test.values, axis=-1)

model.fit(X_train_exp, {'direcao': y_dir_train, 'forca': y_forca_train},
          validation_data=(X_test_exp, {'direcao': y_dir_test, 'forca': y_forca_test}),
          epochs=50, batch_size=32, callbacks=[EarlyStopping(patience=5)])

model.save('modelo_transformer_futuro.h5')
