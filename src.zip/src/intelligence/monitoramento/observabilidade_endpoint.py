"""
Módulo: observabilidade_endpoint.py
Objetivo: Servir métricas de observabilidade via HTTP local.
"""

from fastapi import FastAPI
from fastapi.responses import JSONResponse
import time
import hashlib
import os

app = FastAPI()

# Estado simulado (em produção, essas variáveis devem ser atualizadas pelo sistema)
last_predict_latency_ms = 85.3
ws_start_time = time.time()
model_path = "modelo_transformer_futuro.h5"

def calcular_sha256(path):
    if not os.path.exists(path):
        return None
    sha256_hash = hashlib.sha256()
    with open(path, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()

@app.get("/metrics")
def get_metrics():
    uptime = round(time.time() - ws_start_time, 2)
    hash_ok = calcular_sha256(model_path) is not None  # ajuste com hash esperado real se quiser
    metrics = {
        "last_predict_latency_ms": last_predict_latency_ms,
        "ws_uptime": uptime,
        "model_hash_ok": hash_ok
    }
    return JSONResponse(content=metrics)

# Para rodar: uvicorn infraestrutura.monitoramento.observabilidade_endpoint:app --reload
