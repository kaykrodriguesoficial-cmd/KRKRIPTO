
import time
from inteligencia.avaliadores.avaliador_modelo import avaliar_performance_por_modelo
from inteligencia.evolucao.mutacao_baseada_em_feedback import mutar_com_base_em_feedback
from inteligencia.meta.reforco_qtable import qtable
from executors.logger import log_erro

historico_pnls = {}

def supervisor_ciclo(intervalo=60, threshold_queda=-0.01, min_usos=5):
    '''
    Monitora continuamente os modelos e dispara mutações ou quarentenas com base no desempenho.

    Parâmetros:
    - intervalo: tempo entre verificações (segundos)
    - threshold_queda: PnL médio abaixo do qual o modelo é considerado problemático
    - min_usos: quantidade mínima de sinais emitidos para avaliação

    '''
    print("🧠 Supervisor Fluxo iniciado.")
    while True:
        try:
            relatorio = avaliar_performance_por_modelo()
            for modelo, dados in relatorio.items():
                media_pnl = dados.get("media_pnl", 0.0)
                usos = dados.get("usos", 0)
                regime = dados.get("regime", "desconhecido")
                hora = str(dados.get("hora", "00"))

                if usos >= min_usos and media_pnl < threshold_queda:
                    log_erro(f"🚨 Modelo {modelo} abaixo da linha: PnL={media_pnl:.4f} em {usos} usos. Mutação forçada.")
                    mutar_com_base_em_feedback(regime, hora, {modelo: media_pnl})

        except Exception as e:
            log_erro(f"Erro no supervisor_fluxo: {e}")

        time.sleep(intervalo)
