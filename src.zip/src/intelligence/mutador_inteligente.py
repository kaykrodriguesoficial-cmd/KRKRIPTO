
import pandas as pd
import os
import joblib
import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

def avaliar_e_mutar_modelo(log_path='logs/autoavaliador.csv', modelo_atual_path='modelo_fusao_contextual.pkl'):
    '''
    Avalia desempenho da IA com base nos erros registrados.
    Se detectar falhas contínuas, treina um novo modelo e substitui se for melhor.
    '''
    if not os.path.exists(log_path):
        print("[MUTADOR] Nenhum log encontrado para análise.")
        return

    df = pd.read_csv(log_path)
    if len(df) < 100:
        print("[MUTADOR] Ainda não há dados suficientes para avaliação evolutiva.")
        return

    acertos = df['erro'].value_counts().get(False, 0)
    erros = df['erro'].value_counts().get(True, 0)
    total = acertos + erros
    taxa_erro = erros / total

    print(f"[MUTADOR] Acurácia atual: {acertos/total:.2%}, Erros: {erros}, Total: {total}")

    if taxa_erro < 0.4:
        print("[MUTADOR] Modelo atual ainda está performando bem. Nenhuma mutação necessária.")
        return

    print("[MUTADOR] Iniciando processo de mutação neural...")

    # Preparar dados para re-treinamento
    features = [
        'score_final',
        'probabilidade',
        'divergencia',
        'contexto_regime',
        'fator_rentabilidade',
        'fakeout_detectado',
        'previsao_lstm',
        'validador_volume_profile',
        'validador_book_imbalance',
        'validador_zona_rejeicao'
    ]

    df_treino = df[features + ['resultado_real']].dropna()
    df_treino['resultado_real'] = df_treino['resultado_real'].apply(lambda x: 1 if x > 0 else 0)

    X = df_treino[features]
    y = df_treino['resultado_real']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

    # Novo modelo com mutação (estrutura modificada)
    novo_modelo = MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=1000, random_state=42)
    novo_modelo.fit(X_train, y_train)
    y_pred = novo_modelo.predict(X_test)
    nova_acc = accuracy_score(y_test, y_pred)

    print(f"[MUTADOR] Novo modelo testado. Acurácia: {nova_acc:.2%}")

    if nova_acc > (1 - taxa_erro):
        joblib.dump(novo_modelo, modelo_atual_path)
        print("[MUTADOR] Novo modelo substituiu o antigo com sucesso.")
    else:
        print("[MUTADOR] Novo modelo não superou o atual. Nenhuma troca feita.")
