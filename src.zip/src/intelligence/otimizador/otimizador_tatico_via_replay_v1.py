
import json
from executors.logger import log_erro

CAMINHO_MEMORIA = "memoria_estrategica_longaprazo.jsonl"

def otimizar_parametros_via_replay(filtros=None, limite=100):
    try:
        criterio_acertos = {}
        criterio_total = {}
        
        with open(CAMINHO_MEMORIA, "r") as f:
            linhas = f.readlines()[-limite:]
            for linha in linhas:
                entrada = json.loads(linha)
                if filtros:
                    if any(str(entrada.get(k)) != str(v) for k, v in filtros.items()):
                        continue

                retorno = entrada["resultado"].get("retorno")
                if retorno is None:
                    continue

                for criterio, valor in entrada["contexto"].items():
                    if not isinstance(valor, (int, float)):
                        continue
                    criterio_total[criterio] = criterio_total.get(criterio, 0) + 1
                    if retorno > 0:
                        criterio_acertos[criterio] = criterio_acertos.get(criterio, 0) + 1

        pesos = {}
        for criterio in criterio_total:
            taxa = criterio_acertos.get(criterio, 0) / criterio_total[criterio]
            pesos[criterio] = round(min(1.5, max(0.1, taxa)), 2)

        total_peso = sum(pesos.values()) or 1
        pesos_normalizados = {k: v / total_peso for k, v in pesos.items()}
        return pesos_normalizados
    except Exception as e:
        log_erro(f"[OTIMIZAÇÃO] Erro ao otimizar parâmetros: {e}")
        return {}
