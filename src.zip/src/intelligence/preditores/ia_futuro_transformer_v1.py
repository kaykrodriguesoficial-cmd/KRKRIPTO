# ia_futuro_transformer.py
import os
import numpy as np
import pandas as pd
from tensorflow.keras.models import load_model, Sequential
from tensorflow.keras.layers import Dense, LSTM, Dropout
import logging

logger = logging.getLogger("kr_kripto")

# Definir caminho para o modelo
modelo_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'modelos')
modelo_path = os.path.join(modelo_dir, 'modelo_transformer_futuro.h5')

# Tentar carregar o modelo, criar um novo se não existir
try:
    model = load_model(modelo_path)
    logger.info(f"Modelo carregado com sucesso de {modelo_path}")
except:
    logger.warning(f"Modelo não encontrado em {modelo_path}. Criando modelo inicial...")
    # Criar um modelo simples para iniciar
    model = Sequential([
        LSTM(50, return_sequences=True, input_shape=(20, 1)),
        Dropout(0.2),
        LSTM(50, return_sequences=False),
        Dropout(0.2),
        Dense(2, activation='softmax')
    ])
    model.compile(optimizer='adam', loss='categorical_crossentropy')
    
    # Salvar o modelo inicial
    os.makedirs(modelo_dir, exist_ok=True)
    model.save(modelo_path)
    logger.info(f"Modelo inicial criado e salvo em {modelo_path}")

def prever_futuro_transformer(janela_atual: pd.DataFrame) -> dict:
    try:
        dados = janela_atual.values
        dados_exp = np.expand_dims(dados, axis=(0, -1))
        
        pred = model.predict(dados_exp, verbose=0)
        
        # Verificar formato da saída do modelo
        if isinstance(pred, list) and len(pred) > 1:
            direcao = 'alta' if np.argmax(pred[0]) == 1 else 'baixa'
            forca = float(pred[1][0])
        else:
            # Adaptação para modelo inicial que pode ter formato diferente
            direcao = 'alta' if np.argmax(pred[0]) == 1 else 'baixa'
            forca = float(np.max(pred[0]))
        
        return {
            'direcao_prevista': direcao,
            'forca_prevista': round(forca, 3),
            'volatilidade': 'alta' if forca > 0.7 else 'baixa',
            'reversao_prob': forca < 0.3
        }
    except Exception as e:
        logger.error(f"Erro ao fazer previsão: {e}")
        # Retornar valores padrão em caso de erro
        return {
            'direcao_prevista': 'neutra',
            'forca_prevista': 0.5,
            'volatilidade': 'média',
            'reversao_prob': False
        }

# Versão assíncrona para uso com asyncio
async def prever_futuro_transformer_async(janela_atual: pd.DataFrame) -> dict:
    """
    Versão assíncrona da função para prever o futuro
    """
    import asyncio
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, prever_futuro_transformer, janela_atual)
