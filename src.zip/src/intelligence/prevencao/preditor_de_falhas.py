
import math

def estimar_risco_de_falha(probabilidade, fakeout, regime, historico_modelo, volatilidade=1.0):
    '''
    Avalia o risco de falha de um sinal com base em múltiplos fatores:
    - Confiança do modelo
    - Fator de fakeout (risco de armadilha)
    - Regime de mercado
    - Histórico de falhas do modelo nesse regime
    - Volatilidade do momento

    Retorna:
    - risco (float entre 0 e 1): 0 = seguro, 1 = risco total
    - descricao (str): análise textual da composição do risco
    '''

    risco = 0.0
    fatores = []

    if probabilidade < 0.65:
        risco += 0.3
        fatores.append("baixa confiança")

    if fakeout > 0.6:
        risco += 0.25
        fatores.append("alto fakeout")

    if regime in ["consolidacao", "lateral"]:
        risco += 0.15
        fatores.append("regime instável")

    falhas_passadas = historico_modelo.get(regime, {}).get("falhas", 0)
    execucoes = historico_modelo.get(regime, {}).get("total", 1)
    taxa_falha = falhas_passadas / execucoes
    if taxa_falha > 0.4:
        risco += 0.2
        fatores.append("histórico ruim no regime")

    if volatilidade > 2.0:
        risco += 0.15
        fatores.append("alta volatilidade")

    risco = min(round(risco, 3), 1.0)
    descricao = ", ".join(fatores) if fatores else "baixo risco detectado"
    return risco, descricao
