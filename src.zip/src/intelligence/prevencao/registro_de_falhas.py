
import json
import os
from datetime import datetime

CAMINHO_REGISTRO = "dados/falhas/falhas_reincidentes.json"

def registrar_falha(ativo, modelo, contexto):
    os.makedirs(os.path.dirname(CAMINHO_REGISTRO), exist_ok=True)
    dado = {
        "timestamp": datetime.utcnow().isoformat(),
        "ativo": ativo,
        "modelo": modelo,
        "contexto": contexto
    }

    try:
        if os.path.exists(CAMINHO_REGISTRO):
            with open(CAMINHO_REGISTRO, "r") as f:
                falhas = json.load(f)
        else:
            falhas = {}

        chave = f"{ativo}::{modelo}"
        if chave not in falhas:
            falhas[chave] = []
        falhas[chave].append(dado)

        with open(CAMINHO_REGISTRO, "w") as f:
            json.dump(falhas, f, indent=4)

        print(f"📌 Falha registrada para {modelo} em {ativo}")
    except Exception as e:
        print(f"❌ Erro ao registrar falha: {e}")
