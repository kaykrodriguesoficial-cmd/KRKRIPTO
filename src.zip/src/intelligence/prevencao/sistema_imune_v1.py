
from executors.logger import log_erro
from datetime import datetime

def verificar_sistema_imune(ativo, ultima_atividade, tentativas_falhas, delay_execucao):
    """
    Avalia sinais de instabilidade ou falha operativa para aplicar medidas imunes.
    """
    try:
        agora = datetime.utcnow()
        delta = (agora - ultima_atividade).total_seconds()

        if tentativas_falhas > 3:
            log_erro(f"[IMUNE] ⚠️ Falhas consecutivas detectadas no agente {ativo}. Reset recomendado.")
            return "reiniciar"

        if delta > 300:
            log_erro(f"[IMUNE] ⚠️ Inatividade prolongada detectada ({delta:.0f}s) — intervenção recomendada.")
            return "verificar"

        if delay_execucao > 5:
            log_erro(f"[IMUNE] ⚠️ Execução lenta detectada para {ativo} ({delay_execucao:.2f}s) — performance comprometida.")
            return "ajustar"

        return "ok"
    except Exception as e:
        log_erro(f"[IMUNE] Erro no núcleo imune para {ativo}: {e}")
        return "erro"
