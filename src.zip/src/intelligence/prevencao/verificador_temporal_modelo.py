
import numpy as np

def verificar_consistencia_temporal(decisoes_recentes, padrao_historico, tolerancia=0.25):
    '''
    Compara as últimas decisões de um modelo com seu padrão histórico de comportamento.
    
    Parâmetros:
    - decisoes_recentes: lista de decisões recentes (ex: scores, direções, probabilidades)
    - padrao_historico: lista média histórica ou distribuição esperada
    - tolerancia: limite de desvio percentual aceitável

    Retorna:
    - bool: True se o comportamento está dentro do esperado, False se desvio é crítico
    - str: explicação da consistência ou desvio detectado
    '''
    if len(decisoes_recentes) < 5 or len(padrao_historico) < 5:
        return True, "dados insuficientes para avaliação temporal"

    media_recente = np.mean(decisoes_recentes)
    media_historica = np.mean(padrao_historico)

    if media_historica == 0:
        return True, "padrão histórico nulo, sem comparação possível"

    desvio = abs(media_recente - media_historica) / abs(media_historica)

    if desvio > tolerancia:
        return False, f"❗ Desvio crítico detectado ({round(desvio * 100, 2)}%) — comportamento instável"
    else:
        return True, f"✅ Consistência temporal mantida ({round(desvio * 100, 2)}% de variação)"
