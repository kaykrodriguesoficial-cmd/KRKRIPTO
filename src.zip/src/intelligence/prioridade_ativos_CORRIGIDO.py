
import pandas as pd
import os
from inteligencia.log_por_ativo import registrar_log

def calcular_prioridade_ativos(caminho_csv="historico_sinais.csv", minimo=50):
    '''
    Avalia o desempenho de cada ativo com base no histórico de sinais e gera uma prioridade.
    Retorna um dicionário {ativo: prioridade (alta, media, baixa)}
    '''

    prioridades = {}

    try:
        if not os.path.exists(caminho_csv):
            registrar_log("GLOBAL", f"📂 Arquivo {caminho_csv} não encontrado.", "prioridade_ativos")
            return {}

        df = pd.read_csv(caminho_csv, on_bad_lines='skip')

        if 'par' not in df.columns or 'resultado_5_candles' not in df.columns or 'classe_prevista' not in df.columns:
            registrar_log("GLOBAL", f"❌ Colunas obrigatórias não encontradas em {caminho_csv}.", "prioridade_ativos")
            return {}

        for ativo, grupo in df.groupby("par"):
            grupo = grupo[grupo["classe_prevista"].isin(["compra", "venda"])]
            if len(grupo) < minimo:
                prioridades[ativo] = "baixa"
                continue

            taxa_acerto = (grupo["resultado_5_candles"] > 0).mean()
            lucro_total = grupo["resultado_5_candles"].sum()

            if taxa_acerto >= 0.6 and lucro_total > 0:
                prioridade = "alta"
            elif taxa_acerto >= 0.45:
                prioridade = "media"
            else:
                prioridade = "baixa"

            prioridades[ativo] = prioridade
            registrar_log(ativo, f"📊 Prioridade atribuída: {prioridade.upper()} | Acerto={taxa_acerto:.2f} | Lucro={lucro_total:.2f}", "prioridade_ativos")

    except Exception as e:
        registrar_log("GLOBAL", f"❌ Erro ao calcular prioridade: {e}", "prioridade_ativos", "ERROR")

    return prioridades
