
import pandas as pd
import numpy as np
import os

def purgar_variaveis_inuteis(path_csv='logs/autoavaliador.csv', threshold_importancia=0.01, salvar_em='dados_input_filtrado.pkl'):
    '''
    Analisa quais variáveis mais causam erro nas decisões da IA e remove as inúteis.
    '''
    if not os.path.exists(path_csv):
        print("[PURGADOR] Arquivo de log não encontrado:", path_csv)
        return

    df = pd.read_csv(path_csv)

    if 'erro' not in df.columns:
        print("[PURGADOR] Coluna 'erro' ausente no CSV.")
        return

    features = [col for col in df.columns if col not in ['erro', 'resultado_real']]

    if len(features) == 0:
        print("[PURGADOR] Nenhuma feature identificada para análise.")
        return

    # Calcular correlação de cada variável com erro
    correlacoes = {}
    for col in features:
        try:
            correlacao = abs(df[col].corr(df['erro']))
            correlacoes[col] = correlacao
        except:
            pass

    correlacoes = dict(sorted(correlacoes.items(), key=lambda item: item[1], reverse=True))

    print("[PURGADOR] Ranking de correlação com erro (quanto maior, pior):")
    for var, cor in correlacoes.items():
        print(f"  {var}: {cor:.4f}")

    # Selecionar variáveis que têm correlação com erro abaixo do limite
    uteis = [var for var, cor in correlacoes.items() if cor < threshold_importancia]

    print(f"[PURGADOR] Mantendo {len(uteis)} variáveis úteis. Removendo o resto.")

    # Salvar nova estrutura limpa (apenas com as úteis)
    df_filtrado = df[uteis + ['erro']]
    df_filtrado.to_pickle(salvar_em)
    print(f"[PURGADOR] Dados filtrados salvos em: {salvar_em}")
