
import pandas as pd
import os
from inteligencia.log_por_ativo import registrar_log

def ajustar_pesos_por_lucro(caminho="historico_sinais.csv"):
    if not os.path.exists(caminho):
        registrar_log("GLOBAL", "❌ Arquivo histórico não encontrado.", "reforco_lucro", "ERROR")
        return 0.5, 0.3, 0.2

    try:
        df = pd.read_csv(caminho, on_bad_lines='skip')
        df = df.dropna(subset=["score", "probabilidade", "fakeout_detectado", "lucro"])
        df = df[df['lucro'] != 0.0]

        if df.empty:
            registrar_log("GLOBAL", "⚠️ Nenhum lucro real para cálculo de pesos.", "reforco_lucro")
            return 0.5, 0.3, 0.2

        melhores = df.sort_values(by='lucro', ascending=False).head(100)

        peso_score = melhores['score'].corr(melhores['lucro'])
        peso_proba = melhores['probabilidade'].corr(melhores['lucro'])
        peso_fake = melhores['fakeout_detectado'].astype(int).corr(melhores['lucro'])

        pesos = [peso_score, peso_proba, peso_fake]
        pesos = [p if pd.notna(p) else 0.0 for p in pesos]

        soma = sum(abs(p) for p in pesos)
        if soma == 0:
            registrar_log("GLOBAL", "⚠️ Pesos zerados, fallback para padrão.", "reforco_lucro")
            return 0.5, 0.3, 0.2

        pesos_normalizados = [round(abs(p) / soma, 2) for p in pesos]

        registrar_log("GLOBAL", f"📊 Pesos recalibrados | Score={pesos_normalizados[0]}, IA={pesos_normalizados[1]}, Fakeout={pesos_normalizados[2]}", "reforco_lucro")
        return tuple(pesos_normalizados)

    except Exception as e:
        registrar_log("GLOBAL", f"❌ Erro ao ajustar pesos por lucro: {e}", "reforco_lucro", "ERROR")
        return 0.5, 0.3, 0.2
