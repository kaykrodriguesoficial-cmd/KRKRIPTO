import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

def detectar_regime(df, janela=30):
    """
    Classifica o regime do mercado com base no slope de regressão + volatilidade.
    Retorna: 'alta', 'baixa', 'lateral', 'reversao', ou 'desconhecido'.
    """
    if len(df) < janela:
        return "desconhecido"

    precos = df["close"].tail(janela).values.reshape(-1, 1)
    x = np.arange(janela).reshape(-1, 1)

    modelo = LinearRegression().fit(x, precos)
    slope = modelo.coef_[0][0]
    std = df["close"].tail(janela).std()

    if abs(slope) < 0.02 and std < 0.5:
        return "lateral"
    elif slope > 0.05:
        return "alta"
    elif slope < -0.05:
        return "baixa"
    else:
        return "reversao"
