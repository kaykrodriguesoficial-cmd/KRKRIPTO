
import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from executors.logger import log_erro

modelo_regime = None
pca = PCA(n_components=3)
scaler = StandardScaler()

def treinar_classificador_regime(df):
    global modelo_regime, pca, scaler

    try:
        df = df.dropna()
        features = ['retorno_pct', 'volatilidade', 'dominancia_btc']
        X = scaler.fit_transform(df[features])
        X_pca = pca.fit_transform(X)

        y = df['regime_label'].values  # valores como 'BULL', 'BEAR', 'LATERAL'

        modelo_regime = RandomForestClassifier(n_estimators=100, random_state=42)
        modelo_regime.fit(X_pca, y)

    except Exception as e:
        log_erro(f"[TREINO REGIME] Erro ao treinar classificador de regime: {e}")

def prever_regime(df):
    global modelo_regime, pca, scaler

    try:
        features = ['retorno_pct', 'volatilidade', 'dominancia_btc']
        if not all(f in df.columns for f in features):
            return "INDEFINIDO"

        X = scaler.transform(df[features].tail(1))
        X_pca = pca.transform(X)
        return modelo_regime.predict(X_pca)[0] if modelo_regime else "INDEFINIDO"
    except Exception as e:
        log_erro(f"[PREDIÇÃO REGIME] Erro ao prever regime: {e}")
        return "INDEFINIDO"
