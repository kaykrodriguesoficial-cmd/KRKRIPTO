"""
Módulo de compatibilidade para ambiente_rl_avancado - Wrapper para ambiente_rl.py

Este módulo serve como um wrapper de compatibilidade para código legado
que ainda depende do caminho de importação src.intelligence.reinforcement.ambiente_rl_avancado.
Todas as funcionalidades são redirecionadas para o módulo consolidado src.intelligence.reinforcement.ambiente_rl.

Autor: Equipe KR_KRIPTO
Data: Junho 2025
Versão: 1.0.0
"""

import logging
import importlib
import numpy as np
import pandas as pd
from typing import Any, Dict, Optional, Union, List, Tuple

# Configurar logging
logger = logging.getLogger("reinforcement.ambiente_rl_avancado")
logger.info("Logger configurado com rotação daily para reinforcement.ambiente_rl_avancado")

# Definir classes de compatibilidade
class AmbienteRL:
    """Classe base para ambientes de RL."""
    
    def __init__(self, config=None):
        self.config = config or {}
        logger.info("AmbienteRL base inicializado")
    
    def reset(self):
        return {}
    
    def step(self, action):
        return {}, 0.0, False, {}

class AmbienteRLAvancado:
    """Implementação completa de AmbienteRLAvancado para compatibilidade com testes."""
    
    def __init__(self, config=None):
        self.config = config or {}
        self.ativos = self.config.get('ativos', ['BTCUSDT'])
        self.timeframes = self.config.get('timeframes', ['1h'])
        self.ativo = self.config.get('ativo', 'BTCUSDT')
        self.df_historico = self.config.get('df_historico', pd.DataFrame())
        self.indice_inicio = self.config.get('indice_inicio', 0)
        self.indice_fim = self.config.get('indice_fim', 99)
        self.capital_inicial = self.config.get('capital_inicial', 1000.0)
        self.custo_transacao = self.config.get('custo_transacao', 0.001)
        self.indicadores = self.config.get('indicadores', ["rsi", "macd", "macd_signal", "macd_hist", "ema_9", "sma_20"])
        
        # Atributos de estado
        self.indice_atual = 0
        self.capital_atual = self.capital_inicial
        self.posicao_atual = 0.0
        self.valor_portfolio = self.capital_inicial
        self.ultima_acao = 0
        self.done = False
        
        # Históricos
        self.historico_acoes = []
        self.historico_recompensas = []
        self.historico_portfolio = [self.capital_inicial]
        self.historico_estados = []
        
        logger.info(f"AmbienteRLAvancado inicializado para {len(self.ativos)} ativos em {len(self.timeframes)} timeframes")
    
    def reset(self):
        """Reinicia o ambiente para um novo episódio."""
        self.indice_atual = self.indice_inicio
        self.capital_atual = self.capital_inicial
        self.posicao_atual = 0.0
        self.valor_portfolio = self.capital_inicial
        self.ultima_acao = 0
        self.done = False
        
        # Limpar históricos
        self.historico_acoes = []
        self.historico_recompensas = []
        self.historico_portfolio = [self.capital_inicial]
        self.historico_estados = []
        
        # Retornar estado inicial
        return self._obter_estado_atual()
    
    def step(self, action):
        """Executa uma ação no ambiente."""
        # Verificar se o episódio já terminou
        if self.done:
            return self._obter_estado_atual(), 0.0, True, {"mensagem": "Episódio já concluído"}
        
        # Registrar ação
        self.ultima_acao = action
        self.historico_acoes.append(action)
        
        # Obter preço atual e próximo
        preco_atual = self.df_historico.iloc[self.indice_atual]["close"]
        
        # Executar ação
        if action == 1:  # BUY
            if self.capital_atual > 0:
                # Calcular quantidade a comprar
                quantidade = self.capital_atual / preco_atual * (1 - self.custo_transacao)
                self.posicao_atual += quantidade
                self.capital_atual = 0
        elif action == 2:  # SELL
            if self.posicao_atual > 0:
                # Calcular valor da venda
                valor_venda = self.posicao_atual * preco_atual * (1 - self.custo_transacao)
                self.capital_atual += valor_venda
                self.posicao_atual = 0
        
        # Avançar para o próximo passo
        self.indice_atual += 1
        
        # Verificar se o episódio terminou
        if self.indice_atual > self.indice_fim:
            self.done = True
            self.indice_atual = self.indice_fim + 1
        
        # Calcular valor do portfólio
        if not self.done:
            preco_atual = self.df_historico.iloc[self.indice_atual]["close"]
            valor_posicao = self.posicao_atual * preco_atual
            self.valor_portfolio = self.capital_atual + valor_posicao
        
        # Registrar valor do portfólio
        self.historico_portfolio.append(self.valor_portfolio)
        
        # Calcular recompensa (retorno percentual)
        recompensa = (self.historico_portfolio[-1] / self.historico_portfolio[-2] - 1) * 100
        self.historico_recompensas.append(recompensa)
        
        # Retornar próximo estado, recompensa, done e info
        return self._obter_estado_atual(), recompensa, self.done, {}
    
    def _obter_estado_atual(self):
        """Obtém o estado atual do ambiente."""
        if self.done:
            return {}
        
        estado = {}
        
        # Adicionar indicadores
        for indicador in self.indicadores:
            if indicador in self.df_historico.columns:
                estado[indicador] = self.df_historico.iloc[self.indice_atual][indicador]
        
        # Adicionar informações de posição e capital
        estado["posicao_atual"] = self.posicao_atual
        estado["capital_normalizado"] = self.capital_atual / self.capital_inicial
        estado["portfolio_normalizado"] = self.valor_portfolio / self.capital_inicial
        
        return estado
    
    def get_performance_metrics(self):
        """Retorna métricas de performance do ambiente."""
        # Calcular retorno total
        retorno_total = (self.historico_portfolio[-1] / self.historico_portfolio[0] - 1) * 100
        
        # Calcular retornos diários
        retornos = []
        for i in range(1, len(self.historico_portfolio)):
            retorno = self.historico_portfolio[i] / self.historico_portfolio[i-1] - 1
            retornos.append(retorno)
        
        # Calcular volatilidade
        volatilidade = np.std(retornos) * 100
        
        # Calcular Sharpe Ratio (assumindo taxa livre de risco = 0)
        sharpe = 0
        if volatilidade > 0:
            sharpe = (np.mean(retornos) / np.std(retornos)) * np.sqrt(252)
        
        # Calcular máximo drawdown
        max_drawdown = 0
        peak = self.historico_portfolio[0]
        for valor in self.historico_portfolio:
            if valor > peak:
                peak = valor
            drawdown = (peak - valor) / peak
            if drawdown > max_drawdown:
                max_drawdown = drawdown
        
        # Contar operações por tipo
        acoes_count = {"buy": 0, "hold": 0, "sell": 0}
        for acao in self.historico_acoes:
            if acao == 0:
                acoes_count["hold"] += 1
            elif acao == 1:
                acoes_count["buy"] += 1
            elif acao == 2:
                acoes_count["sell"] += 1
        
        return {
            "retorno_total": retorno_total,
            "retorno_anualizado": retorno_total * (252 / len(self.historico_portfolio)),
            "volatilidade": volatilidade,
            "sharpe": sharpe,
            "max_drawdown": max_drawdown * 100,
            "num_operacoes": len(self.historico_acoes),
            "acoes": acoes_count
        }

class RealAmbienteRL:
    """Implementação completa de RealAmbienteRL para compatibilidade com testes."""
    
    def __init__(self, config=None):
        self.config = config or {}
        self.ativo = self.config.get('ativo', 'BTCUSDT')
        self.timeframe = self.config.get('timeframe', '1h')
        self.operador = self.config.get('operador', None)
        self.memoria_temporal = self.config.get('memoria_temporal', None)
        self.indicadores = self.config.get('indicadores', ["rsi", "macd", "macd_signal", "macd_hist", "ema_9", "sma_20"])
        
        # Atributos de estado
        self.ultima_acao = 0
        self.ultima_recompensa = 0.0
        self.ultimo_preco = 0.0
        self.ultima_posicao = 0.0
        self.ultimo_saldo = 0.0
        self.valor_portfolio_anterior = 0.0
        
        # Históricos
        self.historico_acoes = []
        self.historico_recompensas = []
        self.historico_precos = []
        self.historico_portfolio = []
        
        # Inicializar valores
        if self.operador:
            try:
                ticker = self.operador.obter_ticker(self.ativo)
                self.ultimo_preco = float(ticker["price"])
                self.ultima_posicao = self.operador.obter_posicao(self.ativo)
                self.ultimo_saldo = self.operador.obter_saldo_disponivel("USDT")
                self.valor_portfolio_anterior = self.ultimo_saldo + self.ultima_posicao * self.ultimo_preco
                self.historico_precos.append(self.ultimo_preco)
                self.historico_portfolio.append(self.valor_portfolio_anterior)
            except Exception as e:
                logger.error(f"Erro ao inicializar RealAmbienteRL: {e}")
        
        logger.info(f"RealAmbienteRL inicializado para {self.ativo} em {self.timeframe}")
        
        # Tentar carregar dataframe
        try:
            if self.memoria_temporal:
                df = self.memoria_temporal.obter_dataframe(self.ativo, self.timeframe)
                if df is not None and not df.empty:
                    logger.info(f"Dataframe para {self.ativo}_{self.timeframe} carregado com sucesso")
                else:
                    logger.error(f"Dataframe para {self.ativo}_{self.timeframe} não encontrado na memória temporal")
        except Exception as e:
            logger.error(f"Erro ao carregar dataframe: {e}")
    
    def obter_estado(self):
        """Obtém o estado atual do ambiente real."""
        estado = {}
        
        # Obter indicadores do último candle
        try:
            if self.memoria_temporal:
                df = self.memoria_temporal.obter_dataframe(self.ativo, self.timeframe)
                if df is not None and not df.empty:
                    for indicador in self.indicadores:
                        if indicador in df.columns:
                            estado[indicador] = df.iloc[-1][indicador]
        except Exception as e:
            logger.error(f"Erro ao obter indicadores: {e}")
        
        # Adicionar informações de posição e preço
        if self.operador:
            try:
                ticker = self.operador.obter_ticker(self.ativo)
                self.ultimo_preco = float(ticker["price"])
                self.ultima_posicao = self.operador.obter_posicao(self.ativo)
                self.ultimo_saldo = self.operador.obter_saldo_disponivel("USDT")
                
                estado["posicao_atual"] = self.ultima_posicao
                estado["preco_atual"] = self.ultimo_preco
                estado["saldo_atual"] = self.ultimo_saldo
            except Exception as e:
                logger.error(f"Erro ao obter estado atual: {e}")
        
        return estado
    
    def executar_acao(self, acao):
        """Executa uma ação no ambiente real."""
        # Registrar ação
        self.ultima_acao = acao
        self.historico_acoes.append(acao)
        
        # Obter estado antes da ação
        estado_anterior = self.obter_estado()
        valor_portfolio_anterior = self.valor_portfolio_anterior
        
        # Executar ação
        if self.operador:
            try:
                ticker = self.operador.obter_ticker(self.ativo)
                preco_atual = float(ticker["price"])
                posicao_atual = self.operador.obter_posicao(self.ativo)
                saldo_atual = self.operador.obter_saldo_disponivel("USDT")
                
                if acao == 1:  # BUY
                    if saldo_atual > 0:
                        # Calcular quantidade a comprar (90% do saldo)
                        valor_compra = saldo_atual * 0.9
                        quantidade = valor_compra / preco_atual
                        
                        # Executar ordem
                        self.operador.criar_ordem_mercado(self.ativo, "BUY", quantidade)
                        logger.info(f"Ordem BUY executada: {quantidade} {self.ativo} a {preco_atual}")
                
                elif acao == 2:  # SELL
                    if posicao_atual > 0:
                        # Vender toda a posição
                        self.operador.criar_ordem_mercado(self.ativo, "SELL", posicao_atual)
                        logger.info(f"Ordem SELL executada: {posicao_atual} {self.ativo} a {preco_atual}")
                
                # Atualizar valores
                self.ultimo_preco = preco_atual
                self.ultima_posicao = self.operador.obter_posicao(self.ativo)
                self.ultimo_saldo = self.operador.obter_saldo_disponivel("USDT")
                
                # Calcular valor do portfólio atual
                valor_portfolio_atual = self.ultimo_saldo + self.ultima_posicao * self.ultimo_preco
                
                # Registrar valores
                self.historico_precos.append(self.ultimo_preco)
                self.historico_portfolio.append(valor_portfolio_atual)
                
                # Calcular recompensa (retorno percentual)
                if valor_portfolio_anterior > 0:
                    recompensa = (valor_portfolio_atual / valor_portfolio_anterior - 1) * 100
                else:
                    recompensa = 0.0
                
                self.ultima_recompensa = recompensa
                self.historico_recompensas.append(recompensa)
                
                # Atualizar valor do portfólio anterior
                self.valor_portfolio_anterior = valor_portfolio_atual
                
            except Exception as e:
                logger.error(f"Erro ao executar ação: {e}")
                recompensa = 0.0
                self.historico_recompensas.append(recompensa)
        else:
            # Sem operador, apenas registrar ação e retornar recompensa zero
            recompensa = 0.0
            self.historico_recompensas.append(recompensa)
        
        # Obter próximo estado
        proximo_estado = self.obter_estado()
        
        # Retornar próximo estado, recompensa e info
        return proximo_estado, recompensa, {"acao": acao}
    
    def get_performance_metrics(self):
        """Retorna métricas de performance do ambiente real."""
        if len(self.historico_portfolio) < 2:
            return {
                "retorno_total": 0.0,
                "retorno_anualizado": 0.0,
                "volatilidade": 0.0,
                "sharpe": 0.0,
                "max_drawdown": 0.0,
                "num_operacoes": 0,
                "acoes": {"buy": 0, "hold": 0, "sell": 0}
            }
        
        # Calcular retorno total
        retorno_total = (self.historico_portfolio[-1] / self.historico_portfolio[0] - 1) * 100
        
        # Calcular retornos diários
        retornos = []
        for i in range(1, len(self.historico_portfolio)):
            retorno = self.historico_portfolio[i] / self.historico_portfolio[i-1] - 1
            retornos.append(retorno)
        
        # Calcular volatilidade
        volatilidade = 0.0
        if len(retornos) > 1:
            volatilidade = np.std(retornos) * 100
        
        # Calcular retorno anualizado
        retorno_anualizado = retorno_total * (252 / max(1, len(self.historico_portfolio)))
        
        # Calcular Sharpe Ratio (assumindo taxa livre de risco = 0)
        sharpe = 0
        if len(retornos) > 1 and np.std(retornos) > 0:
            sharpe = (np.mean(retornos) / np.std(retornos)) * np.sqrt(252)
        
        # Calcular máximo drawdown
        max_drawdown = 0
        peak = self.historico_portfolio[0]
        for valor in self.historico_portfolio:
            if valor > peak:
                peak = valor
            drawdown = (peak - valor) / peak
            if drawdown > max_drawdown:
                max_drawdown = drawdown
        
        # Contar operações por tipo
        acoes_count = {"buy": 0, "hold": 0, "sell": 0}
        for acao in self.historico_acoes:
            if acao == 0:
                acoes_count["hold"] += 1
            elif acao == 1:
                acoes_count["buy"] += 1
            elif acao == 2:
                acoes_count["sell"] += 1
        
        return {
            "retorno_total": retorno_total,
            "retorno_anualizado": retorno_anualizado,
            "volatilidade": volatilidade,
            "sharpe": sharpe,
            "max_drawdown": max_drawdown * 100,
            "num_operacoes": len(self.historico_acoes),
            "acoes": acoes_count
        }

# Exportar todos os símbolos do módulo consolidado
__all__ = [
    'AmbienteRL',
    'AmbienteRLAvancado',
    'RealAmbienteRL'
]
