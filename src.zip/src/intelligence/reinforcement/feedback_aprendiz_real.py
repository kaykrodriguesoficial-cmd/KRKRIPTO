
from datetime import datetime
from inteligencia.avaliador.calculador_de_recompensa import calcular_recompensa
from inteligencia.memoria.historico_de_sinais import historico
from inteligencia.meta.reforco_qtable import qtable

def atualizar_qtable_com_feedback(df_completo, ativo):
    def avaliador(sinal):
        resultado = calcular_recompensa(sinal, df_completo)
        if resultado and 'recompensa' in resultado:
            qtable.registrar_recompensa(
                regime=sinal['contexto']['regime'],
                hora=sinal['contexto']['hora'],
                modelo=sinal['contexto']['modelo'],
                recompensa=resultado['recompensa']
            )
        return resultado

    historico.registrar_resultado(ativo, datetime.utcnow(), avaliador)
