"""
Módulo: replay_engine.py
Executa simulação de decisões passadas para retroalimentar modelos com base em histórico real.
"""

import csv
import os

def carregar_sinais_historicos(caminho_csv):
    sinais = []
    if not os.path.exists(caminho_csv):
        raise FileNotFoundError(f"Arquivo não encontrado: {caminho_csv}")
    
    with open(caminho_csv, "r") as f:
        leitor = csv.DictReader(f)
        for linha in leitor:
            sinais.append({
                "ativo": linha.get("ativo"),
                "timestamp": linha.get("timestamp"),
                "entrada": float(linha.get("entrada", 0)),
                "saida": float(linha.get("saida", 0)),
                "lucro": float(linha.get("lucro", 0)),
                "score": float(linha.get("score", 0)),
                "modelo": linha.get("modelo_usado")
            })
    return sinais

def simular_replay(sinais):
    print(f"🔁 Iniciando replay de {len(sinais)} sinais...")
    total = 0
    positivos = 0
    acumulado = 0.0
    modelos = {}

    for s in sinais:
        total += 1
        lucro = s["lucro"]
        modelo = s["modelo"]
        acumulado += lucro
        if lucro > 0:
            positivos += 1
        if modelo not in modelos:
            modelos[modelo] = {"count": 0, "lucro": 0.0}
        modelos[modelo]["count"] += 1
        modelos[modelo]["lucro"] += lucro

    print(f"✅ Replay finalizado: {positivos}/{total} positivos | Lucro total: {acumulado:.2f}")
    print("🏆 Desempenho por modelo:")
    for m, stats in modelos.items():
        avg = stats["lucro"] / stats["count"]
        print(f"  - {m}: {stats['count']} sinais | Lucro total: {stats['lucro']:.2f} | Média: {avg:.4f}")
