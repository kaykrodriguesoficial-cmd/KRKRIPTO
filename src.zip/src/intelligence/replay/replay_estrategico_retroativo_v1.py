
import json
from executors.logger import log_erro

CAMINHO_MEMORIA = "memoria_estrategica_longaprazo.jsonl"

def simular_replay_tatico(filtros=None, limite=20):
    resultados = []
    try:
        with open(CAMINHO_MEMORIA, "r") as f:
            linhas = f.readlines()[-limite:]
            for linha in linhas:
                entrada = json.loads(linha)
                if filtros:
                    if any(str(entrada.get(k)) != str(v) for k, v in filtros.items()):
                        continue
                resultado = {
                    "ativo": entrada.get("ativo"),
                    "score": entrada["contexto"].get("score"),
                    "retorno": entrada["resultado"].get("retorno"),
                    "status": entrada["resultado"].get("status"),
                    "timestamp": entrada["timestamp"]
                }
                resultados.append(resultado)
    except Exception as e:
        log_erro(f"[REPLAY] Erro ao executar replay estratégico: {e}")
    return resultados
