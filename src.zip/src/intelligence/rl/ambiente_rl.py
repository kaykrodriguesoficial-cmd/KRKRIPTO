# src/intelligence/rl/ambiente_rl.py
import pandas as pd
import logging
import numpy as np # Adicionado para cálculos

logger = logging.getLogger("kr_kripto_rl_env")

class AmbienteRL:
    def __init__(self, config: dict):
        # Extrair parâmetros do dicionário config
        self.ativo = config.get('ativo', 'UNKNOWN')
        self.df = config.get('df_inicial', None)
        self.capital_inicial = config.get('capital_inicial', 1000.0)
        self.custo_transacao = config.get('custo_transacao', 0.001)
        
        self.indice_atual = len(self.df) - 1 if self.df is not None else -1
        self.capital_atual = self.capital_inicial
        self.posicao_atual = 0.0 # Quantidade do ativo
        self.ultima_acao = 0 # 0: HOLD, 1: BUY, 2: SELL
        self.valor_portfolio = self.capital_inicial
        
        logger.info(f"[{self.ativo}] AmbienteRL base inicializado com capital {self.capital_inicial}, custo {self.custo_transacao}.")

    def atualizar_dados(self, df: pd.DataFrame):
        # Método base, pode ser sobrescrito
        logger.debug(f"[{self.ativo}] AmbienteRL base: atualizar_dados chamado.")
        self.df = df
        self.indice_atual = len(self.df) - 1 if self.df is not None else -1

    def obter_estado(self):
        # Método base, retorna um estado placeholder
        logger.debug(f"[{self.ativo}] AmbienteRL base: obter_estado chamado.")
        if self.df is not None and self.indice_atual >= 0 and self.indice_atual < len(self.df):
            try:
                # Exemplo: usar RSI_14 e posição atual (agora minúsculo)
                # Tentar encontrar a coluna RSI, independentemente do sufixo exato
                rsi_col = next((col for col in self.df.columns if col.lower().startswith("rsi")), None)
                if rsi_col is None:
                    logger.error(f"[{self.ativo}] Coluna RSI não encontrada no DataFrame para obter estado.")
                    return None
                rsi = self.df[rsi_col].iloc[self.indice_atual]
                
                # Normalizar posição (ex: -1 para vendido, 0 neutro, 1 comprado)
                # Aqui simplificamos para 0 (neutro) ou 1 (comprado), pois não há shorting
                posicao_norm = 1 if self.posicao_atual > 0 else 0 
                return {"rsi": rsi, "posicao_atual": posicao_norm}
            except KeyError as e:
                logger.error(f"[{self.ativo}] Coluna necessária ausente no DataFrame para obter estado: {e}")
                return None
            except IndexError:
                 logger.error(f"[{self.ativo}] Índice inválido ao obter estado: {self.indice_atual}")
                 return None
        return None # Estado inválido

    def _calcular_recompensa(self, valor_portfolio_anterior):
        # Recompensa simples baseada na variação percentual do portfólio
        if valor_portfolio_anterior <= 0:
            return 0.0
        return (self.valor_portfolio / valor_portfolio_anterior) - 1.0

    def step(self, acao):
        # Método base, retorna valores placeholder
        logger.debug(f"[{self.ativo}] AmbienteRL base: step chamado com ação {acao}.")
        
        if self.df is None or self.indice_atual < 0 or self.indice_atual >= len(self.df):
            logger.warning(f"[{self.ativo}] Tentativa de step com dados inválidos ou índice fora dos limites.")
            return None, 0.0, True # Estado inválido, recompensa 0, finalizado

        valor_portfolio_antes = self.valor_portfolio
        
        # --- Correção: Usar coluna 'close' em minúsculo --- 
        try:
            preco_atual = self.df["close"].iloc[self.indice_atual]
        except KeyError:
             logger.error(f"[{self.ativo}] Coluna 'close' não encontrada no DataFrame para step.")
             return None, 0.0, True # Estado inválido
        except IndexError:
             logger.error(f"[{self.ativo}] Índice inválido ao obter preço atual no step: {self.indice_atual}")
             return None, 0.0, True # Estado inválido
        # --- Fim da Correção ---
        
        done = False # Simulação não termina por padrão aqui

        if acao == 1: # BUY
            if self.capital_atual > 0:
                quantidade_comprar = self.capital_atual / preco_atual * (1 - self.custo_transacao)
                self.posicao_atual += quantidade_comprar
                self.capital_atual = 0.0
                self.ultima_acao = 1
                logger.debug(f"[{self.ativo}] BUY: {quantidade_comprar:.4f} @ {preco_atual:.2f}")
            else:
                # Penalidade por tentar comprar sem capital?
                self.ultima_acao = 0 # Considera HOLD se não pode comprar
                logger.debug(f"[{self.ativo}] Tentativa de BUY sem capital.")
        elif acao == 2: # SELL
            if self.posicao_atual > 0:
                valor_venda = self.posicao_atual * preco_atual * (1 - self.custo_transacao)
                self.capital_atual += valor_venda
                posicao_vendida = self.posicao_atual # Log antes de zerar
                self.posicao_atual = 0.0
                self.ultima_acao = 2
                logger.debug(f"[{self.ativo}] SELL: {posicao_vendida:.4f} @ {preco_atual:.2f} -> Capital {self.capital_atual:.2f}")
            else:
                # Penalidade por tentar vender sem posição?
                self.ultima_acao = 0 # Considera HOLD se não pode vender
                logger.debug(f"[{self.ativo}] Tentativa de SELL sem posição.")
        else: # HOLD (acao == 0)
            self.ultima_acao = 0
            logger.debug(f"[{self.ativo}] HOLD @ {preco_atual:.2f}")

        # Atualizar valor do portfólio
        self.valor_portfolio = self.capital_atual + self.posicao_atual * preco_atual
        
        # Calcular recompensa
        recompensa = self._calcular_recompensa(valor_portfolio_antes)
        
        # Avançar para o próximo estado (simplificado, apenas obtém estado atual)
        # Em uma simulação real, avançaria o índice
        proximo_estado = self.obter_estado()
        if proximo_estado is None:
             done = True # Finaliza se o próximo estado for inválido

        return proximo_estado, recompensa, done

# Define a classe RealAmbienteRL herdando de AmbienteRL
class RealAmbienteRL:
    def __init__(self, config=None):
        self.config = config or {}

    # Inicialmente, pode ser uma simples herança sem modificações adicionais.
    # Se houver lógica específica para RealAmbienteRL, ela pode ser adicionada aqui.
    pass

