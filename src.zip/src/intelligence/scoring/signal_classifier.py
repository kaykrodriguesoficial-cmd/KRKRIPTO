# src/strategies/signal_classifier.py
import pandas as pd
import logging
import numpy as np # Import numpy for isnan

logger = logging.getLogger("kr_kripto_classifier")

def prever_classe_corrigido_v12(df: pd.DataFrame):
    logger.debug(f"prever_classe_corrigido_v12 chamado.")
    
    # Default values
    classe = "nada"
    probabilidade = 0.5

    try:
        if df is not None and not df.empty and 'RSI' in df.columns:
            # Get the last non-NaN RSI value if possible, otherwise the very last one
            rsi_series = df['RSI'].dropna()
            if not rsi_series.empty:
                last_rsi = rsi_series.iloc[-1]
                logger.debug(f"Último RSI válido: {last_rsi}")
                if last_rsi < 30:
                    classe = "compra"
                elif last_rsi > 70:
                    classe = "venda"
                # else: classe remains "nada"
            else:
                # Handle case where RSI column exists but is all NaN
                logger.warning("Coluna RSI encontrada, mas todos os valores são NaN.")
        else:
            if df is None or df.empty:
                logger.warning("DataFrame vazio ou None recebido.")
            else: # RSI column missing
                logger.warning("Coluna RSI não encontrada no DataFrame.")
                
    except Exception as e:
        logger.error(f"Erro ao calcular classe baseada no RSI: {e}")
        # Keep default 'nada' in case of error

    logger.debug(f"Classe prevista: {classe}, Probabilidade: {probabilidade}")
    return classe, probabilidade


