
def simular_impacto_tatico(df):
    """
    Simulação simples baseada nos últimos candles.
    Estima se há risco elevado na projeção do próximo movimento.
    """
    try:
        df = df.copy()
        df["ret"] = df["close"].pct_change()
        media = df["ret"].rolling(3).mean().iloc[-1]
        vol = df["ret"].rolling(3).std().iloc[-1]

        if media < -0.01 or vol > 0.03:
            return False  # Alto risco ou reversão
        return True
    except Exception as e:
        print(f"[SIMULAÇÃO] Erro: {e}")
        return True
