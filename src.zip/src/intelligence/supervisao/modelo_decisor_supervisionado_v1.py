
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from executors.logger import log_erro

modelo_decisor = None
scaler = StandardScaler()

def treinar_decisor_supervisionado(df_memoria):
    global modelo_decisor, scaler

    try:
        df = df_memoria.dropna()
        features = ['score', 'probabilidade', 'entropia', 'feedback', 'regime_id', 'simulacao']
        target = 'executou'  # 1 = executou, 0 = não

        if not all(col in df.columns for col in features + [target]):
            raise ValueError("Colunas obrigatórias ausentes no dataframe")

        X = scaler.fit_transform(df[features])
        y = df[target].astype(int)

        modelo_decisor = RandomForestClassifier(n_estimators=100, random_state=42)
        modelo_decisor.fit(X, y)
    except Exception as e:
        log_erro(f"[TREINO DECISOR] Erro ao treinar modelo supervisionado: {e}")

def prever_execucao(df_contexto):
    global modelo_decisor, scaler

    try:
        if modelo_decisor is None or df_contexto.empty:
            return 1.0  # executa por padrão

        df = df_contexto.tail(1).copy()
        features = ['score', 'probabilidade', 'entropia', 'feedback', 'regime_id', 'simulacao']

        if not all(f in df.columns for f in features):
            return 1.0

        X = scaler.transform(df[features])
        prob_execucao = modelo_decisor.predict_proba(X)[0][1]  # probabilidade de execução
        return float(prob_execucao)
    except Exception as e:
        log_erro(f"[PREDIÇÃO DECISOR] Erro ao prever execução: {e}")
        return 1.0
