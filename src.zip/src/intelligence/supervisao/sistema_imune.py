
import json
import os
from datetime import datetime, timedelta

ARQUIVO_RELATORIO = "dados/avaliacoes_modelos/relatorio_modelos.json"
ARQUIVO_MODELOS_BLOQUEADOS = "dados/imunidade/modelos_bloqueados.json"
LIMIAR_ACERTO_MIN = 0.40
LIMIAR_PNL_MIN = 0.0

def ativar_sistema_imune():
    if not os.path.exists(ARQUIVO_RELATORIO):
        print("⚠️ Sem relatório para análise imunológica.")
        return []

    with open(ARQUIVO_RELATORIO, "r") as f:
        dados = json.load(f)

    modelos_bloqueados = {}
    for modelo, stats in dados.items():
        if stats["taxa_acerto"] < LIMIAR_ACERTO_MIN or stats["media_pnl"] < LIMIAR_PNL_MIN:
            modelos_bloqueados[modelo] = {
                "motivo": "baixo desempenho",
                "timestamp_bloqueio": datetime.utcnow().isoformat(),
                "acuracia": stats["taxa_acerto"],
                "media_pnl": stats["media_pnl"]
            }

    os.makedirs(os.path.dirname(ARQUIVO_MODELOS_BLOQUEADOS), exist_ok=True)
    with open(ARQUIVO_MODELOS_BLOQUEADOS, "w") as f:
        json.dump(modelos_bloqueados, f, indent=4)

    print(f"🧬 Modelos bloqueados por baixa performance: {list(modelos_bloqueados.keys())}")
    return list(modelos_bloqueados.keys())

def modelo_esta_bloqueado(nome_modelo):
    if not os.path.exists(ARQUIVO_MODELOS_BLOQUEADOS):
        return False
    with open(ARQUIVO_MODELOS_BLOQUEADOS, "r") as f:
        bloqueados = json.load(f)
    return nome_modelo in bloqueados
