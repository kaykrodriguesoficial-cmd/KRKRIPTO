
import pandas as pd

historico_path = "historico_sinais.csv"
log_path = "logs/desempenho_cerebros.csv"

def comparar_votos_com_resultado():
    try:
        df = pd.read_csv(historico_path, on_bad_lines='skip')
        if "resultado_5_candles" not in df.columns:
            return

        resultados = []
        for _, row in df.iterrows():
            classe_real = "compra" if row["resultado_5_candles"] > 0 else "venda"
            resultado = {
                "classe_real": classe_real,
                "heuristica": row.get("classe_heuristica"),
                "lstm": row.get("classe_lstm"),
                "soberana": row.get("classe_soberana")
            }
            resultados.append(resultado)

        df_resultados = pd.DataFrame(resultados)
        desempenho = {}

        for cerebro in ["heuristica", "lstm", "soberana"]:
            acertos = (df_resultados[cerebro] == df_resultados["classe_real"]).sum()
            total = df_resultados[cerebro].notna().sum()
            desempenho[cerebro] = round(acertos / total, 4) if total > 0 else 0.0

        df_desempenho = pd.DataFrame([desempenho])
        df_desempenho.to_csv(log_path, mode='a', header=not Path(log_path).exists(), index=False)
        return desempenho

    except Exception as e:
        print(f"[Erro] Validação Cruzada: {e}")
        return {}

def ajustar_pesos_por_performance(pesos_atuais, desempenho):
    nova_config = {}
    total = sum(desempenho.values())
    for cerebro, peso in desempenho.items():
        nova_config[cerebro] = round((peso / total), 3) if total > 0 else pesos_atuais.get(cerebro, 0.33)
    return nova_config

def gerar_relatorio_desempenho_cerebral():
    try:
        df = pd.read_csv(log_path)
        return df.tail(10)
    except Exception:
        return pd.DataFrame()
