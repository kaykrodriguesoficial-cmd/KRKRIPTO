
import numpy as np
from datetime import datetime
from joblib import load
from inteligencia.log_por_ativo import registrar_log

try:
    modelo_direcional = load("modelo_direcao_historica.pkl")
except Exception as e:
    print(f"❌ Erro ao carregar modelo_direcional: {e}")
    modelo_direcional = None

def validar_direcao(df, i, classe_prevista, ativo="BTCUSDT", limiar_reforco=5):
    """
    Valida a direção com base na IA histórica, ajusta score e registra log estratégico.
    Retorna: (valido: bool, score: int, mensagem: str)
    """

    try:
        if modelo_direcional is None:
            registrar_log(ativo, "⚠️ Modelo de direção não carregado.")
            return True, 0, "Modelo indisponível"

        if i < 10 or len(df) < i + 1:
            return True, 0, "⏳ Ponto inválido para previsão histórica"

        janela = df.iloc[i-10:i][["Close"]].values.flatten()
        delta = np.diff(janela)
        direcional_input = delta.reshape(1, -1)

        direcao_prevista = modelo_direcional.predict(direcional_input)[0]

        if classe_prevista == "compra" and direcao_prevista == 1:
            registrar_log(ativo, "✅ Reforço por IA histórica: direção confirma compra")
            return True, limiar_reforco, "Reforço positivo: direção confirma compra"
        elif classe_prevista == "venda" and direcao_prevista == -1:
            registrar_log(ativo, "✅ Reforço por IA histórica: direção confirma venda")
            return True, limiar_reforco, "Reforço positivo: direção confirma venda"
        elif direcao_prevista == 0:
            registrar_log(ativo, "⚠️ Direção neutra da IA histórica")
            return True, 0, "Neutro: IA sem direção"
        else:
            registrar_log(ativo, "⛔️ Divergência com IA histórica")
            return False, -limiar_reforco, "Divergente: IA histórica nega o sinal"

    except Exception as e:
        registrar_log(ativo, f"[ERRO DIREÇÃO]: {e}")
        return True, 0, "Erro ao validar direção"
