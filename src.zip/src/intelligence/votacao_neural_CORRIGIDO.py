
import numpy as np

# Pesos base — podem ser ajustados por ativo, cenário ou aprendidos dinamicamente
PESOS_PADRAO = {
    "ia_soberana": 0.35,
    "lstm": 0.20,
    "direcao_hist": 0.15,
    "score_orderflow": 0.10,
    "score_geral": 0.10,
    "fakeout": 0.05,
    "memoria_score": 0.05
}

def votacao_neural_ponderada(vetor_x, classe_soberana, prob_soberana, pred_lstm, direcao_hist):
    try:
        votos = {
            "ia_soberana": 1 if classe_soberana in ["compra", "venda"] else 0,
            "lstm": 1 if pred_lstm > 0 else -1,
            "direcao_hist": direcao_hist,
            "score_orderflow": 1 if vetor_x.get("score_orderflow", 0) > 0.5 else -1,
            "score_geral": 1 if vetor_x.get("score_final", 0) > 0.5 else -1,
            "fakeout": -1 if vetor_x.get("fakeout_detectado", 0) else 1,
            "memoria_score": 1 if vetor_x.get("memoria_score", 0) > 0.5 else -1
        }

        # Combinar votos com os pesos
        score_total = sum(PESOS_PADRAO[key] * votos[key] for key in votos)
        classe_final = "compra" if score_total > 0.2 else "venda" if score_total < -0.2 else "nada"
        confianca = round(abs(score_total), 4)

        return classe_final, confianca, votos

    except Exception as e:
        print(f"[Erro na votação ponderada]: {e}")
        return "nada", 0.0, {}
