
import time
import threading
from datetime import datetime
from executors.logger import log_erro

# Armazena o último timestamp de candle recebido por ativo
ultimo_candle_timestamp = {}
tempo_limite = 90  # segundos

def atualizar_ultimo_candle(ativo):
    ultimo_candle_timestamp[ativo] = time.time()

def monitorar_atividade_socket(ativo, reiniciar_socket_fn):
    while True:
        time.sleep(30)
        try:
            agora = time.time()
            ultimo = ultimo_candle_timestamp.get(ativo, 0)
            if agora - ultimo > tempo_limite:
                log_erro(f"⚠️ Inatividade detectada no WebSocket para {ativo}. Reiniciando...")
                reiniciar_socket_fn(ativo)
                atualizar_ultimo_candle(ativo)
        except Exception as e:
            log_erro(f"Erro no watchdog do ativo {ativo}: {e}")
