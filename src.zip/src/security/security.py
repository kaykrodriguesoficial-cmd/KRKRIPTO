"""
Módulo: verificar_assinatura_modelo.py
Valida a integridade e autenticidade do modelo .h5 com assinatura digital.
"""

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.exceptions import InvalidSignature
import os

def verificar_assinatura(modelo_path, assinatura_path, chave_publica_path):
    try:
        # Ler o modelo
        with open(modelo_path, "rb") as f:
            modelo_bytes = f.read()

        # Ler a assinatura
        with open(assinatura_path, "rb") as f:
            assinatura = f.read()

        # Ler a chave pública
        with open(chave_publica_path, "rb") as f:
            chave_publica = serialization.load_pem_public_key(f.read())

        # Verificar a assinatura
        chave_publica.verify(
            assinatura,
            modelo_bytes,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        print("🔐 Assinatura válida. Modelo autenticado.")
        return True

    except InvalidSignature:
        print("❌ Assinatura inválida! Modelo pode estar comprometido.")
        return False
    except Exception as e:
        print(f"⚠️ Erro ao verificar assinatura: {str(e)}")
        return False



import hashlib

def validar_modelo_sha256(path_modelo: str, sha256_esperado: str) -> bool:
    """Valida o hash SHA256 de um arquivo .h5."""
    # TODO: Consider integrating logging instead of print statements
    try:
        with open(path_modelo, 'rb') as f:
            file_hash = hashlib.sha256(f.read()).hexdigest()
        is_valid = file_hash == sha256_esperado
        if not is_valid:
            print(f"❌ Hash SHA256 inválido para {path_modelo}. Esperado: {sha256_esperado}, Obtido: {file_hash}")
        else:
            print(f"🔐 Hash SHA256 válido para {path_modelo}.")
        return is_valid
    except FileNotFoundError:
        print(f"❌ Arquivo não encontrado para validação SHA256: {path_modelo}")
        return False
    except Exception as e:
        print(f"⚠️ Erro ao validar hash SHA256: {e}")
        return False

