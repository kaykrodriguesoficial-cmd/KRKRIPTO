# src/simulation/replay_engine.py

import asyncio
import pandas as pd
import logging
import random
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class ReplayEngine:
    """Simulates real-time data stream from historical CSV datasets with anomaly injection."""

    def __init__(self, csv_filepath: str, speed_multiplier: float = 1.0, time_column: str = 'Timestamp',
                 lag_probability: float = 0.0, max_lag_seconds: float = 0.0,
                 gap_probability: float = 0.0,
                 pump_dump_probability: float = 0.0, pump_dump_factor: float = 2.0):
        """
        Initializes the ReplayEngine.

        Args:
            csv_filepath: Path to the CSV file containing historical data.
            speed_multiplier: Factor to speed up or slow down the replay (1.0 = real-time based on timestamps).
            time_column: Name of the column containing timestamps in the CSV.
            lag_probability: Probability (0.0 to 1.0) of injecting additional lag before sending a data point.
            max_lag_seconds: Maximum additional lag in seconds to inject (actual lag is random up to this max).
            gap_probability: Probability (0.0 to 1.0) of skipping (creating a gap) a data point.
            pump_dump_probability: Probability (0.0 to 1.0) of artificially inflating/deflating price/volume.
            pump_dump_factor: Multiplier for price/volume during a pump/dump event.
        """
        self.csv_filepath = csv_filepath
        self.speed_multiplier = speed_multiplier
        self.time_column = time_column
        self.data = None
        self.current_index = 0

        # Anomaly parameters
        self.lag_probability = lag_probability
        self.max_lag_seconds = max_lag_seconds
        self.gap_probability = gap_probability
        self.pump_dump_probability = pump_dump_probability
        self.pump_dump_factor = pump_dump_factor

        logger.info(f"ReplayEngine inicializado com arquivo: {csv_filepath}, speed: {speed_multiplier}x")
        logger.info(f"Anomalias: Lag(prob={lag_probability}, max={max_lag_seconds}s), Gap(prob={gap_probability}), Pump/Dump(prob={pump_dump_probability}, factor={pump_dump_factor})")

    def load_data(self):
        """Loads and preprocesses data from the CSV file."""
        try:
            logger.info(f"Carregando dados de {self.csv_filepath}...")
            self.data = pd.read_csv(self.csv_filepath)
            if self.time_column not in self.data.columns:
                raise ValueError(f"Coluna de tempo '{self.time_column}' não encontrada no CSV.")
            self.data[self.time_column] = pd.to_datetime(self.data[self.time_column])
            self.data = self.data.sort_values(by=self.time_column).reset_index(drop=True)
            logger.info(f"Dados carregados com sucesso. {len(self.data)} registros.")
            self.current_index = 0
            return True
        except FileNotFoundError:
            logger.error(f"Erro: Arquivo CSV não encontrado em {self.csv_filepath}")
            return False
        except Exception as e:
            logger.error(f"Erro ao carregar ou processar CSV {self.csv_filepath}: {e}", exc_info=True)
            return False

    async def _inject_lag(self, base_wait_time: float) -> float:
        """Injects random lag based on probability."""
        if random.random() < self.lag_probability and self.max_lag_seconds > 0:
            injected_lag = random.uniform(0, self.max_lag_seconds)
            logger.warning(f"Injetando lag: {injected_lag:.2f}s")
            return base_wait_time + injected_lag
        return base_wait_time

    def _should_inject_gap(self) -> bool:
        """Determines if a gap should be injected."""
        if random.random() < self.gap_probability:
            logger.warning("Injetando gap (pulando ponto de dado)")
            return True
        return False

    def _inject_pump_dump(self, data_point: dict) -> dict:
        """Injects artificial pump/dump in price/volume."""
        if random.random() < self.pump_dump_probability:
            factor = self.pump_dump_factor if random.random() > 0.5 else (1 / self.pump_dump_factor)
            logger.warning(f"Injetando Pump/Dump (fator: {factor:.2f})")
            if 'Close' in data_point and isinstance(data_point['Close'], (int, float)):
                data_point['Close'] *= factor
            if 'Volume' in data_point and isinstance(data_point['Volume'], (int, float)):
                data_point['Volume'] *= factor
            # Potentially adjust High/Low as well for consistency
            if 'High' in data_point and isinstance(data_point['High'], (int, float)):
                 data_point['High'] = max(data_point['High'], data_point.get('Close', data_point['High'])) * factor
            if 'Low' in data_point and isinstance(data_point['Low'], (int, float)):
                 data_point['Low'] = min(data_point['Low'], data_point.get('Close', data_point['Low'])) / factor # Inverse factor for low

        return data_point

    async def run(self, callback):
        """
        Runs the replay simulation, yielding data points according to their timestamps,
        potentially injecting anomalies.

        Args:
            callback: An async function to call with each data point (as a dictionary).
        """
        if self.data is None:
            if not self.load_data():
                logger.error("Falha ao carregar dados. Abortando simulação.")
                return

        logger.info("Iniciando simulação de replay...")
        last_timestamp = None

        while self.current_index < len(self.data):
            row = self.data.iloc[self.current_index]
            current_timestamp = row[self.time_column]

            if last_timestamp:
                time_diff_data = (current_timestamp - last_timestamp).total_seconds()
                wait_time = time_diff_data / self.speed_multiplier

                # Inject Lag
                wait_time = await self._inject_lag(wait_time)

                if wait_time > 0:
                    try:
                        await asyncio.sleep(wait_time)
                    except asyncio.CancelledError:
                        logger.info("Simulação de replay cancelada.")
                        return

            # Inject Gap
            if self._should_inject_gap():
                last_timestamp = current_timestamp # Update timestamp even if gap injected
                self.current_index += 1
                continue # Skip processing this data point

            data_point = row.to_dict()

            # Inject Pump/Dump
            data_point = self._inject_pump_dump(data_point)

            try:
                await callback(data_point)
            except asyncio.CancelledError:
                 logger.info("Simulação de replay cancelada durante callback.")
                 return
            except Exception as e:
                logger.error(f"Erro no callback da simulação: {e}", exc_info=True)
                # Continue simulation even if callback fails

            last_timestamp = current_timestamp
            self.current_index += 1

        logger.info("Simulação de replay concluída.")

# Exemplo de uso (será movido ou adaptado na integração)
async def simple_processor(data_point):
    # Use time_column variable defined in main_test
    print(f"Processando: {data_point[time_column]} - Close: {data_point.get('Close', 'N/A'):.2f}, Volume: {data_point.get('Volume', 'N/A'):.2f}")
    await asyncio.sleep(0.01) # Simula algum trabalho

async def main_test():
    csv_path = 'data/BTCUSDT_1h.csv'
    time_column = 'Timestamp'
    engine = ReplayEngine(
        csv_filepath=csv_path,
        speed_multiplier=10000, # Faster for testing
        time_column=time_column,
        lag_probability=0.1,    # 10% chance of lag
        max_lag_seconds=0.5,    # Max 0.5s additional lag (scaled by speed_multiplier in sleep)
        gap_probability=0.05,   # 5% chance of gap
        pump_dump_probability=0.02, # 2% chance of pump/dump
        pump_dump_factor=1.5    # 50% increase/decrease
    )
    await engine.run(simple_processor)

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(name)s - %(message)s')
    csv_path = 'data/BTCUSDT_1h.csv' # Define here for exception handling
    time_column = 'Timestamp' # Define here for simple_processor access
    try:
        asyncio.run(main_test())
    except FileNotFoundError:
        print(f"Erro: Arquivo de teste '{csv_path}' não encontrado. Crie um CSV de exemplo ou ajuste o caminho.")
    except KeyboardInterrupt:
        print("Teste interrompido.")

