# src/strategies/score_calculator.py
import pandas as pd
import logging

logger = logging.getLogger("kr_kripto_score")

def calcular_score_corrigido_v12(df: pd.DataFrame, i: int, ativo: str):
    logger.debug(f"[{ativo}] calcular_score_corrigido_v12 (stub) chamado.")
    # Retorna um score neutro placeholder
    return 0.5

