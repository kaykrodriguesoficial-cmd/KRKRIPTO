# src/strategies/validators/book_imbalance.py
import logging
from src.realtime.book_processor import BookState # Assuming BookState is defined here or imported

logger = logging.getLogger("kr_kripto_validator_book")

# --- CORRECTION: Reintroduce tipo_sinal and implement correct logic --- 
def validar_book_institucional(book_state: BookState, tipo_sinal: str):
    logger.debug(f"validar_book_institucional chamado com imbalance={book_state.imbalance if book_state else 'None'} e tipo_sinal='{tipo_sinal}'")
    
    # Define a threshold for strong imbalance (can be configured later)
    IMBALANCE_THRESHOLD = 0.5 
    
    if book_state is None:
        logger.warning("BookState é None, validação falhou.")
        return False
        
    try:
        imbalance = book_state.imbalance
        if imbalance is None:
             logger.warning("BookState.imbalance é None, validação falhou.")
             return False # Treat missing imbalance as invalid
             
        # Neutral signal is always valid regardless of imbalance
        if tipo_sinal == "nada":
            logger.debug("Sinal neutro ('nada'), validação passa.")
            return True
            
        # Check for contradiction based on signal type
        is_compra = tipo_sinal == "compra"
        is_venda = tipo_sinal == "venda"
        
        # Contradiction: BUY signal with strong SELL imbalance
        if is_compra and imbalance < -IMBALANCE_THRESHOLD:
            logger.debug(f"Sinal COMPRA contradito por imbalance de venda forte ({imbalance:.2f} < {-IMBALANCE_THRESHOLD}). Validação falha.")
            return False
            
        # Contradiction: SELL signal with strong BUY imbalance
        if is_venda and imbalance > IMBALANCE_THRESHOLD:
            logger.debug(f"Sinal VENDA contradito por imbalance de compra forte ({imbalance:.2f} > {IMBALANCE_THRESHOLD}). Validação falha.")
            return False
            
        # No contradiction found, signal is valid based on imbalance
        logger.debug(f"Nenhuma contradição de imbalance encontrada para sinal '{tipo_sinal}'. Validação passa.")
        return True
            
    except AttributeError:
        logger.error("Erro ao acessar book_state.imbalance.")
        return False
    except Exception as e:
        logger.error(f"Erro inesperado em validar_book_institucional: {e}", exc_info=True)
        return False
# --- END CORRECTION ---

