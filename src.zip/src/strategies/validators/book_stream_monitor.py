"""
Módulo: book_stream_monitor.py
Objetivo: Monitorar o order book institucional em tempo real via WebSocket e atualizar filtro.
"""

import asyncio
from binance import ThreadedWebsocketManager
from validadores.book_imbalance import validar_book_institucional

# Dicionário para armazenar o último estado do book institucional
estado_book = {}

def atualizar_estado_book(ativo, dados_depth):
    resultado = validar_book_institucional(dados_depth)
    estado_book[ativo] = resultado

def obter_estado_book(ativo):
    return estado_book.get(ativo, {"book_institucional_valido": True})

def iniciar_monitor_book(binance_api_key, binance_api_secret, ativo="BTCUSDT"):
    def processar_depth(msg):
        if msg["e"] == "depthUpdate":
            atualizar_estado_book(ativo, msg)

    twm = ThreadedWebsocketManager(api_key=binance_api_key, api_secret=binance_api_secret)
    twm.start()
    twm.start_depth_socket(callback=processar_depth, symbol=ativo)
    print(f"📡 Book monitor institucional ativado para {ativo}")
    return twm
