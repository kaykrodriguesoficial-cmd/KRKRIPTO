
import numpy as np
import tensorflow.keras.backend as K
from executors.logger import log_erro

def avaliar_incerteza_montecarlo(modelo, X_input, n_amostras=20):
    """
    Retorna média das predições e entropia das saídas.
    Entropia alta indica alta incerteza do modelo.
    """
    try:
        f_model = K.function([modelo.input, K.learning_phase()], [modelo.output])
        preds = np.array([f_model([X_input, 1])[0] for _ in range(n_amostras)])
        media_pred = np.mean(preds, axis=0).flatten()

        # Calcular entropia
        variancia = np.var(preds, axis=0).flatten()
        entropia = np.mean(variancia)

        return media_pred, entropia
    except Exception as e:
        log_erro(f"[INFERÊNCIA MONTECARLO] Falha: {e}")
        return [0.0], 1.0
