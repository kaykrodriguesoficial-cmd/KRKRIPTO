# src/strategies/validators/filtros_institucionais.py
import pandas as pd
import numpy as np
import logging
from src.realtime.book_processor import BookState # Assuming BookState is defined here or imported

logger = logging.getLogger("kr_kripto_validator_filtros")

def detectar_rejeicao(df: pd.DataFrame, wick_threshold=0.6) -> bool:
    """Detecta rejeição (longa sombra superior ou inferior) no último candle."""
    if len(df) < 1:
        return False
    last_candle = df.iloc[-1]
    high = last_candle.get("High", np.nan)
    low = last_candle.get("Low", np.nan)
    close = last_candle.get("Close", np.nan)
    open_ = last_candle.get("Open", np.nan)

    if pd.isna([high, low, close, open_]).any():
        logger.warning("Dados OHLC ausentes para detectar rejeição.")
        return False

    candle_range = high - low
    if candle_range == 0:
        return False # Doji ou candle sem range

    upper_wick = high - max(open_, close)
    lower_wick = min(open_, close) - low

    # Verifica se a sombra é significativamente grande em relação ao range total
    if upper_wick / candle_range > wick_threshold or lower_wick / candle_range > wick_threshold:
        logger.debug(f"Rejeição detectada: H={high}, L={low}, O={open_}, C={close}")
        return True
    return False

def detectar_volume_anormal(df: pd.DataFrame, window=20, factor=3.0) -> bool:
    """Detecta volume anormalmente alto no último candle em comparação com a média recente."""
    if "Volume" not in df.columns or len(df) < window:
        logger.debug(f"Dados insuficientes ou coluna 'Volume' ausente para detectar volume anormal (len={len(df)})." )
        return False

    last_volume = df["Volume"].iloc[-1]
    # Calcula a média excluindo o último volume
    mean_volume = df["Volume"].iloc[-window:-1].mean()

    if pd.isna(last_volume) or pd.isna(mean_volume) or mean_volume == 0:
        return False # Não é possível comparar

    if last_volume > mean_volume * factor:
        logger.debug(f"Volume anormal detectado: Último={last_volume:.2f}, Média({window-1})={mean_volume:.2f}, Fator={factor}")
        return True
    return False

def detectar_fakeout(df: pd.DataFrame) -> bool:
    """Detecta um sinal de fakeout no último candle (baseado em coluna 'fakeout')."""
    if "fakeout" not in df.columns or len(df) < 1:
        return False

    last_fakeout_signal = df["fakeout"].iloc[-1]
    if pd.notna(last_fakeout_signal) and last_fakeout_signal == 1:
        logger.debug("Fakeout detectado no último candle.")
        return True
    return False

def validar_filtro_institucional(df: pd.DataFrame, book_state: BookState):
    """Executa validações baseadas em filtros institucionais (rejeição, volume, fakeout)."""
    logger.debug(f"Executando validar_filtro_institucional...")
    try:
        if detectar_rejeicao(df):
            reason = "Rejeição detectada no último candle."
            logger.info(f"Filtro institucional falhou: {reason}")
            return False, reason

        if detectar_volume_anormal(df):
            reason = "Volume anormal detectado no último candle."
            logger.info(f"Filtro institucional falhou: {reason}")
            return False, reason

        # Assumindo que a coluna 'fakeout' é adicionada em outro lugar
        if detectar_fakeout(df):
            reason = "Fakeout detectado no último candle."
            logger.info(f"Filtro institucional falhou: {reason}")
            return False, reason

        # Outras validações usando book_state podem ser adicionadas aqui
        # Ex: if book_state.liquidez_total_bids < threshold:
        #         return False, "Baixa liquidez nos bids"

        logger.debug("Filtro institucional passou.")
        return True, "OK"

    except Exception as e:
        logger.error(f"Erro durante a validação do filtro institucional: {e}", exc_info=True)
        return False, f"Erro na validação: {e}"


