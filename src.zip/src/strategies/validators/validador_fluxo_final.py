
def validar_fluxo(ativo, modelo_usado, score_calculado, score_logado, contexto, log_final):
    '''
    Valida integridade do ciclo de decisão:
    - Confirma que o modelo logado é o mesmo que foi usado
    - Score final logado corresponde ao score realmente calculado
    - Contexto de decisão e log estão alinhados

    Parâmetros:
    - ativo: str
    - modelo_usado: nome do modelo utilizado
    - score_calculado: float calculado internamente
    - score_logado: float registrado no log
    - contexto: dict com regime, hora, probabilidade, fakeout etc.
    - log_final: dict contendo os mesmos dados do log externo
    
    Retorna: bool (True = consistente, False = há divergência)
    '''
    erros = []

    if modelo_usado != log_final.get("modelo"):
        erros.append(f"🚨 Divergência no modelo usado vs. logado: {modelo_usado} != {log_final.get('modelo')}")

    if round(score_calculado, 4) != round(log_final.get("score_final", 0), 4):
        erros.append(f"🚨 Score divergente: calculado={score_calculado}, logado={log_final.get('score_final')}")

    for chave in ["regime", "hora", "fakeout", "probabilidade"]:
        if contexto.get(chave) != log_final.get(chave):
            erros.append(f"⚠️ Divergência em {chave}: contexto={contexto.get(chave)} | log={log_final.get(chave)}")

    if erros:
        print(f"❌ Inconsistências detectadas no ciclo do ativo {ativo}:")
        for e in erros:
            print("   ", e)
        return False

    print(f"✅ Validação final OK para {ativo}.")
    return True
