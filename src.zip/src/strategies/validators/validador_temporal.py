
def validar_integridade_temporal(df, intervalo_segundos=60):
    '''
    Garante que os dados estão em ordem cronológica e não usam dados futuros.
    
    Parâmetros:
    - df: DataFrame com índice datetime.
    - intervalo_segundos: intervalo esperado entre candles (default: 60s para 1min).

    Retorna:
    - True se a integridade for válida.
    - False se houver falha.
    '''
    if df is None or df.empty:
        return False

    if not df.index.is_monotonic_increasing:
        return False

    # Garante que os timestamps estão no passado (ou no presente)
    from datetime import datetime
    agora = datetime.utcnow()
    if df.index[-1] > agora:
        return False

    # Verifica se os deltas entre candles são consistentes
    deltas = df.index.to_series().diff().dropna().dt.total_seconds()
    if not all(abs(delta - intervalo_segundos) <= 2 for delta in deltas):
        return False

    return True
