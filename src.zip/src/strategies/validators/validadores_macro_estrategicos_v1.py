
import random

def validar_indicadores_macro(ativo):
    """
    Mock estratégico: em produção, conectar ao feed externo real (ex: Binance API, Glassnode, Coinglass).
    """
    funding_rate = random.uniform(-0.05, 0.05)
    open_interest = random.randint(500, 1500)
    book_imbalance = random.uniform(-1, 1)

    if abs(funding_rate) > 0.03:
        return False
    if open_interest < 600:
        return False
    if abs(book_imbalance) > 0.8:
        return False
    return True
