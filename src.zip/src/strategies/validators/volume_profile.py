# src/strategies/validators/volume_profile.py
import pandas as pd
import logging

logger = logging.getLogger("kr_kripto_validator_volume")

def validador_volume_profile(df: pd.DataFrame):
    logger.debug(f"validador_volume_profile (stub) chamado.")
    # Retorna True (válido) como placeholder
    return True

