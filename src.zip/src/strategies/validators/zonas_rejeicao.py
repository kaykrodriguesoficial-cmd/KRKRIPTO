# src/strategies/validators/zonas_rejeicao.py
import pandas as pd
import logging

logger = logging.getLogger("kr_kripto_validator_zonas")

def validador_zona_rejeicao(df: pd.DataFrame):
    logger.debug(f"validador_zona_rejeicao (stub) chamado.")
    # Retorna True (válido) como placeholder
    return True

