#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Módulo de carregamento de configurações.

Este módulo fornece funções para carregar configurações de arquivos
ou dicionários, com suporte a fallbacks e configurações padrão.

Autor: Equipe KR_KRIPTO
Data: Maio 2025
Versão: 2.0
"""

import os
import json
import yaml
import logging
import copy
from typing import Dict, Any, Union, Optional

# Configurar logging
try:
    from src.utils.logger_config import setup_logger
    logger = setup_logger("utils.config_loader")
except ImportError:
    # Fallback para logging padrão
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger("utils.config_loader")

class ConfigLoader:
    """
    Classe para carregamento e gerenciamento de configurações.
    
    Esta classe fornece métodos para carregar, salvar e manipular
    configurações de arquivos ou dicionários.
    
    Attributes:
        config_path (str): Caminho do arquivo de configuração
        config (Dict): Configurações carregadas
    """
    
    def __init__(self, config_path: Union[str, Dict, None] = None):
        """
        Inicializa o carregador de configurações.
        
        Args:
            config_path: Caminho do arquivo de configuração, dicionário de configuração ou None
        """
        self.config_path = config_path
        self.config = carregar_config(config_path)
        logger.info("ConfigLoader inicializado")
    
    def get_config(self) -> Dict[str, Any]:
        """
        Retorna as configurações carregadas.
        
        Returns:
            Dict: Configurações
        """
        return self.config
    
    def get_value(self, caminho: str, padrao: Any = None) -> Any:
        """
        Obtém um valor específico da configuração.
        
        Args:
            caminho: Caminho do valor (ex: "database.host")
            padrao: Valor padrão se o caminho não existir
            
        Returns:
            Any: Valor encontrado ou valor padrão
        """
        return obter_valor_config(self.config, caminho, padrao)
    
    def set_value(self, caminho: str, valor: Any) -> None:
        """
        Define um valor específico na configuração.
        
        Args:
            caminho: Caminho do valor (ex: "database.host")
            valor: Novo valor
        """
        self.config = definir_valor_config(self.config, caminho, valor)
    
    def save(self, config_path: str = None) -> bool:
        """
        Salva as configurações em um arquivo.
        
        Args:
            config_path: Caminho do arquivo de configuração (opcional)
            
        Returns:
            bool: True se salvou com sucesso
        """
        path = config_path or self.config_path
        if isinstance(path, str):
            return salvar_config(self.config, path)
        else:
            logger.error("Caminho de configuração inválido para salvar")
            return False
    
    def reload(self) -> Dict[str, Any]:
        """
        Recarrega as configurações do arquivo.
        
        Returns:
            Dict: Configurações recarregadas
        """
        self.config = carregar_config(self.config_path)
        return self.config
    
    def validate(self, schema: Dict[str, Any]) -> bool:
        """
        Valida as configurações contra um schema.
        
        Args:
            schema: Schema de validação
            
        Returns:
            bool: True se as configurações são válidas
        """
        return validar_config(self.config, schema)


def obter_config_padrao() -> Dict[str, Any]:
    """
    Retorna a configuração padrão.
    
    Returns:
        Dict: Configuração padrão
    """
    return {
        "ambiente": "desenvolvimento",
        "logging": {
            "level": "INFO",
            "formato": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            "arquivo": "logs/app.log",
            "rotacao": "daily"
        },
        "database": {
            "host": "localhost",
            "port": 5432,
            "user": "postgres",
            "password": "",
            "dbname": "kripto_db"
        },
        "api": {
            "host": "0.0.0.0",
            "port": 8000,
            "debug": True,
            "timeout": 30
        },
        "seguranca": {
            "secret_key": "chave_secreta_padrao",
            "algoritmo": "HS256",
            "expiracao_token": 3600
        },
        "cache": {
            "enabled": True,
            "ttl": 300,
            "max_size": 1000
        },
        "limites": {
            "max_requisicoes_por_minuto": 60,
            "max_conexoes": 100,
            "timeout_conexao": 5
        },
        "notificacoes": {
            "email": {
                "enabled": False,
                "smtp_server": "smtp.example.com",
                "smtp_port": 587,
                "username": "",
                "password": ""
            },
            "telegram": {
                "enabled": False,
                "token": "",
                "chat_id": ""
            }
        },
        "automl": {
            "n_trials": 5,
            "window_size": 10,
            "adaptation_rate": 0.1,
            "min_weight": 0.1,
            "default_weight": 0.5,
            "max_modelos": 5,
            "timeout": 3600,
            "otimizacao": "bayesiana",
            "metrica_avaliacao": "f1",
            "usar_ensemble": True,
            "caminho_modelos": "models"
        },
        "reinforcement": {
            "algoritmo": "dqn",
            "gamma": 0.99,
            "learning_rate": 0.001,
            "epsilon": 0.1,
            "epsilon_decay": 0.995,
            "epsilon_min": 0.01,
            "batch_size": 32,
            "memory_size": 10000,
            "target_update": 10,
            "max_episodes": 1000,
            "max_steps": 500,
            "reward_threshold": 200
        }
    }

def carregar_config(config_path: Union[str, Dict, None] = None) -> Dict[str, Any]:
    """
    Carrega configurações de um arquivo ou dicionário, com suporte a fallbacks robustos.
    
    Args:
        config_path: Caminho do arquivo de configuração, dicionário de configuração ou None
        
    Returns:
        Dict: Configurações carregadas ou configuração padrão se falhar
    """
    # Caso 1: config_path é None
    if config_path is None:
        logger.info("Nenhuma configuração fornecida, usando configuração padrão")
        return obter_config_padrao()
    
    # Caso 2: config_path já é um dicionário
    if isinstance(config_path, dict):
        logger.info("Usando configuração fornecida como dicionário")
        return copy.deepcopy(config_path)
    
    # Caso 3: config_path é um caminho de arquivo
    try:
        if not os.path.exists(config_path):
            logger.warning(f"Arquivo de configuração não encontrado: {config_path}")
            logger.info("Usando configuração padrão")
            return obter_config_padrao()
        
        # Fazer backup do arquivo de configuração antes de carregar
        try:
            backup_path = f"{config_path}.bak"
            with open(config_path, 'r') as src, open(backup_path, 'w') as dst:
                dst.write(src.read())
            logger.debug(f"Backup da configuração criado em {backup_path}")
        except Exception as e:
            logger.warning(f"Não foi possível criar backup da configuração: {e}")
        
        # Carregar configuração do arquivo
        with open(config_path, 'r') as f:
            conteudo = f.read()
            
            # Determinar formato do arquivo
            if config_path.endswith('.json'):
                config = json.loads(conteudo)
                logger.info(f"Configuração carregada de {config_path} (JSON)")
            elif config_path.endswith(('.yaml', '.yml')):
                config = yaml.safe_load(conteudo)
                logger.info(f"Configuração carregada de {config_path} (YAML)")
            else:
                # Tentar JSON primeiro, depois YAML
                try:
                    config = json.loads(conteudo)
                    logger.info(f"Configuração carregada de {config_path} (detectado como JSON)")
                except json.JSONDecodeError:
                    try:
                        config = yaml.safe_load(conteudo)
                        logger.info(f"Configuração carregada de {config_path} (detectado como YAML)")
                    except yaml.YAMLError:
                        logger.error(f"Formato de configuração não reconhecido: {config_path}")
                        logger.info("Usando configuração padrão")
                        return obter_config_padrao()
        
        # Mesclar com configuração padrão para garantir que todos os campos existam
        config_padrao = obter_config_padrao()
        config_final = mesclar_configs(config_padrao, config)
        
        return config_final
        
    except Exception as e:
        logger.error(f"Erro ao carregar configuração: {e}")
        logger.info("Usando configuração padrão")
        return obter_config_padrao()

def mesclar_configs(config_base: Dict[str, Any], config_override: Dict[str, Any]) -> Dict[str, Any]:
    """
    Mescla duas configurações, com a segunda sobrescrevendo a primeira.
    
    Args:
        config_base: Configuração base
        config_override: Configuração que sobrescreve a base
        
    Returns:
        Dict: Configuração mesclada
    """
    resultado = copy.deepcopy(config_base)
    
    for chave, valor in config_override.items():
        if isinstance(valor, dict) and chave in resultado and isinstance(resultado[chave], dict):
            # Recursivamente mesclar subdicionários
            resultado[chave] = mesclar_configs(resultado[chave], valor)
        else:
            # Sobrescrever valor
            resultado[chave] = copy.deepcopy(valor)
    
    return resultado

def salvar_config(config: Dict[str, Any], config_path: str) -> bool:
    """
    Salva configurações em um arquivo.
    
    Args:
        config: Configurações a serem salvas
        config_path: Caminho do arquivo de configuração
        
    Returns:
        bool: True se salvou com sucesso
    """
    try:
        # Criar diretório se não existir
        os.makedirs(os.path.dirname(os.path.abspath(config_path)), exist_ok=True)
        
        # Fazer backup do arquivo existente
        if os.path.exists(config_path):
            backup_path = f"{config_path}.bak"
            with open(config_path, 'r') as src, open(backup_path, 'w') as dst:
                dst.write(src.read())
            logger.debug(f"Backup da configuração criado em {backup_path}")
        
        # Determinar formato do arquivo
        if config_path.endswith('.json'):
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=2)
            logger.info(f"Configuração salva em {config_path} (JSON)")
        elif config_path.endswith(('.yaml', '.yml')):
            with open(config_path, 'w') as f:
                yaml.dump(config, f, default_flow_style=False)
            logger.info(f"Configuração salva em {config_path} (YAML)")
        else:
            # Usar JSON como formato padrão
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=2)
            logger.info(f"Configuração salva em {config_path} (formato padrão: JSON)")
        
        return True
        
    except Exception as e:
        logger.error(f"Erro ao salvar configuração: {e}")
        return False

def obter_valor_config(config: Dict[str, Any], caminho: str, padrao: Any = None) -> Any:
    """
    Obtém um valor específico da configuração usando notação de caminho.
    
    Args:
        config: Configuração
        caminho: Caminho do valor (ex: "database.host")
        padrao: Valor padrão se o caminho não existir
        
    Returns:
        Any: Valor encontrado ou valor padrão
    """
    try:
        partes = caminho.split('.')
        valor = config
        
        for parte in partes:
            if isinstance(valor, dict) and parte in valor:
                valor = valor[parte]
            else:
                return padrao
        
        return valor
        
    except Exception as e:
        logger.error(f"Erro ao obter valor de configuração '{caminho}': {e}")
        return padrao

def definir_valor_config(config: Dict[str, Any], caminho: str, valor: Any) -> Dict[str, Any]:
    """
    Define um valor específico na configuração usando notação de caminho.
    
    Args:
        config: Configuração
        caminho: Caminho do valor (ex: "database.host")
        valor: Novo valor
        
    Returns:
        Dict: Configuração atualizada
    """
    try:
        resultado = copy.deepcopy(config)
        partes = caminho.split('.')
        
        # Navegar até o penúltimo nível
        atual = resultado
        for i, parte in enumerate(partes[:-1]):
            if parte not in atual or not isinstance(atual[parte], dict):
                atual[parte] = {}
            atual = atual[parte]
        
        # Definir valor no último nível
        atual[partes[-1]] = valor
        
        return resultado
        
    except Exception as e:
        logger.error(f"Erro ao definir valor de configuração '{caminho}': {e}")
        return config

def validar_config(config: Dict[str, Any], schema: Dict[str, Any]) -> bool:
    """
    Valida uma configuração contra um schema.
    
    Args:
        config: Configuração a ser validada
        schema: Schema de validação
        
    Returns:
        bool: True se a configuração é válida
    """
    try:
        # Implementação básica de validação
        # Para uma validação mais robusta, considerar usar jsonschema
        
        for chave, valor_schema in schema.items():
            # Verificar se a chave existe
            if chave not in config:
                logger.error(f"Chave obrigatória ausente na configuração: {chave}")
                return False
            
            # Verificar tipo
            if isinstance(valor_schema, dict) and 'type' in valor_schema:
                tipo_esperado = valor_schema['type']
                valor_config = config[chave]
                
                if tipo_esperado == 'string' and not isinstance(valor_config, str):
                    logger.error(f"Tipo inválido para {chave}: esperado string, recebido {type(valor_config).__name__}")
                    return False
                elif tipo_esperado == 'number' and not isinstance(valor_config, (int, float)):
                    logger.error(f"Tipo inválido para {chave}: esperado number, recebido {type(valor_config).__name__}")
                    return False
                elif tipo_esperado == 'boolean' and not isinstance(valor_config, bool):
                    logger.error(f"Tipo inválido para {chave}: esperado boolean, recebido {type(valor_config).__name__}")
                    return False
                elif tipo_esperado == 'object' and not isinstance(valor_config, dict):
                    logger.error(f"Tipo inválido para {chave}: esperado object, recebido {type(valor_config).__name__}")
                    return False
                elif tipo_esperado == 'array' and not isinstance(valor_config, list):
                    logger.error(f"Tipo inválido para {chave}: esperado array, recebido {type(valor_config).__name__}")
                    return False
                
                # Validar recursivamente objetos aninhados
                if tipo_esperado == 'object' and 'properties' in valor_schema:
                    if not validar_config(valor_config, valor_schema['properties']):
                        return False
        
        return True
        
    except Exception as e:
        logger.error(f"Erro ao validar configuração: {e}")
        return False
