#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Módulo para configuração centralizada de logging com rotação automática.

Este módulo fornece funções para configurar logging com rotação automática
de arquivos, garantindo que os logs não cresçam indefinidamente.

Autor: Equipe KR_KRIPTO
Data: Maio 2025
"""

import os
import logging
from logging.handlers import TimedRotatingFileHandler
import json
from datetime import datetime

def configurar_logging(nome_logger, nivel=logging.INFO, arquivo_log=None, formato=None, console=True):
    """
    Configura um logger com rotação automática de arquivos.
    
    Args:
        nome_logger: Nome do logger
        nivel: Nível de logging (default: logging.INFO)
        arquivo_log: Caminho do arquivo de log (default: None)
        formato: Formato das mensagens de log (default: None)
        console: Se True, adiciona um StreamHandler para console (default: True)
        
    Returns:
        logging.Logger: Logger configurado
    """
    # Criar logger
    logger = logging.getLogger(nome_logger)
    logger.setLevel(nivel)
    
    # Limpar handlers existentes
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # Definir formato padrão se não especificado
    if formato is None:
        formato = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    formatter = logging.Formatter(formato)
    
    # Adicionar handler para console
    if console:
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
    
    # Adicionar handler para arquivo com rotação
    if arquivo_log:
        # Garantir que o diretório do arquivo de log existe
        os.makedirs(os.path.dirname(os.path.abspath(arquivo_log)), exist_ok=True)
        
        # Configurar rotação diária com retenção de 30 dias
        file_handler = TimedRotatingFileHandler(
            filename=arquivo_log,
            when='midnight',
            interval=1,
            backupCount=30,
            encoding='utf-8'
        )
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger

def configurar_logging_json(nome_logger, nivel=logging.INFO, arquivo_log=None, console=True):
    """
    Configura um logger com formato JSON e rotação automática de arquivos.
    
    Args:
        nome_logger: Nome do logger
        nivel: Nível de logging (default: logging.INFO)
        arquivo_log: Caminho do arquivo de log (default: None)
        console: Se True, adiciona um StreamHandler para console (default: True)
        
    Returns:
        logging.Logger: Logger configurado
    """
    class JsonFormatter(logging.Formatter):
        """Formatter que produz logs em formato JSON."""
        
        def format(self, record):
            log_data = {
                'timestamp': datetime.utcnow().isoformat(),
                'level': record.levelname,
                'logger': record.name,
                'message': record.getMessage(),
            }
            
            # Adicionar informações de exceção se disponíveis
            if record.exc_info:
                log_data['exception'] = self.formatException(record.exc_info)
            
            # Adicionar atributos extras
            for key, value in record.__dict__.items():
                if key not in ['args', 'asctime', 'created', 'exc_info', 'exc_text', 'filename',
                              'funcName', 'id', 'levelname', 'levelno', 'lineno', 'module',
                              'msecs', 'message', 'msg', 'name', 'pathname', 'process',
                              'processName', 'relativeCreated', 'stack_info', 'thread', 'threadName']:
                    log_data[key] = value
            
            return json.dumps(log_data)
    
    # Criar logger
    logger = logging.getLogger(nome_logger)
    logger.setLevel(nivel)
    
    # Limpar handlers existentes
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    formatter = JsonFormatter()
    
    # Adicionar handler para console
    if console:
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
    
    # Adicionar handler para arquivo com rotação
    if arquivo_log:
        # Garantir que o diretório do arquivo de log existe
        os.makedirs(os.path.dirname(os.path.abspath(arquivo_log)), exist_ok=True)
        
        # Configurar rotação diária com retenção de 30 dias
        file_handler = TimedRotatingFileHandler(
            filename=arquivo_log,
            when='midnight',
            interval=1,
            backupCount=30,
            encoding='utf-8'
        )
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger

# Exemplo de uso
if __name__ == "__main__":
    # Configurar logging básico
    logger = configurar_logging(
        nome_logger="exemplo",
        nivel=logging.DEBUG,
        arquivo_log="logs/exemplo.log"
    )
    
    # Testar logging
    logger.debug("Mensagem de debug")
    logger.info("Mensagem de info")
    logger.warning("Mensagem de warning")
    logger.error("Mensagem de erro")
    
    # Configurar logging JSON
    logger_json = configurar_logging_json(
        nome_logger="exemplo_json",
        nivel=logging.DEBUG,
        arquivo_log="logs/exemplo_json.log"
    )
    
    # Testar logging JSON
    logger_json.debug("Mensagem de debug em JSON")
    logger_json.info("Mensagem de info em JSON")
    logger_json.warning("Mensagem de warning em JSON")
    logger_json.error("Mensagem de erro em JSON")
